/* ctcp.h  */
/* Functions that allow slisp to be accessed from external C routines over the network.   jfb 9/8/94 */
#define XTCP_ERR_RETURN -1
#define XTCP_DEFAULT_TIMEOUT 5

extern int xtcp_Connect();
extern void xtcp_Disconnect();
extern void xtcp_Eval_Str();
extern int xtcp_Int();
extern float xtcp_Float();
extern char *xtcp_String();
extern int xtcp_Int_Eval_Str();
extern float xtcp_Float_Eval_Str();
extern char *xtcp_Str_Eval_Str();
extern void xtcp_Open_Transcript();
extern void xtcp_Close_Transcript();
extern void xtcp_Stack_Check();

