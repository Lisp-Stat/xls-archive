/* {{{ ctcp.c -- tcp functions for slisp				*/

/* This file is formatted for use with folding.el for emacs, sort	*/
/* of an outline-mode for programmers, ftp-able from elisp archives	*/
/* such as tut.cis.ohio-state.edu (128.146.8.52).  If you don't use	*/
/* folding-mode and/or emacs, you may want to prepare a table of	*/
/* contents for this file by doing "grep '{{{' thisfile.c".		*/

/************************************************************************/
/*                              history                                 */
/*									*/
/* 									*/
/* 94Sept9 jfb: Created.						*/
/************************************************************************/

/* }}} */

/* {{{ Header stuff							*/

#include "ctcp.h" 
#include <strings.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

/* Manifest constants: */
#define INITIAL_RESULT_BUF_SIZE (2)
#ifndef TRUE
#define TRUE	(1)
#endif
#ifndef FALSE
#define FALSE	(0)
#endif
#define max(a,b) ((a) > (b) ? (a) : (b))
#define min(a,b) ((a) < (b) ? (a) : (b))


/* Global variables: */
static struct sockaddr_in sa;
static struct hostent *hp;
static FILE *xtcp_tfp = NULL;
static int timeout=XTCP_DEFAULT_TIMEOUT;

static int  data=2;
static int  end=3;
static int  err=16;

/* External variables: */

/* External routines: */

/* Forward declarations: */
static void buf_putc();
static void buf_reset();
static void buf_double();
static void buf_init();
static int receiveChars();
static int data_waiting();
static int ready_for_writing();

/* A buffer in which we return string values: */
static char* result_buf     = NULL;
static int   result_buf_len = 0;
static int   result_buf_ptr = 0;
static char *message_start = NULL;

/* }}} */

/* --- Central externally callable routines ---				*/
/* {{{ xtcp_Connect -- Connect to a host				*/

int xtcp_Connect(hostaddr, portid)
const char *hostaddr;
int portid;
{
    /* Connect to hostadd on port id, return socket number if connection
    is successful, XTCP_ERR_RETURN if not. 
    I think only one connection can be open 
    because sa is global, but I need to check that */
    int s;
    if ((hp=gethostbyname((char *)hostaddr)) == NULL) return XTCP_ERR_RETURN;
    bcopy((char *)hp->h_addr,(char *)&sa.sin_addr,hp->h_length);
    sa.sin_family = hp->h_addrtype;
    sa.sin_port = portid;
    if((s = socket(hp->h_addrtype,SOCK_STREAM,0)) < 0) return XTCP_ERR_RETURN;
    if(connect(s,(struct sockaddr *) &sa,sizeof(sa)) < 0) 
	return XTCP_ERR_RETURN;
    else
	return s;
}
/* }}} */
/* {{{ xtcp_Disconnect -- Disconnect from a host			*/
     
void xtcp_Disconnect(s)
int s;
{
    /* Disconnect previously connected socket s */ 
    close(s);
}
/* }}} */
/* {{{ xtcp_Eval_Str -- Main evaluate-string-and-return-string entrypt.	*/

void xtcp_Eval_Str(s, got_err, outstr, instr )
int s;
int* got_err;
char **outstr,*instr;
{
    /* Send instr to socket s, which is assumed to be connected to an 
    slisp server via xtcp_connect. Instr must be a a valid s-expr.
    If an error is returned by the server set got_err to be TRUE,
    with the contents of outstr being the error message. Otherwise got_err
    is FALSE and the contents of outstr are the normal output. If the
    server times out, set got_err to TRUE with an appropriate error
    message in outstr */
    char *dataptr, *errptr, *endptr, *transptr;
    /* if (!xtcp_tfp) xtcp_Open_Transcript("/tmp/trans.txt", &transptr); */
    *got_err  = FALSE;
   if (xtcp_tfp) fprintf(xtcp_tfp, "instr: %s\n", instr);
    /* Check to be sure the connection is valid */
    if (!ready_for_writing(s)) {
	*got_err = TRUE;
	*outstr="connection not open";
	buf_reset();
	return;
	}
    /* Flush any existing input */
    buf_reset();
    while (data_waiting(s)) 
	if (!receiveChars(s)) {
	  *got_err = TRUE;
	  *outstr = "server timeout";
	  xtcp_Disconnect(s); 
	  buf_reset();
	  return;
	  }
    buf_reset();
    /* Send the input string */
    write(s, instr, strlen(instr));
    write(s, "\n", 1);
     /* Look for start of message */
    if (!receiveChars(s)) {
	*got_err = TRUE;
	*outstr = "server timeout";
	xtcp_Disconnect(s); 
	buf_reset();
	return;
	}
    dataptr = index(result_buf, data);
    errptr = index(result_buf,err);
    if (!dataptr && !errptr) {
	*got_err = TRUE;
	*outstr = "server incorrect delimeters";
	buf_reset();
	return;
	}
    if (!errptr) 
	*got_err = FALSE;
    else if (!dataptr)
	*got_err = TRUE;
    else if (dataptr < errptr)
	*got_err = FALSE;
    else
	*got_err = TRUE;
    if (*got_err == TRUE)
  	message_start = errptr+1;
    else
	message_start = dataptr+1;
    /* Read rest of message up to end character */
    while (!(endptr = index(result_buf,end))) {
        if (!receiveChars(s)) {
	  *got_err = TRUE;
	  *outstr = "server timeout";
	  buf_reset();
 	  return;
	  }
 	}
    *endptr='\0';
    /* If got_err strip off initial error:, since calling routine
    will put it back */
    if ((*got_err == TRUE) && (!strncmp(message_start,"error:", 6))) 
	*outstr=message_start+6;
    else
        *outstr=message_start;
    if (xtcp_tfp) fprintf(xtcp_tfp, "outstr: %s\n", *outstr);
    return;
}

/* }}} */
/* {{{ xtcp_Int -- Return integer value of current buffer		*/

int xtcp_Int( got_err )
int        *got_err;
{
    int val;
    *got_err = FALSE;
    if (!message_start) {
	*got_err = TRUE;
	return XTCP_ERR_RETURN;
	}
    sscanf(message_start, "%d", &val);
    return val;
}

/* }}} */
/* {{{ xtcp_Float -- Return float value of current buffer		*/

float xtcp_Float( got_err )
int            *got_err;
{
    float val;
    *got_err = FALSE;
    if (!message_start) {
	*got_err = TRUE;
	return -1.0;
	}
    sscanf(message_start, "%f", &val);
    return val;
}

/* }}} */
/* {{{ xtcp_String -- Return string value of current buffer		*/

char *xtcp_String( got_err )
int             *got_err;
{
    *got_err = FALSE;
    if (!message_start) {
	*got_err = TRUE;
	return "";
	}
    return message_start;
}

/* }}} */

/* --- Additional convenience externally callable routines ---		*/
/* {{{ xtcp_Int_Eval_Str -- Eval 'instr', return int result.		*/

int xtcp_Int_Eval_Str(s, got_err, outstr, instr )
int s;
int                 *got_err;
char                        **outstr,*instr;
{
    xtcp_Eval_Str(s, got_err, outstr, instr );
    if (*got_err)   return 0;
    else            return xtcp_Int( got_err );
}

/* }}} */
/* {{{ xtcp_Float_Eval_Str -- Eval 'instr', return float result.		*/

float xtcp_Float_Eval_Str(s, got_err, outstr, instr)
int s;
int                     *got_err;
char                            **outstr,*instr;
{
    xtcp_Eval_Str(s, got_err, outstr, instr );
    if (*got_err)   return 0.0;
    else            return xtcp_Float( got_err );
}

/* }}} */
/* {{{ xtcp_Str_Eval_Str -- Eval 'instr', return string result.		*/

char *xtcp_Str_Eval_Str(s, got_err, outstr, instr )
int s;
int                   *got_err;
char                          **outstr,*instr;
{
    xtcp_Eval_Str(s, got_err, outstr, instr );
    if (*got_err)   return "";
    else            return xtcp_String( got_err );
}

/* }}} */

/* --- Internal routines ---						*/
/* {{{ buf_init -- Establish result_buf.				*/
	
static void buf_init( void ) {
    result_buf_len = INITIAL_RESULT_BUF_SIZE;
    result_buf = (char*) malloc( result_buf_len );
    if (!result_buf) {
	fputs("slisp.c:buf_init: out of ram!?\n",stderr);
	abort();
    }
}

/* }}} */
/* {{{ buf_double -- Double size of result_buf.				*/
	
static void buf_double( void ) {
    result_buf_len *= 2;
    result_buf = (char*) realloc( result_buf, result_buf_len );
    if (!result_buf) {
	fputs("slisp.c:buf_double: out of ram!?\n",stderr);
	abort();
    }
}

/* }}} */
/* {{{ buf_putc -- Append one char to result_buf.			*/

	
static void buf_putc( c )
int                   c;
{
    if (result_buf_ptr + 2 >= result_buf_len)   buf_double();
    result_buf[ result_buf_ptr++ ] =   c ;
    result_buf[ result_buf_ptr   ] = '\0';
}

/* }}} */
/* {{{ buf_reset -- Set result_buf to empty string 				*/
	
static void buf_reset( void ) 
{ 
    if (!result_buf_len) buf_init();
    result_buf_ptr = 0; 
    result_buf[ result_buf_ptr   ] = '\0';
    message_start=NULL;
}

/* }}} */

/* {{{ receiveChars --- Read characters from read buffer		*/

static int receiveChars(s)
int s;
{
    /* Continuously poll connected socket s to find out if data is 
    waiting to be read. If no data is avaialble within timeout seconds
    return 0, which can be interpreted as a network or server timeout.
    Once data is available keep reading it until no more is available. A
    "nicer" process is commented out - in this case the client sleeps
    for 1 second if data is not initially present. However this results
    in the client always sleeping for 1 second since data is never waiting
    when this routine is first called. Since most client programs will
    be run on individual workstations it didn't seem necessary to be this
    nice at the expense of extra delay   - jfb  */
    int i,j, total;
    char buf[BUFSIZ+1];
    struct timeval tv;
    struct timezone tz;
    int starttime, currenttime;
     i=0;
    gettimeofday(&tv,&tz);
    starttime = tv.tv_sec;
    /* while ((data_waiting(s) == 0) && (i++<timeout)) sleep(1);  */ 
    total=0;
    while (data_waiting(s) == 0) {
	gettimeofday(&tv,&tz); 
	currenttime = tv.tv_sec;
	if ((currenttime - starttime) >= timeout) return 0;
	}
     while (data_waiting(s) > 0)  {
	i = read(s, buf, BUFSIZ);
	if(!i) return(0);
	for(j=0;j<i;j++) buf_putc(buf[j]);
	total += i;
    }
    return(total);
}

/* {{{ data_waiting --- Check for data in read buffer			*/
static int data_waiting(s)
int s;
{
  fd_set fds;
  struct timeval to;
  int n;
  to.tv_sec=0;
  to.tv_usec=0;
  FD_ZERO(&fds);
  FD_SET(s,&fds);
  n=select(s+1,&fds,0,0,&to);
  return(n);
}
/* }}} */
	
/* {{{ ready_for_writing --- Check for open connection			*/
static int ready_for_writing(s)
int s;
{
  struct stat buf;
  int st;
  st = fstat(s,&buf);
  if(!st) 
    return TRUE;
  else
    return FALSE;
}
/* }}} */

/* --- Debugging routines ---						*/
/* {{{ xtcp_Open_Transcript -- Open debug session logfile.			*/

void xtcp_Open_Transcript( fullpath, outstr )
char               *fullpath,**outstr;

/* Open a transcript file, given by fullpath, for writing.	*/
/* All input and output to slisp will be written to this file,	*/
/* which will then be closed on exit or by explicit call to	*/
/* xtcp_Wrapup. This is useful for debugging slisp as it receives	*/
/* commands from a separate C program, which may not be		*/
/* printing out the results of slisp as it executes.		*/
{
    char outbuf[200];
    int i;
    buf_reset();
    if ((xtcp_tfp = fopen(fullpath, "w")) == NULL) {
      sprintf(outbuf, "error: can't open slisp transcript file: %s", fullpath);
    } else {
      sprintf(outbuf, "xtcp transcript file %s opened", fullpath);
    }  
    for(i=0;i<strlen(outbuf); i++) buf_putc(outbuf[i]);
    *outstr=result_buf;
    return; 
}

/* }}} */

/* {{{ xtcp_Close_Transcript -- Close debug logfile			*/

void xtcp_Close_Transcript() {
    /* Close the xtcp transcript file if it exists. Don't exit since	*/
    /* the controlling program might want to do other wrapup first.	*/
    if (xtcp_tfp) fclose(xtcp_tfp);
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/


/* }}} */

    
