/* xnet.c  */

#include "../../xcore/c/xlisp.h"
#include "../../include/netseval.h"

extern LVAL true;
extern LVAL xformat();
extern int current_socket;
extern int client_end;
extern int client_data;
static void xnetfail();

LVAL xlnet_connect()
{
    /* (NET-CONNECT <hostname> <portid>)	*/
    LVAL hostname, portid;
    int sock;
    int got_err;
    char *outstr, *err;
    hostname= xlgastring();
    portid = xlgafixnum();
    xllastarg();
    sock = 
      sn_Connect(getstring(hostname), getfixnum(portid), 
		 &got_err, &outstr, &err);
    if(outstr)
	stdputstr(outstr);
    if (got_err) xnetfail(err);
    return(cvfixnum(sock));
}

LVAL xlnet_close()
{
    /* (NET-CLOSE <socket>) */
    LVAL sock;
    sock = xlgafixnum();
    xllastarg(); 
    sn_Disconnect(getfixnum(sock));
    return(true);
}

LVAL xlnet_set_socket()
{
    /* (NET-SET-SOCKET <socket>) */
    LVAL sock;
    sock = xlgafixnum();
    xllastarg(); 
    sn_Set_Socket(getfixnum(sock));
    return(sock);
}
LVAL xlnet_set_timeout()
{
    /* (NET-SET-TIMEOUT &optional <seconds>) */
    LVAL timeexpr;
    int seconds;
    if (moreargs()) {
       timeexpr = xlgafixnum();
       seconds = getfixnum(timeexpr);
       }
    else
       seconds = SN_DEFAULT_TIMEOUT;
    xllastarg(); 
    sn_Set_Timeout(seconds);
    return(cvfixnum(seconds));
}

LVAL xlnet_set_delimiters()
{
    /* (NET-SET-DELIMITERS &key :DATA <data_char> :END <end_char> :RESET ) */
    LVAL endexpr, dataexpr, keysym;
    int endchar, datachar, got_err;
    char *outstr;
    int nlvals = 3;
    xlsave(endexpr);
    xlsave(dataexpr);
    xlsave(keysym);
    endchar=client_end;
    datachar=client_data;
    while (moreargs()) {
       keysym = xlgasymbol();
       if (keysym == xlenter(":RESET")) {
	  datachar = SN_DEFAULT_DATA;
	  endchar = SN_DEFAULT_END;
	  break;
	  }
       else if (keysym == xlenter(":DATA")) {
	  dataexpr = xlgafixnum();
	  datachar = getfixnum(dataexpr);
	  }
       else if (keysym == xlenter(":END")) {
	  endexpr = xlgafixnum();
	  endchar = getfixnum(endexpr);
	  }
       else
	  xlerror("unknown key symbol", keysym);
       }
    sn_Set_Delimiters(datachar, endchar, &got_err, &outstr);
    xlpopn(nlvals);
    if(got_err) xnetfail(outstr);
    return(true);
}

LVAL xlnet_eval()
{
    /* (NET-EVAL <expr> &key :SOCKET <socketnumber>)  */
    int got_err;
    char *result, *outstr;
    LVAL expr,strexpr,  lp, ustr, retval, sockey, sockval;
    int nlvals = 7;
    int socknum, savecurrentsocket;
    socknum = -1;
    savecurrentsocket = current_socket;
    xlsave(expr);
    xlsave(strexpr);
     xlsave(lp);
    xlsave(ustr);
    xlsave(retval);
    xlsave(sockey);
    xlsave(sockval);
     /* Get the argument */
    expr = xlgetarg();
    /* Get socket keyword if it is present */
    if (moreargs()) {
	sockey = xlgasymbol();
	if (sockey == xlenter(":SOCKET")) {
	   sockval=xlgafixnum();
	   socknum = getfixnum(sockval);
	   }
	else
	   xlerror("unknown key", sockey);
	}
    xllastarg();
    if (socknum > 0) current_socket = socknum;
    /* Setup args to xformat to format expr as a string */
    lp=consa(expr);
    lp=cons(xlenter("QUOTE"), lp);
    lp=consa(lp);
    lp=cons(cvstring("~S"),lp);
    lp=cons(NIL,lp);
    lp=cons(xlenter("FORMAT"),lp);
    strexpr=xleval(lp);
    /* Evaluate the string */
    result = sn_Eval_Str(&got_err, &outstr, getstring(strexpr));
    current_socket = savecurrentsocket;
    /* If result != outstr then output was generated before data or error */
    if (result != outstr) stdputstr(result);
    /* If got_err is true then use use xlisp error mechanism to return */
    if (got_err) {
	xlpopn(nlvals);
	xnetfail(outstr);
	}
    /* Otherwise convert output string to an unnamed stream and read it.  */ 
    strexpr=cvstring(outstr);
    lp=consa(strexpr);
    lp=cons(xlenter("MAKE-STRING-INPUT-STREAM"), lp);
    ustr=xleval(lp);
    lp=consa(ustr);
    lp=(cons(xlenter("READ"), lp));
    retval=xleval(lp);
    xlpopn(nlvals);
    return(retval);
}

/* Internal function to strip off lf from an xlisp error message before
passing to xlfail. Assumes error messages are reasonably small  */    
#define MAXERR 4096
static void xnetfail(msg)  
char *msg; 
{
  int c;
  char outmsg[MAXERR+1];
  char *dst=outmsg;
  if (strlen(msg) > MAXERR) xlfail("Server error message too long");
  while (c = *msg++) if (c != '\n') *dst++ = c;
  *dst = '\0';
  xlfail(outmsg);
}
	   
    
