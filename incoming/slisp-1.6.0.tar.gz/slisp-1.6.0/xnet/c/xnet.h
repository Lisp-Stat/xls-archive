/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xnet.h
* Description:  Template for xlisp extension-module file headers.
* Author:       Jim Brinkley
* Created:      94Sep12
* Modified:        
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1994, University of Washington 
*
*********************************************************************************/ /* Not infrequently, implementing a new xlisp class requires adding some  */
/* new primitive (== "implemented in C") functions to xlisp.  The new	  */
/* primitives may be needed to access special hardware resources, or they */
/* may be speed hacks needed to achieve acceptable performance.		  */
/* 								          */
/* This file is a template showing how to do so.  Make a copy of this	  */
/* file called, say, "xmyclass.h", insert a '#include "xmyclass.h"' line  */
/* xmodules.h, and then edit "xmyclass.h" following the directions below. */
/* REMEMBER TO DELETE ALL THE EXAMPLE CODE FROM YOUR COPY OF THIS FILE!   */
/**************************************************************************/

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLINIT
/* code to be executed on startup  */
#endif


#ifdef MODULE_XLDMEM_H_GLOBALS
/* New macros to appear in xldmem.h. */
/* New extern declarations to appear in xldmem.h. */
/**********************************************************/
/* In this section, you should declare all your primitive */
/* functions -- those which will be visible to the xlisp  */
/* programmer. Examples:                                  */
/**********************************************************/
/* xnet primitives */
extern LVAL xlnet_connect();
extern LVAL xlnet_close();
extern LVAL xlnet_set_socket();
extern LVAL xlnet_set_timeout();
extern LVAL xlnet_set_delimiters(); 
extern LVAL xlnet_eval();
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
/**********************************************************/
/* In this section, you specify the native xlisp name of  */
/* each of your primitive SUBR functions -- those which   */
/* want their arguments evaluated. (Most likely, all of   */
/* your primitives will be of this type.)		  */
/*							  */
/* Each line has two parts.				  */
/*							  */
/* The first part gives the xlisp name for your		  */
/* primitive.  Make it all upper case.  If your primitive */
/* is to be a message rather than a function, make this   */
/* this entry NULL.					  */
/*							  */
/* The second part is the name of your C function.	  */
/*							  */
/**********************************************************/
DEFINE_SUBR( "NET-CONNECT", xlnet_connect)
DEFINE_SUBR( "NET-CLOSE", xlnet_close )
DEFINE_SUBR( "NET-SET-SOCKET", xlnet_set_socket )
DEFINE_SUBR( "NET-SET-TIMEOUT", xlnet_set_timeout )
DEFINE_SUBR( "NET-SET-DELIMITERS", xlnet_set_delimiters )
DEFINE_SUBR( "NET-EVAL", xlnet_eval )
#endif


#ifdef MODULE_XLISP_H_PROVIDE
/* Define a macro indicating that your module is being     */
/* compiled into xlisp.  This will let future modules that */
/* depend on yours test for its presence (see next).  By   */
/* convention, such macros begin with "PROVIDE_":          */
#define PROVIDE_XNET
#endif





