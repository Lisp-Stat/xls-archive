#include	<sys/types.h>
#include	<sys/time.h>

main(argc, argv)
int	argc;
char	*argv[];
{
	long				atol(), sec;
	static struct timeval		timeout;
	if (argc != 2) exit(1);
	printf("argc %d\n", argc);
	sec = atol(argv[1]);
	printf("sec %l\n", sec);
	timeout.tv_sec = sec;
	printf("Set msec\n");
	timeout.tv_usec = 0;
	printf("Start select\n");
	if (select(0, (fd_set *) 0, (fd_set *) 0, (fd_set *) 0, &timeout)  < 0)
		exit(1);
        printf("Done\n");
	exit(0);
}