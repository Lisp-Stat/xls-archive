/******************************************************************/
/* sltcp.c */


#include "ctcp.h"
#include <stdio.h>

#define BUF_SIZ 4000

/* Main program that uses functions in ctcp.h to implement a client
   to access the server program sld */ 
main()
{
    char inbuf[ BUF_SIZ ];
    int s;
    int got_err;
    char *result;
    s = xtcp_Connect("localhost", 5200, &got_err, &result);
    if(s == XTCP_ERR_RETURN) {
	printf("Can't connect\n");
	exit(1);
	}
    printf("%s", result);
    for (;;) {
	printf("> ");
	fgets( inbuf, BUF_SIZ, stdin );
	xtcp_Eval_Str(s, &got_err, &result, inbuf );
	if (got_err) {
	  if (!strcmp(&result[got_err], "Server timeout") ||
              !strcmp(&result[got_err], "Connection not open"))  {
	    printf("%s\n", &result[got_err]);
	    exit(0);
	    }
   	  }
	printf("%s", result);
    }
    xtcp_Disconnect(s);
}

