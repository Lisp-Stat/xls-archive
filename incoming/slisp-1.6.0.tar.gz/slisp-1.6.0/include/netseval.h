/* netseval.h  */
/* Functions that allow slisp to be called as a server 
from external C routines. These are analogous to routines in seval.h that
allow slisp to be linked with the executable   */
/* Created jfb 9/28/94  */
#define SN_ERR_RETURN -1	
#define SN_DEFAULT_TIMEOUT 15
#define SN_DEFAULT_END 3
#define SN_DEFAULT_DATA 4

/* Only for network clients */
extern int sn_Connect();
extern void sn_Disconnect();
extern void sn_Set_Socket();
extern void sn_Set_Timeout();
extern void sn_Set_Delimiters();

/* Analogous to routines in seval.h */
extern void sn_Init();
extern void sn_Wrapup();
extern char *sn_Eval_Str();
extern int sn_Int();
extern float sn_Float();
extern char *sn_String();
extern int sn_Int_Eval_Str();
extern float sn_Float_Eval_Str();
extern char *sn_Str_Eval_Str();
extern void sn_Open_Transcript();
extern void sn_Close_Transcript();




