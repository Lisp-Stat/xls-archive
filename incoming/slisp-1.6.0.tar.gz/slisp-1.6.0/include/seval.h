/* seval.h  */
/* Functions that allow slisp to be called from external C routines. Slisp
routines are linked in with the executable. These are analogous to routines in
netseval.h that allow slisp to be called over the network */
/* Created jfb 11/13/93 */
/* Modifed: jfb 9/23/94 Changed slisp.h to seval.h  */

/* Analogous to routines in netseval.h  */ 
extern void sl_Init();
extern void sl_Wrapup();
extern char *sl_Eval_Str();
extern int sl_Int();
extern float sl_Float();
extern char *sl_String();
extern int sl_Int_Eval_Str();
extern float sl_Float_Eval_Str();
extern char *sl_Str_Eval_Str();
extern void sl_Open_Transcript();
extern void sl_Close_Transcript();


/* Debugging function, not used in general  */
extern void sl_Stack_Check();


