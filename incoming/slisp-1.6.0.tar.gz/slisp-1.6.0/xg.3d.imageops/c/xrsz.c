/* TO DO:  Convert to iterating through all arrays instead of */
/* just looking for some, and to handle both byte and float   */
/* instead of just byte. */

/* {{{ xrsz.c -- Image-zoom (magnify/minify) transforms.	     CrT*/

/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92May26
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 95Dec11 jsp: Added xrsF* support float as well as byte arrays.	*/
/* 94Jun15 jsp: Allow out-of-range src/dst coordinates.			*/
/* 93May31 jsp: xrsz29_Maybe_Resize_FilterRows malloc bugs fixed.	*/
/* 92Jun01 jsp: Operational.						*/
/* 92May26 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

#include "../../xg.3d/c/csry.h"

/* Haeberli & Heckbert stuff: */
#define IMPULSE		1
#define BOX		2
#define TRIANGLE	3
#define QUADRATIC	4
#define MITCHELL	5
static int   filtershape = TRIANGLE;
static float blurfactor = 1.0;

extern LVAL k_xsrcloc;

/* }}} */
/* {{{ --- statics ---							*/

static void xrsz30_filterZoom(
    unsigned char*,int,int,int,int,int,
    unsigned char*,int,int,int,int,int,
    int
);

/* }}} */
/* {{{ --- Public fns ---						*/

/* }}} */
/* {{{ xrsz08_Resize_Image_Msg -- Copy image while resizing.		*/

/* {{{ xrsz06_Trim_Selected_Areas					*/


/* {{{ xrsz04_Detop_Area -- Shave top 'ratio'th off this dimension.	*/

int xrsz04_Detop_Area(
    float ratio,
    int*d_min,
    int*d_max
) {
    *d_max = *d_max - (int)(ratio * (float)(*d_max-*d_min));
    return *d_max != *d_min;
}

/* }}} */
/* {{{ xrsz05_Debot_Area -- Shave bott0m 'ratio'th off this dimension.	*/

int xrsz05_Debot_Area(
    float ratio,
    int*d_min,
    int*d_max
) {
    *d_min += (int)( ratio * (float)(*d_max - *d_min)  );
    return *d_max != *d_min;
}

/* }}} */

int xrsz06_Trim_Selected_Areas(
    LVAL lv_src, int*x_src_min, int*y_src_min, int*x_src_siz, int*y_src_siz,
    LVAL lv_dst, int*x_dst_min, int*y_dst_min, int*x_dst_siz, int*y_dst_siz
) {
    int x_src_max = *x_src_min + *x_src_siz;
    int y_src_max = *y_src_min + *y_src_siz;
    int x_dst_max = *x_dst_min + *x_dst_siz;
    int y_dst_max = *y_dst_min + *y_dst_siz;

    int                             x_src_lim,  y_src_lim;
    int                             x_dst_lim,  y_dst_lim;
    xrsz07_Get_X_And_Y_Dimensions( &x_src_lim, &y_src_lim, lv_src );
    xrsz07_Get_X_And_Y_Dimensions( &x_dst_lim, &y_dst_lim, lv_dst );
    if (*x_src_siz < 1
    ||  *y_src_siz < 1
    ){
	xlerror("Bad :IMAGE-RESIZE area",lv_src);
    }
    if (*x_dst_siz < 1
    ||  *y_dst_siz < 1
    ){
	xlerror("Bad :IMAGE-RESIZE area",lv_dst);
    }

    /**************************************************/
    /* It turns out to be more convenient to the lisp */
    /* programmer to correctly handle src/dst areas   */
    /* which are partly or wholly outside the image,  */
    /* rather than flagging them as errors and making */
    /* the lisp programmer special-case them.         */
    /*                                                */
    /* We define "correctly handle" to mean ignoring  */
    /* any part of the operation which corresponds to */
    /* unavailable source or destination pixels, but  */
    /* correctly copying the rest:                    */
    /**************************************************/

    /* If part of the src/dst area   */
    /* is outside the src/dst image, */
    /* trim both areas to fix this:  */
    if (*x_src_min < 0) {
	float ratio = -*x_src_min / (float)(x_src_max - *x_src_min);
	if (!xrsz05_Debot_Area( ratio, x_src_min, &x_src_max )) return 0;
	if (!xrsz05_Debot_Area( ratio, x_dst_min, &x_dst_max )) return 0;
    }
    if (*x_dst_min < 0) {
	float ratio = -*x_dst_min / (float)(x_dst_max - *x_dst_min);
	if (!xrsz05_Debot_Area( ratio, x_src_min, &x_src_max )) return 0;
	if (!xrsz05_Debot_Area( ratio, x_dst_min, &x_dst_max )) return 0;
    }

    if (*y_src_min < 0) {
	float ratio = -*y_src_min / (float)(y_src_max - *y_src_min);
	if (!xrsz05_Debot_Area( ratio, y_src_min, &y_src_max )) return 0;
	if (!xrsz05_Debot_Area( ratio, y_dst_min, &y_dst_max )) return 0;
    }
    if (*y_dst_min < 0) {
	float ratio = -*y_dst_min / (float)(y_dst_max - *y_dst_min);
	if (!xrsz05_Debot_Area( ratio, y_src_min, &y_src_max )) return 0;
	if (!xrsz05_Debot_Area( ratio, y_dst_min, &y_dst_max )) return 0;
    }

    if (x_src_max >= x_src_lim) {
	float ratio = (x_src_max-x_src_lim) / (float)(x_src_max - *x_src_min);
	if (!xrsz04_Detop_Area( ratio, x_src_min, &x_src_max )) return 0;
	if (!xrsz04_Detop_Area( ratio, x_dst_min, &x_dst_max )) return 0;
    }
    if (x_dst_max >= x_dst_lim) {
	float ratio = (x_dst_max-x_dst_lim) / (float)(x_dst_max - *x_dst_min);
	if (!xrsz04_Detop_Area( ratio, x_src_min, &x_src_max )) return 0;
	if (!xrsz04_Detop_Area( ratio, x_dst_min, &x_dst_max )) return 0;
    }

    if (y_src_max >= y_src_lim) {
	float ratio = (y_src_max-y_src_lim) / (float)(y_src_max - *y_src_min);
	if (!xrsz04_Detop_Area( ratio, y_src_min, &y_src_max )) return 0;
	if (!xrsz04_Detop_Area( ratio, y_dst_min, &y_dst_max )) return 0;
    }
    if (y_dst_max >= y_dst_lim) {
	float ratio = (y_dst_max-y_dst_lim) / (float)(y_dst_max - *y_dst_min);
	if (!xrsz04_Detop_Area( ratio, y_src_min, &y_src_max )) return 0;
	if (!xrsz04_Detop_Area( ratio, y_dst_min, &y_dst_max )) return 0;
    }

    /* Return FALSE if src or dst area is wholly out of bounds: */
    if (*x_src_min >= x_src_lim
    ||  *y_src_min >= y_src_lim
    ||  *x_dst_min >= x_dst_lim
    ||  *y_dst_min >= y_dst_lim
    ||   x_src_max <= 0
    ||   y_src_max <= 0
    ||   x_dst_max <= 0
    ||   y_dst_max <= 0
    ){
        return FALSE;
    }

    *x_src_siz = x_src_max - *x_src_min;
    *y_src_siz = y_src_max - *y_src_min;

    *x_dst_siz = x_dst_max - *x_dst_min;
    *y_dst_siz = y_dst_max - *y_dst_min;

    /* Sanity check: */
    if (*x_src_min < 0   ||   *x_src_min + *x_src_siz > x_src_lim
    ||  *y_src_min < 0   ||   *y_src_min + *y_src_siz > y_src_lim
    ||  *x_dst_min < 0   ||   *x_dst_min + *x_dst_siz > x_dst_lim
    ||  *y_dst_min < 0   ||   *y_dst_min + *y_dst_siz > y_dst_lim
    ){
	fprintf(stderr,"xrsz06_Trim_Selected_Areas: internal err\n");
	abort();
    }

    return TRUE;
}

/* }}} */
/* {{{ xrsz07_Get_X_And_Y_Dimensions					*/

xrsz07_Get_X_And_Y_Dimensions( px, py, lv )
int                           *px,*py;
LVAL                                   lv;
{   csry_rec* h = (csry_rec*) gobjimmbase( lv );
    if (h->rank != 2)  xlerror("Image array not 2-D!",lv);
    *py = h->dim[0];
    *px = h->dim[1];
}

/* }}} */

LVAL xrsz08_Resize_Image_Msg() {
    extern LVAL xf8v04_Get_A_XF8V();
    extern LVAL k_from;
    extern LVAL k_blurfactor;
    extern LVAL k_filtershape;
    extern LVAL k_impulse;
    extern LVAL k_triangle;
    extern LVAL k_box;
    extern LVAL k_quadratic;
    extern LVAL k_mitchell;
    extern LVAL lv_xsrcloc;
    extern LVAL k_ysrcloc;
    extern LVAL k_xsrcsiz;
    extern LVAL k_ysrcsiz;
    extern LVAL k_xdstloc;
    extern LVAL k_ydstloc;
    extern LVAL k_xdstsiz;
    extern LVAL k_ydstsiz;

    LVAL lv_dst = NIL;	/* CLASS-UNIT-FLOAT array to copy from. */
    LVAL lv_src = NIL;  /* CLASS-UNIT-FLOAT array to copy into. */

    int  x_src_max;	/* Actual x-size of lv_src.		*/
    int  x_src_loc=0;	/* Src rectangle lower-left corner.	*/
    int  y_src_loc=0;	/* Src rectangle lower-left corner.	*/
    int  x_src_siz;	/* Src rectangle size in pixels.	*/
    int  y_src_siz;	/* Src rectangle size in pixels.	*/

    int  x_dst_max;	/* Actual x-size of lv_dst.		*/
    int  x_dst_loc=0;	/* Dst rectangle lower-left corner.	*/
    int  y_dst_loc=0;	/* Dst rectangle lower-left corner.	*/
    int  x_dst_siz;	/* Src rectangle size in pixels.	*/
    int  y_dst_siz;	/* Src rectangle size in pixels.	*/

    unsigned char* src_pxl;	/* Actual src pixel buffer.	*/
    unsigned char* dst_pxl;	/* Actual dst pixel buffer.	*/

    /* Read our arguments: */

    lv_dst = xf8v04_Get_A_XF8V();
    xrsz07_Get_X_And_Y_Dimensions( &x_dst_siz, &y_dst_siz, lv_dst );
    x_dst_max = x_dst_siz;

    lv_src = xf8v04_Get_A_XF8V();
    xrsz07_Get_X_And_Y_Dimensions( &x_src_siz, &y_src_siz, lv_src );
    x_src_max = x_src_siz;
    

    /* Scan optional parameters: */
    while (moreargs()) {

	LVAL key = xlgasymbol();

	if        (key == k_xsrcloc) {

	    x_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcloc) {

	    y_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xsrcsiz) {

	    x_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcsiz) {

	    y_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstloc) {

	    x_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstloc) {

	    y_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstsiz) {

	    x_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstsiz) {

	    y_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_filtershape) {

	    LVAL shape = xlgasymbol();
	    if        (shape == k_impulse  )   filtershape = IMPULSE  ;
	    else if   (shape == k_box      )   filtershape = BOX      ;
	    else if   (shape == k_triangle )   filtershape = TRIANGLE ;
	    else if   (shape == k_quadratic)   filtershape = QUADRATIC;
	    else if   (shape == k_mitchell )   filtershape = MITCHELL ;
	    else      xlerror("Unknown :FILTER-SHAPE",shape);

	} else if (key == k_blurfactor) {

	    blurfactor =  xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (blurfactor == 0.0)   xlfail("Zero :BLUR-FACTOR");

	} else {

	    xlerror("Bad :RESIZE-IMAGE keyword",key);
    }	}

    if (lv_src == lv_dst)  xlerror(":IMAGE-RESIZE from array to self!",lv_dst);
    if (!xrsz06_Trim_Selected_Areas(
            lv_src, &x_src_loc, &y_src_loc, &x_src_siz, &y_src_siz,
            lv_dst, &x_dst_loc, &y_dst_loc, &x_dst_siz, &y_dst_siz
    )) {
	return NIL;
    }

    src_pxl = (unsigned char*) (csry_base( lv_src ));
    dst_pxl = (unsigned char*) (csry_base( lv_dst ));

    if (filtershape == IMPULSE) {

	xrsz20_impulseZoom(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
	    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
	);

    } else {

	xrsz30_filterZoom(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
	    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz,
	    /*clamp:*/ filtershape == MITCHELL
	);
    }

    return NIL;
}

/* }}} */
/* {{{ xrsz95_Resize_Relation_Msg -- Copy image planes while resizing.	*/

/****************************************************************/
/* This function differs from xrsz08_Resize_Image_Msg() only	*/
/* in that the arguments expected are graphic relations		*/
/* containing :pixel-reg :pixel-green :pixel-blue arrays,	*/
/* rather than just arrays.					*/
/****************************************************************/

xrsz94_Resize_Relation_Msg_A(
  lv_dst, lv_src,
  x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
  x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
  filtershape
)
LVAL  lv_src, lv_dst;
int   x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz;
int   x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz;
int   filtershape;
{
    unsigned char* src_pxl;
    unsigned char* dst_pxl;

    if (!lv_dst)   return;

    if (!xrsz06_Trim_Selected_Areas(
            lv_src, &x_src_loc, &y_src_loc, &x_src_siz, &y_src_siz,
            lv_dst, &x_dst_loc, &y_dst_loc, &x_dst_siz, &y_dst_siz
    )) {
	return;
    }

    src_pxl = (unsigned char*) (csry_base( lv_src ));
    dst_pxl = (unsigned char*) (csry_base( lv_dst ));

    if (filtershape == IMPULSE) {

	xrsz20_impulseZoom(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
	    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
	);

    } else {

	xrsz30_filterZoom(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
	    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz,
	    /*clamp:*/ filtershape == MITCHELL
	);
    }
}

LVAL xrsz95_Resize_Relation_Msg() {
    extern LVAL xgrl01_Get_A_XGRL();
    extern LVAL k_from;
    extern LVAL k_blurfactor;
    extern LVAL k_filtershape;
    extern LVAL k_impulse;
    extern LVAL k_triangle;
    extern LVAL k_box;
    extern LVAL k_quadratic;
    extern LVAL k_mitchell;
    extern LVAL lv_xsrcloc;
    extern LVAL k_ysrcloc;
    extern LVAL k_xsrcsiz;
    extern LVAL k_ysrcsiz;
    extern LVAL k_xdstloc;
    extern LVAL k_ydstloc;
    extern LVAL k_xdstsiz;
    extern LVAL k_ydstsiz;

    LVAL lv_dst = NIL;
    LVAL lv_src = NIL;
    int  x_src_max;
    int  x_src_loc=0, y_src_loc=0;
    int  x_src_siz  , y_src_siz  ;
    int  x_dst_max;
    int  x_dst_loc=0, y_dst_loc=0;
    int  x_dst_siz  , y_dst_siz  ;

    /* Read our arguments: */

    lv_dst = xgrl01_Get_A_XGRL();
    xrsz07_Get_X_And_Y_Dimensions( &x_dst_siz, &y_dst_siz, lv_dst );
    x_dst_max = x_dst_siz;

    lv_src = xgrl01_Get_A_XGRL();
    xrsz07_Get_X_And_Y_Dimensions( &x_src_siz, &y_src_siz, lv_src );
    x_src_max = x_src_siz;
    

    /* Scan optional parameters: */
    while (moreargs()) {

	LVAL key = xlgasymbol();

	if        (key == k_xsrcloc) {

	    x_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcloc) {

	    y_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xsrcsiz) {

	    x_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcsiz) {

	    y_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstloc) {

	    x_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstloc) {

	    y_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstsiz) {

	    x_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstsiz) {

	    y_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_filtershape) {

	    LVAL shape = xlgasymbol();
	    if        (shape == k_impulse  )   filtershape = IMPULSE  ;
	    else if   (shape == k_box      )   filtershape = BOX      ;
	    else if   (shape == k_triangle )   filtershape = TRIANGLE ;
	    else if   (shape == k_quadratic)   filtershape = QUADRATIC;
	    else if   (shape == k_mitchell )   filtershape = MITCHELL ;
	    else      xlerror("Unknown :FILTER-SHAPE",shape);

	} else if (key == k_blurfactor) {

	    blurfactor =  xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (blurfactor == 0.0)   xlfail("Zero :BLUR-FACTOR");

	} else {

	    xlerror("Bad :RESIZE-IMAGE keyword",key);
    }	}

    if (lv_src == lv_dst)   xlerror(":IMAGE-RESIZE from relation to self!",lv_dst);

    /* Fetch image-plane arrays out of graphic relations: */
    {   LVAL lv_src_red, lv_src_green, lv_src_blue;
	LVAL lv_dst_red, lv_dst_green, lv_dst_blue;

	int  src_planes = xthl3a_GetPixelRedGreenBlueIfPresent(
	    &lv_src_red,&lv_src_green,&lv_src_blue, lv_src
	);
	int  dst_planes = xthl3a_GetPixelRedGreenBlueIfPresent(
	    &lv_dst_red,&lv_dst_green,&lv_dst_blue, lv_dst
	);

	if (!src_planes || !dst_planes)   return NIL;

	/* For each output plane, assign an input plane to read from: */
	if (lv_dst_red   && !lv_src_red  ) {
	    lv_src_red   = lv_src_green ? lv_src_green : lv_src_blue ;
	}
	if (lv_dst_green && !lv_src_green) {
	    lv_src_green = lv_src_red   ? lv_src_red   : lv_src_blue ;
	}
	if (lv_dst_blue  && !lv_src_blue ) {
	    lv_src_blue  = lv_src_red   ? lv_src_red   : lv_src_green;
	}

	/* Fill each output plane present: */
	xrsz94_Resize_Relation_Msg_A(
	    lv_dst_red  , lv_src_red  ,
	    x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
	    x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
	    filtershape
        );
	xrsz94_Resize_Relation_Msg_A(
	    lv_dst_green, lv_src_green,
	    x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
	    x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
	    filtershape
        );
	xrsz94_Resize_Relation_Msg_A(
	    lv_dst_blue , lv_src_blue ,
	    x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
	    x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
	    filtershape
        );
    }

    return NIL;
}

/* }}} */

/* {{{ --- Comments on SGI code and copyright ---			*/

/************************************************************************/
/*                              comments                                */
/*                                                                      */
/*  Following code adapted from SGI's 'izoom.c' filter.  It carried no  */
/*  copyright, but most SGI 4Dgifts stuff carries a simple              */
/*  "don't sue us!" copyright.                                          */
/*                                                                      */
/*  Original code was a small program designed to process one image     */
/*  and exit, hence malloced randomly right and left.  This version     */
/*  is intended to be called repeatedly from an interactive program,    */
/*  hence it allocates buffers when first called, expands them as       */
/*  needed, and never contracts or frees the buffers (to minimize       */
/*  fragmentation and wasted cycles).                                   */
/*                                                                      */
/*  izoom-                                                              */
/*          Magnify or minify a picture with or without filtering.  The */
/*  filtered method is one pass, uses 2-d convolution, and is optimized */
/*  by integer arithmetic and precomputation of filter coeffs.          */
/*									*/
/*                  Paul Haeberli and Paul Heckbert - 1988		*/
/*                                                                      */
/************************************************************************/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <malloc.h>

#define EPSILON		0.0001

/* This file is designed to operate on 8-bit pixel values */
/* using 16-bit shorts to accumulate values, interpreted  */
/* as containing 12-bit fixpoint numbers:                 */
#define SHIFT 12
#define ONE (1<<SHIFT)

float xrsz36_filterRadius();
float xrsz38_filterIntegrate();
float xrsz50_mitchell();


/* impulse zoom implementation follows */

#define GRID_TO_FLOAT(pos,n)	(((pos)+0.5)/(n))
#define FLOAT_TO_GRID(pos,n)	((pos)*(n))

/* For a 3x3 convolution (typical), 'n' */
/* will be 3 and 'weight' will point to */
/* three precomputed weights.		*/
typedef struct FILTER {
    int    physical_len;	/* # Physical entries in 'weight'.	*/
    int    n	       ;	/* # useful   entries in 'weight'.	*/
    int    total_weight;	/* Sum of first 'n' 'weight' entries.	*/

    short* dat         ;
    short* weight      ;
} FILTER;

typedef struct FLOAT_FILTER {
    int    physical_len;	/* # Physical entries in 'weight'.	*/
    int    n	       ;	/* # useful   entries in 'weight'.	*/
    float  total_weight;	/* Sum of first 'n' 'weight' entries.	*/

    float* dat         ;
    float* weight      ;
} FLOAT_FILTER;

/* }}} */

/*     --- SGI fns ---							*/
/* {{{ --- statics ---							*/

static void xrsz13_size_buf(void*,int*,int,int );
static void xrsz14_Maybe_Re_Alloc_Weight_Vector( FILTER* );
static void xrsz34_makeFilter(FILTER**,int*,short*,int,int,int*);
static void xrsF34_makeFilter(FLOAT_FILTER**,int*,float*,int,int,int*);

/* }}} */

/* {{{ xrsz11_get_row	Read row from array into buffer.		*/

xrsz11_get_row( buf, ary, x_max, x_loc, x_siz, y_loc, y )
short*          buf;
unsigned char*       ary;
int                       x_max, x_loc, x_siz, y_loc, y;
{
    register         short* dst = buf;
    register unsigned char* src = ary + (y_loc+y)*x_max + x_loc;
    register                i   = x_siz;
    while (i --> 0) {
	if (i >= 7) {
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    i -= 7;
	} else {
	    *dst++ = *src++;
	}
    }
}

/* }}} */
/* {{{ xrsF11_get_row	Read row from array into buffer.		*/

xrsF11_get_row( buf, ary, x_max, x_loc, x_siz, y_loc, y )
float*          buf;
float*               ary;
int                       x_max, x_loc, x_siz, y_loc, y;
{
    register float* dst = buf;
    register float* src = ary + (y_loc+y)*x_max + x_loc;
    register        i   = x_siz;
    while (i --> 0) {
	if (i >= 7) {
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    i -= 7;
	} else {
	    *dst++ = *src++;
	}
    }
}

/* }}} */
/* {{{ xrsz12_put_row	Write row from buffer into an array.		*/

xrsz12_put_row( ary, x_ary_max, x_loc, x_siz, y_loc, y, buf )
unsigned char*  ary;
int                  x_ary_max, x_loc, x_siz, y_loc, y;
short*                                                  buf;
{
    register         short* src = buf;
    register unsigned char* dst = ary + (y_loc+y)*x_ary_max + x_loc;
    register                i   = x_siz;
    while (i --> 0) {
	if (i >= 7) {
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    i -= 7;
	} else {
	    *dst++ = *src++;
	}
    }
}

/* }}} */
/* {{{ xrsF12_put_row	Write row from buffer into an array.		*/

xrsF12_put_row( ary, x_ary_max, x_loc, x_siz, y_loc, y, buf )
float*          ary;
int                  x_ary_max, x_loc, x_siz, y_loc, y;
float*                                                  buf;
{
    register float* src = buf;
    register float* dst = ary + (y_loc+y)*x_ary_max + x_loc;
    register        i   = x_siz;
    while (i --> 0) {
	if (i >= 7) {
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    i -= 7;
	} else {
	    *dst++ = *src++;
	}
    }
}

/* }}} */
/* {{{ xrsz13_size_buf	Make given buf large enough, if need be.	*/

static void
xrsz13_size_buf(
    void*   pb,
    int*    p_old_size,
    int     needed_size,
    int     el_size
) {
    short** pbufptr = (short**) pb;
    if (needed_size <= *p_old_size)   return;

    {   int bytes = needed_size * el_size;
        if (!*p_old_size)   *pbufptr = (short*)   malloc(           bytes );
        else                *pbufptr = (short*)  realloc( *pbufptr, bytes );
	if (!*pbufptr) {printf("xrsz13 out of ram!"); abort();}
    }
    *p_old_size = needed_size;
}

/* }}} */
/* {{{ xrsz14_Maybe_Re_Alloc_Weight_Vector for xrsz35_applyXFilter.	*/

static void
xrsz14_Maybe_Re_Alloc_Weight_Vector(
    FILTER *f
) {
    xrsz13_size_buf(&f->weight, &f->physical_len, f->n, sizeof(short));
}

/* }}} */
/* {{{ xrsF14_Maybe_Re_Alloc_Weight_Vector for xrsF35_applyXFilter.	*/

static void
xrsF14_Maybe_Re_Alloc_Weight_Vector(
    FLOAT_FILTER *f
) {
    xrsz13_size_buf(&f->weight, &f->physical_len, f->n, sizeof(float));
}

/* }}} */
/* {{{ xrsz20_impulseZoom	Scale image by (only) copying pixels.	*/

short*  xrsz14_srcbuf; int xrsz15_srcbuf_len = 0;
short*  xrsz16_dstbuf; int xrsz17_dstbuf_len = 0;
int     xrsz18_xltmap; int xrsz19_xltmap_len = 0;
short*  xrsz1a_tmpbuf; int xrsz1b_tmpbuf_len = 0;
xrsz20_impulseZoom(
    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
)
unsigned char* dst_pxl;
int          x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz;
unsigned char* src_pxl;
int          x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz;
{
    float       fy;
    int      y_dst;
    int      y_src;
    int last_y_src;

    /* Make our temporary buffers big enough to hold a row: */
    xrsz13_size_buf(&xrsz14_srcbuf,&xrsz15_srcbuf_len,x_src_siz,sizeof(short));
    xrsz13_size_buf(&xrsz16_dstbuf,&xrsz17_dstbuf_len,x_dst_siz,sizeof(short));
    xrsz13_size_buf(&xrsz18_xltmap,&xrsz19_xltmap_len,x_dst_siz,sizeof(int  ));

    /* Map output pixel xcoords to input pixel xcoords: */
    xrsz21_makexmap( xrsz18_xltmap, x_src_siz, x_dst_siz );

    /* Compute all output pixel rows: */
    last_y_src = -1;
    for (y_dst = 0;   y_dst < y_dst_siz;   ++y_dst) {

	/* Figure out which input pixel row to read from: */
	fy    = GRID_TO_FLOAT( y_dst, y_dst_siz );
	y_src = FLOAT_TO_GRID(    fy, y_src_siz );

	/* Fetch & scale that input pixel row unless same as last input row: */
	if (y_src != last_y_src) {
	    xrsz11_get_row(
		xrsz14_srcbuf, 
                src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src
	    );
	    if (x_src_siz != x_dst_siz) {
		xrsz22_xscalebuf(
		    xrsz16_dstbuf, x_dst_siz, xrsz18_xltmap, xrsz14_srcbuf
		);
	    }
	    last_y_src = y_src;
	}

	/* Write scaled input pixel row to output pixel array: */
	xrsz12_put_row(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
	    x_src_siz == x_dst_siz ? xrsz14_srcbuf : xrsz16_dstbuf
	);
    }
}

/* }}} */
/* {{{ xrsF20_impulseZoom	Scale image by (only) copying pixels.	*/

float*  xrsF14_srcbuf; int xrsF15_srcbuf_len = 0;
float*  xrsF16_dstbuf; int xrsF17_dstbuf_len = 0;
int     xrsF18_xltmap; int xrsF19_xltmap_len = 0;
float*  xrsF1a_tmpbuf; int xrsF1b_tmpbuf_len = 0;
xrsF20_impulseZoom(
    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
)
float*       dst_pxl;
int          x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz;
float*       src_pxl;
int          x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz;
{
    float       fy;
    int      y_dst;
    int      y_src;
    int last_y_src;

    /* Make our temporary buffers big enough to hold a row: */
    xrsz13_size_buf(&xrsF14_srcbuf,&xrsF15_srcbuf_len,x_src_siz,sizeof(float));
    xrsz13_size_buf(&xrsF16_dstbuf,&xrsF17_dstbuf_len,x_dst_siz,sizeof(float));
    xrsz13_size_buf(&xrsF18_xltmap,&xrsF19_xltmap_len,x_dst_siz,sizeof(int  ));

    /* Map output pixel xcoords to input pixel xcoords: */
    xrsz21_makexmap( xrsF18_xltmap, x_src_siz, x_dst_siz );

    /* Compute all output pixel rows: */
    last_y_src = -1;
    for (y_dst = 0;   y_dst < y_dst_siz;   ++y_dst) {

	/* Figure out which input pixel row to read from: */
	fy    = GRID_TO_FLOAT( y_dst, y_dst_siz );
	y_src = FLOAT_TO_GRID(    fy, y_src_siz );

	/* Fetch & scale that input pixel row unless same as last input row: */
	if (y_src != last_y_src) {
	    xrsF11_get_row(
		xrsF14_srcbuf, 
                src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src
	    );
	    if (x_src_siz != x_dst_siz) {
		xrsF22_xscalebuf(
		    xrsF16_dstbuf, x_dst_siz, xrsF18_xltmap, xrsF14_srcbuf
		);
	    }
	    last_y_src = y_src;
	}

	/* Write scaled input pixel row to output pixel array: */
	xrsF12_put_row(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
	    x_src_siz == x_dst_siz ? xrsF14_srcbuf : xrsF16_dstbuf
	);
    }
}

/* }}} */
/* {{{ xrsz21_makexmap	Make map from output cols to input, for IMPULSE.*/

xrsz21_makexmap( xltmap, x_src_siz, x_dst_siz)
int              xltmap[];
int                      x_src_siz, x_dst_siz;
{   int x, ax;
    float fx;

    for(x = 0;   x < x_dst_siz;   x++) {
       fx = GRID_TO_FLOAT( x,x_dst_siz);
       ax = FLOAT_TO_GRID(fx,x_src_siz);
       xltmap[x] = ax;
    }
}

/* }}} */
/* {{{ xrsz22_mscalebuf	Do IMPULSE remapping on a row.			*/

xrsz22_xscalebuf( dstbuf, x_dst_siz, xltmap, srcbuf )
register short   *dstbuf;
register                  x_dst_siz;
register int                         xltmap[];
register short   			    *srcbuf;
{
    register i;
    for (i = 0;   i < x_dst_siz;   ) {
	if (x_dst_siz-i >= 8) {
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	} else {
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	}
    }
}
xrsF22_xscalebuf( dstbuf, x_dst_siz, xltmap, srcbuf )
register float   *dstbuf;
register                  x_dst_siz;
register int                         xltmap[];
register float   			    *srcbuf;
{
    register i;
    for (i = 0;   i < x_dst_siz;   ) {
	if (x_dst_siz-i >= 8) {
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	} else {
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	}
    }
}

/* filtered zoom implementation follows */


/* While running, xFilter points to a vector */
/* of xFilter_len FILTER instances, one for  */
/* each column in the destination rectangle. */
/*                                           */
/* Similarly, yFilter points to a vector     */
/* of yFilter_len FILTER instances, one for  */
/* each row    in the destination rectangle. */
FILTER       *xrsz3a_xFilter;    int xrsz3b_xFilter_len = 0;
FILTER       *xrsz3c_yFilter;    int xrsz3d_yFilter_len = 0;

FLOAT_FILTER *xrsF3a_xFilter;    int xrsF3b_xFilter_len = 0;
FLOAT_FILTER *xrsF3c_yFilter;    int xrsF3d_yFilter_len = 0;

/* filterRows is a 2-D array of input lines which we've  */
/* already transformed.  Since each output line requires */
/* several input lines, this cache speeds things up...   */
short **xrsz3e_filterRows; int xrsz3f_rows        = 0;
			   int xrsz3g_cols        = 0;

float **xrsF3e_filterRows; int xrsF3f_rows        = 0;
			   int xrsF3g_cols        = 0;


int   *xrsz3h_accumulateRow; int xrsz3i_accumulateRow_len = 0;
float *xrsF3h_accumulateRow; int xrsF3i_accumulateRow_len = 0;

/* }}} */
/* {{{ xrsz28_Zero_Integer_Buffer					*/

xrsz28_Zero_Integer_Buffer( buf, len )
register int               *buf, len;
{
    /* Original code used bzero, but that tends to be a */
    /* portability problem, and this isn't that time-   */
    /* critical, to my taste ... -- CrT                 */
    while (len --> 0) {
	if (len >= 7) {
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    len -= 7;
	} else {
	    *buf++ = 0;
    }	}
}

/* }}} */
/* {{{ xrsF28_Zero_Float_Buffer					*/

xrsF28_Zero_Float_Buffer( buf,     len )
register float           *buf; int len;
{
    while (len --> 0) {
	if (len >= 7) {
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    len -= 7;
	} else {
	    *buf++ = (float) 0.0;
    }	}
}

/* }}} */
/* {{{ xrsz29_Maybe_Resize_FilterRows					*/

xrsz29_Maybe_Resize_FilterRows( needed_rows, needed_cols )
int                             needed_rows, needed_cols;
{   int i;
    if (!xrsz3f_rows) {
	xrsz3e_filterRows = (short**) malloc( needed_rows * sizeof(short *));
	if (!xrsz3e_filterRows) {printf("xrsz29/a out of ram!"); abort();}
	for (i = 0;   i < needed_rows;   i++) {
	    xrsz3e_filterRows[i] = (short*) malloc( needed_cols * sizeof(short  ));
	    if (!xrsz3e_filterRows[i]) {printf("xrsz29/b out of ram!"); abort();}
	}
	xrsz3f_rows = needed_rows;
        xrsz3g_cols = needed_cols;
    } else {
	if (xrsz3f_rows < needed_rows) {
	    xrsz3e_filterRows = (short**) realloc(
		xrsz3e_filterRows,
		needed_rows * sizeof(short *)
	    );
	    if (!xrsz3e_filterRows) {printf("xrsz29/c out of ram!"); abort();}
	    for (i = xrsz3f_rows;   i < needed_rows;   i++) {
		xrsz3e_filterRows[i] = (short*) malloc(
		    xrsz3g_cols * sizeof(short)
		);
	        if (!xrsz3e_filterRows[i]) {printf("xrsz29/ out of ram!"); abort();}
	    }
	    xrsz3f_rows = needed_rows;
	}
	if (xrsz3g_cols < needed_cols) {
	    for (i = 0;   i < xrsz3f_rows;   i++) {
		xrsz3e_filterRows[i] = (short*) realloc(
		    xrsz3e_filterRows[i],
		    needed_cols * sizeof(short)
		);
		if (!xrsz3e_filterRows[i]) {printf("xrsz29/ out of ram!"); abort();}
	    }
	}
        xrsz3g_cols = needed_cols;
    }
}

/* }}} */
/* {{{ xrsF29_Maybe_Resize_FilterRows					*/

xrsF29_Maybe_Resize_FilterRows( needed_rows, needed_cols )
int                             needed_rows, needed_cols;
{   int i;
    if (!xrsF3f_rows) {
	xrsF3e_filterRows = (float**) malloc( needed_rows * sizeof(float *));
	if (!xrsF3e_filterRows) {printf("xrsF29/a out of ram!"); abort();}
	for (i = 0;   i < needed_rows;   i++) {
	    xrsF3e_filterRows[i] = (float*) malloc( needed_cols*sizeof(float));
	    if (!xrsF3e_filterRows[i]){printf("xrsF29/b out of ram!");abort();}
	}
	xrsF3f_rows = needed_rows;
        xrsF3g_cols = needed_cols;
    } else {
	if (xrsF3f_rows < needed_rows) {
	    xrsF3e_filterRows = (float**) realloc(
		xrsF3e_filterRows,
		needed_rows * sizeof(float *)
	    );
	    if (!xrsF3e_filterRows){printf("xrsF29/c out of ram!"); abort();}
	    for (i = xrsF3f_rows;   i < needed_rows;   i++) {
		xrsF3e_filterRows[i] = (float*) malloc(
		    xrsF3g_cols * sizeof(float)
		);
	        if(!xrsF3e_filterRows[i]){printf("xrsF29/no ram!");abort();}
	    }
	    xrsF3f_rows = needed_rows;
	}
	if (xrsF3g_cols < needed_cols) {
	    for (i = 0;   i < xrsF3f_rows;   i++) {
		xrsF3e_filterRows[i] = (float*) realloc(
		    xrsF3e_filterRows[i],
		    needed_cols * sizeof(float)
		);
		if (!xrsF3e_filterRows[i]) {printf("xrsz29/no ram!"); abort();}
	    }
	}
        xrsF3g_cols = needed_cols;
    }
}

/* }}} */
/* {{{ xrsz30_filterZoom Magnify/minify image by convolution.		*/

static void
xrsz30_filterZoom(
    unsigned char* dst_pxl,	/* Actual dst pixel buffer.	*/
    int          x_dst_max,	/* Actual x-size  of dst_pxl.	*/
    int          x_dst_loc,	/* Dst rect lower-left corner.	*/
    int          x_dst_siz,	/* Dst rect size  in pixels.	*/
    int          y_dst_loc,	/* Dst rect lower-left corner.	*/
    int          y_dst_siz,	/* Dst rect size  in pixels.	*/

    unsigned char* src_pxl,	/* Actual src pixel buffer.	*/
    int          x_src_max,	/* Actual x-size  of src_pxl.	*/
    int          x_src_loc,	/* Src rect lower-left corner.	*/
    int          x_src_siz,	/* Src rect size  in pixels.	*/
    int          y_src_loc,	/* Src rect lower-left corner.	*/
    int          y_src_siz,	/* Src rect size  in pixels.	*/

    int          clamp		/* TRUE iff filter yields vals	*/
) {				/* outside of input 0-255 range.*/
    FILTER *f;
    int x, y_dst, y_src;
    short *w;
    short **rptr;
    short *row;
    int nrows;
    int fy, n, total_weight;
    int i, min, max;
    float fmin, fmax;

    /* Make our temporary buffers big enough to hold a row: */
    xrsz13_size_buf(&xrsz14_srcbuf, &xrsz15_srcbuf_len, x_src_siz, sizeof(short));
    xrsz13_size_buf(&xrsz16_dstbuf, &xrsz17_dstbuf_len, x_dst_siz, sizeof(short));
    xrsz13_size_buf(&xrsz1a_tmpbuf, &xrsz1b_tmpbuf_len, x_dst_siz, sizeof(short));

    xrsz34_makeFilter(
	&xrsz3a_xFilter, &xrsz3b_xFilter_len,
        xrsz14_srcbuf, x_src_siz, x_dst_siz, &nrows
    );

    xrsz34_makeFilter(
	&xrsz3c_yFilter, &xrsz3d_yFilter_len,
	0,             y_src_siz, y_dst_siz, &nrows
    );

    xrsz29_Maybe_Resize_FilterRows(
	/* needed_rows: */ nrows,
	/* needed_cols: */ x_dst_siz
    );

    xrsz13_size_buf(
        &xrsz3h_accumulateRow,
	&xrsz3i_accumulateRow_len,
	x_dst_siz,
	sizeof( int )
    );

    y_src = 0;
    for (y_dst = 0;   y_dst < y_dst_siz;   ++y_dst) {

	f = xrsz3c_yFilter + y_dst;
	max = ((int)f->dat) / sizeof(short) + (f->n - 1);
	while (y_src <= max) {
	    xrsz11_get_row(
		xrsz14_srcbuf, 
                src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src++
	    );
	    row = xrsz3e_filterRows[0];
	    for (i = 0;   i < (nrows-1);   i++) {
		xrsz3e_filterRows[i] = xrsz3e_filterRows[i+1];
	    }
	    xrsz3e_filterRows[nrows-1] = row;
	    xrsz35_applyXFilter(
		xrsz3e_filterRows[nrows-1], xrsz3a_xFilter, x_dst_siz
	    );
	}

	if (f->n == 1) {
	    if (clamp) {
		xrsz31_clampRow(
		    xrsz3e_filterRows[nrows-1], xrsz1a_tmpbuf, x_dst_siz
		);
		xrsz12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xrsz1a_tmpbuf
		);
	    } else {
		xrsz12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xrsz3e_filterRows[nrows-1]
		);
	    }
	} else {
	    xrsz28_Zero_Integer_Buffer( xrsz3h_accumulateRow, x_dst_siz );
	    for (fy = 0;   fy < f->n;   fy++) {
		xrsz32_addRow(
		    xrsz3h_accumulateRow,
		    xrsz3e_filterRows[ fy + (nrows-1) - (f->n-1) ],
		    f->weight[fy],
		    x_dst_siz
		);
	    }
	    xrsz33_divRow(
		xrsz3h_accumulateRow,xrsz16_dstbuf,f->total_weight,x_dst_siz
	    );
	    if (clamp) {
		xrsz31_clampRow( xrsz16_dstbuf, xrsz1a_tmpbuf, x_dst_siz );
		xrsz12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xrsz1a_tmpbuf
		);
	    } else {
		xrsz12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xrsz16_dstbuf
   		);
    }   }   }
}

/* }}} */
/* {{{ xrsF30_filterZoom Magnify/minify image by convolution.		*/

static void
xrsF30_filterZoom(
    float*	 dst_pxl,	/* Actual dst pixel buffer.	*/
    int          x_dst_max,	/* Actual x-size  of dst_pxl.	*/
    int          x_dst_loc,	/* Dst rect lower-left corner.	*/
    int          x_dst_siz,	/* Dst rect size  in pixels.	*/
    int          y_dst_loc,	/* Dst rect lower-left corner.	*/
    int          y_dst_siz,	/* Dst rect size  in pixels.	*/

    float*	 src_pxl,	/* Actual src pixel buffer.	*/
    int          x_src_max,	/* Actual x-size  of src_pxl.	*/
    int          x_src_loc,	/* Src rect lower-left corner.	*/
    int          x_src_siz,	/* Src rect size  in pixels.	*/
    int          y_src_loc,	/* Src rect lower-left corner.	*/
    int          y_src_siz,	/* Src rect size  in pixels.	*/

    int          clamp		/* TRUE iff filter yields vals	*/
) {				/* outside of input 0-255 range.*/
    FLOAT_FILTER *f;
    int x, y_dst, y_src;
    float *w;
    float **rptr;
    float *row;
    int nrows;
    int fy, n;
    float total_weight;
    int i, min, max;
    float fmin, fmax;

    /* Make our temporary buffers big enough to hold a row: */
    xrsz13_size_buf(&xrsF14_srcbuf,&xrsF15_srcbuf_len,x_src_siz,sizeof(float));
    xrsz13_size_buf(&xrsF16_dstbuf,&xrsF17_dstbuf_len,x_dst_siz,sizeof(float));
    xrsz13_size_buf(&xrsF1a_tmpbuf,&xrsF1b_tmpbuf_len,x_dst_siz,sizeof(float));

    xrsF34_makeFilter(
	&xrsF3a_xFilter, &xrsF3b_xFilter_len,
        xrsF14_srcbuf, x_src_siz, x_dst_siz, &nrows
    );

    xrsF34_makeFilter(
	&xrsF3c_yFilter, &xrsF3d_yFilter_len,
	0,             y_src_siz, y_dst_siz, &nrows
    );

    xrsF29_Maybe_Resize_FilterRows(
	/* needed_rows: */ nrows,
	/* needed_cols: */ x_dst_siz
    );

    xrsz13_size_buf(
        &xrsF3h_accumulateRow,
	&xrsF3i_accumulateRow_len,
	x_dst_siz,
	sizeof( float )
    );

    y_src = 0;
    for (y_dst = 0;   y_dst < y_dst_siz;   ++y_dst) {

	f = xrsF3c_yFilter + y_dst;
	max = ((int)f->dat) / sizeof(float) + (f->n - 1);
	while (y_src <= max) {
	    xrsF11_get_row(
		xrsF14_srcbuf, 
                src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src++
	    );
	    row = xrsF3e_filterRows[0];
	    for (i = 0;   i < (nrows-1);   i++) {
		xrsF3e_filterRows[i] = xrsF3e_filterRows[i+1];
	    }
	    xrsF3e_filterRows[nrows-1] = row;
	    xrsF35_applyXFilter(
		xrsF3e_filterRows[nrows-1], xrsF3a_xFilter, x_dst_siz
	    );
	}

	if (f->n == 1) {
            #ifdef UNWORKABLE
	    /* This is unworkable because while our image */
	    /* pixels are nicely normalized to a 0-255    */
	    /* range and we can clamp anything outside    */
	    /* that range, our float RSA coord data which */
	    /* we're isn't scaled to a fixed 0-1 range.   */
	    if (clamp) {
		xrsF31_clampRow(
		    xrsF3e_filterRows[nrows-1], xrsF1a_tmpbuf, x_dst_siz
		);
		xrsF12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xrsF1a_tmpbuf
		);
	    } else {
            #endif
		xrsF12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xrsF3e_filterRows[nrows-1]
		);
            #ifdef UNWORKABLE
	    }
            #endif
	} else {
	    xrsF28_Zero_Float_Buffer( xrsF3h_accumulateRow, x_dst_siz );
	    for (fy = 0;   fy < f->n;   fy++) {
		xrsz32_addRow(
		    xrsF3h_accumulateRow,
		    xrsF3e_filterRows[ fy + (nrows-1) - (f->n-1) ],
		    f->weight[fy],
		    x_dst_siz
		);
	    }
	    xrsF33_divRow(
		xrsF3h_accumulateRow,xrsF16_dstbuf,f->total_weight,x_dst_siz
	    );
            #ifdef UNWORKABLE
	    /* This is unworkable because while our image */
	    /* pixels are nicely normalized to a 0-255    */
	    /* range and we can clamp anything outside    */
	    /* that range, our float RSA coord data which */
	    /* we're isn't scaled to a fixed 0-1 range.   */
	    if (clamp) {
		xrsF31_clampRow( xrsF16_dstbuf, xrsF1a_tmpbuf, x_dst_siz );
		xrsF12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xrsF1a_tmpbuf
		);
	    } else {
            #endif
		xrsF12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xrsF16_dstbuf
   		);
            #ifdef UNWORKABLE
            }
            #endif
        }
    }
}

/* }}} */
/* {{{ xrsz31_clampRow	Clamp a rowbuffer to [0,255].			*/

xrsz31_clampRow( iptr, optr, n)
short           *iptr,*optr;
int                          n;
{   while (n --> 0) {
	short val = *iptr++;
	if      (val <   0)   *optr++ =   0;
	else if (val > 255)   *optr++ = 255;
	else		      *optr++ = val;
    }
}

/* }}} */
/* {{{ xrsF31_clampRow	Clamp a rowbuffer to [0,1].			*/

#ifdef CURRENTLY_UNUSED
xrsF31_clampRow( iptr, optr, n)
float           *iptr,*optr;
int                          n;
{   while (n --> 0) {
	float val = *iptr++;
	if      (val < (float) 0.0)   *optr++ = (float) 0.0;
	else if (val > (float) 1.0)   *optr++ = (float) 1.0;
	else		      *optr++ = val;
    }
}
#endif

/* }}} */
/* {{{ xrsz32_addRow	Add a constant to row while copying it.		*/

xrsz32_addRow( iptr, sptr, w, n)
register int  *iptr;
register short      *sptr;
register int               w, n;
{
    while (n --> 0) {
	if (n >= 7) {
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    n -= 7;
	} else {
	    *iptr++ += (w * *sptr++);
	}
    }
}

/* }}} */
/* {{{ xrsF32_addRow	Add a constant to row while copying it.		*/

xrsF32_addRow( iptr, sptr, w, n)
register float*iptr;
register float      *sptr;
register float             w;
register int                  n;
{
    while (n --> 0) {
	if (n >= 7) {
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    n -= 7;
	} else {
	    *iptr++ += (w * *sptr++);
	}
    }
}

/* }}} */
/* {{{ xrsz33_divRow	Divide row by a constant while copying it.	*/

xrsz33_divRow( iptr, sptr, tot, n )
register int  *iptr;
register short      *sptr;
register int               tot, n;
{
    while (n --> 0) {
	if (n >= 7) {
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    n -= 7;
	} else {
	    *sptr++ = (*iptr++) / tot;
    }	}
}

/* }}} */
/* {{{ xrsF33_divRow	Divide row by a constant while copying it.	*/

xrsF33_divRow( iptr, sptr, tot, n )
register float*iptr;
register float      *sptr;
         float             tot;
register int                    n;
{
    register float tot_inv = 1.0 / tot;
    while (n --> 0) {
	if (n >= 7) {
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    n -= 7;
	} else {
	    *sptr++ = (*iptr++) * tot_inv;
    }	}
}

/* }}} */
/* {{{ xrsz34_makeFilter Preprocessed filter for xrsz35_applyXFilter.	*/

static void
xrsz34_makeFilter(
    FILTER** pFilter,
    int*     pFilterLen,
    short*   srcBuf,
    int	     src_siz,
    int      dst_siz,
    int*     maxN
) {
    FILTER *f, *filter;
    int   x, min, max, n, pos;
    float cover;

    float dstMin, dstMax, dstCent, dstRad;
    float   fMin,   fMax, srcCent, srcRad;
    int   srcMin, srcMax;

    {   /* If our filter doesn't exist, malloc() some ram for it. */
	/* If our filter is too small, realloc() more ram for it. */
	int oldFilterLen = *pFilterLen;
	xrsz13_size_buf( pFilter, pFilterLen, dst_siz, sizeof(FILTER) );
	filter = f = *pFilter;

	/* If we created any new FILTER instances,*/
	/* mark them as not yet having any weight */
        /* vector allocated:                      */
	if (dst_siz > oldFilterLen) {
	    for (x = oldFilterLen;   x < dst_siz;   x++) f[x].physical_len = 0;
    }   }

    /* Over each individual filter that we are creating: */
    *maxN = 0;
    for (x = 0;   x < dst_siz;   x++) {

	/* Handle magnifying and minifying cases separately: */
	if (dst_siz < src_siz) {

	    /*********************/
	    /* We are minifying. */
	    /*********************/

	    dstRad  = xrsz36_filterRadius()/dst_siz;
	    dstCent = ((float)x+0.5)/dst_siz;
	    srcMin  = floor((dstCent-dstRad)*src_siz+EPSILON);
	    srcMax  = floor((dstCent+dstRad)*src_siz-EPSILON);

	    if (srcMin < 0)          srcMin = 0;
	    if (srcMax >= src_siz)   srcMax = src_siz-1;

	    f->n      = 1 + srcMax - srcMin;
	    f->dat    = srcBuf + srcMin;
	    xrsz14_Maybe_Re_Alloc_Weight_Vector( f );
	    f->total_weight = 0;

	    for (n = 0;   n < f->n;   n++) {
		dstMin  = dst_siz*((((float)srcMin +n   )/src_siz) - dstCent);
		dstMax  = dst_siz*((((float)srcMin +n +1)/src_siz) - dstCent);
		cover = (
		    xrsz38_filterIntegrate( dstMax, 1 ) -
		    xrsz38_filterIntegrate( dstMin, 0 )
		);  
		f->weight[n] = (ONE*cover)+0.5;
		f->total_weight += f->weight[n];
	    }

	} else {

	    /**********************/
	    /* We are magnifying. */
	    /**********************/

	    /* Filter radius will normally be a pixel or  */
	    /* two; express it as a fraction of src rect: */

	    srcRad = xrsz36_filterRadius()/src_siz;

	    /* Express current pixel-width of interest */
	    /* in 0 -> 1 parametric coords relative to */
	    /* complete output range of interest:      */
	    dstMin = ((float)x    )/dst_siz;
	    dstMax = ((float)x+1.0)/dst_siz;

	    /* Express the image of above pixel on src */
	    /* rectangle in 0 -> 1 parametric coords   */
	    /* relative to complete input rectangle:   */
	    srcMin = floor((dstMin-srcRad)*src_siz+0.5+EPSILON);
	    srcMax = floor((dstMax+srcRad)*src_siz-0.5-EPSILON);

	    /* Clip above image to edges of image, */
	    /* if it extends beyond it:            */
	    if (srcMin < 0)          srcMin = 0;
	    if (srcMax >= src_siz)   srcMax = src_siz-1;

	    /* Build a filter with one weight for  */
	    /* each pixel actually present:        */

	    /* Compute and remember number of weights */
	    /* needed for this particular filter.  We */
	    /* need one for each input pixel present: */
	    f->n      = 1 + srcMax - srcMin;

	    /* Compute pointer into input row buffer  */
	    /* corresponding to first weight:         */
	    f->dat    = srcBuf + srcMin;

	    /* Ensure our weight vector is long enough: */
	    xrsz14_Maybe_Re_Alloc_Weight_Vector( f );

	    /* Compute each weight vector entry: */
	    f->total_weight = 0;
	    for (n = 0;   n < f->n;   n++) {

		srcCent = (srcMin+n+0.5) / src_siz;
		fMin  = src_siz*(dstMin-srcCent);
		fMax  = src_siz*(dstMax-srcCent);
		cover = (
		    xrsz38_filterIntegrate( fMax, 1 ) -
		    xrsz38_filterIntegrate( fMin, 0 )
		);
		f->weight[n]  = (ONE*cover)+0.5;

		f->total_weight += f->weight[n];
	    }
	}
	if (f->n > *maxN)   *maxN = f->n;
	f++;
    }
}

/* }}} */
/* {{{ xrsF34_makeFilter Preprocessed filter for xrsF35_applyXFilter.	*/

static void
xrsF34_makeFilter(
    FLOAT_FILTER** pFilter,
    int*     pFilterLen,
    float*   srcBuf,
    int	     src_siz,
    int      dst_siz,
    int*     maxN
) {
    FLOAT_FILTER *f, *filter;
    int   x, min, max, n, pos;
    float cover;

    float dstMin, dstMax, dstCent, dstRad;
    float   fMin,   fMax, srcCent, srcRad;
    int   srcMin, srcMax;

    {   /* If our filter doesn't exist, malloc() some ram for it. */
	/* If our filter is too small, realloc() more ram for it. */
	int oldFilterLen = *pFilterLen;
	xrsz13_size_buf( pFilter, pFilterLen, dst_siz, sizeof(FLOAT_FILTER) );
	filter = f = *pFilter;

	/* If we created any new FILTER instances,*/
	/* mark them as not yet having any weight */
        /* vector allocated:                      */
	if (dst_siz > oldFilterLen) {
	    for (x = oldFilterLen;   x < dst_siz;   x++) f[x].physical_len = 0;
    }   }

    /* Over each individual filter that we are creating: */
    *maxN = 0;
    for (x = 0;   x < dst_siz;   x++) {

	/* Handle magnifying and minifying cases separately: */
	if (dst_siz < src_siz) {

	    /*********************/
	    /* We are minifying. */
	    /*********************/

	    dstRad  = xrsz36_filterRadius()/dst_siz;
	    dstCent = ((float)x+0.5)/dst_siz;
	    srcMin  = floor((dstCent-dstRad)*src_siz+EPSILON);
	    srcMax  = floor((dstCent+dstRad)*src_siz-EPSILON);

	    if (srcMin < 0)          srcMin = 0;
	    if (srcMax >= src_siz)   srcMax = src_siz-1;

	    f->n      = 1 + srcMax - srcMin;
	    f->dat    = srcBuf + srcMin;
	    xrsF14_Maybe_Re_Alloc_Weight_Vector( f );
	    f->total_weight = (float) 0.0;

	    for (n = 0;   n < f->n;   n++) {
		dstMin  = dst_siz*((((float)srcMin +n   )/src_siz) - dstCent);
		dstMax  = dst_siz*((((float)srcMin +n +1)/src_siz) - dstCent);
		cover = (
		    xrsz38_filterIntegrate( dstMax, 1 ) -
		    xrsz38_filterIntegrate( dstMin, 0 )
		);  
		f->weight[n] = cover+0.5;
		f->total_weight += f->weight[n];
	    }

	} else {

	    /**********************/
	    /* We are magnifying. */
	    /**********************/

	    /* Filter radius will normally be a pixel or  */
	    /* two; express it as a fraction of src rect: */

	    srcRad = xrsz36_filterRadius()/src_siz;

	    /* Express current pixel-width of interest */
	    /* in 0 -> 1 parametric coords relative to */
	    /* complete output range of interest:      */
	    dstMin = ((float)x    )/dst_siz;
	    dstMax = ((float)x+1.0)/dst_siz;

	    /* Express the image of above pixel on src */
	    /* rectangle in 0 -> 1 parametric coords   */
	    /* relative to complete input rectangle:   */
	    srcMin = floor((dstMin-srcRad)*src_siz+0.5+EPSILON);
	    srcMax = floor((dstMax+srcRad)*src_siz-0.5-EPSILON);

	    /* Clip above image to edges of image, */
	    /* if it extends beyond it:            */
	    if (srcMin < 0)          srcMin = 0;
	    if (srcMax >= src_siz)   srcMax = src_siz-1;

	    /* Build a filter with one weight for  */
	    /* each pixel actually present:        */

	    /* Compute and remember number of weights */
	    /* needed for this particular filter.  We */
	    /* need one for each input pixel present: */
	    f->n      = 1 + srcMax - srcMin;

	    /* Compute pointer into input row buffer  */
	    /* corresponding to first weight:         */
	    f->dat    = srcBuf + srcMin;

	    /* Ensure our weight vector is long enough: */
	    xrsF14_Maybe_Re_Alloc_Weight_Vector( f );

	    /* Compute each weight vector entry: */
	    f->total_weight = (float) 0.0;
	    for (n = 0;   n < f->n;   n++) {

		srcCent = (srcMin+n+0.5) / src_siz;
		fMin  = src_siz*(dstMin-srcCent);
		fMax  = src_siz*(dstMax-srcCent);
		cover = (
		    xrsz38_filterIntegrate( fMax, 1 ) -
		    xrsz38_filterIntegrate( fMin, 0 )
		);
		f->weight[n]  = cover+0.5;

		f->total_weight += f->weight[n];
	    }
	}
	if (f->n > *maxN)   *maxN = f->n;
	f++;
    }
}

/* }}} */
/* {{{ xrsz35_applyXFilter Filter a row by preprocessed filter.		*/

xrsz35_applyXFilter( dstbuf, xfilt, x_dst_siz )
register short      *dstbuf;
register FILTER             *xfilt;
register int                        x_dst_siz;
{
    register short *w;
    register short *dptr;
    register int n, val;

    while (x_dst_siz --> 0) {
	if ((n = xfilt->n) == 1) {
	    *dstbuf++ = *xfilt->dat;
	} else {
	    w    = xfilt->weight;
	    dptr = xfilt->dat;
	    val  = 0;
	    n    = xfilt->n;
	    while (n --> 0)   val += *w++ * *dptr++;
	    *dstbuf++ = val / xfilt->total_weight;
	}
	xfilt++;
    }
}

/* }}} */
/* {{{ xrsF35_applyXFilter Filter a row by preprocessed filter.		*/

xrsF35_applyXFilter( dstbuf, xfilt, x_dst_siz )
register float      *dstbuf;
register FLOAT_FILTER       *xfilt;
register int                        x_dst_siz;
{
    register float *w;
    register float *dptr;
    register int n, val;

    while (x_dst_siz --> 0) {
	if ((n = xfilt->n) == 1) {
	    *dstbuf++ = *xfilt->dat;
	} else {
	    w    = xfilt->weight;
	    dptr = xfilt->dat;
	    val  = 0;
	    n    = xfilt->n;
	    while (n --> 0)   val += *w++ * *dptr++;
	    *dstbuf++ = val / xfilt->total_weight;
	}
	xfilt++;
    }
}

/* }}} */
/* {{{ xrsz36_filterRadius Compute appropriate radius for selected filter.  */

float xrsz36_filterRadius()
{
    switch(filtershape) {
    case BOX:	    return 0.5 * blurfactor;
    case TRIANGLE:  return 1.0 * blurfactor;
    case QUADRATIC: return 1.0 * blurfactor;
    case MITCHELL:  return 2.0 * blurfactor;
    default:
	abort();
    }
}

/* }}} */
/* {{{ xrsz37_QuadraticIntegrate Compute area under part of QUADRATIC filter*/

float xrsz37_QuadraticIntegrate( x )
float                            x; /* x <= 0.0 */
{
    if (x < -1.0)   return 0.0;
    if (x < -0.5)   return 2.0*((1.0/3.0)*(x*x*x+1.0) + x*x + x);
    else            return     -(2.0/3.0)* x*x*x + x + 0.5;
}

/* }}} */
/* {{{ xrsz38_filterIntegrate Compute area under part of selected filter.   */

float xrsz38_filterIntegrate( x, side )
float                         x;
int                              side;
{
    /* Return the integral from -INFINITY to x of the       */
    /* selected filter function.  By taking the difference  */
    /* of this value at either end of a closed interval, we */
    /* can determine the weight to assign to that interval  */
    /* in our descrete transform.                           */
    float val;

    x = x / blurfactor;

    switch(filtershape) {

    case BOX:
        /* Canonical boxfilter is unit area squarewave */
	/* at [-0.5, 0.5], zero elsewhere:             */
	if      (x < -0.5)   return   0.0;
	else if (x >  0.5)   return   1.0;
	else		     return x+0.5;

    case TRIANGLE:
        /* Canonical triangular filter is unit area    */
	/* triangle at [-1.0, 1.0], zero elsewhere:    */
	if      (x < -1.0)	    return 0.0;
	else if (x >  1.0)	    return 1.0;
	else if (x <  0.0) {
	    val = x+1.0;
	    return 0.5 * val * val;
	} else {
	    val = 1.0 - x;
	    return 1.0 - 0.5 * val * val;
	}

    case QUADRATIC:
	/* The 'quadratic' may be a cubic approximation */
	/* to a guassian, nonzero on [-1.0, 1.0]:       */
	if (x < 0.0)   return       xrsz37_QuadraticIntegrate( x);
	else           return 1.0 - xrsz37_QuadraticIntegrate(-x);

    case MITCHELL:
	/* This looks like maybe a still better approximation */
        /* to a gaussian, nonzero on [-2.0, 2.0].             */
	if (side == 0)   return 0.0;
	return xrsz50_mitchell(x);
    }
    abort();
}

/* }}} */
/* {{{ xrsz50_mitchell Compute area under part of MITCHELL filter.	*/

static float p0, p2, p3, q0, q1, q2, q3;

/*
 * see Mitchell&Netravali, "Reconstruction Filters in Computer Graphics",
 * SIGGRAPH 88.  Mitchell code provided by Paul Heckbert.
 */
float xrsz50_mitchell(x)	/* Mitchell & Netravali's two-param cubic */
float                 x;
{
    static int firsted;

    if(!firsted) {
	xrsz60_mitchellInit( 1.0/3.0, 1.0/3.0 );
	firsted = 1;
    }
    if (x <-2.) return 0.0;
    if (x <-1.) return 2.0*(q0-x*(q1-x*(q2-x*q3)));
    if (x < 0.) return 2.0*(p0+x*x*    (p2-x*p3)) ;
    if (x < 1.) return 2.0*(p0+x*x*    (p2+x*p3)) ;
    if (x < 2.) return 2.0*(q0+x*(q1+x*(q2+x*q3)));
    return 0.0;
}

/* }}} */
/* {{{ xrsz60_mitchellInit Initialize some constants used xrsz50_mitchell.*/

xrsz60_mitchellInit( b, c )
float                b, c;
{
    p0 = (  6. -  2.*b        ) / 6.;
    p2 = (-18. + 12.*b +  6.*c) / 6.;
    p3 = ( 12. -  9.*b -  6.*c) / 6.;
    q0 = (	  8.*b + 24.*c) / 6.;
    q1 = (     - 12.*b - 48.*c) / 6.;
    q2 = (	  6.*b + 30.*c) / 6.;
    q3 = (     -     b -  6.*c) / 6.;
}
/* }}} */

/************************************************************************/
/* NONE OF THE FOLLOWING IS USED, OR EVEN COMPILED. (95Dec11jsp)	*/
/************************************************************************/

/* -- Filtered Image Rescaling -- Dale Schumacher			*/
/* {{{ Header stuff.							*/

#ifdef UNUSED

/* clamp the input to the specified range */
#define CLAMP(v,l,h)    ((v)<(l) ? (l) : (v) > (h) ? (h) : v)
/* #include "GraphicsGems.h" */

static char	_Program[] = "fzoom";
static char	_Version[] = "0.20";
static char	_Copyright[] = "Public Domain 1991 by Dale Schumacher";

#ifndef EXIT_SUCCESS
#define	EXIT_SUCCESS	(0)
#define	EXIT_FAILURE	(1)
#endif

typedef	unsigned char	Pixel;

typedef struct {
	int	xsize;		/* horizontal size of the image in Pixels */
	int	ysize;		/* vertical size of the image in Pixels */
	Pixel *	data;		/* pointer to first scanline of image */
	int	span;		/* byte offset between two scanlines */
} Image;

#define	WHITE_PIXEL	(255)
#define	BLACK_PIXEL	(0)

#endif

/* }}} */

/* -- Generic image access and i/o support routines. --			*/
/* {{{ next_token							*/

#ifdef UNUSED

static char *
next_token(
    FILE* f
) {
    static char delim[] = " \t\r\n";
    static char *t = NULL;
    static char lnbuf[256];
    char *p;

    while (t == NULL) {

	/* Nothing in the buffer. */

	/* Read a line: */
	if (!fgets(lnbuf, sizeof(lnbuf), f))   return NULL;

	/* Clip any comment: */
	if (p = strchr(lnbuf, '#'))   *p = '\0';

	/* Get first token: */
	t = strtok( lnbuf, delim );
    }

    /* Get next token: */
    p = t;
    t = strtok( (char *)NULL, delim );

    return p;
}

#endif

/* }}} */
/* {{{ new_image							*/

#ifdef UNUSED

static Image *
new_image(
    int xsize,
    int ysize
) {
    /* Create a blank image */
    Image *image;

    if ((image = (Image *)malloc(sizeof(Image)))
    && (image->data = (Pixel *)calloc(ysize, xsize))
    ){
	image->xsize = xsize;
	image->ysize = ysize;
	image->span  = xsize;
    }

    return image;
}

#endif

/* }}} */
/* {{{ free_image							*/

#ifdef UNUSED

static void
free_image(
    Image *image
) {
    free( image->data );
    free( image       );
}

#endif

/* }}} */
/* {{{ load_image							*/

#ifdef UNUSED

static Image *
load_image(
    FILE *f
) {
    /* Read image from file: */
    char*  p;
    int    width, height;
    Image* image;

    if (((p = next_token(f)) && (strcmp(p, "Bm") == 0))
    &&  ((p = next_token(f)) && ((width  = atoi(p)) > 0))
    &&  ((p = next_token(f)) && ((height = atoi(p)) > 0))
    &&  ((p = next_token(f)) && !strcmp(p, "8"))
    &&  (image = new_image(width, height))
    &&  (fread(image->data, width, height, f) == height)
    ){
	/* Successful load: */
        return image;
    }

    /* Load failed: */
    return NULL;
}

#endif

/* }}} */
/* {{{ saved_image							*/

#ifdef UNUSED

static int
save_image(
    FILE*  f,
    Image* image
) {
    /* Write image to file: */
    fprintf(f, "Bm # PXM 8-bit greyscale image\n");
    fprintf(f,
        "%d %d 8 # width height depth\n",
	image->xsize, image->ysize
    );

    if (fwrite(image->data, image->xsize, image->ysize, f) == image->ysize) {
	/* Save succeeded: */
	return 0;
    }

    /* Save failed: */
    return -1;
}

#endif

/* }}} */
/* {{{ get_pixel							*/

#ifdef UNUSED

static Pixel
get_pixel(
    Image* image,
    int    x,
    int    y
) {
    static Image *im = NULL;
    static int    yy = -1;
    static Pixel  *p = NULL;

    if (x <  0  ||  x >= image->xsize
    ||  y <  0  ||  y >= image->ysize
    ){
	return 0;
    }

    if (im != image || yy != y) {
	im = image;
	yy = y;
	p = image->data + (y * image->span);
    }

    return p[x];
}

#endif

/* }}} */
/* {{{ get_row								*/

#ifdef UNUSED

static void
get_row(
    Pixel *row,
    Image *image,
    int    y
) {
    if((y < 0) || (y >= image->ysize)) {
	return;
    }

    memcpy(
	row,
	image->data + (y * image->span),
	(sizeof(Pixel) * image->xsize)
    );
}

#endif

/* }}} */
/* {{{ get_column							*/

#ifdef UNUSED

static void
get_column(
    Pixel *column,
    Image *image,
    int x
) {
    int i, d;
    Pixel *p;

    if (x < 0 || x >= image->xsize) {
	return;
    }

    d = image->span;
    for (i = image->ysize, p = image->data + x;   i --> 0;   p += d) {
	*column++ = *p;
    }
}

#endif

/* }}} */
/* {{{ put_pixel							*/

#ifdef UNUSED

static Pixel
put_pixel(
    Image*image,
    int   x,
    int   y,
    Pixel data
) {
    static Image *im = NULL;
    static int    yy = -1;
    static Pixel * p = NULL;

    if (x < 0 || x >= image->xsize
    ||  y < 0 || y >= image->ysize
    ){
	return 0;
    }

    if (im != image || yy != y) {
	im = image;
	yy = y;
	p  = image->data + (y * image->span);
    }

    return   p[x] = data;
}

#endif

/* }}} */

/* -- Filter function definitions --					*/
/* {{{ filter								*/

#ifdef UNUSED

#define	filter_support		(1.0)

static double
filter(
    double t
) {
    /* f(t) = 2|t|^3 - 3|t|^2 + 1, -1 <= t <= 1 */
    if (t < 0.0) t = -t;
    if (t < 1.0) return (2.0 * t - 3.0) * t * t + 1.0;
    return 0.0;
}

#endif

/* }}} */
/* {{{ box_filter							*/

#ifdef UNUSED

#define	box_support		(0.5)

static double
box_filter(
    double t
) {
    if (t > -0.5
    &&  t <= 0.5
    ){
        return 1.0;
    }
    return 0.0;
}

#endif

/* }}} */
/* {{{ triangle_filter							*/

#ifdef UNUSED

#define	triangle_support	(1.0)

double
triangle_filter(
    double t
) {
    if (t < 0.0)   t = -t;
    if (t < 1.0)   return 1.0 - t;
    return  0.0;
}

#endif

/* }}} */
/* {{{ bell_filter							*/

#ifdef UNUSED

#define	bell_support		(1.5)

static double
bell_filter(
    double t
) {
    /* box (*) box (*) box */
    if (t < 0.0) t = -t;
    if (t < 0.5) return 0.75 - (t * t);
    if (t < 1.5) {
	t = (t - 1.5);
	return 0.5 * (t * t);
    }
    return 0.0;
}

#endif

/* }}} */
/* {{{ B_spline_filter							*/

#ifdef UNUSED
#define	B_spline_support	(2.0)

static double
B_spline_filter(
    double t
) {
    /* box (*) box (*) box (*) box */
    double tt;

    if (t < 0) t = -t;
    if (t < 1) {
	tt = t * t;
	return (0.5 * tt * t) - tt + (2.0 / 3.0);
    } else if (t < 2) {
	t = 2 - t;
	return (1.0 / 6.0) * (t * t * t);
    }
    return 0.0;
}
#endif

/* }}} */
/* {{{ sinc								*/

#ifdef UNUSED
static double
sinc(
    double x
) {
    x *= M_PI;
    if (x != 0)   return sin(x) / x;
    return 1.0;
}
#endif

/* }}} */
/* {{{ Lanczos3_filter							*/

#ifdef UNUSED

#define	Lanczos3_support	(3.0)

static double
Lanczos3_filter(
    double t
) {
    if (t < 0) t = -t;
    if (t < 3.0)   return sinc(t) * sinc(t/3.0);
    return 0.0;
}
#endif

/* }}} */
/* {{{ Mitchell_filter							*/

#ifdef UNUSED

#define	Mitchell_support	(2.0)

#define	B	(1.0 / 3.0)
#define	C	(1.0 / 3.0)

static double
Mitchell_filter(
    double t
) {
    double tt;

    tt = t * t;
    if (t < 0) t = -t;
    if (t < 1.0) {
	t = (((12.0 - 9.0 * B - 6.0 * C) * (t * tt))
	   + ((-18.0 + 12.0 * B + 6.0 * C) * tt)
	   + (6.0 - 2 * B)
	);
	return t / 6.0;
    } else if (t < 2.0) {
	t = (((-1.0 * B - 6.0 * C) * (t * tt))
	   + ((6.0 * B + 30.0 * C) * tt)
	   + ((-12.0 * B - 48.0 * C) * t)
	   + (8.0 * B + 24 * C)
	);
	return t / 6.0;
    }
    return 0.0;
}
#endif

/* }}} */
/* {{{ zoom -- Central image rescaling routine				*/

#ifdef UNUSED
typedef struct {
    int	   pixel;
    double weight;
} CONTRIB;

typedef struct {
    int	     n;		/* Number of contributors.		*/
    CONTRIB* p;		/* Pointer to vector of contributions.	*/
} CLIST;

CLIST	*contrib;	/* Array of contribution lists.		*/

static void
zoom(
    Image *dst,				/* Destination image structure.	*/
    Image *src,				/* Source image structure.	*/
    double (*filterf)(),		/* Filter function.		*/
    double fwidth			/* Filter width (support).	*/
) {
    Image *tmp;				/* Intermediate image.		*/
    double xscale, yscale;		/* Zoom scale factors.		*/
    int i, j, k;			/* Loop variables.		*/
    int n;				/* Pixel number.		*/
    double center, left, right;		/* Filter calculation variables.*/
    double width, fscale, weight;	/* Filter calculation variables.*/
    Pixel *raster;			/* A row or column of pixels.	*/

    /* Create intermediate image to hold horizontal zoom: */
    tmp = new_image(dst->xsize, src->ysize);
    xscale = (double) dst->xsize / (double) src->xsize;
    yscale = (double) dst->ysize / (double) src->ysize;

    /* Pre-calculate filter contributions for a row: */
    contrib = (CLIST *)calloc(dst->xsize, sizeof(CLIST));
    if (xscale < 1.0) {
	width = fwidth / xscale;
	fscale = 1.0 / xscale;
	for (i = 0;   i < dst->xsize;   ++i) {
	    contrib[i].n = 0;
	    contrib[i].p = (CONTRIB *)calloc((int) (width * 2 + 1),
					sizeof(CONTRIB)
	    );
	    center = (double) i / xscale;
	    left   = ceil( center - width);
	    right  = floor(center + width);
	    for (j = left; j <= right; ++j) {
		weight = center - (double) j;
		weight = (*filterf)(weight / fscale) / fscale;
		if (j < 0) {
		    n = -j;
		} else if (j >= src->xsize) {
		    n = (src->xsize - j) + src->xsize - 1;
		} else {
		    n = j;
		}
		k = contrib[i].n++;
		contrib[i].p[k].pixel  = n;
		contrib[i].p[k].weight = weight;
	    }
	}
    } else {
	for (i = 0; i < dst->xsize; ++i) {
	    contrib[i].n = 0;
	    contrib[i].p = (CONTRIB *)calloc((int) (fwidth * 2 + 1),
		sizeof(CONTRIB)
	    );
	    center = (double) i / xscale;
	    left = ceil(center - fwidth);
	    right = floor(center + fwidth);
	    for (j = left; j <= right; ++j) {
		weight = center - (double) j;
		weight = (*filterf)(weight);
		if (j < 0) {
		    n = -j;
		} else if (j >= src->xsize) {
		    n = (src->xsize - j) + src->xsize - 1;
		} else {
		    n = j;
		}
		k = contrib[i].n++;
		contrib[i].p[k].pixel = n;
		contrib[i].p[k].weight = weight;
	    }
	}
    }

    /* Apply filter to zoom horizontally from src to tmp: */
    raster = (Pixel *)calloc(src->xsize, sizeof(Pixel));
    for (k = 0; k < tmp->ysize; ++k) {
	get_row(raster, src, k);
	for (i = 0; i < tmp->xsize; ++i) {
	    weight = 0.0;
	    for (j = 0; j < contrib[i].n; ++j) {
		weight += raster[ contrib[i].p[j].pixel ]
			        * contrib[i].p[j].weight
		;
	    }
	    put_pixel(
		tmp, i, k,
		(Pixel)CLAMP(weight, BLACK_PIXEL, WHITE_PIXEL)
	    );
	}
    }
    free(raster);

    /* Free the memory allocated for horizontal filter weights: */
    for (i = 0;   i < tmp->xsize;   ++i) {
	free( contrib[i].p );
    }
    free( contrib );

    /* Pre-calculate filter contributions for a column: */
    contrib = (CLIST *)calloc( dst->ysize, sizeof(CLIST) );
    if (yscale < 1.0) {
	width = fwidth / yscale;
	fscale = 1.0 / yscale;
	for (i = 0;   i < dst->ysize;   ++i) {
	    contrib[i].n = 0;
	    contrib[i].p = (CONTRIB *)calloc((int) (width * 2 + 1),
		sizeof(CONTRIB)
	    );
	    center = (double) i / yscale;
	    left = ceil(center - width);
	    right = floor(center + width);
	    for (j = left; j <= right; ++j) {
		weight = center - (double) j;
		weight = (*filterf)(weight / fscale) / fscale;
		if (j < 0) {
		    n = -j;
		} else if (j >= tmp->ysize) {
		    n = (tmp->ysize - j) + tmp->ysize - 1;
		} else {
		    n = j;
		}
		k = contrib[i].n++;
		contrib[i].p[k].pixel = n;
		contrib[i].p[k].weight = weight;
	    }
	}
    } else {
	for (i = 0; i < dst->ysize; ++i) {
	    contrib[i].n = 0;
	    contrib[i].p = (CONTRIB *)calloc((int) (fwidth * 2 + 1),
		sizeof(CONTRIB)
	    );
	    center = (double) i / yscale;
	    left = ceil(center - fwidth);
	    right = floor(center + fwidth);
	    for (j = left;   j <= right;   ++j) {
		weight = center - (double) j;
		weight = (*filterf)(weight);
		if (j < 0) {
		    n = -j;
		} else if(j >= tmp->ysize) {
		    n = (tmp->ysize - j) + tmp->ysize - 1;
		} else {
		    n = j;
		}
		k = contrib[i].n++;
		contrib[i].p[k].pixel = n;
		contrib[i].p[k].weight = weight;
	    }
	}
    }

    /* Apply filter to zoom vertically from tmp to dst: */
    raster = (Pixel *)calloc(tmp->ysize, sizeof(Pixel));
    for (k = 0;   k < dst->xsize;   ++k) {
	get_column( raster, tmp, k );
	for (i = 0;   i < dst->ysize;   ++i) {
	    weight = 0.0;
	    for (j = 0; j < contrib[i].n; ++j) {
		weight += raster[contrib[i].p[j].pixel]
		    * contrib[i].p[j].weight
		;
	    }
	    put_pixel(dst, k, i,
		(Pixel)CLAMP(weight, BLACK_PIXEL, WHITE_PIXEL)
	    );
	}
    }
    free(raster);

    /* Free the memory allocated for vertical filter weights: */
    for (i = 0;   i < tmp->xsize;   ++i) {
	free (contrib[i].p);
    }
    free( contrib );

    free_image( tmp );
}
#endif

/* }}} */

/* -- Command line interface --						*/
/* {{{ usage -- Central image rescaling routine				*/

#ifdef UNUSED
static void
usage()
{
    fprintf(stderr, "usage: %s [-options] input.bm output.bm\n", _Program);
    fprintf(stderr,
	"options:\n"
	"	-x xsize		output x size\n"
	"	-y ysize		output y size\n"
	"	-f filter		filter type\n"
	"{b=box, t=triangle, q=bell, B=B-spline,"
	" h=hermite, l=Lanczos3, m=Mitchell}\n"
    );
    exit(1);
}
#endif

/* }}} */
/* {{{ banner				 				*/

#ifdef UNUSED
static void
banner()
{
    printf("%s v%s -- %s\n", _Program, _Version, _Copyright);
}
#endif

/* }}} */
/* {{{ dale_main			 				*/

#ifdef UNUSED
static
dale_main(argc, argv)
int argc;
char *argv[];
{
    register int c;
    extern int optind;
    extern char *optarg;
    int xsize = 0, ysize = 0;
    double (*f)() = filter;
    double s = filter_support;
    char *dstfile, *srcfile;
    Image *dst, *src;
    FILE *fp;

    while((c = getopt(argc, argv, "x:y:f:V")) != EOF) {
	switch(c) {
	case 'x': xsize = atoi(optarg); break;
	case 'y': ysize = atoi(optarg); break;
	case 'f':
	    switch(*optarg) {
	    case 'b': f=box_filter; s=box_support; break;
	    case 't': f=triangle_filter; s=triangle_support; break;
	    case 'q': f=bell_filter; s=bell_support; break;
	    case 'B': f=B_spline_filter; s=B_spline_support; break;
	    case 'h': f=filter; s=filter_support; break;
	    case 'l': f=Lanczos3_filter; s=Lanczos3_support; break;
	    case 'm': f=Mitchell_filter; s=Mitchell_support; break;
	    default: usage();
	    }
	    break;
	case 'V': banner(); exit(EXIT_SUCCESS);
	case '?': usage();
	default:  usage();
	}
    }
    if ((argc - optind) != 2)  usage();
    srcfile = argv[optind];
    dstfile = argv[optind + 1];
    if (((fp = fopen(srcfile, "r")) == NULL)
    || ((src = load_image(fp)) == NULL)
    ){
	fprintf(stderr, "%s: can't load source image '%s'\n",
	    _Program, srcfile
	);
	exit(EXIT_FAILURE);
    }
    fclose(fp);
    if (xsize <= 0)   xsize = src->xsize;
    if (ysize <= 0)   ysize = src->ysize;
    dst = new_image(xsize, ysize);
    zoom(dst, src, f, s);
    if (((fp = fopen(dstfile, "w")) == NULL)
    || (save_image(fp, dst) != 0)
    ){
	fprintf(stderr, "%s: can't save destination image '%s'\n",
	    _Program, dstfile
	);
	exit(EXIT_FAILURE);
    }
    fclose(fp);
    exit( EXIT_SUCCESS );
}
#endif

/* }}} */


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
