/* {{{ xheq.h -- Histogram equalization on 8-bit images.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jun01
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
extern LVAL xheq08_Equalize_Histogram_Msg();
extern LVAL xheq18_Equalize_Histogram_Relation_Msg();

#ifndef EXTERNED_ADDNOISE
extern LVAL k_addnoise;   /* Keyword ":ADD-NOISE" */
#define EXTERNED_ADDNOISE
#endif

#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	NULL,		xheq08_Equalize_Histogram_Msg		)
DEFINE_SUBR(	NULL,		xheq18_Equalize_Histogram_Relation_Msg	)
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS


#ifndef DEFINED_ADDNOISE
LVAL k_addnoise;   /* Keyword ":add-noise" */
#define DEFINED_ADDNOISE
#endif

LOCAL struct xheq_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xheq_xf8v_table[] = {
    {	":EQUALIZE-HISTOGRAM",	xheq08_Equalize_Histogram_Msg  	},

    {	NULL,			NULL	                	}
};
LOCAL struct xheq_xgrl_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xheq_xgrl_table[] = {
    {	":EQUALIZE-HISTOGRAM",	xheq18_Equalize_Histogram_Relation_Msg 	},

    {	NULL,			NULL	                	}
};
#endif

#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_ADDNOISE
    k_addnoise = xlenter(":ADD-NOISE");
#define CREATED_ADDNOISE
#endif

#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
    xgbj56_Enter_Messages( lv_xf8v,  xheq_xf8v_table );
    xgbj56_Enter_Messages( lv_xgrl,  xheq_xgrl_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
