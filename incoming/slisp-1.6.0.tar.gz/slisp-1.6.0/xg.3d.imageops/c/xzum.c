/* {{{ xzum.c -- Image-zoom (magnify/minify) transforms.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92May26
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 94Jun15 jsp: Allow out-of-range src/dst coordinates.			*/
/* 93May31 jsp: xzum29_Maybe_Resize_FilterRows malloc bugs fixed.	*/
/* 92Jun01 jsp: Operational.						*/
/* 92May26 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/cf2v.h"
#include "../../xg.3d/c/cf8v.h"
#include "../../xg.3d/c/cflv.h"

/* Haeberli & Heckbert stuff: */
#define IMPULSE		1
#define BOX		2
#define TRIANGLE	3
#define QUADRATIC	4
#define MITCHELL	5
static int   filtershape = TRIANGLE;
static float blurfactor = 1.0;

extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();

extern LVAL k_setarray;
extern LVAL k_new;
extern LVAL lv_xgrl;
extern LVAL lv_xflv;
extern LVAL lv_xf8v;
extern LVAL lv_xf2v;


extern LVAL k_result_in;/* Symbol ":RESULT-IN" */
extern LVAL k_xsrcloc;
extern LVAL s_arraylist;

/* }}} */
/* {{{ --- statics ---							*/

static void xzum30_filterZoom(
    unsigned char*,int,int,int,int,int,
    unsigned char*,int,int,int,int,int,
    int
);
static void xzum30F_filterZoom(
    float*,int,int,int,int,int,
    float*,int,int,int,int,int,
    int
);

/* }}} */
/* {{{ --- Public fns ---						*/

/* }}} */
/* {{{ xzum03_Set_Filtershape -- Translate symbol to int constant.	*/

static void
xzum03_Set_Filtershape(
    LVAL shape
) {
    extern LVAL k_impulse;
    extern LVAL k_triangle;
    extern LVAL k_box;
    extern LVAL k_quadratic;
    extern LVAL k_mitchell;

    if        (shape == k_impulse  )   filtershape = IMPULSE  ;
    else if   (shape == k_box      )   filtershape = BOX      ;
    else if   (shape == k_triangle )   filtershape = TRIANGLE ;
    else if   (shape == k_quadratic)   filtershape = QUADRATIC;
    else if   (shape == k_mitchell )   filtershape = MITCHELL ;
    else      xlerror("Unknown :FILTER-SHAPE",shape);
}

/* }}} */
/* {{{ xzum08_Resize_Image_Msg -- Copy image while resizing.		*/

/* {{{ xzum06_Trim_Selected_Areas					*/


/* {{{ xzum04_Detop_Area -- Shave top 'ratio'th off this dimension.	*/

int xzum04_Detop_Area(
    float ratio,
    int*d_min,
    int*d_max
) {
    *d_max = *d_max - (int)(ratio * (float)(*d_max-*d_min));
    return *d_max != *d_min;
}

/* }}} */
/* {{{ xzum05_Debot_Area -- Shave bott0m 'ratio'th off this dimension.	*/

int xzum05_Debot_Area(
    float ratio,
    int*d_min,
    int*d_max
) {
    *d_min += (int)( ratio * (float)(*d_max - *d_min)  );
    return *d_max != *d_min;
}

/* }}} */

int xzum06_Trim_Selected_Areas(
    LVAL lv_src, int*x_src_min, int*y_src_min, int*x_src_siz, int*y_src_siz,
    LVAL lv_dst, int*x_dst_min, int*y_dst_min, int*x_dst_siz, int*y_dst_siz
) {
    int x_src_max = *x_src_min + *x_src_siz;
    int y_src_max = *y_src_min + *y_src_siz;
    int x_dst_max = *x_dst_min + *x_dst_siz;
    int y_dst_max = *y_dst_min + *y_dst_siz;

    int                             x_src_lim,  y_src_lim;
    int                             x_dst_lim,  y_dst_lim;
    xzum07_Get_X_And_Y_Dimensions( &x_src_lim, &y_src_lim, lv_src );
    xzum07_Get_X_And_Y_Dimensions( &x_dst_lim, &y_dst_lim, lv_dst );
    if (*x_src_siz < 1
    ||  *y_src_siz < 1
    ){
	xlerror("Bad :IMAGE-RESIZE area",lv_src);
    }
    if (*x_dst_siz < 1
    ||  *y_dst_siz < 1
    ){
	xlerror("Bad :IMAGE-RESIZE area",lv_dst);
    }

    /**************************************************/
    /* It turns out to be more convenient to the lisp */
    /* programmer to correctly handle src/dst areas   */
    /* which are partly or wholly outside the image,  */
    /* rather than flagging them as errors and making */
    /* the lisp programmer special-case them.         */
    /*                                                */
    /* We define "correctly handle" to mean ignoring  */
    /* any part of the operation which corresponds to */
    /* unavailable source or destination pixels, but  */
    /* correctly copying the rest:                    */
    /**************************************************/

    /* If part of the src/dst area   */
    /* is outside the src/dst image, */
    /* trim both areas to fix this:  */
    if (*x_src_min < 0) {
	float ratio = -*x_src_min / (float)(x_src_max - *x_src_min);
	if (!xzum05_Debot_Area( ratio, x_src_min, &x_src_max )) return 0;
	if (!xzum05_Debot_Area( ratio, x_dst_min, &x_dst_max )) return 0;
    }
    if (*x_dst_min < 0) {
	float ratio = -*x_dst_min / (float)(x_dst_max - *x_dst_min);
	if (!xzum05_Debot_Area( ratio, x_src_min, &x_src_max )) return 0;
	if (!xzum05_Debot_Area( ratio, x_dst_min, &x_dst_max )) return 0;
    }

    if (*y_src_min < 0) {
	float ratio = -*y_src_min / (float)(y_src_max - *y_src_min);
	if (!xzum05_Debot_Area( ratio, y_src_min, &y_src_max )) return 0;
	if (!xzum05_Debot_Area( ratio, y_dst_min, &y_dst_max )) return 0;
    }
    if (*y_dst_min < 0) {
	float ratio = -*y_dst_min / (float)(y_dst_max - *y_dst_min);
	if (!xzum05_Debot_Area( ratio, y_src_min, &y_src_max )) return 0;
	if (!xzum05_Debot_Area( ratio, y_dst_min, &y_dst_max )) return 0;
    }

    if (x_src_max >= x_src_lim) {
	float ratio = (x_src_max-x_src_lim) / (float)(x_src_max - *x_src_min);
	if (!xzum04_Detop_Area( ratio, x_src_min, &x_src_max )) return 0;
	if (!xzum04_Detop_Area( ratio, x_dst_min, &x_dst_max )) return 0;
    }
    if (x_dst_max >= x_dst_lim) {
	float ratio = (x_dst_max-x_dst_lim) / (float)(x_dst_max - *x_dst_min);
	if (!xzum04_Detop_Area( ratio, x_src_min, &x_src_max )) return 0;
	if (!xzum04_Detop_Area( ratio, x_dst_min, &x_dst_max )) return 0;
    }

    if (y_src_max >= y_src_lim) {
	float ratio = (y_src_max-y_src_lim) / (float)(y_src_max - *y_src_min);
	if (!xzum04_Detop_Area( ratio, y_src_min, &y_src_max )) return 0;
	if (!xzum04_Detop_Area( ratio, y_dst_min, &y_dst_max )) return 0;
    }
    if (y_dst_max >= y_dst_lim) {
	float ratio = (y_dst_max-y_dst_lim) / (float)(y_dst_max - *y_dst_min);
	if (!xzum04_Detop_Area( ratio, y_src_min, &y_src_max )) return 0;
	if (!xzum04_Detop_Area( ratio, y_dst_min, &y_dst_max )) return 0;
    }

    /* Return FALSE if src or dst area is wholly out of bounds: */
    if (*x_src_min >= x_src_lim
    ||  *y_src_min >= y_src_lim
    ||  *x_dst_min >= x_dst_lim
    ||  *y_dst_min >= y_dst_lim
    ||   x_src_max <= 0
    ||   y_src_max <= 0
    ||   x_dst_max <= 0
    ||   y_dst_max <= 0
    ){
        return FALSE;
    }

    *x_src_siz = x_src_max - *x_src_min;
    *y_src_siz = y_src_max - *y_src_min;

    *x_dst_siz = x_dst_max - *x_dst_min;
    *y_dst_siz = y_dst_max - *y_dst_min;

/* Nastyugly96Jul29jsp fix so John can keep working: */
/* BUGGO, should figure out what's going on... */
  if (*x_src_min + *x_src_siz == x_src_lim+1) --*x_src_siz;
  if (*y_src_min + *y_src_siz == y_src_lim+1) --*y_src_siz;
  if (*x_dst_min + *x_dst_siz == x_dst_lim+1) --*x_dst_siz;
  if (*y_dst_min + *y_dst_siz == y_dst_lim+1) --*y_dst_siz;

    /* Sanity check: */
    if (*x_src_min < 0   ||   *x_src_min + *x_src_siz > x_src_lim
    ||  *y_src_min < 0   ||   *y_src_min + *y_src_siz > y_src_lim
    ||  *x_dst_min < 0   ||   *x_dst_min + *x_dst_siz > x_dst_lim
    ||  *y_dst_min < 0   ||   *y_dst_min + *y_dst_siz > y_dst_lim
    ){
printf("*x_src_min d=%d\n",*x_src_min);
printf("*y_src_min d=%d\n",*y_src_min);
printf("*x_dst_min d=%d\n",*x_dst_min);
printf("*y_dst_min d=%d\n",*y_dst_min);
printf("*x_src_siz d=%d\n",*x_src_siz);
printf("*y_src_siz d=%d\n",*y_src_siz);
printf("*x_dst_siz d=%d\n",*x_dst_siz);
printf("*y_dst_siz d=%d\n",*y_dst_siz);
printf(" x_src_lim d=%d\n", x_src_lim);
printf(" y_src_lim d=%d\n", y_src_lim);
printf(" x_dst_lim d=%d\n", x_dst_lim);
printf(" y_dst_lim d=%d\n", y_dst_lim);
if (*x_src_min + *x_src_siz > x_src_lim) printf("*x_src_min + *x_src_siz > x_src_lim\n");
if (*y_src_min + *y_src_siz > y_src_lim) printf("*y_src_min + *y_src_siz > y_src_lim\n");
if (*x_dst_min + *x_dst_siz > x_dst_lim) printf("*x_dst_min + *x_dst_siz > x_dst_lim\n");
if (*y_dst_min + *y_dst_siz > y_dst_lim) printf("*y_dst_min + *y_dst_siz > y_dst_lim\n");
	fprintf(stderr,"xzum06_Trim_Selected_Areas: internal err\n");
	abort();
    }

    return TRUE;
}

/* }}} */
/* {{{ xzum07_Get_X_And_Y_Dimensions					*/

xzum07_Get_X_And_Y_Dimensions( px, py, lv )
int                           *px,*py;
LVAL                                   lv;
{   csry_rec* h = (csry_rec*) gobjimmbase( lv );
    if (h->rank != 2)  xlerror("Image array not 2-D!",lv);
    *py = h->dim[0];
    *px = h->dim[1];
}

/* }}} */

LVAL xzum08_Resize_Image_Msg() {
    extern LVAL xf8v04_Get_A_XF8V();
    extern LVAL k_from;
    extern LVAL k_blurfactor;
    extern LVAL k_filtershape;
    extern LVAL lv_xsrcloc;
    extern LVAL k_ysrcloc;
    extern LVAL k_xsrcsiz;
    extern LVAL k_ysrcsiz;
    extern LVAL k_xdstloc;
    extern LVAL k_ydstloc;
    extern LVAL k_xdstsiz;
    extern LVAL k_ydstsiz;

    LVAL lv_dst = NIL;	/* CLASS-UNIT-FLOAT array to copy from. */
    LVAL lv_src = NIL;  /* CLASS-UNIT-FLOAT array to copy into. */

    int  x_src_max;	/* Actual x-size of lv_src.		*/
    int  x_src_loc=0;	/* Src rectangle lower-left corner.	*/
    int  y_src_loc=0;	/* Src rectangle lower-left corner.	*/
    int  x_src_siz;	/* Src rectangle size in pixels.	*/
    int  y_src_siz;	/* Src rectangle size in pixels.	*/

    int  x_dst_max;	/* Actual x-size of lv_dst.		*/
    int  x_dst_loc=0;	/* Dst rectangle lower-left corner.	*/
    int  y_dst_loc=0;	/* Dst rectangle lower-left corner.	*/
    int  x_dst_siz;	/* Src rectangle size in pixels.	*/
    int  y_dst_siz;	/* Src rectangle size in pixels.	*/

    unsigned char* src_pxl;	/* Actual src pixel buffer.	*/
    unsigned char* dst_pxl;	/* Actual dst pixel buffer.	*/

    /* Read our arguments: */

    lv_dst = xf8v04_Get_A_XF8V();
    xzum07_Get_X_And_Y_Dimensions( &x_dst_siz, &y_dst_siz, lv_dst );
    x_dst_max = x_dst_siz;

    lv_src = xf8v04_Get_A_XF8V();
    xzum07_Get_X_And_Y_Dimensions( &x_src_siz, &y_src_siz, lv_src );
    x_src_max = x_src_siz;
    

    /* Scan optional parameters: */
    while (moreargs()) {

	LVAL key = xlgasymbol();

	if        (key == k_xsrcloc) {

	    x_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcloc) {

	    y_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xsrcsiz) {

	    x_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcsiz) {

	    y_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstloc) {

	    x_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstloc) {

	    y_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstsiz) {

	    x_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstsiz) {

	    y_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_filtershape) {

	    xzum03_Set_Filtershape( xlgasymbol() );

	} else if (key == k_blurfactor) {

	    blurfactor =  xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (blurfactor == 0.0)   xlfail("Zero :BLUR-FACTOR");

	} else {

	    xlerror("Bad :RESIZE-IMAGE keyword",key);
    }	}

    if (lv_src == lv_dst)  xlerror(":IMAGE-RESIZE from array to self!",lv_dst);
    if (!xzum06_Trim_Selected_Areas(
            lv_src, &x_src_loc, &y_src_loc, &x_src_siz, &y_src_siz,
            lv_dst, &x_dst_loc, &y_dst_loc, &x_dst_siz, &y_dst_siz
    )) {
	return NIL;
    }

    src_pxl = (unsigned char*) (csry_base( lv_src ));
    dst_pxl = (unsigned char*) (csry_base( lv_dst ));

    if (filtershape == IMPULSE) {

	xzum20_impulzeZoom(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
	    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
	);

    } else {

	xzum30_filterZoom(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
	    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz,
	    /*clamp:*/ filtershape == MITCHELL
	);
    }

    return NIL;
}

/* }}} */
/* {{{ xzum95_Resize_Image_Msg -- Copy image planes while resizing.	*/

/****************************************************************/
/* This function differs from xzum08_Resize_Image_Msg() only	*/
/* in that the arguments expected are graphic relations		*/
/* containing :pixel-reg :pixel-green :pixel-blue arrays,	*/
/* rather than just arrays.					*/
/****************************************************************/

xzum94_Resize_Image_Msg_A(
  lv_dst, lv_src,
  x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
  x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
  filtershape
)
LVAL  lv_src, lv_dst;
int   x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz;
int   x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz;
int   filtershape;
{
    unsigned char* src_pxl;
    unsigned char* dst_pxl;

    if (!lv_dst)   return;

    if (!xzum06_Trim_Selected_Areas(
            lv_src, &x_src_loc, &y_src_loc, &x_src_siz, &y_src_siz,
            lv_dst, &x_dst_loc, &y_dst_loc, &x_dst_siz, &y_dst_siz
    )) {
	return;
    }

    src_pxl = (unsigned char*) (csry_base( lv_src ));
    dst_pxl = (unsigned char*) (csry_base( lv_dst ));

    if (filtershape == IMPULSE) {

	xzum20_impulzeZoom(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
	    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
	);

    } else {

	xzum30_filterZoom(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
	    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz,
	    /*clamp:*/ filtershape == MITCHELL
	);
    }
}

LVAL xzum95_Resize_Image_Msg() {
    extern LVAL xgrl01_Get_A_XGRL();
    extern LVAL k_from;
    extern LVAL k_blurfactor;
    extern LVAL k_filtershape;
    extern LVAL lv_xsrcloc;
    extern LVAL k_ysrcloc;
    extern LVAL k_xsrcsiz;
    extern LVAL k_ysrcsiz;
    extern LVAL k_xdstloc;
    extern LVAL k_ydstloc;
    extern LVAL k_xdstsiz;
    extern LVAL k_ydstsiz;

    LVAL lv_dst = NIL;
    LVAL lv_src = NIL;
    int  x_src_max;
    int  x_src_loc=0, y_src_loc=0;
    int  x_src_siz  , y_src_siz  ;
    int  x_dst_max;
    int  x_dst_loc=0, y_dst_loc=0;
    int  x_dst_siz  , y_dst_siz  ;

    /* Read our arguments: */

    lv_dst = xgrl01_Get_A_XGRL();
    xzum07_Get_X_And_Y_Dimensions( &x_dst_siz, &y_dst_siz, lv_dst );
    x_dst_max = x_dst_siz;

    lv_src = xgrl01_Get_A_XGRL();
    xzum07_Get_X_And_Y_Dimensions( &x_src_siz, &y_src_siz, lv_src );
    x_src_max = x_src_siz;
    

    /* Scan optional parameters: */
    while (moreargs()) {

	LVAL key = xlgasymbol();

	if        (key == k_xsrcloc) {

	    x_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcloc) {

	    y_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xsrcsiz) {

	    x_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcsiz) {

	    y_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstloc) {

	    x_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstloc) {

	    y_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstsiz) {

	    x_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstsiz) {

	    y_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_filtershape) {

	    xzum03_Set_Filtershape( xlgasymbol() );

	} else if (key == k_blurfactor) {

	    blurfactor =  xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (blurfactor == 0.0)   xlfail("Zero :BLUR-FACTOR");

	} else {

	    xlerror("Bad :RESIZE-IMAGE keyword",key);
    }	}

    if (lv_src == lv_dst)   xlerror(":IMAGE-RESIZE from relation to self!",lv_dst);

    /* Fetch image-plane arrays out of graphic relations: */
    {   LVAL lv_src_red, lv_src_green, lv_src_blue, lv_src_depth;
	LVAL lv_dst_red, lv_dst_green, lv_dst_blue, lv_dst_depth;

	int  src_planes = xthl3b_GetPixelRedGreenBlueDepthIfPresent(
	    &lv_src_red,&lv_src_green,&lv_src_blue,&lv_src_depth, lv_src
	);
	int  dst_planes = xthl3b_GetPixelRedGreenBlueDepthIfPresent(
	    &lv_dst_red,&lv_dst_green,&lv_dst_blue,&lv_dst_depth, lv_dst
	);

	if (!src_planes || !dst_planes)   return NIL;

	/* For each output plane, assign an input plane to read from: */
	if (lv_dst_red   && !lv_src_red  ) {
	    lv_src_red   = lv_src_green ? lv_src_green : lv_src_blue ;
	}
	if (lv_dst_green && !lv_src_green) {
	    lv_src_green = lv_src_red   ? lv_src_red   : lv_src_blue ;
	}
	if (lv_dst_blue  && !lv_src_blue ) {
	    lv_src_blue  = lv_src_red   ? lv_src_red   : lv_src_green;
	}
	if (lv_dst_depth && !lv_src_depth) {
	    lv_src_depth = lv_src_red   ? lv_src_red   : lv_src_green;
	}

	/* Fill each output plane present: */
	xzum94_Resize_Image_Msg_A(
	    lv_dst_red  , lv_src_red  ,
	    x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
	    x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
	    filtershape
        );
	xzum94_Resize_Image_Msg_A(
	    lv_dst_green, lv_src_green,
	    x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
	    x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
	    filtershape
        );
	xzum94_Resize_Image_Msg_A(
	    lv_dst_blue , lv_src_blue ,
	    x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
	    x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
	    filtershape
        );
	xzum94_Resize_Image_Msg_A(
	    lv_dst_depth, lv_src_depth,
	    x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
	    x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
	    filtershape
        );
    }

    return NIL;
}

/* }}} */
/* {{{ xzum99_Resize_Relation_Msg -- Copy image planes while resizing.	*/

/****************************************************************/
/* This function differs from xzum95_Resize_Image_Msg()		*/
/* in that we try to just generically handle any combination	*/
/* of float and unit-float arrays, rather than being hardwired	*/
/* to handle just red/green/blue/depth.				*/
/****************************************************************/

xzum98_Resize_Relation_Msg_A(
  lv_dst, lv_src,
  x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
  x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
  filtershape
)
LVAL  lv_src, lv_dst;
int   x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz;
int   x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz;
int   filtershape;
{
    if (!lv_dst)   return;

    if (!xzum06_Trim_Selected_Areas(
            lv_src, &x_src_loc, &y_src_loc, &x_src_siz, &y_src_siz,
            lv_dst, &x_dst_loc, &y_dst_loc, &x_dst_siz, &y_dst_siz
    )) {
	return;
    }

    if (filtershape == IMPULSE) {

	if (xf8vp( lv_src )) {
	    unsigned char* src_pxl = (unsigned char*) (csry_base( lv_src ));
	    unsigned char* dst_pxl = (unsigned char*) (csry_base( lv_dst ));
	    xzum20_impulzeZoom(
		dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
		src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
	    );
	} else if (xflvp( lv_src )) {
	    float* src_pxl = (float*) (csry_base( lv_src ));
	    float* dst_pxl = (float*) (csry_base( lv_dst ));
	    xzum20F_impulzeZoom(
		dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
		src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
	    );
	} else {
	    xlerror("Bad :RESIZE-RELATION input array",lv_src);
	}

    } else {

	if (xf8vp( lv_src )) {
	    unsigned char* src_pxl = (unsigned char*) (csry_base( lv_src ));
	    unsigned char* dst_pxl = (unsigned char*) (csry_base( lv_dst ));
	    xzum30_filterZoom(
		dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
		src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz,
		/*clamp:*/ filtershape == MITCHELL
	    );
	} else if (xflvp( lv_src )) {
	    float* src_pxl = (float*) (csry_base( lv_src ));
	    float* dst_pxl = (float*) (csry_base( lv_dst ));
	    xzum30F_filterZoom(
		dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
		src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz,
		/*clamp:*/ filtershape == MITCHELL
	    );
	} else {
	    xlerror("Bad :RESIZE-RELATION input array",lv_src);
	}
    }
}

LVAL
xzum99_Resize_Relation_Msg() {
    extern LVAL xgrl01_Get_A_XGRL();
    extern LVAL k_from;
    extern LVAL k_blurfactor;
    extern LVAL k_filtershape;
    extern LVAL lv_xsrcloc;
    extern LVAL k_ysrcloc;
    extern LVAL k_xsrcsiz;
    extern LVAL k_ysrcsiz;
    extern LVAL k_xdstloc;
    extern LVAL k_ydstloc;
    extern LVAL k_xdstsiz;
    extern LVAL k_ydstsiz;

    int  x_src_max;
    int  x_src_loc=0, y_src_loc=0;
    int  x_src_siz  , y_src_siz  ;
    int  x_dst_max;
    int  x_dst_loc=0, y_dst_loc=0;
    int  x_dst_siz  , y_dst_siz  ;

    int  toProt = 3;
    LVAL lv_shape;
    LVAL lv_dst;
    LVAL lv_src;
    xlstkcheck(toProt);
    xlsave( lv_shape );
    xlsave( lv_dst   );
    xlsave( lv_src   );

    /* Read our arguments: */

    lv_src = xgrl01_Get_A_XGRL();
    xzum07_Get_X_And_Y_Dimensions( &x_src_siz, &y_src_siz, lv_src );
    x_src_max = x_src_siz;
    

    /* Scan optional parameters: */
    while (moreargs()) {

	LVAL key = xlgasymbol();

	if        (key == k_xsrcloc) {

	    x_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcloc) {

	    y_src_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xsrcsiz) {

	    x_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ysrcsiz) {

	    y_src_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstloc) {

	    x_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstloc) {

	    y_dst_loc = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_xdstsiz) {

	    x_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_ydstsiz) {

	    y_dst_siz = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (key == k_filtershape) {

	    xzum03_Set_Filtershape( xlgasymbol() );

	} else if (key == k_blurfactor) {

	    blurfactor =  xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (blurfactor == 0.0)   xlfail("Zero :BLUR-FACTOR");

	} else if (key == k_result_in) {

	    lv_dst = xgrl01_Get_A_XGRL();
	    xzum07_Get_X_And_Y_Dimensions( &x_dst_siz, &y_dst_siz, lv_dst );
	    x_dst_max = x_dst_siz;

	} else {

	    xlerror("Bad :RESIZE-RELATION keyword",key);
    }	}

    /* Create output relation if we weren't given */
    /* one, or if it is wrong shape:              */
    if (lv_dst == NIL
    ||  !xgrlp(lv_dst)
    ||  lv_dst == lv_src
    ){
	/* Create graphic relation to hold result: */ 
	lv_shape = cons(/*cols*/cvfixnum(x_src_siz),     NIL);
	lv_shape = cons(/*rows*/cvfixnum(y_src_siz), lv_shape);
	lv_dst   = xsendmsg1( lv_xgrl, k_new, lv_shape );
    }

    /* Over all arrays in lv_src: */
    {   LVAL* pArrayList;
	LVAL  lv_prop_cell;
	LVAL  lv_valu_cell;

	if (!xthl87_GetAddressOfObjectVariableValue(
	    lv_src,
	    getclass( lv_src ),
	    s_arraylist,
	    &pArrayList
	)) {
	    xlbadtype( lv_src );/* No arraylist! Should not be possible. */
	}

	for (
	    lv_prop_cell = *pArrayList;
	    consp(lv_prop_cell) && consp(lv_valu_cell=cdr(lv_prop_cell));
	    lv_prop_cell = cdr( lv_valu_cell )
	) {
	    LVAL lv_key = car(lv_prop_cell);
	    LVAL lv_ary = car(lv_valu_cell);

	    /* We currently only support float and byte arrays: */
	    if (!xflvp( lv_ary )
	    &&  !xf8vp( lv_ary )
	    ){
		xlerror( "Must be float or unit-float array", lv_ary );
	    }

	    /* Make sure a matching destination array exists: */
	    {   LVAL lv_dst_ary = xgrl3c_Get_Array( lv_dst, lv_key, NIL, TRUE );
		if (lv_dst_ary == NIL) {

		    /* Create destination array: */ 
		    if (!consp(lv_shape)) {
			lv_shape   = cons(/*cols*/cvfixnum(x_src_siz),     NIL);
			lv_shape   = cons(/*rows*/cvfixnum(y_src_siz), lv_shape);
		    }
		    if (xflvp( lv_ary )) {
			lv_dst_ary = xsendmsg1( lv_xf8v, k_new, lv_shape );
		    } else {
			lv_dst_ary = xsendmsg1( lv_xflv, k_new, lv_shape );
		    }

                    /* Insert destination array in destination relation: */
                    xsendmsg2( lv_dst, k_setarray, lv_key, lv_dst_ary );
		}

		/* Do the indicated rescaling: */
		xzum98_Resize_Relation_Msg_A(
		    lv_dst_ary  , lv_ary,
		    x_src_max, x_src_loc, y_src_loc, x_src_siz, y_src_siz,
		    x_dst_max, x_dst_loc, y_dst_loc, x_dst_siz, y_dst_siz,
		    filtershape
		);

	    }
	}
    }

    xlpopn(toProt);

    return lv_dst;
}

/* }}} */

/* {{{ --- Comments on SGI code and copyright ---			*/

/************************************************************************/
/*                              comments                                */
/*                                                                      */
/*  Following code adapted from SGI's 'izoom.c' filter, in their	*/
/*  4Dgifts code distribution, which carries the copyright:		*/
/*

    Numerous people have asked about permission to use source
    code found in 4Dgifts.  The below Copyright statement
    should clarify things.

    This Copyright in no way presumes ownership of previously
    Copyright material within the anthology that is found in
    /usr/people/4Dgifts.  The most notable examples are: Free
    Software Foundation (accp), Inc and Trustees of Columbia
    University in the City of New York (kermit).

    *
    * Copyright (c) 1991 Silicon Graphics, Inc.
    *
    * Permission to use, copy, modify, distribute, and sell this software and
    * its documentation for any purpose is hereby granted without fee, provided
    * that (i) the above copyright notices and this permission notice appear in
    * all copies of the software and related documentation, and (ii) the name of
    * Silicon Graphics may not be used in any advertising or
    * publicity relating to the software without the specific, prior written
    * permission of Silicon Graphics.
    * 
    * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF
    * ANY KIND,
    * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
    * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
    *
    * IN NO EVENT SHALL SILICON GRAPHICS BE LIABLE FOR
    * ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
    * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
    * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF 
    * LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
    * OF THIS SOFTWARE.
    */

/*  Original code was a small program designed to process one image     */
/*  and exit, hence malloced randomly right and left.  This version     */
/*  is intended to be called repeatedly from an interactive program,    */
/*  hence it allocates buffers when first called, expands them as       */
/*  needed, and never contracts or frees the buffers (to minimize       */
/*  fragmentation and wasted cycles).                                   */
/*                                                                      */
/*  izoom-                                                              */
/*          Magnify or minify a picture with or without filtering.  The */
/*  filtered method is one pass, uses 2-d convolution, and is optimized */
/*  by integer arithmetic and precomputation of filter coeffs.          */
/*									*/
/*                  Paul Haeberli and Paul Heckbert - 1988		*/
/*                                                                      */
/************************************************************************/

#include <stdio.h>
#include <math.h>
#include <malloc.h>

#define EPSILON		0.0001

/* This file is design to operate on 8-bit pixel values  */
/* using 16-bit shorts to accumulate values, interpreted */
/* as containing 12-bit fixpoint numbers:                */
#define SHIFT 12
#define ONE (1<<SHIFT)

float xzum36_filterRadius();
float xzum38_filterIntegrate();
float xzum50_mitchell();


/* impulse zoom implementation follows */

#define GRID_TO_FLOAT(pos,n)	(((pos)+0.5)/(n))
#define FLOAT_TO_GRID(pos,n)	((pos)*(n))

/* For a 3x3 convolution (typical), 'n' */
/* will be 3 and 'weight' will point to */
/* three precomputed weights.		*/
typedef struct FILTER {
    int    physical_len;	/* # Physical entries in 'weight'.	*/
    int    n	       ;	/* # useful   entries in 'weight'.	*/
    int    total_weight;	/* Sum of first 'n' 'weight' entries.	*/

    short* dat         ;
    short* weight      ;
} FILTER;

typedef struct FLOAT_FILTER {
    int    physical_len;	/* # Physical entries in 'weight'.	*/
    int    n	       ;	/* # useful   entries in 'weight'.	*/
    float  total_weight;	/* Sum of first 'n' 'weight' entries.	*/

    float* dat         ;
    float* weight      ;
} FLOAT_FILTER;

/* }}} */

/*     --- SGI fns ---							*/
/* {{{ --- statics ---							*/

static void xzum13_size_buf(void*,int*,int,int );
static void xzum14_Maybe_Re_Alloc_Weight_Vector( FILTER* );
static void xzum14F_Maybe_Re_Alloc_Weight_Vector( FLOAT_FILTER* );
static void xzum34_makeFilter(FILTER**,int*,short*,int,int,int*);
static void xzum34F_makeFilter(FLOAT_FILTER**,int*,float*,int,int,int*);

/* }}} */

/* {{{ xzum11_get_row	Read row from array into buffer.		*/

xzum11_get_row( buf, ary, x_max, x_loc, x_siz, y_loc, y )
short*          buf;
unsigned char*       ary;
int                       x_max, x_loc, x_siz, y_loc, y;
{
    register         short* dst = buf;
    register unsigned char* src = ary + (y_loc+y)*x_max + x_loc;
    register                i   = x_siz;
    while (i --> 0) {
	if (i >= 7) {
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    i -= 7;
	} else {
	    *dst++ = *src++;
	}
    }
}

/* }}} */
/* {{{ xzum11F_get_row	Read row from array into buffer.		*/

xzum11F_get_row(buf, ary, x_max, x_loc, x_siz, y_loc, y )
float*          buf;
float*               ary;
int                       x_max, x_loc, x_siz, y_loc, y;
{
    register float* dst = buf;
    register float* src = ary + (y_loc+y)*x_max + x_loc;
    register        i   = x_siz;
    while (i --> 0) {
	if (i >= 7) {
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    i -= 7;
	} else {
	    *dst++ = *src++;
	}
    }
}

/* }}} */
/* {{{ xzum12_put_row	Write row from buffer into an array.		*/

xzum12_put_row( ary, x_ary_max, x_loc, x_siz, y_loc, y, buf )
unsigned char*  ary;
int                  x_ary_max, x_loc, x_siz, y_loc, y;
short*                                                  buf;
{
    register         short* src = buf;
    register unsigned char* dst = ary + (y_loc+y)*x_ary_max + x_loc;
    register                i   = x_siz;
    while (i --> 0) {
	if (i >= 7) {
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    i -= 7;
	} else {
	    *dst++ = *src++;
	}
    }
}

/* }}} */
/* {{{ xzum12F_put_row	Write row from buffer into an array.		*/

xzum12F_put_row(ary, x_ary_max, x_loc, x_siz, y_loc, y, buf )
float*          ary;
int                  x_ary_max, x_loc, x_siz, y_loc, y;
float*                                                  buf;
{
    register float* src = buf;
    register float* dst = ary + (y_loc+y)*x_ary_max + x_loc;
    register        i   = x_siz;
    while (i --> 0) {
	if (i >= 7) {
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    *dst++ = *src++;
	    i -= 7;
	} else {
	    *dst++ = *src++;
	}
    }
}

/* }}} */
/* {{{ xzum13_size_buf	Make given buf large enough, if need be.	*/

static void
xzum13_size_buf(
    void*   pb,
    int*    p_old_size,
    int     needed_size,
    int     el_size
) {
    short** pbufptr = (short**) pb;
    if (needed_size <= *p_old_size)   return;

    {   int bytes = needed_size * el_size;
        if (!*p_old_size)   *pbufptr = (short*)   malloc(           bytes );
        else                *pbufptr = (short*)  realloc( *pbufptr, bytes );
	if (!*pbufptr) {printf("xzum13 out of ram!"); abort();}
    }
    *p_old_size = needed_size;
}

/* }}} */
/* {{{ xzum14_Maybe_Re_Alloc_Weight_Vector for xzum35_applyXFilter.	*/

static void
xzum14_Maybe_Re_Alloc_Weight_Vector(
    FILTER *f
) {
    xzum13_size_buf(&f->weight, &f->physical_len, f->n, sizeof(short));
}

/* }}} */
/* {{{ xzum14F_Maybe_Re_Alloc_Weight_Vector for xzum35F_applyXFilter.	*/

static void
xzum14F_Maybe_Re_Alloc_Weight_Vector(
    FLOAT_FILTER *f
) {
    xzum13_size_buf(&f->weight, &f->physical_len, f->n, sizeof(float));
}

/* }}} */
/* {{{ xzum20_impulseZoom	Scale image by (only) copying pixels.	*/

short*  xzum14_srcbuf; int xzum15_srcbuf_len = 0;
short*  xzum16_dstbuf; int xzum17_dstbuf_len = 0;
int     xzum18_xltmap; int xzum19_xltmap_len = 0;
short*  xzum1a_tmpbuf; int xzum1b_tmpbuf_len = 0;
xzum20_impulzeZoom(
    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
)
unsigned char* dst_pxl;
int          x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz;
unsigned char* src_pxl;
int          x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz;
{
    float       fy;
    int      y_dst;
    int      y_src;
    int last_y_src;

    /* Make our temporary buffers big enough to hold a row: */
    xzum13_size_buf(&xzum14_srcbuf,&xzum15_srcbuf_len,x_src_siz,sizeof(short));
    xzum13_size_buf(&xzum16_dstbuf,&xzum17_dstbuf_len,x_dst_siz,sizeof(short));
    xzum13_size_buf(&xzum18_xltmap,&xzum19_xltmap_len,x_dst_siz,sizeof(int  ));

    /* Map output pixel xcoords to input pixel xcoords: */
    xzum21_makexmap( xzum18_xltmap, x_src_siz, x_dst_siz );

    /* Compute all output pixel rows: */
    last_y_src = -1;
    for (y_dst = 0;   y_dst < y_dst_siz;   ++y_dst) {

	/* Figure out which input pixel row to read from: */
	fy    = GRID_TO_FLOAT( y_dst, y_dst_siz );
	y_src = FLOAT_TO_GRID(    fy, y_src_siz );

	/* Fetch & scale that input pixel row unless same as last input row: */
	if (y_src != last_y_src) {
	    xzum11_get_row(
		xzum14_srcbuf, 
                src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src
	    );
	    if (x_src_siz != x_dst_siz) {
		xzum22_xscalebuf(
		    xzum16_dstbuf, x_dst_siz, xzum18_xltmap, xzum14_srcbuf
		);
	    }
	    last_y_src = y_src;
	}

	/* Write scaled input pixel row to output pixel array: */
	xzum12_put_row(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
	    x_src_siz == x_dst_siz ? xzum14_srcbuf : xzum16_dstbuf
	);
    }
}

/* }}} */
/* {{{ xzum20F_impulseZoom	Scale image by (only) copying pixels.	*/

float*  xzum14F_srcbuf; int xzum15F_srcbuf_len = 0;
float*  xzum16F_dstbuf; int xzum17F_dstbuf_len = 0;
int     xzum18F_xltmap; int xzum19F_xltmap_len = 0;
float*  xzum1aF_tmpbuf; int xzum1bF_tmpbuf_len = 0;
xzum20F_impulzeZoom(
    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz,
    src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz
)
unsigned char* dst_pxl;
int          x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst_siz;
unsigned char* src_pxl;
int          x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src_siz;
{
    float       fy;
    int      y_dst;
    int      y_src;
    int last_y_src;

    /* Make our temporary buffers big enough to hold a row: */
    xzum13_size_buf(&xzum14F_srcbuf,&xzum15F_srcbuf_len,x_src_siz,sizeof(float));
    xzum13_size_buf(&xzum16F_dstbuf,&xzum17F_dstbuf_len,x_dst_siz,sizeof(float));
    xzum13_size_buf(&xzum18F_xltmap,&xzum19F_xltmap_len,x_dst_siz,sizeof(int  ));

    /* Map output pixel xcoords to input pixel xcoords: */
    xzum21_makexmap( xzum18F_xltmap, x_src_siz, x_dst_siz );

    /* Compute all output pixel rows: */
    last_y_src = -1;
    for (y_dst = 0;   y_dst < y_dst_siz;   ++y_dst) {

	/* Figure out which input pixel row to read from: */
	fy    = GRID_TO_FLOAT( y_dst, y_dst_siz );
	y_src = FLOAT_TO_GRID(    fy, y_src_siz );

	/* Fetch & scale that input pixel row unless same as last input row: */
	if (y_src != last_y_src) {
	    xzum11F_get_row(
		xzum14F_srcbuf, 
                src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src
	    );
	    if (x_src_siz != x_dst_siz) {
		xzum22F_xscalebuf(
		    xzum16F_dstbuf, x_dst_siz, xzum18F_xltmap, xzum14F_srcbuf
		);
	    }
	    last_y_src = y_src;
	}

	/* Write scaled input pixel row to output pixel array: */
	xzum12F_put_row(
	    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
	    x_src_siz == x_dst_siz ? xzum14F_srcbuf : xzum16F_dstbuf
	);
    }
}

/* }}} */
/* {{{ xzum21_makexmap	Make map from output cols to input, for IMPULSE.*/

xzum21_makexmap( xltmap, x_src_siz, x_dst_siz)
int              xltmap[];
int                      x_src_siz, x_dst_siz;
{   int x, ax;
    float fx;

    for(x = 0;   x < x_dst_siz;   x++) {
       fx = GRID_TO_FLOAT( x,x_dst_siz);
       ax = FLOAT_TO_GRID(fx,x_src_siz);
       xltmap[x] = ax;
    }
}

/* }}} */
/* {{{ xzum22_mscalebuf		Do IMPULSE remapping on a row.		*/

xzum22_xscalebuf( dstbuf, x_dst_siz, xltmap, srcbuf )
register short   *dstbuf;
register                  x_dst_siz;
register int                         xltmap[];
register short   			    *srcbuf;
{
    register i;
    for (i = 0;   i < x_dst_siz;   ) {
	if (x_dst_siz-i >= 8) {
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	} else {
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	}
    }
}

/* }}} */
/* {{{ xzum22F_mscalebuf	Do IMPULSE remapping on a row.		*/

xzum22F_xscalebuf( dstbuf, x_dst_siz, xltmap, srcbuf )
register float    *dstbuf;
register                  x_dst_siz;
register int                         xltmap[];
register float				     *srcbuf;
{
    register i;
    for (i = 0;   i < x_dst_siz;   ) {
	if (x_dst_siz-i >= 8) {
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	} else {
	    *dstbuf++ = srcbuf[ xltmap[i++] ];
	}
    }
}

/* }}} */
/* {{{ Filtered zoom globals (byte)					*/

/* While running, xFilter points to a vector */
/* of xFilter_len FILTER instances, one for  */
/* each column in the destination rectangle. */
/*                                           */
/* Similarly, yFilter points to a vector     */
/* of yFilter_len FILTER instances, one for  */
/* each row    in the destination rectangle. */
FILTER *xzum3a_xFilter;    int xzum3b_xFilter_len = 0;
FILTER *xzum3c_yFilter;    int xzum3d_yFilter_len = 0;

/* filterRows is a 2-D array of input lines which we've  */
/* already transformed.  Since each output line requires */
/* several input lines, this cache speeds things up...   */
short **xzum3e_filterRows; int xzum3f_rows        = 0;
			   int xzum3g_cols        = 0;



int   *xzum3h_accumulateRow; int xzum3i_accumulateRow_len  = 0;

/* }}} */
/* {{{ Filtered zoom globals (float)					*/

FLOAT_FILTER *xzum3aF_xFilter;    int xzum3bF_xFilter_len = 0;
FLOAT_FILTER *xzum3cF_yFilter;    int xzum3dF_yFilter_len = 0;

float **xzum3eF_filterRows;int xzum3fF_rows       = 0;
			   int xzum3gF_cols       = 0;

float *xzum3hF_accumulateRow;int xzum3iF_accumulateRow_len = 0;

/* }}} */
/* {{{ xzum28_Zero_Integer_Buffer					*/

xzum28_Zero_Integer_Buffer( buf, len )
register int               *buf, len;
{
    /* Original code used bzero, but that tends to be a */
    /* portability problem, and this isn't that time-   */
    /* critical, to my taste ...                        */
    while (len --> 0) {
	if (len >= 7) {
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    *buf++ = 0;
	    len -= 7;
	} else {
	    *buf++ = 0;
    }	}
}

/* }}} */
/* {{{ xzum28F_Zero_Float_Buffer					*/

xzum28F_Zero_Float_Buffer( buf, len )
register int              *buf, len;
{
    /* Original code used bzero, but that tends to be a */
    /* portability problem, and this isn't that time-   */
    /* critical, to my taste ... -- CrT                 */
    while (len --> 0) {
	if (len >= 7) {
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    *buf++ = (float) 0.0;
	    len -= 7;
	} else {
	    *buf++ = (float) 0.0;
    }	}
}

/* }}} */
/* {{{ xzum29_Maybe_Resize_FilterRows					*/

xzum29_Maybe_Resize_FilterRows( needed_rows, needed_cols )
int                             needed_rows, needed_cols;
{   int i;
    if (!xzum3f_rows) {
	xzum3e_filterRows = (short**) malloc( needed_rows * sizeof(short *));
	if (!xzum3e_filterRows) {printf("xzum29/a out of ram!"); abort();}
	for (i = 0;   i < needed_rows;   i++) {
	    xzum3e_filterRows[i] = (short*) malloc( needed_cols * sizeof(short  ));
	    if (!xzum3e_filterRows[i]) {printf("xzum29/b out of ram!"); abort();}
	}
	xzum3f_rows = needed_rows;
        xzum3g_cols = needed_cols;
    } else {
	if (xzum3f_rows < needed_rows) {
	    xzum3e_filterRows = (short**) realloc(
		xzum3e_filterRows,
		needed_rows * sizeof(short *)
	    );
	    if (!xzum3e_filterRows) {printf("xzum29/c out of ram!"); abort();}
	    for (i = xzum3f_rows;   i < needed_rows;   i++) {
		xzum3e_filterRows[i] = (short*) malloc(
		    xzum3g_cols * sizeof(short)
		);
	        if (!xzum3e_filterRows[i]) {printf("xzum29/ out of ram!"); abort();}
	    }
	    xzum3f_rows = needed_rows;
	}
	if (xzum3g_cols < needed_cols) {
	    for (i = 0;   i < xzum3f_rows;   i++) {
		xzum3e_filterRows[i] = (short*) realloc(
		    xzum3e_filterRows[i],
		    needed_cols * sizeof(short)
		);
		if (!xzum3e_filterRows[i]) {printf("xzum29/ out of ram!"); abort();}
	    }
	}
        xzum3g_cols = needed_cols;
    }
}

/* }}} */
/* {{{ xzum29F_Maybe_Resize_FilterRows					*/

xzum29F_Maybe_Resize_FilterRows( needed_rows, needed_cols )
int                              needed_rows, needed_cols;
{   int i;
    if (!xzum3fF_rows) {
	xzum3eF_filterRows = (float**) malloc( needed_rows * sizeof(float *));
	if (!xzum3eF_filterRows) {printf("xzum29F/a out of ram!"); abort();}
	for (i = 0;   i < needed_rows;   i++) {
	    xzum3eF_filterRows[i] = (float*) malloc( needed_cols * sizeof(float  ));
	    if (!xzum3eF_filterRows[i]) {printf("xzum29F/b out of ram!"); abort();}
	}
	xzum3fF_rows = needed_rows;
        xzum3gF_cols = needed_cols;
    } else {
	if (xzum3fF_rows < needed_rows) {
	    xzum3eF_filterRows = (float**) realloc(
		xzum3eF_filterRows,
		needed_rows * sizeof(float *)
	    );
	    if (!xzum3eF_filterRows) {printf("xzum29F/c out of ram!"); abort();}
	    for (i = xzum3fF_rows;   i < needed_rows;   i++) {
		xzum3eF_filterRows[i] = (float*) malloc(
		    xzum3gF_cols * sizeof(float)
		);
	        if (!xzum3eF_filterRows[i]) {printf("xzum29F/ out of ram!"); abort();}
	    }
	    xzum3fF_rows = needed_rows;
	}
	if (xzum3gF_cols < needed_cols) {
	    for (i = 0;   i < xzum3fF_rows;   i++) {
		xzum3eF_filterRows[i] = (float*) realloc(
		    xzum3eF_filterRows[i],
		    needed_cols * sizeof(float)
		);
		if (!xzum3eF_filterRows[i]) {printf("xzum29F/ out of ram!"); abort();}
	    }
	}
        xzum3gF_cols = needed_cols;
    }
}

/* }}} */
/* {{{ xzum30_filterZoom Magnify/minify image by convolution.		*/

static void
xzum30_filterZoom(
    unsigned char* dst_pxl,	/* Actual dst pixel buffer.	*/
    int          x_dst_max,	/* Actual x-size  of dst_pxl.	*/
    int          x_dst_loc,	/* Dst rect lower-left corner.	*/
    int          x_dst_siz,	/* Dst rect size  in pixels.	*/
    int          y_dst_loc,	/* Dst rect lower-left corner.	*/
    int          y_dst_siz,	/* Dst rect size  in pixels.	*/

    unsigned char* src_pxl,	/* Actual src pixel buffer.	*/
    int          x_src_max,	/* Actual x-size  of src_pxl.	*/
    int          x_src_loc,	/* Src rect lower-left corner.	*/
    int          x_src_siz,	/* Src rect size  in pixels.	*/
    int          y_src_loc,	/* Src rect lower-left corner.	*/
    int          y_src_siz,	/* Src rect size  in pixels.	*/

    int          clamp		/* TRUE iff filter yields vals	*/
) {				/* outside of input 0-255 range.*/
    FILTER *f;
    int x, y_dst, y_src;
    short *w;
    short **rptr;
    short *row;
    int nrows;
    int fy, n, total_weight;
    int i, min, max;
    float fmin, fmax;

    /* Make sure our temporary buffers are big enough: */

    /* A buffer to hold the current input line: */
    xzum13_size_buf(&xzum14_srcbuf, &xzum15_srcbuf_len, x_src_siz, sizeof(short));

    /* Two buffers to hold the current output line. */
    /* One would suffice, but Paul prefers copying  */
    /* between buffers rather than in-place ops:    */
    xzum13_size_buf(&xzum16_dstbuf, &xzum17_dstbuf_len, x_dst_siz, sizeof(short));
    xzum13_size_buf(&xzum1a_tmpbuf, &xzum1b_tmpbuf_len, x_dst_siz, sizeof(short));

    xzum34_makeFilter(
	&xzum3a_xFilter, &xzum3b_xFilter_len,
        xzum14_srcbuf, x_src_siz, x_dst_siz, &nrows
    );

    xzum34_makeFilter(
	&xzum3c_yFilter, &xzum3d_yFilter_len,
	0,             y_src_siz, y_dst_siz, &nrows
    );

    /* Allocate a temporary buffer big enough to hold */
    /* prefiltered versions of all the input rows     */
    /* contributing to any one output row.  That is,  */
    /* for a 3x3 convolution kernel, we'll need to    */
    /* buffer three full x-filtered input rows:       */
    xzum29_Maybe_Resize_FilterRows(
	/* needed_rows: */ nrows,
	/* needed_cols: */ x_dst_siz
    );

    xzum13_size_buf(
        &xzum3h_accumulateRow,
	&xzum3i_accumulateRow_len,
	x_dst_siz,
	sizeof( int )
    );

    /* Over all destination rows in output image: */
    y_src = 0;
    for (y_dst = 0;   y_dst < y_dst_siz;   ++y_dst) {

        /* Find appropriate y-filter for this row: */
	f = xzum3c_yFilter + y_dst;

        /* X-filter all source rows which contribute  */
        /* to the output row on which we are working: */
	max = ((int)f->dat) / sizeof(short) + (f->n - 1);
	while (y_src <= max) {
	    xzum11_get_row(
		xzum14_srcbuf, 
                src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src++
	    );
	    row = xzum3e_filterRows[0];
	    for (i = 0;   i < nrows-1;   i++) {
		xzum3e_filterRows[i] = xzum3e_filterRows[i+1];
	    }
	    xzum3e_filterRows[nrows-1] = row;
	    xzum35_applyXFilter(
		xzum3e_filterRows[nrows-1], xzum3a_xFilter, x_dst_siz
	    );
	}

	/* Different code depending on number of input */
        /* rows contributing to our output row:        */
	if (f->n == 1) {

	    /* Only one input row contributes to our   */
	    /* output row.  Clamp input row if needed, */
	    /* then just copy it to output row:        */
	    if (!clamp) {
		xzum12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xzum3e_filterRows[nrows-1]
		);
	    } else {
		xzum31_clampRow(
		    xzum3e_filterRows[nrows-1], xzum1a_tmpbuf, x_dst_siz
		);
		xzum12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xzum1a_tmpbuf
		);
	    }

	} else {

	    /* More than one input row contributes to our output row. */

	    /* Zero a buffer in which to accumulate the contributions */
	    /* of the various input rows:                             */
	    xzum28_Zero_Integer_Buffer( xzum3h_accumulateRow, x_dst_siz );

	    /* Sum the various pre-x-filtered rows, each weighted */
	    /* by the appropriate value from our y-filter:        */
	    for (fy = 0;   fy < f->n;   fy++) {
		xzum32_addRow(
		    xzum3h_accumulateRow,
		    xzum3e_filterRows[ fy + (nrows-1) - (f->n-1) ],
		    f->weight[fy],
		    x_dst_siz
		);
	    }

	    /* Normalize the results to equivalent of unit weight: */
	    xzum33_divRow(
		xzum3h_accumulateRow,xzum16_dstbuf,f->total_weight,x_dst_siz
	    );

	    /* Do any needed clamping, then copy to output: */
	    if (clamp) {
		xzum31_clampRow( xzum16_dstbuf, xzum1a_tmpbuf, x_dst_siz );
		xzum12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xzum1a_tmpbuf
		);
	    } else {
		xzum12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xzum16_dstbuf
   		);
    }   }   }
}

/* }}} */
/* {{{ xzum30F_filterZoom Magnify/minify image by convolution.		*/

static void
xzum30F_filterZoom(
    float*       dst_pxl,	/* Actual dst pixel buffer.	*/
    int          x_dst_max,	/* Actual x-size  of dst_pxl.	*/
    int          x_dst_loc,	/* Dst rect lower-left corner.	*/
    int          x_dst_siz,	/* Dst rect size  in pixels.	*/
    int          y_dst_loc,	/* Dst rect lower-left corner.	*/
    int          y_dst_siz,	/* Dst rect size  in pixels.	*/

    float*       src_pxl,	/* Actual src pixel buffer.	*/
    int          x_src_max,	/* Actual x-size  of src_pxl.	*/
    int          x_src_loc,	/* Src rect lower-left corner.	*/
    int          x_src_siz,	/* Src rect size  in pixels.	*/
    int          y_src_loc,	/* Src rect lower-left corner.	*/
    int          y_src_siz,	/* Src rect size  in pixels.	*/

    int          clamp		/* TRUE iff filter yields vals	*/
) {				/* outside of input 0-255 range.*/
    FLOAT_FILTER *f;
    int x, y_dst, y_src;
    float *w;
    float **rptr;
    float *row;
    int nrows;
    int fy, n;
    float total_weight;
    int i, min, max;
    float fmin, fmax;

    /* Make sure our temporary buffers are big enough: */

    /* A buffer to hold the current input line: */
    xzum13_size_buf(&xzum14F_srcbuf, &xzum15F_srcbuf_len, x_src_siz, sizeof(float));

    /* Two buffers to hold the current output line. */
    /* One would suffice, but Paul prefers copying  */
    /* between buffers rather than in-place ops:    */
    xzum13_size_buf(&xzum16F_dstbuf, &xzum17F_dstbuf_len, x_dst_siz, sizeof(float));
    xzum13_size_buf(&xzum1aF_tmpbuf, &xzum1bF_tmpbuf_len, x_dst_siz, sizeof(float));

    xzum34F_makeFilter(
	&xzum3aF_xFilter, &xzum3bF_xFilter_len,
        xzum14F_srcbuf, x_src_siz, x_dst_siz, &nrows
    );

    xzum34F_makeFilter(
	&xzum3cF_yFilter, &xzum3dF_yFilter_len,
	0,             y_src_siz, y_dst_siz, &nrows
    );

    /* Allocate a temporary buffer big enough to hold */
    /* prefiltered versions of all the input rows     */
    /* contributing to any one output row.  That is,  */
    /* for a 3x3 convolution kernel, we'll need to    */
    /* buffer three full x-filtered input rows:       */
    xzum29F_Maybe_Resize_FilterRows(
	/* needed_rows: */ nrows,
	/* needed_cols: */ x_dst_siz
    );

    xzum13_size_buf(
        &xzum3hF_accumulateRow,
	&xzum3iF_accumulateRow_len,
	x_dst_siz,
	sizeof( float )
    );

    /* Over all destination rows in output image: */
    y_src = 0;
    for (y_dst = 0;   y_dst < y_dst_siz;   ++y_dst) {

        /* Find appropriate y-filter for this row: */
	f = xzum3cF_yFilter + y_dst;

        /* X-filter all source rows which contribute  */
        /* to the output row on which we are working: */
	max = ((int)f->dat) / sizeof(float) + (f->n - 1);
	while (y_src <= max) {
	    xzum11F_get_row(
		xzum14F_srcbuf, 
                src_pxl, x_src_max, x_src_loc, x_src_siz, y_src_loc, y_src++
	    );
	    row = xzum3eF_filterRows[0];
	    for (i = 0;   i < nrows-1;   i++) {
		xzum3eF_filterRows[i] = xzum3eF_filterRows[i+1];
	    }
	    xzum3eF_filterRows[nrows-1] = row;
	    xzum35F_applyXFilter(
		xzum3eF_filterRows[nrows-1], xzum3aF_xFilter, x_dst_siz
	    );
	}

	/* Different code depending on number of input */
        /* rows contributing to our output row:        */
	if (f->n == 1) {

	    /* Only one input row contributes to our   */
	    /* output row.  Clamp input row if needed, */
	    /* then just copy it to output row:        */
            #ifdef IMPRACTICAL /* Float arrays aren't in a known range, so */
	    if (!clamp) {      /* we can't clamp them, alas.               */
	    #endif
		xzum12F_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xzum3eF_filterRows[nrows-1]
		);
            #ifdef IMPRACTICAL /* Float arrays aren't in a known range, so */
	    } else {
		xzum31F_clampRow(
		    xzum3eF_filterRows[nrows-1], xzum1aF_tmpbuf, x_dst_siz
		);
		xzum12F_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xzum1aF_tmpbuf
		);
	    }
	    #endif

	} else {

	    /* More than one input row contributes to our output row. */

	    /* Zero a buffer in which to accumulate the contributions */
	    /* of the various input rows:                             */
	    xzum28F_Zero_Float_Buffer( xzum3hF_accumulateRow, x_dst_siz );

	    /* Sum the various pre-x-filtered rows, each weighted */
	    /* by the appropriate value from our y-filter:        */
	    for (fy = 0;   fy < f->n;   fy++) {
		xzum32F_addRow(
		    xzum3hF_accumulateRow,
		    xzum3eF_filterRows[ fy + (nrows-1) - (f->n-1) ],
		    f->weight[fy],
		    x_dst_siz
		);
	    }

	    /* Normalize the results to equivalent of unit weight: */
	    xzum33F_divRow(
		xzum3hF_accumulateRow,xzum16F_dstbuf,f->total_weight,x_dst_siz
	    );

            #ifdef IMPRACTICAL
	    /* Do any needed clamping, then copy to output: */
	    if (clamp) {
		xzum31_clampRow( xzum16_dstbuf, xzum1a_tmpbuf, x_dst_siz );
		xzum12_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xzum1a_tmpbuf
		);
	    } else {
	    #endif
		xzum12F_put_row(
		    dst_pxl, x_dst_max, x_dst_loc, x_dst_siz, y_dst_loc, y_dst,
		    xzum16F_dstbuf
   		);
            #ifdef IMPRACTICAL
            }
	    #endif
        }
    }
}

/* }}} */
/* {{{ xzum31_clampRow	Clamp a rowbuffer to [0,255].			*/

xzum31_clampRow( iptr, optr, n)
short           *iptr,*optr;
int                          n;
{   while (n --> 0) {
	short val = *iptr++;
	if      (val <   0)   *optr++ =   0;
	else if (val > 255)   *optr++ = 255;
	else		      *optr++ = val;
    }
}

/* }}} */
/* {{{ xzum31F_clampRow	Clamp a rowbuffer to [0.0,1.0].			*/

#ifdef IMPRACTICAL
/* This function isn't used because the float arrays */
/* which I'm using don't come in a 0.0->1.0 value    */
/* range, hence we can't clip them safely to any     */
/* such bounds.                                      */
xzum31F_clampRow( iptr, optr, n)
float            *iptr,*optr;
int                           n;
{   while (n --> 0) {
	float val = *iptr++;
	if      (val < 0.0)   *optr++ = (float) 0.0;
	else if (val > 1.0)   *optr++ = (float) 1.0;
	else		      *optr++ = val;
    }
}
#endif

/* }}} */
/* {{{ xzum32_addRow	Add a constant to row while copying it.		*/

xzum32_addRow( iptr, sptr, w, n)
register int  *iptr;
register short      *sptr;
register int               w, n;
{
    while (n --> 0) {
	if (n >= 7) {
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    n -= 7;
	} else {
	    *iptr++ += (w * *sptr++);
	}
    }
}

/* }}} */
/* {{{ xzum32F_addRow	Add a constant to row while copying it.		*/

xzum32F_addRow( iptr, sptr, w, n)
register float *iptr;
register float       *sptr;
register float              w;
register int                   n;
{
    while (n --> 0) {
	if (n >= 7) {
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    *iptr++ += (w * *sptr++);
	    n -= 7;
	} else {
	    *iptr++ += (w * *sptr++);
	}
    }
}

/* }}} */
/* {{{ xzum33_divRow	Divide row by a constant while copying it.	*/

xzum33_divRow( iptr, sptr, tot, n )
register int  *iptr;
register short      *sptr;
register int               tot, n;
{
    while (n --> 0) {
	if (n >= 7) {
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    *sptr++ = (*iptr++) / tot;
	    n -= 7;
	} else {
	    *sptr++ = (*iptr++) / tot;
    }	}
}

/* }}} */
/* {{{ xzum33F_divRow	Divide row by a constant while copying it.	*/

xzum33F_divRow(  iptr, sptr, tot, n )
register float  *iptr;
register float        *sptr;
         float               tot;
register int                      n;
{
    register float tot_inv = 1.0 / tot;
    while (n --> 0) {
	if (n >= 7) {
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    *sptr++ = (*iptr++) * tot_inv;
	    n -= 7;
	} else {
	    *sptr++ = (*iptr++) * tot_inv;
    }	}
}

/* }}} */
/* {{{ xzum34_makeFilter Preprocessed filter for xzum35_applyXFilter.	*/

static void
xzum34_makeFilter(
    FILTER** pFilter,
    int*     pFilterLen,
    short*   srcBuf,
    int	     src_siz,
    int      dst_siz,
    int*     maxN
) {
    FILTER *f, *filter;
    int   x, min, max, n, pos;
    float cover;

    float dstMin, dstMax, dstCent, dstRad;
    float   fMin,   fMax, srcCent, srcRad;
    int   srcMin, srcMax;

    {   /* If our filter doesn't exist, malloc() some ram for it. */
	/* If our filter is too small, realloc() more ram for it. */
	int oldFilterLen = *pFilterLen;
	xzum13_size_buf( pFilter, pFilterLen, dst_siz, sizeof(FILTER) );
	filter = f = *pFilter;

	/* If we created an new FILTER instances, */
	/* mark them as not yet having any weight */
        /* vector allocated:                      */
	if (dst_siz > oldFilterLen) {
	    for (x = oldFilterLen;   x < dst_siz;   x++) f[x].physical_len = 0;
    }   }

    /* Over each individual filter that we are creating: */
    *maxN = 0;
    for (x = 0;   x < dst_siz;   x++) {

	/* Handle magnifying and minifying cases separately: */
	if (dst_siz < src_siz) {

	    /*********************/
	    /* We are minifying. */
	    /*********************/

	    dstRad  = xzum36_filterRadius()/dst_siz;
	    dstCent = ((float)x+0.5)/dst_siz;
	    srcMin  = floor((dstCent-dstRad)*src_siz+EPSILON);
	    srcMax  = floor((dstCent+dstRad)*src_siz-EPSILON);

	    if (srcMin < 0)          srcMin = 0;
	    if (srcMax >= src_siz)   srcMax = src_siz-1;

	    f->n      = 1 + srcMax - srcMin;
	    f->dat    = srcBuf + srcMin;
	    xzum14_Maybe_Re_Alloc_Weight_Vector( f );
	    f->total_weight = 0;

	    for (n = 0;   n < f->n;   n++) {
		dstMin  = dst_siz*((((float)srcMin +n   )/src_siz) - dstCent);
		dstMax  = dst_siz*((((float)srcMin +n +1)/src_siz) - dstCent);
		cover = (
		    xzum38_filterIntegrate( dstMax, 1 ) -
		    xzum38_filterIntegrate( dstMin, 0 )
		);  
		f->weight[n] = (ONE*cover)+0.5;
		f->total_weight += f->weight[n];
	    }

	} else {

	    /**********************/
	    /* We are magnifying. */
	    /**********************/

	    /* Filter radius will normally be a pixel or  */
	    /* two; express it as a fraction of src rect: */
	    srcRad = xzum36_filterRadius()/src_siz;

	    /* Express current pixel-width of interest */
	    /* in 0 -> 1 parametric coords relative to */
	    /* complete output range of interest:      */
	    dstMin = ((float)x    )/dst_siz;
	    dstMax = ((float)x+1.0)/dst_siz;

	    /* Express the image of above pixel on src */
	    /* rectangle in 0 -> 1 parametric coords   */
	    /* relative to complete input rectangle:   */
	    srcMin = floor((dstMin-srcRad)*src_siz+0.5+EPSILON);
	    srcMax = floor((dstMax+srcRad)*src_siz-0.5-EPSILON);

	    /* Clip above image to edges of image, */
	    /* if it extends beyond it:            */
	    if (srcMin < 0)          srcMin = 0;
	    if (srcMax >= src_siz)   srcMax = src_siz-1;

	    /* Build a filter with one weight for  */
	    /* each pixel actually present:        */

	    /* Compute and remember number of weights */
	    /* needed for this particular filter.  We */
	    /* need one for each input pixel present: */
	    f->n      = 1 + srcMax - srcMin;

	    /* Compute pointer into input row buffer  */
	    /* corresponding to first weight:         */
	    f->dat    = srcBuf + srcMin;

	    /* Ensure our weight vector is long enough: */
	    xzum14_Maybe_Re_Alloc_Weight_Vector( f );

	    /* Compute each weight vector entry: */
	    f->total_weight = 0;
	    for (n = 0;   n < f->n;   n++) {

		srcCent = (srcMin+n+0.5) / src_siz;
		fMin  = src_siz*(dstMin-srcCent);
		fMax  = src_siz*(dstMax-srcCent);
		cover = (
		    xzum38_filterIntegrate( fMax, 1 ) -
		    xzum38_filterIntegrate( fMin, 0 )
		);
		f->weight[n]  = (ONE*cover)+0.5;

		f->total_weight += f->weight[n];
	    }
	}
	if (f->n > *maxN)   *maxN = f->n;
	f++;
    }
}

/* }}} */
/* {{{ xzum34F_makeFilter Preprocessed filter for xzum35_applyXFilter.	*/

static void
xzum34F_makeFilter(
    FLOAT_FILTER** pFilter,
    int*     pFilterLen,
    float*   srcBuf,
    int	     src_siz,
    int      dst_siz,
    int*     maxN
) {
    FLOAT_FILTER *f, *filter;
    int   x, min, max, n, pos;
    float cover;

    float dstMin, dstMax, dstCent, dstRad;
    float   fMin,   fMax, srcCent, srcRad;
    int   srcMin, srcMax;

    {   /* If our filter doesn't exist, malloc() some ram for it. */
	/* If our filter is too small, realloc() more ram for it. */
	int oldFilterLen = *pFilterLen;
	xzum13_size_buf( pFilter, pFilterLen, dst_siz, sizeof(FLOAT_FILTER) );
	filter = f = *pFilter;

	/* If we created an new FILTER instances, */
	/* mark them as not yet having any weight */
        /* vector allocated:                      */
	if (dst_siz > oldFilterLen) {
	    for (x = oldFilterLen;   x < dst_siz;   x++) f[x].physical_len = 0;
    }   }

    /* Over each individual filter that we are creating: */
    *maxN = 0;
    for (x = 0;   x < dst_siz;   x++) {

	/* Handle magnifying and minifying cases separately: */
	if (dst_siz < src_siz) {

	    /*********************/
	    /* We are minifying. */
	    /*********************/

	    dstRad  = xzum36_filterRadius()/dst_siz;
	    dstCent = ((float)x+0.5)/dst_siz;
	    srcMin  = floor((dstCent-dstRad)*src_siz+EPSILON);
	    srcMax  = floor((dstCent+dstRad)*src_siz-EPSILON);

	    if (srcMin < 0)          srcMin = 0;
	    if (srcMax >= src_siz)   srcMax = src_siz-1;

	    f->n      = 1 + srcMax - srcMin;
	    f->dat    = srcBuf + srcMin;
	    xzum14F_Maybe_Re_Alloc_Weight_Vector( f );
	    f->total_weight = (float) 0.0;

	    for (n = 0;   n < f->n;   n++) {
		dstMin  = dst_siz*((((float)srcMin +n   )/src_siz) - dstCent);
		dstMax  = dst_siz*((((float)srcMin +n +1)/src_siz) - dstCent);
		cover = (
		    xzum38_filterIntegrate( dstMax, 1 ) -
		    xzum38_filterIntegrate( dstMin, 0 )
		);  
		f->weight[n] = cover;
		f->total_weight += f->weight[n];
	    }

	} else {

	    /**********************/
	    /* We are magnifying. */
	    /**********************/

	    /* Filter radius will normally be a pixel or  */
	    /* two; express it as a fraction of src rect: */
	    srcRad = xzum36_filterRadius()/src_siz;

	    /* Express current pixel-width of interest */
	    /* in 0 -> 1 parametric coords relative to */
	    /* complete output range of interest:      */
	    dstMin = ((float)x    )/dst_siz;
	    dstMax = ((float)x+1.0)/dst_siz;

	    /* Express the image of above pixel on src */
	    /* rectangle in 0 -> 1 parametric coords   */
	    /* relative to complete input rectangle:   */
	    srcMin = floor((dstMin-srcRad)*src_siz+0.5+EPSILON);
	    srcMax = floor((dstMax+srcRad)*src_siz-0.5-EPSILON);

	    /* Clip above image to edges of image, */
	    /* if it extends beyond it:            */
	    if (srcMin < 0)          srcMin = 0;
	    if (srcMax >= src_siz)   srcMax = src_siz-1;

	    /* Build a filter with one weight for  */
	    /* each pixel actually present:        */

	    /* Compute and remember number of weights */
	    /* needed for this particular filter.  We */
	    /* need one for each input pixel present: */
	    f->n      = 1 + srcMax - srcMin;

	    /* Compute pointer into input row buffer  */
	    /* corresponding to first weight:         */
	    f->dat    = srcBuf + srcMin;

	    /* Ensure our weight vector is long enough: */
	    xzum14F_Maybe_Re_Alloc_Weight_Vector( f );

	    /* Compute each weight vector entry: */
	    f->total_weight = (float) 0.0;
	    for (n = 0;   n < f->n;   n++) {

		srcCent = (srcMin+n+0.5) / src_siz;
		fMin  = src_siz*(dstMin-srcCent);
		fMax  = src_siz*(dstMax-srcCent);
		cover = (
		    xzum38_filterIntegrate( fMax, 1 ) -
		    xzum38_filterIntegrate( fMin, 0 )
		);
		f->weight[n]  = cover;
		f->total_weight += f->weight[n];
	    }
	}
	if (f->n > *maxN)   *maxN = f->n;
	f++;
    }
}

/* }}} */
/* {{{ xzum35_applyXFilter Filter a row by preprocessed filter.		*/

xzum35_applyXFilter( dstbuf, xfilt, x_dst_siz )
register short      *dstbuf;
register FILTER             *xfilt;
register int                        x_dst_siz;
{
    register short *w;
    register short *dptr;
    register int    n;
    register int    val;

    while (x_dst_siz --> 0) {
	if ((n = xfilt->n) == 1) {
	    *dstbuf++ = *xfilt->dat;
	} else {
	    w    = xfilt->weight;
	    dptr = xfilt->dat;
	    val  = 0;
	    n    = xfilt->n;
	    while (n --> 0)   val += *w++ * *dptr++;
	    *dstbuf++ = val / xfilt->total_weight;
	}
	xfilt++;
    }
}

/* }}} */
/* {{{ xzum35F_applyXFilter Filter a row by preprocessed filter.	*/

xzum35F_applyXFilter( dstbuf, xfilt, x_dst_siz )
register float       *dstbuf;
register FLOAT_FILTER        *xfilt;
register int                         x_dst_siz;
{
    register float *w;
    register float *dptr;
    register int    n;
    register float  val;

    while (x_dst_siz --> 0) {
	if ((n = xfilt->n) == 1) {
	    *dstbuf++ = *xfilt->dat;
	} else {
	    w    = xfilt->weight;
	    dptr = xfilt->dat;
	    val  = 0.0;
	    n    = xfilt->n;
	    while (n --> 0)   val += *w++ * *dptr++;
	    *dstbuf++ = val / xfilt->total_weight;
	}
	xfilt++;
    }
}

/* }}} */
/* {{{ xzum36_filterRadius Compute appropriate radius for selected filter.  */

float xzum36_filterRadius()
{
    switch(filtershape) {
    case BOX:	    return 0.5 * blurfactor;
    case TRIANGLE:  return 1.0 * blurfactor;
    case QUADRATIC: return 1.0 * blurfactor;
    case MITCHELL:  return 2.0 * blurfactor;
    default:
	abort();
    }
}

/* }}} */
/* {{{ xzum37_QuadraticIntegrate Compute area under part of QUADRATIC filter*/

float xzum37_QuadraticIntegrate( x )
float                            x; /* x <= 0.0 */
{
    if (x < -1.0)   return 0.0;
    if (x < -0.5)   return 2.0*((1.0/3.0)*(x*x*x+1.0) + x*x + x);
    else            return     -(2.0/3.0)* x*x*x + x + 0.5;
}

/* }}} */
/* {{{ xzum38_filterIntegrate Compute area under part of selected filter.   */

float xzum38_filterIntegrate( x, side )
float                         x;
int                              side;
{
    /* Return the integral from -INFINITY to x of the       */
    /* selected filter function.  By taking the difference  */
    /* of this value at either end of a closed interval, we */
    /* can determine the weight to assign to that interval  */
    /* in our descrete transform.                           */
    float val;

    x = x / blurfactor;

    switch(filtershape) {

    case BOX:
        /* Canonical boxfilter is unit area squarewave */
	/* at [-0.5, 0.5], zero elsewhere:             */
	if      (x < -0.5)   return   0.0;
	else if (x >  0.5)   return   1.0;
	else		     return x+0.5;

    case TRIANGLE:
        /* Canonical triangular filter is unit area    */
	/* triangle at [-1.0, 1.0], zero elsewhere:    */
	if      (x < -1.0)	    return 0.0;
	else if (x >  1.0)	    return 1.0;
	else if (x <  0.0) {
	    val = x+1.0;
	    return 0.5 * val * val;
	} else {
	    val = 1.0 - x;
	    return 1.0 - 0.5 * val * val;
	}

    case QUADRATIC:
	/* The 'quadratic' may be a cubic approximation */
	/* to a guassian, nonzero on [-1.0, 1.0]:       */
	if (x < 0.0)   return       xzum37_QuadraticIntegrate( x);
	else           return 1.0 - xzum37_QuadraticIntegrate(-x);

    case MITCHELL:
	/* This looks like maybe a still better approximation */
        /* to a gaussian, nonzero on [-2.0, 2.0].             */
	if (side == 0)   return 0.0;
	return xzum50_mitchell(x);
    }
    abort();
}

/* }}} */
/* {{{ xzum50_mitchell Compute area under part of MITCHELL filter.	*/

static float p0, p2, p3, q0, q1, q2, q3;

/*
 * see Mitchell&Netravali, "Reconstruction Filters in Computer Graphics",
 * SIGGRAPH 88.  Mitchell code provided by Paul Heckbert.
 */
float xzum50_mitchell(x)	/* Mitchell & Netravali's two-param cubic */
float                 x;
{
    static int firsted;

    if(!firsted) {
	xzum60_mitchellInit( 1.0/3.0, 1.0/3.0 );
	firsted = 1;
    }
    if (x <-2.) return 0.0;
    if (x <-1.) return 2.0*(q0-x*(q1-x*(q2-x*q3)));
    if (x < 0.) return 2.0*(p0+x*x*    (p2-x*p3)) ;
    if (x < 1.) return 2.0*(p0+x*x*    (p2+x*p3)) ;
    if (x < 2.) return 2.0*(q0+x*(q1+x*(q2+x*q3)));
    return 0.0;
}

/* }}} */
/* {{{ xzum60_mitchellInit Initialize some constants used xzum50_mitchell.*/

xzum60_mitchellInit( b, c )
float                b, c;
{
    p0 = (  6. -  2.*b        ) / 6.;
    p2 = (-18. + 12.*b +  6.*c) / 6.;
    p3 = ( 12. -  9.*b -  6.*c) / 6.;
    q0 = (	  8.*b + 24.*c) / 6.;
    q1 = (     - 12.*b - 48.*c) / 6.;
    q2 = (	  6.*b + 30.*c) / 6.;
    q3 = (     -     b -  6.*c) / 6.;
}
/* }}} */

/* {{{ xzum71_clampRow	Clamp a rowbuffer to [0,4095].			*/

static void
xzum71_clampRow(
    short* row,
    int    n
) {
    while (n --> 0) {
	short val = *row;
	if ((unsigned short)val > 4095) {
	    if (val > 4095)  *row = 4095;
	    else             *row =    0;
	}
	++row;
    }
}

/* }}} */
/* {{{ xzum75_VoxelZoom_Init To magnify/minify voxels by 1-Dconvolution.*/

void
xzum75_VoxelZoom_Init(
    int  dst_siz, /* Dst row size in voxels.	*/
    int  src_siz, /* Src row size  in pixels.	*/
    LVAL shape
) {
    int nrows;

    /* Translate filtershape from symbol to int const: */
    xzum03_Set_Filtershape( shape );

    /* Make sure our temporary buffers are big enough: */

    /* A buffer to hold the current input line: */
    xzum13_size_buf(&xzum14_srcbuf, &xzum15_srcbuf_len, src_siz, sizeof(short));

    /* Allocate a temporary buffer big enough to hold */
    /* prefiltered versions of all the input rows     */
    /* contributing to any one output row.  That is,  */
    /* for a 3x3 convolution kernel, we'll need to    */
    /* buffer three full x-filtered input rows:       */
    xzum29_Maybe_Resize_FilterRows(
	/* needed_rows: */ 1,
	/* needed_cols: */ dst_siz
    );

    /* A temp buf for clamping, if needed: */
    xzum13_size_buf(&xzum1a_tmpbuf, &xzum1b_tmpbuf_len, dst_siz, sizeof(short));

    /* Construct appropriate filter: */
    xzum34_makeFilter(
	&xzum3a_xFilter, &xzum3b_xFilter_len,
        xzum14_srcbuf, src_siz, dst_siz, &nrows
    );
}

/* }}} */
/* {{{ xzum78_VoxelZoom_Row  To magnify/minify voxels by 1-Dconvolution.*/

void
xzum78_VoxelZoom_Row(
    short*       vox_out,
    short*       vox_in,
    int          dst_siz,	/* Dst row size in voxels.	 */
    int          src_siz,	/* Src row size in pixels.	 */
    int          clamp		/* TRUE iff filter yields vals	 */
) {				/* outside of input 0-4095 range.*/
    /* Copy input voxels to xzum14_srcbuf, */
    /* mostly because filter fn has buffer */
    /* loc hardwired:                      */
    {   short* src = vox_in;
	short* dst = xzum14_srcbuf;
	int    i   = src_siz;
	while (i --> 0)   *dst++ = *src++;
    }

    /* Filter from srcbuf to filterRow buffer: */
    xzum35_applyXFilter(
	xzum3e_filterRows[0], xzum3a_xFilter, dst_siz
    );

    /* If filter can produce out-of-range vals, */
    /* clamp buffer to valid 12-bit range:      */
    if (clamp) xzum71_clampRow( xzum3e_filterRows[0], dst_siz );

    /* Copy buffer to output row: */
    {   short* src = xzum3e_filterRows[0];
	short* dst = vox_out;
	int    i   = dst_siz;
	while (i --> 0)   *dst++ = *src++;
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
