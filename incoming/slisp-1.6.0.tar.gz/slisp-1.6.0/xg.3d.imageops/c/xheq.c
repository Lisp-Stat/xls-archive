/* {{{ xheq.h -- Histogram equalization on 8-bit images.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jun01
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Jun01 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

#include "../../xg.3d/c/csry.h"

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xheq08_Equalize_Histogram_Msg					*/

xheq07_Get_X_And_Y_Dimensions( px, py, lv )
int                           *px,*py;
LVAL                                   lv;
{   csry_rec* h = (csry_rec*) gobjimmbase( lv );
    if (h->rank != 2)  xlerror("Image array not 2-D!",lv);
    *py = h->dim[0];
    *px = h->dim[1];
}
LVAL xheq08_Equalize_Histogram_Msg() {
    extern LVAL xf8v04_Get_A_XF8V();
    extern LVAL k_addnoise;

    int  addnoise = FALSE;
    int  x_siz;
    int  y_siz;
    LVAL lv_us = NIL;

    unsigned char* mat;

    /* Read our arguments: */

    lv_us = xf8v04_Get_A_XF8V();
    xheq07_Get_X_And_Y_Dimensions( &x_siz, &y_siz, lv_us );

    /* Scan optional paramters: */
    while (moreargs()) {

	LVAL key = xlgasymbol();

	if        (key == k_addnoise) {

	    addnoise = !null(xlgetarg());

	} else {

	    xlerror("Bad :EQUALIZE-HISTOGRAM keyword",key);
    }	}

    mat = (unsigned char*) (csry_base( lv_us ));

    xheq20_equalizeHistogram( mat, x_siz * y_siz );

    return NIL;
}

/* }}} */
/* {{{ xheq18_Equalize_Histogram_Relation_Msg				*/

LVAL xheq18_Equalize_Histogram_Relation_Msg() {
    extern LVAL xgrl01_Get_A_XGRL();
    extern LVAL k_addnoise;

    int  addnoise = FALSE;
    int  x_siz;
    int  y_siz;
    LVAL lv_us = NIL;

    unsigned char* mat;

    /* Read our arguments: */

    lv_us = xgrl01_Get_A_XGRL();
    xheq07_Get_X_And_Y_Dimensions( &x_siz, &y_siz, lv_us );

    /* Scan optional paramters: */
    while (moreargs()) {

	LVAL key = xlgasymbol();

	if        (key == k_addnoise) {

	    addnoise = !null(xlgetarg());

	} else {

	    xlerror("Bad :EQUALIZE-HISTOGRAM keyword",key);
    }	}


    /* Process red/grn/blu image-plane arrays in our graphic relation: */
    {   LVAL lv_red, lv_green, lv_blue;

	int  src_planes = xthl3a_GetPixelRedGreenBlueIfPresent(
	    &lv_red,&lv_green,&lv_blue, lv_us
	);

	if (lv_red  ) {
	    mat = (unsigned char*) (csry_base( lv_red   ));
	    xheq20_equalizeHistogram( mat, x_siz * y_siz );
	}
	if (lv_green) {
	    mat = (unsigned char*) (csry_base( lv_green ));
	    xheq20_equalizeHistogram( mat, x_siz * y_siz );
	}
	if (lv_blue ) {
	    mat = (unsigned char*) (csry_base( lv_blue  ));
	    xheq20_equalizeHistogram( mat, x_siz * y_siz );
	}
    }

    return NIL;
}

/* }}} */
/* {{{ xheq20_equalizeHistogram						*/

xheq20_equalizeHistogram( mat, siz, addnoise )
unsigned char *           mat;
int			       siz, addnoise;
{
    /* This is a simple transform which basically improves the human */
    /* visible contrast in an image. Digital Image Processing, by    */
    /* Gonzalez and Wintz, discusses this (sec 4.2.2), for example.  */
    /* The idea is to take an image in which the pixel values tend to*/
    /* cluster in too narrow a range of value for the human eye to   */
    /* comfortably distinguish, and remap it so that (ideally) all   */
    /* pixel values are equally used in the image.                   */

    int map[256];
    int i;
    int	sum;	
    int	area;	

    /* Clear our count of pixel values: */
    for (i = 256;   i --> 0;   )     map[i] = 0;

    /* Count number of pixels with each possible value: */
    for (i = siz;   i --> 0;   )   ++map[mat[i]];

    /* Rescale histogram: */
    sum  = siz;
    area = 0;
    for (i = 0;   i < 256;   ++i) {
	int old_val = map[i];
	map[i] = (area*255.0) / sum;
	area += old_val;
    }

    if (!addnoise) {
        for (i = siz;   i --> 0; )   mat[i] = map[ mat[i] ];
    } else {
        for (i = siz;   i --> 0; ) {
	    int this        = mat[   i  ];
	    int mapped_this = map[ this ];
	    int next        = (this < 255)   ?   map[ this +1 ]   :   255;
	    int span        = next - mapped_this;

	    if (span)   mapped_this += random() % span;

	    mat[i] = mapped_this;
    }	}
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
