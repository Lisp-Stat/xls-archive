/* {{{ xrsz.h -- Image zooming -- magnify/minify.		     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92May26
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
extern LVAL xrsz08_Resize_Image_Msg(   );
extern LVAL xrsz95_Resize_Relation_Msg();

#ifndef EXTERNED_FROM
extern LVAL k_from;   /* Keyword ":FROM" */
#define EXTERNED_FROM
#endif

#ifndef EXTERNED_BLURFACTOR
extern LVAL k_blurfactor;   /* Keyword ":blur-factor" */
#define EXTERNED_BLURFACTOR
#endif

#ifndef EXTERNED_FILTERSHAPE
extern LVAL k_filtershape;   /* Keyword ":filter-shape" */
#define EXTERNED_FILTERSHAPE
#endif

#ifndef EXTERNED_IMPULSE
extern LVAL k_impulse;   /* Keyword ":impulse" */
#define EXTERNED_IMPULSE
#endif

#ifndef EXTERNED_TRIANGLE
extern LVAL k_triangle;   /* Keyword ":triangle" */
#define EXTERNED_TRIANGLE
#endif

#ifndef EXTERNED_BOX
extern LVAL k_box;   /* Keyword ":box" */
#define EXTERNED_BOX
#endif

#ifndef EXTERNED_QUADRATIC
extern LVAL k_quadratic;   /* Keyword ":quadratic" */
#define EXTERNED_QUADRATIC
#endif

#ifndef EXTERNED_MITCHELL
extern LVAL k_mitchell;   /* Keyword ":mitchell" */
#define EXTERNED_MITCHELL
#endif

#ifndef EXTERNED_XSRCLOC
extern LVAL k_xsrcloc;   /* Keyword ":x-src-loc" */
#define EXTERNED_XSRCLOC
#endif

#ifndef EXTERNED_YSRCLOC
extern LVAL k_ysrcloc;   /* Keyword ":y-src-loc" */
#define EXTERNED_YSRCLOC
#endif

#ifndef EXTERNED_XSRCSIZ
extern LVAL k_xsrcsiz;   /* Keyword ":x-src-siz" */
#define EXTERNED_XSRCSIZ
#endif

#ifndef EXTERNED_YSRCSIZ
extern LVAL k_ysrcsiz;   /* Keyword ":y-src-siz" */
#define EXTERNED_YSRCSIZ
#endif



#ifndef EXTERNED_XDSTLOC
extern LVAL k_xdstloc;   /* Keyword ":x-dst-loc" */
#define EXTERNED_XDSTLOC
#endif

#ifndef EXTERNED_YDSTLOC
extern LVAL k_ydstloc;   /* Keyword ":y-dst-loc" */
#define EXTERNED_YDSTLOC
#endif

#ifndef EXTERNED_XDSTSIZ
extern LVAL k_xdstsiz;   /* Keyword ":x-dst-siz" */
#define EXTERNED_XDSTSIZ
#endif

#ifndef EXTERNED_YDSTSIZ
extern LVAL k_ydstsiz;   /* Keyword ":y-dst-siz" */
#define EXTERNED_YDSTSIZ
#endif

#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	NULL,				xrsz08_Resize_Image_Msg		)
DEFINE_SUBR(	NULL,				xrsz95_Resize_Relation_Msg	)
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS


#ifndef DEFINED_BLURFACTOR
LVAL k_blurfactor;   /* Keyword ":blur-factor" */
#define DEFINED_BLURFACTOR
#endif

#ifndef DEFINED_FILTERSHAPE
LVAL k_filtershape;   /* Keyword ":filter-shape" */
#define DEFINED_FILTERSHAPE
#endif

#ifndef DEFINED_IMPULSE
LVAL k_impulse;   /* Keyword ":impulse" */
#define DEFINED_IMPULSE
#endif

#ifndef DEFINED_TRIANGLE
LVAL k_triangle;   /* Keyword ":triangle" */
#define DEFINED_IMPULSE
#endif

#ifndef DEFINED_BOX
LVAL k_box;   /* Keyword ":box" */
#define DEFINED_BOX
#endif

#ifndef DEFINED_QUADRATIC
LVAL k_quadratic;   /* Keyword ":quadratic" */
#define DEFINED_QUADRATIC
#endif

#ifndef DEFINED_MITCHELL
LVAL k_mitchell;   /* Keyword ":mitchell" */
#define DEFINED_MITCHELL
#endif

#ifndef DEFINED_FROM
LVAL k_from;   /* Keyword ":FROM" */
#define DEFINED_FROM
#endif

#ifndef DEFINED_XSRCLOC
LVAL k_xsrcloc;   /* Keyword ":x-src-loc" */
#define DEFINED_XSRCLOC
#endif

#ifndef DEFINED_YSRCLOC
LVAL k_ysrcloc;   /* Keyword ":y-src-loc" */
#define DEFINED_YSRCLOC
#endif

#ifndef DEFINED_XSRCSIZ
LVAL k_xsrcsiz;   /* Keyword ":x-src-siz" */
#define DEFINED_XSRCSIZ
#endif

#ifndef DEFINED_YSRCSIZ
LVAL k_ysrcsiz;   /* Keyword ":y-src-siz" */
#define DEFINED_YSRCSIZ
#endif


#ifndef DEFINED_XDSTLOC
LVAL k_xdstloc;   /* Keyword ":x-dst-loc" */
#define DEFINED_XDSTLOC
#endif

#ifndef DEFINED_YDSTLOC
LVAL k_ydstloc;   /* Keyword ":y-dst-loc" */
#define DEFINED_YDSTLOC
#endif

#ifndef DEFINED_XDSTSIZ
LVAL k_xdstsiz;   /* Keyword ":x-dst-siz" */
#define DEFINED_XDSTSIZ
#endif

#ifndef DEFINED_YDSTSIZ
LVAL k_ydstsiz;   /* Keyword ":y-dst-siz" */
#define DEFINED_YDSTSIZ
#endif

LOCAL struct xrsz_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xrsz_xf8v_table[] = {
    {	":NEW-RESIZE-IMAGE",	xrsz08_Resize_Image_Msg        	},

    {	NULL,			NULL	                	}
};
LOCAL struct xrsz_message2 {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xrsz_xgrl_table[] = {
    {	":NEW-RESIZE-IMAGE",	xrsz95_Resize_Relation_Msg     	},

    {	NULL,			NULL	                	}
};
#endif

#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_BLURFACTOR
    k_blurfactor = xlenter(":BLUR-FACTOR");
#define CREATED_BLURFACTOR
#endif

#ifndef CREATED_FILTERSHAPE
    k_filtershape = xlenter(":FILTER-SHAPE");
#define CREATED_FILTERSHAPE
#endif

#ifndef CREATED_IMPULSE
    k_impulse = xlenter(":IMPULSE");
#define CREATED_IMPULSE
#endif

#ifndef CREATED_TRIANGLE
    k_triangle = xlenter(":TRIANGLE");
#define CREATED_TRIANGLE
#endif

#ifndef CREATED_BOX
    k_box = xlenter(":BOX");
#define CREATED_BOX
#endif

#ifndef CREATED_QUADRATIC
    k_quadratic = xlenter(":QUADRATIC");
#define CREATED_QUADRATIC
#endif

#ifndef CREATED_MITCHELL
    k_mitchell = xlenter(":MITCHELL");
#define CREATED_MITCHELL
#endif

#ifndef CREATED_FROM
    k_from = xlenter(":FROM");
#define CREATED_FROM
#endif

#ifndef CREATED_XSRCLOC
    k_xsrcloc = xlenter(":X-SRC-LOC");
#define CREATED_XSRCLOC
#endif

#ifndef CREATED_YSRCLOC
    k_ysrcloc = xlenter(":Y-SRC-LOC");
#define CREATED_YSRCLOC
#endif

#ifndef CREATED_XSRCSIZ
    k_xsrcsiz = xlenter(":X-SRC-SIZ");
#define CREATED_XSRCSIZ
#endif

#ifndef CREATED_YSRCSIZ
    k_ysrcsiz = xlenter(":Y-SRC-SIZ");
#define CREATED_YSRCSIZ
#endif

#ifndef CREATED_XDSTLOC
    k_xdstloc = xlenter(":X-DST-LOC");
#define CREATED_XDSTLOC
#endif

#ifndef CREATED_YDSTLOC
    k_ydstloc = xlenter(":Y-DST-LOC");
#define CREATED_YDSTLOC
#endif

#ifndef CREATED_XDSTSIZ
    k_xdstsiz = xlenter(":X-DST-SIZ");
#define CREATED_XDSTSIZ
#endif

#ifndef CREATED_YDSTSIZ
    k_ydstsiz = xlenter(":Y-DST-SIZ");
#define CREATED_YDSTSIZ
#endif

#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
    xgbj56_Enter_Messages( lv_xf8v,  xrsz_xf8v_table );
    xgbj56_Enter_Messages( lv_xgrl,  xrsz_xgrl_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
