/* {{{ xpwb.c -- Procedural World Building.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94Apr16
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 94Apr16 CrT: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  

#include "../../xcore/c/xlisp.h"

#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/cthl.h"

extern LVAL k_facet0;
extern LVAL k_facet1;
extern LVAL k_facet2;
extern LVAL k_facet3;
extern LVAL k_facetnormalx;
extern LVAL k_facetnormaly;
extern LVAL k_facetnormalz;
extern LVAL k_facetrelation;
extern LVAL k_maxx;
extern LVAL k_maxy;
extern LVAL k_maxz;
extern LVAL k_minx;
extern LVAL k_miny;
extern LVAL k_minz;
extern LVAL k_pointrelation;
extern LVAL k_pointx;
extern LVAL k_pointy;
extern LVAL k_pointz;
extern LVAL k_thing;
extern LVAL k_generator;
extern LVAL k_camera;

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xpwbG2_Insert_Terrain_Fn -- Insert terrain in grlpair.		*/

LVAL xpwbG1_Insert_Terrain(
    point_grl, /* Points     grl */
    facet_grl, /* Rectangles grl */

    xmin, xmax,
    ymin, ymax,
    zmin, zmax
)
    LVAL    facet_grl, point_grl;
    FLOTYPE xmin, xmax;
    FLOTYPE ymin, ymax;
    FLOTYPE zmin, zmax;
{
    /***********************************************************/
    /* Track down the component arrays we need from our grls.  */
    /***********************************************************/
    csry_rec*h_pntGrl = (csry_rec*) gobjimmbase( point_grl );
  
    LVAL*p_pArrayList = (LVAL *) xgrl13_pArrayList( point_grl );
    LVAL*f_pArrayList = (LVAL *) xgrl13_pArrayList( facet_grl );

    LVAL lv_point_x   = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointx );
    LVAL lv_point_y   = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointy );
    LVAL lv_point_z   = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointz );

    float*  point_x;
    float*  point_y;
    float*  point_z;

    LVAL lv_facet_0   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facet0 );
    LVAL lv_facet_1   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facet1 );
    LVAL lv_facet_2   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facet2 );
    LVAL lv_facet_3   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facet3 );

    int  *  facet_0;
    int  *  facet_1;
    int  *  facet_2;
    int  *  facet_3;

    LVAL lv_norml_x   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facetnormalx );
    LVAL lv_norml_y   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facetnormaly );
    LVAL lv_norml_z   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facetnormalz );

    float*  norml_x;
    float*  norml_y;
    float*  norml_z;

    int  oldPointSz;
    int  oldFacetSz;

    int  pointsNeeded = 8;
#if WANT_BACKFACE
    int  facetsNeeded = 6;
#else
    int  facetsNeeded = 5;
#endif

    FLOTYPE Xmin, Xmax;
    FLOTYPE Ymin, Ymax;
    FLOTYPE thickness;

    int  b;  /* Base index of point array. */


    /* Sanity checks to keep user honest: */

    xthlEe_Error_If_Not_Rank_1( point_grl, point_grl );
    xthlEe_Error_If_Not_Rank_1( facet_grl, facet_grl );

    xthlEc_Error_If_Not_FloatVector( lv_point_x, k_pointx );
    xthlEc_Error_If_Not_FloatVector( lv_point_y, k_pointy );
    xthlEc_Error_If_Not_FloatVector( lv_point_z, k_pointz );

    xthlEd_Error_If_Not_Int32Vector( lv_facet_0, k_facet0 );
    xthlEd_Error_If_Not_Int32Vector( lv_facet_1, k_facet1 );
    xthlEd_Error_If_Not_Int32Vector( lv_facet_2, k_facet2 );
    xthlEd_Error_If_Not_Int32Vector( lv_facet_3, k_facet3 );

    xthlEc_Error_If_Not_FloatVector( lv_norml_x, k_facetnormalx );
    xthlEc_Error_If_Not_FloatVector( lv_norml_y, k_facetnormaly );
    xthlEc_Error_If_Not_FloatVector( lv_norml_z, k_facetnormalz );

    if (xmin > xmax) {FLOTYPE f = xmin; xmin = xmax; xmax = f; }
    if (ymin > ymax) {FLOTYPE f = ymin; ymin = ymax; ymax = f; }
    if (zmin > zmax) {FLOTYPE f = zmin; zmin = zmax; zmax = f; }

    oldPointSz = xthlEf_Resize_Grl( point_grl, pointsNeeded );
    oldFacetSz = xthlEf_Resize_Grl( facet_grl, facetsNeeded );
    b = oldPointSz;


    /* Grab hard pointers to the relevant facet and point arrays: */

    facet_0     = ((int  *) csry_base( lv_facet_0 )) + oldFacetSz;
    facet_1     = ((int  *) csry_base( lv_facet_1 )) + oldFacetSz;
    facet_2     = ((int  *) csry_base( lv_facet_2 )) + oldFacetSz;
    facet_3     = ((int  *) csry_base( lv_facet_3 )) + oldFacetSz;

    point_x     = ((float*) csry_base( lv_point_x )) + oldPointSz;
    point_y     = ((float*) csry_base( lv_point_y )) + oldPointSz;
    point_z     = ((float*) csry_base( lv_point_z )) + oldPointSz;

    norml_x     = ((float*) csry_base( lv_norml_x )) + oldPointSz;
    norml_y     = ((float*) csry_base( lv_norml_y )) + oldPointSz;
    norml_z     = ((float*) csry_base( lv_norml_z )) + oldPointSz;



    /* Figure x-y corners of near face from those of far face,	*/
    /* by constructing a 45 degree bevel:			*/
    thickness	= zmax - zmin;
    Xmin	= xmin + thickness;
    Xmax	= xmax - thickness;
    Ymin	= ymin + thickness;
    Ymax	= ymax - thickness;



    /* Deposit the new points, counterclockwise from lower-left, front then back: */

    *point_x++  = Xmin;   *point_y++ = Ymin;   *point_z++ = zmin;
    *point_x++  = Xmax;   *point_y++ = Ymin;   *point_z++ = zmin;
    *point_x++  = Xmax;   *point_y++ = Ymax;   *point_z++ = zmin;
    *point_x++  = Xmin;   *point_y++ = Ymax;   *point_z++ = zmin;

    *point_x++  = xmin;   *point_y++ = ymin;   *point_z++ = zmax;
    *point_x++  = xmax;   *point_y++ = ymin;   *point_z++ = zmax;
    *point_x++  = xmax;   *point_y++ = ymax;   *point_z++ = zmax;
    *point_x++  = xmin;   *point_y++ = ymax;   *point_z++ = zmax;



    /* Deposit the new facets, near then counterclockwise from bottom: */

    *facet_0++  = b+0;   *facet_1++ = b+1;   *facet_2++ = b+2;   *facet_3++ = b+3;

    *facet_0++  = b+0;   *facet_1++ = b+4;   *facet_2++ = b+5;   *facet_3++ = b+1;
    *facet_0++  = b+1;   *facet_1++ = b+5;   *facet_2++ = b+6;   *facet_3++ = b+2;
    *facet_0++  = b+2;   *facet_1++ = b+6;   *facet_2++ = b+7;   *facet_3++ = b+3;
    *facet_0++  = b+3;   *facet_1++ = b+7;   *facet_2++ = b+4;   *facet_3++ = b+0;

#if WANT_BACKFACE
    *facet_0++  = b+7;   *facet_1++ = b+6;   *facet_2++ = b+5;   *facet_3++ = b+4;
#endif



    /* Deposit the facet normals, same order as facets: */
#define IR2 (0.707107)
    *norml_x++  =  0.0;   *norml_y++ =  0.0;   *norml_z++ = -1.0;

    *norml_x++  =  0.0;   *norml_y++ = -IR2;   *norml_z++ = -IR2;
    *norml_x++  =  IR2;   *norml_y++ =  0.0;   *norml_z++ = -IR2;
    *norml_x++  =  0.0;   *norml_y++ =  IR2;   *norml_z++ = -IR2;
    *norml_x++  =  IR2;   *norml_y++ =  0.0;   *norml_z++ = -IR2;

#if WANT_BACKFACE
    *norml_x++  =  0.0;   *norml_y++ =  0.0;   *norml_z++ =  1.0;
#endif
#undef IR2


    return NIL;
}

LVAL xpwbG2_Insert_Terrain_Fn()
{
    LVAL lv_point_grl = NIL;
    LVAL lv_rects_grl = NIL;

    FLOTYPE minx   = - 8.0;
    FLOTYPE maxx   =   8.0;

    FLOTYPE miny   =  -6.0;
    FLOTYPE maxy   =   6.0;

    FLOTYPE minz   =  -1.0;
    FLOTYPE maxz   =   1.0;

    while (moreargs()) {
        LVAL key = xlgasymbol();
        if (key == k_thing) {

	    LVAL lv_thing = xlgacons();
	    lv_point_grl = xthl74_GetProp(
		&lv_thing,
		k_pointrelation,
		NIL,			/* default_val */
		TRUE			/* got_default */
	    );
	    lv_rects_grl = xthl74_GetProp(
		&lv_thing,
		k_facetrelation,
		NIL,			/* default_val */
		TRUE			/* got_default */
	    );

        } else if (key == k_minx) {
	    minx = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
        } else if (key == k_maxx) {
	    maxx = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

        } else if (key == k_miny) {
	    miny = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
        } else if (key == k_maxy) {
	    maxy = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

        } else if (key == k_minz) {
	    minz = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
        } else if (key == k_maxz) {
	    maxz = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

	} else {

            xlerror("bad XBLL-INSERT-SPHERE keyword",key);
        }
    }

    xgrl0h_Must_Be_A_XGRL( lv_point_grl );
    xgrl0h_Must_Be_A_XGRL( lv_rects_grl );

    return xpwbG1_Insert_Terrain(
	lv_point_grl, lv_rects_grl, 
	minx, maxx,
	miny, maxy,
	minz, maxz
    );
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
