/******************************************************************/
/* client_check.c  Check routines for local and net clients       */

#ifdef NET_CLIENT
#include "netseval.h"
#else
#include "seval.h"
#endif

#include <stdio.h>


static tests_done = 0;
static bugs_found = 0;

strip_nl( dst, src )
char     *dst,*src;
{
    int    c;
    while (c = *src++)    if (c != '\n')   *dst++ = c;
    *dst = '\0';
}

should_be_true( bool, got_err, result, input, expected_result )
int             bool, got_err;
char                          *result,*input,*expected_result;
{
    ++tests_done;
    if (got_err) {
        printf("***** Error during evaluation of '%s'\n", input );
	++bugs_found;
    } else if (!bool || strcmp( result, expected_result )) {
	char r[ 4096 ];
	char e[ 4096 ];
	/* strip_nl( r,          result );
	strip_nl( e, expected_result ); */
        printf("***** Error: %s gave ", input);
	printcharstr(result);
	printf(",expected ");
	printcharstr(expected_result);
	printf("\n");
        /* printf("***** Error: %s gave %s, expected %s\n", input, r, e ); */
	++bugs_found;
    }
}

should_fail( bool, what )
int          bool;
char*              what;
{
    ++tests_done;
    if (!bool) {
        printf("***** Error: Didn't fail when trying to %s\n", what );
	++bugs_found;
    }
}

printcharstr(str)
char *str;
{
    char *s;
    for (s=str; *s; s++) 
      if (*s >= '\040') 
	printf("%c", *s);
      else
	printf("<%d>", *s);
}

main(argc,argv)
int argc; char *argv[];
{
    int   b;
    int   e;
    char* i;
    char* o;
    char *errstr;
    char *str;
    #ifdef NET_CLIENT
    int s;
    if (!(argc == 3)) {
	printf("Usage: %s <hostname> <port number>\n", argv[0]);
	exit(1);
	}
    s = sn_Connect(argv[1], atoi(argv[2]), &e, &o, &errstr);
    if(s == SN_ERR_RETURN) {
	printf("Can't connect to %s on port %s\n", argv[1], argv[2]);
	exit(1);
	}
    printf("%s", o);
    sn_Set_Socket(s);
    printf("Testing net client to %s on port %s-------\n", argv[1], argv[2]);
    sn_Eval_Str(    &e,&o, i="(+ 3 4)" );
    should_be_true(1,e, o, i, "7\n");

    sn_Eval_Str(    &e,&o, i="(* 3 4)" );
    b = sn_Int(&e)==12;
    should_be_true( b, e, o, i, "12\n" );

    i ="(+ 3 4)";
    b = 7==sn_Int_Eval_Str(&e,&o,i);
    should_be_true( b, e,o,i, "7\n" );

    i = "(* 0.5 7.0)";
    b = 3.5==sn_Float_Eval_Str(&e,&o,i);
    should_be_true( b, e,o,i,"3.5\n" );

    i = "(strcat \"a\" \"bc\")";
    str=sn_Str_Eval_Str(&e,&o,i);
    b = !strcmp( "abc", str);
    should_be_true( b, e,str,i,"abc" );
    
    i = "(+ 10 11)";
    sn_Set_Timeout(0);
    sn_Eval_Str(    &e,&o, i );
    should_fail(e,"Timeout = 0");
    sn_Set_Timeout(SN_DEFAULT_TIMEOUT);
    sn_Eval_Str(    &e,&o, i );
    should_be_true(1,e, o, i, "21\n");
    #else
    printf("Testing local client ---------------------------------\n");
    sl_Init();
    sl_Eval_Str(    &e,&o, i="(+ 3 4)" );
    should_be_true(1,e, o, i, "7\n"); 

    sl_Eval_Str(    &e,&o, i="(* 3 4)" );
    b = sl_Int(&e)==12;
     should_be_true( b, e, o, i, "12\n" );

    i ="(+ 3 4)";
    b = 7==sl_Int_Eval_Str(&e,&o,i);
    should_be_true( b, e,o,i, "7\n" );

    i = "(* 0.5 7.0)";
    b = 3.5==sl_Float_Eval_Str(&e,&o,i);
    should_be_true( b, e,o,i,"3.5\n" );

    i = "(strcat \"a\" \"bc\")";
    str=sl_Str_Eval_Str(&e,&o,i);
    b = !strcmp( "abc", str);
    should_be_true( b, e,str,i,"abc" );

    i = "(defun test () (print \"Hello\") (* 5 6))";
    sl_Eval_Str(&e, &o,i);
    i="(test)";
    str=sl_Eval_Str(&e, &o,i);
    should_be_true(1,e,str,i,"\"Hello\"\n");
    should_be_true(1,e,o,i,"30\n"); 

    /* Only local client  checks for type of result */ 
    sl_Eval_Str(    &e,&o, i="(+ 3 4)" );
    sl_Float(&e);
    should_fail(e,"fetch int as float");
    sl_String(&e);
    should_fail(e,"fetch int as string");

    sl_Eval_Str(    &e,&o, i="(* 0.5 7.0)" );
    sl_Int(&e);
    should_fail(e,"fetch float as int");
    sl_String(&e);
    should_fail(e,"fetch float as string");

    sl_Eval_Str(    &e,&o, i="(strcat \"a\" \"bc\")");
    sl_Int(&e);
    should_fail(e,"fetch string as int");
    sl_Float(&e);
    should_fail(e,"fetch string as float");  
    #endif

    printf("%d tests done, %d bugs found\n", tests_done, bugs_found );
}

