/* {{{ netseval.c -- network eval functions for slisp			*/

/* This file is formatted for use with folding.el for emacs, sort	*/
/* of an outline-mode for programmers, ftp-able from elisp archives	*/
/* such as tut.cis.ohio-state.edu (128.146.8.52).  If you don't use	*/
/* folding-mode and/or emacs, you may want to prepare a table of	*/
/* contents for this file by doing "grep '{{{' thisfile.c".		*/

/************************************************************************/
/*                              history                                 */
/*									*/
/* 									*/
/* 94Sept26 jfb: Created.						*/
/************************************************************************/

/* }}} */

/* {{{ Header stuff							*/

#include "netseval.h" 
#include <strings.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

/* Manifest constants: */
#define INITIAL_RESULT_BUF_SIZE (2)
#ifndef TRUE
#define TRUE	(1)
#endif
#ifndef FALSE
#define FALSE	(0)
#endif


/* Global variables: */
static FILE *sn_tfp = NULL;
static int server_timeout=SN_DEFAULT_TIMEOUT;
int current_socket = -1;
int client_end = SN_DEFAULT_END;
int client_data = SN_DEFAULT_DATA;

/* Forward declarations: */
static void buf_putc();
static void buf_reset();
static void buf_double();
static void buf_init();
static char *receiveFromServer();
static int receiveChars();
static int data_waiting();
static int ready_for_writing();


/* A buffer in which we return string values: */
static char* result_buf     = NULL;
static int   result_buf_len = 0;
static int   result_buf_ptr = 0;
static char *current_data_ptr = NULL;

/* }}} */

/* --- External routines  only for network clients---			*/
/* {{{ sn_Connect -- Connect to a host				*/

int sn_Connect(hostaddr, portid, got_err, outstr, errstr)
char *hostaddr;
int portid;
int *got_err;
char **outstr, **errstr;
{
    /* Connect to hostaddr on portid, return socket number if connection
    is successful, SN_ERR_RETURN if not. Return any initialization output
    produced by the server in outstr. Since all servers should at least
    output an initialization banner, if no message is received from the
    server then the connection failed, so  return SN_ERR_RETURN. 
    If any of the output includes an error
    message beginning with "error:", set got_err to TRUE and return
    the error message in errstr, and any previous output in outstr. If
    no error message was present in the output got_err is FALSE and
    errstr points to NULL */
    int s;
    struct sockaddr_in sa;
    struct hostent *hp;
     *got_err=FALSE;
    if ((hp=gethostbyname((char *)hostaddr)) == NULL) {
	*got_err = TRUE;
	*outstr=NULL;
	*errstr = "Can't find host\n";
	return SN_ERR_RETURN;
	}
    bcopy((char *)hp->h_addr,(char *)&sa.sin_addr,hp->h_length);
    sa.sin_family = hp->h_addrtype;
    sa.sin_port = portid;
    if((s = socket(hp->h_addrtype,SOCK_STREAM,0)) < 0) { 
	*got_err = TRUE;
	*errstr = "Can't connect\n";
	*outstr=NULL;
	return SN_ERR_RETURN;
	}
    if(connect(s,(struct sockaddr *) &sa,sizeof(sa)) < 0) {
	*got_err = TRUE;
	*errstr = "Can't connect\n";
	*outstr=NULL;
	printf("return\n");
	return SN_ERR_RETURN;
	} 
     *outstr = receiveFromServer(s, got_err, errstr); 
     if (*got_err) 
 	return SN_ERR_RETURN;
     else
 	return s; 
}
/* }}} */

/* {{{ sn_Disconnect -- Disconnect from a host			*/
     
void sn_Disconnect(s)
int s;
{
    /* Disconnect previously connected socket s */ 
    close(s);
}
/* }}} */

/* {{{ sn_Set_Socket -- Set current socket			*/
     
void sn_Set_Socket(s)
int s;
{
    /* Set current_socket to the previously connected socket s. This
    should allow multiple connections to be maintained */ 
    current_socket = s;
    return;
}
/* }}} */

/* {{{ sn_Set_Timeout -- Set timeout in seconds			*/
void sn_Set_Timeout(seconds)
int seconds;
{
  /* Set number of seconds for client to wait for server  to reply  */
  server_timeout = seconds;
  return;
}
/* }}} */

/* {{{ sn_Set_Delimiters   Set client and server data and  end markers     */					void sn_Set_Delimiters (datachar, endchar, got_err, outstr)
int datachar, endchar;
int *got_err;
char **outstr;
{
  /* Set client and server data start and end of message character. 
  datachar is the decimal equivalent of the data start character. 
  endchar is the decimal equivalent of the new end character. 
  This is only callable
  after a connection has been established since it must inform the server
  of the new delimiter. If an error is encountered from the server got_err
  will point to the start of the error message in outstr.
  The server will immediately start sending the new
  delimeters  */
  int savedatadelim, saveenddelim;
  char buf[100];
  /* Save the old delimters in case of error, then reset the delimeters */
  savedatadelim=client_data;
  saveenddelim=client_end;
  client_data=datachar;
  client_end = endchar;
  /* Now tell the server about the change */
  sprintf(buf, "(XETC-SET-SERVER-DELIMITERS %d %d)", client_data, client_end); 
  sn_Eval_Str(got_err, outstr, buf);
  /* In case of error restore the old delimeter.  */
  if (*got_err) {
	client_data = savedatadelim;
	client_end = saveenddelim;
	}
  return;
}
/* }}} */

/* -------Analogous to routines in seval.h -----------------------------*/
/* {{{ sn_Init -- Network initialization					*/
extern void sn_Init()
{
    /* Placeholder in case we need to do some initialization later */
    return;
}
/* }}} */

/* {{{ sn_Init -- Network wrapup					*/

extern void sn_Wrapup()
{
    return;
}
/* }}} */

/* {{{ sn_Eval_Str -- Main evaluate-string-and-return-string entrypt.	*/

char *sn_Eval_Str(got_err, outstr, instr )
int* got_err;
char **outstr,*instr;
{
    /* Send instr to current_socket, which is assumed to be connected to an 
    slisp server via sn_Connect and sn_Set_Socket. 
    Instr must be a a valid s-expr.
    If an error is returned by the server set got_err to be TRUE, and set 
    outstr to point to the error message, after the initial "error:" If an
    error is not returned set got_err to be FALSE and point outstr to the
    string representation of the expression returned by the function. 
    In either case
    if any output was generated (say by PRINT or FORMAT) the return value of
    the function  points to this
    output. If no other output was generated then the return value points to
    outstr.  */
    int d;
    char *o;
    /* if (!sn_tfp) sn_Open_Transcript("/tmp/trans.txt", &transptr); */
    if (sn_tfp) fprintf(sn_tfp, "instr: %s\n", instr);
    /* Check to be sure the connection is valid */
    if (!ready_for_writing(current_socket)) {
	*got_err = TRUE;
	*outstr="Connection not open\n";
	return *outstr;
	}
    /* Send the input string plus a return */
    write(current_socket, instr, strlen(instr));
    write(current_socket, "\n", 1);
    /* Receive results */
    return (receiveFromServer(current_socket, got_err, outstr));
}

/* }}} */
/* {{{ sn_Int -- Return integer value of current buffer		*/

int sn_Int( got_err )
int        *got_err;
{
    int val;
    *got_err = FALSE;
    if (!current_data_ptr) {
	*got_err = TRUE;
	return SN_ERR_RETURN;
	}
    sscanf(current_data_ptr, "%d", &val);
    return val;
}

/* }}} */
/* {{{ sn_Float -- Return float value of current buffer		*/

float sn_Float( got_err )
int            *got_err;
{
    float val;
    *got_err = FALSE;
    if (!current_data_ptr) {
	*got_err = TRUE;
	return -1.0;
	}
    sscanf(current_data_ptr, "%f", &val);
    return val;
}

/* }}} */
/* {{{ sn_String -- Return string value of current buffer		*/

char *sn_String( got_err )
int             *got_err;
{
    /* Strip off surrrounding quotes  and copy unquoted string to end
    of buffer */
    char *s, *e;
    *got_err = FALSE;
    if (!current_data_ptr) {
	*got_err = TRUE;
	return "";
	}
    /* End the output string */
    buf_putc('\0');
    s = &result_buf[result_buf_ptr];
    /* Copy non-quoted part of output string to end of buffer */
    e=current_data_ptr;
    while (*e && !(*e=='\"')) e++;
    e++;
    while (*e && !(*e=='\"')) {
	buf_putc(*e);
	e++;
	}
    return s;
}

/* }}} */

/* --- Additional convenience externally callable routines ---		*/
/* {{{ sn_Int_Eval_Str -- Eval 'instr', return int result.		*/

int sn_Int_Eval_Str(got_err, outstr, instr )
int                 *got_err;
char                        **outstr,*instr;
{
    sn_Eval_Str(got_err, outstr, instr );
    if (*got_err)   return 0;
    else            return sn_Int( got_err );
}

/* }}} */
/* {{{ sn_Float_Eval_Str -- Eval 'instr', return float result.		*/

float sn_Float_Eval_Str(got_err, outstr, instr)
int                     *got_err;
char                            **outstr,*instr;
{
    sn_Eval_Str(got_err, outstr, instr );
    if (*got_err)   return 0.0;
    else            return sn_Float( got_err );
}

/* }}} */
/* {{{ sn_Str_Eval_Str -- Eval 'instr', return string result.		*/

char *sn_Str_Eval_Str(got_err, outstr, instr )
int                   *got_err;
char                          **outstr,*instr;
{
    sn_Eval_Str(got_err, outstr, instr );
    if (*got_err)   return "";
    else            return sn_String( got_err );
}

/* }}} */

/* --- Debugging routines ---						*/
/* {{{ sn_Open_Transcript -- Open debug session logfile.			*/

void sn_Open_Transcript( fullpath, outstr )
char               *fullpath,**outstr;

/* Open a transcript file, given by fullpath, for writing.	*/
/* All input and output to slisp will be written to this file,	*/
/* which will then be closed on exit or by explicit call to	*/
/* sn_Wrapup. This is useful for debugging slisp as it receives	*/
/* commands from a separate C program, which may not be		*/
/* printing out the results of slisp as it executes.		*/
{
    char outbuf[200];
    int i;
    buf_reset();
    if ((sn_tfp = fopen(fullpath, "w")) == NULL) {
      sprintf(outbuf, "error: can't open slisp transcript file: %s", fullpath);
    } else {
      sprintf(outbuf, "sl transcript file %s opened", fullpath);
    }  
    for(i=0;i<strlen(outbuf); i++) buf_putc(outbuf[i]);
    *outstr=result_buf;
    return; 
}

/* }}} */

/* {{{ sn_Close_Transcript -- Close debug logfile			*/

void sn_Close_Transcript() {
    /* Close the sl transcript file if it exists. Don't  since	*/
    /* the controlling program might want to do other wrapup first.	*/
    if (sn_tfp) fclose(sn_tfp);
}

/* }}} */
/* --- Internal routines ---						*/
/* {{{ buf_init -- Establish result_buf.				*/
	
static void buf_init( void ) {
    result_buf_len = INITIAL_RESULT_BUF_SIZE;
    result_buf = (char*) malloc( result_buf_len );
    if (!result_buf) {
	fputs("slisp.c:buf_init: out of ram!?\n",stderr);
	abort();
    }
}

/* }}} */
/* {{{ buf_double -- Double size of result_buf.				*/
	
static void buf_double( void ) {
    result_buf_len *= 2;
    result_buf = (char*) realloc( result_buf, result_buf_len );
    if (!result_buf) {
	fputs("slisp.c:buf_double: out of ram!?\n",stderr);
	abort();
    }
}

/* }}} */
/* {{{ buf_putc -- Append one char to result_buf.			*/

	
static void buf_putc( c )
int                   c;
{
    if (result_buf_ptr + 2 >= result_buf_len)   buf_double();
    result_buf[ result_buf_ptr++ ] =   c ;
    result_buf[ result_buf_ptr   ] = '\0';
}

/* }}} */
/* {{{ buf_reset -- Set result_buf to empty string 				*/
	
static void buf_reset( void ) 
{ 
    if (!result_buf_len) buf_init();
    result_buf_ptr = 0; 
    result_buf[ result_buf_ptr   ] = '\0';
    current_data_ptr = NULL;
}

/* }}} */

/* {{{ receiveFromServer --- Receive server message			*/
static char *receiveFromServer(s, got_err, outstr)
int s;
int *got_err;
char **outstr;
{
    /* Receive characters from server until client_end character is received,
    or until timeout. If an error is returned by the server set got_err to be
    TRUE, and set 
    outstr to point to the error message, after the initial "error:" If an
    error is not returned set got_err to be FALSE and point outstr to the
    string representation of the expression returned by the function. 
    In either case
    if any output was generated (say by PRINT or FORMAT) the return value of
    the function  points to this
    output. If no other output was generated then the return value points to
    outstr. */
    char *errptr, *endptr, *dataptr;
    buf_reset();
    *got_err = FALSE;
    while (!(endptr = index(result_buf,client_end))) {
        if (!receiveChars(s)) {
	  *got_err = TRUE;
	  *outstr = "Server timeout\n";
 	  return *outstr;
	  }
 	}
    *endptr='\0';
    /* Look for start of data   */
    if (dataptr=index(result_buf, client_data)) {
	*dataptr='\0';
	current_data_ptr = dataptr + 1;
	*outstr=current_data_ptr;
	if (dataptr==result_buf)
	   return *outstr;
	else
	   return result_buf;
	}
    /* Look for error message if no data was sent */
    for (errptr=result_buf; errptr < endptr; errptr++) 
	if (!strncmp(errptr, "error:", 6)) {
	    *got_err = TRUE;
	    *errptr='\0';
	    *outstr=errptr+ 6;
	    if (errptr==result_buf)
		return *outstr;
	    else
		return result_buf;
	    }
    /* If this point is reached no data or error was sent, as at 
    initialization. This is not necessarily an error  */
     *outstr=NULL;
    return result_buf;
}

/* }}} */

/* {{{ receiveChars --- Read characters from read buffer		*/

static int receiveChars(s)
int s;
{
    /* Continuously poll connected socket s to find out if data is 
    waiting to be read. If no data is available within timeout seconds
    return 0, which can be interpreted as a network or server timeout.
    Once data is available keep reading it until no more is available. A
    "nicer" process is commented out - in this case the client sleeps
    for 1 second if data is not initially present. However this results
    in the client always sleeping for 1 second since data is never waiting
    when this routine is first called. Since most client programs will
    be run on individual workstations it didn't seem necessary to be this
    nice at the expense of extra delay   - jfb  */
    int i,j, total;
    char buf[BUFSIZ+1];
    struct timeval tv;
    struct timezone tz;
    int starttime, currenttime;
     i=0;
    gettimeofday(&tv,&tz);
    starttime = tv.tv_sec;
    /* while ((data_waiting(s) == 0) && (i++<server_timeout)) sleep(1);  */ 
    total=0;
    while (data_waiting(s) == 0) {
	gettimeofday(&tv,&tz); 
	currenttime = tv.tv_sec;
	if ((currenttime - starttime) >= server_timeout) return 0;
	}
     while (data_waiting(s) > 0)  {
	i = read(s, buf, BUFSIZ);
	if(!i) return(0);
	for(j=0;j<i;j++) buf_putc(buf[j]);
	total += i;
    }
    return(total);
}

/* {{{ data_waiting --- Check for data in read buffer			*/
static int data_waiting(s)
int s;
{
  fd_set fds;
  struct timeval to;
  int n;
  to.tv_sec=0;
  to.tv_usec=0;
  FD_ZERO(&fds);
  FD_SET(s,&fds);
  n=select(s+1,&fds,0,0,&to);
  return(n);
}
/* }}} */
	
/* {{{ ready_for_writing --- Check for open connection			*/
static int ready_for_writing(s)
int s;
{
  struct stat buf;
  int st;
  int d;
  /* Reset input buffer */
  buf_reset();
  /* Make sure socket is valid */
  st = fstat(s,&buf);
  if (st) return FALSE;
  /* Flush any data in input buffer */
  while (data_waiting(s)) 
	if (!receiveChars(s)) return FALSE;
  return TRUE;
}
/* }}} */



/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/


/* }}} */

    
