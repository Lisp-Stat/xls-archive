/* {{{ seval.c -- local eval functions for slisp			*/

/* This file is formatted for use with folding.el for emacs, sort	*/
/* of an outline-mode for programmers, ftp-able from elisp archives	*/
/* such as tut.cis.ohio-state.edu (128.146.8.52).  If you don't use	*/
/* folding-mode and/or emacs, you may want to prepare a table of	*/
/* contents for this file by doing "grep '{{{' thisfile.c".		*/

/************************************************************************/
/*                              history                                 */
/*									*/
/* 94Sep26 jfb: Renamed seval from slisp.c				*/
/* 94Feb15 jsp: Header stuff, internal ustream_to_str buffer, cleanup.	*/
/* 94Jan?? jfb: Created.						*/
/************************************************************************/

/* }}} */

/* {{{ Header stuff							*/

#include "xlisp.h"
#include "seval.h"
#include <string.h>

/* Manifest constants: */
#define INITIAL_RESULT_BUF_SIZE (2)

/* Global variables: */
static jmp_buf top_level;
static LVAL expr, stdinsave, stdoutsave, stderrsave, debugsave;
static CONTEXT context;
static FILE *sl_tfp;

/* External variables: */
extern LVAL  s_stderr, s_stdout, s_stdin, s_tracenable, s_breakenable;
extern LVAL true;
extern LVAL xlmakesym();

/* External routines: */
extern FILE *osaopen();
extern FILE *osclose();

/* Forward declarations: */
static LVAL str_to_ustream();
static void ustream_to_buf();
static void buf_putc();
static void buf_reset();
static void buf_double();
static void buf_init();

/* A buffer in which we return string values: */
static char* result_buf     = NULL;
static int   result_buf_len = 0;
static int   result_buf_ptr = 0;

/* }}} */

/* --- Externally callable routines  for local clients---		*/
/* {{{ sl_Init -- Start-of-world initialization.			*/

void sl_Init() {

    static int done_init = FALSE;
    int nlvals=5;
    if (done_init)   return;
    done_init = TRUE;

    /* Allocate result_buf: */
    buf_init();

    /* Initialize slisp, must be called first */
    /* setup initialization error handler */
    xlbegin(&context,CF_TOPLEVEL|CF_CLEANUP|CF_BRKLEVEL,(LVAL)1);
    if (setjmp(context.c_jmpbuf))
	xlfatal("fatal initialization error");
    /* initialize xlisp */
    xlinit();
    xlend(&context);

    /********************************************************************/
    /* Protect some pointers. Expr is the current expression as		*/
    /* in xmain.  stdoutsave etc are the original values of		*/
    /* s_stdout etc, which are initially set in xlinit to stdout	*/
    /* etc. If these are not saved in global variables their		*/
    /* corresponding STREAM nodes will not be accessible from the	*/
    /* garbage collector once s_stdout etc have been reassigned to	*/
    /* unnamed streams in slevalstr. Hence the garbage collector	*/
    /* will try to sweep them, which means that it will try to		*/
    /* fclose stdout, stdin or stderr. Before I started to protect	*/
    /* these variables this created a nasty bug that was very hard	*/
    /* to trace.  Lesson - the need to protect LVALS is very		*/
    /* important, and not always obvious when it needs to be done	*/
    /*   -- jfb								*/
    /********************************************************************/

    xlstkcheck( nlvals );
    xlsave( expr       );
    xlsave( stdinsave  );
    xlsave( stdoutsave );
    xlsave( stderrsave );
    xlsave( debugsave  );

    /* Save existing values */
    stdoutsave = getvalue( s_stdout );
    stderrsave = getvalue( s_stderr );
    stdinsave  = getvalue( s_stdin  );

    /************************************************************/
    /* Reset s-breakenable and s_tracenable to a symbol		*/
    /* (*DEBUGSAVE*) which always has value NIL. This symbol is	*/
    /* not part of obarray so is not changeable by the lisp	*/
    /* programmer. In this way if a lisp programmer sets	*/
    /* *BREAKENABLE* to T this will have no effect, and break	*/
    /* loops will always remain disabled. Seval.c does not	*/
    /* handle break loops because the breakloop function	*/
    /* requires additional input, which is not compatible with	*/
    /* the idea of sending all the input in a single string.	*/
    /************************************************************/

    debugsave = xlmakesym("*DEBUGSAVE*");
    setvalue( debugsave, NIL );
    s_breakenable = debugsave;
    s_tracenable  = debugsave;

    /* Reset the error handler: */
    xlbegin(&context,CF_TOPLEVEL|CF_CLEANUP|CF_BRKLEVEL,true);
}

/* }}} */
/* {{{ sl_Wrapup -- End-of-world shutdown.				*/

void sl_Wrapup() {
    /* Close the slisp transcript file if it exists. Don't exit since	*/
    /* the controlling program might want to do other wrapup first.	*/
    if (sl_tfp) osclose(sl_tfp);
}

/* }}} */

/* -----Externally callable routines analogous to those in netseval.h---*/
/* {{{ sl_Eval_Str -- Main evaluate-string-and-return-string entrypt.	*/

char *sl_Eval_Str( got_err, outstr, instr )
int*              got_err;
char                     **outstr,*instr;
{
    /* Eval instr, return result in outstr. If the evaluated function
    prints anything prior to returning return a pointer to the printed
    text. If nothing is printed the return value is equal to outstr. If
    an error is generated got_err is set to TRUE and outstr points to
    the start of an error message, which starts with "error:" */
    LVAL errstream, stdstream, instream;
    int nlvals=3;
    int errptr,dataptr;
    *got_err  = FALSE;

    /* Make sure we got initialized: */
    sl_Init();
    buf_reset();

    if (sl_tfp) fprintf(sl_tfp, "instr: %s\n", instr);
    xlsave(errstream);
    xlsave(stdstream);
    xlsave(instream);
    /* Set value of standard output and standard error output	*/
    /* to unnamed streams, so output will be written to these	*/
    /* streams rather than stdout or stderr.			*/
    errstream = newustream();
    stdstream = newustream();
    setvalue(s_stdout, stdstream);
    setvalue(s_stderr, errstream);

    /* Place input string in an unnamed stream */
    /* and set this to be s_stdin:             */
    instream = str_to_ustream( instr );
    setvalue( s_stdin, instream );

    /* Set up the error return. Errors will transfer here. Set the return
    value to any output written to stdout prior to the error, set got_err
    to TRUE, and set outstr to the start of an error message, after the
    initial "error:" */
     if (setjmp(context.c_jmpbuf)) {
        /* Output any results that were printed in the function */
        ustream_to_buf(stdstream);
        if(result_buf_ptr) {
	  buf_putc('\0');
	  errptr=result_buf_ptr;
	  }
        else
	  errptr = 0;
	ustream_to_buf( errstream );
	*outstr = &result_buf[errptr + 7];  /* Past the "error:" start  */
	if (sl_tfp) fprintf(sl_tfp, "outstr: %s\n", *outstr);
        *got_err = TRUE;
	if (!errptr)
	    return *outstr;
	else
 	    return result_buf;
        }  

    /* With no errors the following functions are executed,	*/
    /* then the routine returns. These are taken almost		*/
    /* verbatim from the main loop in xmain:			*/ 

    /* Read an expression. A read error will transfer		*/
    /* to the error return:					*/
    if (!xlread(instream,&expr, FALSE))   return;

    /* Save the input expression: */
    xlrdsave(expr);

    /* Evaluate the expression: */
    expr = xleval(expr);

    /* Save the result: */
    xlevsave(expr);

    /* Output any results that were printed in the function */
    ustream_to_buf(stdstream);
    if(result_buf_ptr) {
	buf_putc('\0');
	dataptr=result_buf_ptr;
	}
    else
	dataptr = 0;
    /* Print the expression: */
    stdprint(expr);

    /* Output has been written to stdstream.	*/
    /* Now convert this to outstr:		*/
    ustream_to_buf( stdstream );
    xlpopn(nlvals);
    *outstr = &result_buf[dataptr];
    if (sl_tfp)   fprintf(sl_tfp, "outstr: %s\n", result_buf);
    return (result_buf);
}

/* }}} */
/* {{{ sl_Int -- Return integer value of current expression.		*/

int sl_Int( got_err )
int        *got_err;
{
    *got_err = FALSE;
    if (!fixp(expr)) {
	*got_err = TRUE;
	return 0;
    }
    return getfixnum(expr);
}

/* }}} */
/* {{{ sl_Float -- Return float value of current expression.		*/

float sl_Float( got_err )
int            *got_err;
{
    *got_err = FALSE;
    if (!floatp( expr )) {
	*got_err = TRUE;
	return 0.0;
    }
    return getflonum( expr );
}

/* }}} */
/* {{{ sl_String -- Return string value of current expression.		*/

char *sl_String( got_err )
int             *got_err;
{
    *got_err = FALSE;
    if (!stringp( expr )) {
	*got_err = TRUE;
	return NULL;
    }
    return (char*) getstring( expr );
}

/* }}} */

/* --- Additional convenience externally callable routines ---		*/
/* {{{ sl_Int_Eval_Str -- Eval 'instr', return int result.		*/

int sl_Int_Eval_Str( got_err, outstr, instr )
int                 *got_err;
char                        **outstr,*instr;
{
    sl_Eval_Str( got_err, outstr, instr );
    if (*got_err)   return 0;
    else            return sl_Int( got_err );
}

/* }}} */
/* {{{ sl_Float_Eval_Str -- Eval 'instr', return float result.		*/

float sl_Float_Eval_Str( got_err, outstr, instr)
int                     *got_err;
char                            **outstr,*instr;
{
    sl_Eval_Str( got_err, outstr, instr );

    if (*got_err)   return 0.0;
    else            return sl_Float( got_err );
}

/* }}} */
/* {{{ sl_Str_Eval_Str -- Eval 'instr', return string result.		*/

char *sl_Str_Eval_Str( got_err, outstr, instr )
int                   *got_err;
char                          **outstr,*instr;
{
    sl_Eval_Str( got_err, outstr, instr );

    if (*got_err)   return NULL;
    else            return sl_String( got_err );
}

/* }}} */

/* --- Debugging routines ---						*/
/* {{{ sl_Open_Transcript -- Open debug session logfile.		*/

void sl_Open_Transcript( fullpath, outstr )
char               *fullpath,*outstr;

/* Open a transcript file, given by fullpath, for writing.	*/
/* All input and output to slisp will be written to this file,	*/
/* which will then be closed on exit or by explicit call to	*/
/* sl_Wrapup. This is useful for debugging slisp as it receives	*/
/* commands from a separate C program, which may not be		*/
/* printing out the results of slisp as it executes.		*/
{
    if ((sl_tfp = osaopen(fullpath, "w")) == NULL) {
      sprintf(outstr, "error: can't open slisp transcript file: %s", fullpath);
    } else {
      sprintf(outstr, "Slisp transcript file %s opened", fullpath);
    }    
}

/* }}} */
/* {{{ sl_Close_Transcript -- Close debug logfile			*/

void sl_Close_Transcript() {
    /* Close the sl transcript file if it exists. Don't  since	*/
    /* the controlling program might want to do other wrapup first.	*/
    if (sl_tfp) fclose(sl_tfp);
}

/* }}} */

/* --- Internal routines ---						*/
/* {{{ buf_init -- Establish result_buf.				*/
	
static void buf_init( void ) {
    result_buf_len = INITIAL_RESULT_BUF_SIZE;
    result_buf = (char*) malloc( result_buf_len );
    if (!result_buf) {
	fputs("slisp.c:buf_init: out of ram!?\n",stderr);
	abort();
    }
    buf_reset();
}

/* }}} */
/* {{{ buf_double -- Double size of result_buf.				*/
	
static void buf_double( void ) {
    result_buf_len *= 2;
    result_buf = (char*) realloc( result_buf, result_buf_len );
    if (!result_buf) {
	fputs("slisp.c:buf_double: out of ram!?\n",stderr);
	abort();
    }
}

/* }}} */
/* {{{ buf_putc -- Append one char to result_buf.			*/

	
static void buf_putc( c )
int                   c;
{
    if (result_buf_ptr + 2 >= result_buf_len)   buf_double();
    result_buf[ result_buf_ptr++ ] =   c ;
    result_buf[ result_buf_ptr   ] = '\0';
}

/* }}} */
/* {{{ buf_reset -- Set result_buf to empty string 				*/
	
static void buf_reset( void ) 
{ 
    if (!result_buf_len) buf_init();
    result_buf_ptr = 0; 
    result_buf[ result_buf_ptr   ] = '\0';
}

/* }}} */
/* {{{ str_to_ustream -- Return new unnamed stream holding string 'str'.*/
	
static LVAL str_to_ustream( str )
char *                      str;
{
    /* Create stream: */
    LVAL    unstream;
    xlsave1(unstream);
    unstream = newustream();

    /* Copy str into it; */
    {   int    c;
        while (c = *str++)   xlputc( unstream, c );
    }

    xlpop();
    return unstream;
}

/* }}} */
/* {{{ ustream_to_buf -- Copy unnamed stream 'u' to result_buf.		*/

static void ustream_to_buf( u, str )
LVAL                        u;
char *                         str;
{ 
    /* Removed buf_reset since may want to append   jfb */ 
    {   int     c;
	while ((c = xlgetc(u)) != EOF)   buf_putc( c );
    }
}

/* }}} */


/* {{{ sl_Stack_Check -- Nonce fn when debugging gc problems.		*/

void sl_Stack_Check( msg )
char                *msg;

/* This routine is not normally used, but it is useful in	*/
/* case of obscure garbage collection bugs that arise from not	*/
/* protecting or popping LVALS in your own functions. For	*/
/* example, it can be called at the beginning of each gc, which	*/
/* is defined in xldmem.c, to make sure the variables you	*/
/* thought you were protecting are still on the stack. What is	*/
/* currently here is what I was checking for the last time I	*/
/* had a bad gc bug - jfb					*/

{
    register LVAL **p,  tmp;
    return;
#ifdef SOMETIMES
    printf("Stack check: %s\n", msg);
    printf("  xlstack=%p\n", xlstack);
    printf("  xlstktop=%p\n", xlstktop);
    for (p = xlstack; p < xlstktop; ++p) {
	printf("  p=%p *p=%p\n", p, *p);
	if (*p==&expr) printf("  expr in stack\n");
	if (*p==&stdinsave) printf("  stdinsave in stack\n");
	if (*p==&stdoutsave) printf("  stdoutsave in stack\n");
	if (*p==&stderrsave) printf("  stderrsave in stack\n");
	if (*p==&debugsave) printf("  debugsave in stack\n");
	tmp=**p;
 	if (!tmp) continue;
	if ((tmp->n_type < 1) || (tmp->n_type > 14))
		printf("Bad type in stack\n");
	if (tmp->n_type==STREAM) {
		if (getfile(tmp)==stdout) printf("  stdout in stack\n");
		}
    }
#endif
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/


/* }}} */

    
