/******************************************************************/
/* sl_client.c */

#ifdef NET_CLIENT
#include "netseval.h"
#else
#include "seval.h"
#endif

#include <stdio.h>

#define BUF_SIZ 4000
/* Demo main program that implements either a net client or a local client that 
sends an  s-expression string to slisp,  and returns the result of its
evaluation. If NET_CLIENT is defined a network client is created that
sends the string to an slisp server running on a defined machine and port,
given on the command line. If
LOCAL_CLIENT is defined slisp is linked into the executable image of the
main program. For the NET_CLIENT the main program is linked with the library
libnetseval.a, whereas for the LOCAL_CLIENT the main program is linked with
the library libseval.a, as well as the slisp libraries libslisp.a and
libapp.a, where app is the name of an slisp application.  */  

main(argc,argv)
int argc; char *argv[];
{
    char inbuf[ BUF_SIZ ];
    int got_err;
    char *result, *err, *out;
    #ifdef NET_CLIENT
    int s;
    #else
    sl_Init();
    #endif
    #ifdef NET_CLIENT
    if (!(argc == 3)) { 
	printf("Usage: %s <hostname> <port number>\n", argv[0]);
	exit(1);
	}
    s = sn_Connect(argv[1], atoi(argv[2]), &got_err, &result, &err);
    if (got_err) {
	if (result)
	   printf("%s", result);
	printf("error: %s", err);
	printf("Can't connect to %s on port %s\n", argv[1], argv[2]);
	exit(1);
	}
    printf("%s", result);
    sn_Set_Socket(s);
    #endif
    for (;;) {
	printf("> ");
	fgets( inbuf, BUF_SIZ, stdin );

	#ifdef NET_CLIENT
	out = sn_Eval_Str(&got_err, &result, inbuf );
	if (out != result) printf("%s", out);
	if (got_err) {
	  if (!strcmp(result, "Server timeout\n") ||
              !strcmp(result, "Connection not open\n"))  {
	    printf("%s", result);
	    exit(0);
	    }
	  else
	    printf("error: %s", result);
   	  }
	else
	  printf("%s", result);

 	#else
	out = sl_Eval_Str(&got_err, &result, inbuf );
	if (out != result) printf("%s", out);
	if (got_err)
	  printf("error: %s", result);
	else
	  printf("%s", result);
	#endif
    }
}

