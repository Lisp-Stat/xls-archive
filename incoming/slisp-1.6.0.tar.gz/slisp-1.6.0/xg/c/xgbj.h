/* {{{ xgbj.h -- General-oBJects.				     CrT*/
/*************************************************************************
*
* File:         xgbj.h
* Description:  General-OBJEct header file.
* Author:       Jeff Prothero
* Created:      90Nov16
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */


#ifdef MODULE_XLDMEM_H_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	NULL,	xgbj54_Show		)

/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.  This lets GOBJECT sub-   */
/* classes achieve a certain level of privacy by redefining    */
/* these messages.                                             */
DEFINE_SUBR(	NULL,	xgbj01_Get_Size_In_Lvals	)
DEFINE_SUBR(	NULL,	xgbj03_Set_Size_In_Lvals	)
DEFINE_SUBR(	NULL,	xgbj05_Get_Lval			)
DEFINE_SUBR(	NULL,	xgbj07_Set_Lval			)
DEFINE_SUBR(	NULL,	xgbj08_Insert_Lval		)
DEFINE_SUBR(	NULL,	xgbj09_Delete_Lval		)

DEFINE_SUBR(	NULL,	xgbj10_Get_Size_In_Bytes	)
DEFINE_SUBR(	NULL,	xgbj12_Set_Size_In_Bytes	)
DEFINE_SUBR(	NULL,	xgbj14_Get_Byte			)
DEFINE_SUBR(	NULL,	xgbj16_Set_Byte			)
DEFINE_SUBR(	NULL,	xgbj17_Insert_Byte		)
DEFINE_SUBR(	NULL,	xgbj18_Delete_Byte		)

DEFINE_SUBR(	NULL,	xgbj19_Get_Size_In_Ints		)
DEFINE_SUBR(	NULL,	xgbj21_Set_Size_In_Ints		)
DEFINE_SUBR(	NULL,	xgbj23_Get_Int			)
DEFINE_SUBR(	NULL,	xgbj25_Set_Int			)
DEFINE_SUBR(	NULL,	xgbj26_Insert_Int		)
DEFINE_SUBR(	NULL,	xgbj27_Delete_Int		)

DEFINE_SUBR(	NULL,	xgbj28_Get_Size_In_Floats	)
DEFINE_SUBR(	NULL,	xgbj30_Set_Size_In_Floats	)
DEFINE_SUBR(	NULL,	xgbj32_Get_Float		)
DEFINE_SUBR(	NULL,	xgbj34_Set_Float		)
DEFINE_SUBR(	NULL,	xgbj35_Insert_Float		)
DEFINE_SUBR(	NULL,	xgbj36_Delete_Float		)

DEFINE_SUBR(	NULL,	xgbj37_Get_Size_In_Doubles	)
DEFINE_SUBR(	NULL,	xgbj39_Set_Size_In_Doubles	)
DEFINE_SUBR(	NULL,	xgbj41_Get_Double		)
DEFINE_SUBR(	NULL,	xgbj43_Set_Double		)
DEFINE_SUBR(	NULL,	xgbj44_Insert_Double		)
DEFINE_SUBR(	NULL,	xgbj45_Delete_Double		)
#endif


#ifdef MODULE_XLINIT_C_XLINIT
#endif

#ifdef MODULE_XLISP_C_WRAPUP
#endif


#ifdef MODULE_XLDMEM_H_NINFO
#endif

#ifdef MODULE_XLDBUG_C_BREAKLOOP_REPLACEMENT
#endif


#ifdef MODULE_XLDMEM_C_GLOBALS
#include "../../xg.3d/c/c03d.h" /* <-- TEMP DEBUG HACK, DELETE */
#endif


#ifdef MODULE_XLDMEM_C_GC
#endif

#ifdef MODULE_XLDMEM_C_MARK
case GOBJECT:
    /* Just like OBJECT, except we may need */
    /* to mark some array LVARs as well:    */
    n = getsize(this) + getgobjarraylvals(this);
    for (i = 0;   i < n;   ++i) {
	if (tmp = getelement(this,i)) {
	    mark(tmp);
	}
    }
    break;
#endif



#ifdef MODULE_XLDMEM_C_SWEEP
case GOBJECT:
    total -= (long) (getgobjarraylvals(p) * sizeof(LVAL));
    total -= (long) (p->n_vsize           * sizeof(LVAL));
    total -= (long) (getgobjimmbytes(p));
    free(&p->n_vdata[-2]);
    break;
#endif


#ifdef MODULE_XLDMEM_C_XLMINIT
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
LVAL a_gobject=NIL;
#endif



#ifdef MODULE_XLIMAGE_C_XLISAVE
case GOBJECT:
    xlfail("GOBJECT save not implemented");/*BUGGO*/
    break;
#endif



#ifdef MODULE_XLIMAGE_C_XLIRESTORE
case GOBJECT:
    xlerror("GOBJECT restore not implemented",NIL);/*BUGGO*/
    break;
#endif



#ifdef MODULE_XLIMAGE_C_FREEIMAGE
case GOBJECT:
    free(&p->n_vdata[-2]);
    break;
#endif



#ifdef MODULE_XLINIT_C_GLOBALS
extern LVAL a_gobject;
#endif



#ifdef MODULE_XLINIT_C_XLSYMBOLS
    a_gobject	= xlenter("CLASS-GOBJECT");
#endif



#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xgbj;
LVAL k_closed_gobject;

LOCAL struct xgbj_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xgbj_table[] = {
     {	":LVAL-ARRAY-DIMENSION",	xgbj01_Get_Size_In_Lvals	},
     {	":LVAL-ADJUST-ARRAY",		xgbj03_Set_Size_In_Lvals	},
     {	":LVAL-AREF",			xgbj05_Get_Lval			},
     {	":LVAL-SETF",			xgbj07_Set_Lval			},
     {	":LVAL-INSERT",			xgbj08_Insert_Lval		},
     {	":LVAL-DELETE",			xgbj09_Delete_Lval		},

     {	":BYTE-ARRAY-DIMENSION",	xgbj10_Get_Size_In_Bytes	},
     {	":BYTE-ADJUST-ARRAY",		xgbj12_Set_Size_In_Bytes	},
     {	":BYTE-AREF",			xgbj14_Get_Byte			},
     {	":BYTE-SETF",			xgbj16_Set_Byte			},
     {	":BYTE-INSERT",			xgbj17_Insert_Byte		},
     {	":BYTE-DELETE",			xgbj18_Delete_Byte		},

     {	":INTEGER-ARRAY-DIMENSION",	xgbj19_Get_Size_In_Ints		},
     {	":INTEGER-ADJUST-ARRAY",	xgbj21_Set_Size_In_Ints		},
     {	":INTEGER-AREF",		xgbj23_Get_Int			},
     {	":INTEGER-SETF",		xgbj25_Set_Int			},
     {	":INTEGER-INSERT",		xgbj26_Insert_Int		},
     {	":INTEGER-DELETE",		xgbj27_Delete_Int		},

     {	":FLOAT-ARRAY-DIMENSION",	xgbj28_Get_Size_In_Floats	},
     {	":FLOAT-ADJUST-ARRAY",		xgbj30_Set_Size_In_Floats	},
     {	":FLOAT-AREF",			xgbj32_Get_Float		},
     {	":FLOAT-SETF",			xgbj34_Set_Float		},
     {	":FLOAT-INSERT",		xgbj35_Insert_Float		},
     {	":FLOAT-DELETE",		xgbj36_Delete_Float		},

     {	":DOUBLE-ARRAY-DIMENSION",	xgbj37_Get_Size_In_Doubles	},
     {	":DOUBLE-ADJUST-ARRAY",		xgbj39_Set_Size_In_Doubles	},
     {	":DOUBLE-AREF",			xgbj41_Get_Double		},
     {	":DOUBLE-SETF",			xgbj43_Set_Double		},
     {	":DOUBLE-INSERT",		xgbj44_Insert_Double		},
     {	":DOUBLE-DELETE",		xgbj45_Delete_Double		},

     {	NULL,				NULL				}
};


#endif



#ifdef MODULE_XLOBJ_C_CLNEW
    if (xgbj50_Is_A_Gobject(self)) {
        return (xgbj49_New(self,getivcnt(self,IVARTOTAL)));
    }
#endif


#ifdef MODULE_XLOBJ_C_OBSYMBOLS
    lv_xgbj           = getvalue(xlenter("CLASS-GOBJECT"));
    k_closed_gobject = getvalue(xlenter("CLASS-CLOSED-GOBJECT"));
#endif


#ifdef MODULE_XLOBJ_C_XLOINIT
    /* Create and initialize the 'Gobject' class-instance object: */
    k_closed_gobject = xlclass("CLASS-CLOSED-GOBJECT",0);
    lv_xgbj           = xlclass("CLASS-GOBJECT",0);

    /* Set the GOBJECT superclass to CLOSED-GOBJECT: */
    setivar(lv_xgbj,SUPERCLASS,k_closed_gobject);

    /* Not in table because it goes on k_closed_gobject */
    /* instead of on lv_xgbj:                            */
    xladdmsg(k_closed_gobject,":SHOW",funtab_offset(xgbj54_Show));

    /* Define basic gobject-manipulation messages. */
    /* We define these as messages but not xlisp   */
    /* fns because this way a subclass of gobject  */
    /* can (by redefining these messages) achieve  */
    /* a reasonable level of privacy.              */
    xgbj56_Enter_Messages( lv_xgbj,  xgbj_table );
#endif



#ifdef MODULE_XLPRIN_C_GLOBALS
#endif

#ifdef MODULE_XLPRIN_C_XLPRINT
case GOBJECT:
    putatm(fptr,"Gobject",vptr);
    break;
#endif



#ifdef MODULE_XLSYS_C_GLOBALS
extern LVAL a_gobject;
#endif



#ifdef MODULE_XLSYS_C_XTYPE
    case GOBJECT:	return (a_gobject);
#endif
