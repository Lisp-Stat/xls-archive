/* {{{ xgbj.c -- General oBJects: objects plus LVAL array and immediate array.
******************************************************************************
*
* Author:       Jeff Prothero
* Created:      90Nov14
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/*************************************************************************/
/* Gobjects ("General OBJECTs") are a general tool supporting the use of */
/* xlisp as an embedded application language.  Gobjects can do           */
/* everything a normal xlisp object can do, and under most circumstances */
/* look just like normal xlisp objects, but they also contain a          */
/* variable-length array of LVALs, and a separate variable-length array  */
/* of immediate byte data.                                               */
/*									 */
/* Gobjects serve as a common storage pool for the xlisp and C parts of  */
/* an application: Large, efficiency-critical structures such as pixel   */
/* maps can be stored in the byte-array portion of large gobjects. xlisp */
/* code can access the contents of the LVAL and imm arrays through the   */
/* functions provided in this file, and can garbage-collect them         */
/* normally.  Efficiency-critical operations can be coded in C and run at*/
/* full speed on the binary data in the gobjects.			 */
/*									 */
/* To make most effective use of gobjects, you should keep the state of  */
/* the system, and the main thread of control, entirely within xlisp,    */
/* calling state-free C functions only for the efficiency-critical parts */
/* of your application.                                                  */
/*									 */
/* To compile xlisp with support for gobjects, just uncomment            */
/* '#include "gobject/c/xgbj.h" in ~/xmodules.h, and recompile.          */
/*************************************************************************/

/* }}} */
/* {{{ --- history ---							*/

/* 93Nov03 jsp: Speed up xgbj48 by using memset(), not unoptimized loop.*/
/* 92Apr26 jsp: Add_Class_Variables, All_Live_Values, All_Live_Gobjects.*/
/* 91Aug07 jsp: Fixed Off-by-one (classptr) errors in			*/
/*			gobjsizeinbytes(x)				*/
/*			gobjlvalbase(x)					*/
/*			gobjimmbase(x)					*/
/*		Sigh.							*/
/* 90Nov14 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"
#include <string.h>					/* for memset() */

extern LVAL s_stdout;

/* }}} */

/* {{{ --- Statics ---							*/

FORWARD LOCAL LVAL xgbj47_Get_Gobject_And_Index();
FORWARD	LVAL xgbj06_Set_Lval();
LOCAL xgbj46_Check_Index();

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xgbj00_Get_Fix_Or_Flo_Num -- Get numeric argument.		*/

FLOTYPE xgbj00_Get_Fix_Or_Flo_Num( arg )
LVAL				   arg;
/*-
    Get numeric argument.
-*/
{
    if (fixp(  arg))   return (FLOTYPE) getfixnum(arg);
    if (floatp(arg))   return           getflonum(arg);
    xlerror("Need fix or flo",arg);
}


/* }}} */
/* {{{ xgbj01_Get_Size_In_Lvals --Get size-in-slots of gobject LVAL array.  */


LVAL xgbj01_Get_Size_In_Lvals()
/*-
    Get size-in-slots of gobject LVAL array.
-*/
{
    LVAL gobject;
    gobject = xlgagobject();
    xllastarg();
    return cvfixnum(getgobjarraylvals(gobject));
}

/* }}} */
/* {{{ xgbj03_Set_Size_In_Lvals - Set size-in-slots of gobject LVAL array.  */ 


LVAL xgbj02_Set_Size_In_Lvals( gobject, new_slots )
LVAL			       gobject;
int					new_slots;
/*-
    Set size-in-slots of gobject LVAL array.
-*/ 
{
    int old_slots    = getgobjarraylvals(gobject);
    int slots_delta  = new_slots - old_slots;
    int bytes_delta  = slots_delta * sizeof(LVAL);
    int slots_offset = 2 + getsize(gobject) + old_slots;
    int bytes_offset = slots_offset * sizeof(LVAL);
    
    if (new_slots < 0)   xlerror("negative array size",cvfixnum(new_slots));

    xgbj48_Adjust(     gobject, bytes_offset, bytes_delta );
    setgobjarraylvals( gobject, new_slots );

    /* Set new slots to NIL to keep garbage collector (etc) sane: */
    {   int i;
	for (i = old_slots;   i < new_slots;   ++i) {
	    xgbj06_Set_Lval( gobject, i, NIL );
    }	}

    return gobject;
}

LVAL xgbj03_Set_Size_In_Lvals()
/*-
    Set size-in-slots of gobject LVAL array.
-*/ 
{
    LVAL     gobject;
    LVAL     slots_L;
    int      slots_I;

    /* Get gobject and requested LVAL array size: */
    gobject = xlgagobject();
    slots_L = xlgafixnum();
    xllastarg();

    slots_I  = getfixnum(slots_L);

    return xgbj02_Set_Size_In_Lvals( gobject, slots_I );
}

/* }}} */
/* {{{ xgbj05_Get_Lval - Get nth LVAL from LVAL array in a gobject.         */

LVAL xgbj04_Get_Lval( gobject, index )
LVAL		      gobject;
int			       index;
/*-
    Get nth LVAL from LVAL array in a gobject.
-*/
{
    int slots = getgobjarraylvals( gobject );
    xgbj46_Check_Index( index, slots );
    return getelement( gobject, getsize(gobject)+index);
}

LVAL xgbj05_Get_Lval()
/*-
    Get nth LVAL from LVAL array in a gobject.
-*/
{
    return xgbj47_Get_Gobject_And_Index(xgbj04_Get_Lval);
}

/* }}} */
/* {{{ xgbj07_Set_Lval - Set nth LVAL in LVAL array in a gobject.		*/


LVAL xgbj06_Set_Lval( gobject, index, new_val )
LVAL		      gobject;
int			       index;
LVAL				      new_val;
/*-
    Set nth LVAL in LVAL array in a gobject.
-*/
{
    int slots = getgobjarraylvals( gobject );
    xgbj46_Check_Index( index, slots );
    setelement( gobject, getsize(gobject)+index, new_val );
    return new_val;
}

LVAL xgbj07_Set_Lval()
/*-
    Set nth LVAL in LVAL array in a gobject.
-*/
{
    LVAL gobject;
    LVAL n_as_lval;
    int  n_as_int;
    LVAL new_val;

    /* Get gobject and index n: */
    gobject   = xlgagobject();
    n_as_lval = xlgafixnum();
    new_val   = xlgetarg();
    xllastarg();

    n_as_int  = getfixnum( n_as_lval );

    return xgbj06_Set_Lval( gobject, n_as_int, new_val );
}

/* }}} */
/* {{{ xgbj08_Insert_Lval - Insert LVAL at nth slot in gobject LVAL array.	*/

LVAL xgbj08_Insert_Lval()
/*-
    Insert LVAL at nth slot in gobject LVAL array.
-*/
{
}

/* }}} */
/* {{{ xgbj09_Delete_Lval - Delete LVAL at nth slot in gobject LVAL array.  */


LVAL xgbj09_Delete_Lval()
/*-
    Delete LVAL at nth slot in gobject LVAL array.
-*/
{
}

/* }}} */
/* {{{ xgbj10_Get_Size_In_Bytes - Get size-in-bytes of gobject imm array.	*/

LVAL xgbj10_Get_Size_In_Bytes()
{
    LVAL gobject;
    gobject = xlgagobject();
    xllastarg();
    return cvfixnum( getgobjimmbytes(gobject) );
}

/* }}} */
/* {{{ xgbj12_Set_Size_In_Bytes - Set size-in-bytes of gobject imm array.	*/

LVAL xgbj11_Set_Size_In_Bytes( gobject, new_bytes )
LVAL			       gobject;
int					new_bytes;
/*-
    Set size-in-bytes of gobject imm array.
-*/
{
    int old_bytes    = getgobjimmbytes( gobject );
    int bytes_delta  = new_bytes - old_bytes;
    int bytes_offset = gobjsizeinbytes( gobject );
    
    if (new_bytes < 0)   xlerror("negative array size",cvfixnum(new_bytes));

    xgbj48_Adjust(   gobject, bytes_offset, bytes_delta );
    setgobjimmbytes( gobject, new_bytes );

    return gobject;
}

LVAL xgbj12_Set_Size_In_Bytes()
/*-
    Set size-in-bytes of gobject imm array.
-*/
{
    LVAL     gobject;
    LVAL     bytes_L;
    int      bytes_I;

    /* Get gobject and requested imm array size: */
    gobject = xlgagobject();
    bytes_L = xlgafixnum();
    xllastarg();

    bytes_I  = getfixnum(bytes_L);

    return xgbj11_Set_Size_In_Bytes( gobject, bytes_I );
}

/* }}} */
/* {{{ xgbj14_Get_Byte - Get nth byte in imm array in a gobject.		*/

LVAL xgbj13_Get_Byte( gobject, index )
LVAL			gobject;
int				 index;
/*-
    Get nth byte in imm array in a gobject.
-*/
{
    int           bytes = getgobjimmbytes( gobject );
    unsigned char*base  = (unsigned char*) gobjimmbase( gobject );
    xgbj46_Check_Index( index, bytes );
    return cvfixnum( base[index] );
}

LVAL xgbj14_Get_Byte()
/*-
    Get nth byte in imm array in a gobject.
-*/
{
    return xgbj47_Get_Gobject_And_Index(xgbj13_Get_Byte);
}

/* }}} */
/* {{{ xgbj16_Set_Byte - Set nth byte in imm array in a gobject.		*/

int xgbj15_Set_Byte( gobject, index, new_val )
LVAL		     gobject;
int			      index;
int				     new_val;
/*-
    Set nth byte in imm array in a gobject.
-*/
{
    int           bytes = getgobjimmbytes( gobject );
    unsigned char*base  = (unsigned char*) gobjimmbase( gobject );
    xgbj46_Check_Index( index, bytes );
    base[index] = new_val;
    return new_val;
}

LVAL xgbj16_Set_Byte()
/*-
    Set nth byte in imm array in a gobject.
-*/
{
    LVAL gobject;

    LVAL n_as_lval;    int  n_as_int;
    LVAL v_as_lval;    int  v_as_int;

    /* Get gobject and index n: */
    gobject   = xlgagobject();
    n_as_lval = xlgafixnum();
    v_as_lval = xlgafixnum(); /* Should I support chars too? */
    xllastarg();

    n_as_int  = getfixnum( n_as_lval );
    v_as_int  = getfixnum( v_as_lval );

    xgbj15_Set_Byte( gobject, n_as_int, v_as_int );

    return v_as_lval;
}

/* }}} */
/* {{{ xgbj17_Insert_Byte - Insert byte at nth byte slot in gobjectimm ary.	*/

LVAL xgbj17_Insert_Byte()
/*-
    Insert byte at nth byte slot in gobjectimm array.
-*/
{
}

/* }}} */
/* {{{ xgbj18_Delete_Byte - Delete byte: nth byte slot in gobject imm ary.	*/

LVAL xgbj18_Delete_Byte()
/*-
    Delete byte: nth byte slot in gobject imm ary.
-*/
{
}

/* }}} */
/* {{{ xgbj19_Get_Size_In_Ints - Get size-in-ints of gobject imm array.	*/


LVAL xgbj19_Get_Size_In_Ints()
/*-
    Get size-in-ints of gobject imm array.
-*/
{
    LVAL gobject;
    gobject = xlgagobject();
    xllastarg();
    return cvfixnum( getgobjimmbytes(gobject) / sizeof(int) );
}

/* }}} */
/* {{{ xgbj21_Set_Size_In_Ints - Set size-in-ints of gobject imm array.	*/

LVAL xgbj20_Set_Size_In_Ints( gobject, new_ints )
LVAL			      gobject;
int				       new_ints;
/*-
    Set size-in-ints of gobject imm array.
-*/
{
    int new_imm_bytes = new_ints * sizeof(int);
    int old_imm_bytes = getgobjimmbytes( gobject );
    int bytes_delta   = new_imm_bytes - old_imm_bytes;
    int bytes_offset = gobjsizeinbytes( gobject );
    
    if (new_imm_bytes < 0) {
        xlerror("negative array size",cvfixnum(new_imm_bytes));
    }

    xgbj48_Adjust(   gobject, bytes_offset, bytes_delta );
    setgobjimmbytes( gobject, new_imm_bytes );

    return gobject;
}

LVAL xgbj21_Set_Size_In_Ints()
/*-
    Set size-in-ints of gobject imm array.
-*/
{
    LVAL     gobject;
    LVAL     ints_L;
    int      ints_I;

    /* Get gobject and requested LVAL array size: */
    gobject = xlgagobject();
    ints_L  = xlgafixnum();
    xllastarg();

    ints_I  = getfixnum(ints_L);

    return xgbj20_Set_Size_In_Ints( gobject, ints_I );
}

/* }}} */
/* {{{ xgbj23_Get_Int - Get nth integer in imm array in a gobject.        */


LVAL xgbj22_Get_Int( gobject, index )
LVAL		       gobject;
int				index;
/*-
    Get nth integer in imm array in a gobject.
-*/
{
    int  ints  =    getgobjimmbytes( gobject ) / sizeof(int);
    int* base  = (int*) gobjimmbase( gobject );
    xgbj46_Check_Index( index, ints );
    return cvfixnum( base[index] );
}

LVAL xgbj23_Get_Int()
/*-
    Get nth integer in imm array in a gobject.
-*/
{
    return xgbj47_Get_Gobject_And_Index(xgbj22_Get_Int);
}

/* }}} */
/* {{{ xgbj25_Set_Int - Set nth integer in imm array in a gobject.	*/

int xgbj24_Set_Int( gobject, index, new_val )
LVAL		    gobject;
int			     index;
int				    new_val;
/*-
    Set nth integer in imm array in a gobject.
-*/
{
    int  ints  =    getgobjimmbytes( gobject ) / sizeof(int);
    int* base  = (int*) gobjimmbase( gobject );
    xgbj46_Check_Index( index, ints );
    base[index] = new_val;
    return new_val;
}

LVAL xgbj25_Set_Int()
/*-
    Set nth integer in imm array in a gobject.
-*/
{
    LVAL gobject;

    LVAL n_as_lval;    int  n_as_int;
    LVAL v_as_lval;    int  v_as_int;

    /* Get gobject and index n: */
    gobject   = xlgagobject();
    n_as_lval = xlgafixnum();
    v_as_lval = xlgafixnum(); /* Should I support chars too? */
    xllastarg();

    n_as_int  = getfixnum( n_as_lval );
    v_as_int  = getfixnum( v_as_lval );

    xgbj24_Set_Int( gobject, n_as_int, v_as_int );

    return v_as_lval;
}

/* }}} */
/* {{{ xgbj26_Insert_Int - Insert int: nth integer slot in gobject imm ary.	*/

LVAL xgbj26_Insert_Int()
/*-
    Insert int: nth integer slot in gobject imm array.
-*/
{
}

/* }}} */
/* {{{ xgbj27_Delete_Int - Delete int: nth integer slot in gobject imm ary.	*/

LVAL xgbj27_Delete_Int()
/*-
    Delete int: nth integer slot in gobject imm array.
-*/
{
}

/* }}} */
/* {{{ xgbj28_Get_Size_In_Floats - Get size-in-floats of gobject imm array.	*/

LVAL xgbj28_Get_Size_In_Floats()
/*-
    Get size-in-floats of gobject imm array.
-*/
{
    LVAL gobject;
    gobject = xlgagobject();
    xllastarg();
    return cvfixnum(getgobjimmbytes(gobject)/sizeof(float));
}

/* }}} */
/* {{{ xgbj30_Set_Size_In_Floats - Set size-in-floats of gobject imm array.	*/

LVAL xgbj29_Set_Size_In_Floats( gobject, new_floats )
LVAL 				gobject;
int					 new_floats;
/*-
    Set size-in-floats of gobject imm array.
-*/
{
    int new_imm_bytes = new_floats * sizeof(float);
    int old_imm_bytes = getgobjimmbytes( gobject );
    int bytes_delta   = new_imm_bytes - old_imm_bytes;
    int bytes_offset  = gobjsizeinbytes( gobject );
    
    if (new_imm_bytes < 0) {
        xlerror("negative array size",cvfixnum(new_imm_bytes));
    }

    xgbj48_Adjust(   gobject, bytes_offset, bytes_delta );
    setgobjimmbytes( gobject, new_imm_bytes );

    return gobject;
}

LVAL xgbj30_Set_Size_In_Floats()
/*-
    Set size-in-floats of gobject imm array.
-*/
{

    LVAL     gobject;
    LVAL     floats_L;
    int      floats_I;

    /* Get gobject and requested LVAL array size: */
    gobject  = xlgagobject();
    floats_L = xlgafixnum();
    xllastarg();

    floats_I = getfixnum( floats_L );

    return xgbj29_Set_Size_In_Floats( gobject, floats_I );
}

/* }}} */
/* {{{ xgbj32_Get_Float - Get nth float in imm array in a gobject.		*/

LVAL xgbj31_Get_Float( gobject, index )
LVAL		       gobject;
int				index;
/*-
    Get nth float in imm array in a gobject.
-*/
{
    int    floats =      getgobjimmbytes( gobject ) / sizeof(float);
    float* base   = (float*) gobjimmbase( gobject );
    xgbj46_Check_Index( index, floats );
    return cvflonum( base[index] );
}

LVAL xgbj32_Get_Float()
/*-
    Get nth float in imm array in a gobject.
-*/
{
    return xgbj47_Get_Gobject_And_Index(xgbj31_Get_Float);
}

/* }}} */
/* {{{ xgbj34_Set_Float - Set nth float in imm array in a gobject.		*/

int xgbj33_Set_Float( gobject, index, new_val )
LVAL		      gobject;
int			       index;
float 				      new_val;
/*-
    Set nth float in imm array in a gobject.
-*/
{
    int    floats=      getgobjimmbytes( gobject ) / sizeof(float);
    float* base  = (float*) gobjimmbase( gobject );
    xgbj46_Check_Index( index, floats );
    base[index]  = new_val;
    return new_val;
}

LVAL xgbj34_Set_Float()
/*-
    Set nth float in imm array in a gobject.
-*/
{
    LVAL gobject;

    LVAL n_as_lval;    int   n_as_int;
    LVAL v_as_lval;    float v_as_float;

    /* Get gobject and index n: */
    gobject   = xlgagobject();
    n_as_lval = xlgafixnum();
    v_as_lval = xlgetarg(); /* Support fixnums *and* flonums. */
    xllastarg();

    n_as_int  = getfixnum(      n_as_lval );
    v_as_float= xgbj00_Get_Fix_Or_Flo_Num( v_as_lval );

    xgbj33_Set_Float( gobject, n_as_int, v_as_float );

    return v_as_lval;
}

/* }}} */
/* {{{ xgbj35_Insert_Float - Insert at nth float slot in gobject imm array.	*/


LVAL xgbj35_Insert_Float()
/*-
    Insert at nth float slot in gobject imm array.
-*/
{
}

/* }}} */
/* {{{ xgbj36_Delete_Float - Delete at nth float slot in gobject imm array.	*/

LVAL xgbj36_Delete_Float()
/*-
    Delete at nth float slot in gobject imm array.
-*/
{
}

/* }}} */
/* {{{ xgbj37_Get_Size_In_Doubles - Get size-in-doubles of gobject imm ary.	*/

LVAL xgbj37_Get_Size_In_Doubles()
/*-
    Get size-in-doubles of gobject imm array.
-*/
{
    LVAL gobject;
    gobject = xlgagobject();
    xllastarg();
    return cvfixnum(getgobjimmbytes(gobject)/sizeof(double));
}


/* }}} */
/* {{{ xgbj39_Set_Size_In_Doubles - Set size-in-doubles of gobjectimm ary.	*/

LVAL xgbj38_Set_Size_In_Doubles( gobject, new_doubles )
LVAL				 gobject;
int					  new_doubles;
/*-
    Set size-in-doubles of gobjectimm array.
-*/
{
    int new_imm_bytes = new_doubles * sizeof(double);
    int old_imm_bytes = getgobjimmbytes( gobject );
    int bytes_delta   = new_imm_bytes - old_imm_bytes;
    int bytes_offset  = gobjsizeinbytes( gobject );
    
    if (new_imm_bytes < 0) {
        xlerror("negative array size",cvfixnum(new_imm_bytes));
    }

    xgbj48_Adjust(   gobject, bytes_offset, bytes_delta );
    setgobjimmbytes( gobject, new_imm_bytes );

    return gobject;
}

LVAL xgbj39_Set_Size_In_Doubles()
/*-
    Set size-in-doubles of gobjectimm array.
-*/
{

    LVAL     gobject;
    LVAL     doubles_L;
    int      doubles_I;

    /* Get gobject and requested LVAL array size: */
    gobject   = xlgagobject();
    doubles_L = xlgafixnum();
    xllastarg();

    doubles_I = getfixnum( doubles_L );

    return xgbj38_Set_Size_In_Doubles( gobject, doubles_I );
}


/* }}} */
/* {{{ xgbj41_Get_Double - Get nth double in imm array in a gobject.	*/

LVAL xgbj40_Get_Double( gobject, index )
LVAL			gobject;
int				 index;
/*-
    Get nth double in imm array in a gobject.
-*/
{
    int    doubles =      getgobjimmbytes( gobject ) / sizeof(double);
    double* base   = (double*) gobjimmbase( gobject );
    xgbj46_Check_Index( index, doubles );
    return cvflonum( base[index] );
}

LVAL xgbj41_Get_Double()
/*-
    Get nth double in imm array in a gobject.
-*/
{
    return xgbj47_Get_Gobject_And_Index(xgbj40_Get_Double);
}

/* }}} */
/* {{{ xgbj43_Set_Double - Set nth double in imm array in a gobject.	*/

int xgbj42_Set_Double( gobject, index, new_val )
LVAL		       gobject;
int				index;
double				       new_val;
/*-
    Set nth double in imm array in a gobject.
-*/
{
    int    doubles=      getgobjimmbytes( gobject ) / sizeof(double);
    double* base  = (double*) gobjimmbase( gobject );
    xgbj46_Check_Index( index, doubles );
    base[index]  = new_val;
    return new_val;
}

LVAL xgbj43_Set_Double()
/*-
    Set nth double in imm array in a gobject.
-*/
{
    LVAL gobject;

    LVAL n_as_lval;    int    n_as_int;
    LVAL v_as_lval;    double v_as_double;

    /* Get gobject and index n: */
    gobject    = xlgagobject();
    n_as_lval  = xlgafixnum();
    v_as_lval  = xlgetarg(); /* Support fixnums *and* flonums. */
    xllastarg();

    n_as_int   = getfixnum(      n_as_lval );
    v_as_double= xgbj00_Get_Fix_Or_Flo_Num( v_as_lval );

    xgbj42_Set_Double( gobject, n_as_int, v_as_double );

    return v_as_lval;
}

/* }}} */
/* {{{ xgbj44_Insert_Double - Insert at nth double slot in gobject imm ary.	*/

LVAL xgbj44_Insert_Double()
/*-
    Insert at nth double slot in gobject imm array.
-*/
{
}

/* }}} */
/* {{{ xgbj45_Delete_Double - Delete at nth double slot in gobject imm ary.	*/

LVAL xgbj45_Delete_Double()
/*-
    Delete at nth double slot in gobject imm array.
-*/
{
}

/* }}} */
/* {{{ xgbj46_Check_Index -- Check index against array bound.		*/

LOCAL xgbj46_Check_Index( index, bound )
int		          index;
int			         bound;
/*-
    Check index against array bound.
-*/
{
    if (index < 0  ||  index >= bound) {
        xlerror("bad index",cvfixnum(index));
    }
}

/* }}} */
/* {{{ xgbj47_Get_Gobject_And_Index -- Get object and index into it.	*/

LOCAL LVAL xgbj47_Get_Gobject_And_Index( fn )
LVAL 				       (*fn)();
/*-
    Get object and index into it.
-*/
{
    LVAL gobject;
    LVAL n_as_lval;
    int  n_as_int;

    /* Get gobject and index n: */
    gobject   = xlgagobject();
    n_as_lval = xlgafixnum();
    xllastarg();

    n_as_int   = getfixnum( n_as_lval );

    return (*fn)( gobject, n_as_int );
}

/* }}} */
/* {{{ xgbj48_Adjust -- Expand or contract a gobject.			*/


xgbj48_Adjust( gobject, byte_offset, byte_delta )
LVAL gobject;     /* gobject to insert or delete bytes from.   */
int  byte_offset; /* Offset relative to &gobject->v_vdata[-2]. */
int  byte_delta;  /* If >0, insert zero bytes AFTER  offset.   */
                  /* If <0, delete      bytes BEFORE offset.   */
/*-
    Expand or contract a gobject.
-*/
{

    LVAL*     vector;
    LVAL*     new_vector;
    unsigned old_size_in_bytes;
    unsigned new_size_in_bytes;
    register char* src;
    register char* dst;
    register int   i;

    /**************************************************/
    /* Figure new gobject body size and realloc() it. */
    /* If body is shrinking, we need to slide stuff   */
    /* zeroward *before* we realloc.                  */
    /* If body is expanding, we need to slide stuff   */
    /* zerofard *after* we realloc.                   */
    /**************************************************/

    old_size_in_bytes = gobjsizeinbytes( gobject );
    new_size_in_bytes = old_size_in_bytes + byte_delta;

    /* gobject must always have the two hidden size slots: */
    if (new_size_in_bytes < 2*sizeof(LVAL)) {
	xlerror("negative gobject size requested",cvfixnum(byte_delta));
    }

    /* Get pointer to real beginning of ram block */
    /* (including the two hidden size slots):     */
    vector = &gobject->n_vdata[-2];

    if (byte_delta >= 0) {

        /* Sanity check -- don't insert past end or before */
        /* beginning of our ram block (clobbering other    */
        /* objects):                                       */
        if (byte_offset > old_size_in_bytes ||
            byte_offset < 2*sizeof(LVAL)
        ) {
   	    xlerror("bad gobject insert",cvfixnum(byte_offset));
        }

    } else /* byte_delta < 0 */ {

        /* Sanity check -- don't delete past end or before */
        /* beginning of our ram block (clobbering other    */
        /* objects):                                       */
        if (byte_offset                > old_size_in_bytes ||
            byte_offset -(-byte_delta) < 2*sizeof(LVAL)
        ) {
   	    xlerror("bad gobject delete",cvfixnum(byte_offset));
        }

        /* Slide zeroward to close up hole: */
        src = ((char*)vector)   +  byte_offset;
        dst = src               -(-byte_delta);
        i   = old_size_in_bytes -  byte_offset;
        while (--i >= 0)   *dst++ = *src++;
    }

    /* Extend/contract our ram block: */
    new_vector = (LVAL*) realloc( vector, new_size_in_bytes );

    if (new_vector == NULL) {
	char buf[ 132 ];
	sprintf( buf, "Couldn't allocated %d-byte vector?!", new_size_in_bytes );
        xlfail(buf);
    }
    gobject->n_vdata = new_vector+2;

    if (byte_delta > 0) {

	/* Slide zerofard to open up hole: */
	dst = ((char*)new_vector) + new_size_in_bytes;
	src = dst - byte_delta;
	i   = old_size_in_bytes - byte_offset;
	while (--i >= 0)   *--dst = *--src;

	/* Fill hole with zero bytes: */
#ifdef OLD_SLOW
	i   = byte_delta;
	while (--i >= 0)   *--dst = 0;
#else
	memset( /*where:*/dst-byte_delta, /*what:*/0, /*count:*/byte_delta );
#endif
    }
}

/* }}} */
/* {{{ xgbj49_New -- Allocate and initialize a new gobject.			*/

LVAL xgbj49_New( class, size )
LVAL		 class;
int			size;
/*-
    Allocate and initialize a new gobject.
-*/
{
    LVAL val;
    val = newvector(size+3); /* +3 for class slot + 2 size slots */
    val->n_type  = GOBJECT;

    /* Create two hidden slots, -1 & -2. */
    val->n_vdata = &val->n_vdata[2];
    val->n_vsize = size+1;   /* +1 for class slot. */

    setelement(val,0,class);
    setgobjimmbytes(val,0);
    setgobjarraylvals(val,0);

    return val;
}

/* }}} */
/* {{{ xgbj50_Is_A_Gobject - return TRUE iff class is a gobject [sub]class. */

int xgbj50_Is_A_Gobject( class )
LVAL			 class;
/*-
    Return TRUE iff class is a gobject [sub]class.
-*/
{
    do {
	extern LVAL  k_closed_gobject;
        if (class == k_closed_gobject)   return TRUE;
    } while (class = getivar(class,SUPERCLASS));
    return FALSE;
}

/* }}} */
/* {{{ xgbj51_Show_Instance_Variables -- Show instance var of gobject.    	*/

LVAL xgbj51_Show_Instance_Variables( self, fptr )/* CALLED BY xtrans.c ETC */
LVAL 				     self, fptr;
/*-
    Show instance variables of a gobject. This is a clone of
    xlobj.c:obshow, but for gobjects instead of objects.
-*/
{
    LVAL class, names;
    int ivtotal,i,n;

    /* get the gobject's class */
    class = getclass(self);

    /* print the gobject and class */
    xlputstr(fptr,"Gobject is ");
    xlprint(fptr,self,TRUE);
    xlputstr(fptr,", Class is ");
    xlprint(fptr,class,TRUE);
    xlterpri(fptr);

    /* print the gobject's instance variables */
    for (; class; class = getivar(class,SUPERCLASS)) {
	names = getivar(class,IVARS);
	ivtotal = getivcnt(class,IVARTOTAL);
	for (n = ivtotal - getivcnt(class,IVARCNT); n < ivtotal; ++n) {
	    xlputstr(fptr,"  ");
	    xlprint(fptr,car(names),TRUE);
	    xlputstr(fptr," = ");
	    xlprint(fptr,getivar(self,n),TRUE);
	    xlterpri(fptr);
	    names = cdr(names);
	}
    }

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xgbj52_Show_Lval_Vector -- Print gobject's lval vector to stdout.	*/

LVAL xgbj52_Show_Lval_Vector( self, fptr )
LVAL			      self, fptr;
/*-
    Print gobject's lval vector to stdout.
    CALLED BY xtrans.c ETC.
-*/
{
    int i,n;

    /* Print the gobject's LVAL vector: */
    n = getgobjarraylvals( self );
    for (i = 0;   i < n;   ++i) {
        char buf[32];
        sprintf(buf,"  lval[%2d] = ",i);
	xlputstr(fptr,buf);
        xlprint( fptr, xgbj04_Get_Lval(self,i), TRUE );
	xlterpri(fptr);
    }

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xgbj53_Show_Byte_Vector -- Print gobject's bytevector to stdout.	*/

LVAL xgbj53_Show_Byte_Vector( self, fptr )
LVAL			      self, fptr;
/*-
    Print gobject's bytevector to stdout.
-*/
{
    int i,n;

    /* Print the gobject's BYTE vector: */
    n = getgobjimmbytes( self );
    for (i = 0;   i < n;   ++i) {
        char buf[32];
        unsigned char* base = (unsigned char*)gobjimmbase(self);
        sprintf(buf,"  byte[%2d] = %02x",i,base[i]);
	xlputstr(fptr,buf);
	xlterpri(fptr);
    }

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xgbj54_Show -- Print gobject to stdout.				*/

LVAL xgbj54_Show()
/*-
    Print gobject to stdout.
-*/
{
    LVAL self,fptr,class,names;
    int ivtotal,i,n;

    /* get self and the file pointer */
    self = xlgaobject();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);
    xgbj53_Show_Byte_Vector(self,fptr);

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xgbj55_Get_Fix_Pair_Initializer -- Get '(12 45) initializer.		*/

xgbj55_Get_Fix_Pair_Initializer( x,  y )
int                             *x, *y;
/*-
    Get '(12 45) initializer.
-*/
{
    LVAL list  = xlgalist();
    LVAL xcons = list;
    LVAL ycons;
    LVAL coord;

    xcons = list;
    if (!consp(xcons))        xlbadinit(list);

    ycons = cdr(xcons);
    if (!consp(ycons))        xlbadinit(list);

    coord = car(xcons);
    if (!fixp(coord ))        xlbadinit(list);
    *x = getfixnum(coord);

    coord = car(ycons);
    if (!fixp(coord ))        xlbadinit(list);
    *y = getfixnum(coord);

    if (cdr(ycons) != NULL)   xlbadinit(list);
}

/* }}} */
/* {{{ xgbj56_Enter_Messages -- Enter a list of messages into a class.	*/

LOCAL struct xgbj_msg {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
};
xgbj56_Enter_Messages( our_class,  p )
LVAL                   our_class;
struct xgbj_msg *                  p;
/*-
    Enter a list of messages into given class.
-*/
{
    while (p->gs_msg_name != NULL) {
        xladdmsg(our_class,p->gs_msg_name,funtab_offset(p->gs_subr));
        ++p;
    }
}

/* }}} */
/* {{{ xgbj57_Add_Instance_Variable -- Add an instance var to a class.      */

xgbj57_Add_Instance_Variable( clas, var_name )
LVAL		      	      clas;
char*				    var_name;
/*-
    -- Add an instance var to a class.
-*/
{
    xladdivar(clas,var_name);
    setivar(clas,IVARCNT,  cvfixnum((FIXTYPE)(getfixnum(getivar(clas,IVARCNT  )))+1));
    setivar(clas,IVARTOTAL,cvfixnum((FIXTYPE)(getfixnum(getivar(clas,IVARTOTAL)))+1));
}

/* }}} */
/* {{{ xgbj58_Create_Class -- Create a class.				*/

LVAL xgbj58_Create_Class( name, superclass )
char*			  name;
LVAL				superclass;
/*-
    -- Create a subclass of given class
-*/
{
    /* This is a just slight generalization of xlobj.c:xlclass(): */
    LVAL sym,cls;
    int  vcnt = getfixnum(getivar(superclass,IVARTOTAL));

    /* create the class */
    sym = xlenter(name);
    cls = newobject(cls_class,CLASSSIZE);
    setvalue(sym,cls);

    /* set the instance variable counts */
    setivar(cls,IVARCNT,cvfixnum((FIXTYPE)0));
    setivar(cls,IVARTOTAL,cvfixnum((FIXTYPE)vcnt));

    /* set the superclass pointer: */
    setivar(cls,SUPERCLASS,superclass);

    /* return the new class */
    return (cls);
}

/* }}} */
/* {{{ xgbj59_Add_Class_Variables -- Add list of class vars to (new) class. */

xgbj59_Add_Class_Variable( self, cvars )
LVAL		      	   self; /* class */
LVAL                             cvars;
{   /* Half-hearted validation: */
    if (!consp(cvars))   xlerror("Class var list isn't",cvars);
    /* Little fragment stolen from xlobj.c:clisnew(): */
    setivar(self,CVARS,cvars);
    setivar(self,CVALS,newvector(listlength(cvars)));
}

/* }}} */
/* {{{ xgbj60_All_Live_Values -- Call given C fn on all live lisp values.   */

xgbj60_All_Live_Values( fn, fa )
int                   (*fn)();
int                         fa;
{   /* This fn is adapted from xldmem.c:sweep() :)     */
    /* Unless you're interested in processing garbage  */
    /* for some reason, it's an excellent idea to call */
    /* gc() immediately before calling this fn, since  */
    /* by live we just mean not yet garbage-collected. */
    extern SEGMENT *segs;	/* List of all existing segments. */
    extern SEGMENT *fixseg;	/* Segment of statically allocated small ints. */
    extern SEGMENT *charseg;	/* Segment of statically allocated asci chars. */
    SEGMENT *seg;
    LVAL p;
    int n;

    /* Over (almost!) all segments of lisp values: */
    for (seg = segs; seg; seg = seg->sg_next) {
	if      (seg == fixseg ) continue; /* don't process the fixnum segment */
	else if (seg == charseg) continue; /* don't process the char   segment */

	/* Over all lisp values in current segment: */
	p = &seg->sg_nodes[0];
	for (n = seg->sg_size; --n >= 0; ++p) {
	    if (p->n_type != FREE) {
		int result = (*fn)(fa, p );
		if (result)  return result;
	    }
        }
    }
    return 0;
}

/* }}} */
/* {{{ xgbj64_All_Live_Gobjects -- Call given C fn on all live gobjects.    */

struct xgbj62_Rec {
    int (*fn)();
    int   fa;
};
xgbj63_All_Live_Gobjects_Fn( r, lv )
struct xgbj62_Rec *          r;
LVAL                            lv;
{
    if (gobjectp(lv))  return (*r->fn)( r->fa, lv );
    return 0; /* Continue iteration */
}
xgbj64_All_Live_Gobjects( fn, fa )
int                     (*fn)();
int                           fa;
{   struct xgbj62_Rec r;
    r.fn = fn;
    r.fa = fa;
    return xgbj60_All_Live_Values( xgbj63_All_Live_Gobjects_Fn, &r );
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */


