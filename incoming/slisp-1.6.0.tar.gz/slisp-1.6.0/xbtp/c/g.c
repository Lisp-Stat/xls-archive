/* I suspect some of these aren't needed any more: */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <strings.h>
#include <device.h>
#include <fcntl.h>
#include <termio.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#define ERR (-1)
#define loop for(;;)

#ifndef FALSE
#define FALSE (0)
#endif

main() {

    winopen("ghost.c");
    winconstraints();/*91Jan10jsp*/
    winconstraints();/*91Jan10jsp*/
    RGBmode();
    gconfig();
    attachcursor(GHOSTX,GHOSTY);
#ifdef BLICK
    for (;;) {
	int x, y, b;
        xbtp32_Bitpad1_Read_State( &x, &y, &b );
        setvaluator(GHOSTX,x,0,2000);
        setvaluator(GHOSTY,y,0,2000);
	if (b) break;
    }
    attachcursor(GHOSTX,GHOSTY);
#endif
}
