
/* I suspect some of these aren't needed any more: */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <strings.h>
#include <device.h>
#include <fcntl.h>
#include <termio.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#define ERR (-1)
#define loop for(;;)

#ifndef FALSE
#define FALSE (0)
#endif

/* fd for serial port we communicate with Panasonic on: */
static xbtp00_Port = FALSE;

static char* xbtp05_Init_Port( devName )
char *                         devName; /* /dev/ttyd2 or /dev/ttyd3 */
{
    int fd;
    struct termio   trmStruct;

    /* Open serial port to recorder: */
    fd = open( devName, O_RDWR );
    if (fd < 0) {

        return "Couldn't open serial port";
    }

    /******************************************************/
    /* Suppress all handling possible -- in particular,   */
    /* line blocking, because protocol is single 	  */
    /* char both directions, with no returns or newlines. */
    /******************************************************/

    /* Read (part of) the current line status: */
    if (ioctl(fd,TCGETA,&trmStruct)==ERR){
        close( fd );
        return "Couldn't ioctl(TCGETA) serial port";
    }

    /* Turn off all the knobs we can reach: */
    trmStruct.c_iflag &= ~( IUCLC  | IXON  | IXOFF                  );
    trmStruct.c_oflag &= ~( OPOST  | OLCUC | ONLCR | OCRNL | OFILL  );
    trmStruct.c_lflag &= ~( ICANON | ECHO  | ECHOE | ECHOK | ECHONL );

trmStruct.c_cflag = B9600 | CS8 | /*CSTOPB |*/ CREAD | /*PARENB |*/ CLOCAL;

#ifdef CRIB
/* set tty to 9600 baud 8 bits even parity two stop bits */
termio.c_iflag = 0;
termio.c_oflag = 0;
termio.c_cflag = B9600 | CS8 | CSTOPB | CREAD | PARENB | CLOCAL;
termio.c_lflag = 0;
termio.c_line = 0;
termio.c_cc[0] = 0;
#endif


    trmStruct.c_cc[ VMIN  ] = 0;
    trmStruct.c_cc[ VTIME ] = 1;

    /* Transmit new state back to Unix: */
    if (ioctl(fd,TCSETA,&trmStruct)==ERR){
        close( fd );
        return "Couldn't ioctl(TCSETA) serial port";
    }
    xbtp00_Port = fd;
    return NULL;
}

static xbtp10_Init_Bitpad()
{
    char c = '@';
    write( xbtp00_Port, &c, 1 );
    c = 'f';
    write( xbtp00_Port, &c, 1 );
}

static xbtp20_Wait( time_out )
int                 time_out;
{
    if (!xbtp00_Port)   return ERR;
    loop {
        char input;
        int charsRead = read( xbtp00_Port, &input, 1 );
        if (charsRead == 0   &&   !--time_out) {
printf("No input!\n");
            return ERR;
        }
        if (charsRead == 1)   return input;
        if (charsRead > 1) { printf("charsRead > 1 ?!@#\n"); exit(1); }
    }
}

xbtp09_Read_Input( time_out )
int                time_out;
{
    if (!xbtp00_Port)   return ERR;
    loop {
        char input;
        int charsRead = read( xbtp00_Port, &input, 1 );
        if (charsRead == 0   &&   !--time_out) {
	    return 0;
        }
        if (charsRead == 1) {
            return input;
	}
        if (charsRead > 1) { printf("charsRead > 1 ?!@#\n"); exit(1); }
    }
}
xbtp92_Bitpad1_Read_Int() {
    int  i;
    int  c = 0;
    int  v = 0;
    for (i = 4;   i --> 0; ) {
       c = xbtp09_Read_Input(100); 
       if (c == '\n' || c == '\r') { ++i; continue; }
       if (!isdigit(c))  return -1;
       v = v*10 + (c-'0');
    } 
    return v;
}
xbtp32_Bitpad1_Read_State( px, py, pb )
int                       *px,*py,*pb;
{
    /*********************************************/
    /* Read a string of the form dddd,dddd,x<nl> */ 
    /*********************************************/
    for (;;) {

	/* Wait until at the end of one coordinate set: */ 
	while (xbtp09_Read_Input(100) != '\n');

	/* Read a string of the form dddd,dddd,x<nl> */ 
	if (0 > (*px = xbtp92_Bitpad1_Read_Int()))  continue;
	if (xbtp09_Read_Input(100) != ',')          continue;
	if (0 > (*py = xbtp92_Bitpad1_Read_Int()))  continue;
	if (xbtp09_Read_Input(100) != ',')          continue;
	*pb = (xbtp09_Read_Input(100) != '0');
	return 0;
    }
}
main() {
    char* errmsg = xbtp05_Init_Port( "/dev/ttyd2" );
    if (errmsg) { puts(errmsg); exit(1); }
    xbtp10_Init_Bitpad();
    for (;;) {
	int i = xbtp20_Wait( 100 );
	printf("%c[%d]",i,i);
    }
#ifdef NEVER
    winopen("test.c");
    winconstraints();/*91Jan10jsp*/
    winconstraints();/*91Jan10jsp*/
    RGBmode();
    gconfig();
    attachcursor(GHOSTX,GHOSTY);

    for (;;) {
	int x, y, b;
        xbtp32_Bitpad1_Read_State( &x, &y, &b );
        setvaluator(GHOSTX,x,0,2000);
        setvaluator(GHOSTY,y,0,2000);
	if (b) break;
    }
    attachcursor(CURSORX,CURSORY);
#endif
}
