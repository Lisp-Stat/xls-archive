/* {{{ xbtp.c -- Driver for data tablets.				*/
/************************************************************************
*
* Author:       Jeff Prothero
* Created:      93Jun08
* Language:     C
* Package:      N/A
*
* Copyright (c) 1994, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
**************************************************************************
*/

/* }}} */

/* {{{ --- overview ---							*/

/*

Just enough interface to use a data tablet reasonably.  Data tablets
are treated as being logically one-button, to increase application
code portability between devices -- I think data tablet pens let users
use the precision grip and do better work more comfortably than the
power grip which large pucks force on one, and would like users to be
free to choose the pen over the puck for any application coded in this
system.

I once saw a tablet puck with fifteen buttons, I think?  Sheesh.  I'm
amazed someone doesn't just glue a trackball under their keyboard and
slide _it_ around...

Anyhow, this module allows one to discover where the puck is and what
the single logical button on it is up to, which is quite enough for
me.  Please don't mail me "improved" versions that return which of
fifteen buttons are pressed :).

*/

/* }}} */

/* {{{ --- history ---							*/

/*
 * 93Aug25 jsp: Wacom tablet support.
 * 93Jun08 jsp: Created.
 */

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

/* I suspect some of these aren't needed any more: */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <strings.h>
#include <device.h>
#include <fcntl.h>
#ifdef OLD
#include <termio.h>
#else
/* POSIX wants us to use termios not termio: */
#include <termios.h>
#endif
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#define ERR (-1)
#define loop for(;;)

extern LVAL k_bitpad1;
extern LVAL k_blockuntilinputarrives;
extern LVAL k_currentstate;
extern LVAL k_downclick;
extern LVAL k_drag;
extern LVAL k_get;
extern LVAL k_initializefromfile;
extern LVAL k_initialstate;
extern LVAL k_label;
extern LVAL k_wacom_fat_stylus;
extern LVAL k_wacom_thin_stylus_tip;
extern LVAL k_wacom_thin_stylus_side;
extern LVAL k_protocol;
extern LVAL k_select;
extern LVAL k_subtree;
extern LVAL k_summasketch2;
extern LVAL k_upclick;
extern LVAL lv_xlgt;
extern LVAL s_currentstate;
extern LVAL s_initialstate;
extern LVAL s_strcat;
extern LVAL s_subtree;
extern LVAL s_xbtppuckmoved;
extern LVAL s_xg3dmousecol;
extern LVAL s_xg3dmouserow;
extern LVAL s_xg3dmousepressure;
extern LVAL s_xg3dmousestate;

static char* xbtp25_Command();

/* fd for serial port we communicate with Panasonic on: */
static xbtp00_Port = FALSE;

/* Type of data tablet we're talking to: */
#define XBTP_BITPAD1                    (1)
#define XBTP_SUMMASKETCH2               (2)
#define XBTP_WACOM_PRESSURE_STYLUS      (3) /* Fat  stylus, tip pressure. */
#define XBTP_WACOM_STANDARD_STYLUS_TIP  (4) /* Thin stylus, tip  switch.  */
#define XBTP_WACOM_STANDARD_STYLUS_SIDE (5) /* Thin stylus, side switch.  */

static int xbtp01_protocol = XBTP_BITPAD1;

#define XBTP_UP		(0)
#define XBTP_DOWN	(1)
static int xbtp02_last_state     = XBTP_UP;

/* For xsk3-morpho.lsp, we do this at the lisp level: */
static int xbtp03_stream_spacing =  1;

static float xbtp04_Pen_Threshold = 0.5;

/* }}} */

/* {{{ xbtp06_Initialize_Fn -- Initialize bitpad serial port.		*/

static char* xbtp05_Initialize( devName )
char *                          devName; /* /dev/ttyd2 or /dev/ttyd3 */
{
    extern LVAL true;
    int fd;
    struct termios trmStruct;

    /* Open serial port to recorder: */
    fd = open( devName, O_RDWR | O_NOCTTY );
    if (fd < 0) {
        return "Couldn't open serial port";
    }

    /******************************************************/
    /* Suppress all handling possible:			  */
    /******************************************************/
    /* Stevens says POSIX says to use termios not termio. */

    /* Read (part of) the current line status: */
    if (tcgetattr(fd,&trmStruct)==ERR){
        close( fd );
        return "Couldn't tcgetattr() serial port";
    }



    /* Turn off all the knobs we can reach: */

    #ifdef IUCLC
    trmStruct.c_iflag &= ~IUCLC;
    #endif

    #ifdef IXON
    trmStruct.c_iflag &= ~IXON;
    #endif

    #ifdef IXOFF
    trmStruct.c_iflag &= ~IXOFF;
    #endif

    #ifdef ISTRIP
    trmStruct.c_iflag &= ~ISTRIP;
    #endif

    #ifdef INPCK
    trmStruct.c_iflag &= ~INPCK;
    #endif

    #ifdef INLCR
    trmStruct.c_iflag &= ~INLCR;
    #endif

    #ifdef IGNPAR
    trmStruct.c_iflag &= ~IGNPAR;
    #endif

    #ifdef IGNCR
    trmStruct.c_iflag &= ~IGNCR;
    #endif

    #ifdef ICRLN
    trmStruct.c_iflag &= ~ICRNL;
    #endif


    #ifdef OPOST
    trmStruct.c_oflag &= ~OPOST;
    #endif

    #ifdef OLCUC
    trmStruct.c_oflag &= ~OLCUC;
    #endif

    #ifdef ONLCR
    trmStruct.c_oflag &= ~ONLCR;
    #endif

    #ifdef OCRNL
    trmStruct.c_oflag &= ~OCRNL;
    #endif

    #ifdef OFILL
    trmStruct.c_oflag &= ~OFILL;
    #endif


    #ifdef ICANON
    trmStruct.c_lflag &= ~ICANON;
    #endif

    #ifdef ECHO
    trmStruct.c_lflag &= ~ECHO;
    #endif

    #ifdef ECHOE
    trmStruct.c_lflag &= ~ECHOE;
    #endif

    #ifdef ECHOK
    trmStruct.c_lflag &= ~ECHOK;
    #endif

    #ifdef ECHONL
    trmStruct.c_lflag &= ~ECHONL;
    #endif

    #ifdef ECHOCTL
    trmStruct.c_lflag &= ~ECHOCTL;
    #endif


    /* Select eight bits per byte: */
    #ifdef CSIZE
    trmStruct.c_cflag &= ~CSIZE;
    trmStruct.c_cflag |=  CS8;
    #endif

    trmStruct.c_cc[ VMIN  ] = 0;
    trmStruct.c_cc[ VTIME ] = 1;

    /* Make sure device is at 9600 baud: */
    if (cfsetospeed( &trmStruct, B9600 )
    ||  cfsetispeed( &trmStruct, B9600 )
    ){
        close( fd );
        return "Couldn't set serial port to 9600 baud";
    }


    /* Transmit new state back to Unix: */
    if (tcsetattr(fd,TCSAFLUSH,&trmStruct)==ERR){
        close( fd );
        return "Couldn't tcsetattr() serial port";
    }



    xbtp00_Port = fd;

    switch (xbtp01_protocol) {

    case XBTP_BITPAD1:
	xbtp31_Bitpad1_Initialize(      );
	break;

    case XBTP_SUMMASKETCH2:
	xbtp41_SummaSketch2_Initialize( );
	break;

    case XBTP_WACOM_PRESSURE_STYLUS:
        xbtp51_WacoP_Initialize(        );
	break;

    case XBTP_WACOM_STANDARD_STYLUS_TIP:
        xbtp61_WacoST_Initialize(        );
	break;

    case XBTP_WACOM_STANDARD_STYLUS_SIDE:
        xbtp71_WacoSS_Initialize(        );
	break;
    }

    return NULL;
}
LVAL xbtp06_Initialize_Fn() {
    
    char* result;
    char*    err = "Bad xbtp-initialize arg";
    char*    dev = "/dev/ttyd2";
    float    sens= 0.5;
    if (moreargs()) {
	LVAL  lv_dev = xlgastring();
        dev = (char*)getstring( lv_dev );
    }
    if (moreargs()) {
	LVAL lv_key  = xlgasymbol();
	if  (lv_key != k_protocol) xlerror(err,lv_key);

	lv_key = xlgasymbol();
	if        (lv_key == k_bitpad1     ) {
	    xbtp01_protocol = XBTP_BITPAD1;
	} else if (lv_key == k_summasketch2) {
	    xbtp01_protocol = XBTP_SUMMASKETCH2;
	} else if (lv_key == k_wacom_fat_stylus) {
	    xbtp01_protocol = XBTP_WACOM_PRESSURE_STYLUS;
	} else if (lv_key == k_wacom_thin_stylus_tip) {
	    xbtp01_protocol = XBTP_WACOM_STANDARD_STYLUS_TIP;
	} else if (lv_key == k_wacom_thin_stylus_side) {
	    xbtp01_protocol = XBTP_WACOM_STANDARD_STYLUS_SIDE;
        } else {
	    xlerror(err,lv_key);
	}
    }
    xllastarg();
    result = xbtp05_Initialize( dev, sens );
    if (result)   xlfail( result );
    return NIL;
}

/* }}} */
/* {{{ xbtp08_Flush_Input -- Eat all pending input on serial line.	*/

xbtp08_Flush_Input() {
#ifdef OLD
    loop {
        char c;
        int  charsRead = read( xbtp00_Port, &c, 1 );
        if (!charsRead)  break;
    }
#else
#ifdef OLD
    /* The SysV solution: */
    if (ioctl(xbtp00_Port,TCFLSH,0)==ERR){
        xlfail("Couldn't ioctl(TCFLSH) serial port");
    }
#else
    /* The POSIX solution: */
    if (tcflush(xbtp00_Port,TCIFLUSH)) {
        xlfail("Couldn't tcflush(TCIFLUSH) serial port");
    }
#endif
#endif
}

/* }}} */
/* {{{ xbtp09_Read_Input -- Read one input char.			*/

xbtp09_Read_Input( time_out )
int                time_out;
{
    if (!xbtp00_Port)   return ERR;
    loop {
        char input;
        int charsRead = read( xbtp00_Port, &input, 1 );
        if (charsRead == 0   &&   !--time_out) {
	    return -1;
        }
        if (charsRead == 1) {
            return input;
	}
        if (charsRead > 1) { printf("charsRead > 1 ?!@#\n"); exit(1); }
    }
}

/* }}} */
/* {{{ xbtp11_Read_State_Fn -- Read puck location+state.		*/

LVAL xbtp11_Read_State_Fn() {
    
    extern LVAL true;/*xlglob.c*/
    extern int xcmr05_Frame_Number;
    static int frame_Of_Last_Mouse_Event = -1;
    static int last_x=0;
    static int last_y=0;
    static int last_z=0;
    static int last_b=0;
    int  block_until_input_arrives = TRUE;
    LVAL state;
    int  x = last_x;
    int  y = last_y;
    int  z = last_z;
    int  b = last_b;

    while (moreargs()) {
        LVAL lv_key = xlgasymbol();
	if (lv_key == k_blockuntilinputarrives) {
            block_until_input_arrives = !null(xlgetarg());
        } else {
	    xlerror("Bad XBTP-READ-STATE keyword:",lv_key);
    }	}
    if (!xbtp00_Port) xlerror("XBTP-READ-STATE: Uninitialized!");

    do {
	int err;

	switch (xbtp01_protocol) {

	case XBTP_BITPAD1:
	    err=xbtp32_Bitpad1_Read_State(     &x,&y,&z,&b);
	    break;

	case XBTP_SUMMASKETCH2:
	    err=xbtp42_SummaSketch2_Read_State(&x,&y,&z,&b);
	    break;

	case XBTP_WACOM_PRESSURE_STYLUS:
	    err=xbtp52_WacoP_Read_State(&x,&y,&z,&b);
	    break;

	case XBTP_WACOM_STANDARD_STYLUS_TIP:
	    err=xbtp62_WacoST_Read_State(&x,&y,&z,&b);
	    break;

	case XBTP_WACOM_STANDARD_STYLUS_SIDE:
	    err=xbtp72_WacoSS_Read_State(&x,&y,&z,&b);
	    break;

	default:
 	    fputs("xbtp11_Read_State_Fn: internal err\n",stderr);
	    abort();
	}
	/* Hack to handle no data tablet data: */
	if (err == -1) {
	    x     = last_x;
	    y     = last_y;
	    z     = last_z;
	    b     = last_b;
	    state = NIL;
	    break;
        }

	switch ((b         << 1) | xbtp02_last_state) {
	case    (XBTP_UP   << 1) | XBTP_UP    : state = k_select   ;  break;
	case    (XBTP_DOWN << 1) | XBTP_UP    : state = k_downclick;  break;
	case    (XBTP_UP   << 1) | XBTP_DOWN  : state = k_upclick  ;  break;
	case    (XBTP_DOWN << 1) | XBTP_DOWN  : state = k_drag     ;  break;
	}
	xbtp02_last_state = b;

	/* Logic to synthesize :DRAG or :SELECT at most once per frame: */
	if (frame_Of_Last_Mouse_Event == xcmr05_Frame_Number) {
	    if (state == k_drag
	    ||  state == k_select
	    ){
		state =  NIL;
	    }
	}
	if (state != NIL) {
	    frame_Of_Last_Mouse_Event = xcmr05_Frame_Number;
	}
    } while (block_until_input_arrives && state==NIL);

    setvalue( s_xg3dmousepressure  , cvfixnum( z ) );
    setvalue( s_xg3dmouserow       , cvfixnum( y ) );
    setvalue( s_xg3dmousecol       , cvfixnum( x ) );
    setvalue( s_xg3dmousestate     , state         );

    {   int x_dist = (x > last_x) ? (x - last_x) : (last_x -x);
        int y_dist = (y > last_y) ? (y - last_y) : (last_y -y);
	int   dist = (x_dist > y_dist) ? x_dist  : y_dist;
	if   (dist < xbtp03_stream_spacing) {
	    setvalue( s_xbtppuckmoved, NIL  );
	} else {
	    setvalue( s_xbtppuckmoved, true );
	    last_x = x;
	    last_y = y;
	    last_z = z;
	}
    }

    return state;
}

/* }}} */
/* {{{ xbtp13_Resolution_Fn -- Return tablet resolution in microns.	*/

LVAL xbtp13_Resolution_Fn() {
    
    int microns = 50;

    xllastarg();

    if (!xbtp00_Port) xlerror("XBTP-RESOLUTION-IN-MICRONS: Uninitialized!");

    switch (xbtp01_protocol) {
    case XBTP_BITPAD1:
        microns = xbtp33_Bitpad1_Resolution();
	break;
    case XBTP_SUMMASKETCH2:
	microns = xbtp43_SummaSketch2_Resolution();
	break;
    case XBTP_WACOM_PRESSURE_STYLUS:
        microns = xbtp53_WacoP_Resolution();
	break;
    case XBTP_WACOM_STANDARD_STYLUS_TIP:
        microns = xbtp63_WacoST_Resolution();
	break;
    case XBTP_WACOM_STANDARD_STYLUS_SIDE:
        microns = xbtp73_WacoSS_Resolution();
	break;
    }

    return cvfixnum( microns );
}

/* }}} */
/* {{{ xbtp15_Dimensions_Fn  -- Return tablet dimensions in counts.	*/

LVAL xbtp15_Dimensions_Fn() {
    
    int x = 1;
    int y = 1;

    xllastarg();

    if (!xbtp00_Port) xlerror("XBTP-TABLET-SIZE-IN-COUNTS Uninitialized!");

    switch (xbtp01_protocol) {
    case XBTP_BITPAD1:
        xbtp34_Bitpad1_Dimensions(       &x, &y );
	break;
    case XBTP_SUMMASKETCH2:
	xbtp44_SummaSketch2_Dimensions(  &x, &y );
	break;
    case XBTP_WACOM_PRESSURE_STYLUS:
        xbtp54_WacoP_Dimensions(         &x, &y );
	break;
    case XBTP_WACOM_STANDARD_STYLUS_TIP:
        xbtp64_WacoST_Dimensions(        &x, &y );
	break;
    case XBTP_WACOM_STANDARD_STYLUS_SIDE:
        xbtp74_WacoSS_Dimensions(        &x, &y );
	break;
    }

    {   LVAL result;
        xlsave1(result);
	result = cons( cvfixnum( y ), NIL    );
	result = cons( cvfixnum( x ), result );
	xlpop();
        return result;
    }
}

/* }}} */
/* {{{ xbtp17_Protocols_Fn  -- Return list of supported tablets.	*/

LVAL xbtp17_Protocols_Fn() {
    
    xllastarg();

    {   LVAL result;
        xlsave1(result);
	result = cons( k_summasketch2          , NIL    );
	result = cons( k_bitpad1               , result );
	result = cons( k_wacom_fat_stylus      , result );
	result = cons( k_wacom_thin_stylus_tip , result );
	result = cons( k_wacom_thin_stylus_side, result );
	xlpop();
        return result;
    }
}

/* }}} */
/* {{{ xbtp19_Pen_Threshold_Fn  -- Get/set stylus sensitivity.		*/

LVAL xbtp19_Pen_Threshold_Fn() {
    
    float result = xbtp04_Pen_Threshold;
    if (moreargs()) {
	LVAL  lv_threshold = xlgaflonum();
	float    threshold = getflonum(  lv_threshold );
	lib18_Clip_Float_To_Unit_Interval( &threshold );
	/* Threshold 1.0 tends to be a nuisance special case: */
	if (threshold == 1.0)   threshold = 0.9999;
	xbtp04_Pen_Threshold = threshold;
    }
    xllastarg();
    return cvflonum( result );
}

/* }}} */

/* {{{ Summagraphics Bitpad One support.				*/

/* {{{ Bitpad One Overview						*/

/*

The Summagraphics Bitpad One (likely TM) is an ancient (1980? 1978?)
data tablet which is significant because our lab happens to have
several lying around, and because some later data tablets (such as our
Scriptels (likely TM also)) would emulate it.

It has a number of configurations, and I don't have the manual
handy, but we run it by setting internal dipswitches like so:

    Top switch: 0100000000 
    Switch 1  : 111010010
    Switch 2  : 101110

This gives us continuous transmission of strings of the form
dddd,dddd,x<nl> ("%04d,%04d,%1x\n"), that being x,y puck position to
0.1mm integer precision, 0,0 being lower-left corner, followed by
button state.  We always run the serial link at 9600 baud.

I like continuous-transmission because it allows for stream digitizing
without constant clicking, and is less likely to give mode problems
than a switched stream.  We _did_ once have a PDP-11/24 (RSX-11M) that
wouldn't boot with input coming in a serial port, that's the only time
this mode has given me problems...  

*/

/* }}} */

/* {{{ xbtp31_Bitpad1_Initialize					*/

xbtp31_Bitpad1_Initialize( ) {
    /* We initialize bitpad1 entirely via hardware dipswitches, */
    /* to continuous-stream ascii mode, resolution 0.1mm.	*/
}

/* }}} */
/* {{{ xbtp32_Bitpad1_Read_State					*/

xbtp92_Bitpad1_Read_Int() {
    int  i;
    int  c = 0;
    int  v = 0;
    for (i = 4;   i --> 0; ) {
       c = xbtp09_Read_Input(100); 
       if (c == -1)   return -1;	/* Escape from dead tablet. */
       if (c == '\n' || c == '\r') { ++i; continue; }
       if (!isdigit(c))  return -1;
       v = v*10 + (c-'0');
    } 
    /* Dividing return values by two is a quick way of     */
    /* both fighting noise (our tablets usually oscillate  */
    /* between two adjacent values) and fitting the tablet */
    /* resolution more closely to the screen resolution:   */
    return v>>1;
}
xbtp32_Bitpad1_Read_State( px, py, pz, pb )
int                       *px,*py,*pz,*pb;
{
    /*********************************************/
    /* Read a string of the form dddd,dddd,x<nl> */ 
    /*********************************************/
    for (;;) {

	/* Wait until at the end of one coordinate set: */ 
	int i;
	while ((i=xbtp09_Read_Input(100)) != '\n') if (i==-1) return -1;

	/* Read a string of the form dddd,dddd,x<nl> */ 
	if (0 > (*px = xbtp92_Bitpad1_Read_Int()))  continue;
	if (xbtp09_Read_Input(100) != ',')          continue;
	if (0 > (*py = xbtp92_Bitpad1_Read_Int()))  continue;
	if (xbtp09_Read_Input(100) != ',')          continue;
	*pb = (xbtp09_Read_Input(100) != '0');
	*pz = 1024 * *pb;
	return 0;
    }
}

/* }}} */
/* {{{ xbtp33_Bitpad1_Resolution					*/

xbtp33_Bitpad1_Resolution()
{
    /* Multiply by two because xbtp92_Bitpad1_Read_Int */
    /* divides by two:                                 */
    return 200;
}

/* }}} */
/* {{{ xbtp34_Bitpad1_Dimenions						*/

xbtp34_Bitpad1_Dimensions( px, py )
int                       *px,*py;
{
    /* Empirical numbers from sliding the puck around :) */
    *px = 3100;
    *py = 2950;
}

/* }}} */

/* }}} */
/* {{{ Summagraphics SummaSketch2 support.				*/

/* {{{ SummasketchII Overview						*/

/*

The Bitpad Ones we use seem to be ancient history, so I added
SummasketchII support for folks using our software who need to have
support for something currently purchasable *grin*.  I borrowed one
long enough to set this up, and since I couldn't dig everything I
needed out of the manual, begged some real info via fax.  Since I
don't currently have one of these tablets, and the code I'm cribbing
from was on a PC, this code may be badly broken.

Here's what I cribbed from the fax:
*/

      /******************************************************/
      /*   MSB				    LSB 	    */
      /*   7	6    5	  4    3    2	 1    0 	    */
      /* ---  ---  ---	---  ---  ---  ---  --- 	    */
      /*  PH   PR    T	 Sx   Sy   Fc	Fb   Fa   Byte 0    */
      /*   0   X6   X5	 X4   X3   X2	X1   X0   Byte 1    */
      /*   0  X13  X12	X11  X10   X9	X8   X7   Byte 2    */
      /*   0   Y6   Y5	 Y4   Y3   Y2	Y1   Y0   Byte 3    */
      /*   0  Y13  Y12	Y11  Y10   Y9	Y8   Y7   Byte 4    */
      /*                                                    */
      /*  PH is always 1.				    */
      /*  PR Proximity: 1 == in-prox  0 == out-prox	    */
      /*  Sx, Sy: Sign bits of X,Y coords. Always zero	    */
      /*	  if not in relative mode.		    */
      /*  T: Tablet identifier. Can be set to 0 or 1.	    */
      /*                                                    */
      /* Fc, Fb, Fa give the button status according to     */
      /* the following half-assed encoding:		    */
      /*						    */
      /* CBA						    */
      /* ---						    */
      /* 000  No buttons pressed			    */
      /* 001  1 pressed 				    */
      /* 010  2 pressed 				    */
      /* 011  3 pressed 				    */
      /* 100  4 pressed 				    */
      /*                                                    */
      /*      If the user pressed more than one button,     */
      /*      God help you -- Summagraphics sure won't.     */
      /*                                                    */
      /* While we're documenting the SummaSketch II, here's */
      /* some Big Secrets the documentation doesn't cover:  */
      /*                                                    */
      /* * Sending ASCII '@' will put the pad in	    */
      /*   stream mode, sending continuously.		    */
      /*                                                    */
      /* * Sending ASCII 'A' will put the pad in switched-  */
      /*   stream mode, sending continuously while any      */ 
      /*   button is down.  (The is the default mode.)      */ 
      /*                                                    */
      /* * Sending ASCII 'B' will put the pad in point      */
      /*   mode, sending only 1 coord per button-push.      */   
      /*                                                    */   
      /* * Sending ASCII 'D' will put the pad in remote     */
      /*   request mode.  Trigger command is 'P'.	    */
      /*                                                    */  
      /* * Sending ASCII 'E' will put the pad in delta      */
      /*   mode.                                            */ 
      /*                                                    */    
      /* * Sending ASCII 'I' is the increment command.      */
      /*   Value SP to z. (0x20 to 0x7A.)  (means what?)    */ 
      /*                                                    */     
      /* * Sending ASCII 'G' is the axis-update command.    */
      /*   Value SP to z. (0x20 to 0x7A.)  (means what?)    */  
      /*                                                    */      
      /* * Sending ASCII 'T' will reduce the report rate    */
      /*   byte a factor of 32.                             */ 
      /*                                                    */   
      /* * Sending ASCII 'S' will reduce the report rate    */
      /*   byte a factor of  8.                             */ 
      /*                                                    */    
      /* * Sending ASCII 'R' will reduce the report rate    */
      /*   byte a factor of  2.                             */ 
      /*                                                    */     
      /* * Sending ASCII 'Q' will restore maximum report    */
      /*   rate (default).                                  */ 
      /*                                                    */ 
      /* * Sending ASCII NUL will reset the SummaSketch.    */
      /*                                                    */ 
      /* * Sending ASCII 'f' yields   10 lines/mm.	    */
      /* * Sending ASCII 'i' yields   20 lines/mm.	    */
      /* * Sending ASCII 'q' yields   40 lines/mm.	    */
      /* * Sending ASCII 'd' yields  100 lines/inch.	    */
      /* * Sending ASCII 'e' yields  200 lines/inch.	    */
      /* * Sending ASCII 'g' yields  400 lines/inch.	    */
      /* * Sending ASCII 'h' yields  500 lines/inch.Default.*/
      /* * Sending ASCII 'j' yields 1000 lines/inch.	    */
      /*                                                    */
      /* Other random stuff before I lose the fax:	    */
      /*  Grid Roundoff:  'l'=1lpi 'n'=2lpi 'p'=4lpi	    */
      /* Stop  Transmission: DC3 == 0x13		    */
      /* Start Transmission: DC1 == 0x11		    */
      /* Send configuration: 'a'                            */
      /* Self-test         : 't'                            */
      /* Send test results : 'w'                            */
      /* Echo              : 'k'                            */
      /* Code check        : 'x'                            */
      /* Ftry test (DON'T!): 'z'                            */
      /* Table ID	   : '0' '1'			    */
      /*						    */
      /* * Sending ASCII ':' (?? -- fax unreadable) is the  */
      /*   set X,Y Scale command. Followed (?) by the	    */
      /*   Xlo, Xhi, Ylo, Yhi bytes, each 0x00 -> 0xFF.     */
      /*						    */
      /******************************************************/

/* }}} */

/* {{{ xbtp41_SummaSketch2_Initialize					*/

xbtp41_SummaSketch2_Initialize() {

    /* Continuous-stream mode: */
    write( xbtp00_Port, "@", 1 );

    /* 10 lines per mm: */
    write( xbtp00_Port, "f", 1 );
}

/* }}} */
/* {{{ xbtp42_SummaSketch2_Read_State					*/

xbtp42_SummaSketch2_Read_State( px, py, pz, pb )
int                            *px,*py,*pz,*pb;
{
    /******************************************************/
    /*  Read a packed binary sequence in the format:      */ 
    /*                                                    */
    /*   MSB				    LSB 	  */
    /*   7	6    5	  4    3    2	 1    0 	  */
    /* ---  ---  ---	---  ---  ---  ---  --- 	  */
    /*  PH   PR    T	 Sx   Sy   Fc	Fb   Fa   Byte 0  */
    /*   0   X6   X5	 X4   X3   X2	X1   X0   Byte 1  */
    /*   0  X13  X12	X11  X10   X9	X8   X7   Byte 2  */
    /*   0   Y6   Y5	 Y4   Y3   Y2	Y1   Y0   Byte 3  */
    /*   0  Y13  Y12	Y11  Y10   Y9	Y8   Y7   Byte 4  */
    /******************************************************/

    int byt0 = 0;
    int byt1 = 0;
    int byt2 = 0;
    int byt3 = 0;
    int byt4 = 0;
    do {
	byt0 = byt1;
	byt1 = byt2;
	byt2 = byt3;
	byt3 = byt4;
	byt4 = xbtp09_Read_Input(100);
	if (byt4 == -1)   return -1; /* Dead-tablet escape route. */
    } while (!(byt0 & 0x80));

    /*******************************************/
    /* Translate binary format to output vars: */
    /*******************************************/
    *px  = (byt2 << 7)   |   byt1;
    *py  = (byt4 << 7)   |   byt3;
    *pb  = (byt0 &  7)   !=     0;
    *pz  = 1024* *pb;

    return 0;
}

/* }}} */
/* {{{ xbtp43_SummaSketch2_Resolution					*/

xbtp43_SummaSketch2_Resolution()
{
    return 100;
}

/* }}} */
/* {{{ xbtp44_SummaSketch2_Dimensions					*/

xbtp44_SummaSketch2_Dimensions( px, py )
int                            *px,*py;
{
    /* These are actually my Bitpad One numbers: */
    *px = 3100;
    *py = 2950;
}

/* }}} */

/* }}} */
/* {{{ Wacom Pressure Stylus support.					*/

#define WACOM_FILTERING   (0)
#define WACOM_BINARY_MODE (1)

/* {{{ Wacom Overview							*/

/*

My friendly SGI multimedia guru tells me Wacom tablets are just
THE thing to be using these days... and they do look like it,
from the sample I have in front of me.

/* }}} */

/* {{{ xbtp5g_Wacom_XY_Filter						*/

#if WACOM_FILTERING
int xbtp5g_Wacom_XY_Filter( x, y, inside )
int 			    x, y, inside;
{
    /****************************************************/
    /* Our Wacom SD-510C produces totally bogus values	*/
    /* 1-10% of the time, in isolated bursts of 1-10 or */
    /* so samples.  Attempting to talk to Wacom about   */
    /* this has so far just produced happy innocent     */
    /* smiles from the Clueless Phone Squad there.  I   */
    /* suspect we have a defective Wacom, since I find  */
    /* it hard to believe they could become as popular  */
    /* as they seem to be with merchandise this badly   */
    /* behaved, but ... *shrug*. As a work-around, this */
    /* code suppresses points when the datastream has   */
    /* been unstable recently:                          */
    /****************************************************/

    static last_x = 0;
    static last_y = 0;

    static dx1 = 0;
    static dy1 = 0;

    static dx2 = 0;
    static dy2 = 0;

    static dx3 = 0;
    static dy3 = 0;

    static dx4 = 0;
    static dy4 = 0;

    static dx5 = 0;
    static dy5 = 0;

    static consecutive_poor_samples = 0;
    static consecutive_good_samples = 0;

    int dx0 = x - last_x;
    int dy0 = y - last_y;

    if (!inside)   return FALSE;

    if (dx0 < 0)   dx0 = -dx0;
    if (dy0 < 0)   dy0 = -dy0;

    if (dx0 > 100 || dy0 > 100
    ||  dx1 > 100 || dy1 > 100
    ||  dx2 > 100 || dy2 > 100
    ||  dx3 > 100 || dy3 > 100
    ||  dx4 > 100 || dy4 > 100
    ||  dx5 > 100 || dy5 > 100
    ) {
	inside = FALSE;
      ++consecutive_poor_samples;
	consecutive_good_samples = 0;
    } else {
      ++consecutive_good_samples;
	consecutive_poor_samples = 0;
    }

    last_x = x;
    last_y = y;

    dx5 = dx4;   dy5 = dy4;
    dx4 = dx3;   dy4 = dy3;
    dx3 = dx2;   dy3 = dy2;
    dx2 = dx1;   dy2 = dy1;
    dx1 = dx0;   dy1 = dy0;

    return inside;
}
#endif

/* }}} */
/* {{{ xbtp5h_Wacom_B_Filter						*/

#if WACOM_FILTERING

#define WACOM_CLICK_FILTER 12

int xbtp5h_Wacom_B_Filter( b )
int                        b;
{
    /* The bogus-values-from-Wacom problem also affects	    */
    /* the switch information.  Require N samples with same */
    /* value before paying attention, as an ugly fix:	    */
    static logical_b                     = 0;
    static last_b                        = 0;
    static consecutive_identical_samples = 0;
    if (last_b != b) {
	last_b  = b;
	consecutive_identical_samples = 0;
    } else if (++consecutive_identical_samples > WACOM_CLICK_FILTER) {
        if (b && !logical_b) {
	    extern LVAL xgtmK2_Ring_Bell_Fn();
	    xgtmK2_Ring_Bell_Fn();
        }
	logical_b  = b;
    }

    return logical_b;
}
#endif

/* }}} */

#if WACOM_BINARY_MODE

#define WACOM_SAMPLE_BYTES 7
struct wacoSample { int byt[ WACOM_SAMPLE_BYTES + 7 ]; };

/* {{{ xbtp5a_Waco_Unpack_X						*/

int xbtp5a_Waco_Unpack_X( s )
struct wacoSample *       s;
{
    int x_sign = (s->byt[0] & 0x04) ? -1 : 1;
    int x      = x_sign * (
	((s->byt[0] & 0x03) << 14)
    |   ((s->byt[1] & 0x7F) <<  7)
    |   ((s->byt[2] & 0x7F)      )
    );
    return x;
}

/* }}} */
/* {{{ xbtp5b_Waco_Unpack_Y						*/

int xbtp5b_Waco_Unpack_Y( s )
struct wacoSample *       s;
{
    int y_sign = (s->byt[3] & 0x04) ? -1 : 1;
    int y      = y_sign * (
	((s->byt[3] & 0x03) << 14)
    |   ((s->byt[4] & 0x7F) <<  7)
    |   ((s->byt[5] & 0x7F)      )
    );
    return y;
}

/* }}} */
/* {{{ xbtp5c_Waco_Unpack_Inside					*/

int xbtp5c_Waco_Unpack_Inside( s )
struct wacoSample *            s;
{
    return (s->byt[0] & 0x40) != 0;
}

/* }}} */
/* {{{ xbtp5d_Waco_Unpack_Tipswitch					*/

int xbtp5d_Waco_Unpack_Tipswitch( s )
struct wacoSample *               s;
{
    /* Tip switch state is recorded in bit zero: */
    return (s->byt[6] & 0x01) != 0;
}

/* }}} */
/* {{{ xbtp5e_Waco_Unpack_Sideswitch					*/

int xbtp5e_Waco_Unpack_Sideswitch( s )
struct wacoSample *                s;
{
    /* Side switch state is recorded in bit one: */
    return (s->byt[6] & 0x02) != 0;
}

/* }}} */
/* {{{ xbtp5f_Waco_Unpack_TipPressure					*/

int xbtp5f_Waco_Unpack_TipPressure( s )
struct wacoSample *                 s;
{
    /* z is given as a signed 7-bit value, but we're supposed to */
    /* clamp to -32->32 and then map that to 0->64.  Wacom's     */
    /* folks found a much uglier way of doing this:              */
    int        z = (((signed char)(s->byt[6]<<1)) >> 1) + 32;
    if (z < 0) z = 0;
    if (z >64) z = 64;
    return     z;
}

/* }}} */
/* {{{ xbtp50_Waco_Read_Sample						*/

int xbtp50_Waco_Read_Sample( result )
struct wacoSample *          result;
{
    struct wacoSample s;
    
int bytesread = 0;
    /******************************************************/
    /*  Read a packed binary sequence in the format:      */ 
    /*                                                    */
    /*   MSB				    LSB 	  */
    /*   7    6    5      4    3    2	 1    0 	  */
    /* ---  ---  ---	---  ---  ---  ---  --- 	  */
    /*   1   in      	         Xsign X15  X14   Byte 0  */
    /*   0  X13  X12	X11  X10   X9	X8   X7   Byte 1  */
    /*   0   X6   X5	 X4   X3   X2	X1   X0   Byte 2  */
    /*   0         	         Ysign Y15  Y14   Byte 3  */
    /*   0  Y13  Y12	Y11  Y10   Y9	Y8   Y7   Byte 4  */
    /*   0   Y6   Y5	 Y4   Y3   Y2	Y1   Y0   Byte 5  */
    /*   0   Z6   Z5	 Z4   Z3   Z2	Z1   Z0   Byte 6  */
    /******************************************************/

    s.byt[0] = 0;
    s.byt[1] = 0;
    s.byt[2] = 0;
    s.byt[3] = 0;
    s.byt[4] = 0;
    s.byt[5] = 0;
    s.byt[6] = 0;

    s.byt[ 7] = 0;
    s.byt[ 8] = 0;
    s.byt[ 9] = 0;
    s.byt[10] = 0;
    s.byt[11] = 0;
    s.byt[12] = 0;
    s.byt[13] = 0;

    /* Unflushed input gives us bizarre runaway behavior */
    /* after pauses to read from the keyboard and such:  */
    xbtp08_Flush_Input();

    /* Request a coord stream: */
    write( xbtp00_Port, "ST\n", 3 );

    /* Read a coord, with timeout: */
    do {
	/* Yah, a circular buffer is faster.  */
        /* but we only have to keep up with a */
        /* 9600bps serial link, why sweat it: */
	s.byt[ 0] = s.byt[ 1];
	s.byt[ 1] = s.byt[ 2];
	s.byt[ 2] = s.byt[ 3];
	s.byt[ 3] = s.byt[ 4];
	s.byt[ 4] = s.byt[ 5];
	s.byt[ 5] = s.byt[ 6];
	s.byt[ 6] = s.byt[ 7];

	s.byt[ 7] = s.byt[ 8];
	s.byt[ 8] = s.byt[ 9];
	s.byt[ 9] = s.byt[10];
	s.byt[10] = s.byt[11];
	s.byt[11] = s.byt[12];
	s.byt[12] = s.byt[13];
	s.byt[13] = xbtp09_Read_Input(100);
++bytesread;

	if (s.byt[7] == -1)   return 0; /* Dead-tablet escape route. */
#ifdef WACOM_WORKED_AS_DOCUMENTED
    } while (!(s.byt[0] & 0x80));
#else
        /* Wacom promises to only set high bit on first byte 	*/
        /* in sequence, but in fact seems to frequently set on 	*/
        /* last byte as well, witness this log of samples    	*/
        /* from my SD510C running WacomII Pressure mode, only	*/
        /* activity being pressure changes:                  	*/
	/* ----------------------------------------------------	*/
	/* e0 04 15 00 07 4d 21 [i]    533,   973,    64	*/
	/* e0 04 16 00 07 4f 21 [i]    534,   975,    64	*/
	/* e0 04 18 00 07 51 00 [i]    536,   977,    32	*/
	/* e0 04 12 00 07 4b 23 [i]    530,   971,    64	*/
	/* e0 04 10 00 07 49 22 [i]    528,   969,    64	*/
	/* e0 04 12 00 07 4b be [i]    530,   971,    64 	*/
	/* bf e0 04 12 00 07 4c [o] -61444, 32775,     0	*/
	/* bf e0 04 12 00 07 4c [o] -61444, 32775,     0	*/
	/* bf e0 04 13 00 07 4c [o] -61444, 49159,     0	*/
	/* e0 04 13 00 07 4c bf [i]    531,   972,    64	*/
	/* bf e0 04 13 00 07 4d [o] -61444, 49159,     0	*/
	/* e1 e0 04 13 00 07 4d [i]  28676, 49159,     0	*/
	/* e0 04 13 00 07 4d e1 [i]    531,   973,     1	*/
	/* e0 04 13 00 07 4d e1 [i]    531,   973,     1	*/
	/* e0 04 12 00 07 4e e1 [i]    530,   974,     1	*/
	/* e1 e0 04 12 00 07 4e [i]  28676, 32775,     0	*/
	/* e0 04 12 00 07 4e e1 [i]    530,   974,     1	*/
	/* e0 04 13 00 07 4e e1 [i]    531,   974,     1	*/
	/* e1 e0 04 13 00 07 4e [i]  28676, 49159,     0	*/
	/* e0 04 13 00 07 4e e1 [i]    531,   974,     1	*/
	/* e0 04 12 00 07 4e e1 [i]    530,   974,     1	*/
	/* e1 e0 04 12 00 07 4e [i]  28676, 32775,     0	*/
	/* e0 04 12 00 07 4d e1 [i]    530,   973,     1	*/
	/* e0 04 12 00 07 4d bf [i]    530,   973,    64	*/
	/* bf e0 04 0f 00 07 4b [o] -61444,-49159,     0	*/
	/* e0 04 0f 00 07 4b 22 [i]    527,   971,    64	*/
	/* e0 04 11 00 07 52 22 [i]    529,   978,    64	*/
	/* e0 04 11 00 07 53 21 [i]    529,   979,    64	*/
	/* ----------------------------------------------------	*/
	/* As a workaround, we accept a sample set only if the	*/
	/* first byte has high bit set and none of the next	*/
	/* five bytes do:                                       */
    } while (!(s.byt[ 0] & 0x80)
    ||	      (s.byt[ 1] & 0x80)
    ||	      (s.byt[ 2] & 0x80)
    ||	      (s.byt[ 3] & 0x80)
    ||	      (s.byt[ 4] & 0x80)
    ||	      (s.byt[ 5] & 0x80)
    ||	      (s.byt[ 6] & 0x80)

    ||	     !(s.byt[ 7] & 0x80)
    ||	      (s.byt[ 8] & 0x80)
    ||	      (s.byt[ 9] & 0x80)
    ||	      (s.byt[10] & 0x80)
    ||	      (s.byt[11] & 0x80)
    ||	      (s.byt[12] & 0x80)
    ||	      (s.byt[13] & 0x80)
    );
#endif

    /* Switch off coord stream and return sample: */
    write( xbtp00_Port, "SP\n", 3 );
   *result = s;
    return 1;
}

/* }}} */

#else

#define WACOM_SAMPLE_BYTES 17
struct wacoSample { char byt[ WACOM_SAMPLE_BYTES ]; };

/* {{{ xbtp5a_Waco_Unpack_X						*/

int xbtp5a_Waco_Unpack_X( s )
struct wacoSample *       s;
{
    return atoi( (const char*)&s->byt[2] );
}

/* }}} */
/* {{{ xbtp5b_Waco_Unpack_Y						*/

int xbtp5b_Waco_Unpack_Y( s )
struct wacoSample *       s;
{
    return atoi( (const char*)&s->byt[8] );
}

/* }}} */
/* {{{ xbtp5c_Waco_Unpack_Inside					*/

int xbtp5c_Waco_Unpack_Inside( s )
struct wacoSample *            s;
{
    int    z  = atoi( (const char*)&s->byt[14] );
    return z != 99;
}

/* }}} */
/* {{{ xbtp5d_Waco_Unpack_Tipswitch					*/

int xbtp5d_Waco_Unpack_Tipswitch( s )
struct wacoSample *               s;
{
    int     z  = atoi( (const char*)&s->byt[14] );
    return (z & 0x01) != 0;
}

/* }}} */
/* {{{ xbtp5e_Waco_Unpack_Sideswitch					*/

int xbtp5e_Waco_Unpack_Sideswitch( s )
struct wacoSample *                s;
{
    int     z  = atoi( (const char*)&s->byt[14] );
    return (z & 0x02) != 0;
}

/* }}} */
/* {{{ xbtp5f_Waco_Unpack_TipPressure					*/

int xbtp5f_Waco_Unpack_TipPressure( s )
struct wacoSample *                 s;
{
    /* z is given as a signed 7-bit value, but we're supposed to */
    /* clamp to -32->32 and then map that to 0->64.  Wacom's     */
    /* folks found a much uglier way of doing this:              */
    int        z = atoi( (const char*)&s->byt[14] )   + 32;
    if (z < 0) z = 0;
    if (z >64) z = 64;
    return     z;
}

/* }}} */
/* {{{ xbtp50_Waco_Read_Sample						*/

int xbtp50_Waco_Read_Sample( result )
struct wacoSample *          result;
{
    struct wacoSample s;
    
    /******************************************************/
    /*  Read an ascii sequence in the format:             */ 
    /*                                                    */
    /*  #,12345,23456,89<RET>                             */
    /******************************************************/

    {   int i = WACOM_SAMPLE_BYTES; while (i-->0) s.byt[i]=0; }

    /* Unflushed input gives us bizarre runaway behavior */
    /* after pauses to read from the keyboard and such:  */
    xbtp08_Flush_Input();

    /* Request a coord stream: */
    write( xbtp00_Port, "ST\n", 3 );

    /* Read a coord, with timeout: */
    do {
	/* Yah, a circular buffer is faster.  */
        /* but we only have to keep up with a */
        /* 9600bps serial link, why sweat it: */
	{   int i;
	    for (i = 0; i < WACOM_SAMPLE_BYTES; ++i) s.byt[i-1]=s.byt[i];
	}
	{   int i = xbtp09_Read_Input(100);
	    /* Provide a dead-tablet escape route: */
	    if (i == -1)  return 0;
	    s.byt[WACOM_SAMPLE_BYTES-1] = 0x7F & i;
	}

	/* #,01903,00928,00 */
	/* 0123456789012345 */
    } while (   (s.byt[0]  != '#'   &&   s.byt[0] != '!')
    ||           s.byt[ 1] != ','
    ||	         s.byt[ 7] != ','
    ||	         s.byt[13] != ','

    || !isdigit( s.byt[ 2] )
    || !isdigit( s.byt[ 3] )
    || !isdigit( s.byt[ 4] )
    || !isdigit( s.byt[ 5] )
    || !isdigit( s.byt[ 6] )

    || !isdigit( s.byt[ 8] )
    || !isdigit( s.byt[ 9] )
    || !isdigit( s.byt[10] )
    || !isdigit( s.byt[11] )
    || !isdigit( s.byt[12] )
    );

    /* Switch off coord stream and return sample: */
    write( xbtp00_Port, "SP\n", 3 );
   *result = s;
    return 1;
}

/* }}} */

#endif

/* {{{ xbtp51_WacoP_Initialize						*/

xbtp51_WacoP_Initialize( ) {

    /* Note, Wacom manual states that '$' does not need a following	*/
    /* newline, but next command gets ignored if we leave it out.	*/
    /* Later: Hmm.  I get the feeling maybe just the first few chars	*/
    /* after '$' tend to get lost.  Sending the first command three	*/
    /* times will maybe help:						*/
    static char* mode =
	"$\n"		/* Reset, select WacomII commandset.		*/
	"PH1\n"		/* Pressure mode (requires pressure stylus)	*/
	"PH1\n"		/* Pressure mode (requires pressure stylus)	*/
	"PH1\n"		/* Pressure mode (requires pressure stylus)	*/
	"OC0\n"		/* Origin at lower-left of data tablet		*/
#if WACOM_BINARY_MODE
	"AS1\n"		/* Binary format				*/
#else
	"AS0\n"		/* Ascii format					*/
#endif

	"AL1\n"		/* Always provide data, even if pen out of range*/
        "DE0\n"		/* Absolute mode (vs relative)			*/
        "IC0\n"		/* Millimeter mode (vs inch)			*/
	"IT00\n"	/* Send coord every nx5ms			*/
	"IN000\n"	/* Don't send until coords change this much	*/
	"SU00\n"	/* Make sure suppressed mode is off.		*/
	"SR\n"		/* Stream mode (vs Point or switched-stream)	*/
	"SP\n"		/* Stop -- don't actually send until requested.	*/
    ;

    write( xbtp00_Port, mode, strlen(mode) );
}

/* }}} */
/* {{{ xbtp52_WacoP_Read_State						*/

xbtp52_WacoP_Read_State( px, py, pz, pb )
int                     *px,*py,*pz,*pb;
{
    struct wacoSample s;
    if (!xbtp50_Waco_Read_Sample( &s ))   return -1;

    /******************************************************/
    /*  Unpack sample in the format:                      */ 
    /*                                                    */
    /*   MSB				    LSB 	  */
    /*   7    6    5      4    3    2	 1    0 	  */
    /* ---  ---  ---	---  ---  ---  ---  --- 	  */
    /*   1   in      	         Xsign X15  X14   Byte 0  */
    /*   0  X13  X12	X11  X10   X9	X8   X7   Byte 1  */
    /*   0   X6   X5	 X4   X3   X2	X1   X0   Byte 2  */
    /*   0         	         Ysign Y15  Y14   Byte 3  */
    /*   0  Y13  Y12	Y11  Y10   Y9	Y8   Y7   Byte 4  */
    /*   0   Y6   Y5	 Y4   Y3   Y2	Y1   Y0   Byte 5  */
    /*   0   Z6   Z5	 Z4   Z3   Z2	Z1   Z0   Byte 6  */
    /******************************************************/

    /*******************************************/
    /* Translate binary format to output vars: */
    /*******************************************/
    {   int threshold  = (int) (xbtp04_Pen_Threshold * 64.0);
        int x          = xbtp5a_Waco_Unpack_X(           &s );
        int y          = xbtp5b_Waco_Unpack_Y(           &s );
	int inside     = xbtp5c_Waco_Unpack_Inside(      &s );
	int z	       = xbtp5f_Waco_Unpack_TipPressure( &s );
	int b          = z > threshold;

#if WACOM_FILTERING
	inside 	      = xbtp5g_Wacom_XY_Filter( x, y, inside );
	b	      = xbtp5h_Wacom_B_Filter(  b            );
#endif

	*px = x;
	*py = y;
	*pb = b;
        *pz = z*16;

        return inside ? 0 : -1;
    }
}

/* }}} */
/* {{{ xbtp53_WacoP_Resolution						*/

xbtp53_WacoP_Resolution()
{
    return 100;
}

/* }}} */
/* {{{ xbtp54_WacoP_Dimensions						*/

xbtp54_WacoP_Dimensions( px, py )
int                     *px,*py;
{
    /* These are actually my Bitpad One numbers: */
    *px = 3100;
    *py = 2950;
}

/* }}} */

/* }}} */
/* {{{ Wacom Standard Stylus tip  switch support.			*/

/* {{{ xbtp61_WacoST_Initialize						*/

xbtp61_WacoST_Initialize( ) {

    static char* mode =
	"$\n"		/* Reset, select WacomII commandset.		*/
	"PH0\n"		/* Nonpressure mode: requires "standard" stylus	*/
	"PH0\n"		/* Nonpressure mode: requires "standard" stylus	*/
	"PH0\n"		/* Nonpressure mode: requires "standard" stylus	*/
	"OC0\n"		/* Origin at lower-left of data tablet		*/
#if WACOM_BINARY_MODE
	"AS1\n"		/* Binary format				*/
#else
	"AS0\n"		/* Ascii format					*/
#endif
	"AL1\n"		/* Always provide data, even if pen out of range*/
        "DE0\n"		/* Absolute mode (vs relative)			*/
        "IC0\n"		/* Millimeter mode (vs inch)			*/
	"IT00\n"	/* Send coord every nx5ms			*/
	"IN000\n"	/* Don't send until coords change this much	*/
	"SU00\n"	/* Make sure suppressed mode is off.		*/
	"SR\n"		/* Stream mode (vs Point or switched-stream)	*/
	"SP\n"		/* Stop -- don't actually send until requested.	*/
    ;

    write( xbtp00_Port, mode, strlen(mode) );
}

/* }}} */
/* {{{ xbtp62_WacoST_Read_State						*/

xbtp62_WacoST_Read_State( px, py, pz, pb )
int                      *px,*py,*pz,*pb;
{
    struct wacoSample s;
    if (!xbtp50_Waco_Read_Sample( &s ))   return -1;

    {   int x         = xbtp5a_Waco_Unpack_X(         &s );
        int y         = xbtp5b_Waco_Unpack_Y(         &s );
	int inside    = xbtp5c_Waco_Unpack_Inside(    &s );
        int b         = xbtp5d_Waco_Unpack_Tipswitch( &s );

#if WACOM_FILTERING
	inside 	      = xbtp5g_Wacom_XY_Filter( x, y, inside );
	b	      = xbtp5h_Wacom_B_Filter(  b            );
#endif

	*px = x;
	*py = y;
	*pb = b;
	*pz = 1024 * b;


        return inside ? 0 : -1;
    }
}

/* }}} */
/* {{{ xbtp63_WacoST_Resolution						*/

xbtp63_WacoST_Resolution()
{
    return xbtp53_WacoP_Resolution();
}

/* }}} */
/* {{{ xbtp64_WacoST_Dimensions						*/

xbtp64_WacoST_Dimensions( px, py )
int                      *px,*py;
{
    return xbtp54_WacoP_Dimensions( px, py );
}

/* }}} */

/* }}} */
/* {{{ Wacom Standard Stylus side switch support.			*/

/* {{{ xbtp71_WacoSS_Initialize						*/

xbtp71_WacoSS_Initialize( ) {
    xbtp61_WacoST_Initialize();
}

/* }}} */
/* {{{ xbtp72_WacoSS_Read_State						*/

xbtp72_WacoSS_Read_State( px, py, pz, pb )
int                      *px,*py,*pz,*pb;
{
    struct wacoSample s;
    if (!xbtp50_Waco_Read_Sample( &s ))   return -1;

    {   int x         = xbtp5a_Waco_Unpack_X(          &s );
        int y         = xbtp5b_Waco_Unpack_Y(          &s );
	int inside    = xbtp5c_Waco_Unpack_Inside(     &s );
	int b	      = xbtp5e_Waco_Unpack_Sideswitch( &s );

#if WACOM_FILTERING
	inside 	      = xbtp5g_Wacom_XY_Filter( x, y, inside );
	b	      = xbtp5h_Wacom_B_Filter(  b            );
#endif

	*px = x;
	*py = y;
	*pb = b;
	*pz = 1024 * b;

        return inside ? 0 : -1;
    }
}

/* }}} *//* {{{ xbtp73_WacoSS_Resolution						*/

xbtp73_WacoSS_Resolution()
{
    return xbtp53_WacoP_Resolution();
}

/* }}} */
/* {{{ xbtp74_WacoSS_Dimensions						*/

xbtp74_WacoSS_Dimensions( px, py )
int                      *px,*py;
{
    return xbtp54_WacoP_Dimensions( px, py );
}

/* }}} */

/* }}} */

/* {{{ This is my old code to read Wacom ascii format.			*/

#ifdef OLDJUNK
    /******************************************************/
    /*  Read an ascii sequence in the format:             */ 
    /*                                                    */
    /*  #,12345,23456,89                                  */
    /******************************************************/

    static pen_up_samples = 0;
    int x = 0;
    int y = 0;
    int z = 0;
    int b = 0;

    /* Unflushed input gives us bizarre runaway behavior */
    /* after pauses to read from the keyboard and such:  */
    xbtp08_Flush_Input();

    do {
	b = xbtp09_Read_Input(100);
	if (b == -1)   return -1; /* Dead-tablet escape route. */
    } while (b != '#');

    if (xbtp09_Read_Input(100) != ',')   return -1;

    {   int i;
        for (i = 5;   i --> 0;   ) {
	    int b = xbtp09_Read_Input(100);
	    if (b < '0' || b > '9')   return -1;
	    x = 10*x + (b - '0');
    }	}

    if (xbtp09_Read_Input(100) != ',')   return -1;

    {   int i;
        for (i = 5;   i --> 0;   ) {
	    int b = xbtp09_Read_Input(100);
	    if (b < '0' || b > '9')   return -1;
	    y = 10*y + (b - '0');
    }	}

    if (xbtp09_Read_Input(100) != ',')   return -1;

    {   int i;
        for (i = 2;   i --> 0;   ) {
	    int b = xbtp09_Read_Input(100);
	    if (b < '0' || b > '9')   return -1;
	    z = 10*z + (b - '0');
    }	}

    /* Debounce click by requiring 10 'up'        */
    /* samples before we take a 'down' seriously: */
    ++       pen_up_samples;
    if      (pen_up_samples < 10)  z = 0;
    else if (z > threshold)   pen_up_samples = 0;

    *px = (     x)>>1;
    *py = (3000-y)>>1;
    *pb = (z > threshold);

    /* Users round here like a beep on each     */
    /* mouseclick, easier to do it here than in */
    /* every fn that responds to a mouseclick:  */
    if (*pb) {
	extern LVAL xgtmK2_Ring_Bell_Fn();
	xgtmK2_Ring_Bell_Fn();
    }

    return 0;

}
#endif
/* }}} */



/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */

