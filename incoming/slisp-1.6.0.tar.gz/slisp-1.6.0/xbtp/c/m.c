/* I suspect some of these aren't needed any more: */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <strings.h>
#include <device.h>
#include <fcntl.h>
#include <termio.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#define ERR (-1)
#define loop for(;;)

#ifndef FALSE
#define FALSE (0)
#endif

main(argc,argv)
int  argc;
char**    argv;
{
    int i;
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    winopen("test.c");
    winconstraints();/*91Jan10jsp*/
    winconstraints();/*91Jan10jsp*/
    RGBmode();
    gconfig();

/*    attachcursor(GHOSTX,GHOSTY);
    gconfig();
*/
/*    for (i = 100; i < 101; ++i) {*/
        setvaluator(MOUSEX,x,0,2000);
        setvaluator(MOUSEY,y,0,2000);
/*    }*/

/*    attachcursor(MOUSEX,MOUSEY);*/
/*    finish();*/
/*    gconfig();*/
}
