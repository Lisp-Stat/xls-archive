/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xbtp.h
* Description:  Header for bitpad driver.
* Author:       Jeff Prothero
* Created:      93Jun08
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1994, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/


#ifdef MODULE_XLDMEM_H_GLOBALS

extern LVAL xbtp06_Initialize_Fn();
extern LVAL xbtp11_Read_State_Fn();
extern LVAL xbtp13_Resolution_Fn();
extern LVAL xbtp15_Dimensions_Fn();
extern LVAL xbtp17_Protocols_Fn();
extern LVAL xbtp19_Pen_Threshold_Fn();
/*extern LVAL xbtpzz_Px_Fn();*/

#ifndef EXTERNED_PROTOCOL
extern LVAL k_protocol;/* Keyword ":protocol" */
#define EXTERNED_PROTOCOL
#endif

#ifndef EXTERNED_BITPAD1
extern LVAL k_bitpad1;/* Keyword ":bitpad1" */
#define EXTERNED_BITPAD1
#endif

#ifndef EXTERNED_WACOM_FAT_STYLUS
extern LVAL k_wacom_fat_stylus;/* Keyword ":wacom-fat-stylus" */
#define EXTERNED_WACOM_FAT_STYLUS
#endif

#ifndef EXTERNED_WACOM_THIN_STYLUS_TIP
extern LVAL k_wacom_thin_stylus_tip;/* Keyword ":wacom-thin-stylus-tip" */
#define EXTERNED_WACOM_THIN_STYLUS_TIP
#endif

#ifndef EXTERNED_WACOM_THIN_STYLUS_SIDE
extern LVAL k_wacom_thin_stylus_side;/* Keyword ":wacom-thin-stylus-side" */
#define EXTERNED_WACOM_THIN_STYLUS_SIDE
#endif

#ifndef EXTERNED_SUMMASKETCH2
extern LVAL k_summasketch2;/* Keyword ":summasketch2" */
#define EXTERNED_SUMMASKETCH2
#endif

#ifndef EXTERNED_DOWNCLICK
extern LVAL k_downclick;   /* Keyword ":DOWNCLICK" */
#define EXTERNED_DOWNCLICK
#endif

#ifndef EXTERNED_DRAG
extern LVAL k_drag;   /* Keyword ":DRAG" */
#define EXTERNED_DRAG
#endif

#ifndef EXTERNED_SELECT
extern LVAL k_select;   /* Keyword ":SELECT" */
#define EXTERNED_SELECT
#endif

#ifndef EXTERNED_UPCLICK
extern LVAL k_upclick;   /* Keyword ":UPCLICK" */
#define EXTERNED_UPCLICK
#endif

#ifndef EXTERNED_S_XG3DMOUSEROW
extern LVAL s_xg3dmouserow;/* Symbol "XG.3D-MOUSE-ROW" */
#define EXTERNED_S_XG3DMOUSEROW
#endif

#ifndef EXTERNED_S_XG3DMOUSECOL
extern LVAL s_xg3dmousecol;/* Symbol "XG.3D-MOUSE-COL" */
#define EXTERNED_S_XG3DMOUSECOL
#endif

#ifndef EXTERNED_S_XG3DMOUSEPRESSURE
extern LVAL s_xg3dmousepressure;/* Symbol "XG.3D-MOUSE-PRESSURE" */
#define EXTERNED_S_XG3DMOUSEPRESSURE
#endif

#ifndef EXTERNED_S_XG3DMOUSESTATE
extern LVAL s_xg3dmousestate;/* Symbol "XG.3D-MOUSE-STATE" */
#define EXTERNED_S_XG3DMOUSESTATE
#endif

#ifndef EXTERNED_BLOCKUNTILINPUTARRIVES
extern LVAL k_blockuntilinputarrives;   /* Keyword ":block-until-input-arrives" */
#define EXTERNED_BLOCKUNTILINPUTARRIVES
#endif

#ifndef EXTERNED_XBTPPUCKMOVED
extern LVAL s_xbtppuckmoved;   /* Symbol "xbtp-puck-moved" */
#define EXTERNED_XBTPPUCKMOVED
#endif

#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S

DEFINE_SUBR( "XBTP-INITIALIZE",			xbtp06_Initialize_Fn	)
DEFINE_SUBR( "XBTP-READ-STATE",			xbtp11_Read_State_Fn	)
DEFINE_SUBR( "XBTP-RESOLUTION-IN-MICRONS",	xbtp13_Resolution_Fn	)
DEFINE_SUBR( "XBTP-TABLET-SIZE-IN-COUNTS",	xbtp15_Dimensions_Fn	)
DEFINE_SUBR( "XBTP-TABLETS-SUPPORTED",		xbtp17_Protocols_Fn	)
DEFINE_SUBR( "XBTP-PEN-THRESHOLD",		xbtp19_Pen_Threshold_Fn	)
/*DEFINE_SUBR( "XBTP-PX",				xbtpzz_Px_Fn	)*/


#endif



#ifdef MODULE_XLOBJ_C_GLOBALS

#ifndef DEFINED_PROTOCOL
LVAL k_protocol;/* Keyword ":protocol" */
#define DEFINED_PROTOCOL
#endif

#ifndef DEFINED_BITPAD1
LVAL k_bitpad1;/* Keyword ":bitpad1" */
#define DEFINED_BITPAD1
#endif

#ifndef DEFINED_WACOM_FAT_STYLUS
LVAL k_wacom_fat_stylus;/* Keyword ":wacom-fat-stylus" */
#define DEFINED_WACOM_FAT_STYLUS
#endif

#ifndef DEFINED_WACOM_THIN_STYLUS_TIP
LVAL k_wacom_thin_stylus_tip;/* Keyword ":wacom-thin-stylus-tip" */
#define DEFINED_WACOM_THIN_STYLUS_TIP
#endif

#ifndef DEFINED_WACOM_THIN_STYLUS_SIDE
LVAL k_wacom_thin_stylus_side;/* Keyword ":wacom-thin-stylus-side" */
#define DEFINED_WACOM_THIN_STYLUS_SIDE
#endif

#ifndef DEFINED_SUMMASKETCH2
LVAL k_summasketch2;/* Keyword ":summasketch2" */
#define DEFINED_SUMMASKETCH2
#endif

#ifndef DEFINED_DOWNCLICK
LVAL k_downclick;   /* Keyword ":downclick" */
#define DEFINED_DOWNCLICK
#endif

#ifndef DEFINED_DRAG
LVAL k_drag;   /* Keyword ":drag" */
#define DEFINED_DRAG
#endif

#ifndef DEFINED_SELECT
LVAL k_select;   /* Keyword ":select" */
#define DEFINED_SELECT
#endif

#ifndef DEFINED_UPCLICK
LVAL k_upclick;   /* Keyword ":upclick" */
#define DEFINED_UPCLICK
#endif

#ifndef DEFINED_S_XG3DMOUSEROW
LVAL s_xg3dmouserow;/* Symbol "XG.3D-MOUSE-ROW" */
#define DEFINED_S_XG3DMOUSEROW
#endif

#ifndef DEFINED_S_XG3DMOUSECOL
LVAL s_xg3dmousecol;/* Symbol "XG.3D-MOUSE-COL" */
#define DEFINED_S_XG3DMOUSECOL
#endif

#ifndef DEFINED_S_XG3DMOUSEPRESSURE
LVAL s_xg3dmousepressure;/* Symbol "XG.3D-MOUSE-PRESSURE" */
#define DEFINED_S_XG3DMOUSEPRESSURE
#endif

#ifndef DEFINED_S_XG3DMOUSESTATE
LVAL s_xg3dmousestate;/* Symbol "XG.3D-MOUSE-STATE" */
#define DEFINED_S_XG3DMOUSESTATE
#endif

#ifndef DEFINED_BLOCKUNTILINPUTARRIVES
LVAL k_blockuntilinputarrives;   /* Keyword ":block-until-input-arrives" */
#define DEFINED_BLOCKUNTILINPUTARRIVES
#endif

#ifndef DEFINED_XBTPPUCKMOVED
LVAL s_xbtppuckmoved;   /* Symbol "xbtp-puck-moved" */
#define DEFINED_XBTPPUCKMOVED
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_PROTOCOL
    k_protocol = xlenter(":PROTOCOL");
#define CREATED_PROTOCOL
#endif

#ifndef CREATED_BITPAD1
    k_bitpad1 = xlenter(":BITPAD1");
#define CREATED_BITPAD1
#endif

#ifndef CREATED_WACOM_FAT_STYLUS
    k_wacom_fat_stylus = xlenter(":WACOM-FAT-STYLUS");
#define CREATED_WACOM_FAT_STYLUS
#endif

#ifndef CREATED_WACOM_THIN_STYLUS_TIP
    k_wacom_thin_stylus_tip = xlenter(":WACOM-THIN-STYLUS-TIP");
#define CREATED_WACOM_THIN_STYLUS_TIP
#endif

#ifndef CREATED_WACOM_THIN_STYLUS_SIDE
    k_wacom_thin_stylus_side = xlenter(":WACOM-THIN-STYLUS-SIDE");
#define CREATED_WACOM_THIN_STYLUS_SIDE
#endif

#ifndef CREATED_SUMMASKETCH2
    k_summasketch2 = xlenter(":SUMMASKETCH2");
#define CREATED_SUMMASKETCH2
#endif

#ifndef CREATED_DOWNCLICK
    k_downclick = xlenter(":DOWNCLICK");
#define CREATED_DOWNCLICK
#endif

#ifndef CREATED_DRAG
    k_drag = xlenter(":DRAG");
#define CREATED_DRAG
#endif

#ifndef CREATED_SELECT
    k_select = xlenter(":SELECT");
#define CREATED_SELECT
#endif

#ifndef CREATED_UPCLICK
    k_upclick = xlenter(":UPCLICK");
#define CREATED_UPCLICK
#endif

#ifndef CREATED_S_XG3DMOUSEROW
    s_xg3dmouserow = xlenter("XG.3D-MOUSE-ROW");
#define CREATED_S_XG3DMOUSEROW
#endif

#ifndef CREATED_S_XG3DMOUSECOL
    s_xg3dmousecol = xlenter("XG.3D-MOUSE-COL");
#define CREATED_S_XG3DMOUSECOL
#endif

#ifndef CREATED_S_XG3DMOUSEPRESSURE
    s_xg3dmousepressure = xlenter("XG.3D-MOUSE-PRESSURE");
#define CREATED_S_XG3DMOUSEPRESSURE
#endif

#ifndef CREATED_S_XG3DMOUSESTATE
    s_xg3dmousestate = xlenter("XG.3D-MOUSE-STATE");
#define CREATED_S_XG3DMOUSESTATE
#endif

#ifndef CREATED_BLOCKUNTILINPUTARRIVES
    k_blockuntilinputarrives = xlenter(":BLOCK-UNTIL-INPUT-ARRIVES");
#define CREATED_BLOCKUNTILINPUTARRIVES
#endif

#ifndef CREATED_XBTPPUCKMOVED
    s_xbtppuckmoved = xlenter("XBTP-PUCK-MOVED");
#define CREATED_XBTPPUCKMOVED
#endif

#endif

