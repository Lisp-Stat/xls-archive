/* {{{ xtub.c -- tube objects.					     CrT*/
/*************************************************************************
*
* File:         xtub.c
* Description:  Hybrid-class code for tub (tube) objects.
* Author:       Jeff Prothero
* Created:      92Nov08
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Nov08 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xtub;
extern LVAL k_currentstate;
extern LVAL k_get;
extern LVAL k_initializefromfile;
extern LVAL k_initialstate;
extern LVAL k_label;
extern LVAL k_subtree;
extern LVAL lv_xlgt;
extern LVAL s_currentstate;
extern LVAL s_initialstate;
extern LVAL s_label;
extern LVAL s_strcat;
extern LVAL s_subtree;
extern LVAL k_subtree;
extern LVAL k_radians;
extern LVAL k_pointtextureu;
extern LVAL k_pointtexturev;
extern LVAL lv_xflv;
extern LVAL k_getarray;
extern LVAL k_setarray;
extern LVAL k_ribbonrelation;
extern LVAL k_framenumber ;
extern LVAL k_contourbase ;
extern LVAL k_contourlen  ;
extern LVAL k_ribbonbase  ;
extern LVAL k_ribbonlen   ;
extern LVAL k_ribbonislocked;
extern LVAL k_ribbonisinvisible;


extern LVAL s_stdout;
extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();
LVAL  xtub41_Put();

#include <math.h>
#include <string.h>
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cthl.h"
#ifdef MAYBE_NEEDED
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/clgt.h"
#include "../../xg.3d/c/ccmr.h"
#endif
#include "../../xg.3d.fileio/c/cfil.h"
#include "ctub.h"

ctub_rec* xtub9c_Find_Immediate_Base();

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xtub00_Is_New -- Initialize a new xtub instance.			*/

ctub_rec xtub_defaults = {
    C03D_xTUB,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */

    ~13,			/* spare_1			*/
    ~13,			/* spare_2			*/

   -314155.0 			/* fspare_1			*/
};


LVAL xtub00_Is_New()
/*-
    Initialize a new xtub instance.
-*/
{
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    ctub_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xtubp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( ctub_rec ) );

    /* Initialize menu record to reasonable default values: */
    r	= (ctub_rec*) gobjimmbase( lv );
   *r   = xtub_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    xthl91_SetObjectVariable( lv, s_initialstate, NIL );
    xthl91_SetObjectVariable( lv, s_currentstate, NIL );
    xthl91_SetObjectVariable( lv, s_subtree     , NIL );
    xthl91_SetObjectVariable( lv, s_label       ,   cvstring("()") );

    xtub41_Put( lv );

    return lv;
}

/* }}} */
/* {{{ xtub01_Get_A_XTUB -- Get arg, must be of class xtub.		*/

LOCAL LVAL xtub01_Get_A_XTUB()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XTUB has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xtub.  Similarly,          */
    /* nobody but nobody has any business resizing a xtub,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xtubp(m_as_lval) ||
        getgobjimmbytes(m_as_lval) != sizeof(ctub_rec)
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xtub03_Show_Msg -- Show the contents of a ctub.			*/

LVAL xtub03_Show_Msg()
{
    LVAL lv,fptr;

    /* get self and the file pointer */
    lv   = xtub01_Get_A_XTUB();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(lv,fptr);
    xgbj52_Show_Lval_Vector(lv,fptr);

    /* Print the tub record: */
    {   ctub_rec * r = xtub9c_Find_Immediate_Base( lv );
	/* Suppose I should write this someday... (buggo) */
    }

    /* return the gobject */
    return lv;
}

/* }}} */
/* {{{ xtub08_Copy_Msg -- Build copy of given CTUB.			*/

LVAL xtub09_Copy( m_as_lval )
LVAL		  m_as_lval;
{
    /* Create a new gobject to hold result: */
    ctub_rec*mh = xtub9c_Find_Immediate_Base( m_as_lval );
    ctub_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xtub,k_new);
    xlpop();
    nh = (ctub_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}
LVAL xtub08_Copy_Msg()
{
    LVAL m_as_lval;
    LVAL x_as_lval = xtub01_Get_A_XTUB();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xtub09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xtub28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xtub28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {   char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xtub29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xtub01_Get_A_XTUB();
    LVAL n_as_lval = xtub01_Get_A_XTUB();
    xllastarg();
    return xtub28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xtub40_Get_Msg -- Get keyword properties.                        */

LVAL xtub39_Get( lv_xtub )
LVAL             lv_xtub;
{
    extern LVAL true;/*xlglob.c*/
    ctub_rec* r = xtub9c_Find_Immediate_Base( lv_xtub );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL lv_result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if        (key == k_initialstate) {

        lv_result = xthl90_GetObjectVariable( lv_xtub, s_initialstate );

    } else if (key == k_currentstate) {

        lv_result = xthl90_GetObjectVariable( lv_xtub, s_currentstate );

    } else if (key == k_subtree) {

        lv_result = xthl90_GetObjectVariable( lv_xtub, s_subtree );

    } else if (key == k_label) {

        lv_result = xthl90_GetObjectVariable( lv_xtub, s_label );

    } else {

	/* If this isn't a property we know, do a generic get property: */
        lv_result = xthl8a_GetObjectProp( lv_xtub, key, default_val, got_default );
    }
    return lv_result;
}
LVAL xtub40_Get_Msg()
{
    return xtub39_Get( xtub01_Get_A_XTUB() );
}

/* }}} */
/* {{{ xtub42_Put_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Put, update XTUB_PROPS and xtub94_ProplistNth. */
#define XTUB_PROPS (4)

/* A little macro to make this fn a little neater: */
#define XTUB_REDO(x) {		\
    x;				\
    rebuild = TRUE;		\
}

LVAL xtub41_Put( lv_xtub )
LVAL             lv_xtub;
{
    ctub_rec* r = xtub9c_Find_Immediate_Base( lv_xtub );
    extern LVAL true;/*xlglob.c*/

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xtubz7_Read_Xtub_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_xtub,
		getfile(xlgetfile()),
		xtubz7_Read_Xtub_From_File,NULL
	    );

        } else if (key == k_initialstate) {

	    /* Be nice to to a little validation here at some point: */
	    LVAL lv_thinglist = xlgalist();
	    xthl91_SetObjectVariable( lv_xtub, s_initialstate, lv_thinglist );

        } else if (key == k_currentstate) {

	    /* Be nice to to a little validation here at some point: */
	    LVAL lv_thinglist = xlgalist();
	    xthl91_SetObjectVariable( lv_xtub, s_currentstate, lv_thinglist );

        } else if (key == k_subtree) {

#ifdef HMM
	    /* Subtree isn't used on tubes yet: */
            xlerror("Can't set subtree on tube",xlgetarg());
#else
	    /* Yah, be nice to do some validation: */
	    LVAL lv_subtree = xlgetarg();
	    xthl91_SetObjectVariable( lv_xtub, s_subtree, lv_subtree );

#endif

        } else if (key == k_label) {

	    LVAL lv_string = xlgastring();
	    xthl91_SetObjectVariable( lv_xtub, s_label, lv_string );

	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_xtub, key, xlgetarg() );
        }
    }

    return lv_xtub;
}
#undef XTUB_REDO
LVAL xtub42_Put_Msg()
{   /* Read keyword properties for a menu object. */
    LVAL   lv_xtub = xtub01_Get_A_XTUB();
    LVAL   result  = xtub41_Put( lv_xtub );
    return result;
}

/* }}} */
/* {{{ xtub91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xtub90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XTUB_PROPS + x03d89_PropListLength( *pPropList ) );
}
LVAL xtub91_ProplistLength_Msg()
{
    return xtub90_ProplistLength( xtub01_Get_A_XTUB() );
}

/* }}} */
/* {{{ xtub95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xtub94_ProplistNth( lv_g )
LVAL                     lv_g;
{
    LVAL*pPropList  = x03d73_pPropList( lv_g );
    LVAL lv_n       = xlgafixnum();
    int  n          = getfixnum(lv_n);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    switch (n) {
    case  0: return k_label;
    case  1: return k_initialstate;
    case  2: return k_currentstate;
    case  3: return k_subtree;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XTUB_PROPS,
	    lv_n,
	    default_val,
	    got_default
	);
    }
}
LVAL xtub95_ProplistNth_Msg()
{
    return xtub94_ProplistNth( xtub01_Get_A_XTUB() );
}

/* }}} */
/* {{{ xtub9c_Find_Immediate_Base                                       */

ctub_rec* xtub9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    ctub_rec*tub = (ctub_rec*) gobjimmbase( lv );
    return tub;
}

/* }}} */
/* {{{ xtubb9_Compute_Texture_Coords					*/

struct xtubb0_Index_Rec {
    LVAL lv_tubName;
    LVAL lv_thing;
    LVAL lv_pointGrl;
    LVAL lv_facetGrl;
    LVAL lv_ribbons;

    /* Arrays on ribbon relation as properties: */
    LVAL lv_frameNumber;
    LVAL lv_contourBase;
    LVAL lv_contourLen;
    LVAL lv_ribbonBase ;
    LVAL lv_ribbonLen  ;
    LVAL lv_ribbonIsLocked;
    LVAL lv_ribbonIsInvisible;

    /* Number of contours: */
    int contours;

    /* Per-contour information: */
    int*  frameNumber      ;
    int*  contourBase      ;
    int*  contourLen       ;
    int*  ribbonBase       ;
    int*  ribbonLen        ;
    char* ribbonIsLocked   ;
    char* ribbonIsInvisible;
};

void
xtubb7_Fetch_Contour_Information(
    LVAL lv_tub,
    struct xtubb0_Index_Rec* x
) {
    csry_rec* hc;
    csry_rec* hr;

    /* Unpack the stuff we need: */
    x->lv_tubName  = xthl90_GetObjectVariable( lv_tub, s_label );
    x->lv_thing    = xsendmsg1( lv_tub, k_get, k_initialstate );
    x->lv_pointGrl = xthlA2_Get_Point_Relation_From_Thing( x->lv_thing );
    x->lv_facetGrl = xthlA4_Get_Facet_Relation_From_Thing( x->lv_thing );

    /* Fetch ribbon relation from facet relation: */
    x->lv_ribbons	= xsendmsg1( x->lv_facetGrl, k_get, k_ribbonrelation );

    /* Fetch arrays from ribbon relation: */
    x->lv_frameNumber   = xsendmsg1(x->lv_ribbons, k_getarray, k_framenumber );
    x->lv_contourBase   = xsendmsg1(x->lv_ribbons, k_getarray, k_contourbase );
    x->lv_contourLen    = xsendmsg1(x->lv_ribbons, k_getarray, k_contourlen  );
    x->lv_ribbonBase    = xsendmsg1(x->lv_ribbons, k_getarray, k_ribbonbase  );
    x->lv_ribbonLen     = xsendmsg1(x->lv_ribbons, k_getarray, k_ribbonlen   );
    x->lv_ribbonIsLocked= xsendmsg1(x->lv_ribbons, k_getarray, k_ribbonislocked);
    x->lv_ribbonIsInvisible=xsendmsg1(x->lv_ribbons,k_getarray,k_ribbonisinvisible);

    /* Assume our arrays are 1-D and ignore fill pointer */
    /* ('cause it seems to be set to zero!)		 */
    hc = xsry9c_Find_Immediate_Base( x->lv_contourBase );
    x->contours = hc->dim[0];
    hr = xsry9c_Find_Immediate_Base( x->lv_ribbonBase  );

    /* buggo ... should do some validation in here. */
    x->frameNumber       = (int *) (csry_base( x->lv_frameNumber       ));
    x->contourBase       = (int *) (csry_base( x->lv_contourBase       ));
    x->contourLen        = (int *) (csry_base( x->lv_contourLen        ));
    x->ribbonBase        = (int *) (csry_base( x->lv_ribbonBase        ));
    x->ribbonLen         = (int *) (csry_base( x->lv_ribbonLen         ));
    x->ribbonIsLocked    = (char*) (csry_base( x->lv_ribbonIsLocked    ));
    x->ribbonIsInvisible = (char*) (csry_base( x->lv_ribbonIsInvisible ));
}

void
xtubb8_Compute_Texture_Coordinates(
    LVAL  lv_xtub,
    float radians
) {
    gt_tri_rec r;
    struct xtubb0_Index_Rec x;
    float  z_max;
    float  z_min;

    /* Unpack our per-contour information and such: */
    xtubb7_Fetch_Contour_Information( lv_xtub, &x );

    /* Unpack our standard geometry information: */
    xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
    xthlB3_Fill_Tri_Rec_From_Grl( &r, x.lv_pointGrl );
    xthlB3_Fill_Tri_Rec_From_Grl( &r, x.lv_facetGrl );

    /* If we don't have point texture arrays, create them: */
    if (!r.got_point_textures) {
	xsendmsg2( x.lv_pointGrl, k_setarray, k_pointtextureu, lv_xflv );
	xsendmsg2( x.lv_pointGrl, k_setarray, k_pointtexturev, lv_xflv );

	xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
	xthlB3_Fill_Tri_Rec_From_Grl( &r, x.lv_pointGrl );
	xthlB3_Fill_Tri_Rec_From_Grl( &r, x.lv_facetGrl );
if (!r.got_point_textures) {
fprintf(stderr,"xtubb8_Compute_Texture_Coordinates: WAHH!");
abort();
}
    }

/* Buggo, all this code needs to handle empty ctrs and tubs */

    /* Find maximum and minimum z-coords in tub: */
    z_min = r.z[ x.contourBase[            0 ] ];
    z_max = r.z[ x.contourBase[ x.contours-1 ] ];
/*printf("z_min g=%g z_max g=%g\n",z_min,z_max);*/

    /* Over all contours in tube: */
    {   int ctr;
	for (ctr = x.contours;   ctr --> 0;  ) {
	    float c_len = 0.0;
	    float c_loc = 0.0;
	    float u;
	    float v;

	    /* Find point with largest y-coord in contour: */
	    /* Over all points in contour: */
	    float y_max;
	    int   y_most;
	    int   i;
	    int   pt;
	    int   len  = x.contourLen[  ctr ];
	    int   base = x.contourBase[ ctr ];
	    for (pt = 0;  pt < len;   ++pt) {
		float y = r.y[ base + pt ];
		if (!pt  ||  y > y_max) {
		    y_max  =  y;
		    y_most = pt;
	    }   }
/*printf("y_max g=%g y_most d=%d (of %d pts)\n",y_max,y_most,x.contourLen[ctr]);*/

	    /* Compute contour length: */
	    {   float     last_x = r.x[ base + len-1 ];
		float     last_y = r.y[ base + len-1 ];
		for (pt = 0;  pt < len;   ++pt) {
		    float this_x = r.x[ base + pt    ];
		    float this_y = r.y[ base + pt    ];
		    float dist   = sqrt(
			(last_x - this_x) * (last_x - this_x) +
			(last_y - this_y) * (last_y - this_y)
		    );
		    c_len += dist;
/*printf("this_x %g this_y %g last_x %g last_y %g dist %g c_len %g\n",this_x,this_y,last_x,last_y,dist,c_len);*/
		    last_x = this_x;
		    last_y = this_y;
	    }   }
/*printf("c_len g=%g\n",c_len);*/

	    /* Compute v (z) texture coordinate for contour: */
	    v = (r.z[ base ] - z_min) / (z_max - z_min);

	    /* Assign texture coords to all points in contour. */
	    /* Over all points in contour, starting at y-most: */
	    {   float     last_x = r.x[ base + y_most ];
		float     last_y = r.y[ base + y_most ];
		for (pt=y_most, i=len;  i --> 0;   pt = (pt+1) % len) {

		    /* Compute our location on contour: */
		    float this_x = r.x[ base + pt    ];
		    float this_y = r.y[ base + pt    ];
		    float dist   = sqrt(
			(last_x - this_x) * (last_x - this_x) +
			(last_y - this_y) * (last_y - this_y)
		    );
		    c_loc += dist;
/*printf("this_x %g this_y %g last_x %g last_y %g dist %g c_loc %g\n",this_x,this_y,last_x,last_y,dist,c_loc);*/
		    last_x = this_x;
		    last_y = this_y;

		    /* Compute u texture coord, our position on contour: */
		    u = 1.0 - c_loc / c_len;

		    /* Set u,v texture coords for point: */
		    r.ptu[ base + pt ] = u;
		    r.ptv[ base + pt ] = v;
/*printf("Setting ctr %d point %d textcoords to %g,%g\n",ctr,pt,u,v);*/
		}
	    }
    }   }

}

LVAL xtubb9_Compute_Texture_Coordinates_Msg() {

    /* Get recipient of message: */
    LVAL   lv_xtub = xtub01_Get_A_XTUB();
    float  radians = 0.0;

    /* Parse any arguments.  Syntax is:                      	*/
    /* (send xtub :compute-texture-coords [ :radians angle ]	*/
    /* Where :RADIANS rotates the inserted texture map around	*/
    /* the contour.						*/

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_radians) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    radians = tmp;

	} else {
	    xlerror("Bad :COMPUTE-TEXTURE-COORDINATES keyword",key);
        }
    }

    xtubb8_Compute_Texture_Coordinates( lv_xtub, radians );

    return NIL;
}

/* }}} */
/* {{{ xtubz7_Read_Xtub_From_File                                       */

xtubz7_Read_Xtub_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   ctub_rec* h;
    char*     p;
    if (version != CTUB_REC_VERSION) {
	xlerror("xtubz7: unsupported version",cvfixnum(version));
    }
    h = (ctub_rec*) gobjimmbase( lv );

    p = (char*) &h->CTUB_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CTUB_INT32_COUNT,  magic, fp );

    p = (char*) &h->CTUB_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CTUB_FLOAT_COUNT,  magic, fp );

#ifdef NOT_CURRENTLY_NEEDED
    p = (char*) &h->CTUB_FIRST_BYTE;
    p = cfil52_Read_Bytes_From_File(   p, CTUB_BYTE_COUNT ,  magic, fp );
#endif
}

/* }}} */
/* {{{ xtubwo_Write_Xtub_To_Graphics_File                               */

xtubwo_Write_Xtub_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   ctub_rec* h = (ctub_rec*) gobjimmbase( lv );
	char*     p;

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CTUB_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CTUB_FIRST_INT32, CTUB_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CTUB_FIRST_FLOAT, CTUB_FLOAT_COUNT, fdob);
#ifdef NOT_CURRENTLY_NEEDED
	cfil45_Write_Bytes_To_File( &h->CTUB_FIRST_BYTE , CTUB_BYTE_COUNT , fdob);
#endif
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
