/* {{{ cslc.h -- xslc.c rotor (TuRN) objects.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94May03
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
********************************************************************************
*/

/* }}} */
/* {{{ --- header stuff ---						*/

#ifndef INCLUDED_CSLC_H
#define INCLUDED_CSLC_H

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/geo.h"

/* }}} */

#define CSLC_REC_VERSION (28)

#define CSLC_MAX_LABEL   (64)

/* A struct type that holds everything we need to know about a slc.     */
/* WARNING:  xslc.c depends on the below order to initialize correctly. */
/* See xslc00_Is_New.     						*/ 
struct cslc_struct {
    int           k_class; /* k_class should always be first in record. */
    c03d_fileInfo fileInfo;/* Always 2nd in record.  Save-file.         */

#define CSLC_FIRST_INT32 zDir
#define CSLC_INT32_COUNT 24
    int		zDir;
    int		clipBy;
    int		useCartoonMode;
    int		cursorMatDirty;
    int		face[6];

    int		a0_zplClipInside;
    int		a0_zplBoxFrontIsVisible;
    int		a0_zplBoxBackIsVisible;
    int		a0_zplBoxTabsAreVisible;
    int		a0_zplBoxTint;
    int		a0_zplBoxIsSolid;

    int		a1_zplClipInside;
    int		a1_zplBoxFrontIsVisible;
    int		a1_zplBoxBackIsVisible;
    int		a1_zplBoxTabsAreVisible;
    int		a1_zplBoxTint;
    int		a1_zplBoxIsSolid;

    int		  spare_1;
    int		  spare_2;


#define CSLC_FIRST_FLOAT zCoord
#define CSLC_FLOAT_COUNT 20

    float	zCoord;
    float	zRate;
    float	zCap;
    geo_matrix	cursorMat;

    float	fspare_1;

#define CSLC_FIRST_BYTE  label[0]
#define CSLC_BYTE_COUNT  (0 * CSLC_MAX_LABEL)
};
typedef struct cslc_struct  cslc_rec;

cslc_rec* xslc9c_Find_Immediate_Base();

#define xslcp(o) (gobjectp(o) && ((((cslc_rec*)(gobjimmbase(o)))->k_class) == C03D_xSLC))

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
#endif
/* }}} */
