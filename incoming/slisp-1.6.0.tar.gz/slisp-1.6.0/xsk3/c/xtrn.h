/* {{{ xtrn.h -- rotor (TuRN) filters.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Nov08
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xtrn;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xtrn00_Is_New();
extern LVAL xtrn08_Copy_Msg();
extern LVAL xtrn03_Show_Msg();
extern LVAL xtrn40_Get_Msg();
extern LVAL xtrn42_Put_Msg();
extern LVAL xtrn91_ProplistLength_Msg();
extern LVAL xtrn95_ProplistNth_Msg();

#ifndef EXTERNED_CURRENTSTATE
extern LVAL k_currentstate;/* Keyword ":current-state" */
#define EXTERNED_CURRENTSTATE
#endif

#ifndef EXTERNED_INITIALSTATE
extern LVAL k_initialstate;/* Keyword ":initial-state" */
#define EXTERNED_INITIALSTATE
#endif

#ifndef EXTERNED_SUBTREE
extern LVAL k_subtree;/* Keyword ":subtree" */
#define EXTERNED_SUBTREE
#endif

#ifndef EXTERNED_LABEL
extern LVAL k_label;/* Keyword ":label" */
#define EXTERNED_LABEL
#endif

#ifndef EXTERNED_S_CURRENTSTATE
extern LVAL s_currentstate;/* Symbol "current-state" */
#define EXTERNED_S_CURRENTSTATE
#endif

#ifndef EXTERNED_S_INITIALSTATE
extern LVAL s_initialstate;/* Symbol "initial-state" */
#define EXTERNED_S_INITIALSTATE
#endif

#ifndef EXTERNED_S_SUBTREE
extern LVAL s_subtree;/* Symbol "subtree" */
#define EXTERNED_S_SUBTREE
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,			xtrn00_Is_New			)
DEFINE_SUBR(	NULL,			xtrn08_Copy_Msg			)
DEFINE_SUBR(	NULL,			xtrn03_Show_Msg			)
DEFINE_SUBR(	NULL,			xtrn40_Get_Msg			)
DEFINE_SUBR(	NULL,			xtrn42_Put_Msg			)
DEFINE_SUBR(	NULL,			xtrn91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,			xtrn95_ProplistNth_Msg		)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLINIT
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xtrn;
LOCAL struct xtrn_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xtrn_table[] = {
    {	":ISNEW",		xtrn00_Is_New			},
    {	":COPY",		xtrn08_Copy_Msg			},
    {	":SHOW",		xtrn03_Show_Msg			},
    {	":GET", 		xtrn40_Get_Msg			},
    {	":SET", 		xtrn42_Put_Msg			},
    {	":PROPERTY-LIST-LENGTH",xtrn91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xtrn95_ProplistNth_Msg		},

    {	NULL,			NULL				}
};

#ifndef DEFINED_CURRENTSTATE
LVAL k_currentstate;/* Keyword ":current-state" */
#define DEFINED_CURRENTSTATE
#endif

#ifndef DEFINED_INITIALSTATE
LVAL k_initialstate;/* Keyword ":initial-state" */
#define DEFINED_INITIALSTATE
#endif

#ifndef DEFINED_SUBTREE
LVAL k_subtree;/* Keyword ":subtree" */
#define DEFINED_SUBTREE
#endif

#ifndef DEFINED_LABEL
LVAL k_label;/* Keyword ":label" */
#define DEFINED_LABEL
#endif

#ifndef DEFINED_S_CURRENTSTATE
LVAL s_currentstate;/* Symbol "current-state" */
#define DEFINED_S_CURRENTSTATE
#endif

#ifndef DEFINED_S_INITIALSTATE
LVAL s_initialstate;/* Symbol "initial-state" */
#define DEFINED_S_INITIALSTATE
#endif

#ifndef DEFINED_S_SUBTREE
LVAL s_subtree;/* Symbol "subtree" */
#define DEFINED_S_SUBTREE
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_CURRENTSTATE
    k_currentstate = xlenter(":CURRENT-STATE");
#define CREATED_CURRENTSTATE
#endif

#ifndef CREATED_INITIALSTATE
    k_initialstate = xlenter(":INITIAL-STATE");
#define CREATED_INITIALSTATE
#endif

#ifndef CREATED_SUBTREE
    k_subtree = xlenter(":SUBTREE");
#define CREATED_SUBTREE
#endif

#ifndef CREATED_LABEL
    k_label = xlenter(":LABEL");
#define CREATED_LABEL
#endif

#ifndef CREATED_S_CURRENTSTATE
    s_currentstate = xlenter("CURRENT-STATE");
#define CREATED_S_CURRENTSTATE
#endif

#ifndef CREATED_S_INITIALSTATE
    s_initialstate = xlenter("INITIAL-STATE");
#define CREATED_S_INITIALSTATE
#endif

#ifndef CREATED_S_SUBTREE
    s_subtree = xlenter("SUBTREE");
#define CREATED_S_SUBTREE
#endif


#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xtrn = xgbj58_Create_Class("CLASS-SK3-ROTOR",lv_x03d);
    xgbj57_Add_Instance_Variable( lv_xtrn,"INITIAL-STATE"); /* stuff with our state */
    xgbj57_Add_Instance_Variable( lv_xtrn,"CURRENT-STATE"); /* stuff with our state */
    xgbj57_Add_Instance_Variable( lv_xtrn,"SUBTREE");
    xgbj56_Enter_Messages(        lv_xtrn, xtrn_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
