/* {{{ ceye.h -- xeye.c camera filter objects.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94May03
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1994, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
********************************************************************************
*/

/* }}} */
/* {{{ --- header stuff ---						*/

#ifndef INCLUDED_CEYE_H
#define INCLUDED_CEYE_H

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/geo.h"

/* }}} */

#define CEYE_REC_VERSION (28)

#define CEYE_MAX_LABEL   (64)

/* A struct type that holds everything we need to know about a eye.     */
/* WARNING:  xeye.c depends on the below order to initialize correctly. */
/* See xeye00_Is_New.     						*/ 
struct ceye_struct {
    int           k_class; /* k_class should always be first in record. */
    c03d_fileInfo fileInfo;/* Always 2nd in record.  Save-file.         */

#define CEYE_FIRST_INT32 spare_1
#define CEYE_INT32_COUNT 3
    int		  spare_1;
    int		  spare_2;
    int           portShape;

#define CEYE_FIRST_FLOAT fspare_1
#define CEYE_FLOAT_COUNT 1

    float	fspare_1;

#define CEYE_FIRST_BYTE  label[0]
#define CEYE_BYTE_COUNT  (0 * CEYE_MAX_LABEL)
};
typedef struct ceye_struct  ceye_rec;

#define xeyep(o) (gobjectp(o) && ((((ceye_rec*)(gobjimmbase(o)))->k_class) == C03D_xEYE))

ceye_rec* xeye9c_Find_Immediate_Base();

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
#endif
/* }}} */
