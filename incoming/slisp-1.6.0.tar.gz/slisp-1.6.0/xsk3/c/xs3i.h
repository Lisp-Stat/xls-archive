/* {{{ xs3i.h -- Skandha3 file Input.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Mar01
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS

extern LVAL xs3i90_Load_Skandha3_File_Fn();

#ifndef EXTERNED_LIGHTIS
extern LVAL k_lightis; /* Keyword ":light-is" */
#define EXTERNED_LIGHTIS
#endif

#ifndef EXTERNED_ADDITIONAL
extern LVAL k_additional; /* Keyword ":additional" */
#define EXTERNED_ADDITIONAL
#endif

#ifndef EXTERNED_REPLACEMENT
extern LVAL k_replacement; /* Keyword ":replacement" */
#define EXTERNED_REPLACEMENT
#endif

#ifndef EXTERNED_ZCOORDINATE
extern LVAL k_zcoordinate; /* Keyword ":z-coordinate" */
#define EXTERNED_ZCOORDINATE
#endif

/* Commented out because it's in xlglob.c: */
/* #ifndef EXTERNED_DIRECTION */
/* extern LVAL k_direction; /* Keyword ":direction" */
/* #define EXTERNED_DIRECTION */
/* #endif */

#ifndef EXTERNED_POLYGONS
extern LVAL k_polygons; /* Keyword ":polygons" */
#define EXTERNED_POLYGONS
#endif

#ifndef EXTERNED_OFFSET
extern LVAL k_offset; /* Keyword ":offset" */
#define EXTERNED_OFFSET
#endif

#ifndef EXTERNED_TILINGISDIRTY
extern LVAL k_tilingisdirty; /* Keyword ":tiling-is-dirty" */
#define EXTERNED_TILINGISDIRTY
#endif

#ifndef EXTERNED_DISPLAYAS
extern LVAL k_displayas; /* Keyword ":display-as" */
#define EXTERNED_DISPLAYAS
#endif

#ifndef EXTERNED_DISPLAYNORMALS
extern LVAL k_displaynormals; /* Keyword ":display-normals" */
#define EXTERNED_DISPLAYNORMALS
#endif

#ifndef EXTERNED_FACETNORMALSDIRTY
extern LVAL k_facetnormalsdirty; /* Keyword ":facet-normals-dirty" */
#define EXTERNED_FACETNORMALSDIRTY
#endif

#ifndef EXTERNED_SELFLENGTH
extern LVAL k_selflength; /* Keyword ":self-length" */
#define EXTERNED_SELFLENGTH
#endif


#ifndef EXTERNED_SET
extern LVAL k_set;/* Keyword ":set" */
#define EXTERNED_SET
#endif

#ifndef EXTERNED_SETARRAY
extern LVAL k_setarray;/* Keyword ":SET-ARRAY" */
#define EXTERNED_SETARRAY
#endif

#ifndef EXTERNED_FRAMENUMBER
extern LVAL k_framenumber;/* Keyword ":FRAME-NUMBER" */
#define EXTERNED_FRAMENUMBER
#endif

#ifndef EXTERNED_CONTOURBASE
extern LVAL k_contourbase;/* Keyword ":CONTOUR-BASE" */
#define EXTERNED_CONTOURBASE
#endif

#ifndef EXTERNED_CONTOURLEN
extern LVAL k_contourlen;/* Keyword ":CONTOUR-LEN" */
#define EXTERNED_CONTOURLEN
#endif

#ifndef EXTERNED_RIBBONBASE
extern LVAL k_ribbonbase;/* Keyword ":RIBBON-BASE" */
#define EXTERNED_RIBBONBASE
#endif

#ifndef EXTERNED_RIBBONLEN
extern LVAL k_ribbonlen;/* Keyword ":RIBBON-LEN" */
#define EXTERNED_RIBBONLEN
#endif

#ifndef EXTERNED_RIBBONRELATION
extern LVAL k_ribbonrelation;/* Keyword ":RIBBON-RELATION" */
#define EXTERNED_RIBBONRELATION
#endif

#ifndef EXTERNED_RIBBONISLOCKED
extern LVAL k_ribbonislocked;/* Keyword ":RIBBON-IS-LOCKED" */
#define EXTERNED_RIBBONISLOCKED
#endif

#ifndef EXTERNED_RIBBONISINVISIBLE
extern LVAL k_ribbonisinvisible;/* Keyword ":RIBBON-IS-INVISIBLE" */
#define EXTERNED_RIBBONISINVISIBLE
#endif

#ifndef EXTERNED_M4400
extern LVAL k_m4400;/* Keyword ":M44[0][0]" */
#define EXTERNED_M4400
#endif
#ifndef EXTERNED_M4401
extern LVAL k_m4401;/* Keyword ":M44[0][1]" */
#define EXTERNED_M4401
#endif
#ifndef EXTERNED_M4402
extern LVAL k_m4402;/* Keyword ":M44[0][2]" */
#define EXTERNED_M4402
#endif
#ifndef EXTERNED_M4403
extern LVAL k_m4403;/* Keyword ":M44[0][3]" */
#define EXTERNED_M4403
#endif

#ifndef EXTERNED_M4410
extern LVAL k_m4410;/* Keyword ":M44[1][0]" */
#define EXTERNED_M4410
#endif
#ifndef EXTERNED_M4411
extern LVAL k_m4411;/* Keyword ":M44[1][1]" */
#define EXTERNED_M4411
#endif
#ifndef EXTERNED_M4412
extern LVAL k_m4412;/* Keyword ":M44[1][2]" */
#define EXTERNED_M4412
#endif
#ifndef EXTERNED_M4413
extern LVAL k_m4413;/* Keyword ":M44[1][3]" */
#define EXTERNED_M4413
#endif

#ifndef EXTERNED_M4420
extern LVAL k_m4420;/* Keyword ":M44[2][0]" */
#define EXTERNED_M4420
#endif
#ifndef EXTERNED_M4421
extern LVAL k_m4421;/* Keyword ":M44[2][1]" */
#define EXTERNED_M4421
#endif
#ifndef EXTERNED_M4422
extern LVAL k_m4422;/* Keyword ":M44[2][2]" */
#define EXTERNED_M4422
#endif
#ifndef EXTERNED_M4423
extern LVAL k_m4423;/* Keyword ":M44[2][3]" */
#define EXTERNED_M4423
#endif

#ifndef EXTERNED_M4430
extern LVAL k_m4430;/* Keyword ":M44[3][0]" */
#define EXTERNED_M4430
#endif
#ifndef EXTERNED_M4431
extern LVAL k_m4431;/* Keyword ":M44[3][1]" */
#define EXTERNED_M4431
#endif
#ifndef EXTERNED_M4432
extern LVAL k_m4432;/* Keyword ":M44[3][2]" */
#define EXTERNED_M4432
#endif
#ifndef EXTERNED_M4433
extern LVAL k_m4433;/* Keyword ":M44[3][3]" */
#define EXTERNED_M4433
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	"XSK3-LOAD-SKANDHA3-FILE",	xs3i90_Load_Skandha3_File_Fn	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS

#ifndef DEFINED_ZCOORDINATE
LVAL k_zcoordinate; /* Keyword ":Z-COORDINATE" */
#define DEFINED_ZCOORDINATE
#endif

#ifndef DEFINED_LIGHTIS
LVAL k_lightis; /* Keyword ":LIGHT-IS" */
#define DEFINED_LIGHTIS
#endif

#ifndef DEFINED_ADDITIONAL
LVAL k_additional; /* Keyword ":ADDITIONAL" */
#define DEFINED_ADDITIONAL
#endif

#ifndef DEFINED_REPLACMENT
LVAL k_replacement; /* Keyword ":REPLACEMENT" */
#define DEFINED_REPLACEMENT
#endif

/* Commented out because it's in xlglob.c: */
/* #ifndef DEFINED_DIRECTION */
/* LVAL k_direction; /* Keyword ":DIRECTION" */
/* #define DEFINED_DIRECTION */
/* #endif */

#ifndef DEFINED_POLYGONS
LVAL k_polygons; /* Keyword ":POLYGONS" */
#define DEFINED_POLYGONS
#endif

#ifndef DEFINED_OFFSET
LVAL k_offset; /* Keyword ":OFFSET" */
#define DEFINED_OFFSET
#endif

#ifndef DEFINED_TILINGISDIRTY
LVAL k_tilingisdirty; /* Keyword ":TILING-IS-DIRTY" */
#define DEFINED_TILINGISDIRTY
#endif

#ifndef DEFINED_DISPLAYAS
LVAL k_displayas; /* Keyword ":DISPLAY-AS" */
#define DEFINED_DISPLAYAS
#endif

#ifndef DEFINED_DISPLAYNORMALS
LVAL k_displaynormals; /* Keyword ":DISPLAY-NORMALS" */
#define DEFINED_DISPLAYNORMALS
#endif

#ifndef DEFINED_FACETNORMALSDIRTY
LVAL k_facetnormalsdirty; /* Keyword ":FACET-NORMALS-DIRTY" */
#define DEFINED_FACETNORMALSDIRTY
#endif

#ifndef DEFINED_SELFLENGTH
LVAL k_selflength; /* Keyword ":SELF-LENGTH" */
#define DEFINED_SELFLENGTH
#endif

#ifndef DEFINED_SET
LVAL k_set;/* Keyword ":SET" */
#define DEFINED_SET
#endif

#ifndef DEFINED_SETARRAY
LVAL k_setarray;/* Keyword ":SET-ARRAY" */
#define DEFINED_SETARRAY
#endif

#ifndef DEFINED_FRAMENUMBER
LVAL k_framenumber;/* Keyword ":FRAME-NUMBER" */
#define DEFINED_FRAMENUMBER
#endif

#ifndef DEFINED_CONTOURBASE
LVAL k_contourbase;/* Keyword ":CONTOUR-BASE" */
#define DEFINED_CONTOURBASE
#endif

#ifndef DEFINED_CONTOURLEN
LVAL k_contourlen;/* Keyword ":CONTOUR-LEN" */
#define DEFINED_CONTOURLEN
#endif

#ifndef DEFINED_RIBBONBASE
LVAL k_ribbonbase;/* Keyword ":RIBBON-BASE" */
#define DEFINED_RIBBONBASE
#endif

#ifndef DEFINED_RIBBONLEN
LVAL k_ribbonlen;/* Keyword ":RIBBON-LEN" */
#define DEFINED_RIBBONLEN
#endif

#ifndef DEFINED_RIBBONRELATION
LVAL k_ribbonrelation;/* Keyword ":RIBBON-RELATION" */
#define DEFINED_RIBBONRELATION
#endif

#ifndef DEFINED_RIBBONISLOCKED
LVAL k_ribbonislocked;/* Keyword ":RIBBON-IS-LOCKED" */
#define DEFINED_RIBBONISLOCKED
#endif

#ifndef DEFINED_RIBBONISINVISIBLE
LVAL k_ribbonisinvisible;/* Keyword ":RIBBON-IS-INVISIBLE" */
#define DEFINED_RIBBONISINVISIBLE
#endif

#ifndef DEFINED_M4400
LVAL k_m4400;/* Keyword ":M44[0][0]" */
#define DEFINED_M4400
#endif
#ifndef DEFINED_M4401
LVAL k_m4401;/* Keyword ":M44[0][1]" */
#define DEFINED_M4401
#endif
#ifndef DEFINED_M4402
LVAL k_m4402;/* Keyword ":M44[0][2]" */
#define DEFINED_M4402
#endif
#ifndef DEFINED_M4403
LVAL k_m4403;/* Keyword ":M44[0][3]" */
#define DEFINED_M4403
#endif

#ifndef DEFINED_M4410
LVAL k_m4410;/* Keyword ":M44[1][0]" */
#define DEFINED_M4410
#endif
#ifndef DEFINED_M4411
LVAL k_m4411;/* Keyword ":M44[1][1]" */
#define DEFINED_M4411
#endif
#ifndef DEFINED_M4412
LVAL k_m4412;/* Keyword ":M44[1][2]" */
#define DEFINED_M4412
#endif
#ifndef DEFINED_M4413
LVAL k_m4413;/* Keyword ":M44[1][3]" */
#define DEFINED_M4413
#endif

#ifndef DEFINED_M4420
LVAL k_m4420;/* Keyword ":M44[2][0]" */
#define DEFINED_M4420
#endif
#ifndef DEFINED_M4421
LVAL k_m4421;/* Keyword ":M44[2][1]" */
#define DEFINED_M4421
#endif
#ifndef DEFINED_M4422
LVAL k_m4422;/* Keyword ":M44[2][2]" */
#define DEFINED_M4422
#endif
#ifndef DEFINED_M4423
LVAL k_m4423;/* Keyword ":M44[2][3]" */
#define DEFINED_M4423
#endif

#ifndef DEFINED_M4430
LVAL k_m4430;/* Keyword ":M44[3][0]" */
#define DEFINED_M4430
#endif
#ifndef DEFINED_M4431
LVAL k_m4431;/* Keyword ":M44[3][1]" */
#define DEFINED_M4431
#endif
#ifndef DEFINED_M4432
LVAL k_m4432;/* Keyword ":M44[3][2]" */
#define DEFINED_M4432
#endif
#ifndef DEFINED_M4433
LVAL k_m4433;/* Keyword ":M44[3][3]" */
#define DEFINED_M4433
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_ZCOORDINATE
    k_zcoordinate = xlenter(":Z-COORDINATE");
#define CREATED_ZCOORDINATE
#endif

#ifndef CREATED_LIGHTIS
    k_lightis = xlenter(":LIGHT-IS");
#define CREATED_LIGHTIS
#endif

#ifndef CREATED_ADDITIONAL
    k_additional = xlenter(":ADDITIONAL");
#define CREATED_ADDITIONAL
#endif

#ifndef CREATED_REPLACEMENT
    k_replacement = xlenter(":REPLACEMENT");
#define CREATED_REPLACEMENT
#endif

/* Commented out because it's in xlglob.c: */
/* #ifndef CREATED_DIRECTION */
/*     k_direction = xlenter(":DIRECTION"); */
/* #define CREATED_DIRECTION */
/* #endif */

#ifndef CREATED_POLYGONS
    k_polygons = xlenter(":POLYGONS");
#define CREATED_POLYGONS
#endif

#ifndef CREATED_OFFSET
    k_offset = xlenter(":OFFSET");
#define CREATED_OFFSET
#endif

#ifndef CREATED_TILINGISDIRTY
    k_tilingisdirty = xlenter(":TILING-IS-DIRTY");
#define CREATED_TILINGISDIRTY
#endif

#ifndef CREATED_DISPLAYAS
    k_displayas = xlenter(":DISPLAY-AS");
#define CREATED_DISPLAYAS
#endif

#ifndef CREATED_DISPLAYNORMALS
    k_displaynormals = xlenter(":DISPLAY-NORMALS");
#define CREATED_DISPLAYNORMALS
#endif

#ifndef CREATED_FACETNORMALSDIRTY
    k_facetnormalsdirty = xlenter(":FACET-NORMALS-DIRTY");
#define CREATED_FACETNORMALSDIRTY
#endif

#ifndef CREATED_SELFLENGTH
    k_selflength = xlenter(":SELF-LENGTH");
#define CREATED_SELFLENGTH
#endif


#ifndef CREATED_SET
    k_set = xlenter(":SET");
#define CREATED_SET
#endif

#ifndef CREATED_SETARRAY
    k_setarray = xlenter(":SET-ARRAY");
#define CREATED_SETARRAY
#endif

#ifndef CREATED_FRAMENUMBER
    k_framenumber = xlenter(":FRAME-NUMBER");
#define CREATED_FRAMENUMBER
#endif

#ifndef CREATED_CONTOURBASE
    k_contourbase = xlenter(":CONTOUR-BASE");
#define CREATED_CONTOURBASE
#endif

#ifndef CREATED_CONTOURLEN
    k_contourlen = xlenter(":CONTOUR-LEN");
#define CREATED_CONTOURLEN
#endif

#ifndef CREATED_RIBBONBASE
    k_ribbonbase = xlenter(":RIBBON-BASE");
#define CREATED_RIBBONBASE
#endif

#ifndef CREATED_RIBBONLEN
    k_ribbonlen = xlenter(":RIBBON-LEN");
#define CREATED_RIBBONLEN
#endif

#ifndef CREATED_RIBBONRELATION
    k_ribbonrelation = xlenter(":RIBBON-RELATION");
#define CREATED_RIBBONRELATION
#endif

#ifndef CREATED_RIBBONISLOCKED
    k_ribbonislocked = xlenter(":RIBBON-IS-LOCKED");
#define CREATED_RIBBONISLOCKED
#endif

#ifndef CREATED_RIBBONISINVISIBLE
    k_ribbonisinvisible = xlenter(":RIBBON-IS-INVISIBLE");
#define CREATED_RIBBONISINVISIBLE
#endif

#ifndef CREATED_M4400
    k_m4400 = xlenter(":M44[0][0]");
#define CREATED_M4400
#endif
#ifndef CREATED_M4401
    k_m4401 = xlenter(":M44[0][1]");
#define CREATED_M4401
#endif
#ifndef CREATED_M4402
    k_m4402 = xlenter(":M44[0][2]");
#define CREATED_M4402
#endif
#ifndef CREATED_M4403
    k_m4403 = xlenter(":M44[0][3]");
#define CREATED_M4403
#endif

#ifndef CREATED_M4410
    k_m4410 = xlenter(":M44[1][0]");
#define CREATED_M4410
#endif
#ifndef CREATED_M4411
    k_m4411 = xlenter(":M44[1][1]");
#define CREATED_M4411
#endif
#ifndef CREATED_M4412
    k_m4412 = xlenter(":M44[1][2]");
#define CREATED_M4412
#endif
#ifndef CREATED_M4413
    k_m4413 = xlenter(":M44[1][3]");
#define CREATED_M4413
#endif

#ifndef CREATED_M4420
    k_m4420 = xlenter(":M44[2][0]");
#define CREATED_M4420
#endif
#ifndef CREATED_M4421
    k_m4421 = xlenter(":M44[2][1]");
#define CREATED_M4421
#endif
#ifndef CREATED_M4422
    k_m4422 = xlenter(":M44[2][2]");
#define CREATED_M4422
#endif
#ifndef CREATED_M4423
    k_m4423 = xlenter(":M44[2][3]");
#define CREATED_M4423
#endif

#ifndef CREATED_M4430
    k_m4430 = xlenter(":M44[3][0]");
#define CREATED_M4430
#endif
#ifndef CREATED_M4431
    k_m4431 = xlenter(":M44[3][1]");
#define CREATED_M4431
#endif
#ifndef CREATED_M4432
    k_m4432 = xlenter(":M44[3][2]");
#define CREATED_M4432
#endif
#ifndef CREATED_M4433
    k_m4433 = xlenter(":M44[3][3]");
#define CREATED_M4433
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
