#define SAVE_LID_TEXTURES_SOON (1)
/* {{{ xs3i.c -- Skandha3 Input fns.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Mar01
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 96Aug06 jsp: Read full color info in skandha3 file format.		*/
/* 92Mar01 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

  

#include "../../xcore/c/xlisp.h"

/* For GT_AS_SOLID and such: */
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/cthl.h"
#include "../../xg.3d/c/ctxr.h"
#include "../../xg.3d/c/clgt.h"

#include "cclr.h"
#include "ctrn.h"
#include "ceye.h"
#include "cslc.h"
#include "clit.h"
#include "ctxf.h"

extern LVAL k_lightis;
extern LVAL k_additional;
extern LVAL k_replacement;
extern LVAL k_graphicrelation;
extern LVAL k_adjustarray;
extern LVAL k_contourbase;
extern LVAL k_contourlen;
extern LVAL k_currentstate;
extern LVAL k_pointtextureu;
extern LVAL k_pointtexturev;
extern LVAL k_facetnormalx;
extern LVAL k_facetnormaly;
extern LVAL k_facetnormalz;
extern LVAL k_framenumber;
extern LVAL k_getarray;
extern LVAL k_initialstate;
extern LVAL k_label;
extern LVAL k_name;
extern LVAL k_ribbonbase;
extern LVAL k_ribbonisinvisible;
extern LVAL k_ribbonislocked;
extern LVAL k_ribbonlen;
extern LVAL k_ribbonrelation;
extern LVAL k_set;
extern LVAL k_setarray;
extern LVAL k_subtree;
extern LVAL lv_x01v;
extern LVAL lv_xclr;
extern LVAL lv_xedt;
extern LVAL lv_xeye;
extern LVAL lv_xflv;
extern LVAL lv_xlst;
extern LVAL lv_xslc;
extern LVAL lv_xsub;
extern LVAL lv_xtfm;
extern LVAL lv_xtrn;
extern LVAL lv_xtub;
extern LVAL s_label;

extern LVAL k_m4400;/* Keyword ":M44[0][0]" */
extern LVAL k_m4401;/* Keyword ":M44[0][1]" */
extern LVAL k_m4402;/* Keyword ":M44[0][2]" */
extern LVAL k_m4403;/* Keyword ":M44[0][3]" */

extern LVAL k_m4410;/* Keyword ":M44[1][0]" */
extern LVAL k_m4411;/* Keyword ":M44[1][1]" */
extern LVAL k_m4412;/* Keyword ":M44[1][2]" */
extern LVAL k_m4413;/* Keyword ":M44[1][3]" */

extern LVAL k_m4420;/* Keyword ":M44[2][0]" */
extern LVAL k_m4421;/* Keyword ":M44[2][1]" */
extern LVAL k_m4422;/* Keyword ":M44[2][2]" */
extern LVAL k_m4423;/* Keyword ":M44[2][3]" */

extern LVAL k_m4430;/* Keyword ":M44[3][0]" */
extern LVAL k_m4431;/* Keyword ":M44[3][1]" */
extern LVAL k_m4432;/* Keyword ":M44[3][2]" */
extern LVAL k_m4433;/* Keyword ":M44[3][3]" */

extern LVAL xsendmsg0(); 
extern LVAL xsendmsg1(); 
extern LVAL xsendmsg2(); 

#define PaSCII  (1)
#define PbINARY (2)

#define UsAMEsTRING (0)

union uAnyType {
    int       uI;
    int   *   uP;
    float     uF;
    float *   uFP;
    char  *   uT;
    LVAL      uL;
    short *   uSP;
    int     (*uFn)();
};
#define uAny		union uAnyType

LVAL xs3i86_Load_Subtree();

LVAL xs3i10_Load_Clr();
LVAL xs3i15_Load_Ctr();
LVAL xs3i17_Load_Edt();
LVAL xs3i20_Load_Fbr();
LVAL xs3i25_Load_Lid();
LVAL xs3i30_Load_Lit();
LVAL xs3i35_Load_Lst();
LVAL xs3i37_Load_Prt();
LVAL xs3i40_Load_Pts();
LVAL xs3i45_Load_Rbn();
LVAL xs3i50_Load_Sub();
LVAL xs3i55_Load_Trn();
LVAL xs3i60_Load_Tub();
LVAL xs3i65_Load_Zpl();
LVAL xs3i70_Load_Txf();

LVAL xs3i89_Load_File();

void xs3ia5_Load_FltArray(float*,int,int,FILE*);

#define XSK3_MAX_TEXT (200)
#define XS3I_MODULES_INSTALLED 15
char  xs3i00_Text_Buffer[ XSK3_MAX_TEXT ];
int   xs3i01_Modules_Installed = XS3I_MODULES_INSTALLED;
char* xs3i02_Module_Prefix[ XS3I_MODULES_INSTALLED ] = {
    "clr",
    "ctr",
    "edt",
    "fbr",
    "lid",
    "lit",
    "lst",
    "prt",
    "pts",
    "rbn",
    "sub",
    "trn",
    "tub",
    "zpl",
    "txf",
};
LVAL (*xs3i03_Module_Load_Fn[ XS3I_MODULES_INSTALLED ])() = {
    xs3i10_Load_Clr,
    xs3i15_Load_Ctr,
    xs3i17_Load_Edt,
    xs3i20_Load_Fbr,
    xs3i25_Load_Lid,
    xs3i30_Load_Lit,
    xs3i35_Load_Lst,
    xs3i37_Load_Prt,
    xs3i40_Load_Pts,
    xs3i45_Load_Rbn,
    xs3i50_Load_Sub,
    xs3i55_Load_Trn,
    xs3i60_Load_Tub,
    xs3i65_Load_Zpl,
    xs3i70_Load_Txf,
};

int  xs3i04_Point_Grl_Valid = FALSE;
LVAL xs3i05_Point_Grl;

int  xs3i06_Facet_Grl_Valid = FALSE;
LVAL xs3i07_Facet_Grl;

LVAL xs3i08_Ribbon_Grl;

int  xs3ipn_PointCount;
LVAL xs3ipx_PointX;
LVAL xs3ipy_PointY;
LVAL xs3ipz_PointZ;
/* Point(point) normals: */
LVAL xs3ivx_PtNmlX;
LVAL xs3ivy_PtNmlY;
LVAL xs3ivz_PtNmlZ;
LVAL xs3ipu_PtTxrU;
LVAL xs3ipv_PtTxrV;

int  xs3ifn_FacetCount;
LVAL xs3if0_Facet0;
LVAL xs3if1_Facet1;
LVAL xs3if2_Facet2;
LVAL xs3ifx_FtNmlX;
LVAL xs3ify_FtNmlY;
LVAL xs3ifz_FtNmlZ;

/* Quick-and-dirty indices to the tub(e) we're building: */
#define XSK3_MAX_CTRS_PER_TUB (1000)
struct xs3icr_Ctr_Rec {
    int        point_base;
    int        point_len;
    float      ctr_zcoord;		/* Used to sort ribbons. */
    int        ctr_frameNumber;	/* Only for user and generating Skandha3 files. */
    int        facet_base;
    int        facet_len;
    unsigned   locked:    1;
    unsigned   invisible: 1;
    geo_matrix m;
} xs3ict_Ctr[ XSK3_MAX_CTRS_PER_TUB ];
char xs3ict_TubeName[ 128 ];
int  xs3icn_CtrNext;

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ sk309_FGetW -- Read 4 bytes from file.				*/

sk309_FGetW(	fd )
FILE *		fd;
{
    /*************************************************************/
    /* The SVC DOS library getw() fn is buggy: it interprets the */
    /* first 0xFF byte it finds as an end of file.   This is not */
    /* good when reading binary files!	So we use fread instead: */
    /*************************************************************/
    CSRY_INT32   i;
    fread( &i, sizeof(CSRY_INT32), 1, fd );
    return  i;
}

/* }}} */
/* {{{ xs3i10_Load_Clr -- Load object from file				*/

/* The color-table segments: */
#define LIBtINTdEFAULT  (-1) 
#define LIBtINTmIN      0  
#define LIBtINTwHITE    0  
#define LIBtINTrED      1   
#define LIBtINTgREEN    2   
#define LIBtINTbLUE     3   
#define LIBtINTmAGENTA  4   
#define LIBtINTcYAN     5   
#define LIBtINTyELLOW   6   
#define LIBtINTmAX      7  

/* Types of surface representation: */
#define LIBsTYLEdEFAULT		-1
#define LIBsTYLEcONTOURS	0
#define LIBsTYLEvECTORS		1
#define LIBsTYLEfACETS		2
#define LIBsTYLEsMOOTH		3
#define LIBsTYLEpOINTS		4
#define LIBsTYLEiNVISIBLE	5
#define LIBsTYLEmAX		5

struct libTintRecord {
    float libTRMaxRed;
    float libTRMaxGreen;
    float libTRMaxBlue;
} libTint[ LIBtINTmAX ];
int libCurrentTint=1;

LVAL xs3i10_Load_Clr( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    char	version;
    int		self_clrRefCount;
    int		self_clrColor;
    int		self_clrNormals;
    int		self_clrStyle;
    float	self_clrOpacity;
    int		self_clrBackfaces;
    int		self_clrOkToAnimate;


    LVAL	lv_result;
    LVAL	lv_clr;
    LVAL	lv_initialMtl;
    LVAL	lv_currentMtl;
    int         toProt = 4;
    xlstkcheck(toProt);
    xlsave(lv_clr);
    xlsave(lv_initialMtl);
    xlsave(lv_currentMtl);
    xlsave(lv_result);

    switch (t) {

    case PaSCII:
    case PbINARY:
        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
            sscanf( xs3i00_Text_Buffer, "%s\n", buf ); 
	    if (*buf < 'a'   ||   *buf > 'e')	xlfail("clrLoad");
            version	= *buf;
        }

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_clrRefCount );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_clrColor	);

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_clrNormals  );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_clrStyle	  );

        if (
            self_clrStyle < LIBsTYLEdEFAULT
            ||
            self_clrStyle > LIBsTYLEmAX
        ) {
            self_clrStyle = LIBsTYLEmAX;
        }

	if (version >= 'b') {
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_clrOpacity );
	} else {
	    self_clrOpacity	 = 1.0;
	}
	if (version >= 'c') {
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_clrBackfaces );
	} else {
            self_clrBackfaces  = -1;
        }

	if (version >= 'd') {
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_clrOkToAnimate );
	} else {
            self_clrOkToAnimate = 1;
        }



	/* Read in our pointset: */
	{   extern LVAL k_new;
	    extern LVAL lv_xmtl;
	    int old_tint           = libCurrentTint;
	    int our_tint           = self_clrColor;

            /* Create our CLASS-MATERIAL instance to hold color etc: */
            cmtl_rec* i_material;
            cmtl_rec* c_material;
	    lv_initialMtl		   = xsendmsg0(lv_xmtl,k_new);
	    lv_currentMtl		   = xsendmsg0(lv_xmtl,k_new);
	    i_material = (cmtl_rec*) gobjimmbase(lv_initialMtl);
	    c_material = (cmtl_rec*) gobjimmbase(lv_currentMtl);

	    if (our_tint==LIBtINTdEFAULT) our_tint = libCurrentTint;
	    else libCurrentTint    = self_clrColor;


#ifndef OLD
	    if (version >= 'e') {
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%d\n", &i_material->r.opacity_type  );

		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.emission_color.r );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.emission_color.g );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.emission_color.b );

		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.ambient_color.r );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.ambient_color.g );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.ambient_color.b );

		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.diffuse_color.r );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.diffuse_color.g );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.diffuse_color.b );

		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.specular_color.r );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.specular_color.g );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.specular_color.b );

		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.shininess );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.alpha     );

		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.emission_weight );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.ambient_weight );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.diffuse_weight );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.specular_weight );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.shininess_weight );
		xs3i88_Read_Line( fd );
		sscanf(xs3i00_Text_Buffer, "%f\n", &i_material->r.alpha_weight );
	    } else {
		i_material->r.diffuse_color.r = libTint[ our_tint ].libTRMaxRed;
		i_material->r.diffuse_color.g = libTint[ our_tint ].libTRMaxGreen;
		i_material->r.diffuse_color.b = libTint[ our_tint ].libTRMaxBlue;



		/* Set up other values to approximate Skandha3 ... weakly ... */

		i_material->r.emission_color.r = 0.0;
		i_material->r.emission_color.g = 0.0;
		i_material->r.emission_color.b = 0.0;

		i_material->r.ambient_color.r  = 0.0;
		i_material->r.ambient_color.g  = 0.0;
		i_material->r.ambient_color.b  = 0.0;

		i_material->r.specular_color.r = 0.0;
		i_material->r.specular_color.g = 0.0;
		i_material->r.specular_color.b = 0.0;

	    }
#endif
	    switch (self_clrStyle) {
	    case LIBsTYLEdEFAULT:  i_material->r.draw_as=GT_AS_DEFAULT;    break;
	    case LIBsTYLEcONTOURS:
	    case LIBsTYLEvECTORS:  i_material->r.draw_as=GT_AS_WIRE_FRAME; break;
	    case LIBsTYLEfACETS:   i_material->r.draw_as=GT_AS_FACETS;     break;
	    case LIBsTYLEsMOOTH:   i_material->r.draw_as=GT_AS_SOLID;      break;
	    case LIBsTYLEpOINTS:   i_material->r.draw_as=GT_AS_POINT_CLOUD;break;
	    case LIBsTYLEiNVISIBLE:i_material->r.draw_as=GT_AS_INVISIBLE;  break;
	    }
	    i_material->r.dirty      = TRUE;
	    lv_result              = xs3i86_Load_Subtree( fd, t );

	    libCurrentTint         = old_tint;

            *c_material = *i_material;


	}

        {
            char buf[ 80 ];
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "."    )   !=   UsAMEsTRING
            &&  strcmp( buf, ".clr" )   !=   UsAMEsTRING) {
                xlfail("clrLoad");
            }
        }
        break;

    default:
        xlfail("clrLoad");
    }

    lv_clr = xsendmsg2( lv_xclr, k_new, k_subtree, lv_result );
    xsendmsg2( lv_clr, k_set, k_initialstate, lv_initialMtl );
    xsendmsg2( lv_clr, k_set, k_currentstate, lv_currentMtl );
    {   cclr_rec* clr      = xclr9c_Find_Immediate_Base( lv_clr );
	clr->tint          = self_clrColor      ;
	clr->normals       = self_clrNormals    ;
	clr->opacity       = self_clrOpacity    ;
	clr->backfaces     = self_clrBackfaces  ;
	clr->ok_to_animate = self_clrOkToAnimate;
    }
    xlpopn(toProt);
    return lv_clr;
}

/* }}} */
/* {{{ xs3i15_Load_Ctr -- Load object from file				*/

LVAL xs3i15_Load_Ctr( dumm, t, fd )
LVAL                  dumm;
int                         t;
FILE *                         fd;
{
    char  buf[ 80 ];

    int   self_ctrRefCount;
    int   self_ctrDisplayAs;
    int   self_ctrFinished;
    float self_ctrZCoord;
    int   self_ctrFrameNo;
    int   self_ctrAreaDirty;
    float self_ctrArea;
    float self_ctrCentroidX;
    float self_ctrCentroidY;
    int   self_ctrIsOpen;
    int   self_ctrWasReversed;
    float self_ctr2D_t2_x0, self_ctr2D_t2_x1, self_ctr2D_t2_x2;
    float self_ctr2D_t2_y0, self_ctr2D_t2_y1, self_ctr2D_t2_y2;
    geo_matrix m;

    char  version;

    int        toProt = 0;
    xlstkcheck(toProt);


    /*++libObjCreates;*/

    switch (t) {

    case PaSCII:
    case PbINARY:

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf );
        version = buf[0];

        if (version < 'a'   ||   version > 'e')  xlfail("ctrLoad");

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ctrRefCount	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ctrDisplayAs	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ctrFinished	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctrZCoord 	 );
	xs3ict_Ctr[ xs3icn_CtrNext ].ctr_zcoord = self_ctrZCoord ;

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ctrFrameNo	 );
	xs3ict_Ctr[ xs3icn_CtrNext ].ctr_frameNumber = self_ctrFrameNo;

        if (version <= 'a') {

            self_ctrAreaDirty	= TRUE;

        } else {

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_ctrAreaDirty	);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctrArea		);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctrCentroidX	);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctrCentroidY	);
        }
        if (version < 'c') {

            self_ctrIsOpen         = FALSE; 
            self_ctrWasReversed    = FALSE; 

        } else {    

            xs3i88_Read_Line( fd );    
            sscanf( xs3i00_Text_Buffer, "%d\n", &self_ctrIsOpen         );  

            xs3i88_Read_Line( fd );    
            sscanf( xs3i00_Text_Buffer, "%d\n", &self_ctrWasReversed    ); 
        } 
  
        if (version < 'd') {

#ifdef OLD
            /* Initial life-time edit transform is null: */
            struct libMatRec m;
            mdcMatNull( &m );
            ctrEdit_3D_to_2D( &self->ctr2D, &m );
#endif

        } else {

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctr2D_t2_x0	     );

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctr2D_t2_x1	     );

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctr2D_t2_x2	     );

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctr2D_t2_y0	     );

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctr2D_t2_y1	     );

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_ctr2D_t2_y2	     );
        }

        if (version < 'e') {

	    int      row;
	    int      col;
	    for     (row = 0;   row < 4;   ++row) {
	        for (col = 0;   col < 4;   ++col) {
		    m.m[row][col] = (row==col) ? 1.0 : 0.0;
	    }	}

        } else {

	    int      row;
	    int      col;
	    for     (row = 0;   row < 4;   ++row) {
	        for (col = 0;   col < 4;   ++col) {
                    xs3i88_Read_Line( fd );
		    sscanf(xs3i00_Text_Buffer,"%lf\n",&m.m[row][col]);
        }   }	}
	xs3ict_Ctr[ xs3icn_CtrNext ].m = m;

	/* Read in our pointset: */
	xs3i86_Load_Subtree( fd, t );

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf );
        if (strcmp( buf, "."    )   !=   UsAMEsTRING
        &&  strcmp( buf, ".ctr" )   !=   UsAMEsTRING)  xlfail("ctrLoad");
        break;

    default:
        xlfail("ctrLoad");
    }

    xlpopn(toProt);

    return  NIL;
}

/* }}} */
/* {{{ xs3i17_Load_Edt -- Load editor from file				*/

LVAL xs3i17_Load_Edt( dumm, t, fd )
LVAL                  dumm;
int                         t;
FILE *                         fd;
{
    LVAL	lv_result;
    LVAL	lv_edt;

    char  buf[ 80 ];

    int   self_edtRefCount;

    char  version;

    int        toProt = 2;
    xlstkcheck(toProt);
    xlsave(lv_edt);
    xlsave(lv_result);

    /*++libObjCreates;*/

    switch (t) {

    case PaSCII:
    case PbINARY:

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf );
        version = buf[0];

        if (version < 'a'   ||   version > 'a')  xlfail("edtLoad");

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_edtRefCount	 );

	/* Read in our child: */
	lv_result = xs3i86_Load_Subtree( fd, t );

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf );
        if (strcmp( buf, "."    )   !=   UsAMEsTRING
        &&  strcmp( buf, ".edt" )   !=   UsAMEsTRING)  xlfail("edtLoad");
        break;

    default:
        xlfail("edtLoad");
    }

    lv_edt = xsendmsg2( lv_xedt, k_new, k_subtree, lv_result );
    xsendmsg2( lv_edt, k_set, k_initialstate, NIL );
    xsendmsg2( lv_edt, k_set, k_currentstate, NIL );

    xlpopn(toProt);

    return lv_edt;
}

/* }}} */
/* {{{ xs3i20_Load_Fbr -- Load object from file				*/

LVAL xs3i20_Load_Fbr( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    int		version;
    char	buf[ 80 ];
    int		self_fbrRefCount;
    int		self_fbrDisplayAs;
    int		self_fbrFinished;
    float	self_fbrZCoord;
    int		self_fbrFrameNo;
    int		self_fbrThinnedBy;
    float	self_fbrThinSpacing;
    float	self_fbrThinScale;
    char	self_fbrThinWhen[128];
    char	self_fbrThinWho[128];

    switch (t) {

    case PaSCII:
    case PbINARY:

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf );
        version	= buf[0];

        if (version < 'a'    ||   version > 'c')   xlfail("fbrLoad");

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_fbrRefCount	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_fbrDisplayAs	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_fbrFinished	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &self_fbrZCoord 	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_fbrFrameNo	 );

        if (version < 'c') {

#ifdef OLD
            self_fbrThinnedBy		= THINNEDbYnONE;
            self_fbrThinSpacing		= 0.0;
            self_fbrThinScale	 	= 0.0;
            strcpy( self->fbrThinWhen, "$" );
            strcpy( self->fbrThinWho,  "$" );
#endif

        } else {

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_fbrThinnedBy	);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_fbrThinSpacing	);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_fbrThinScale	);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n",  self_fbrThinWhen	);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n",  self_fbrThinWho	);

#ifdef OLD
            libStrUnderlinesToBlanks( self->fbrThinWhen );
            libStrUnderlinesToBlanks( self->fbrThinWho  );
#endif
        }

	/* Load our pointset: */
	xs3i86_Load_Subtree( fd, t );

        if (version < 'b') {
#ifdef OLD
            self->fbrChildOriginal.uI	= UcOPY( self->fbrChild.uO, t, 0 );
#endif
        } else {
	    /* Read (and discard) unmodified fiberset: */
	    xs3i86_Load_Subtree( fd, t );
        }

#ifdef OLD
        self->fbrParent.uI	= libNopObject();
        self->fbrPrevSibling.uI	= libNopObject();
        self->fbrNextSibling.uI	= libNopObject();
        self->fbrParent.uI	= libNopObject();
        self->fbrPointsTemp	= FALSE;
#endif

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf );
        if (strcmp( buf, "."    )   !=   UsAMEsTRING
        &&  strcmp( buf, ".fbr" )   !=   UsAMEsTRING)   xlfail("fbrLoad");

        break;

    default:
        xlfail("fbrLoad");
    }

    xlfail("xs3i20_Load_Fbr: not implemented");
    return NIL;
}

/* }}} */
/* {{{ xs3i25_Load_Lid -- Load object from file				*/

LVAL xs3i25_Load_Lid( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    /* Lisp keywords we need: */

    extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xflv;
    extern LVAL lv_x32v;
    extern LVAL lv_xlid;

    extern LVAL k_pointx;
    extern LVAL k_pointy;
    extern LVAL k_pointz;

    extern LVAL k_pointnormalx;
    extern LVAL k_pointnormaly;
    extern LVAL k_pointnormalz;

    extern LVAL k_facet0;
    extern LVAL k_facet1;
    extern LVAL k_facet2;

    extern LVAL k_set;
    extern LVAL k_setarray;

    extern LVAL k_material;
    extern LVAL k_pointrelation;
    extern LVAL k_facetrelation;
    extern LVAL k_facetif;

    extern LVAL k_zcoordinate;
    extern LVAL k_direction;
    extern LVAL k_polygons;
    extern LVAL k_offset;
    extern LVAL k_tilingisdirty;
    extern LVAL k_displayas;
    extern LVAL k_displaynormals;
    extern LVAL k_facetnormalsdirty;
    extern LVAL k_selflength;

    char	self_lidTubeName[128];
    float	self_lidTubeZCoord;
    int		self_lidDirection;
    int		self_lidRefCount;
    int		self_lidPolygons;
    int		self_lidFinished;
    int		self_lidResult_uI;
    float	self_lidOffset;
    int		self_lidTilingIsDirty;
    int		self_lidDisplayAs;
    int		self_lidDisplayNormals;
    int		self_lidFacetNormalDirty;
    int		self_lidSelfLen;
    float	self_lidFacetNormal_uPtX;
    float	self_lidFacetNormal_uPtY;
    float	self_lidFacetNormal_uPtZ;

    char      version;



    /* Variables to hold lisp values: */

    LVAL lv_result;
    LVAL lv_lid = NIL;
    LVAL lv_point_grl;
    LVAL lv_facet_grl;
    LVAL lv_pointCount;
    LVAL lv_facetCount;
    LVAL lv_lidName;

#ifdef SAVE_LID_TEXTURES_SOON
    LVAL lv_ptTxrU;    LVAL lv_ptTxrV;
#endif
    LVAL lv_pointX;    LVAL lv_pointY;    LVAL lv_pointZ;
    LVAL lv_ptNmlX;    LVAL lv_ptNmlY;    LVAL lv_ptNmlZ;
    LVAL lv_facet0;    LVAL lv_facet1;    LVAL lv_facet2;



    /* Tell the garbage collector */
    /* about all our lisp values: */

#ifdef SAVE_LID_TEXTURES_SOON
    int        toProt = 18;
#else
    int        toProt = 16;
#endif
    xlstkcheck(toProt);

    xlsave( lv_result     );
    xlsave( lv_lid        );

    xlsave( lv_point_grl  );
    xlsave( lv_facet_grl  );

    xlsave( lv_facetCount );
    xlsave( lv_pointCount );

    xlsave( lv_lidName    );

#ifdef SAVE_LID_TEXTURES_SOON
    xlsave( lv_ptTxrU );    xlsave( lv_ptTxrV );
#endif
    xlsave( lv_pointX );    xlsave( lv_pointY );    xlsave( lv_pointZ );
    xlsave( lv_ptNmlX );    xlsave( lv_ptNmlY );    xlsave( lv_ptNmlZ );
    xlsave( lv_facet0 );    xlsave( lv_facet1 );    xlsave( lv_facet2 );



    switch (t) {

    case PaSCII:
    case PbINARY:
        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            version	= *buf;

#ifdef SAVE_LID_TEXTURES_SOON
	    if (version < 'a'	||   version > 'b') {
#else
	    if (version < 'a'	||   version > 'a') {
#endif
		xlfail("lidLoad");
            }
        }

	/* Read in the local scalar values: */

        xs3i88_Read_Line( fd ); 
        sscanf( xs3i00_Text_Buffer, "%s\n",  self_lidTubeName		);  
	lv_lidName = cvstring( xs3i00_Text_Buffer );

        xs3i88_Read_Line( fd );  
        sscanf( xs3i00_Text_Buffer, "%f\n", &self_lidTubeZCoord		);  

        xs3i88_Read_Line( fd );  
        sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidDirection		); 

	xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidRefCount		); 

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidPolygons		);

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidFinished		);

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidResult_uI		);

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &self_lidOffset 		);

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidTilingIsDirty	);

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidDisplayAs		);

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidDisplayNormals	);

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidFacetNormalDirty	);

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lidSelfLen	);

	/* Watch for obsolete (or unknown) DisplayAs: */
        if (
	    self_lidDisplayAs < LIBsTYLEdEFAULT
            ||
	    self_lidDisplayAs > LIBsTYLEmAX
        ) {
	    self_lidDisplayAs = LIBsTYLEdEFAULT;
        }



	/* Create our point relation: */
	lv_pointCount	= cvfixnum( self_lidPolygons + 2 );
	lv_point_grl	= xsendmsg1( lv_xgrl, k_new, lv_pointCount );

	/* Create point-x/y/z arrays to go in point relation: */
	lv_pointX	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
	lv_pointY	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
	lv_pointZ	= xsendmsg1( lv_xflv, k_new, lv_pointCount );

	/* Insert point-x/y/z arrays in point relation: */
	xsendmsg2( lv_point_grl, k_setarray, k_pointx, lv_pointX );
	xsendmsg2( lv_point_grl, k_setarray, k_pointy, lv_pointY );
	xsendmsg2( lv_point_grl, k_setarray, k_pointz, lv_pointZ );

	/* Create point-normal-x/y/z arrays to go in point relation: */
	lv_ptNmlX	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
	lv_ptNmlY	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
	lv_ptNmlZ	= xsendmsg1( lv_xflv, k_new, lv_pointCount );

	/* Insert point-normal-x/y/z arrays in point relation: */
	xsendmsg2( lv_point_grl, k_setarray, k_pointnormalx, lv_ptNmlX );
	xsendmsg2( lv_point_grl, k_setarray, k_pointnormaly, lv_ptNmlY );
	xsendmsg2( lv_point_grl, k_setarray, k_pointnormalz, lv_ptNmlZ );

	/* Create our facet relation: */
	lv_facetCount	= cvfixnum( self_lidPolygons );
	lv_facet_grl	= xsendmsg1( lv_xgrl, k_new, lv_facetCount );

	/* Create facet-0/1/2 arrays to go in facet relation: */
	lv_facet0	= xsendmsg1( lv_x32v, k_new, lv_facetCount );
	lv_facet1	= xsendmsg1( lv_x32v, k_new, lv_facetCount );
	lv_facet2	= xsendmsg1( lv_x32v, k_new, lv_facetCount );

	/* Insert facet-0/1/2 arrays in facet relation: */
	xsendmsg2( lv_facet_grl, k_setarray, k_facet0, lv_facet0 );
	xsendmsg2( lv_facet_grl, k_setarray, k_facet1, lv_facet1 );
	xsendmsg2( lv_facet_grl, k_setarray, k_facet2, lv_facet2 );




	/* Load our polygon definitions and facet normal: */
        if (t == PaSCII) {

	    /* Read facet normal: */
	    xs3i88_Read_Line( fd );
	    sscanf(
		xs3i00_Text_Buffer,
		"%f %f %f\n",
		&self_lidFacetNormal_uPtX,
		&self_lidFacetNormal_uPtY,
		&self_lidFacetNormal_uPtZ
	    );

	    /* Read polygon definitions, initialize per-polygon info: */
	    {   /* Get pointers to the actual int areas, for speed:   */
		int* facet0 = (int*) (csry_base( lv_facet0 ));
		int* facet1 = (int*) (csry_base( lv_facet1 ));
		int* facet2 = (int*) (csry_base( lv_facet2 ));
		int  i;
		for (i = 0;   i < self_lidPolygons;   ++i) {	
		    int p0, p1, p2;
		    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%d %d %d\n", &p0, &p1, &p2 );
		    facet0[i] = p0;
		    facet1[i] = p1;
		    facet2[i] = p2;
	    }   }

        } else {

	    /* Read facet normal: */
            register uAny      u;
            u.uI                        = sk309_FGetW( fd );
            self_lidFacetNormal_uPtX   = u.uF; 
            u.uI                        = sk309_FGetW( fd );
	    self_lidFacetNormal_uPtY	= u.uF;
            u.uI                        = sk309_FGetW( fd );
	    self_lidFacetNormal_uPtZ	= u.uF;

	    /* Read polygon definitions, initialize per-polygon info: */
	    {   /* Get pointers to the actual int areas, for speed:   */
		int* facet0 = (int*) (csry_base( lv_facet0 ));
		int* facet1 = (int*) (csry_base( lv_facet1 ));
		int* facet2 = (int*) (csry_base( lv_facet2 ));
		int  i;
		for (i = 0;   i < self_lidPolygons;   ++i) {	

		    int p0 = sk309_FGetW( fd );
		    int p1 = sk309_FGetW( fd );
		    int p2 = sk309_FGetW( fd );

		    facet0[i] = p0;
		    facet1[i] = p1;
		    facet2[i] = p2;
        }   }   }

	/* Initialize per-point info: */
	{   /* Get pointers to the actual float areas, for speed:   */

	    float* ptNmlX = (float*) (csry_base( lv_ptNmlX ));
	    float* ptNmlY = (float*) (csry_base( lv_ptNmlY ));
	    float* ptNmlZ = (float*) (csry_base( lv_ptNmlZ ));

	    float* pointX = (float*) (csry_base( lv_pointX ));
	    float* pointY = (float*) (csry_base( lv_pointY ));
	    float* pointZ = (float*) (csry_base( lv_pointZ ));

	    int  i;
	    for (i = 0;   i < self_lidPolygons+2;   ++i) {	

		ptNmlX[i] = self_lidFacetNormal_uPtX;
		ptNmlY[i] = self_lidFacetNormal_uPtY;
		ptNmlZ[i] = self_lidFacetNormal_uPtZ;

		pointX[i] = (float) (i*1);
		pointY[i] = (float) (i*i);
		pointZ[i] = self_lidTubeZCoord;
	}   }

#ifdef OLD
	self->lidContour.uI	= FALSE;
        self->lidIsNonce        = FALSE;
#endif

#ifdef SAVE_LID_TEXTURES_SOON
        if (version > 'a') {
	    /* Over all point-texture arrays (maybe someday more): */
	    for (;;) {
		xs3i88_Read_Line( fd );
		if (strcmp( xs3i00_Text_Buffer, "."    ) == UsAMEsTRING
		||  strcmp( xs3i00_Text_Buffer, ".lid" ) == UsAMEsTRING)   break;

		/* Should have an array.  First three chars */
		/* give the array type, currently this has  */
		/* to be 'flt':                             */
		if (!strncmp( xs3i00_Text_Buffer, "flt", 3)) {

		    /* Load in in a flt array: */
		    char*  name   = xs3i00_Text_Buffer+4;
		    float* ary;

            	    /* Insert point-texture arrays if not yet created: */
	    	    if (null(lv_ptTxrU)) {
			lv_ptTxrU = xsendmsg1(
			    lv_xflv, k_new, lv_pointCount
			);
			xsendmsg2(
			    lv_point_grl,
			    k_setarray,
			    k_pointtextureu,
			    lv_ptTxrU
			);
		    }
	    	    if (null(lv_ptTxrV)) {
			lv_ptTxrV = xsendmsg1(
			    lv_xflv, k_new, lv_pointCount
			);
			xsendmsg2(
			    lv_point_grl,
			    k_setarray,
			    k_pointtexturev,
			    lv_ptTxrV
			);
		    }

		    /* Get pointer directly to array: */
		    if (       !strcmp( name, ":POINT-TEXTURE-U")) {
			ary = (float*) (csry_base( lv_ptTxrU ));
		    } else if (!strcmp( name, ":POINT-TEXTURE-V")) {
			ary = (float*) (csry_base( lv_ptTxrV ));
		    } else {
			xlerror("ptsLoad: unknown array name",cvstring(name));
		    }

		    xs3ia5_Load_FltArray( ary, self_lidPolygons+2, t, fd );
	}   }   } else 
#endif

        {   char buf[ 80 ];
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
	    if (strcmp( buf, "."    )  != UsAMEsTRING
	    &&  strcmp( buf, ".lid" )  != UsAMEsTRING
            ){
		xlfail("lidLoad");
	    }
        }


#ifdef OLD
	lidEdit_NameUpdate( self );
#endif
	break;

    default:
	xlfail("lidLoad");
    }

    /* Construct return value: */

    lv_result   = cons( lv_facet_grl    ,       NIL );
    lv_result   = cons( k_facetrelation , lv_result );

    lv_result   = cons( lv_point_grl    , lv_result );
    lv_result   = cons( k_pointrelation , lv_result );

    lv_result	= cons( lv_lidName      , lv_result );
    lv_result	= cons( k_name          , lv_result );

    /* Construct the class-sk3-lid object: */
    lv_lid	= xsendmsg2( lv_xlid, k_new, k_initialstate, lv_result );
    xsendmsg2( lv_lid, k_set, k_currentstate, lv_result );

    /* Set name variable in lid: */
    xthl91_SetObjectVariable( lv_lid, s_label, lv_lidName );

    /* Save other info on lid, mostly for so xs3o.c can  */
    /* regenerate the original data on output as closely */
    /* as practical:                                     */
    #define fix(x) cvfixnum(x)
    #define flo(x) cvflonum(x)
    xsendmsg2(lv_lid,k_set,k_zcoordinate      ,flo(self_lidTubeZCoord      ));
    xsendmsg2(lv_lid,k_set,k_direction        ,fix(self_lidDirection       ));
    xsendmsg2(lv_lid,k_set,k_polygons         ,fix(self_lidPolygons        ));
    xsendmsg2(lv_lid,k_set,k_offset	      ,flo(self_lidOffset          ));
    xsendmsg2(lv_lid,k_set,k_tilingisdirty    ,fix(self_lidTilingIsDirty   ));
    xsendmsg2(lv_lid,k_set,k_displayas        ,fix(self_lidDisplayAs       ));
    xsendmsg2(lv_lid,k_set,k_displaynormals   ,fix(self_lidDisplayNormals  ));
    xsendmsg2(lv_lid,k_set,k_facetnormalsdirty,fix(self_lidFacetNormalDirty));
    xsendmsg2(lv_lid,k_set,k_selflength       ,fix(self_lidSelfLen         ));
    #undef flo
    #undef fix

#ifdef CRIB
    "%f\n", &self_lidTubeZCoord		);  
    "%d\n", &self_lidDirection		); 
    "%d\n", &self_lidPolygons		);
    "%f\n", &self_lidOffset 		);
    "%d\n", &self_lidTilingIsDirty	);
    "%d\n", &self_lidDisplayAs		);
    "%d\n", &self_lidDisplayNormals	);
    "%d\n", &self_lidFacetNormalDirty	);
    "%d\n", &self_lidSelfLen	        );

    extern LVAL k_zcoordinate;
    extern LVAL k_direction;
    extern LVAL k_polygons;
    extern LVAL k_offset;
    extern LVAL k_tilingisdirty;
    extern LVAL k_displayas;
    extern LVAL k_displaynormals;
    extern LVAL k_facetnormalsdirty;
    extern LVAL k_selflength;
#endif




#ifdef OLD
    if (libDebug) printf("\nLoaded lid '%s'",UpgET(((uObj)self),PnAME));
#endif

    xlpopn(toProt);

    return   lv_lid;
}

/* }}} */
/* {{{ xs3i30_Load_Lit -- Load object from file				*/

LVAL xs3i30_Load_Lit( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    extern LVAL lv_xlit;

    char      version;
    int       self_litLightIs;
    int       self_litRefCount;
    int       self_litDefault;
    float     self_litSunAltitude;
    float     self_litSunAzimuth;
    int       self_litFixed;
    float     self_litSun[3];
    int       self_litOkToAnimate;

    int       self_litLightIsLocal;

    float     self_litAmbientR;
    float     self_litAmbientG;
    float     self_litAmbientB;

    float     self_litColorR;
    float     self_litColorG;
    float     self_litColorB;

    float     self_litTargetX;
    float     self_litTargetY;
    float     self_litTargetZ;

    LVAL	lv_lit;
    LVAL	lv_result;
    LVAL	lv_initialLgt;
    LVAL	lv_currentLgt;
    int         toProt = 4;
    xlstkcheck(toProt);
    xlsave(lv_result);
    xlsave(lv_lit);
    xlsave(lv_initialLgt);
    xlsave(lv_currentLgt);

    switch (t) {

    case PaSCII:
    case PbINARY:
	xs3i88_Read_Line( fd );
	version     = *xs3i00_Text_Buffer;
	if (version < 'a'   ||	 version > 'e') {
	    printf("\nVersion '%c' not supported", *xs3i00_Text_Buffer);
            xlfail("litLoad");
	}

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_litRefCount    );

        xs3i88_Read_Line( fd );
	if (version < 'c') {
	    /* Due to a typo, versions before 'c' had '\d' instead of '\n': */
	    sscanf(
		xs3i00_Text_Buffer,"%dd%f\n",&self_litDefault,&self_litSunAltitude
	    );
	} else {
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_litDefault );
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_litSunAltitude );
	}

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &self_litSunAzimuth  );

        if (version == 'a') {
#ifdef OLD
            lit_Update( self );
#endif
            self_litFixed	= TRUE;
        } else {
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_litSun[0] );
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_litSun[1] );
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_litSun[2] );
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_litFixed );
	}

        if (version >= 'd') {
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_litOkToAnimate );
        } else {
            self_litOkToAnimate= TRUE;
        }

        if (version >= 'e') {
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_litLightIsLocal );

            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%f\n", &self_litAmbientR );
            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%f\n", &self_litAmbientG );
            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%f\n", &self_litAmbientB );

            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%f\n", &self_litColorR );
            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%f\n", &self_litColorG );
            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%f\n", &self_litColorB );

            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%f\n", &self_litTargetX );
            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%f\n", &self_litTargetY );
            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%f\n", &self_litTargetZ );

            xs3i88_Read_Line(fd);sscanf(xs3i00_Text_Buffer,"%d\n", &self_litLightIs );
	}

	lv_result = xs3i86_Load_Subtree( fd, t );

        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "."    )   !=   UsAMEsTRING
            &&  strcmp( buf, ".lit" )   !=   UsAMEsTRING
            ){
                xlfail("litLoad");
            }
        }
        break;

    default:
        xlfail("litLoad");
    }

    lv_lit = xsendmsg2( lv_xlit, k_new, k_subtree, lv_result );
    {   extern LVAL k_new;
	extern LVAL lv_xlgt;

	/* Create our CLASS-LIGHT instance: */
	clgt_rec* i_light;
	clgt_rec* c_light;
	clit_rec*   light;
	lv_initialLgt	     = xsendmsg0(lv_xlgt,k_new);
	lv_currentLgt	     = xsendmsg0(lv_xlgt,k_new);
	i_light = (clgt_rec*) gobjimmbase(lv_initialLgt);
	c_light = (clgt_rec*) gobjimmbase(lv_currentLgt);
	light   = (clit_rec*) gobjimmbase(lv_lit);

	light->Default     = self_litDefault;
	light->sunAltitude = self_litSunAltitude;
	light->sunAzimuth  = self_litSunAzimuth;
	light->fixed       = self_litFixed;
        light->sun[0]	   = self_litSun[0];
        light->sun[1]	   = self_litSun[1];
        light->sun[2]	   = self_litSun[2];
	light->okToAnimate = self_litOkToAnimate;

        if (version >= 'e') {
            ctfm_rec*initial_mat;
            ctfm_rec*current_mat;
            xlgt35_Find_Viewing_Matrix( lv_initialLgt, &initial_mat );
            xlgt35_Find_Viewing_Matrix( lv_currentLgt, &current_mat );

	    i_light->r.light_is_local  = self_litLightIsLocal;

            i_light->r.ambient_color.r = self_litAmbientR;
            i_light->r.ambient_color.g = self_litAmbientG;
            i_light->r.ambient_color.b = self_litAmbientB;

            i_light->r.light_color.r   = self_litColorR;
            i_light->r.light_color.g   = self_litColorG;
            i_light->r.light_color.b   = self_litColorB;

	    c_light->r.light_is_local  = self_litLightIsLocal;

            c_light->r.ambient_color.r = self_litAmbientR;
            c_light->r.ambient_color.g = self_litAmbientG;
            c_light->r.ambient_color.b = self_litAmbientB;

            c_light->r.light_color.r   = self_litColorR;
            c_light->r.light_color.g   = self_litColorG;
            c_light->r.light_color.b   = self_litColorB;

	    initial_mat->target.x      = self_litTargetX;
	    initial_mat->target.y      = self_litTargetY;
	    initial_mat->target.z      = self_litTargetZ;
	    initial_mat->want_to_recompute_matrix = TRUE;

	    current_mat->target.x      = self_litTargetX;
	    current_mat->target.y      = self_litTargetY;
	    current_mat->target.z      = self_litTargetZ;
	    current_mat->want_to_recompute_matrix = TRUE;
	}

/*      *c_light = *i_light; */

        xsendmsg2( lv_lit, k_set, k_currentstate, lv_currentLgt );
        xsendmsg2( lv_lit, k_set, k_initialstate, lv_initialLgt );
	switch (self_litLightIs) {
	case 1:  xsendmsg2( lv_lit, k_set, k_lightis, k_additional  );	break;
	case 2:  xsendmsg2( lv_lit, k_set, k_lightis, k_replacement );	break;
	default: xsendmsg2( lv_lit, k_set, k_lightis, NIL	    );	break;
	}
    }

    xlpopn(toProt);
    return   lv_lit;
}

/* }}} */
/* {{{ xs3i35_Load_Lst -- Load object from file				*/

LVAL xs3i35_Load_Lst( dumm, t, fd )
LVAL                  dumm;
int                         t;
int                            fd;
{
    char buf[80];
    int  self_lstRefCount;
    int  self_lstChildren;
    int  self_lstCursor  ;
    int  self_lstFinished;
    int  self_lstResult_uI;
    int  self_lstResultOffset;
    int  dum;

    int     toProt = 4;
    LVAL    lv_kid;
    LVAL    lv_result;
    LVAL    lv_sublist;
    LVAL    lv_lstName;
    xlstkcheck(toProt  );
    xlsave( lv_result  );
    xlsave( lv_sublist );
    xlsave( lv_kid     );
    xlsave( lv_lstName );

    switch (t) {

    case PaSCII:
    case PbINARY:
        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "a" )   !=   UsAMEsTRING) {
                xlfail( "lstLoad" );
            }
        }

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lstRefCount	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lstChildren	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf			   );
	lv_lstName = cvstring( buf );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lstCursor 	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lstFinished	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lstResult_uI	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_lstResultOffset  );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &dum			   );

        /* Load in all the kids.  Prepending each kid to the */
	/* list gives simpler code, but isn't what we want:  */
        {   int     i;
	    LVAL    lv_last;
	    if (self_lstChildren) {	    
		lv_kid    = xs3i86_Load_Subtree( fd, t );
		lv_result = cons( lv_kid, NIL );
		lv_last   = lv_result;
	    }

            for (i = 1;   i < self_lstChildren;   i++) {
		lv_kid    = xs3i86_Load_Subtree( fd, t );
		lv_kid    = cons( lv_kid, NIL );
	        rplacd( lv_last, lv_kid );
		lv_last   = lv_kid;
        }   }

        {
            char buf[ 80 ];
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%sn", buf );
            if (strcmp( buf, "."    )   !=   UsAMEsTRING
            &&  strcmp( buf, ".lst" )   !=   UsAMEsTRING) {
                xlfail("lstLoad");
            }
        }
        break;

    default:
        xlfail("lstLoad");
    }

    /* Construct the class-sk3-list object: */
    lv_sublist = xsendmsg2( lv_xlst, k_new, k_subtree, lv_result );
    /* Set name variable in list: */
    xthl91_SetObjectVariable( lv_sublist, s_label, lv_lstName );
    xlpopn(toProt);
    return lv_sublist;
}

/* }}} */
/* {{{ xs3i37_Load_Prt -- Load camera from file				*/

LVAL xs3i37_Load_Prt( dumm, t, fd )
LVAL                  dumm;
int                         t;
FILE *                         fd;
{
    LVAL	lv_result;
    LVAL	lv_prt;

    char  buf[ 80 ];

    int   self_prtRefCount;
    int   self_prtPortShape;

    char  version;

    int        toProt = 2;
    xlstkcheck(toProt);
    xlsave(lv_prt);
    xlsave(lv_result);

    /*++libObjCreates;*/

    switch (t) {

    case PaSCII:
    case PbINARY:

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf );
        version = buf[0];

        if (version < 'a'   ||   version > 'a')  xlfail("prtLoad");

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_prtRefCount	 );

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_prtPortShape	 );

	/* Read in our child: */
	lv_result = xs3i86_Load_Subtree( fd, t );

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf );
        if (strcmp( buf, "."    )   !=   UsAMEsTRING
        &&  strcmp( buf, ".prt" )   !=   UsAMEsTRING)  xlfail("prtLoad");
        break;

    default:
        xlfail("prtLoad");
    }

    lv_prt = xsendmsg2( lv_xeye, k_new, k_subtree, lv_result );
    {   ceye_rec *r  = (ceye_rec*) gobjimmbase(lv_prt);
	r->portShape = self_prtPortShape;
    }

    xlpopn(toProt);

    return lv_prt;
}

/* }}} */
/* {{{ xs3i40_Load_Pts -- Load object from file				*/

LVAL xs3i40_Load_Pts( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    /* Strictly, all of the k_* should be   */
    /* _EXTERNED, _DEFINED and _CREATED in  */
    /* xs3i.c ... skipped in laziness aided */
    /* and abetted by a feeling that this   */
    /* whole file is a kludge...	    */
    extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xflv;

    extern LVAL k_pointx;
    extern LVAL k_pointy;
    extern LVAL k_pointz;

    extern LVAL k_setarray;
    extern LVAL k_adjustarray;

    int self_ptsRefCount;
    int self_ptsChildren;
    int self_ptsCursor;
    int self_ptsFinished;
    int self_ptsResult;
    int self_ptsResultOffset;
    int dum;
    int self_ptsLabelPoints;
    int self_ptsPicking;
    int self_ptsLastPointPicked;
    int self_ptsFriend;

    float* arrayX;
    float* arrayY;
    float* arrayZ;

    char  buf[ 80 ];
    char  version;

    LVAL lv_ary;
    LVAL lv_pointcount;

    int        toProt = 1;
    xlstkcheck(toProt);
    xlsave(lv_pointcount);

    switch (t) {

    case PaSCII:
    case PbINARY:

        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%s\n", buf ); 
	version = *buf;

	if (version < 'a' || version > 'b')   xlfail("ptsLoad0");

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ptsRefCount	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ptsChildren	 );

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n",	buf		 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ptsCursor 	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ptsFinished	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ptsResult	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ptsResultOffset	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &dum			 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ptsLabelPoints	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ptsPicking	 );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_ptsLastPointPicked );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%x\n", &self_ptsFriend 	 );


	/* Get pointers to the actual float areas, for speed. */
	arrayX = (float*) (csry_base( xs3ipx_PointX ));
	arrayY = (float*) (csry_base( xs3ipy_PointY ));
	arrayZ = (float*) (csry_base( xs3ipz_PointZ ));

        if (self_ptsChildren != xs3ict_Ctr[ xs3icn_CtrNext ].point_len) {
	    fprintf(stderr,
		"**** Tube '%s' Pts %g: expected %d pts, got %d, faking it.\n",
		xs3ict_TubeName,
		xs3ict_Ctr[ xs3icn_CtrNext ].ctr_zcoord,
		xs3ict_Ctr[ xs3icn_CtrNext ].point_len,
		self_ptsChildren
	    );
	}

#ifdef OLD
	if (xs3ict_Ctr[ xs3icn_CtrNext ].point_len != self_ptsChildren) {
#ifndef DEBUG
printf("xs3840_Load_Pts: xs3ict_Ctr[ xs3icn_CtrNext ].ctr_zcoord g=%g\n",xs3ict_Ctr[ xs3icn_CtrNext ].ctr_zcoord);
printf("xs3i40_Load_Pts: self_ptsChildren d=%d\n", self_ptsChildren);
printf("xs3i40_Load_Pts: xs3ict_Ctr[ xs3icn_CtrNext ].point_len d=%d\n", xs3ict_Ctr[ xs3icn_CtrNext ].point_len);
#endif
	    xlfail("bad ctr len");
	}
#endif
        if (t == PaSCII) {
            int     i;
	    int   base = xs3ict_Ctr[ xs3icn_CtrNext ].point_base;
	    float x = 0.0;
	    float y = 0.0;
	    float z = xs3ict_Ctr[ xs3icn_CtrNext ].ctr_zcoord;
            for (i = 0;   i < self_ptsChildren;  ++i) {

                xs3i88_Read_Line( fd );
		sscanf( xs3i00_Text_Buffer, "%f %f %f\n", &x, &y, &z );

	        if (i < xs3ict_Ctr[ xs3icn_CtrNext ].point_len) {
		    arrayX[ base + i ] = x;
		    arrayY[ base + i ] = y;
		    arrayZ[ base + i ] = z;
	        } else {
		    fprintf(stderr,
			"**** xs3i40_Load_Pts DISCARDING UNEXPECTED POINT %d\n",
			i
		    );
	    }   }
            for ( ;   i < xs3ict_Ctr[ xs3icn_CtrNext ].point_len;  ++i) {
		arrayX[ base + i ] = x;
		arrayY[ base + i ] = y;
		arrayZ[ base + i ] = z;
		fprintf(stderr,
		    "xs3i40_Load_Pts setting point[%d] to BOGUS %g,%g,%g\n",
		    base+i,
		    arrayX[ base+i ],
		    arrayY[ base+i ],
		    arrayZ[ base+i ]
		);
	    }

        } else {

	    int 	i;
	    uAny	u;
	    float x = 0.0;
	    float y = 0.0;
	    float z = xs3ict_Ctr[ xs3icn_CtrNext ].ctr_zcoord;
	    int   base = xs3ict_Ctr[ xs3icn_CtrNext ].point_base;
	    for (i = 0;   i < self_ptsChildren;   ++i) {

		u.uI	= sk309_FGetW( fd );
                x	= u.uF;

		u.uI	= sk309_FGetW( fd );
                y	= u.uF;

		u.uI	= sk309_FGetW( fd );
                z	= u.uF;

	        if (i < xs3ict_Ctr[ xs3icn_CtrNext ].point_len) {
		    arrayX[ base + i ] = x;
		    arrayY[ base + i ] = y;
		    arrayZ[ base + i ] = z;
	        } else {
		    fprintf(stderr,
			"**** xs3i40_Load_Pts DISCARDING UNEXPECTED POINT %d\n",
			i
		    );
	    }   }
            for ( ;   i < xs3ict_Ctr[ xs3icn_CtrNext ].point_len;  ++i) {
		arrayX[ base + i ] = x;
		arrayY[ base + i ] = y;
		arrayZ[ base + i ] = z;
		fprintf(stderr,
		    "xs3i40_Load_Pts setting point[%d] to BOGUS %g,%g,%g\n",
		    base+i,
		    arrayX[ base+i ],
		    arrayY[ base+i ],
		    arrayZ[ base+i ]
		);
	    }
        }

        if (version > 'a') {
	    /* Over all point-texture arrays (maybe someday more): */
	    for (;;) {
		xs3i88_Read_Line( fd );
		if (strcmp( xs3i00_Text_Buffer, "."    ) == UsAMEsTRING
		||  strcmp( xs3i00_Text_Buffer, ".pts" ) == UsAMEsTRING
                ){
		    break;
		}

		/* Should have an array.  First three chars */
		/* give the array type, currently this has  */
		/* to be 'flt':                             */
		if (!strncmp( xs3i00_Text_Buffer, "flt", 3)) {

		    /* Load in in a flt array: */
		    char*  name   = xs3i00_Text_Buffer+4;
		    float* ary;
		    int    base   = xs3ict_Ctr[ xs3icn_CtrNext ].point_base;
		    int    len    = xs3ict_Ctr[ xs3icn_CtrNext ].point_len ;
		    lv_pointcount = cvfixnum( xs3ipn_PointCount );

            	    /* Insert point-texture arrays if not yet created: */
	    	    if (null(xs3ipu_PtTxrU)) {
			xs3ipu_PtTxrU = xsendmsg1(
			    lv_xflv, k_new, lv_pointcount
			);
			xsendmsg2(
			    xs3i05_Point_Grl,
			    k_setarray,
			    k_pointtextureu,
			    xs3ipu_PtTxrU
			);
		    }
	    	    if (null(xs3ipv_PtTxrV)) {
			xs3ipv_PtTxrV = xsendmsg1(
			    lv_xflv, k_new, lv_pointcount
			);
			xsendmsg2(
			    xs3i05_Point_Grl,
			    k_setarray,
			    k_pointtexturev,
			    xs3ipv_PtTxrV
			);
		    }

		    /* Get pointer directly to array: */
		    if (       !strcmp( name, ":POINT-TEXTURE-U")) {
			ary = (float*) (csry_base( xs3ipu_PtTxrU ));
		    } else if (!strcmp( name, ":POINT-TEXTURE-V")) {
			ary = (float*) (csry_base( xs3ipv_PtTxrV ));
		    } else {
			xlerror("ptsLoad: unknown array name",cvstring(name));
		    }

		    xs3ia5_Load_FltArray( ary+base, len, t, fd );
	        }
	    }
	} else {

	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
	    if (strcmp( buf, "."    )   !=   UsAMEsTRING
	    &&  strcmp( buf, ".pts" )   !=   UsAMEsTRING
	    ){
		xlfail("ptsLoad1");
	    }
	}

	++xs3icn_CtrNext; /* buggo, check for overflow sometime. */

        break;

    default:
        xlfail( "ptsLoad2" );
    }

    xlpopn(toProt);

    return  NIL;
}

/* }}} */
/* {{{ xs3i45_Load_Rbn -- Load object from file				*/

LVAL xs3i45_Load_Rbn( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    char      version;

    int       self_rbnRefCount;
    int       self_rbnPolygons;
    int	      self_rbnCursor;
    int	      self_rbnFinished;
    int       self_rbnResult_uI;
    int	      self_rbnResultOffset;
    int       dum;
    int	      self_rbnTilingIsDirty;
    int	      self_rbnLastPolyPicked;
    int	      self_rbnDisplayAs;
    int	      self_rbnDisplayNormals;
    int	      self_rbnDebug;
    int	      self_rbnFacetNormalsDirty;
    int	      self_rbnPointNormalsDirty;
    int	      self_rbnPointNormals;
    int       self_rbnPolygonsLocked;
    int       self_rbnPrevLen;
    int       self_rbnSelfLen;

    int*      array0;
    int*      array1;
    int*      array2;

    float*    arrayX;
    float*    arrayY;
    float*    arrayZ;

    float*    arrayNX;
    float*    arrayNY;
    float*    arrayNZ;

    int       loadFacetNormals;

    int	      point_len;
    int	      facet_len;

    LVAL      lv_facetcount;
    LVAL      lv_pointcount;

    int        toProt = 2;
    xlstkcheck(toProt);
    xlsave(lv_facetcount);
    xlsave(lv_pointcount);


    if (!xs3i06_Facet_Grl_Valid)   xlfail("rbnLoad.0");

    switch (t) {

    case PaSCII:
    case PbINARY:
        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            version	= *buf;

	    if (version < 'a'	||   version > 'e') {
		xlfail( "rbnLoad.1" );
            }
        }

        /* Read in the local scalar values: */
        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnRefCount		   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnPolygons		   );

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnCursor 		   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnFinished		   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnResult_uI		   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnResultOffset	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &dum			   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnTilingIsDirty	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnLastPolyPicked 	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnDisplayAs		   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnDisplayNormals 	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnDebug		   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnFacetNormalsDirty	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnPointNormalsDirty	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnPointNormals	   );

        if (version < 'b') {
            self_rbnPolygonsLocked   = FALSE;
        } else {
            xs3i88_Read_Line( fd );
            sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnPolygonsLocked );
        }

	if (version >= 'd') {
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnPrevLen	    );

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_rbnSelfLen	    );
        } else {
            self_rbnPrevLen		= 0;
            self_rbnSelfLen		= 0;
        }

	loadFacetNormals	= (
            (version < 'c')
            ||
            !self_rbnFacetNormalsDirty
        );

	/* Versions of Skandha3 prior to 94Mar16 neglected to initialize */
	/* the following fields, meaning that we have zillions of data   */
	/* files in which these values may be garbage (if the contour    */
	/* hasn't been used, resulting in good values never overwriting  */
	/* the initial values):                                          */
	if (version < 'e') {
	    if ((self_rbnFinished != FALSE   &&   self_rbnFinished != TRUE)
	    ||  ((unsigned)self_rbnSelfLen        > 100000)
	    ||  ((unsigned)self_rbnPrevLen        > 100000)
	    ||  ((unsigned)self_rbnLastPolyPicked > 100000)
	    ){
		self_rbnFinished	= FALSE;
		self_rbnSelfLen		= 0;
		self_rbnPrevLen		= 0;
		self_rbnResult_uI	= 0;
		self_rbnResultOffset	= 0;
		self_rbnLastPolyPicked	= 0;
	}   }


	xs3ict_Ctr[ xs3icn_CtrNext ].point_base = xs3ipn_PointCount;
	xs3ict_Ctr[ xs3icn_CtrNext ].facet_base = xs3ifn_FacetCount;
#ifdef DEBUG
printf("\nxs3i45_Load_Rbn: self_rbnPointNormals d=%d\n", self_rbnPointNormals);
printf(  "xs3i45_Load_Rbn: self_rbnSelfLen      d=%d\n", self_rbnSelfLen     );
printf(  "xs3i45_Load_Rbn: self_rbnPrevLen      d=%d\n", self_rbnPrevLen     );
printf(  "xs3i45_Load_Rbn: self_rbnPolygons     d=%d\n", self_rbnPolygons    );
#endif
	point_len = (version >= 'd') ? self_rbnSelfLen : self_rbnPointNormals;
	facet_len = self_rbnPolygons;

	xs3ict_Ctr[ xs3icn_CtrNext ].point_len  = point_len;
/*printf("xs3i45_Load_Rbn noting point_len as %d\n",xs3ict_Ctr[ xs3icn_CtrNext ].point_len );*/
	xs3ict_Ctr[ xs3icn_CtrNext ].facet_len  = facet_len;
/*printf("xs3i45_Load_Rbn noting facet_len as %d\n",xs3ict_Ctr[ xs3icn_CtrNext ].facet_len );*/
	xs3ict_Ctr[ xs3icn_CtrNext ].locked     =  self_rbnPolygonsLocked;
	xs3ict_Ctr[ xs3icn_CtrNext ].invisible  = (
	    self_rbnDisplayAs == LIBsTYLEiNVISIBLE
	);



        /* Resize our point and facet relations: */

	if (facet_len) {
/*printf("xs3i45_Load_Rbn bumping xs3ifn_FacetCount from %d to %d\n",xs3ifn_FacetCount,xs3ifn_FacetCount+self_rbnPolygons);*/

	    xs3ifn_FacetCount += facet_len;
	    lv_facetcount      = cvfixnum( xs3ifn_FacetCount );
	    xsendmsg1( xs3i07_Facet_Grl, k_adjustarray, lv_facetcount );
	}

/*printf("xs3i45_Load_Rbn bumping xs3ipn_PointCount from %d to %d\n",xs3ipn_PointCount,xs3ipn_PointCount+self_rbnPointNormals);*/
	if (point_len) {
	    xs3ipn_PointCount += point_len;
	    lv_pointcount      = cvfixnum( xs3ipn_PointCount );
	    xsendmsg1( xs3i05_Point_Grl, k_adjustarray, lv_pointcount );
	}

	/* Get hard pointers to facet normals, if needed: */
        if (loadFacetNormals) {
	    lv_facetcount      = cvfixnum( xs3ifn_FacetCount );

            /* Insert facet-normal arrays if not yet created: */
	    if (null(xs3ifx_FtNmlX)) {
                xs3ifx_FtNmlX	= xsendmsg1( lv_xflv, k_new, lv_facetcount );
                xsendmsg2(xs3i07_Facet_Grl,k_setarray,k_facetnormalx,xs3ifx_FtNmlX);
	    }
	    if (null(xs3ify_FtNmlY)) {
                xs3ify_FtNmlY	= xsendmsg1( lv_xflv, k_new, lv_facetcount );
                xsendmsg2(xs3i07_Facet_Grl,k_setarray,k_facetnormaly,xs3ify_FtNmlY);
	    }
	    if (null(xs3ifz_FtNmlZ)) {
                xs3ifz_FtNmlZ	= xsendmsg1( lv_xflv, k_new, lv_facetcount );
                xsendmsg2(xs3i07_Facet_Grl,k_setarray,k_facetnormalz,xs3ifz_FtNmlZ);
	    }

	    arrayNX = (float*) (csry_base( xs3ifx_FtNmlX ));
	    arrayNY = (float*) (csry_base( xs3ify_FtNmlY ));
	    arrayNZ = (float*) (csry_base( xs3ifz_FtNmlZ ));
        }


	/* Get pointers to the actual int areas, for speed.   */
	/* note that these areas can move during a resize,    */
	/* hence this must follow the above resize...	      */
	array0 = (int*) (csry_base( xs3if0_Facet0 ));
	array1 = (int*) (csry_base( xs3if1_Facet1 ));
	array2 = (int*) (csry_base( xs3if2_Facet2 ));

        /* Load our polygon definitions and facet normals: */
	if (self_rbnPolygons != xs3ict_Ctr[ xs3icn_CtrNext ].facet_len){
	    xlfail("rbnLoad.2");
	}

        if (t == PaSCII) {
            int i;
            int p1, p2, p3;
	    int   base = xs3ict_Ctr[ xs3icn_CtrNext ].facet_base;
            for (i = 0;   i < self_rbnPolygons;   i++)   {

		if (loadFacetNormals) {
		    float x,y,z;
		    xs3i88_Read_Line( fd );
		    sscanf(
			xs3i00_Text_Buffer,
                        "%f %f %f %d %d %d\n",
                        &x , &y , &z,
                        &p1, &p2, &p3
		    );

/*printf("xs3i45_Load_Rbn setting facetnormal[%d] to %g,%g,%g\n",base+i,x,y,z);*/
		    if (i < facet_len) {
			arrayNX[ base + i ] = x;
			arrayNY[ base + i ] = y;
			arrayNZ[ base + i ] = z;
		    }
		} else {
		    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%d %d %d\n", &p1, &p2, &p3 );
		}
/*printf("xs3i45_Load_Rbn setting facet[%d] to %d,%d,%d\n",base+i,p1,p2,p3);*/
		if (i < facet_len) {
		    array0[ base + i ] = p1;
		    array1[ base + i ] = p2;
		    array2[ base + i ] = p3;
	        }
	    }

        } else {

            int                i;
            int                p1, p2, p3;
            register uAny      u;
	    int   base = xs3ict_Ctr[ xs3icn_CtrNext ].facet_base;
            for (i = 0;   i < self_rbnPolygons;   i++)   {

                if (loadFacetNormals) {
		    u.uI	   = sk309_FGetW( fd );
		    arrayNX[ base + i ] = u.uF;
		    u.uI	   = sk309_FGetW( fd );
		    arrayNY[ base + i ] = u.uF;
		    u.uI	   = sk309_FGetW( fd );
		    arrayNZ[ base + i ] = u.uF;
/*printf("xs3i45_Load_Rbn setting facetnormal[%d] to %g,%g,%g\n",base+i,arrayNX[base+i],arrayNY[base+i],arrayNZ[base+i]);*/
                }

		p1		   = sk309_FGetW( fd );
		p2		   = sk309_FGetW( fd );
		p3		   = sk309_FGetW( fd );

		if (i < facet_len) {
/*printf("xs3i45_Load_Rbn setting facet[%d] to %d,%d,%d\n",base+i,p1,p2,p3);*/
		    array0[ base + i ] = p1;
		    array1[ base + i ] = p2;
		    array2[ base + i ] = p3;
                }
            }
            for ( ;   i < facet_len;   i++)   {
                if (loadFacetNormals) {
		    arrayNX[ base + i ] = 0.0;
		    arrayNY[ base + i ] = 0.0;
		    arrayNZ[ base + i ] = 1.0;
		}
		array0[ base + i ] = p1;
		array1[ base + i ] = p2;
		array2[ base + i ] = p3;
	    }
        }

        /* Load our private vector of point-normal definitions: */

	/* Get pointers to the actual float areas, for speed. */
	/* note that these areas can move during a resize,    */
	/* hence this must follow the above resize...	      */
	arrayX = (float*) (csry_base( xs3ivx_PtNmlX ));
	arrayY = (float*) (csry_base( xs3ivy_PtNmlY ));
	arrayZ = (float*) (csry_base( xs3ivz_PtNmlZ ));


#ifdef OLD
	if (self_rbnPointNormals != xs3ict_Ctr[ xs3icn_CtrNext ].point_len){
printf("\nxs3i45_Load_Rbn: self_rbnPointNormals d=%d\n",self_rbnPointNormals);
printf(  "xs3i45_Load_Rbn: xs3ict_Ctr[ xs3icn_CtrNext ].point_len d=%d\n",xs3ict_Ctr[ xs3icn_CtrNext ].point_len);
	    xlfail("rbnLoad.3");
	}
#else
	/* We used to make sure that                                      */
        /* self_rbnPointNormals == xs3ict_Ctr[ xs3icn_CtrNext ].point_len */
        /* at this point, but appears that many Skandha3 files get saved  */
        /* without updating surface info, so (unwisely?) changed our code */
        /* here to tolerate such data silently.  At the moment, this is   */
        /* mostly for Loyd/AVS which recompute normals anyhow. 94Mar08jsp */
#endif
        if (t == PaSCII) {
	    int   base = xs3ict_Ctr[ xs3icn_CtrNext ].point_base;
	    float x = 1.0;
	    float y = 0.0;
	    float z = 0.0;
            int  i;
            for (i = 0;   i < self_rbnPointNormals;  i++){
                xs3i88_Read_Line( fd );
		sscanf( xs3i00_Text_Buffer, "%f %f %f\n", &x, &y, &z );
		if (i < point_len) {	/* 'if' 'cause normals may be outdated. */
		    arrayX[ base + i ] = x;
		    arrayY[ base + i ] = y;
		    arrayZ[ base + i ] = z;
/*printf("xs3i45_Load_Rbn setting pointnormal[%d] to %g,%g,%g\n",base+i,arrayX[base+i],arrayY[base+i],arrayZ[base+i]);*/
		} else {
		    fprintf(stderr,
			"**** xs3i45_Load_Rbn DISCARDING UNEXPECTED POINT NORMAL %d\n",
			i
		    );
            }   }

	    /* Gracefully handle outdated normal data: */
            for ( ;   i < point_len;  i++){
		arrayX[ base + i ] = x;
		arrayY[ base + i ] = y;
		arrayZ[ base + i ] = z;
		fprintf(stderr,
		    "xs3i45_Load_Rbn setting pointnormal[%d] to BOGUS %g,%g,%g\n",
		    base+i,
		    arrayX[ base+i ],
		    arrayY[ base+i ],
		    arrayZ[ base+i ]
		);
	    }
        } else {
            int             i;
            register uAny   u;
	    float x = 1.0;
	    float y = 0.0;
	    float z = 0.0;
	    int   base = xs3ict_Ctr[ xs3icn_CtrNext ].point_base;
            for (i = 0;   i < self_rbnPointNormals;   i++){

		u.uI	= sk309_FGetW( fd );
                x	= u.uF;

		u.uI	= sk309_FGetW( fd );
                y	= u.uF;

		u.uI	= sk309_FGetW( fd );
                z	= u.uF;

		if (i < point_len) {	/* 'if' 'cause normals may be outdated. */
		    arrayX[ base + i ] = x;
		    arrayY[ base + i ] = y;
		    arrayZ[ base + i ] = z;
/*printf("xs3i45_Load_Rbn setting pointnormal[%d] to %g,%g,%g\n",base+i,arrayX[base+i],arrayY[base+i],arrayZ[base+i]);*/
		} else {
		    fprintf(stderr,
			"**** xs3i45_Load_Rbn DISCARDING UNEXPECTED POINT NORMAL %d\n",
			i
		    );
            }   }

	    /* Gracefully handle outdated normal data: */
            for ( ;   i < point_len;  i++){
		arrayX[ base + i ] = x;
		arrayY[ base + i ] = y;
		arrayZ[ base + i ] = z;
		fprintf(stderr,
		    "xs3i45_Load_Rbn setting pointnormal[%d] to BOGUS %g,%g,%g\n",
		    base+i,
		    arrayX[ base+i ],
		    arrayY[ base+i ],
		    arrayZ[ base+i ]
		);
	    }
        }

        /* Load our contour, a true subobject: */
	xs3i86_Load_Subtree( fd, t );

        if (self_rbnPointNormals != xs3ict_Ctr[ xs3icn_CtrNext-1 ].point_len) {
	    fprintf(stderr,
		"**** Tube '%s' Rbn %g: EXPECTED %d PT NMLS, GOT %d, FAKING IT.\n",
		xs3ict_TubeName,
		xs3ict_Ctr[ xs3icn_CtrNext-1 ].ctr_zcoord,
		xs3ict_Ctr[ xs3icn_CtrNext-1 ].point_len,
		self_rbnPointNormals
	    );
	}

#ifdef XYZZY
if (self_rbnPointNormals == xs3ict_Ctr[ xs3icn_CtrNext-1 ].point_len) {
    fprintf(stderr,
	"Tube '%s' Rbn %g: expected and got %d pt nmls.\n",
	xs3ict_TubeName,
	xs3ict_Ctr[ xs3icn_CtrNext-1 ].ctr_zcoord,
	xs3ict_Ctr[ xs3icn_CtrNext-1 ].point_len,
	self_rbnPointNormals
    );
}
#endif

        {
            char buf[ 80 ];
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "."    )  !=  UsAMEsTRING
            &&  strcmp( buf, ".rbn" )  !=  UsAMEsTRING)  xlfail("rbnLoad.4");
        }

        break;

    default:
        xlfail("rbnLoad.5");
    }

    xlpopn(toProt);

    return   NIL;
}

/* }}} */
/* {{{ xs3i50_Load_Sub -- Load object from file				*/

#ifdef OLD
LVAL xs3i51_Load_Sub( self )
LVAL         self;
{
    LVAL here;

    /* Check to see if we've already loaded given subfile somewhere: */
    for (here = (LVAL)libFirstSubfileInstance; here; here = here->subChain) {

        if (here != self   &&   !strcmp( here->subName, self->subName )) {

            /* We have!  Use pointer to existing */
            /* copy rather than loading another: */
            self->subChild.uO  = here->subChild.uO;
            UriNC( self->subChild.uO );
	    return;
        }
    }

    /* Load our child from separate file: */
    if (SubDepth >= MAXdEPTH) {
        libHotSpotNote2("Subfiles Overnested!",self->subName);
    } else {
        int i;
        ++SubDepth;
        if (i = mdcLoadFile( FALSE, self->subName )) {
            self->subChild.uI	= i;
        }
        --SubDepth;
    }
}
#endif

LVAL xs3i50_Load_Sub( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    int    self_subRefCount;
    char   self_subName[128];

    char   version;

    LVAL      lv_sub;
    LVAL      lv_result;

    int        toProt = 2;
    xlstkcheck(toProt);
    xlsave(lv_sub);
    xlsave(lv_result);

#ifdef OLD
    LVAL     self;
    int   *   p;

    /*++libObjCreates;*/

    /* Allocate the RAM: */
    if (!(self   =   ((LVAL) malloc( sizeof( struct subRecord ) )))) {
        xlfail( self, "subLoad", 1 );
    }

    /* cc complains about "us->subMsg = subTable;" so: */
    p   = ((int*) self);
    *p  = ((int ) subTable);

    self->subChangeFnFaCount    = 0;

    /* We've never saved this file from this subfile object: */
    self->subWriteNo = 0;

    /* Thread ourself onto global list of all Sub instances: */
    self->subChain           = (LVAL) libFirstSubfileInstance;
    libFirstSubfileInstance  = (uObj) self;

    /* Maybe set up pointer to first subFile instance created: */
    if (!libFirstSubfileInstance)  libFirstSubfileInstance = (uObj)self;
#endif

    switch (t) {

    case PaSCII:
    case PbINARY:
        {
            char buf[ 80 ];

	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
	    if (*buf < 'a'   ||   *buf > 'a')	xlfail("subLoad/a");
            version	= *buf;
        }

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_subRefCount    );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n",	self_subName	     );
/*printf("xs3i50_Load_Sub: file name is '%s'\n", self_subName );*/

        {   char buf[ 80 ];
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "."    )   !=   UsAMEsTRING
            &&  strcmp( buf, ".sub" )   !=   UsAMEsTRING) {
                xlfail( "subLoad/b" );
            }
        }

        lv_result = xs3i89_Load_File( self_subName );
#ifdef OLD
        self->subChild.uI	= libNopObject();
        xs3i51_Load_Sub( self );
#endif
        break;

    default:
        xlfail("subLoad/c");
    }

    lv_sub = xsendmsg2( lv_xsub, k_new, k_subtree, lv_result );
    xsendmsg2( lv_sub, k_set, k_label, cvstring( self_subName ) );

    xlpopn(toProt);
    return  lv_sub;
}

/* }}} */
/* {{{ xs3i55_Load_Trn -- Load object from file				*/

LVAL xs3i55_Load_Trn( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    /* For now, rotors are completely ignored ... (!) :) */

    int       self_trnRefCount;
    float     self_trnYRotRate; 
    float     self_trnLastTime;
    int       self_trnPostApply;
    int	      self_trnShowAxes;
    float     self_trnLoc_uPtX;
    float     self_trnLoc_uPtY;
    float     self_trnLoc_uPtZ;
    float     self_trnAltitude;
    float     self_trnAzimuth;
    float     self_trnScale;
    int       self_trnCompatable;

    float     self_trnXRotRate;
    float     self_trnZRotRate;
    float     self_trnXMovRate;
    float     self_trnYMovRate;
    float     self_trnZMovRate;
    float     self_trnZoomRate;
    int       self_trnLocked;

    float     self_trnFulMatrix[ 4 ][ 4 ];
    float     self_trnRotMatrix[ 4 ][ 4 ];

    char      version;

    ctfm_rec* i_transform;
    ctfm_rec* c_transform;

    LVAL      lv_trn;
    LVAL      lv_initialTfm;
    LVAL      lv_currentTfm;
    LVAL      lv_result;
    int       toProt = 4;
    xlstkcheck(toProt);
    xlsave(lv_trn);
    xlsave(lv_initialTfm);
    xlsave(lv_currentTfm);
    xlsave(lv_result);

    /* Create our CLASS-MATRIX44 instance to hold our position/orientation: */
    lv_initialTfm	= xsendmsg0(lv_xtfm,k_new);
    lv_currentTfm	= xsendmsg0(lv_xtfm,k_new);
    i_transform = (ctfm_rec*) gobjimmbase(lv_initialTfm);
    c_transform = (ctfm_rec*) gobjimmbase(lv_currentTfm);

    switch (t) {

    case PaSCII:
    case PbINARY:
        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
            sscanf( xs3i00_Text_Buffer, "%s\n", buf ); 
	    version	= *buf;
	    if (version < 'a'	||   version > 'e') {
                xlfail("trnLoad");
            }
        }

	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_trnRefCount );

        if (version < 'b') {
            self_trnYRotRate	= 1.0;
            self_trnLastTime	= 0.0;
        } else {
            xs3i88_Read_Line( fd );
            sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnYRotRate ); 
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnLastTime );

	    if (version < 'c') {
		self_trnPostApply = TRUE;
	    } else {
                xs3i88_Read_Line( fd );
                sscanf( xs3i00_Text_Buffer, "%d\n", &self_trnPostApply ); 

		if (version < 'e') {
		    self_trnShowAxes	= FALSE;
		    self_trnLoc_uPtX	=
		    self_trnLoc_uPtY	=
		    self_trnLoc_uPtZ	= 0.0;
		    self_trnAltitude	= 90.0;
		    self_trnAzimuth	=  0.0;
                    self_trnScale      =  0.1;
		    self_trnCompatable = TRUE;
		} else {
                    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%d\n", &self_trnShowAxes	);
		    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnLoc_uPtX	);
                    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnLoc_uPtY	);
                    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnLoc_uPtZ	);
                    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnAltitude	);
                    xs3i88_Read_Line( fd );
                    sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnAzimuth    ); 
                    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnScale	);
		    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%d\n", &self_trnCompatable );
		}
            }
	}

        if (version < 'd') {
            self_trnXRotRate   = 0.0;  
            self_trnZRotRate   = 0.0;  
            self_trnXMovRate   = 0.0;  
            self_trnYMovRate   = 0.0;  
            self_trnZMovRate   = 0.0;  
            self_trnZoomRate   = 1.0;  
            self_trnLocked     = FALSE;  
        } else {  
            xs3i88_Read_Line( fd );  
            sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnXRotRate );  
            xs3i88_Read_Line( fd );  
            sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnZRotRate );   
            xs3i88_Read_Line( fd );  
            sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnXMovRate );   
            xs3i88_Read_Line( fd );  
            sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnYMovRate );   
            xs3i88_Read_Line( fd );  
            sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnZMovRate );   
            xs3i88_Read_Line( fd );  
            sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnZoomRate );   
            xs3i88_Read_Line( fd );  
            sscanf( xs3i00_Text_Buffer, "%d\n", &self_trnLocked   );  
        }  

        {
            int i, j;

            for (i = 0;   i < 4;   i++)   {
                for (j = 0;   j < 4;   j++)   {
		    float f;
                    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%f\n", &f );
		    i_transform->m.m[ i ][ j ] = f;
                    /* Really should phase these self_* out at some point... */
                    self_trnFulMatrix[ i ][ j ] = i_transform->m.m[ i ][ j ];
                }
            }

            for (i = 0;   i < 4;   i++)   {
                for (j = 0;   j < 4;   j++)   {
                    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%f\n", &self_trnRotMatrix[ i ][ j ] );
                }
            }
        }

        lv_result = xs3i86_Load_Subtree( fd, t );

        {
            char buf[ 80 ];
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "."    )   !=   UsAMEsTRING
            &&  strcmp( buf, ".trn" )   !=   UsAMEsTRING) {
                xlfail( "trnLoad" );
            }
        }
        break;

    default:
        xlfail( "trnLoad" );
    }

    *c_transform = *i_transform;
    lv_trn = xsendmsg2( lv_xtrn, k_new, k_subtree, lv_result );

    xsendmsg2( lv_trn, k_set, k_initialstate, lv_initialTfm );
    xsendmsg2( lv_trn, k_set, k_currentstate, lv_currentTfm );

    {   ctrn_rec* trn   = (ctrn_rec*) xtrn9c_Find_Immediate_Base( lv_trn );
	trn->post_apply = self_trnPostApply;
	trn->show_axes  = self_trnShowAxes ;
	trn->locked     = self_trnLocked   ;
    }

    xlpopn(toProt);
    return lv_trn;
}

/* }}} */
/* {{{ xs3i60_Load_Tub -- Load object from file				*/

/* {{{ xs3i59_Fix -- Convert between Skandha3 & Skandha indexing.	*/

xs3i59_Fix( ary, i, c, n )
int*        ary;
int              i, c, n;
{
    /********************************************************************/
    /* This function converts a point index from Skandha3   	       	*/
    /* conventions to Skandha4 conventions. 	    	    	       	*/
    /* 	    	    	    	    	    	    	    	       	*/
    /* Skandha3 represents surfaces in "ribbon"s bounded by two	       	*/
    /* sets of points, the "current contour" and the "next  	       	*/
    /* contour".  Each point in a polygon is represented by a	       	*/
    /* 16-bit number which is a (negated) index into the "next	       	*/
    /* contour" if negative, else an index into the "current	       	*/
    /* contour".    	    	    	    	    	    	       	*/
    /* 	    	    	    	    	    	    	    	       	*/
    /* Skandha4 represents all the points in a given surface in a      	*/
    /* single pointset, and points in a polygon are simply (32-bit)    	*/
    /* integer indices into this single pointset.   	    	       	*/
    /* 	    	    	    	    	    	    	    	       	*/
    /* When we are called:  	    	    	    	    	       	*/
    /* 	    	    	    	    	    	    	    	       	*/
    /* ary[i] is the index to be converted; 	    	    	       	*/
    /* 	    	    	    	    	    	    	    	       	*/
    /* xs3ict_Ctr[] is an array identifying the location and lenth     	*/
    /* of each Skandha3 'contour' in our unified Skandha4 pointset;    	*/
    /* 	    	    	    	    	    	    	    	       	*/
    /* 'c' is the index of the "current contour" in xs3ict_Ctr[];      	*/
    /* 'n' is the index of the    "next contour" in xs3ict_Ctr[];      	*/
    /********************************************************************/

    /* Fetch value to convert: */
    int p   = ary[i];

    /* Decide whether we're in current or next contour: */
    int x   = (p >= 0) ? c : n;

    /* Find loc & len of our contour in unified point array: */
    int bas = xs3ict_Ctr[ x ].point_base;
    int lim = xs3ict_Ctr[ x ].point_len;

    /* If index was negated, undo that: */
    if (p < 0)	  p = -1-p;

    /* If index was out of range (shouldn't be possible) make it valid: */
    if (p >= lim) p = lim-1;

    /* Add in base offset of our contour and store fixed index back: */
    ary[i] = bas + p;
}

/* }}} */

LVAL xs3i60_Load_Tub( dumm, t, fd )
LVAL                  dumm;
int                         t;
FILE *                         fd;
{
    /* Lisp keywords we need: */

    extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xflv;
    extern LVAL lv_x32v;

    extern LVAL k_pointx;
    extern LVAL k_pointy;
    extern LVAL k_pointz;

    extern LVAL k_pointnormalx;
    extern LVAL k_pointnormaly;
    extern LVAL k_pointnormalz;

    extern LVAL k_facet0;
    extern LVAL k_facet1;
    extern LVAL k_facet2;

    extern LVAL k_setarray;

    extern LVAL k_material;
    extern LVAL k_pointrelation;
    extern LVAL k_facetrelation;
    extern LVAL k_facetif;



    int self_tubRefCount;



    /* Variables to hold lisp values: */

    LVAL lv_result;
    LVAL lv_tubName;
    LVAL lv_pointCount;
    LVAL lv_facetCount;
    LVAL lv_tube;

    LVAL lv_frameNumber;
    LVAL lv_contourBase;
    LVAL lv_contourLen;
    LVAL lv_ribbonBase;
    LVAL lv_ribbonLen;
    LVAL lv_ribbonIsLocked;
    LVAL lv_ribbonIsInvisible;
    LVAL lv_facetif;

    LVAL lv_m4400;
    LVAL lv_m4401;
    LVAL lv_m4402;
    LVAL lv_m4403;

    LVAL lv_m4410;
    LVAL lv_m4411;
    LVAL lv_m4412;
    LVAL lv_m4413;

    LVAL lv_m4420;
    LVAL lv_m4421;
    LVAL lv_m4422;
    LVAL lv_m4423;

    LVAL lv_m4430;
    LVAL lv_m4431;
    LVAL lv_m4432;
    LVAL lv_m4433;



    /* Tell the garbage collector */
    /* about all our lisp values: */

    int        toProt = 46;
    xlstkcheck(toProt);

    xlsave(lv_result);
    xlsave(lv_tube);

    xlsave(xs3i05_Point_Grl);
    xlsave(xs3i07_Facet_Grl);
    xlsave(xs3i08_Ribbon_Grl);

    xlsave(lv_tubName);
    xlsave(lv_pointCount);
    xlsave(lv_facetCount);

    xlsave(xs3ipx_PointX);    xlsave(xs3ipy_PointY);    xlsave(xs3ipz_PointZ);
    xlsave(xs3ivx_PtNmlX);    xlsave(xs3ivy_PtNmlY);    xlsave(xs3ivz_PtNmlZ);
    xlsave(xs3if0_Facet0);    xlsave(xs3if1_Facet1);    xlsave(xs3if2_Facet2);
    xlsave(xs3ifx_FtNmlX);    xlsave(xs3ify_FtNmlY);    xlsave(xs3ifz_FtNmlZ);
    xlsave(xs3ipu_PtTxrU);    xlsave(xs3ipv_PtTxrV);

    xlsave(lv_contourBase);   xlsave(lv_contourLen);    xlsave(lv_frameNumber);
    xlsave(lv_ribbonBase);    xlsave(lv_ribbonLen );

    xlsave(lv_ribbonIsLocked   );
    xlsave(lv_ribbonIsInvisible);
    xlsave(lv_facetif);

    xlsave(lv_m4400);    xlsave(lv_m4401);    xlsave(lv_m4402);    xlsave(lv_m4403);
    xlsave(lv_m4410);    xlsave(lv_m4411);    xlsave(lv_m4412);    xlsave(lv_m4413);
    xlsave(lv_m4420);    xlsave(lv_m4421);    xlsave(lv_m4422);    xlsave(lv_m4423);
    xlsave(lv_m4430);    xlsave(lv_m4431);    xlsave(lv_m4432);    xlsave(lv_m4433);



    /* Sanity check ... skandha3 lets them get away with murder ...	*/
    /* shouldn't really crash, of course ...				*/
    if (xs3i04_Point_Grl_Valid)  xlfail("nested tubes!");
    if (xs3i06_Facet_Grl_Valid)  xlfail("nested tubes!");
    xs3icn_CtrNext = 0;



    /* Create our point relation: */
    xs3ipn_PointCount	= 0;
    lv_pointCount	= cvfixnum(xs3ipn_PointCount);
    xs3i05_Point_Grl	= xsendmsg1( lv_xgrl, k_new, lv_pointCount );
    xs3i04_Point_Grl_Valid = TRUE;
/* printf("xs3i60_Load_Tub building point grl %d long\n",xs3ipn_PointCount);*/

    /* Create point-x/y/z arrays to go in point relation: */
    xs3ipx_PointX	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xs3ipy_PointY	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xs3ipz_PointZ	= xsendmsg1( lv_xflv, k_new, lv_pointCount );

    /* Insert point-x/y/z arrays in point relation: */
    xsendmsg2( xs3i05_Point_Grl, k_setarray, k_pointx, xs3ipx_PointX );
    xsendmsg2( xs3i05_Point_Grl, k_setarray, k_pointy, xs3ipy_PointY );
    xsendmsg2( xs3i05_Point_Grl, k_setarray, k_pointz, xs3ipz_PointZ );

    /* Create point-normal-x/y/z arrays to go in point relation: */
    xs3ivx_PtNmlX	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xs3ivy_PtNmlY	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xs3ivz_PtNmlZ	= xsendmsg1( lv_xflv, k_new, lv_pointCount );

    /* Insert point-normal-x/y/z arrays in point relation: */
    xsendmsg2( xs3i05_Point_Grl, k_setarray, k_pointnormalx, xs3ivx_PtNmlX );
    xsendmsg2( xs3i05_Point_Grl, k_setarray, k_pointnormaly, xs3ivy_PtNmlY );
    xsendmsg2( xs3i05_Point_Grl, k_setarray, k_pointnormalz, xs3ivz_PtNmlZ );

    /* Remember that we haven't created point textures yet: */
    xs3ipu_PtTxrU       = NIL;
    xs3ipv_PtTxrV       = NIL;



    /* Create our facet relation: */
    xs3ifn_FacetCount	= 0;
    lv_facetCount	= cvfixnum(xs3ifn_FacetCount);
    xs3i07_Facet_Grl	= xsendmsg1( lv_xgrl, k_new, lv_facetCount );
    xs3i06_Facet_Grl_Valid = TRUE;
/*printf("xs3i60_Load_Tub building facet grl %d long\n",xs3ifn_FacetCount);*/

    /* Create facet-0/1/2 arrays to go in facet relation: */
    xs3if0_Facet0	= xsendmsg1( lv_x32v, k_new, lv_facetCount );
    xs3if1_Facet1	= xsendmsg1( lv_x32v, k_new, lv_facetCount );
    xs3if2_Facet2	= xsendmsg1( lv_x32v, k_new, lv_facetCount );

    /* Insert facet-0/1/2 arrays in facet relation: */
    xsendmsg2( xs3i07_Facet_Grl, k_setarray, k_facet0, xs3if0_Facet0 );
    xsendmsg2( xs3i07_Facet_Grl, k_setarray, k_facet1, xs3if1_Facet1 );
    xsendmsg2( xs3i07_Facet_Grl, k_setarray, k_facet2, xs3if2_Facet2 );

    /* Remember that we haven't created facet normals yet: */
    xs3ifx_FtNmlX       = NIL;
    xs3ify_FtNmlY       = NIL;
    xs3ifz_FtNmlZ       = NIL;



    switch (t) {

    case PaSCII:
    case PbINARY:
        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "a" )   !=   UsAMEsTRING) {
                xlfail( "tubLoad" );
            }
        }

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_tubRefCount );

        {   char buf[ 256 ];
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n",	buf	  );
	    strcpy( xs3ict_TubeName, buf );
	    lv_tubName = cvstring( buf );
/* printf("xs3i60_Load_Tub: name s='%s'\n",buf); */
	}

	/* Load all the ribbons in tube: */
	xs3i86_Load_Subtree( fd, t );

        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "."    )   !=   UsAMEsTRING
            &&  strcmp( buf, ".tub" )   !=   UsAMEsTRING) {
                xlfail( "tubLoad" );
            }
        }

        break;

    default:
        xlfail( "tubLoad" );
    }

#ifdef OLD
    /* Recompute center and volume, since they're not currently saved: */
    tub_CleanCenterAndVolume( self );
#endif

    /* Fix facet indices into point vector: */
    {   int c,d;
	/* This is fairly awful code. Among other things, it's O(N^2)...*/

	/* Find our facet vectors: */
	int* array0 = (int*) (csry_base( xs3if0_Facet0 ));
	int* array1 = (int*) (csry_base( xs3if1_Facet1 ));
	int* array2 = (int*) (csry_base( xs3if2_Facet2 ));

	/* Over all contours... */
	for     (c = 0;   c < xs3icn_CtrNext;   c++) {

	    /* Find contour with zcoord next-largest to ours: */
	    float     c_zcoord = xs3ict_Ctr[ c ].ctr_zcoord;
	    float     best_z   = 10.0e31;/*ick:)*/
	    int       neighbor = 0;
	    for (d = 0;   d < xs3icn_CtrNext;   d++) {
		float d_zcoord = xs3ict_Ctr[ d ].ctr_zcoord;
		if (d_zcoord > c_zcoord && d_zcoord < best_z) {
		    neighbor   = d;
		    best_z     = d_zcoord;
	    }   }

	    /* Fix up the facet indices: */
	    {   int  start     = xs3ict_Ctr[ c	      ].facet_base;
		int  stop      = xs3ict_Ctr[ c	      ].facet_len + start;
		int  i;
		for (i = start;   i < stop;   ++i) {

		    xs3i59_Fix( array0, i, c, neighbor );
		    xs3i59_Fix( array1, i, c, neighbor );
		    xs3i59_Fix( array2, i, c, neighbor );
    }   }   }   }



    /* Construct return value: */

    lv_result     = cons( xs3i07_Facet_Grl,       NIL );
    lv_result     = cons( k_facetrelation , lv_result );

    lv_result     = cons( xs3i05_Point_Grl, lv_result );
    lv_result     = cons( k_pointrelation , lv_result );

    lv_result	= cons( lv_tubName      , lv_result );
    lv_result	= cons( k_name          , lv_result );

    /* Construct the class-sk3-tube object: */
    lv_tube	= xsendmsg2( lv_xtub, k_new, k_initialstate, lv_result );
    xsendmsg2( lv_tube, k_set, k_currentstate, lv_result );

    /* Set name variable in tube: */
    xthl91_SetObjectVariable( lv_tube, s_label, lv_tubName );

    /****************************************************/
    /* Preserve information about contours and ribbons, */
    /* specifically the offset and length of each       */
    /* contour and ribbon in point and facet relations, */
    /* respectively.  The immediate purpose of this is  */
    /* to allow us to regenerate a valid Skandha3 file, */
    /* but it will also allow eventual display/editing  */
    /* of ribbons and contours.				*/
    /*							*/
    /* To do this, we simply attach array-valued	*/
    /* :CONTOUR-BASE and :CONTOUR-LEN properties to	*/
    /* the point relation, and matching array-valued	*/
    /* :RIBBON-BASE and :RIBBON-LEN properties to	*/
    /* the facet relation.				*/
    /****************************************************/
    {   /* Create the required arrays: */
	lv_frameNumber      =xsendmsg1(lv_x32v,k_new,cvfixnum(xs3icn_CtrNext));
	lv_contourBase      =xsendmsg1(lv_x32v,k_new,cvfixnum(xs3icn_CtrNext));
	lv_contourLen       =xsendmsg1(lv_x32v,k_new,cvfixnum(xs3icn_CtrNext));
	lv_ribbonBase       =xsendmsg1(lv_x32v,k_new,cvfixnum(xs3icn_CtrNext));
	lv_ribbonLen        =xsendmsg1(lv_x32v,k_new,cvfixnum(xs3icn_CtrNext));
	lv_ribbonIsLocked   =xsendmsg1(lv_x01v,k_new,cvfixnum(xs3icn_CtrNext));
	lv_ribbonIsInvisible=xsendmsg1(lv_x01v,k_new,cvfixnum(xs3icn_CtrNext));

	lv_m4400            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4401            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4402            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4403            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));

	lv_m4410            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4411            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4412            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4413            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));

	lv_m4420            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4421            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4422            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4423            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));

	lv_m4430            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4431            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4432            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));
	lv_m4433            =xsendmsg1(lv_xflv,k_new,cvfixnum(xs3icn_CtrNext));


	/* Fill arrays with appropriate values: */
	{   int* contourBase      = (int  *)(csry_base( lv_contourBase       ));
	    int* contourLen       = (int  *)(csry_base( lv_contourLen        ));
	    int* frameNumber      = (int  *)(csry_base( lv_frameNumber       ));
	    int* ribbonBase       = (int  *)(csry_base( lv_ribbonBase        ));
	    int* ribbonLen        = (int  *)(csry_base( lv_ribbonLen         ));
	    char*ribbonIsLocked   = (char *)(csry_base( lv_ribbonIsLocked    ));
	    char*ribbonIsInvisible= (char *)(csry_base( lv_ribbonIsInvisible ));

	    float* m4400          = (float*)(csry_base( lv_m4400             ));
	    float* m4401          = (float*)(csry_base( lv_m4401             ));
	    float* m4402          = (float*)(csry_base( lv_m4402             ));
	    float* m4403          = (float*)(csry_base( lv_m4403             ));

	    float* m4410          = (float*)(csry_base( lv_m4410             ));
	    float* m4411          = (float*)(csry_base( lv_m4411             ));
	    float* m4412          = (float*)(csry_base( lv_m4412             ));
	    float* m4413          = (float*)(csry_base( lv_m4413             ));

	    float* m4420          = (float*)(csry_base( lv_m4420             ));
	    float* m4421          = (float*)(csry_base( lv_m4421             ));
	    float* m4422          = (float*)(csry_base( lv_m4422             ));
	    float* m4423          = (float*)(csry_base( lv_m4423             ));

	    float* m4430          = (float*)(csry_base( lv_m4430             ));
	    float* m4431          = (float*)(csry_base( lv_m4431             ));
	    float* m4432          = (float*)(csry_base( lv_m4432             ));
	    float* m4433          = (float*)(csry_base( lv_m4433             ));

	    int  c, r;

	    /* Over all contours... */
	    for (c = 0;   c < xs3icn_CtrNext;     c++) {

		contourBase[c] =  xs3ict_Ctr[ c ].point_base;
		contourLen[ c] =  xs3ict_Ctr[ c ].point_len ;
		frameNumber[c] =  xs3ict_Ctr[ c ].ctr_frameNumber;

		m4400[      c] =  xs3ict_Ctr[ c ].m.m[0][0];
		m4401[      c] =  xs3ict_Ctr[ c ].m.m[0][1];
		m4402[      c] =  xs3ict_Ctr[ c ].m.m[0][2];
		m4403[      c] =  xs3ict_Ctr[ c ].m.m[0][3];

		m4410[      c] =  xs3ict_Ctr[ c ].m.m[1][0];
		m4411[      c] =  xs3ict_Ctr[ c ].m.m[1][1];
		m4412[      c] =  xs3ict_Ctr[ c ].m.m[1][2];
		m4413[      c] =  xs3ict_Ctr[ c ].m.m[1][3];

		m4420[      c] =  xs3ict_Ctr[ c ].m.m[2][0];
		m4421[      c] =  xs3ict_Ctr[ c ].m.m[2][1];
		m4422[      c] =  xs3ict_Ctr[ c ].m.m[2][2];
		m4423[      c] =  xs3ict_Ctr[ c ].m.m[2][3];

		m4430[      c] =  xs3ict_Ctr[ c ].m.m[3][0];
		m4431[      c] =  xs3ict_Ctr[ c ].m.m[3][1];
		m4432[      c] =  xs3ict_Ctr[ c ].m.m[3][2];
		m4433[      c] =  xs3ict_Ctr[ c ].m.m[3][3];
	    }

	    /* Over all ribbons... */
	    for (r = 0;   r < xs3icn_CtrNext-1;   r++) {
		ribbonBase[ r] =  xs3ict_Ctr[ r ].facet_base;
		ribbonLen[  r] =  xs3ict_Ctr[ r ].facet_len ;
		if (xs3ict_Ctr[ r ].locked) {
		    ribbonIsLocked[    r>>3 ] |= 1 << (r&7);
		}
		if (xs3ict_Ctr[ r ].invisible) {
		    ribbonIsInvisible[ r>>3 ] |= 1 << (r&7);
		}
	    }
	    /* Last ribbon has no actual polygons, */
	    /* since it has only one contour, not  */
	    /* two like the rest:		   */
	    ribbonBase[ r] = 0;
	    ribbonLen[  r] = 0;



	    /* If any ribbons are invisible, create a */
	    /* bitvector to suppress display of them: */
	    {   int seen_invisible_ribbon = FALSE;
		for (r = 0;   r < xs3icn_CtrNext-1;   r++) {
		    if (xs3ict_Ctr[ r ].invisible) {
			seen_invisible_ribbon = TRUE;
			break;
		}   }
		if (!seen_invisible_ribbon) {
		} else {

		    /* Insert & fetch a :FACET-IF bitvector for facet grl:  */
		    xsendmsg2(xs3i07_Facet_Grl, k_setarray, k_facetif, lv_x01v );
		    lv_facetif = xsendmsg1(xs3i07_Facet_Grl, k_getarray, k_facetif);

		    /* Set default value for new bits to 1: */
		    {   csry_rec* p = xsry9c_Find_Immediate_Base(lv_facetif);
			p->default_initializer.i = 0xFF;
		    }

		    /* Set it to 1 on all facets we want displayed, */
		    /* to zero on those we want suppressed:	    */
		    {   char* facetif = (char*) (csry_base( lv_facetif ));
			for (c = 0;   c < xs3icn_CtrNext;     c++) {
			    if (!xs3ict_Ctr[ c ].invisible) {
				int f;
				for (
				    f = xs3ict_Ctr[ c ].facet_base;
				    f < (
					xs3ict_Ctr[ c ].facet_base +
				        xs3ict_Ctr[ c ].facet_len
				    );
			    	    ++f
				) {
				    facetif[ f>>3 ] |= 1 << (f&7);
	}   }   }   }   }   }   }

        /* Create our ribbon relation: */
        xs3i08_Ribbon_Grl= xsendmsg1( lv_xgrl, k_new, cvfixnum( xs3icn_CtrNext ) );

        /* Insert arrays in ribbon relation: */
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_contourbase,lv_contourBase );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_contourlen ,lv_contourLen  );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_framenumber,lv_frameNumber );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_ribbonbase ,lv_ribbonBase  );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_ribbonlen  ,lv_ribbonLen   );
        xsendmsg2(
	    xs3i08_Ribbon_Grl, k_setarray, k_ribbonislocked, lv_ribbonIsLocked
	);
        xsendmsg2(
	    xs3i08_Ribbon_Grl, k_setarray, k_ribbonisinvisible, lv_ribbonIsInvisible
	);

        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4400      ,lv_m4400 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4401      ,lv_m4401 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4402      ,lv_m4402 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4403      ,lv_m4403 );

        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4410      ,lv_m4410 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4411      ,lv_m4411 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4412      ,lv_m4412 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4413      ,lv_m4413 );

        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4420      ,lv_m4420 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4421      ,lv_m4421 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4422      ,lv_m4422 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4423      ,lv_m4423 );

        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4430      ,lv_m4430 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4431      ,lv_m4431 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4432      ,lv_m4432 );
        xsendmsg2(xs3i08_Ribbon_Grl,k_setarray,k_m4433      ,lv_m4433 );

	/* Attach ribbon relation to facet relation: */
	xsendmsg2( xs3i07_Facet_Grl, k_set, k_ribbonrelation, xs3i08_Ribbon_Grl );
    }

    xlpopn(toProt);

    xs3i04_Point_Grl_Valid = FALSE;
    xs3i06_Facet_Grl_Valid = FALSE;

    return   lv_tube;
}

/* }}} */
/* {{{ xs3i65_Load_Zpl -- Load object from file				*/

LVAL xs3i65_Load_Zpl( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    LVAL	lv_result;
    LVAL	lv_slc;

    int		self_zplRefCount;
    float	self_zplZCoord;
    float	self_zplZRate;
    int		self_zplZDir;
    float	self_zplZCap;
    int		self_zplClipBy;
    int		self_zplUseCartoonMode;

    int		self_zplA0_zplClipInside;
    int		self_zplA0_zplBoxFrontIsVisible;
    int		self_zplA0_zplBoxBackIsVisible;
    int		self_zplA0_zplBoxTabsAreVisible;
    int		self_zplA0_zplBoxTint;
    int		self_zplA0_zplBoxIsSolid;

    int		self_zplA1_zplClipInside;
    int		self_zplA1_zplBoxFrontIsVisible;
    int		self_zplA1_zplBoxBackIsVisible;
    int		self_zplA1_zplBoxTabsAreVisible;
    int		self_zplA1_zplBoxTint;
    int		self_zplA1_zplBoxIsSolid;

    int		self_zplCursorMatDirty;

    float	self_zplCursorMat[4][4];
    int		self_zplFace[6];

    char	version;

    int         toProt = 2;
    xlstkcheck(toProt);
    xlsave(lv_slc);
    xlsave(lv_result);

    switch (t) {

    case PaSCII:
    case PbINARY:
        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
            sscanf( xs3i00_Text_Buffer, "%s\n", buf ); 
	    if (*buf < 'a'   ||   *buf > 'c')	xlfail("zplLoad");
            version	= *buf;
        }

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplRefCount	);

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &self_zplZCoord	);

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &self_zplZRate	);

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplZDir	);

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplZCap	);

#ifdef OLD
        self->zplLastDisplayGenerated = -1;
        self->zplTopRotor             =  0; /* Shortcut to top rotor in tree. */
#endif
        if (version < 'b') {
#ifdef OLD
            self_zplClipBy                    = CLIP_BY_DEFAULT;
            self_zplCursorMatDirty            = TRUE;
            self_zplUseCartoonMode            = TRUE;
	    self_zplA[0]_zplClipInside        = TRUE;
	    self_zplA[0]_zplBoxFrontIsVisible = TRUE;
	    self_zplA[0]_zplBoxBackIsVisible  = FALSE;
	    self_zplA[0]_zplBoxTabsAreVisible = TRUE;
	    self_zplA[0]_zplBoxIsSolid        = TRUE;
#endif
        } else {
            xs3i88_Read_Line( fd );
            sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplClipBy  );

            if (version < 'c') {
                self_zplUseCartoonMode = FALSE;
	    } else {
                xs3i88_Read_Line( fd );
                sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplUseCartoonMode	);
	    }

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA0_zplClipInside	);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA0_zplBoxFrontIsVisible);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA0_zplBoxBackIsVisible);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA0_zplBoxTabsAreVisible);

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA0_zplBoxTint           );

            if (version < 'c') {
	        self_zplA0_zplBoxIsSolid = FALSE;
	    } else {
                xs3i88_Read_Line( fd );
	        sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA0_zplBoxIsSolid	);
	    }

            if (version < 'c') {
#ifdef OLD
	        if (self->zplA[0].zplClipInside > CLIP_INSIDE) {
	            self->zplA[0].zplClipInside = CLIP_INSIDE;
                }
#endif
	        self_zplA1_zplClipInside       =!self_zplA0_zplClipInside;

	        self_zplA1_zplBoxFrontIsVisible=self_zplA0_zplBoxFrontIsVisible;
	        self_zplA1_zplBoxBackIsVisible =self_zplA0_zplBoxBackIsVisible;
	        self_zplA1_zplBoxTabsAreVisible=self_zplA0_zplBoxTabsAreVisible;
	        self_zplA1_zplBoxTint          =self_zplA0_zplBoxTint;
	        self_zplA1_zplBoxIsSolid       =self_zplA0_zplBoxIsSolid;
	    } else {
                xs3i88_Read_Line( fd );
	        sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA1_zplClipInside        );
                xs3i88_Read_Line( fd );
	        sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA1_zplBoxFrontIsVisible );
                xs3i88_Read_Line( fd );
	        sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA1_zplBoxBackIsVisible  );
                xs3i88_Read_Line( fd );
	        sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA1_zplBoxTabsAreVisible );
                xs3i88_Read_Line( fd );
	        sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA1_zplBoxTint           );
                xs3i88_Read_Line( fd );
	        sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplA1_zplBoxIsSolid        );
            }

            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplCursorMatDirty    );

	    {   int i,j;
		for     (i = 0;   i < 4;   ++i) {
		    for (j = 0;   j < 4;   ++j) {
                        xs3i88_Read_Line( fd );
			sscanf( xs3i00_Text_Buffer, "%f\n", &self_zplCursorMat[i][j]  );
		    }
		}
	    }
	    {   int i;
		for     (i = 0;   i < 6;   ++i) {
                    xs3i88_Read_Line( fd );
		    sscanf( xs3i00_Text_Buffer, "%d\n", &self_zplFace[i]  );
		}
	    }
        }

	lv_result = xs3i86_Load_Subtree( fd, t );

        {
            char buf[ 80 ];
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "."    )   !=   UsAMEsTRING
            &&  strcmp( buf, ".zpl" )   !=   UsAMEsTRING) {
                xlfail("zplLoad");
            }
        }
        break;

    default:
        xlfail("zplLoad");
    }

    lv_slc = xsendmsg2( lv_xslc, k_new, k_subtree, lv_result );
    xsendmsg2( lv_slc, k_set, k_initialstate, NIL );
    xsendmsg2( lv_slc, k_set, k_currentstate, NIL );

    {   cslc_rec * r = (cslc_rec*) gobjimmbase(lv_slc);

	r->zCoord		= self_zplZCoord;
	r->zRate		= self_zplZRate;
	r->zDir			= self_zplZDir;
	r->zCap			= self_zplZCap;
	r->clipBy		= self_zplClipBy;
	r->useCartoonMode	= self_zplUseCartoonMode;

	r->a0_zplClipInside		= self_zplA0_zplClipInside;
	r->a0_zplBoxFrontIsVisible	= self_zplA0_zplBoxFrontIsVisible;
	r->a0_zplBoxBackIsVisible	= self_zplA0_zplBoxBackIsVisible;
	r->a0_zplBoxTabsAreVisible	= self_zplA0_zplBoxTabsAreVisible;
	r->a0_zplBoxTint		= self_zplA0_zplBoxTint;
	r->a0_zplBoxIsSolid		= self_zplA0_zplBoxIsSolid;

	r->a1_zplClipInside		= self_zplA1_zplClipInside;
	r->a1_zplBoxFrontIsVisible	= self_zplA1_zplBoxFrontIsVisible;
	r->a1_zplBoxBackIsVisible	= self_zplA1_zplBoxBackIsVisible;
	r->a1_zplBoxTabsAreVisible	= self_zplA1_zplBoxTabsAreVisible;
	r->a1_zplBoxTint		= self_zplA1_zplBoxTint;
	r->a1_zplBoxIsSolid		= self_zplA1_zplBoxIsSolid;

	r->cursorMatDirty		= self_zplCursorMatDirty;

	{   int i;
	    int j;
	    for     (i = 4;   i --> 0; ) {
	        for (j = 4;   j --> 0; ) {
		    r->cursorMat.m[i][j] = self_zplCursorMat[i][j];
	}   }	}

	{   int  i = 4;
	    while (i --> 0) r->face[i] = self_zplFace[i];
	}
    }

    xlpopn(toProt);

    return lv_slc;
}

/* }}} */
/* {{{ xs3i70_Load_Txf -- Load object from file				*/

LVAL xs3i70_Load_Txf( dumm, t, fd )
LVAL                  dumm;
int                         t;
FILE *                         fd;
{
    extern LVAL k_filename;
    extern LVAL lv_xtxf;

    char filename[256];
    int  ok_to_animate ;
    int  min_filter ;
    int  mag_filter ;
    int  wrap_type  ;
    int  merge_type ;
    int  texture_is ;

    char	version;
    int		refCount;

    LVAL	lv_result;
    LVAL	lv_txf;
    LVAL	lv_initialTxr;
    LVAL	lv_currentTxr;
    int         toProt = 4;
    filename[0] = '\0';
    xlstkcheck(toProt);
    xlsave(lv_txf);
    xlsave(lv_initialTxr);
    xlsave(lv_currentTxr);
    xlsave(lv_result);

    switch (t) {

    case PaSCII:
    case PbINARY:
        {
            char buf[ 80 ];
            xs3i88_Read_Line( fd );
            sscanf( xs3i00_Text_Buffer, "%s\n", buf ); 
	    if (*buf < 'a'   ||   *buf > 'a') {
		xlfail("txfLoad");
	    }
            version	= *buf;
        }

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &refCount );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", filename	);

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &ok_to_animate );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &min_filter );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &mag_filter );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &wrap_type );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &merge_type );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &texture_is );

	{   extern LVAL k_new;
	    extern LVAL lv_xtxr;

            /* Create our CLASS-TEXTURE instance: */
            ctxr_rec* i_texture;
            ctxr_rec* c_texture;
	    lv_initialTxr		   = xsendmsg0(lv_xtxr,k_new);
	    lv_currentTxr		   = xsendmsg0(lv_xtxr,k_new);
	    i_texture = (ctxr_rec*) gobjimmbase(lv_initialTxr);
	    c_texture = (ctxr_rec*) gobjimmbase(lv_currentTxr);


	    i_texture->r.min_filter = min_filter;
	    i_texture->r.mag_filter = mag_filter;
	    i_texture->r.wrap_type  = wrap_type;
	    i_texture->r.merge_type = merge_type;
	    i_texture->r.texture_is = texture_is;

	    i_texture->r.dirty     = TRUE;

	    lv_result              = xs3i86_Load_Subtree( fd, t );

            *c_texture = *i_texture;
	}

        {   char buf[ 80 ];
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "."    )   !=   UsAMEsTRING
            &&  strcmp( buf, ".txf" )   !=   UsAMEsTRING) {
                xlfail("txfLoad");
            }
        }
        break;

    default:
        xlfail("txfLoad");
    }

    lv_txf = xsendmsg2( lv_xtxf, k_new, k_subtree, lv_result );
    xsendmsg2( lv_txf, k_set, k_initialstate, lv_initialTxr );
    xsendmsg2( lv_txf, k_set, k_currentstate, lv_currentTxr );
    if (*filename) {
	xsendmsg2( lv_txf, k_set, k_filename,     cvstring( filename ) );
    }
    {   ctxf_rec* txf      = xtxf9c_Find_Immediate_Base( lv_txf );
	txf->ok_to_animate = ok_to_animate;
    }

    if (*filename) {
        /* Load the tiff texture file: */
	LVAL xtifa1_main( char* );
	lv_result = xtifa1_main( filename );
	if (lv_result != NIL) {
	    xsendmsg2(lv_initialTxr, k_set, k_graphicrelation, lv_result);
	    xsendmsg2(lv_currentTxr, k_set, k_graphicrelation, lv_result);
    }   }

    xlpopn(toProt);
    return lv_txf;
}

/* }}} */
/* {{{ xs3i86_Load_Subtree                                              */

LVAL xs3i86_Load_Subtree( fd, t )
FILE *                    fd; 
int                           t; 
{ 
    int *   oldAddress; 
    char    buf[   80 ]; 
    char    buf2[ 180 ]; 
    int     i; 
  
    xs3i88_Read_Line( fd );
    sscanf( xs3i00_Text_Buffer, "%s %x\n", buf, &oldAddress );
  
    for (i = 0;   i < xs3i01_Modules_Installed;   ++i) { 
  
        if (strcmp( buf, xs3i02_Module_Prefix[ i ] )   ==   UsAMEsTRING) { 
#ifndef     VERBOSE_DEBUG
	    return (*xs3i03_Module_Load_Fn[ i ])( 0, t, fd );
#else
	    /* Print out object-by-object synopsis of loading, indented */
            /* by nesting depth of object within displaytree:           */
	    LVAL lv;
            static nesting_level = 0;
            int indent;
	    ++nesting_level;
            printf("<%2d>",nesting_level);
            for (indent = nesting_level;   indent --> 0; ) putchar(' ');
            printf("xs3i86 Loading a '%s'...\n",buf);
	    lv = (*xs3i03_Module_Load_Fn[ i ])( 0, t, fd );
            printf("<%2d>",nesting_level);
            for (indent = nesting_level;   indent --> 0; ) putchar(' ');
            printf("xs3i86 Done loading a '%s'.\n",buf);
	    --nesting_level;
	    return lv;
#endif
	}
    } 
    sprintf(buf2,"Load_subtree: unsupported: '%s' %x", buf, oldAddress ); 
    xlfail(buf2);
} 

/* }}} */
/* {{{ xs3i87_Line_Skip_White_Space                                     */

char * xs3i87_Line_Skip_White_Space( t ) 
char *                               t; 
{ 
    while (*t   &&   *t <= ' ')   ++t; 
    return   t; 
} 

/* }}} */
/* {{{ xs3i88_Read_Line -- Read line of text from given input file.	*/

xs3i88_Read_Line( fd )
FILE *	     fd;
{ 
    int      i; 
    char *   s; 
    int      c; 
  
    i   = XSK3_MAX_TEXT;
    s   = xs3i00_Text_Buffer; 
    while (i-- && ((c=fgetc( fd )) != EOF) && (c != '\n')) { 
        if (c == '\t')   c = ' '; 
        if (c != '\r'   &&   c != 0xFF)   *s++ = c; 
    } 
    if (i < 1) {
	xlfail("xs3i88_Read_Line");
    }
    *s = '\0'; 
    return   c != EOF; 
} 

/* }}} */
/* {{{ xs3i89_Load_File                                                 */

LVAL xs3i89_Load_File( fileName )
char		      *fileName; 
{ 
    FILE *   inFD; 
    int      fileType; 
    char     model[ 1000 ]; 
    char     typ[   1000 ]; 
    LVAL     lv_kid; 
  
    int        toProt = 1;
    xlstkcheck(toProt);
    xlsave(   lv_kid);

    /* Open input file: */ 
    { 
        char *   t; 
  
	if (! (inFD = fopen( fileName, "rb" ))) {
	    /* Buggo ... shouldn't really crash on file not found: */
	    sprintf(model, "File not found: %s", fileName);
            xlfail( model ); 
        } 
  
        /* Check file type: */ 
	xs3i88_Read_Line( inFD );
        t       = xs3i87_Line_Skip_White_Space( xs3i00_Text_Buffer ); 
        sscanf( t, "%s %s\n", model, typ );   
        if (strcmp( model, "model" )   !=   UsAMEsTRING) { 
  
	    /* Buggo -- should not crash... */
            xlfail( "?Not a MODEL file!" ); 
        } 
        if        (strcmp( typ, "text"   )   ==   UsAMEsTRING) { 
            fileType    = PaSCII; 
        } else if (strcmp( typ, "binary" )   ==   UsAMEsTRING) { 
            fileType    = PbINARY; 
        } else { 
	    /* Buggo -- should not crash... */
            char buf[ 40 ]; 
            sprintf( buf, "?Bad file type '%s'", typ ); 
            xlfail( buf ); 
        } 
    } 
  
    /* Read child from file: */ 
    lv_kid   = xs3i86_Load_Subtree( inFD, fileType );

    /* Close file: */ 
    fclose( inFD );

    xlpopn(toProt);
    return   lv_kid; 
} 

/* }}} */
/* {{{ xs3i90_Load_Skandha3_File_Fn -- Load a Skandha3 file.		*/

LVAL xs3i90_Load_Skandha3_File_Fn()
{
    int        toProt = 2;
    LVAL  lv_result;
    LVAL  lv_filename = xlgastring();
    char*    filename = (char*)getstring( lv_filename );
    xllastarg();

    xlstkcheck(toProt);
    xlprotect(lv_filename);
    xlsave(   lv_result);

    /* Set up standard color ranges: */ 
    /* White: */ 
    libTint[ LIBtINTwHITE   ].libTRMaxRed       = 1.0;    
    libTint[ LIBtINTwHITE   ].libTRMaxGreen     = 1.0;    
    libTint[ LIBtINTwHITE   ].libTRMaxBlue      = 1.0;    
   
    /* Red: */  
    libTint[ LIBtINTrED     ].libTRMaxRed       = 1.0;    
    libTint[ LIBtINTrED     ].libTRMaxGreen     = 0.0;    
    libTint[ LIBtINTrED     ].libTRMaxBlue      = 0.0;    
   
    /* Green: */  
    libTint[ LIBtINTgREEN   ].libTRMaxRed       = 0.0;    
    libTint[ LIBtINTgREEN   ].libTRMaxGreen     = 1.0;    
    libTint[ LIBtINTgREEN   ].libTRMaxBlue      = 0.0;    
     
    /* Blue: */    
    libTint[ LIBtINTbLUE    ].libTRMaxRed       = 0.0;    
    libTint[ LIBtINTbLUE    ].libTRMaxGreen     = 0.0;    
    libTint[ LIBtINTbLUE    ].libTRMaxBlue      = 1.0;    
     
    /* Magenta: */  
    libTint[ LIBtINTmAGENTA ].libTRMaxRed       = 1.0;    
    libTint[ LIBtINTmAGENTA ].libTRMaxGreen     = 0.0;    
    libTint[ LIBtINTmAGENTA ].libTRMaxBlue      = 1.0;    
     
    /* Cyan: */    
    libTint[ LIBtINTcYAN    ].libTRMaxRed       = 0.0;    
    libTint[ LIBtINTcYAN    ].libTRMaxGreen     = 1.0;    
    libTint[ LIBtINTcYAN    ].libTRMaxBlue      = 1.0;    
     
    /* Yellow: */    
    libTint[ LIBtINTyELLOW  ].libTRMaxRed       = 1.0;    
    libTint[ LIBtINTyELLOW  ].libTRMaxGreen     = 1.0;    
    libTint[ LIBtINTyELLOW  ].libTRMaxBlue      = 0.0;    
   
    {   FILE*inFD;
	if (inFD = fopen( "skandha.ini", "rb" )) {
  
            /* Check file type: */ 
	    xs3i88_Read_Line( inFD );
            if (strcmp( xs3i00_Text_Buffer, "skandha" )   ==   UsAMEsTRING) { 
	        xs3iz0_Load_Config_File( 0, PaSCII, inFD );
            } 
  
            fclose( inFD ); 
    }   }

    xs3i04_Point_Grl_Valid = NULL;
    xs3i06_Facet_Grl_Valid = NULL;

    /* Build up a standard hierarchical Skandha3 displaytree: */
    lv_result = xs3i89_Load_File( filename );
    xlpopn(toProt);
    return lv_result;
}

/* }}} */
/* {{{ xs3ia5_Load_FltArray						*/

void xs3ia5_Load_FltArray(
    float* ary,
    int    len,
    int    t,
    FILE*  fd
) {
    int  rank, dim[7];

    {   char buf[ 80 ];
	xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%s\n", buf );
	if (strcmp( buf, "a" )   !=   UsAMEsTRING) {
	    xlfail( "fltLoad.0" );
    }   }

    xs3i88_Read_Line( fd );
    sscanf( xs3i00_Text_Buffer,
	"%d %d %d %d %d %d %d %d\n",
	&rank,
	&dim[0], &dim[1], &dim[2], &dim[3], &dim[4], &dim[5], &dim[6]
    );
    if (rank   != 1  )   xlfail( "fltLoad: rank != 1" );
    if (dim[0] != len)   xlfail( "fltLoad: dim != len" );

    switch (t) {

    case PaSCII:
        {   int  i;
            for (i = 0;   i < dim[0];  ++i) {
		float f;
		xs3i88_Read_Line( fd );
		sscanf( xs3i00_Text_Buffer, "%f\n", &f );
		ary[i] = f;
	}   }
	break;

    case PbINARY:
        {   int  i;
            for (i = 0;   i < dim[0];  ++i) {
		uAny u;
		u.uI = sk309_FGetW( fd );
		ary[i] = u.uF;
	}   }
	break;

    default:
	xlfail( "fltLoad.1" );
    }

    xs3i88_Read_Line( fd );
    if (strcmp( ".", xs3i00_Text_Buffer )) {
	xlfail( "fltLoad.2" );
    }
}

/* }}} */
/* {{{ xs3iz0_Load_Config_File -- Load config parameters from file	*/ 

xs3iz0_Load_Config_File( dumm, t, fd ) 
int      dumm;    
int            t;    
FILE *            fd;    
{    
    float	libGState_libOpacity;
    float	libGState_libSunAltitude;
    float	libGState_libSunAzimuth;
    float	libGState_libSunX;
    float	libGState_libSunY;
    float	libGState_libSunZ;
    float	libGState_libClipZ;
    int		libAutodraw;
    int		libGState_libScaleAndCenter;
    int		libGState_libAutoclear;
    int		libBlanking;
    int		libGState_libZBuffering;
    int		libOneMap;
    int		libGState_libBackfaces;
    int		libGState_libStyle;
    int		libGState_libNormals;
    int		libGState_libZShading;
    int		libGState_libFlipper;
    int		libPortMode;
    int		libPortShape;
    int		libOneBuffer;

    int   *   p;    
    char      version;    
    float     Red, Green, Blue;
     
    switch (t) {    
     
    case PaSCII:    
    case PbINARY:    
        {    
            char buf[ 80 ];    
	    xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );

            /* Ignore outdated or foriegn configuration files: */
            if (strcmp( xs3i00_Text_Buffer+2, "Iris" ))   return;
            version     = *xs3i00_Text_Buffer;    
            if (version < 'a'   ||   version > 'b') {    
                /* Just ignore unknown configuration files: */
                return;
            }    
        }    
     
        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &libGState_libOpacity	   );

        /* Protect users from mysterious title vanishing: */    
        libGState_libOpacity     = 0.0;    
     
        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &libGState_libSunAltitude  );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &libGState_libSunAzimuth   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &libGState_libSunX 	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &libGState_libSunY 	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &libGState_libSunZ 	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%f\n", &libGState_libClipZ	   );
     
        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libAutodraw	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libGState_libScaleAndCenter  );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libGState_libAutoclear	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libGState_libScaleAndCenter  );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libBlanking	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libGState_libZBuffering	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libOneBuffer	   );
#ifdef OLD
        libBigMap       = libOneBuffer;    
#endif
        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libOneMap	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libGState_libBackfaces	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libGState_libStyle	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libGState_libNormals	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libGState_libZShading	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libGState_libFlipper	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libPortMode	   );

        xs3i88_Read_Line( fd );
	sscanf( xs3i00_Text_Buffer, "%d\n", &libPortShape	   );

        xs3i88_Read_Line( fd );
        xs3i88_Read_Line( fd );
        xs3i88_Read_Line( fd );
        xs3i88_Read_Line( fd );
     
        {    
            int i;    
            for (i = LIBtINTmIN;   i < LIBtINTmAX;   ++i) {    
                xs3i88_Read_Line( fd );
		sscanf( xs3i00_Text_Buffer, "%f\n", &libTint[ i ].libTRMaxRed   );
                xs3i88_Read_Line( fd );
		sscanf( xs3i00_Text_Buffer, "%f\n", &libTint[ i ].libTRMaxGreen );
                xs3i88_Read_Line( fd );
		sscanf( xs3i00_Text_Buffer, "%f\n", &libTint[ i ].libTRMaxBlue  );
#ifdef VERBOZE
printf("color number %d is %g %g %g\n",i,
libTint[ i ].libTRMaxRed,
libTint[ i ].libTRMaxGreen,
libTint[ i ].libTRMaxBlue);
#endif
            }    
        }    
#ifdef OLD
	libTableUpdate();
#endif
 
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Red   );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Green );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBgRAFbACKGROUND, Red, Green, Blue );*/

        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Red   );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Green );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBhERE, Red, Green, Blue );*/

        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Red   );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Green );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBuP, Red, Green, Blue );*/

        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Red   );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Green );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBdOWN, Red, Green, Blue );*/

        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Red   );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Green );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBtEXT, Red, Green, Blue );*/

        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Red   );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Green );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBnORMALvTX, Red, Green, Blue );*/

        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Red   );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Green );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBnORMALfCT, Red, Green, Blue );*/

        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Red   );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Green );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Blue  );    

        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Red   );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Green );    
        xs3i88_Read_Line( fd );
        sscanf( xs3i00_Text_Buffer, "%f\n", &Blue  );    

        if (version > 'a') {
            int lft,bot,top,rgt;
            xs3i88_Read_Line( fd );
            sscanf( xs3i00_Text_Buffer, "%d %d %d %d\n", &lft,&bot, &rgt,&top );
#ifdef OLD
            winposition( lft,rgt, bot,top );
#endif
        }

        {    
            char buf[ 80 ];    
            xs3i88_Read_Line( fd );
	    sscanf( xs3i00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "." )   !=   UsAMEsTRING) {    
                xlfail("xs3iz0_Load_Config_File");    
            }    
        }    
        break;    
     
    default:    
	xlfail("xs3iz0_Load_Config_File");
    }    
}    
/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
