#define SAVE_LID_TEXTURES_SOON (1)
/* {{{ xs3o.c -- Skandha3 Output fns.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      93Apr21
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1994, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 96Aug06 jsp: Save full color info in skandha3 file format.		*/
/* 92Mar01 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

  

#include "../../xcore/c/xlisp.h"

/* For GT_AS_SOLID and such: */
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/cthl.h"
#include "../../xg.3d/c/clgt.h"
#include "../../xg.3d/c/ctxr.h"

#include "cclr.h"
#include "clst.h"
#include "csub.h"
#include "ctrn.h"
#include "ctub.h"
#include "ceye.h"
#include "clit.h"
#include "clid.h"
#include "cedt.h"
#include "cslc.h"
#include "ctxf.h"

extern LVAL k_lightis;
extern LVAL k_additional;
extern LVAL k_replacement;
extern LVAL k_get;
extern LVAL k_initialstate;
extern LVAL k_label;
extern LVAL k_subtree;
extern LVAL s_label;
extern LVAL k_get;
extern LVAL k_initialstate;
extern LVAL k_ribbonrelation;
extern LVAL k_getarray;
extern LVAL k_framenumber;
extern LVAL k_contourbase;
extern LVAL k_contourlen;
extern LVAL k_ribbonbase;
extern LVAL k_ribbonlen;
extern LVAL k_ribbonislocked;
extern LVAL k_ribbonisinvisible;
extern LVAL s_label;
extern LVAL k_saveas;
extern LVAL k_text;
extern LVAL k_binary;

extern LVAL k_m4400;/* Keyword ":M44[0][0]" */
extern LVAL k_m4401;/* Keyword ":M44[0][1]" */
extern LVAL k_m4402;/* Keyword ":M44[0][2]" */
extern LVAL k_m4403;/* Keyword ":M44[0][3]" */

extern LVAL k_m4410;/* Keyword ":M44[1][0]" */
extern LVAL k_m4411;/* Keyword ":M44[1][1]" */
extern LVAL k_m4412;/* Keyword ":M44[1][2]" */
extern LVAL k_m4413;/* Keyword ":M44[1][3]" */

extern LVAL k_m4420;/* Keyword ":M44[2][0]" */
extern LVAL k_m4421;/* Keyword ":M44[2][1]" */
extern LVAL k_m4422;/* Keyword ":M44[2][2]" */
extern LVAL k_m4423;/* Keyword ":M44[2][3]" */

extern LVAL k_m4430;/* Keyword ":M44[3][0]" */
extern LVAL k_m4431;/* Keyword ":M44[3][1]" */
extern LVAL k_m4432;/* Keyword ":M44[3][2]" */
extern LVAL k_m4433;/* Keyword ":M44[3][3]" */

extern LVAL xsendmsg0(); 
extern LVAL xsendmsg1(); 
extern LVAL xsendmsg2(); 

#define PaSCII  (1)
#define PbINARY (2)

#define UsAMEsTRING (0)

union uAnyType {
    int       uI;
    int   *   uP;
    float     uF;
    float *   uFP;
    char  *   uT;
    LVAL      uL;
    short *   uSP;
    int     (*uFn)();
};
#define uAny		union uAnyType

LVAL xs3o86_Save_Subtree();
void xs3oa5_Save_FltArray( float*, int, char*, int, FILE*  );

#define XSK3_MAX_TEXT (200)

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */

/* {{{ sk309_FPutW -- Write 4 bytes to file.				*/

sk309_FPutW( fd, a )
FILE *	     fd;
int          a;
{
    CSRY_INT32 i = a;
    fwrite( &i, sizeof(CSRY_INT32), 1, fd );
}

/* }}} */
/* {{{ xs3o10_Save_Clr -- Save object to file				*/

/* The color-table segments: */
#define LIBtINTdEFAULT  (-1) 
#define LIBtINTmIN      0  
#define LIBtINTwHITE    0  
#define LIBtINTrED      1   
#define LIBtINTgREEN    2   
#define LIBtINTbLUE     3   
#define LIBtINTmAGENTA  4   
#define LIBtINTcYAN     5   
#define LIBtINTyELLOW   6   
#define LIBtINTmAX      7  

/* Types of surface representation: */
#define LIBsTYLEdEFAULT		-1
#define LIBsTYLEcONTOURS	0
#define LIBsTYLEvECTORS		1
#define LIBsTYLEfACETS		2
#define LIBsTYLEsMOOTH		3
#define LIBsTYLEpOINTS		4
#define LIBsTYLEiNVISIBLE	5
#define LIBsTYLEmAX		5

LVAL xs3o10_Save_Clr( lv_clr, t, fd )
LVAL                  lv_clr;
int                           t;
FILE *                           fd;
{
    LVAL	lv_initialMtl = xsendmsg1( lv_clr, k_get, k_initialstate );
    LVAL        lv_kid        = xsendmsg1( lv_clr, k_get, k_subtree      );

    cclr_rec*   xclr       = xclr9c_Find_Immediate_Base( lv_clr        );
    cmtl_rec*   i_material = (cmtl_rec*) gobjimmbase(    lv_initialMtl );

    fprintf(fd, "clr %x\n", lv_clr );

    switch (t) {

    case PaSCII:
    case PbINARY:
	/* Version number: */
#ifdef OLD
	fputs("d\n", fd );
#else
	fputs("e\n", fd );
#endif

	/* Refcount: */
	fputs("1\n", fd );

	fprintf(fd, "%d\n", xclr->tint    );
	fprintf(fd, "%d\n", xclr->normals );

        {   int  style;
	    switch (i_material->r.draw_as) {
	    case GT_AS_DEFAULT    : style = LIBsTYLEdEFAULT  ;  break;
	    case GT_AS_WIRE_FRAME : style = LIBsTYLEvECTORS  ;  break;
	    case GT_AS_FACETS     : style = LIBsTYLEfACETS   ;  break;
	    case GT_AS_SOLID      : style = LIBsTYLEsMOOTH   ;  break;
	    case GT_AS_POINT_CLOUD: style = LIBsTYLEpOINTS   ;  break;
	    case GT_AS_INVISIBLE  : style = LIBsTYLEiNVISIBLE;  break;
            }
	    fprintf(fd, "%d\n", style );
	}

	fprintf(fd, "%g\n", xclr->opacity       );
	fprintf(fd, "%d\n", xclr->backfaces     );
	fprintf(fd, "%d\n", xclr->ok_to_animate );
#ifndef OLD
	fprintf(fd, "%d\n", i_material->r.opacity_type  );

	fprintf(fd, "%g\n", i_material->r.emission_color.r );
	fprintf(fd, "%g\n", i_material->r.emission_color.g );
	fprintf(fd, "%g\n", i_material->r.emission_color.b );

	fprintf(fd, "%g\n", i_material->r.ambient_color.r );
	fprintf(fd, "%g\n", i_material->r.ambient_color.g );
	fprintf(fd, "%g\n", i_material->r.ambient_color.b );

	fprintf(fd, "%g\n", i_material->r.diffuse_color.r );
	fprintf(fd, "%g\n", i_material->r.diffuse_color.g );
	fprintf(fd, "%g\n", i_material->r.diffuse_color.b );

	fprintf(fd, "%g\n", i_material->r.specular_color.r );
	fprintf(fd, "%g\n", i_material->r.specular_color.g );
	fprintf(fd, "%g\n", i_material->r.specular_color.b );

	fprintf(fd, "%g\n", i_material->r.shininess );
	fprintf(fd, "%g\n", i_material->r.alpha     );

	fprintf(fd, "%g\n", i_material->r.emission_weight );
	fprintf(fd, "%g\n", i_material->r.ambient_weight );
	fprintf(fd, "%g\n", i_material->r.diffuse_weight );
	fprintf(fd, "%g\n", i_material->r.specular_weight );
	fprintf(fd, "%g\n", i_material->r.shininess_weight );
	fprintf(fd, "%g\n", i_material->r.alpha_weight );
#endif
	xs3o86_Save_Subtree( fd, t, lv_kid );

	fputs( ".clr\n", fd );
        break;

    default:
        xlfail("clrSave");
    }
    return NIL;
}

/* }}} */
/* {{{ xs3o17_Save_Edt -- Save editor to file				*/

LVAL xs3o17_Save_Edt( lv_edt, t, fd )
LVAL                  lv_edt;
int                           t;
FILE *                           fd;
{
    LVAL        lv_kid     = xsendmsg1( lv_edt, k_get, k_subtree      );

    cedt_rec*   xedt       = xedt9c_Find_Immediate_Base( lv_edt        );

    fprintf(fd, "edt %x\n", lv_edt );

    switch (t) {

    case PaSCII:
    case PbINARY:
	/* Version number: */
	fputs("a\n", fd );

	/* Refcount: */
	fputs("1\n", fd );

	xs3o86_Save_Subtree( fd, t, lv_kid );

	fputs( ".edt\n", fd );
        break;

    default:
        xlfail("edtSave");
    }
    return NIL;
}

/* }}} */
/* {{{ xs3o20_Save_Fbr -- Save object to file				*/

#ifdef OLD
LVAL xs3o20_Save_Fbr( dumm, t, fd )
LVAL    dumm;
int            t;
FILE *            fd;
{
    int		version;
    char	buf[ 80 ];
    int		self_fbrRefCount;
    int		self_fbrDisplayAs;
    int		self_fbrFinished;
    float	self_fbrZCoord;
    int		self_fbrFrameNo;
    int		self_fbrThinnedBy;
    float	self_fbrThinSpacing;
    float	self_fbrThinScale;
    char	self_fbrThinWhen[128];
    char	self_fbrThinWho[128];

    switch (t) {

    case PaSCII:
    case PbINARY:

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%s\n", buf );
        version	= buf[0];

        if (version < 'a'    ||   version > 'c')   xlfail("fbrSave");

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &self_fbrRefCount	 );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &self_fbrDisplayAs	 );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &self_fbrFinished	 );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%f\n", &self_fbrZCoord 	 );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &self_fbrFrameNo	 );

        if (version < 'c') {

        } else {

            xs3o88_Read_Line( fd );
	    sscanf( xs3o00_Text_Buffer, "%d\n", &self_fbrThinnedBy	);

            xs3o88_Read_Line( fd );
	    sscanf( xs3o00_Text_Buffer, "%f\n", &self_fbrThinSpacing	);

            xs3o88_Read_Line( fd );
	    sscanf( xs3o00_Text_Buffer, "%f\n", &self_fbrThinScale	);

            xs3o88_Read_Line( fd );
	    sscanf( xs3o00_Text_Buffer, "%s\n",  self_fbrThinWhen	);

            xs3o88_Read_Line( fd );
	    sscanf( xs3o00_Text_Buffer, "%s\n",  self_fbrThinWho	);

        }

	/* Save our pointset: */
	xs3o86_Save_Subtree( fd, t );

        if (version < 'b') {
        } else {
	    /* Read (and discard) unmodified fiberset: */
	    xs3o86_Save_Subtree( fd, t );
        }

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%s\n", buf );
        if (strcmp( buf, "." )   !=   UsAMEsTRING)   xlfail("fbrSave");

        break;

    default:
        xlfail("fbrSave");
    }

    xlfail("xs3o20_Save_Fbr: not implemented");
    return NIL;
}
#endif

/* }}} */
/* {{{ xs3o25_Save_Lid -- Save object to file				*/

LVAL xs3o25_Save_Lid( lv_lid, t, fd )
LVAL                  lv_lid;
int                           t;
FILE *                           fd;
{
    extern LVAL k_zcoordinate      ;
    extern LVAL k_direction        ;
    extern LVAL k_polygons         ;
    extern LVAL k_offset	   ;
    extern LVAL k_tilingisdirty    ;
    extern LVAL k_displayas        ;
    extern LVAL k_displaynormals   ;
    extern LVAL k_facetnormalsdirty;
    extern LVAL k_selflength       ;
    extern LVAL k_name;
    extern LVAL xthl74_GetProp();
    LVAL lv_thing  = xsendmsg1( lv_lid, k_get, k_initialstate ); /* plist */
    LVAL lv_name   = xthl74_GetProp( &lv_thing, k_name, NIL, /*gotdflt:*/0 );
    char*name      = (char*)getstring( lv_name );

    #define fix(x) getfixnum(xsendmsg1(lv_lid,k_get,(x)))
    #define flo(x) getflonum(xsendmsg1(lv_lid,k_get,(x)))
    float self_lidTubeZCoord      = flo(k_zcoordinate      );
    int   self_lidDirection       = fix(k_direction        );
    int   self_lidPolygons        = fix(k_polygons         );
    float self_lidOffset          = flo(k_offset	   );
    int   self_lidTilingIsDirty   = fix(k_tilingisdirty    );
    int   self_lidDisplayAs       = fix(k_displayas        );
    int   self_lidDisplayNormals  = fix(k_displaynormals   );
    int   self_lidFacetNormalDirty= fix(k_facetnormalsdirty);
    int   self_lidSelfLen         = fix(k_selflength       );
    #undef fix
    #undef flo

    gt_tri_rec r;

    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, lv_thing );

    fprintf(fd, "lid %x\n", lv_lid );

    switch (t) {

    case PaSCII:
    case PbINARY:
	/* Version number: */
#ifdef SAVE_LID_TEXTURES_SOON
	fputs("b\n", fd );
#else
	fputs("a\n", fd );
#endif

	fprintf(fd, "%s\n", name );
	fprintf(fd, "%g\n", self_lidTubeZCoord );
	fprintf(fd, "%d\n", self_lidDirection  );
	fprintf(fd, "%d\n", 1 );	/* Refcount */
	fprintf(fd, "%d\n", self_lidPolygons );
	fprintf(fd, "%d\n", 1 ); /* finished */
	fprintf(fd, "%d\n", 1 ); /* result */
	fprintf(fd, "%g\n", self_lidOffset );
	fprintf(fd, "%d\n", self_lidTilingIsDirty );
	fprintf(fd, "%d\n", self_lidDisplayAs );
	fprintf(fd, "%d\n", self_lidDisplayNormals );
	fprintf(fd, "%d\n", self_lidFacetNormalDirty );
	fprintf(fd, "%d\n", self_lidSelfLen );


        if (t == PaSCII) {
            int i;
	    fprintf(
		fd,
		"%g %g %g\n",
                r.pnx[0],
		r.pny[0],
		r.pnz[0]
	    );
	    for (i = 0;   i < self_lidPolygons;   ++i)  {
		fprintf(
                    fd,
                    "%d %d %d\n",
                    r.f0[i],
                    r.f1[i],
                    r.f2[i]
                );
            }

        } else {
            int i;

	    uAny x;
	    uAny y;
	    uAny z;

	    x.uF = r.pnx[0];
	    y.uF = r.pny[0];
	    z.uF = r.pnz[0];

	    sk309_FPutW( fd, x.uI );
	    sk309_FPutW( fd, y.uI );
	    sk309_FPutW( fd, z.uI );

	    for (i = 0;   i < self_lidPolygons;   ++i)	{
		sk309_FPutW( fd, r.f0[i] );
		sk309_FPutW( fd, r.f1[i] );
		sk309_FPutW( fd, r.f2[i] );
            }
        }

#ifdef SAVE_LID_TEXTURES_SOON
	if (r.ptu != NULL) {
	    xs3oa5_Save_FltArray(
		&r.ptu[ 0 ],
		r.pLen,
		":POINT-TEXTURE-U",
		t,
		fd
	    );
	}
	if (r.ptv != NULL) {
	    xs3oa5_Save_FltArray(
		&r.ptv[ 0 ],
		r.pLen,
		":POINT-TEXTURE-V",
		t,
		fd
	    );
	}
#endif

	fputs( ".lid\n", fd );
        break;

    default:
        xlfail("lidSave");
    }
    return NIL;
}

/* }}} */
/* {{{ xs3o30_Save_Lit -- Save object to file				*/

LVAL xs3o30_Save_Lit( lv_lit, t, fd )
LVAL                  lv_lit;
int                           t;
FILE *                           fd;
{
    LVAL	lv_result;
    LVAL	lv_lightis    = xsendmsg1( lv_lit, k_get, k_lightis      );
    LVAL	lv_initialLgt = xsendmsg1( lv_lit, k_get, k_initialstate );
    LVAL        lv_kid        = xsendmsg1( lv_lit, k_get, k_subtree      );

    clit_rec*   xlit    = xlit9c_Find_Immediate_Base( lv_lit        );
    clgt_rec*   i_light = (clgt_rec*) gobjimmbase(    lv_initialLgt );

    fprintf(fd, "lit %x\n", lv_lit );

    switch (t) {

    case PaSCII:
    case PbINARY:
	/* Version number: */
#ifdef OLD
	fputs("d\n", fd );
#else
	fputs("e\n", fd );
#endif

	/* Refcount: */
	fputs("1\n", fd );

	fprintf(fd, "%d\n", xlit->Default     );
	fprintf(fd, "%g\n", xlit->sunAltitude );
	fprintf(fd, "%g\n", xlit->sunAzimuth  );
	fprintf(fd, "%g\n", xlit->sun[0]      );
	fprintf(fd, "%g\n", xlit->sun[1]      );
	fprintf(fd, "%g\n", xlit->sun[2]      );
	fprintf(fd, "%d\n", xlit->fixed       );
	fprintf(fd, "%d\n", xlit->okToAnimate );

#ifndef OLD
	fprintf(fd, "%d\n", i_light->r.light_is_local );

	fprintf(fd, "%g\n", i_light->r.ambient_color.r );
	fprintf(fd, "%g\n", i_light->r.ambient_color.g );
	fprintf(fd, "%g\n", i_light->r.ambient_color.b );

	fprintf(fd, "%g\n", i_light->r.light_color.r );
	fprintf(fd, "%g\n", i_light->r.light_color.g );
	fprintf(fd, "%g\n", i_light->r.light_color.b );

	{   ctfm_rec*initial_mat;
            xlgt35_Find_Viewing_Matrix( lv_initialLgt, &initial_mat );
	    fprintf(fd, "%g\n", initial_mat->target.x );
	    fprintf(fd, "%g\n", initial_mat->target.y );
	    fprintf(fd, "%g\n", initial_mat->target.z );
	}

	if (lv_lightis == k_additional) {
	    fprintf(fd, "1\n" );
        } else if (lv_lightis == k_replacement) {
	    fprintf(fd, "2\n" );
	} else {
	    fprintf(fd, "0\n" );
	}
#endif

	xs3o86_Save_Subtree( fd, t, lv_kid );

	fputs( ".lit\n", fd );
        break;

    default:
        xlfail("litSave");
    }
    return NIL;
}


/* }}} */
/* {{{ xs3o35_Save_Lst -- Save object to file				*/

LVAL xs3o35_Save_Lst( lv_lst, t, fd )
LVAL                  lv_lst;
int                           t;
FILE*                            fd;
{
    clst_rec*   xlst    = (clst_rec*)xlst9c_Find_Immediate_Base( lv_lst  );
    LVAL        lv_kids = xsendmsg1( lv_lst, k_get, k_subtree );

    fprintf(fd, "lst %x\n", lv_lst );

    /* Version number: */
    fputs("a\n", fd );

    /* Refcount: */
    fputs("1\n", fd );

    /* Kidcount: */
    {   int  n;
	LVAL a = lv_kids;
	for (n = 0; consp(a); a = cdr(a))   n++;
        fprintf(fd,"%d\n", n );
    }

    /* List name: */
    {   LVAL lv_name = xthl90_GetObjectVariable( lv_lst, s_label );
	if (stringp(lv_name))  fprintf(fd,"%s\n", getstring(lv_name) );
	else                   fputs("()\n",fd); /* Shouldn't happen */
    }

    /* lstCursor: */
    fputs("1\n",fd);

    /* lstFinished: */
    fputs("0\n",fd);

    /* lstResult_uI: */
    fputs("0\n",fd);

    /* lstResultOffset: */
    fputs("0\n",fd);

    /* Something historic: */
    fputs("0\n",fd);

    /* Save out all the kids: */
    {   int  n;
	LVAL a = lv_kids;
	for (n = 0;   consp(a);   a = cdr(a)) xs3o86_Save_Subtree( fd, t, car(a) );
    }

    fputs( ".lst\n", fd );
}

/* }}} */
/* {{{ xs3o37_Save_Prt -- Save object to file   			*/

LVAL xs3o37_Save_Prt( lv_prt, t, fd )
LVAL                  lv_prt;
int                           t;
FILE *                           fd;
{
    int		self_prtShape;

    LVAL	lv_result;
    LVAL        lv_kid        = xsendmsg1( lv_prt, k_get, k_subtree      );

    ceye_rec*   xeye       = xeye9c_Find_Immediate_Base( lv_prt        );

    fprintf(fd, "prt %x\n", lv_prt );

    switch (t) {

    case PaSCII:
    case PbINARY:
	/* Version number: */
	fputs("a\n", fd );

	/* Refcount: */
	fputs("1\n", fd );

	/* Port shape: */
	fprintf(fd, "%d\n", xeye->portShape );

	xs3o86_Save_Subtree( fd, t, lv_kid );


	fputs( ".prt\n", fd );
        break;

    default:
        xlfail("prtSave");
    }
}

/* }}} */
/* {{{ xs3o50_Save_Sub -- Save object to file				*/

LVAL xs3o50_Save_Sub( lv_sub, t, fd )
LVAL                  lv_sub;
int                           t;
FILE *                           fd;
{
    LVAL   lv_name = xsendmsg1( lv_sub, k_get, k_label   );
    LVAL   lv_kid  = xsendmsg1( lv_sub, k_get, k_subtree );

    fprintf(fd, "sub %x\n", lv_sub );

    switch (t) {

    case PaSCII:
    case PbINARY:
	/* Version number: */
	fputs("a\n", fd );

	/* Refcount: */
	fputs("1\n", fd );

        fprintf(fd, "%s\n", getstring( lv_name ) );

        xs3o89_Save_File( getstring(lv_name), lv_kid, t );

	fputs( ".sub\n", fd );

        break;

    default:
        xlfail("subSave");
    }
}

/* }}} */
/* {{{ xs3o55_Save_Trn -- Save object to file				*/

LVAL xs3o55_Save_Trn( lv_trn, t, fd )
LVAL                  lv_trn;
int                           t;
FILE *                           fd;
{
    LVAL	lv_initialTfm = xsendmsg1( lv_trn, k_get, k_initialstate );
    LVAL        lv_kid        = xsendmsg1( lv_trn, k_get, k_subtree      );

    ctrn_rec*   xtrn          = (ctrn_rec*)xtrn9c_Find_Immediate_Base(lv_trn);
    ctfm_rec*   i_transform   = (ctfm_rec*) gobjimmbase(    lv_initialTfm );

    fprintf(fd, "trn %x\n", lv_trn );

    switch (t) {

    case PaSCII:
    case PbINARY:
	/* Version number: */
	fputs("e\n", fd );

	/* Refcount: */
	fputs("1\n", fd );

	/* yRotRate: */
	fputs("1\n", fd );

	/* LastTime: */
	fputs("0\n", fd );

	fprintf(fd, "%d\n", xtrn->post_apply );
	fprintf(fd, "%d\n", xtrn->show_axes  );

	/* trnLoc_uPtX,Y,Z: */
	fputs( "0\n", fd );
	fputs( "0\n", fd );
	fputs( "0\n", fd );

	/* trnAltitude, -Azimuth: */
	fputs( "90\n", fd );
	fputs(  "0\n", fd );

	/* trnScale: */
	fputs( "0.1\n", fd );

	/* trnCompatable: */
	fputs( "1\n", fd );

	/* XRotRate, ZRotRate: */
	fputs( "0\n", fd );
	fputs( "0\n", fd );

	/* X/Y/ZMovRate: */
	fputs( "0\n", fd );
	fputs( "0\n", fd );
	fputs( "0\n", fd );

	/* trnZoomRate: */
	fputs( "1\n", fd );

	fprintf(fd, "%d\n", xtrn->locked );


        {   int i, j;
	    /* MIPS cc won't let us combine the following two: */
	    geo_matrix p;p = i_transform->m;

	    /* Print out full matrix: */
            for     (i = 0;   i < 4;   i++)   {
                for (j = 0;   j < 4;   j++)   {
		    fprintf( fd, "%g\n", i_transform->m.m[ i ][ j ] );
                }
            }

	    /* Print out pure-rotation matrix: */
            lib23_Matrix_Pure_Rotation( &p );

            for     (i = 0;   i < 4;   i++)   {
                for (j = 0;   j < 4;   j++)   {
		    fprintf( fd, "%g\n", p.m[ i ][ j ] );
                }
            }
        }

	xs3o86_Save_Subtree( fd, t, lv_kid );
	fputs( ".trn\n", fd );
        break;

    default:
        xlfail( "trnSave" );
    }
}

/* }}} */
/* {{{ xs3o60_Save_Tub -- Save object to file				*/

/* {{{ xs3o59_Save_TubLst -- Save ribbon list to file			*/

/* {{{ xs3o58_Save_Rbn -- Save object to file				*/

/* {{{ xs3o57_Save_Ctr -- Save object to file				*/

/* {{{ xs3o56_Save_Pts -- Save object to file				*/

LVAL xs3o56_Save_Pts(
    fd, t,
    n,
    r,
    contours,
    contourBase, contourLen
)
FILE *       fd;
int          t;
int          n;
gt_tri_rec*  r;
int          contours;
int         *contourBase, *contourLen;
{
    switch (t) {

    case PaSCII:
    case PbINARY:

	fputs("pts 0\n", fd );

	/* Version number: */
#ifdef OLD
	fputs("a\n", fd );
#else
	fputs("b\n", fd );
#endif

	/* Refcount: */
	fputs("1\n", fd );

	/* ptsChildren: */
	fprintf(fd, "%d\n", contourLen[n] );

	/* ptsName: */
	fputs("(points)\n", fd );

	/* ptsCursor: */
	fputs("0\n", fd );

	/* ptsFinished: */
	fputs("0\n", fd );

	/* ptsResult: */
	fputs("0\n", fd );

	/* ptsResultOffset: */
	fputs("0\n", fd );

	/* Something long forgotten: */
	fputs("0\n", fd );

	/* ptsLabelPoints: */
	fputs("0\n", fd );

	/* ptsPicking: */
	fputs("0\n", fd );

	/* ptsLastPointPicked: */
	fputs("0\n", fd );

	/* ptsFriend: */
	fputs("0\n", fd );

        if (t == PaSCII) {
            int     i;
	    int   base = contourBase[n];
            for (i = 0;   i < contourLen[n];  ++i) {
		fprintf(fd,
		    "%g %g %g\n",
		    r->x[ base + i ],
		    r->y[ base + i ],
		    r->z[ base + i ]
		);
	    }

        } else {

            int     i;
	    int   base = contourBase[n];
            for (i = 0;   i < contourLen[n];  ++i) {

		uAny x;
		uAny y;
		uAny z;

		x.uF = r->x[ base + i ];
		y.uF = r->y[ base + i ];
		z.uF = r->z[ base + i ];

		sk309_FPutW( fd, x.uI );
		sk309_FPutW( fd, y.uI );
		sk309_FPutW( fd, z.uI );
	}   }

	if (r->ptu != NULL) {
	    xs3oa5_Save_FltArray(
		&r->ptu[ contourBase[n] ],
		contourLen[n],
		":POINT-TEXTURE-U",
		t,
		fd
	    );
	}
	if (r->ptv != NULL) {
	    xs3oa5_Save_FltArray(
		&r->ptv[ contourBase[n] ],
		contourLen[n],
		":POINT-TEXTURE-V",
		t,
		fd
	    );
	}

	/* End-of-arrays marker: */
	fputs( ".pts\n", fd );

        break;

    default:
        xlfail( "ptsSave" );
    }
}

/* }}} */

LVAL xs3o57_Save_Ctr(
    fd, t,
    n,
    r,
    contours,
    contourBase, contourLen, frameNumber,
    m
)
FILE *       fd;
int          t;
int          n;
gt_tri_rec*  r;
int          contours;
int         *contourBase, *contourLen, *frameNumber;
geo_matrix  *m;
{
    char  buf[ 80 ];

    int   self_ctrRefCount;
    int   self_ctrDisplayAs;
    int   self_ctrFinished;
    float self_ctrZCoord;
    int   self_ctrFrameNo;
    int   self_ctrAreaDirty;
    float self_ctrArea;
    float self_ctrCentroidX;
    float self_ctrCentroidY;
    int   self_ctrIsOpen;
    int   self_ctrWasReversed;
    float self_ctr2D_t2_x0, self_ctr2D_t2_x1, self_ctr2D_t2_x2;
    float self_ctr2D_t2_y0, self_ctr2D_t2_y1, self_ctr2D_t2_y2;

    switch (t) {

    case PaSCII:
    case PbINARY:

	fputs("ctr 0\n", fd );

	/* Version number: */
	fputs("e\n", fd );

	/* Refcount: */
	fputs("1\n", fd );

	/* rbnDisplayAs: */
	fprintf(fd, "%d\n", LIBsTYLEdEFAULT );

	/* ctrFinished: */
	fputs("1\n", fd );

        /* ctrZCoord: */
        if   (r->pLen > contourBase[n])  fprintf(fd, "%g\n", r->z[contourBase[n]] );
        else                             fputs("0.0\n", fd                        );

        /* ctrFrameNumber: */
	fprintf(fd, "%d\n", frameNumber[n] );

	/* ctrAreaDirty: */
	fputs("1\n", fd );

	/* ctrArea: */
	fputs("0.0\n", fd );

	/* ctrCentroidX: */
	fputs("0.0\n", fd );

	/* ctrCentroidY: */
	fputs("0.0\n", fd );

	/* ctrIsOpen: */
	fputs("0\n", fd );

	/* ctrWasReversed: */
	fputs("0\n", fd );

	/* ctr2D_t2_x0/1/2, y0/1/2: */
	fputs("1.0\n0.0\n0.0\n0.0\n1.0\n0.0\n", fd );

	{   int row, col;
	    for     (row = 0;   row < 4;   ++row) {
		for (col = 0;   col < 4;   ++col) {
		    fprintf( fd, "%g\n", m->m[row][col] );
	}   }	}

	/* Save out our pointset: */
	xs3o56_Save_Pts(
	    fd, t,
	    n,
	    r,
	    contours,
	    contourBase, contourLen
	);

	fputs( ".ctr\n", fd );
        break;

    default:
        xlfail("ctrSave");
    }
}

/* }}} */

LVAL xs3o58_Save_Rbn(
    fd, t,
    n,
    r,
    contours,
    contourBase, contourLen, frameNumber,
    ribbonBase,  ribbonLen,
    ribbonIsLocked,
    ribbonIsInvisible,
    m
)

FILE *       fd;
int          t;
int          n;
gt_tri_rec*  r;
int          contours;
int         *contourBase,    *contourLen, *frameNumber;
int         *ribbonBase ,    *ribbonLen ;
char        *ribbonIsLocked, *ribbonIsInvisible;
geo_matrix  *m;
{
    switch (t) {

    case PaSCII:
    case PbINARY:

	fputs("rbn 0\n", fd );

	/* Version number: */
	fputs("d\n", fd );

	/* Refcount: */
	fputs("1\n", fd );

	/* rbnPolygons: */
	fprintf(fd, "%d\n", ribbonLen[n] );

	/* rbnCursor: */
	fputs("0\n", fd );

	/* rbnFinished: */
	fputs("1\n", fd );

	/* rbnResult_uI: */
	fputs("0\n", fd );

	/* rbnResultOffset: */
	fputs("0\n", fd );

	/* Some bit of history: */
	fputs("0\n", fd );

	/* rbnTilingIsDirty: */
	fputs("0\n", fd );

	/* rbnLastPolyPicked: */
	fputs("0\n", fd );

	/* rbnDisplayAs: */
	if (ribbonIsInvisible[n>>3] & (1<<(n&7))) {
	    fprintf(fd,"%d\n", LIBsTYLEiNVISIBLE );
	} else {
	    fprintf(fd,"%d\n", LIBsTYLEdEFAULT   );
	}

	/* rbnDisplayNormals: */
	fputs("0\n", fd );

	/* rbnDebug: */
	fputs("0\n", fd );

	/* rbnFacetNormalsDirty: */
	fprintf(fd, "%d\n", !r->got_facet_normals );

	/* rbnPointNormalsDirty: */
	fputs("0\n", fd );

        /* rbnPointNormals, count of point normals for this contour: */
	fprintf(fd, "%d\n", contourLen[n] );

	/* rbnPolygonsLocked: */
	if (ribbonIsLocked[n>>3] & (1<<(n&7)))   fputs("1\n", fd );
	else					 fputs("0\n", fd );



	/* rbnPrevLen.  Yes, 'next' and 'prev' got reversed at some point: */
	fprintf(fd, "%d\n", n<contours-1 ? contourLen[n+1] : 0 );

	/* rbnSelfLen: */
	fprintf(fd, "%d\n",       contourLen[n  ]     );

        if (t == PaSCII) {

	    /* Over all facets in ribbon: */
	    int  rbase  = ribbonBase[ n];
	    int  cbase  = contourBase[n];
	    int  clen   = contourLen[ n];
            int  i;
            for (i = 0;   i < ribbonLen[n];   i++)   {

		/* Find contour indices for corners of our triangle: */
		int f0 = r->f0[ rbase + i ];
		int f1 = r->f1[ rbase + i ];
		int f2 = r->f2[ rbase + i ];

		/* Convert to funny skandha3 encoding whereby */
		/* negative indices refer to points on our    */
		/* neighbor's contour instead of our own:     */
/*printf("xs3o58_Save_Rbn: rbase d=%d cbase d=%d clen d=%d i d=%d f0/1/2 %d/%d/%d\n",rbase,cbase,clen,i,f0,f1,f2);*/
		f0 = (f0-cbase >= clen) ? -1 -(f0 - contourBase[n+1]) : f0-cbase;
		f1 = (f1-cbase >= clen) ? -1 -(f1 - contourBase[n+1]) : f1-cbase;
		f2 = (f2-cbase >= clen) ? -1 -(f2 - contourBase[n+1]) : f2-cbase;
/*printf("     -> f0/1/2 %d/%d/%d\n",f0,f1,f2);*/

		if (!r->got_facet_normals) {
		    fprintf(fd,
                        "%d %d %d\n",
                         f0,f1,f2
		    );
		} else {
		    float x  = r->fnx[  rbase + i ];
		    float y  = r->fny[  rbase + i ];
		    float z  = r->fnz[  rbase + i ];
		    fprintf(fd,
                        "%g %g %g %d %d %d\n",
                          x, y, z,f0,f1,f2
		    );
	        }
	    }

        } else {

	    /* Over all facets in ribbon: */
	    int  rbase = ribbonBase[ n];
	    int  cbase = contourBase[n];
	    int  clen  = contourLen[ n];
            int  i;
            for (i = 0;   i < ribbonLen[n];   i++)   {

	        /* Write components of facet normal, if present: */
		if (r->got_facet_normals) {
		    uAny x;
		    uAny y;
		    uAny z;

		    x.uF  = r->fnx[  rbase + i ];
		    y.uF  = r->fny[  rbase + i ];
		    z.uF  = r->fnz[  rbase + i ];

		    sk309_FPutW( fd, x.uI );
		    sk309_FPutW( fd, y.uI );
		    sk309_FPutW( fd, z.uI );
                }

		/* Convert and write indices for corners of our triangle: */
		{   int f0 = r->f0[   rbase + i ];
		    int f1 = r->f1[   rbase + i ];
		    int f2 = r->f2[   rbase + i ];

		    /* Convert to funny skandha3 encoding whereby */
		    /* negative indices refer to points on our    */
		    /* neighbor's contour instead of our own:     */
		    f0 = (f0-cbase >= clen) ? -1 -(f0-contourBase[n+1]) : f0-cbase;
		    f1 = (f1-cbase >= clen) ? -1 -(f1-contourBase[n+1]) : f1-cbase;
		    f2 = (f2-cbase >= clen) ? -1 -(f2-contourBase[n+1]) : f2-cbase;

		    sk309_FPutW( fd, f0 );
		    sk309_FPutW( fd, f1 );
		    sk309_FPutW( fd, f2 );
        }   }   }

        /* Save our private vector of point-normal definitions: */
        if (t == PaSCII) {

	    int  cbase = contourBase[n];
            int  i;
            for (i = 0;   i < contourLen[n];   i++)   {

		fprintf(fd,
		    "%g %g %g\n",
		    r->pnx[ cbase + i ],
		    r->pny[ cbase + i ],
		    r->pnz[ cbase + i ]
		);
	    }

        } else {

	    int  cbase = contourBase[n];
	    int  clen  = contourLen[ n];
            int  i;
            for (i = 0;   i < contourLen[n];   i++)   {

		uAny x;
		uAny y;
		uAny z;

		x.uF  = r->pnx[  cbase + i ];
		y.uF  = r->pny[  cbase + i ];
		z.uF  = r->pnz[  cbase + i ];

		sk309_FPutW( fd, x.uI );
		sk309_FPutW( fd, y.uI );
		sk309_FPutW( fd, z.uI );
        }   }

        /* Save our contour: */
	xs3o57_Save_Ctr(
	    fd, t,
	    n,
	    r,
	    contours,
	    contourBase, contourLen, frameNumber,
	    m
	);

	fputs( ".rbn\n", fd );

        break;

    default:
        xlfail("rbnSave");
    }
}

/* }}} */

LVAL xs3o59_Save_TubLst( lv_tub, t, fd )
LVAL                     lv_tub;
int                              t;
FILE *                              fd;
{
    /* Buggo, the following code is now redundant with  */
    /* xtubb7_Fetch_Contour_Information, should rewrite */
    /* to use it here someday. 94May05jsp.		*/

    /* Unpack some stuff we need: */
    LVAL lv_tubName  = xthl90_GetObjectVariable( lv_tub, s_label );
    LVAL lv_thing    = xsendmsg1( lv_tub, k_get, k_initialstate );
    LVAL lv_pointGrl = xthlA2_Get_Point_Relation_From_Thing( lv_thing );
    LVAL lv_facetGrl = xthlA4_Get_Facet_Relation_From_Thing( lv_thing );

    /* Fetch ribbon relation from facet relation: */
    LVAL lv_ribbons	  = xsendmsg1( lv_facetGrl, k_get, k_ribbonrelation );

    /* Fetch arrays from ribbon relation: */
    LVAL lv_frameNumber   = xsendmsg1( lv_ribbons, k_getarray, k_framenumber );
    LVAL lv_contourBase   = xsendmsg1( lv_ribbons, k_getarray, k_contourbase );
    LVAL lv_contourLen    = xsendmsg1( lv_ribbons, k_getarray, k_contourlen  );
    LVAL lv_ribbonBase    = xsendmsg1( lv_ribbons, k_getarray, k_ribbonbase  );
    LVAL lv_ribbonLen     = xsendmsg1( lv_ribbons, k_getarray, k_ribbonlen   );
    LVAL lv_ribbonIsLocked= xsendmsg1( lv_ribbons, k_getarray, k_ribbonislocked);
    LVAL lv_ribbonIsInvisible=xsendmsg1(lv_ribbons,k_getarray, k_ribbonisinvisible);

    LVAL lv_m4400         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4400       );
    LVAL lv_m4401         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4401       );
    LVAL lv_m4402         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4402       );
    LVAL lv_m4403         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4403       );

    LVAL lv_m4410         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4410       );
    LVAL lv_m4411         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4411       );
    LVAL lv_m4412         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4412       );
    LVAL lv_m4413         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4413       );

    LVAL lv_m4420         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4420       );
    LVAL lv_m4421         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4421       );
    LVAL lv_m4422         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4422       );
    LVAL lv_m4423         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4423       );

    LVAL lv_m4430         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4430       );
    LVAL lv_m4431         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4431       );
    LVAL lv_m4432         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4432       );
    LVAL lv_m4433         =xsendmsg1(  lv_ribbons ,k_getarray, k_m4433       );

    /* Assume our arrays are 1-D and ignore fill pointer */
    /* ('cause it seems to be set to zero!)		 */
    csry_rec* hc = xsry9c_Find_Immediate_Base( lv_contourBase );
    int contours = hc->dim[0];
    csry_rec* hr = xsry9c_Find_Immediate_Base( lv_ribbonBase  );

    /* buggo ... should do some validation in here. */
    int*   frameNumber       = (int  *) (csry_base( lv_frameNumber       ));
    int*   contourBase       = (int  *) (csry_base( lv_contourBase       ));
    int*   contourLen        = (int  *) (csry_base( lv_contourLen        ));
    int*   ribbonBase        = (int  *) (csry_base( lv_ribbonBase        ));
    int*   ribbonLen         = (int  *) (csry_base( lv_ribbonLen         ));
    char*  ribbonIsLocked    = (char *) (csry_base( lv_ribbonIsLocked    ));
    char*  ribbonIsInvisible = (char *) (csry_base( lv_ribbonIsInvisible ));

    float* m4400             = (float*) (csry_base( lv_m4400             ));
    float* m4401             = (float*) (csry_base( lv_m4401             ));
    float* m4402             = (float*) (csry_base( lv_m4402             ));
    float* m4403             = (float*) (csry_base( lv_m4403             ));

    float* m4410             = (float*) (csry_base( lv_m4410             ));
    float* m4411             = (float*) (csry_base( lv_m4411             ));
    float* m4412             = (float*) (csry_base( lv_m4412             ));
    float* m4413             = (float*) (csry_base( lv_m4413             ));

    float* m4420             = (float*) (csry_base( lv_m4420             ));
    float* m4421             = (float*) (csry_base( lv_m4421             ));
    float* m4422             = (float*) (csry_base( lv_m4422             ));
    float* m4423             = (float*) (csry_base( lv_m4423             ));

    float* m4430             = (float*) (csry_base( lv_m4430             ));
    float* m4431             = (float*) (csry_base( lv_m4431             ));
    float* m4432             = (float*) (csry_base( lv_m4432             ));
    float* m4433             = (float*) (csry_base( lv_m4433             ));

    geo_matrix m;

    gt_tri_rec r;

    xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
    xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_pointGrl );
    xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_facetGrl );

    fprintf(fd, "lst %x\n", lv_tub );

    /* Version number: */
    fputs("a\n", fd );

    /* Refcount: */
    fputs("1\n", fd );

    /* Kidcount: */
    fprintf(fd,"%d\n", contours );

    /* List name: */
    fputs("Ribbons\n", fd );

    /* lstCursor: */
    fputs("1\n",fd);

    /* lstFinished: */
    fputs("0\n",fd);

    /* lstResult_uI: */
    fputs("0\n",fd);

    /* lstResultOffset: */
    fputs("0\n",fd);

    /* Something historic: */
    fputs("0\n",fd);

    /* Save out all the kids: */
    {   int  n;
	for (n = 0;   n < contours;   ++n) {

	    m.m[0][0] = m4400[n];
	    m.m[0][1] = m4401[n];
	    m.m[0][2] = m4402[n];
	    m.m[0][3] = m4403[n];

	    m.m[1][0] = m4410[n];
	    m.m[1][1] = m4411[n];
	    m.m[1][2] = m4412[n];
	    m.m[1][3] = m4413[n];

	    m.m[2][0] = m4420[n];
	    m.m[2][1] = m4421[n];
	    m.m[2][2] = m4422[n];
	    m.m[2][3] = m4423[n];

	    m.m[3][0] = m4430[n];
	    m.m[3][1] = m4431[n];
	    m.m[3][2] = m4432[n];
	    m.m[3][3] = m4433[n];

            xs3o58_Save_Rbn(
		fd, t,
		n,
		&r,
		contours,
                contourBase, contourLen, frameNumber,
		ribbonBase , ribbonLen,
		ribbonIsLocked,
		ribbonIsInvisible,
		&m
	    );
        }
    }

    fputs( ".lst\n", fd );
}

/* }}} */

LVAL xs3o60_Save_Tub( lv_tub, t, fd )
LVAL                  lv_tub;
int                           t;
FILE *                           fd;
{
    fprintf(fd, "tub %x\n", lv_tub );

    /* Version number: */
    fputs("a\n", fd );

    /* Refcount: */
    fputs("1\n", fd );

    /* Tube name: */
    {   LVAL lv_name = xthl90_GetObjectVariable( lv_tub, s_label );
	if (stringp(lv_name))  fprintf(fd,"%s\n", getstring(lv_name) );
	else                   fputs("()\n",fd); /* Shouldn't happen */
    }

    xs3o59_Save_TubLst( lv_tub, t, fd );

    fputs(".tub\n", fd );
}

/* }}} */
/* {{{ xs3o65_Save_Zpl -- Save object to file				*/

LVAL xs3o65_Save_Zpl( lv_slc, t, fd )
LVAL                  lv_slc;
int                           t;
FILE *                           fd;
{
    LVAL	lv_initialZpl = xsendmsg1( lv_slc, k_get, k_initialstate );
    LVAL        lv_kid        = xsendmsg1( lv_slc, k_get, k_subtree      );

    cslc_rec*   xslc       = xslc9c_Find_Immediate_Base( lv_slc        );
#ifdef SOON
    czpl_rec*   i_slicer   = (czpl_rec*) gobjimmbase(    lv_initialZpl );
#endif

    fprintf(fd, "zpl %x\n", lv_slc );

    switch (t) {

    case PaSCII:
    case PbINARY:
	/* Version number: */
	fputs("c\n", fd );

	/* Refcount: */
	fputs("1\n", fd );

	fprintf(fd, "%g\n", xslc->zCoord	);
	fprintf(fd, "%g\n", xslc->zRate		);
	fprintf(fd, "%d\n", xslc->zDir		);
	fprintf(fd, "%d\n", xslc->zCap		);
	fprintf(fd, "%d\n", xslc->clipBy	);
	fprintf(fd, "%d\n", xslc->useCartoonMode);

	fprintf(fd, "%d\n", xslc->a0_zplClipInside);
	fprintf(fd, "%d\n", xslc->a0_zplBoxFrontIsVisible);
	fprintf(fd, "%d\n", xslc->a0_zplBoxBackIsVisible);
	fprintf(fd, "%d\n", xslc->a0_zplBoxTabsAreVisible);
	fprintf(fd, "%d\n", xslc->a0_zplBoxTint);
	fprintf(fd, "%d\n", xslc->a0_zplBoxIsSolid);

	fprintf(fd, "%d\n", xslc->a1_zplClipInside);
	fprintf(fd, "%d\n", xslc->a1_zplBoxFrontIsVisible);
	fprintf(fd, "%d\n", xslc->a1_zplBoxBackIsVisible);
	fprintf(fd, "%d\n", xslc->a1_zplBoxTabsAreVisible);
	fprintf(fd, "%d\n", xslc->a1_zplBoxTint);
	fprintf(fd, "%d\n", xslc->a1_zplBoxIsSolid);

	fprintf(fd, "%d\n", xslc->cursorMatDirty);

	{   int i,j;
	    for     (i = 0;   i < 4;   ++i) {
		for (j = 0;   j < 4;   ++j) {
		    fprintf( fd, "%g\n", xslc->cursorMat.m[i][j]  );
	}   }	}

	{   int i;
	    for     (i = 0;   i < 6;   ++i) {
		fprintf(fd, "%d\n", xslc->face[i]  );
	}   }

	xs3o86_Save_Subtree( fd, t, lv_kid );

	fputs( ".zpl\n", fd );
        break;

    default:
        xlfail("zplSave");
    }
    return NIL;
}

/* }}} */
/* {{{ xs3o70_Save_Txf -- Save object to file				*/

LVAL xs3o70_Save_Txf( lv_txf, t, fd )
LVAL                  lv_txf;
int                           t;
FILE *                           fd;
{
    extern LVAL s_filename;
    LVAL	lv_initialTxr = xsendmsg1( lv_txf, k_get, k_initialstate );
    LVAL        lv_kid        = xsendmsg1( lv_txf, k_get, k_subtree      );
    LVAL        lv_filename   = xthl90_GetObjectVariable( lv_txf, s_filename );

    ctxf_rec*   xtxf    = xtxf9c_Find_Immediate_Base( lv_txf        );
    ctxr_rec*   i_txr   = (ctxr_rec*) gobjimmbase(    lv_initialTxr );

    fprintf(fd, "txf %x\n", lv_txf );

    switch (t) {

    case PaSCII:
    case PbINARY:
	/* Version number: */
	fputs("a\n", fd );

	/* Refcount: */
	fputs("1\n", fd );

	if (stringp(lv_filename)) fprintf(fd, "%s\n", getstring(lv_filename));
	else                      fputs( "\n", fd );

	fprintf(fd, "%d\n", xtxf->ok_to_animate );
	fprintf(fd, "%d\n", i_txr->r.min_filter );
	fprintf(fd, "%d\n", i_txr->r.mag_filter );
	fprintf(fd, "%d\n", i_txr->r.wrap_type  );
	fprintf(fd, "%d\n", i_txr->r.merge_type );
	fprintf(fd, "%d\n", i_txr->r.texture_is );

	xs3o86_Save_Subtree( fd, t, lv_kid );

	fputs( ".txf\n", fd );
        break;

    default:
        xlfail("txfSave");
    }
    return NIL;
}

/* }}} */
/* {{{ xs3o86_Save_Subtree                                              */

LVAL xs3o86_Save_Subtree( fd, t, lv_object )
FILE *                    fd; 
int                           t; 
LVAL				 lv_object;
{ 
    /********************************************/
    /* Switch on type of object being written.  */
    /* Making these fns methods in the classes  */
    /* would be more thematic, but I don't like */
    /* this file format much, and concentrating */
    /* all the code for it here allows me to    */
    /* fantasize about someday ripping it all   */
    /* out of the program *grin*:		*/
    /********************************************/

    if      (xclrp(lv_object))   xs3o10_Save_Clr( lv_object, t, fd );
    else if (xedtp(lv_object))   xs3o17_Save_Edt( lv_object, t, fd );
#ifdef SOMEDAY
    else if (xfbrp(lv_object))   xs3o20_Save_Fbr( lv_object, t, fd );
#endif
    else if (xlidp(lv_object))   xs3o25_Save_Lid( lv_object, t, fd );
    else if (xlitp(lv_object))   xs3o30_Save_Lit( lv_object, t, fd );
    else if (xlstp(lv_object))   xs3o35_Save_Lst( lv_object, t, fd );
    else if (xeyep(lv_object))   xs3o37_Save_Prt( lv_object, t, fd );
    else if (xsubp(lv_object))   xs3o50_Save_Sub( lv_object, t, fd );
    else if (xtrnp(lv_object))   xs3o55_Save_Trn( lv_object, t, fd );
    else if (xtubp(lv_object))   xs3o60_Save_Tub( lv_object, t, fd );
    else if (xslcp(lv_object))   xs3o65_Save_Zpl( lv_object, t, fd );
    else if (xtxfp(lv_object))   xs3o70_Save_Txf( lv_object, t, fd );
    else {
        xlerror(
            "XSK3-SAVE-SKANDHA3-FILE: unsupported object in subtree",
	    lv_object
        );
    }
} 

/* }}} */
/* {{{ xs3o89_Save_File                                                 */

xs3o89_Save_File( fileName, lv_object, fileType )
char		 *fileName; 
LVAL			    lv_object;
int				       fileType; /* PbINARY/PaSCII */
{ 
    FILE *   outFD; 
    char     model[ 1000 ]; 
    char     typ[   1000 ]; 
    LVAL     lv_kid; 
  
    /* Open input file: */ 
    if (! (outFD = fopen( fileName, "w" ))) {
	sprintf(model, "Couldn't create: %s", fileName);
	xlfail( model ); 
    } 

    /* Write file type: */ 
    fprintf( outFD, "model %s\n", fileType==PbINARY ? "binary" : "text" );   
  
    /* Write object to file: */ 
    xs3o86_Save_Subtree( outFD, fileType, lv_object );

    /* Close file: */ 
    fclose( outFD );
} 

/* }}} */
/* {{{ xs3o90_Save_Skandha3_File_Fn -- Save a Skandha3 file.		*/

LVAL xs3o90_Save_Skandha3_File_Fn()
{
    int        toProt = 3;
    LVAL  lv_result;
    LVAL  lv_filename = xlgastring();
    LVAL  lv_object   = xlgaobject();
    char*    filename = (char*)getstring( lv_filename );
    int   typ = PbINARY;
    while (moreargs()) {
        LVAL       key = xlgasymbol();
	if        (key == k_saveas) {
	    LVAL     val = xlgasymbol();
	    if      (val == k_text)   typ = PaSCII ;
	    else if (val == k_binary) typ = PbINARY;
	    else {
	        xlerror("Bad XSK3-SAVE-SKANDHA3-FILE :SAVE-AS value",val);
	    }
	} else {
	    xlerror("Bad XSK3-SAVE-SKANDHA3-FILE keyword",key);
    }   }

    xlstkcheck(toProt);
    xlprotect(lv_filename);
    xlprotect(lv_object  );
    xlsave(   lv_result  );

    /* Write out treewalk of hierarchical Skandha3 displaytree: */
    lv_result = (LVAL)xs3o89_Save_File( filename, lv_object, typ );

    xlpopn(toProt);
    return lv_result;
}

/* }}} */
/* {{{ xs3oa5_Save_FltArray						*/

void xs3oa5_Save_FltArray(
    float* a,
    int    len,
    char*  name,
    int    t,
    FILE*  fd
) {
    fprintf(fd, "flt %s\n", name );
    fputs("a\n", fd );	/* Version */
    /* Rank followed by seven dimensions.    */
    /* For rank==1, second dimension is      */
    /* fill pointer.  This isn't used here,  */
    /* but is intended to be compatable with */
    /* planned format for general relations. */
    fprintf(fd, "1 %d %d 0 0 0 0 0\n", len, len );
    switch (t) {

    case PaSCII:
        {   int     i;
            for (i = 0;   i < len;  ++i) {
		fprintf(fd, "%g\n", a[i] );
	}   }
	break;

    case PbINARY:
        {   int     i;
            for (i = 0;   i < len;  ++i) {
		uAny u;	u.uF = a[i];
		sk309_FPutW( fd, u.uI );
	}   }
	break;

    default:
        xlfail( "fltSave" );
    }
    fputs(".\n", fd );
}

/* }}} */
/* {{{ xs3oz0_Save_Config_File -- Save config parameters from file	*/ 

#ifdef OLD
xs3oz0_Save_Config_File( dumm, t, fd ) 
int      dumm;    
int            t;    
FILE *            fd;    
{    
    float	libGState_libOpacity;
    float	libGState_libSunAltitude;
    float	libGState_libSunAzimuth;
    float	libGState_libSunX;
    float	libGState_libSunY;
    float	libGState_libSunZ;
    float	libGState_libClipZ;
    int		libAutodraw;
    int		libGState_libScaleAndCenter;
    int		libGState_libAutoclear;
    int		libBlanking;
    int		libGState_libZBuffering;
    int		libOneMap;
    int		libGState_libBackfaces;
    int		libGState_libStyle;
    int		libGState_libNormals;
    int		libGState_libZShading;
    int		libGState_libFlipper;
    int		libPortMode;
    int		libPortShape;
    int		libOneBuffer;

    int   *   p;    
    char      version;    
    float     Red, Green, Blue;
     
    switch (t) {    
     
    case PaSCII:    
    case PbINARY:    
        {    
            char buf[ 80 ];    
	    xs3o88_Read_Line( fd );
	    sscanf( xs3o00_Text_Buffer, "%s\n", buf );

            /* Ignore outdated or foriegn configuration files: */
            if (strcmp( xs3o00_Text_Buffer+2, "Iris" ))   return;
            version     = *xs3o00_Text_Buffer;    
            if (version < 'a'   ||   version > 'b') {    
                /* Just ignore unknown configuration files: */
                return;
            }    
        }    
     
        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%f\n", &libGState_libOpacity	   );

        /* Protect users from mysterious title vanishing: */    
        libGState_libOpacity     = 0.0;    
     
        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%f\n", &libGState_libSunAltitude  );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%f\n", &libGState_libSunAzimuth   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%f\n", &libGState_libSunX 	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%f\n", &libGState_libSunY 	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%f\n", &libGState_libSunZ 	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%f\n", &libGState_libClipZ	   );
     
        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libAutodraw	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libGState_libScaleAndCenter  );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libGState_libAutoclear	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libGState_libScaleAndCenter  );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libBlanking	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libGState_libZBuffering	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libOneBuffer	   );
#ifdef OLD
        libBigMap       = libOneBuffer;    
#endif
        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libOneMap	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libGState_libBackfaces	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libGState_libStyle	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libGState_libNormals	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libGState_libZShading	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libGState_libFlipper	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libPortMode	   );

        xs3o88_Read_Line( fd );
	sscanf( xs3o00_Text_Buffer, "%d\n", &libPortShape	   );

        xs3o88_Read_Line( fd );
        xs3o88_Read_Line( fd );
        xs3o88_Read_Line( fd );
        xs3o88_Read_Line( fd );
     
        {    
            int i;    
            for (i = LIBtINTmIN;   i < LIBtINTmAX;   ++i) {    
                xs3o88_Read_Line( fd );
		sscanf( xs3o00_Text_Buffer, "%f\n", &libTint[ i ].libTRMaxRed   );
                xs3o88_Read_Line( fd );
		sscanf( xs3o00_Text_Buffer, "%f\n", &libTint[ i ].libTRMaxGreen );
                xs3o88_Read_Line( fd );
		sscanf( xs3o00_Text_Buffer, "%f\n", &libTint[ i ].libTRMaxBlue  );
#ifdef VERBOZE
printf("color number %d is %g %g %g\n",i,
libTint[ i ].libTRMaxRed,
libTint[ i ].libTRMaxGreen,
libTint[ i ].libTRMaxBlue);
#endif
            }    
        }    
#ifdef OLD
	libTableUpdate();
#endif
 
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Red   );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Green );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBgRAFbACKGROUND, Red, Green, Blue );*/

        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Red   );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Green );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBhERE, Red, Green, Blue );*/

        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Red   );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Green );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBuP, Red, Green, Blue );*/

        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Red   );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Green );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBdOWN, Red, Green, Blue );*/

        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Red   );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Green );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBtEXT, Red, Green, Blue );*/

        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Red   );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Green );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBnORMALvTX, Red, Green, Blue );*/

        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Red   );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Green );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Blue  );    
/*      mdcTableSet( LIBnORMALfCT, Red, Green, Blue );*/

        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Red   );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Green );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Blue  );    

        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Red   );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Green );    
        xs3o88_Read_Line( fd );
        sscanf( xs3o00_Text_Buffer, "%f\n", &Blue  );    

        if (version > 'a') {
            int lft,bot,top,rgt;
            xs3o88_Read_Line( fd );
            sscanf( xs3o00_Text_Buffer, "%d %d %d %d\n", &lft,&bot, &rgt,&top );
#ifdef OLD
            winposition( lft,rgt, bot,top );
#endif
        }

        {    
            char buf[ 80 ];    
            xs3o88_Read_Line( fd );
	    sscanf( xs3o00_Text_Buffer, "%s\n", buf );
            if (strcmp( buf, "." )   !=   UsAMEsTRING) {    
                xlfail("xs3oz0_Save_Config_File");    
            }    
        }    
        break;    
     
    default:    
	xlfail("xs3oz0_Save_Config_File");
    }    
}    
#endif

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
