/* {{{ xlid.c -- lid objects.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Nov08
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 92Nov08 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xlid;
extern LVAL k_currentstate;
extern LVAL k_initializefromfile;
extern LVAL k_initialstate;
extern LVAL k_ourtube;
extern LVAL k_label;
extern LVAL k_get;
extern LVAL k_subtree;
extern LVAL s_currentstate;
extern LVAL s_label;
extern LVAL s_initialstate;
extern LVAL s_subtree;
extern LVAL s_ourtube;
extern LVAL k_subtree;
extern LVAL k_ushift;
extern LVAL k_uscale;
extern LVAL k_vshift;
extern LVAL k_vscale;
extern LVAL k_pointtextureu;
extern LVAL k_pointtexturev;
extern LVAL lv_xflv;
extern LVAL k_getarray;
extern LVAL k_setarray;
extern LVAL k_radians;

extern LVAL s_stdout;
extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();
LVAL  xlid41_Put();

#include <math.h>
#include <string.h>
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cthl.h"
#ifdef MAYBE_NEEDED
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/clgt.h"
#include "../../xg.3d/c/ccmr.h"
#endif
#include "../../xg.3d.fileio/c/cfil.h"
#include "ctub.h"
#include "clid.h"

clid_rec* xlid9c_Find_Immediate_Base();

/* }}} */
/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xlid00_Is_New -- Initialize a new xlid instance.			*/

clid_rec xlid_defaults = {
    C03D_xLID,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */

    ~13,			/* spare_1			*/
    ~13,			/* spare_2			*/

   -314155.0			/* fspare_1			*/
};


LVAL xlid00_Is_New()
/*-
    Initialize a new xlid instance.
-*/
{
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    clid_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xlidp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( clid_rec ) );

    /* Initialize lid record to reasonable default values: */
    r	= (clid_rec*) gobjimmbase( lv );
   *r   = xlid_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    xthl91_SetObjectVariable( lv, s_initialstate, NIL );
    xthl91_SetObjectVariable( lv, s_currentstate, NIL );
    xthl91_SetObjectVariable( lv, s_subtree     , NIL );
    xthl91_SetObjectVariable( lv, s_label       , cvstring("()") );
    xthl91_SetObjectVariable( lv, s_ourtube     , NIL );

    xlid41_Put( lv );

    return lv;
}

/* }}} */
/* {{{ xlid01_Get_A_XLID -- Get arg, must be of class xlid.		*/

LOCAL LVAL xlid01_Get_A_XLID()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XLID has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xlid.  Similarly,          */
    /* nobody but nobody has any business resizing a xlid,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xlidp(m_as_lval) ||
        getgobjimmbytes(m_as_lval) != sizeof(clid_rec)
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xlid03_Show_Msg -- Show the contents of a clid.			*/

LVAL xlid03_Show_Msg()
{
    LVAL lv,fptr;

    /* get self and the file pointer */
    lv   = xlid01_Get_A_XLID();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(lv,fptr);
    xgbj52_Show_Lval_Vector(lv,fptr);

    /* Print the lid record: */
    {   clid_rec * r = xlid9c_Find_Immediate_Base( lv );
	/* Suppose I should write this someday... (buggo) */
    }

    /* return the gobject */
    return lv;
}

/* }}} */
/* {{{ xlid08_Copy_Msg -- Build copy of given CLID.			*/

LVAL xlid09_Copy( m_as_lval )
LVAL		  m_as_lval;
{
    /* Create a new gobject to hold result: */
    clid_rec*mh = xlid9c_Find_Immediate_Base( m_as_lval );
    clid_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xlid,k_new);
    xlpop();
    nh = (clid_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}
LVAL xlid08_Copy_Msg()
{
    LVAL m_as_lval;
    LVAL x_as_lval = xlid01_Get_A_XLID();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xlid09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xlid28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xlid28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {   char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xlid29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xlid01_Get_A_XLID();
    LVAL n_as_lval = xlid01_Get_A_XLID();
    xllastarg();
    return xlid28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xlid40_Get_Msg -- Get keyword properties.                        */

LVAL xlid39_Get( lv_xlid )
LVAL             lv_xlid;
{
    extern LVAL true;/*xlglob.c*/
    clid_rec* r = xlid9c_Find_Immediate_Base( lv_xlid );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL lv_result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if        (key == k_initialstate) {

        lv_result = xthl90_GetObjectVariable( lv_xlid, s_initialstate );

    } else if (key == k_currentstate) {

        lv_result = xthl90_GetObjectVariable( lv_xlid, s_currentstate );

    } else if (key == k_subtree) {

        lv_result = xthl90_GetObjectVariable( lv_xlid, s_subtree );

    } else if (key == k_label) {

        lv_result = xthl90_GetObjectVariable( lv_xlid, s_label );

    } else if (key == k_ourtube) {

        lv_result = xthl90_GetObjectVariable( lv_xlid, s_ourtube );

    } else if (key == k_label) {

        lv_result = xthl90_GetObjectVariable( lv_xlid, s_label );

    } else {

	/* If this isn't a property we know, do a generic get property: */
        lv_result = xthl8a_GetObjectProp( lv_xlid, key, default_val, got_default );
    }
    return lv_result;
}
LVAL xlid40_Get_Msg()
{
    return xlid39_Get( xlid01_Get_A_XLID() );
}

/* }}} */
/* {{{ xlid42_Put_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Put, update XLID_PROPS and xlid94_ProplistNth. */
#define XLID_PROPS (5)

/* A little macro to make this fn a little neater: */
#define XLID_REDO(x) {		\
    x;				\
    rebuild = TRUE;		\
}

LVAL xlid41_Put( lv_xlid )
LVAL             lv_xlid;
{
    clid_rec* r = xlid9c_Find_Immediate_Base( lv_xlid );
    extern LVAL true;/*xlglob.c*/

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xlidz7_Read_Xlid_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_xlid,
		getfile(xlgetfile()),
		xlidz7_Read_Xlid_From_File,NULL
	    );

        } else if (key == k_initialstate) {

	    /* Be nice to to a little validation here at some point: */
	    LVAL lv_thinglist = xlgalist();
	    xthl91_SetObjectVariable( lv_xlid, s_initialstate, lv_thinglist );

        } else if (key == k_currentstate) {

	    /* Be nice to to a little validation here at some point: */
	    LVAL lv_thinglist = xlgalist();
	    xthl91_SetObjectVariable( lv_xlid, s_currentstate, lv_thinglist );

        } else if (key == k_subtree) {

#ifdef HMM
	    /* Subtree isn't used on lids yet: */
            xlerror("Can't set subtree on lide",xlgetarg());
#else
	    /* Yah, be nice to do some validation: */
	    LVAL lv_subtree = xlgetarg();
	    xthl91_SetObjectVariable( lv_xlid, s_subtree, lv_subtree );
#endif

        } else if (key == k_ourtube) {

	    LVAL lv_ourtube = xlgetarg();
	    if (!xlidp(lv_xlid   )) xlerror("Must be of class lid" ,lv_xlid);
	    if (!xtubp(lv_ourtube)) xlerror("Must be of class tube",lv_ourtube);
	    xlida3_Hook_Lid_To_Tube( lv_xlid, lv_ourtube );
	    xthl91_SetObjectVariable( lv_xlid, s_ourtube, lv_ourtube );

        } else if (key == k_label) {

	    LVAL lv_string = xlgastring();
	    xthl91_SetObjectVariable( lv_xlid, s_label, lv_string );

	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_xlid, key, xlgetarg() );
        }
    }

    return lv_xlid;
}
#undef XLID_REDO
LVAL xlid42_Put_Msg()
{   /* Read keyword properties for a menu object. */
    LVAL   lv_xlid = xlid01_Get_A_XLID();
    LVAL   result  = xlid41_Put( lv_xlid );
    return result;
}

/* }}} */
/* {{{ xlid91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xlid90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XLID_PROPS + x03d89_PropListLength( *pPropList ) );
}
LVAL xlid91_ProplistLength_Msg()
{
    return xlid90_ProplistLength( xlid01_Get_A_XLID() );
}

/* }}} */
/* {{{ xlid95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xlid94_ProplistNth( lv_g )
LVAL                     lv_g;
{
    LVAL*pPropList  = x03d73_pPropList( lv_g );
    LVAL lv_n       = xlgafixnum();
    int  n          = getfixnum(lv_n);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    switch (n) {
    case  0: return k_label;
    case  1: return k_initialstate;
    case  2: return k_currentstate;
    case  3: return k_subtree;
    case  4: return k_ourtube;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XLID_PROPS,
	    lv_n,
	    default_val,
	    got_default
	);
    }
}
LVAL xlid95_ProplistNth_Msg()
{
    return xlid94_ProplistNth( xlid01_Get_A_XLID() );
}

/* }}} */
/* {{{ xlid9c_Find_Immediate_Base                                       */

clid_rec* xlid9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    clid_rec*lid = (clid_rec*) gobjimmbase( lv );
    return lid;
}

/* }}} */
/* {{{ xlida3_Hook_Lid_To_Tube	                                        */

xlida3_Hook_Lid_To_Tube( lv_lid, lv_tub )
LVAL                     lv_lid, lv_tub;
{
    extern LVAL k_get;
    extern LVAL k_zcoordinate;
    extern LVAL k_pointrelation;

    /* Here we copy the pointset in lv_tub into lv_lid, */
    /* ideally ensuring our_lid fits exactly onto tube: */



    /* Locate point-relations for lid and tube: */

    LVAL lv_tub_thing = xsendmsg1( lv_tub, k_get, k_currentstate );
    LVAL lv_tub_grl   = xthl74_GetProp( &lv_tub_thing, k_pointrelation, NIL,0);

    LVAL lv_lid_thing = xsendmsg1( lv_lid, k_get, k_currentstate );
    LVAL lv_lid_grl   = xthl74_GetProp( &lv_lid_thing, k_pointrelation, NIL,0);



    /* Figure sizes of lid and tube relations:  */
    csry_rec* tub_h = (csry_rec*) gobjimmbase( lv_tub_grl );
    csry_rec* lid_h = (csry_rec*) gobjimmbase( lv_lid_grl );
    /* Figure array sizes, respecting fillpointers: */
    int       tub_l = (tub_h->rank==1 && tub_h->dim[1] >= 0) ? tub_h->dim[1] : tub_h->size;
    int       lid_l = (lid_h->rank==1 && lid_h->dim[1] >= 0) ? lid_h->dim[1] : lid_h->size;



    /* Locate pointarrays for lid and tube: */

    LVAL lv_tub_x;    float*  tub_x;
    LVAL lv_tub_y;    float*  tub_y;
    LVAL lv_tub_z;    float*  tub_z;

    LVAL lv_lid_x;    float*  lid_x;
    LVAL lv_lid_y;    float*  lid_y;
    LVAL lv_lid_z;    float*  lid_z;



    /* Locate z-coord for lid: */
    LVAL lv_zcoord = xsendmsg1( lv_lid, k_get, k_zcoordinate );
    float   zcoord = getflonum( lv_zcoord );

    int  tub_frst;
    int  tub_last;

    xthlH0_Check_A_Point_GRL(
        &lv_tub_x,
	&lv_tub_y,
	&lv_tub_z,
	lv_tub_grl
    );
    tub_x     = (float*) (csry_base( lv_tub_x ));
    tub_y     = (float*) (csry_base( lv_tub_y ));
    tub_z     = (float*) (csry_base( lv_tub_z ));

    xthlH0_Check_A_Point_GRL(
        &lv_lid_x,
	&lv_lid_y,
	&lv_lid_z,
	lv_lid_grl
    );
    lid_x     = (float*) (csry_base( lv_lid_x ));
    lid_y     = (float*) (csry_base( lv_lid_y ));
    lid_z     = (float*) (csry_base( lv_lid_z ));



    /* Locate points in tube with our zcoord: */
    for (tub_frst = 0       ;   tub_frst < tub_l;   ++tub_frst) {
	if (tub_z[ tub_frst ] == zcoord)   break;
    }
    for (tub_last = tub_frst;   tub_last < tub_l;   ++tub_last) {
	if (tub_z[ tub_last ] != zcoord)   break;
    }




    /* Copy tube points into lid:   */
    {   int   i;
	float x = 0.0;
	float y = 0.0;
	float z = 0.0;
	for  (i = 0;   i < lid_l;   ++i) {
	    int j = tub_frst + i;
	    if (j < tub_last) {
		x    = tub_x[j];
		y    = tub_y[j];
		z    = tub_z[j];
	    }
	    lid_x[i] = x;
	    lid_y[i] = y;
	    lid_z[i] = z;
	}
    }

    if (tub_last - tub_frst != lid_l) {
        LVAL lv_name = xthl90_GetObjectVariable( lv_lid, s_label );

	char*                  name;
	if (stringp(lv_name))  name = (char*) getstring(lv_name);
	else                   name = "(nameless)"; /* Shouldn't happen. */

	fprintf(stderr,
	    "Found lid '%s' with len (%d) != tube len (%d), faking it.\n",
	    name, lid_l, tub_last - tub_frst
	);
    }
}

/* }}} */
/* {{{ xlidb9_Compute_Texture_Coords					*/

void
xlidb8_Compute_Texture_Coordinates(
    LVAL  lv_xlid,
    float u_shift, float u_scale,
    float v_shift, float v_scale
) {
    LVAL lv_thing    = xsendmsg1( lv_xlid, k_get, k_initialstate );
    LVAL lv_pointGrl = xthlA2_Get_Point_Relation_From_Thing( lv_thing );
    LVAL lv_facetGrl = xthlA4_Get_Facet_Relation_From_Thing( lv_thing );
    gt_tri_rec r;

    /* Unpack our standard geometry information: */
    xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
    xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_pointGrl );
    xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_facetGrl );

    /* If we don't have point texture arrays, create them: */
    if (!r.got_point_textures) {
	xsendmsg2( lv_pointGrl, k_setarray, k_pointtextureu, lv_xflv );
	xsendmsg2( lv_pointGrl, k_setarray, k_pointtexturev, lv_xflv );

	xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
	xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_pointGrl );
	xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_facetGrl );
if (!r.got_point_textures) {
fprintf(stderr,"xlidb8_Compute_Texture_Coordinates: WAHH!");
abort();
}
    }


    /* Over all contours in tube: */
    {   float x_span;
	float y_span;

	float x_span_inv = 1.0;
	float y_span_inv = 1.0;

	/* Find x/y min/max in lid: */
	float x_min = r.x[0];
	float x_max = r.x[0];
	float y_min = r.y[0];
	float y_max = r.y[0];
	int   y_most;
	int   i;
	int   pt;
	for (pt = 0;  pt < r.pLen;   ++pt) {
	    float x = r.x[ pt ];
	    float y = r.y[ pt ];
	    if (x < x_min)    x_min = x;
	    if (x > x_max)    x_max = x;
	    if (y < y_min)    y_min = y;
	    if (y > y_max)    y_max = y;
	}



	/* Assign texture coords to each point: */

	x_span = x_max - x_min;
	y_span = y_max - y_min;

	if (x_span != 0.0)   x_span_inv = 1.0 / x_span;
	if (y_span != 0.0)   y_span_inv = 1.0 / y_span;

	for (pt = 0;  pt < r.pLen;   ++pt) {

	    /* Get x/y: */
	    float x = r.x[ pt ];
	    float y = r.y[ pt ];

	    /* Figure reasonable default that */
	    /* fits everything in 0-1:        */
	    float u = (x - x_min) * x_span_inv;
	    float v = (y - y_min) * y_span_inv;

	    /* Apply user shift/scale to above: */
	    u = u * u_scale + u_shift;
	    v = v * v_scale + v_shift;

	    /* Store: */
	    r.ptu[ pt ] = u;
	    r.ptv[ pt ] = v;
	}
    }
}

LVAL
xlidb9_Compute_Texture_Coordinates_Msg() {

    /* Get recipient of message: */
    LVAL   lv_xlid = xlid01_Get_A_XLID();
    float  u_shift = 0.0;    float  u_scale = 1.0;
    float  v_shift = 0.0;    float  v_scale = 1.0;

    /* Parse any arguments.  Syntax is:                      	*/
    /* (send xlid :compute-texture-coords [ :radians angle ]	*/
    /* Where :RADIANS rotates the inserted texture map around	*/
    /* the contour.						*/

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_ushift) {

	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    u_shift = tmp;

        } else if (key == k_uscale) {

	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp != 0.0) u_scale = tmp;

        } else if (key == k_vshift) {

	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    v_shift = tmp;

        } else if (key == k_vscale) {

	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp != 0.0) v_scale = tmp;

	} else {
	    xlerror("Bad :COMPUTE-TEXTURE-COORDINATES keyword",key);
        }
    }

    xlidb8_Compute_Texture_Coordinates(
	lv_xlid,
	u_shift, u_scale,
	v_shift, v_scale
    );

    return NIL;
}

/* }}} */
/* {{{ xlidz7_Read_Xlid_From_File                                       */

xlidz7_Read_Xlid_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   clid_rec* h;
    char*     p;
    if (version != CLID_REC_VERSION) {
	xlerror("xlidz7: unsupported version",cvfixnum(version));
    }
    h = (clid_rec*) gobjimmbase( lv );

    p = (char*) &h->CLID_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CLID_INT32_COUNT,  magic, fp );

    p = (char*) &h->CLID_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CLID_FLOAT_COUNT,  magic, fp );

#ifdef NOT_CURRENTLY_NEEDED
    p = (char*) &h->CLID_FIRST_BYTE;
    p = cfil52_Read_Bytes_From_File(   p, CLID_BYTE_COUNT ,  magic, fp );
#endif
}

/* }}} */
/* {{{ xlidwo_Write_Xlid_To_Graphics_File                               */

xlidwo_Write_Xlid_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   clid_rec* h = (clid_rec*) gobjimmbase( lv );
	char*     p;

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CLID_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CLID_FIRST_INT32, CLID_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CLID_FIRST_FLOAT, CLID_FLOAT_COUNT, fdob);
#ifdef NOT_CURRENTLY_NEEDED
	cfil45_Write_Bytes_To_File( &h->CLID_FIRST_BYTE , CLID_BYTE_COUNT , fdob);
#endif
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
