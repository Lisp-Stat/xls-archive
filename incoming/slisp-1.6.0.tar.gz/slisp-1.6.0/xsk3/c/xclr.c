/* {{{ xclr.c -- color filter objects.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Nov08
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Nov08 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xclr;

extern LVAL k_currentstate;
extern LVAL k_get;
extern LVAL k_initializefromfile;
extern LVAL k_initialstate;
extern LVAL k_label;
extern LVAL k_subtree;
extern LVAL lv_xmtl;
extern LVAL s_currentstate;
extern LVAL s_initialstate;
extern LVAL s_strcat;
extern LVAL s_subtree;

extern LVAL s_stdout;
extern LVAL xsendmsg0();
extern LVAL xsendmsg0();
LVAL  xclr41_Put();

#include <math.h>
#include <string.h>
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cthl.h"
#ifdef MAYBE_NEEDED
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/clgt.h"
#include "../../xg.3d/c/ccmr.h"
#endif
#include "../../xg.3d.fileio/c/cfil.h"
#include "cclr.h"

cclr_rec* xclr9c_Find_Immediate_Base();

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xclr00_Is_New -- Initialize a new xclr instance.			*/

cclr_rec xclr_defaults = {
    C03D_xCLR,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */

    ~13,			/* spare_1			*/
    ~13,			/* spare_2			*/
    1,				/* tint				*/
    0,				/* normals			*/
    1,				/* backfaces			*/
    1,				/* ok_to_animate		*/

   -314155.0,			/* fspare_1			*/
    1.0				/* opacity			*/
};


LVAL xclr00_Is_New()
/*-
    Initialize a new xclr instance.
-*/
{
    extern LVAL xgbj11_Set_Size_In_Bytes();
    cclr_rec* r;

    int       toProt = 3;
    LVAL      lv;
    LVAL      lv_initialstate;
    LVAL      lv_currentstate;

    xlstkcheck(toProt);
    xlsave(lv);
    xlsave(lv_initialstate);
    xlsave(lv_currentstate);

    lv    = xlgagobject();

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xclrp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( cclr_rec ) );

    /* Initialize menu record to reasonable default values: */
    r	= (cclr_rec*) gobjimmbase( lv );
   *r   = xclr_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    xthl91_SetObjectVariable( lv, s_subtree     , NIL );

    xclr41_Put( lv );

    lv_initialstate = xsendmsg0(lv_xmtl,k_new);
    lv_currentstate = xsendmsg0(lv_xmtl,k_new);

    xthl91_SetObjectVariable( lv, s_initialstate, lv_initialstate );
    xthl91_SetObjectVariable( lv, s_currentstate, lv_currentstate );

    xlpopn(toProt);
    return lv;
}

/* }}} */
/* {{{ xclr01_Get_A_XCLR -- Get arg, must be of class xclr.		*/

LOCAL LVAL xclr01_Get_A_XCLR()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XCLR has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xclr.  Similarly,          */
    /* nobody but nobody has any business resizing a xclr,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xclrp(m_as_lval) ||
        getgobjimmbytes(m_as_lval) != sizeof(cclr_rec)
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xclr03_Show_Msg -- Show the contents of a cclr.			*/

LVAL xclr03_Show_Msg()
{
    LVAL lv,fptr;

    /* get self and the file pointer */
    lv   = xclr01_Get_A_XCLR();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(lv,fptr);
    xgbj52_Show_Lval_Vector(lv,fptr);

    /* Print the clr record: */
    {   cclr_rec * r = xclr9c_Find_Immediate_Base( lv );
	/* Suppose I should write this someday... (buggo) */
    }

    /* return the gobject */
    return lv;
}

/* }}} */
/* {{{ xclr08_Copy_Msg -- Build copy of given CCLR.			*/

LVAL xclr09_Copy( m_as_lval )
LVAL		  m_as_lval;
{
    /* Create a new gobject to hold result: */
    cclr_rec*mh = xclr9c_Find_Immediate_Base( m_as_lval );
    cclr_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xclr,k_new);
    xlpop();
    nh = (cclr_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}
LVAL xclr08_Copy_Msg()
{
    LVAL m_as_lval;
    LVAL x_as_lval = xclr01_Get_A_XCLR();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xclr09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xclr28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT
LVAL xclr28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {   char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xclr29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xclr01_Get_A_XCLR();
    LVAL n_as_lval = xclr01_Get_A_XCLR();
    xllastarg();
    return xclr28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xclr40_Get_Msg -- Get keyword properties.                        */

LVAL xclr39_Get( lv_xclr )
LVAL             lv_xclr;
{
    extern LVAL true;/*xlglob.c*/
    cclr_rec* r = xclr9c_Find_Immediate_Base( lv_xclr );
    LVAL lv_key = xlgasymbol();
    LVAL lv_result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if        (lv_key == k_initialstate) {

        lv_result = xthl90_GetObjectVariable( lv_xclr, s_initialstate );

    } else if (lv_key == k_currentstate) {

        lv_result = xthl90_GetObjectVariable( lv_xclr, s_currentstate );

    } else if (lv_key == k_subtree) {

        lv_result = xthl90_GetObjectVariable( lv_xclr, s_subtree );

    } else if (lv_key == k_label) {

        LVAL xcallfn2(), xsendmsg1();
        LVAL lv_prefix = cvstring( "C:" );
        xlprot1(lv_prefix);
        lv_result = xcallfn2(
            s_strcat, 
            lv_prefix,
            xsendmsg1(
                xthl90_GetObjectVariable( lv_xclr, s_subtree ),
                k_get,
                k_label
            )
        );
        xlpop();

    } else {

	/* If this isn't a property we know, do a generic get property: */
        lv_result = xthl8a_GetObjectProp( lv_xclr, lv_key, default_val,got_default);
    }
    return lv_result;
}
LVAL xclr40_Get_Msg()
{
    return xclr39_Get( xclr01_Get_A_XCLR() );
}

/* }}} */
/* {{{ xclr42_Put_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Put, update XCLR_PROPS and xclr94_ProplistNth. */
#define XCLR_PROPS (4)

/* A little macro to make this fn a little neater: */
#define XCLR_REDO(x) {		\
    x;				\
    rebuild = TRUE;		\
}

LVAL xclr41_Put( lv_xclr )
LVAL             lv_xclr;
{
    cclr_rec* r = xclr9c_Find_Immediate_Base( lv_xclr );
    extern LVAL true;/*xlglob.c*/

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xclrz7_Read_Xclr_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_xclr,
		getfile(xlgetfile()),
		xclrz7_Read_Xclr_From_File,NULL
	    );

        } else if (key == k_initialstate) {

	    /* Our state is always an instance of class-material: */
	    LVAL 	  xmtl01_Get_A_XMTL();
	    LVAL lv_mtl = xmtl01_Get_A_XMTL();
	    xthl91_SetObjectVariable( lv_xclr, s_initialstate, lv_mtl );

        } else if (key == k_currentstate) {

	    /* Our state is always an instance of class-material: */
	    LVAL 	  xmtl01_Get_A_XMTL();
	    LVAL lv_mtl = xmtl01_Get_A_XMTL();
	    xthl91_SetObjectVariable( lv_xclr, s_currentstate, lv_mtl );

        } else if (key == k_subtree) {

	    /* Yah, be nice to do some validation: */
	    LVAL lv_subtree = xlgetarg();
	    xthl91_SetObjectVariable( lv_xclr, s_subtree, lv_subtree );

        } else if (key == k_label) {

            xlerror("Can't set color label",xlgastring());

	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_xclr, key, xlgetarg() );
        }
    }

    return lv_xclr;
}
#undef XCLR_REDO
LVAL xclr42_Put_Msg()
{   /* Read keyword properties for a menu object. */
    LVAL   lv_xclr = xclr01_Get_A_XCLR();
    LVAL   result  = xclr41_Put( lv_xclr );
    return result;
}

/* }}} */
/* {{{ xclr91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xclr90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XCLR_PROPS + x03d89_PropListLength( *pPropList ) );
}
LVAL xclr91_ProplistLength_Msg()
{
    return xclr90_ProplistLength( xclr01_Get_A_XCLR() );
}

/* }}} */
/* {{{ xclr95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xclr94_ProplistNth( lv_g )
LVAL                     lv_g;
{
    LVAL*pPropList  = x03d73_pPropList( lv_g );
    LVAL lv_n       = xlgafixnum();
    int  n          = getfixnum(lv_n);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    switch (n) {
    case  0: return k_label;
    case  1: return k_initialstate;
    case  2: return k_currentstate;
    case  3: return k_subtree;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XCLR_PROPS,
	    lv_n,
	    default_val,
	    got_default
	);
    }
}
LVAL xclr95_ProplistNth_Msg()
{
    return xclr94_ProplistNth( xclr01_Get_A_XCLR() );
}

/* }}} */
/* {{{ xclr9c_Find_Immediate_Base                                       */

cclr_rec* xclr9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    cclr_rec*clr = (cclr_rec*) gobjimmbase( lv );
    return clr;
}

/* }}} */
/* {{{ xclrz7_Read_Xclr_From_File                                       */

xclrz7_Read_Xclr_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   cclr_rec* h;
    char*     p;
    if (version != CCLR_REC_VERSION) {
	xlerror("xclrz7: unsupported version",cvfixnum(version));
    }
    h = (cclr_rec*) gobjimmbase( lv );

    p = (char*) &h->CCLR_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CCLR_INT32_COUNT,  magic, fp );

    p = (char*) &h->CCLR_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CCLR_FLOAT_COUNT,  magic, fp );

#ifdef NOT_NEEDED_CURRENTLY
    p = (char*) &h->CCLR_FIRST_BYTE;
    p = cfil52_Read_Bytes_From_File(   p, CCLR_BYTE_COUNT ,  magic, fp );
#endif
}

/* }}} */
/* {{{ xclrwo_Write_Xclr_To_Graphics_File                               */

xclrwo_Write_Xclr_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   cclr_rec* h = (cclr_rec*) gobjimmbase( lv );
	char*     p;

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CCLR_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CCLR_FIRST_INT32, CCLR_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CCLR_FIRST_FLOAT, CCLR_FLOAT_COUNT, fdob);
#ifdef NOT_NEEDED_CURRENTLY
	cfil45_Write_Bytes_To_File( &h->CCLR_FIRST_BYTE , CCLR_BYTE_COUNT , fdob);
#endif
    }
}
/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
