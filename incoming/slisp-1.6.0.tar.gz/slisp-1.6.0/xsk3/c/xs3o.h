/* {{{ xs3o.h -- Skandha3 file Output.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      93Apr21
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1994, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS

extern LVAL xs3o90_Save_Skandha3_File_Fn();

#ifndef EXTERNED_LIGHTIS
extern LVAL k_lightis; /* Keyword ":light-is" */
#define EXTERNED_LIGHTIS
#endif

#ifndef EXTERNED_ADDITIONAL
extern LVAL k_additional; /* Keyword ":additional" */
#define EXTERNED_ADDITIONAL
#endif

#ifndef EXTERNED_REPLACEMENT
extern LVAL k_replacement; /* Keyword ":replacement" */
#define EXTERNED_REPLACEMENT
#endif

#ifndef EXTERNED_ZCOORDINATE
extern LVAL k_zcoordinate; /* Keyword ":z-coordinate" */
#define EXTERNED_ZCOORDINATE
#endif

#ifndef EXTERNED_SAVEAS
extern LVAL k_saveas;/* Keyword ":save-as" */
#define EXTERNED_SAVEAS
#endif

#ifndef EXTERNED_BINARY
extern LVAL k_binary;/* Keyword ":binary" */
#define EXTERNED_BINARY
#endif

#ifndef EXTERNED_TEXT
extern LVAL k_text;/* Keyword ":text" */
#define EXTERNED_TEXT
#endif

#ifndef EXTERNED_SET
extern LVAL k_set;/* Keyword ":set" */
#define EXTERNED_SET
#endif

#ifndef EXTERNED_GETARRAY
extern LVAL k_getarray;/* Keyword ":GET-ARRAY" */
#define EXTERNED_GETARRAY
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	"XSK3-SAVE-SKANDHA3-FILE",	xs3o90_Save_Skandha3_File_Fn	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS

#ifndef DEFINED_LIGHTIS
LVAL k_lightis; /* Keyword ":LIGHT-IS" */
#define DEFINED_LIGHTIS
#endif

#ifndef DEFINED_ADDITIONAL
LVAL k_additional; /* Keyword ":ADDITIONAL" */
#define DEFINED_ADDITIONAL
#endif

#ifndef DEFINED_REPLACMENT
LVAL k_replacement; /* Keyword ":REPLACEMENT" */
#define DEFINED_REPLACEMENT
#endif

#ifndef DEFINED_SAVEAS
LVAL k_saveas;/* Keyword ":SAVE-AS" */
#define DEFINED_SAVEAS
#endif

#ifndef DEFINED_BINARY
LVAL k_binary;/* Keyword ":BINARY" */
#define DEFINED_BINARY
#endif

#ifndef DEFINED_TEXT
LVAL k_text;/* Keyword ":TEXT" */
#define DEFINED_TEXT
#endif

#ifndef DEFINED_SET
LVAL k_set;/* Keyword ":SET" */
#define DEFINED_SET
#endif

#ifndef DEFINED_GETARRAY
LVAL k_getarray;/* Keyword ":GET-ARRAY" */
#define DEFINED_GETARRAY
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_LIGHTIS
    k_lightis = xlenter(":LIGHT-IS");
#define CREATED_LIGHTIS
#endif

#ifndef CREATED_ADDITIONAL
    k_additional = xlenter(":ADDITIONAL");
#define CREATED_ADDITIONAL
#endif

#ifndef CREATED_REPLACEMENT
    k_replacement = xlenter(":REPLACEMENT");
#define CREATED_REPLACEMENT
#endif

#ifndef CREATED_SAVEAS
    k_saveas = xlenter(":SAVE-AS");
#define CREATED_SAVEAS
#endif

#ifndef CREATED_BINARY
    k_binary = xlenter(":BINARY");
#define CREATED_BINARY
#endif

#ifndef CREATED_TEXT
    k_text = xlenter(":TEXT");
#define CREATED_TEXT
#endif

#ifndef CREATED_SET
    k_set = xlenter(":SET");
#define CREATED_SET
#endif

#ifndef CREATED_GETARRAY
    k_getarray = xlenter(":GET-ARRAY");
#define CREATED_GETARRAY
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
