/* {{{ clit.h -- xlit.c light objects.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Nov09
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
********************************************************************************
*/

/* }}} */
/* {{{ --- header stuff ---						*/

#ifndef INCLUDED_CLIT_H
#define INCLUDED_CLIT_H

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/geo.h"

/* }}} */

#define CLIT_REC_VERSION (28)

#define CLIT_MAX_LABEL   (64)

/* A struct type that holds everything we need to know about a lite.    */
/* WARNING:  xlit.c depends on the below order to initialize correctly. */
/* See xlit00_Is_New.     						*/ 
struct clit_struct {
    int           k_class; /* k_class should always be first in record. */
    c03d_fileInfo fileInfo;/* Always 2nd in record.  Save-file.         */

#define CLIT_FIRST_INT32 Default
#define CLIT_INT32_COUNT 6
    int           Default;
    int           fixed;
    int           okToAnimate;
    int           light_is;

    int		  spare_1;
    int		  spare_2;

#define CLIT_FIRST_FLOAT fspare_1
#define CLIT_FLOAT_COUNT 6
    float         sunAltitude;
    float         sunAzimuth;
    float         sun[3];

    float	fspare_1;

#define CLIT_FIRST_BYTE  label[0]
#define CLIT_BYTE_COUNT  (0 * CLIT_MAX_LABEL)
};
typedef struct clit_struct  clit_rec;

clit_rec* xlit9c_Find_Immediate_Base();

#define xlitp(o) (gobjectp(o) && ((((clit_rec*)(gobjimmbase(o)))->k_class) == C03D_xLIT))

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
#endif
/* }}} */
