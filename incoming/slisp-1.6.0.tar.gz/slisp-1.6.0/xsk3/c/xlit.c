/* {{{ xlit.c -- lit (light) objects.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Nov08
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Nov08 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL k_lightis;
extern LVAL s_lightis;
extern LVAL k_additional;
extern LVAL k_replacement;
extern LVAL lv_xlit;
extern LVAL k_currentstate;
extern LVAL k_get;
extern LVAL k_initializefromfile;
extern LVAL k_initialstate;
extern LVAL k_label;
extern LVAL k_subtree;
extern LVAL lv_xlgt;
extern LVAL s_currentstate;
extern LVAL s_initialstate;
extern LVAL s_strcat;
extern LVAL s_subtree;

extern LVAL s_stdout;
extern LVAL xsendmsg0();
extern LVAL xsendmsg0();
LVAL  xlit41_Put();

#include <math.h>
#include <string.h>
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cthl.h"
#ifdef MAYBE_NEEDED
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/clgt.h"
#include "../../xg.3d/c/ccmr.h"
#endif
#include "../../xg.3d.fileio/c/cfil.h"
#include "clit.h"

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xlit00_Is_New -- Initialize a new xlit instance.			*/

clit_rec xlit_defaults = {
    C03D_xLIT,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */


    TRUE,			/* Default			*/
    TRUE,			/* fixed			*/
    TRUE,			/* okToAnimate			*/
    1,				/* light_is			*/
    ~13,			/* spare_1			*/
    ~13,			/* spare_2			*/

    90.0,			/* sunAltitude			*/
    0.0,			/* sunAzimuth			*/
    { 0.0, 0.0, 1.0 },		/* sun[3];			*/

   -314155.0			/* fspare_1			*/
};


LVAL xlit00_Is_New()
/*-
    Initialize a new xlit instance.
-*/
{
    extern LVAL xgbj11_Set_Size_In_Bytes();
    clit_rec* r;

    int       toProt = 3;
    LVAL      lv;
    LVAL      lv_initialLgt;
    LVAL      lv_currentLgt;

    xlstkcheck(toProt);
    xlsave(lv);
    xlsave(lv_initialLgt);
    xlsave(lv_currentLgt);

    lv  = xlgagobject();

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xlitp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( clit_rec ) );

    /* Initialize menu record to reasonable default values: */
    r	= (clit_rec*) gobjimmbase( lv );
   *r   = xlit_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    xthl91_SetObjectVariable( lv, s_initialstate, NIL );
    xthl91_SetObjectVariable( lv, s_currentstate, NIL );
    xthl91_SetObjectVariable( lv, s_subtree     , NIL );

    xlit41_Put( lv );

    lv_initialLgt = xsendmsg0(lv_xlgt,k_new);
    lv_currentLgt = xsendmsg0(lv_xlgt,k_new);

    xthl91_SetObjectVariable( lv, s_initialstate, lv_initialLgt );
    xthl91_SetObjectVariable( lv, s_currentstate, lv_currentLgt );

    xlpopn(toProt);
    return lv;
}

/* }}} */
/* {{{ xlit01_Get_A_XLIT -- Get arg, must be of class xlit.		*/

LOCAL LVAL xlit01_Get_A_XLIT()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XLIT has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xlit.  Similarly,          */
    /* nobody but nobody has any business resizing a xlit,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xlitp(m_as_lval) ||
        getgobjimmbytes(m_as_lval) != sizeof(clit_rec)
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xlit03_Show_Msg -- Show the contents of a clit.			*/

LVAL xlit03_Show_Msg()
{
    LVAL lv,fptr;

    /* get self and the file pointer */
    lv   = xlit01_Get_A_XLIT();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(lv,fptr);
    xgbj52_Show_Lval_Vector(lv,fptr);

    /* Print the lit record: */
    {   clit_rec * r = xlit9c_Find_Immediate_Base( lv );
	/* Suppose I should write this someday... (buggo) */
    }

    /* return the gobject */
    return lv;
}

/* }}} */
/* {{{ xlit08_Copy_Msg -- Build copy of given CLIT.			*/

LVAL xlit09_Copy( m_as_lval )
LVAL		  m_as_lval;
{
    /* Create a new gobject to hold result: */
    clit_rec*mh = xlit9c_Find_Immediate_Base( m_as_lval );
    clit_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xlit,k_new);
    xlpop();
    nh = (clit_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}
LVAL xlit08_Copy_Msg()
{
    LVAL m_as_lval;
    LVAL x_as_lval = xlit01_Get_A_XLIT();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xlit09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xlit28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xlit28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {   char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xlit29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xlit01_Get_A_XLIT();
    LVAL n_as_lval = xlit01_Get_A_XLIT();
    xllastarg();
    return xlit28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xlit40_Get_Msg -- Get keyword properties.                        */

LVAL xlit39_Get( lv_xlit )
LVAL             lv_xlit;
{
    extern LVAL true;/*xlglob.c*/
    clit_rec* r = xlit9c_Find_Immediate_Base( lv_xlit );
    LVAL lv_key = xlgasymbol();
    LVAL lv_result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if        (lv_key == k_initialstate) {

        lv_result = xthl90_GetObjectVariable( lv_xlit, s_initialstate );

    } else if (lv_key == k_currentstate) {

        lv_result = xthl90_GetObjectVariable( lv_xlit, s_currentstate );

    } else if (lv_key == k_subtree) {

        lv_result = xthl90_GetObjectVariable( lv_xlit, s_subtree );

    } else if (lv_key == k_lightis) {

        lv_result = xthl90_GetObjectVariable( lv_xlit, s_lightis );

    } else if (lv_key == k_label) {

        LVAL xcallfn2(), xsendmsg1();
        LVAL lv_prefix = cvstring( "L:" );
        xlprot1(lv_prefix);
        lv_result = xcallfn2(
            s_strcat, 
            lv_prefix,
            xsendmsg1(
                xthl90_GetObjectVariable( lv_xlit, s_subtree ),
                k_get,
                k_label
            )
        );
        xlpop();

    } else {

	/* If this isn't a property we know, do a generic get property: */
        lv_result = xthl8a_GetObjectProp( lv_xlit, lv_key, default_val,got_default);
    }
    return lv_result;
}
LVAL xlit40_Get_Msg()
{
    return xlit39_Get( xlit01_Get_A_XLIT() );
}

/* }}} */
/* {{{ xlit42_Put_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Put, update XLIT_PROPS and xlit94_ProplistNth. */
#define XLIT_PROPS (5)

/* A little macro to make this fn a little neater: */
#define XLIT_REDO(x) {		\
    x;				\
    rebuild = TRUE;		\
}

LVAL xlit41_Put( lv_xlit )
LVAL             lv_xlit;
{
    clit_rec* r = xlit9c_Find_Immediate_Base( lv_xlit );
    extern LVAL true;/*xlglob.c*/

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xlitz7_Read_Xlit_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_xlit,
		getfile(xlgetfile()),
		xlitz7_Read_Xlit_From_File,NULL
	    );

        } else if (key == k_initialstate) {

	    /* Our state is always an instance of class-light: */
	    LVAL 	  xlgt01_Get_A_XLGT();
	    LVAL lv_lgt = xlgt01_Get_A_XLGT();
	    xthl91_SetObjectVariable( lv_xlit, s_initialstate, lv_lgt );

        } else if (key == k_currentstate) {

	    /* Our state is always an instance of class-light: */
	    LVAL 	  xlgt01_Get_A_XLGT();
	    LVAL lv_lgt = xlgt01_Get_A_XLGT();
	    xthl91_SetObjectVariable( lv_xlit, s_currentstate, lv_lgt );

        } else if (key == k_subtree) {

	    /* Yah, be nice to do some validation: */
	    xthl91_SetObjectVariable( lv_xlit, s_subtree, xlgetarg() );

        } else if (key == k_lightis) {

	    /* Yah, be nice to do some validation: */
	    xthl91_SetObjectVariable( lv_xlit, s_lightis, xlgetarg() );

        } else if (key == k_label) {

            xlerror("Can't set light label",xlgastring());

	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_xlit, key, xlgetarg() );
        }
    }

    return lv_xlit;
}
#undef XLIT_REDO
LVAL xlit42_Put_Msg()
{   /* Read keyword properties for a menu object. */
    LVAL   lv_xlit = xlit01_Get_A_XLIT();
    LVAL   result  = xlit41_Put( lv_xlit );
    return result;
}

/* }}} */
/* {{{ xlit91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xlit90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XLIT_PROPS + x03d89_PropListLength( *pPropList ) );
}
LVAL xlit91_ProplistLength_Msg()
{
    return xlit90_ProplistLength( xlit01_Get_A_XLIT() );
}

/* }}} */
/* {{{ xlit95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xlit94_ProplistNth( lv_g )
LVAL                     lv_g;
{
    LVAL*pPropList  = x03d73_pPropList( lv_g );
    LVAL lv_n       = xlgafixnum();
    int  n          = getfixnum(lv_n);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    switch (n) {
    case  0: return k_label;
    case  1: return k_initialstate;
    case  2: return k_currentstate;
    case  3: return k_subtree;
    case  4: return k_lightis;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XLIT_PROPS,
	    lv_n,
	    default_val,
	    got_default
	);
    }
}
LVAL xlit95_ProplistNth_Msg()
{
    return xlit94_ProplistNth( xlit01_Get_A_XLIT() );
}

/* }}} */
/* {{{ xlit9c_Find_Immediate_Base                                       */

clit_rec* xlit9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    clit_rec*lit = (clit_rec*) gobjimmbase( lv );
    return lit;
}

/* }}} */
/* {{{ xlitz7_Read_Xlit_From_File                                       */

xlitz7_Read_Xlit_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   clit_rec* h;
    char*     p;
    if (version != CLIT_REC_VERSION) {
	xlerror("xlitz7: unsupported version",cvfixnum(version));
    }
    h = (clit_rec*) gobjimmbase( lv );

    p = (char*) &h->CLIT_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CLIT_INT32_COUNT,  magic, fp );

    p = (char*) &h->CLIT_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CLIT_FLOAT_COUNT,  magic, fp );

#ifdef NOT_NEEDED_CURRENTLY
    p = (char*) &h->CLIT_FIRST_BYTE;
    p = cfil52_Read_Bytes_From_File(   p, CLIT_BYTE_COUNT ,  magic, fp );
#endif
}

/* }}} */
/* {{{ xlitwo_Write_Xlit_To_Graphics_File                               */

xlitwo_Write_Xlit_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   clit_rec* h = (clit_rec*) gobjimmbase( lv );
	char*     p;

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CLIT_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CLIT_FIRST_INT32, CLIT_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CLIT_FIRST_FLOAT, CLIT_FLOAT_COUNT, fdob);
#ifdef NOT_NEEDED_CURRENTLY
	cfil45_Write_Bytes_To_File( &h->CLIT_FIRST_BYTE , CLIT_BYTE_COUNT , fdob);
#endif
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
