/* {{{ xpol.h -- Polygon operations.				     CrT*/
/************************************************************************
*
* Author:       Jeff Prothero
* Created:      96Jul19
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1997, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
extern LVAL xpolG2_Compute_Facet_Normals_Fn();

#ifndef EXTERNED_THING
extern LVAL k_thing;   /* Keyword ":THING" */
#define EXTERNED_THING
#endif

#ifndef EXTERNED_MINX
extern LVAL k_minx;   /* Keyword ":MIN-X" */
#define EXTERNED_MINX
#endif

#ifndef EXTERNED_MAXX
extern LVAL k_maxx;   /* Keyword ":MAX-X" */
#define EXTERNED_MAXX
#endif

#ifndef EXTERNED_MINY
extern LVAL k_miny;   /* Keyword ":MIN-Y" */
#define EXTERNED_MINY
#endif

#ifndef EXTERNED_MAXY
extern LVAL k_maxy;   /* Keyword ":MAX-Y" */
#define EXTERNED_MAXY
#endif

#ifndef EXTERNED_MINZ
extern LVAL k_minz;   /* Keyword ":MIN-Z" */
#define EXTERNED_MINZ
#endif

#ifndef EXTERNED_MAXZ
extern LVAL k_maxz;   /* Keyword ":MAX-Z" */
#define EXTERNED_MAXZ
#endif

#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR( "XPOL-COMPUTE-FACET-NORMALS", xpolG2_Compute_Facet_Normals_Fn )
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS


#ifndef DEFINED_THING
LVAL k_thing;   /* Keyword ":thing" */
#define DEFINED_THING
#endif

#ifndef DEFINED_MINX
LVAL k_minx;   /* Keyword ":min-x" */
#define DEFINED_MINX
#endif

#ifndef DEFINED_MAXX
LVAL k_maxx;   /* Keyword ":max-x" */
#define DEFINED_MAXX
#endif

#ifndef DEFINED_MINY
LVAL k_miny;   /* Keyword ":min-y" */
#define DEFINED_MINY
#endif

#ifndef DEFINED_MAXY
LVAL k_maxy;   /* Keyword ":max-y" */
#define DEFINED_MAXY
#endif

#ifndef DEFINED_MINZ
LVAL k_minz;   /* Keyword ":min-z" */
#define DEFINED_MINZ
#endif

#ifndef DEFINED_MAXZ
LVAL k_maxz;   /* Keyword ":max-z" */
#define DEFINED_MAXZ
#endif


#ifdef MAYBE_SOMETIME
LOCAL struct xpol_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xpol_xgrl_table[] = {
    {	":COMPUTE-FACET-NORMALS",	xpolG2_Compute_Facet_Normals	},

    {	NULL,			NULL	                	}
};
#endif
#endif

#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_THING
    k_thing = xlenter(":THING");
#define CREATED_THING
#endif

#ifndef CREATED_MINX
    k_minx = xlenter(":MIN-X");
#define CREATED_MINX
#endif

#ifndef CREATED_MAXX
    k_maxx = xlenter(":MAX-X");
#define CREATED_MAXX
#endif

#ifndef CREATED_MINY
    k_miny = xlenter(":MIN-Y");
#define CREATED_MINY
#endif

#ifndef CREATED_MAXY
    k_maxy = xlenter(":MAX-Y");
#define CREATED_MAXY
#endif

#ifndef CREATED_MINZ
    k_minz = xlenter(":MIN-Z");
#define CREATED_MINZ
#endif

#ifndef CREATED_MAXZ
    k_maxz = xlenter(":MAX-Z");
#define CREATED_MAXZ
#endif

#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
/*   xgbj56_Enter_Messages( lv_xgrl,  xpol_xgrl_table );*/
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
