/* {{{ xnff.c -- Fns to read NFF (neutral file format) files.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Mar08
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Mar08 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"

#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cmtl.h"

extern LVAL xsendmsg0(); 
extern LVAL xsendmsg1(); 
extern LVAL xsendmsg2(); 

#define PaSCII  (1)
#define PbINARY (2)

#define UsAMEsTRING (0)

union uAnyType {
    int       uI;
    int   *   uP;
    float     uF;
    float *   uFP;
    char  *   uT;
    LVAL      uL;
    short *   uSP;
    int     (*uFn)();
};
#define uAny		union uAnyType

LVAL xnff89_Load_File();

#define XNFF_MAX_TEXT (200)
char  xnff00_Text_Buffer[ XNFF_MAX_TEXT ];

int  xnff04_Point_Grl_Valid = FALSE;
LVAL xnff05_Point_Grl;

int  xnff06_Facet_Grl_Valid = FALSE;
LVAL xnff07_Facet_Grl;

int  xnff0a_Material_Valid  = FALSE;
LVAL xnff0b_Material;

LVAL xnffol_ThingList;

int  xnffpn_PointCount;
LVAL xnffpx_PointX;
LVAL xnffpy_PointY;
LVAL xnffpz_PointZ;
/* Point(vertex) normals: */
LVAL xnffvx_PtNmlX;
LVAL xnffvy_PtNmlY;
LVAL xnffvz_PtNmlZ;

int  xnfffn_FacetCount;
LVAL xnfff0_Facet0;
LVAL xnfff1_Facet1;
LVAL xnfff2_Facet2;

int xnfftp_TotalPolygons;
int xnffig_IgnoreThisOne;

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xnff10_viewing_vectors_and_angles                                */

xnff10_viewing_vectors_and_angles( fd )
FILE *	    			   fd;
{
    float f;

    xnff88_Read_Line( fd );
    xnff88_Read_Line( fd );
    xnff88_Read_Line( fd );
    xnff88_Read_Line( fd );
    xnff88_Read_Line( fd );
    xnff88_Read_Line( fd );
#ifdef CRIB
    from %g %g %g
    at %g %g %g
    up %g %g %g
    angle %g
    hither %g
    "resolution" xres yres
#endif
}

/* }}} */
/* {{{ xnff20_positional_light_location                                     */

xnff20_positional_light_location( fd )
FILE *	    			  fd;
{
#ifdef CRIB
    l %g %g %g
#endif
}

/* }}} */
/* {{{ xnff3_background_color                                               */

xnff30_background_color( fd )
FILE *	    		 fd;
{
#ifdef CRIB
    b %g %g %g
#endif
}

/* }}} */
/* {{{ xnff40_thing_material_properties                                    */

xnff40_thing_material_properties( fd )
FILE *	    		 	   fd;
{
#ifdef CRIB
    f %g %g %g %g %g %g %g %g
#endif
}

/* }}} */
/* {{{ xnff50_cone_or_cylinder_primitive                                    */

xnff50_cone_or_cylinder_primitive( fd )
FILE *	    		 	   fd;
{
    printf("NFF Cones and Cylinders not supported yet\n");
    exit(1);
}

/* }}} */
/* {{{ xnff60_sphere_primitive                                              */

xnff60_sphere_primitive( fd )
FILE *	    		 fd;
{
    printf("NFF Spheres not supported yet\n");
    exit(1);
}

/* }}} */
/* {{{ xnff70_polygon_primitive                                             */

xnff70_polygon_primitive( fd )
FILE *	    		  fd;
{
#ifdef MORE_CORRECT
    printf("NFF polygon primitives not supported yet\n");
    exit(1);
#endif
    xnff88_Read_Line( fd );
    xnff88_Read_Line( fd );
    xnff88_Read_Line( fd );
}

/* }}} */
/* {{{ xnff80_polygon_patch_primitive                                       */

xnff80_polygon_patch_primitive( fd )
FILE *	    		        fd;
{
    extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xflv;

    extern LVAL k_pointx;
    extern LVAL k_pointy;
    extern LVAL k_pointz;

    extern LVAL k_pointnormalx;
    extern LVAL k_pointnormaly;
    extern LVAL k_pointnormalz;

    extern LVAL k_setarray;
    extern LVAL k_adjustarray;

    int* array0;
    int* array1;
    int* array2;

    float* arrayX;
    float* arrayY;
    float* arrayZ;

    float* normlX;
    float* normlY;
    float* normlZ;

    int    pbase = xnffpn_PointCount;
    int    fbase = xnfffn_FacetCount;

    LVAL lv_facetcount;
    LVAL lv_pointcount;

    int total_vertices;
    int i;
    float  x,  y,  z; 
    float nx, ny, nz; 
    sscanf( xnff00_Text_Buffer, "pp %d", &total_vertices ); 
    if (total_vertices != 3) {
	printf("nontriangle patches not handled yet!\n");
	exit(1);
    }

    ++xnfffn_FacetCount;
/*printf("\nresizing facet array to %d\n",xnfffn_FacetCount);*/
    lv_facetcount      = cvfixnum( xnfffn_FacetCount );
    xsendmsg1( xnff07_Facet_Grl, k_adjustarray, lv_facetcount );

    xnffpn_PointCount += 3;
/*printf("\nresizing point array to %d\n",xnffpn_PointCount);*/
    lv_pointcount      = cvfixnum( xnffpn_PointCount );
    xsendmsg1( xnff05_Point_Grl, k_adjustarray, lv_pointcount );

    /* Get pointers to the actual int areas, for speed.   */
    /* note that these areas can move during a resize,    */
    /* hence this must follow the above resize...	      */
    array0 = (int*) (csry_base( xnfff0_Facet0 ));
    array1 = (int*) (csry_base( xnfff1_Facet1 ));
    array2 = (int*) (csry_base( xnfff2_Facet2 ));

    /* Get pointers to the actual float areas, for speed. */
    /* note that these areas can move during a resize,    */
    /* hence this must follow the above resize...	      */
    arrayX = (float*) (csry_base( xnffpx_PointX ));
    arrayY = (float*) (csry_base( xnffpy_PointY ));
    arrayZ = (float*) (csry_base( xnffpz_PointZ ));

    normlX = (float*) (csry_base( xnffvx_PtNmlX ));
    normlY = (float*) (csry_base( xnffvy_PtNmlY ));
    normlZ = (float*) (csry_base( xnffvz_PtNmlZ ));

    for (i = 0;   i < total_vertices;   ++i) {
	xnff88_Read_Line( fd );
	sscanf( xnff00_Text_Buffer, "%f %f %f %f %f %f",
	   & x, & y, & z,
	   &nx, &ny, &nz
	); 
/*printf("Line scanfed: %g %g %g %g %g %g\n",
x, y, z,nx, ny, nz); */
        arrayX[ pbase + i ] =  x;
        arrayY[ pbase + i ] =  y;
        arrayZ[ pbase + i ] =  z;

        normlX[ pbase + i ] = nx;
        normlY[ pbase + i ] = ny;
        normlZ[ pbase + i ] = nz;
    }

    array0[ fbase ] = pbase + 0;
    array1[ fbase ] = pbase + 1;
    array2[ fbase ] = pbase + 2;
}

/* }}} */
/* {{{ xnff88_Read_Line             Read line of text from given input file */

xnff88_Read_Line( fd )
FILE *	     fd;
{ 
    int      i; 
    char *   s; 
    int      c; 
  
    do {
	i   = XNFF_MAX_TEXT;
	s   = xnff00_Text_Buffer; 
	while (i-- && ((c=fgetc( fd )) != EOF) && (c != '\n')) { 
	    if (c == '\t')   c = ' '; 
	    if (c != '\r'   &&   c != 0xFF)   *s++ = c; 
	} 
	if (i < 1)	 xlfail("xnff88_Read_Line");
	*s = '\0'; 

    } while (*xnff00_Text_Buffer == '#');

/*printf("input line=%s\n", xnff00_Text_Buffer);*/
    return   c != EOF; 
} 

LVAL xnff87_Create_Grls( fd )
FILE *			 fd;
{
    extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xflv;
    extern LVAL lv_x32v;

    extern LVAL k_pointx;
    extern LVAL k_pointy;
    extern LVAL k_pointz;

    extern LVAL k_pointnormalx;
    extern LVAL k_pointnormaly;
    extern LVAL k_pointnormalz;

    extern LVAL k_facet0;
    extern LVAL k_facet1;
    extern LVAL k_facet2;

    extern LVAL k_setarray;

    extern LVAL k_show;

    extern LVAL k_material;
    extern LVAL k_pointrelation;
    extern LVAL k_facetrelation;

    char *   err_msg = "bad NFF file format!\n";

    int self_tubRefCount;

    LVAL lv_result;
    LVAL lv_tubName;
    LVAL lv_pointCount;
    LVAL lv_facetCount;

    int        toProt = 15;
/*printf("top of tub...\n");*/
    xlstkcheck(toProt);

    xlsave(lv_result);

    xlsave(xnff05_Point_Grl);
    xlsave(xnff07_Facet_Grl);

    xlsave(lv_tubName);
    xlsave(lv_pointCount);
    xlsave(lv_facetCount);

    xlsave(xnffpx_PointX);
    xlsave(xnffpy_PointY);
    xlsave(xnffpz_PointZ);

    xlsave(xnffvx_PtNmlX);
    xlsave(xnffvy_PtNmlY);
    xlsave(xnffvz_PtNmlZ);

    xlsave(xnfff0_Facet0);
    xlsave(xnfff1_Facet1);
    xlsave(xnfff2_Facet2);

    /* Sanity check ... skandha3 lets them get away with murder ...	*/
    /* shouldn't really crash, of course ...				*/
    if (xnff04_Point_Grl_Valid)  xlfail("nested tubes!");
    if (xnff06_Facet_Grl_Valid)  xlfail("nested tubes!");



    /* Create our point relation: */
    xnffpn_PointCount	= 0;
    lv_pointCount	= cvfixnum(xnffpn_PointCount);
    xnff05_Point_Grl	= xsendmsg1( lv_xgrl, k_new, lv_pointCount );
    xnff04_Point_Grl_Valid = TRUE;

    /* Create point-x/y/z arrays to go in point relation: */
    xnffpx_PointX	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xnffpy_PointY	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xnffpz_PointZ	= xsendmsg1( lv_xflv, k_new, lv_pointCount );

    /* Insert point-x/y/z arrays in point relation: */
    xsendmsg2( xnff05_Point_Grl, k_setarray, k_pointx, xnffpx_PointX );
    xsendmsg2( xnff05_Point_Grl, k_setarray, k_pointy, xnffpy_PointY );
    xsendmsg2( xnff05_Point_Grl, k_setarray, k_pointz, xnffpz_PointZ );

    /* Create point-normal-x/y/z arrays to go in point relation: */
    xnffvx_PtNmlX	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xnffvy_PtNmlY	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xnffvz_PtNmlZ	= xsendmsg1( lv_xflv, k_new, lv_pointCount );

    /* Insert point-normal-x/y/z arrays in point relation: */
    xsendmsg2( xnff05_Point_Grl, k_setarray, k_pointnormalx, xnffvx_PtNmlX );
    xsendmsg2( xnff05_Point_Grl, k_setarray, k_pointnormaly, xnffvy_PtNmlY );
    xsendmsg2( xnff05_Point_Grl, k_setarray, k_pointnormalz, xnffvz_PtNmlZ );



    /* Create our facet relation: */
    xnfffn_FacetCount	= 0;
    lv_facetCount	= cvfixnum(xnfffn_FacetCount);
    xnff07_Facet_Grl	= xsendmsg1( lv_xgrl, k_new, lv_facetCount );
    xnff06_Facet_Grl_Valid = TRUE;

    /* Create facet-0/1/2 arrays to go in facet relation: */
    xnfff0_Facet0	= xsendmsg1( lv_x32v, k_new, lv_facetCount );
    xnfff1_Facet1	= xsendmsg1( lv_x32v, k_new, lv_facetCount );
    xnfff2_Facet2	= xsendmsg1( lv_x32v, k_new, lv_facetCount );

    /* Insert facet-0/1/2 arrays in facet relation: */
    xsendmsg2( xnff07_Facet_Grl, k_setarray, k_facet0, xnfff0_Facet0 );
    xsendmsg2( xnff07_Facet_Grl, k_setarray, k_facet1, xnfff1_Facet1 );
    xsendmsg2( xnff07_Facet_Grl, k_setarray, k_facet2, xnfff2_Facet2 );



    while (xnff88_Read_Line( fd )) {
	switch (*xnff00_Text_Buffer) {
	case '#':						break;
        case 'v': xnff10_viewing_vectors_and_angles( fd );	break;
        case 'l': xnff20_positional_light_location(  fd );	break;
        case 'b': xnff30_background_color(	     fd );	break;
        case 'f': xnff40_thing_material_properties( fd );	break;
        case 'c': xnff50_cone_or_cylinder_primitive( fd );	break;
        case 's': xnff60_sphere_primitive(	     fd );	break;
        case 'p':
	    switch (xnff00_Text_Buffer[1]) {
	    case ' ':     xnff70_polygon_primitive(  	   fd );break;
	    case 'p':     xnff80_polygon_patch_primitive(  fd );break;
	    default:
		printf(err_msg);
		abort();
	    }		
	    break;
	default:
	    printf("Unrecognized NFF operator: %c\n",*xnff00_Text_Buffer);
	    printf(err_msg);
	    abort();
	}
    }
/*printf("done reading input file...\n");*/

    /* Close file: */ 
    fclose( fd );
/*printf("xnff80: Total polygons d=%d\n",xnfffn_FacetCount);*/

/*printf("xnff80: Facet grl:\n");
xsendmsg0( xnff07_Facet_Grl, k_show );
printf("xnff80: Point grl:\n");
xsendmsg0( xnff05_Point_Grl, k_show );*/

    /* Construct return value: */
    lv_result     = cons( xnff07_Facet_Grl,       NIL );
    lv_result     = cons( k_facetrelation , lv_result );
    lv_result     = cons( xnff05_Point_Grl, lv_result );
    lv_result     = cons( k_pointrelation , lv_result );
    if (xnff0a_Material_Valid) {
printf("xnff80: MATERIAL IS VALID?\n");
	lv_result = cons( xnff0b_Material , lv_result );
	lv_result = cons( k_material      , lv_result );
    }

    /* Prepend return value (new thing) to global thinglist: */
    xnffol_ThingList = cons( lv_result, xnffol_ThingList );

    xlpopn(toProt);

    xnff04_Point_Grl_Valid = FALSE;
    xnff06_Facet_Grl_Valid = FALSE;

    return lv_result;
}

/* }}} */
/* {{{ xnff89_Load_File                                                     */

LVAL xnff89_Load_File( fileName )
char		      *fileName; 
{ 
    FILE *   fd; 
    int      fileType; 
    char     model[ 1000 ]; 
    char     typ[   1000 ]; 
    LVAL     child; 
  
    /* Open input file: */ 
    { 
        char *   t; 
  
	if (! (fd = fopen( fileName, "rb" ))) {
	    /* Buggo ... shouldn't really crash on file not found: */
	    sprintf(model, "File not found: %s", fileName);
            xlfail( model ); 
        } 
    } 
  
    return xnff87_Create_Grls( fd );
} 

/* }}} */
/* {{{ xnff90_Load_NFF_File_Fn -- Load a NFF (neutral file format) file.	*/

LVAL xnff90_Load_NFF_File_Fn()
{
    LVAL  lv_filename = xlgastring();
    char*    filename = (char*) getstring( lv_filename );
    xllastarg();

    /* Concatenate all tubes together into an thinglist, and return: */
    xlsave1(xnffol_ThingList);
    xnfftp_TotalPolygons = 0;
    xnff89_Load_File( filename );
printf("xnff90_Load_NFF_File_Fn: Total polygons d=%d\n",xnfftp_TotalPolygons);
    xlpop();
    {   LVAL   lv_result = xnffol_ThingList;
	xnffol_ThingList= NIL;
        return lv_result;
    }
}

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

