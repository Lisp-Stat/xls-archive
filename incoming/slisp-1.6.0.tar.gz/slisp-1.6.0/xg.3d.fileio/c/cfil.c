/* {{{ cfil.h -- native binary file I/O support.		     CrT*/

/************************************************************************/
/* Copyright (c) 1993 Jeffrey S. Prothero, University of Washington	*/
/* Department of Biological Structure.  All rights reserved.            */ 
/*									*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU Library General Public License as      */
/* published by the Free Software Foundation; either version 2, or      */
/* (at your option) any later version.					*/
/*									*/
/* This program is distributed in the hope that it will be useful,	*/
/* but WITHOUT ANY WARRANTY; without even the implied warranty of	*/
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the	*/
/* GNU Library General Public License for more details.			*/
/*									*/
/* You should have received a copy of the GNU Library General Public	*/
/* License along with this program; if not, write to the Free Software	*/
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.		*/
/*									*/
/* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES	*/
/* WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF	*/
/* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF		*/
/* WASHINGTON NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR	*/
/* CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS	*/
/* OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,		*/
/* NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN		*/
/* CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.		*/
/*									*/
/* Please send modifications and fixes to jsp@glia.biostr.washington.edu*/
/* Post XLISP-specific questions/infor to the newsgroup comp.lang.lisp.x*/
/************************************************************************/ 

/* }}} */
/* {{{ --- history ---							*/

/* 92May21 jsp	Created, from lib.c fns.				*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/csry.h"

#define CFIL_BYTES   (0x10)
#define CFIL_INT32S  (0x40)
#define CFIL_FLOATS  (0x50)
#define CFIL_DOUBLES (0x80)



/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ cfil43_fread							*/

cfil43_fread( buf, size, count, fp )
char         *buf;
int                size, count;
FILE                           *fp;
{
    {   int bytes_read = fread( buf, size, count, fp );
	if (bytes_read < count) {
	    xlfail("cfil43: unexpected eof");
	}
    }
}

/* }}} */
/* {{{ cfil44_fwrite							*/

cfil44_fwrite( buf, size, count, fp )
char          *buf;
int                 size, count;
FILE                            *fp;
{   if (fwrite( buf, size, count, fp ) < count)   xlfail("cfil44: fwrite failed");
}

/* }}} */
/* {{{ cfil45_Write_Bytes_To_File					*/

char*cfil45_Write_Bytes_To_File( buf, count, fp )
char                            *buf;
int                                   count;
FILE                                        *fp;
{   CSRY_INT32 i;
    i = CFIL_BYTES;    cfil44_fwrite( &i, sizeof(CSRY_INT32), 1, fp );
    i =      count;    cfil44_fwrite( &i, sizeof(CSRY_INT32), 1, fp );
    cfil44_fwrite( buf, sizeof(char), count, fp );
    return         buf +sizeof(char)* count;
}

/* }}} */
/* {{{ cfil46_Write_Doubles_To_File					*/

char* cfil46_Write_Doubles_To_File( buf, count, fp )
char                               *buf;
int                                      count;
FILE                                           *fp;
{   CSRY_INT32 i;
    i = CFIL_DOUBLES;  cfil44_fwrite( &i, sizeof(CSRY_INT32), 1, fp );
    i =      count;    cfil44_fwrite( &i, sizeof(CSRY_INT32), 1, fp );
    cfil44_fwrite( buf, sizeof(double), count, fp );
    return         buf +sizeof(double)* count;
}

/* }}} */
/* {{{ cfil47_Write_Floats_To_File					*/

char*cfil47_Write_Floats_To_File( buf, count, fp )
char                             *buf;
int                                    count;
FILE                                         *fp;
{   CSRY_INT32 i;
    i = CFIL_FLOATS;  cfil44_fwrite( &i, sizeof(CSRY_INT32), 1, fp );
    i =      count;   cfil44_fwrite( &i, sizeof(CSRY_INT32), 1, fp );
    cfil44_fwrite( buf, sizeof(float), count, fp );
    return         buf +sizeof(float)* count;
}

/* }}} */
/* {{{ cfil48_Write_Int32s_To_File					*/

char*cfil48_Write_Int32s_To_File( buf, count, fp )
char                             *buf;
int                                    count;
FILE                                         *fp;
{   CSRY_INT32 i;
    i = CFIL_INT32S;  cfil44_fwrite( &i, sizeof(CSRY_INT32), 1, fp );
    i =      count;   cfil44_fwrite( &i, sizeof(CSRY_INT32), 1, fp );
    cfil44_fwrite( buf, sizeof(CSRY_INT32), count, fp );
    return         buf +sizeof(CSRY_INT32)* count;
}

/* }}} */
/* {{{ cfil49_Read_Binary_Rec_Header_From_File				*/

cfil49_Read_Binary_Rec_Header_From_File( lv, fp, fn,fa )
LVAL					 lv;
FILE                                        *fp;
int				               (*fn)();
char					           *fa;
{   CSRY_INT32 magic;
    CSRY_INT32 version;

    cfil43_fread( &magic     , sizeof(CSRY_INT32), 1, fp );
    cfil43_fread( &version   , sizeof(CSRY_INT32), 1, fp );

    return (*fn)(fa, lv,fp, magic, version );
}

/* }}} */
/* {{{ cfil50_Write_Binary_Rec_Header_To_File				*/

cfil50_Write_Binary_Rec_Header_To_File( fp, lv, Version )
FILE                                   *fp;
LVAL					    lv;
int					        Version;
{   CSRY_INT32 magic     = 0x12345678;
    CSRY_INT32 version   = Version;

    cfil44_fwrite( &magic    , sizeof(CSRY_INT32), 1, fp );
    cfil44_fwrite( &version  , sizeof(CSRY_INT32), 1, fp );
}

/* }}} */
/* {{{ cfil4a_Reorder_Byte4s						*/

cfil4a_Reorder_Byte4s( buf, count, magic )
char                  *buf;
int                         count;
CSRY_INT32                         magic;
{   int	        i;
    CSRY_INT32  n;
    CSRY_INT32* p;

    /* Fix byte ordering if file was written on different-endian machine: */
    switch (magic) {
    case 0x12345678:
	/* No byte reordering needed. */
	break;
    case 0x78563412:
	/* Reverse byte ordering:     */
	p = (CSRY_INT32*) buf;
	for (i = count;   i --> 0;  ) {
	    n  = *p;
	    n  = (
		((n >> 24) & 0x000000FF) |
		((n >>  8) & 0x0000FF00) |
		((n <<  8) & 0x00FF0000) |
		((n << 24) & 0xFF000000)     /* Yeah, don't need mask. Thpt. */
	    );
	    *p++ = n;
	}
	break;
    default:
	/* Trashed file or a *perverted* machine: */
	xlfail( "cfil4a: weird byteorder" );
    }
}

/* }}} */
/* {{{ cfil51_Read_Block_Type_And_Length_From_File			*/

cfil51_Read_Block_Type_And_Length_From_File( blockType, blockLen, magic, fp )
int                                          blockType, blockLen, magic;
FILE							                *fp;
{   CSRY_INT32             inType;
    CSRY_INT32             in_len;
    cfil43_fread(          &inType, sizeof(CSRY_INT32), 1, fp );
    cfil43_fread(          &in_len, sizeof(CSRY_INT32), 1, fp );
    cfil4a_Reorder_Byte4s( &inType, 1, magic );
    cfil4a_Reorder_Byte4s( &in_len, 1, magic );
    if (
	(inType != blockType)			||
        (in_len != blockLen  &&  blockLen != -1)
    ) {
	xlfail("cfil51: bad file format");
    }
    return in_len;
}

/* }}} */
/* {{{ cfil52_Read_Bytes_From_File					*/

char*cfil52_Read_Bytes_From_File( buf, count, magic, fp )
char                             *buf;
int                                    count;
CSRY_INT32                                    magic;
FILE                                                *fp;
{   cfil51_Read_Block_Type_And_Length_From_File( CFIL_BYTES, count, magic, fp );
    cfil43_fread( buf, count, 1, fp );
    return buf+count;
}

/* }}} */
/* {{{ cfil53_Read_Doubles_From_File					*/

char*cfil53_Read_Doubles_From_File( buf, count, magic, fp )
char                               *buf;
int                                      count;
CSRY_INT32                                      magic;
FILE                                                  *fp;
{   int	        i;
    CSRY_INT32 n0;
    CSRY_INT32 n1;
    CSRY_INT32* p;

    /* Read the bufferload: */
    cfil51_Read_Block_Type_And_Length_From_File( CFIL_DOUBLES, count, magic, fp );
    cfil43_fread( buf, sizeof(double), count, fp );

    /* Modern compilers should optimize this away, */
    /* so it's not quite as gross as it looks:     */
    if (sizeof(double) != 2*sizeof(CSRY_INT32)) xlfail("Fix cfil53!");

    /* Fix byte ordering if file was written on different-endian machine: */
    switch (magic) {
    case 0x12345678:
	/* No byte reordering needed. */
	break;
    case 0x78563412:
	/* Reverse byte ordering... trusting naively */
	/* that machines that reverse 4-byte numbers */
	/* end-to-end all do the same with 8-byters: */
	cfil4a_Reorder_Byte4s( buf, count*2, magic );
	p = (CSRY_INT32*) buf;
	for (i = count;   i --> 0;  ) {
	    n0   = p[0];
	    n1   = p[1];
	    p[0] = n1;
	    p[1] = n0;
	    p   += 2;
	}
	break;
    default:
	/* Trashed file or a *perverted* machine: */
	xlfail( "cfil53: bad magic!" );
    }

    return   buf  +  count * sizeof(double);
}

/* }}} */
/* {{{ cfil5a_Read_Byte4s_From_File					*/

char*cfil5a_Read_Byte4s_From_File( buf, count, magic, fp )
char                              *buf;
int                                     count;
CSRY_INT32                                     magic;
FILE                                                 *fp;
{   cfil43_fread( buf, sizeof(CSRY_INT32), count, fp );
    cfil4a_Reorder_Byte4s( buf, count, magic );
    return   buf  +  count * sizeof(CSRY_INT32);
}

/* }}} */
/* {{{ cfil54_Read_Floats_From_File					*/

char*cfil54_Read_Floats_From_File( buf, count, magic, fp )
char                              *buf;
int                                     count;
CSRY_INT32                                     magic;
FILE                                                 *fp;
{   cfil51_Read_Block_Type_And_Length_From_File( CFIL_FLOATS, count, magic, fp );
    return cfil5a_Read_Byte4s_From_File( buf, count, magic, fp );
}

/* }}} */
/* {{{ cfil55_Read_Int32s_From_File					*/

char*cfil55_Read_Int32s_From_File( buf, count, magic, fp )
char                              *buf;
int                                     count;
CSRY_INT32                                     magic;
FILE                                                 *fp;
{   cfil51_Read_Block_Type_And_Length_From_File( CFIL_INT32S, count, magic, fp );
    return cfil5a_Read_Byte4s_From_File( buf, count, magic, fp );
}
/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */

