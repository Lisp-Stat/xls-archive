/* {{{ xvrml.c -- VRML I/O code.					     CrT*/
/*************************************************************************
*
* Author:       Kevin Hinshaw
* Created:      1998Sep23
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

/* {{{ --- history ---							*/

/* 1998Oct20 kph: Added routines for saving VRML97.                     */
/* 1998Sep23 kph: Created.               				*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#include "../../xg.3d/c/xthl.h"
#include "../../xg.3d/c/cgrl.h"

/* external variables */
extern LVAL k_reverse_z;

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xvrm01_1_Save_Points_Fn                    			*/

void xvrm00_1_Save_Points( lv_fp, lv_points, reverse_z )
LVAL		         lv_fp, lv_points;
int                                          reverse_z;
{
  /* Take a GRL of points and spit them out in VRML 1.0 format. */

  FILE *fp  = getfile( lv_fp );
  gt_tri_rec r;
  xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );

  xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_points );
  if (!r.got_points)   xlerror("Need :POINTS-X/Y/Z",lv_points);

printf("Saving %d points...\n", r.pLen);

  fprintf(fp, "Coordinate3 { point [\n");
  { int i;
    float *px = r.x;
    float *py = r.y;
    float *pz = r.z;

    if (reverse_z) {
      for (i = 0; i < r.pLen; i++) {
	fprintf(fp, "  %0.3f %0.3f %0.3f,\n", px[i], py[i], -pz[i]); }
    } else {
      for (i = 0; i < r.pLen; i++) {
	fprintf(fp, "  %0.3f %0.3f %0.3f,\n", px[i], py[i], pz[i]); }
    }
  }
  fprintf(fp, "] }\n");
}


LVAL  xvrm01_1_Save_Points_Fn()
{
  extern LVAL true;
  LVAL lv_fp  = NIL;
  LVAL lv_points = NIL;
  int  reverse_z = FALSE;

  /* read args */
  lv_fp      = xlgetfile();      /* filename */
  lv_points  = xlgagobject();    /* point GRL */
  while (moreargs()) {
    LVAL  key = xlgasymbol();
    if   (key == k_reverse_z)  {
      reverse_z = !null(xlgetarg());
    } else {
      xlerror("Bad keyword", key);
    }
  }

  if (!xgrlp( lv_points )) {
    xlerror("Not a GRL", lv_points);
  }

  xvrm00_1_Save_Points(lv_fp, lv_points, reverse_z);
  return true;
}

/* }}} */
/* {{{ xvrm03_1_Save_Facets_Fn                    			*/

void xvrm02_1_Save_Facets( lv_fp, lv_facets, reverse_z )
LVAL         	         lv_fp, lv_facets;
int                                          reverse_z;
{
  /* Take a GRL of facets and spit them out in VRML 1.0 format. */

  FILE *fp  = getfile( lv_fp );
  gt_tri_rec r;
  xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
  xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_facets );

printf("Saving %d facets...\n", r.fLen);

  { int i;
    int  *f0 = r.f0;
    int  *f1 = r.f1;
    int  *f2 = r.f2;
    int  *f3 = r.f3;

    if (r.got_rectangles) {
      fprintf(fp, "IndexedFaceSet { coordIndex [\n");
      for (i = 0; i < r.fLen; i++) {
	fprintf(fp, "  %d, %d, %d, %d, -1,\n", f0[i], f1[i], f2[i], f3[i]);
      }
      fprintf(fp, "] }\n");
  
    } else if (r.got_triangles) {
      fprintf(fp, "IndexedFaceSet { coordIndex [\n");
      for (i = 0; i < r.fLen; i++) {
	fprintf(fp, "  %d, %d, %d, -1,\n", f0[i], f1[i], f2[i]);
      }
      fprintf(fp, "] }\n");
  
    } else if (r.got_segments) {
      fprintf(fp, "IndexedLineSet { coordIndex [\n");
      for (i = 0; i < r.fLen; i++) {
	fprintf(fp, "  %d, %d, -1,\n", f0[i], f1[i]);
      }
      fprintf(fp, "] }\n");
  
    /* Not checking r.got_points, because right now I'm passing in the */
    /* facet relation only, without actually having the points.        */
    } else if (r.f0 != NULL) {
      fprintf(fp, "PointSet {\n");
      fprintf(fp, "  startIndex 0\n");
      fprintf(fp, "  numPoints -1\n");
      fprintf(fp, "}\n");
      
    } else {
      xlerror("Need :FACET-0/1/2/3",lv_facets);
    }
  }
}

LVAL  xvrm03_1_Save_Facets_Fn()
{
  extern LVAL true;
  LVAL lv_fp  = NIL;
  LVAL lv_facets = NIL;
  int  reverse_z = FALSE;

  /* read GRL and file args */
  lv_fp      = xlgetfile();
  lv_facets  = xlgagobject();
  while (moreargs()) {
    LVAL  key = xlgasymbol();
    if   (key == k_reverse_z)  {
      reverse_z = !null(xlgetarg());
    } else {
      xlerror("Bad keyword", key);
    }
  }

  if (!xgrlp( lv_facets )) {
    xlerror("Not a GRL", lv_facets);
  }

  xvrm02_1_Save_Facets(lv_fp, lv_facets, reverse_z);
  return true;
}

/* }}} */
/* {{{ xvrm06_97_Save_Geometry_Fn                    			*/

void xvrm04_97_Save_Points( FILE *fp, gt_tri_rec *r, int reverse_z )
{
  /* Spit out the points in a processed thing in VRML97 format. */

  int   i;
  float *px = r->x;
  float *py = r->y;
  float *pz = r->z;

printf("Saving %d points...\n", r->pLen);
if (reverse_z) printf(" (reversed)\n");

  fprintf(fp, "coord Coordinate { point [\n");
  if (reverse_z) {
    for (i = 0; i < r->pLen; i++) {
      fprintf(fp, "  %0.3f %0.3f %0.3f,\n", px[i], py[i], -pz[i]); }
  } else {
    for (i = 0; i < r->pLen; i++) {
      fprintf(fp, "  %0.3f %0.3f %0.3f,\n", px[i], py[i], pz[i]); }
  }
  fprintf(fp, "] }\n");
}


void xvrm05_97_Save_Geometry( FILE *fp, gt_tri_rec *r, int reverse_z ) 
{
  /* Save a thing's geometry to file in VRML97 format. */

  int   i;
  float creaseAngle = 1.5;
  int  *f0 = r->f0;
  int  *f1 = r->f1;
  int  *f2 = r->f2;
  int  *f3 = r->f3;

  /* print the proper header */
  if     ((r->got_rectangles) ||
	  (r->got_triangles)) {  
    fprintf(fp, "IndexedFaceSet { \n");
    fprintf(fp, "  solid        FALSE \n");   /* to be safe */
    fprintf(fp, "  creaseAngle  %f \n", creaseAngle);
  }
  else if (r->got_segments)   fprintf(fp, "IndexedLineSet { \n");
  else if (r->got_points)     fprintf(fp, "PointSet {\n");
  else                        xlerror("Need :POINT-X/Y/Z");

  /* print points */
  xvrm04_97_Save_Points(fp, r, reverse_z);

printf("Saving %d facets...\n", r->fLen);

/* DEBUG:  temporarily draw both sides of polys explicitly */

  /* print facets */
  if (r->got_rectangles) {
    fprintf(fp, "coordIndex [\n");
    for (i = 0; i < r->fLen; i++) {
      fprintf(fp, "  %d %d %d %d -1\n", f0[i], f1[i], f2[i], f3[i]);
/*      fprintf(fp, "  %d %d %d %d -1\n", f3[i], f2[i], f1[i], f0[i]); */
    }
    fprintf(fp, "  ]\n");
  
  } else if (r->got_triangles) {
    fprintf(fp, "coordIndex [\n");
    for (i = 0; i < r->fLen; i++) {
      fprintf(fp, "  %d %d %d -1\n", f0[i], f1[i], f2[i]);
/*      fprintf(fp, "  %d %d %d -1\n", f2[i], f1[i], f0[i]); */
    }
    fprintf(fp, "  ]\n");
    
  } else if (r->got_segments) {
    fprintf(fp, "coordIndex [\n");
    for (i = 0; i < r->fLen; i++) {
      fprintf(fp, "  %d %d -1\n", f0[i], f1[i]);
/*      fprintf(fp, "  %d %d -1\n", f1[i], f0[i]); */
    }
    fprintf(fp, "  ]\n");
  }
  /* for points, we don't need any facets */

  /* print footer */
  fprintf(fp, "}\n");
}


LVAL  xvrm06_97_Save_Geometry_Fn()
{
  /* Lisp name:  XVRML-97-SAVE-GEOMETRY
   *
   * Parse args before saving a thing's geometry in VRML97 format.
   */

  gt_tri_rec  r;
  int         reverse_z = FALSE;
  LVAL        lv_fp     = NIL;
  LVAL        lv_thing  = NIL;
  extern LVAL true;
  FILE        *fp;

  /* read args */
  lv_fp      = xlgetfile();
  lv_thing   = xlgacons();
  while (moreargs()) {
    LVAL  key = xlgasymbol();
    if   (key == k_reverse_z)  {
      reverse_z = !null(xlgetarg());
    } else {
      xlerror("Bad keyword", key);
    }
  }

  /* parse the LVALS */
  xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
  xthlB1_Process_Thing( &r, lv_thing );
  if (!r.got_points)   xlerror("Need :POINTS-X/Y/Z",lv_thing);
  fp = getfile( lv_fp );
  if (!fp)             xlerror("Bad file pointer", lv_fp);

  xvrm05_97_Save_Geometry(fp, &r, reverse_z);
  return true;
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
