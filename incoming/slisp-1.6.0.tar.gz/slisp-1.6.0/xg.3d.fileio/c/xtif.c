/* {{{ xtif.c -- Read tiff (Tagged Image File Format) files.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero ('cept it's mostly stolen sam@sgi.com code)
* Created:      92Apr19
* Modified:
* Language:     C.  Uses libtiff.a (tested with v2.4), available at net.archives.
* Package:      N/A
* Status:
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/************************************************************************/
/*                              comments                                */
/*                                                                      */
/*      My package is only designed to work with RGB images for now,    */
/*      the colortable fns in this file aren't currently used, are      */
/*      left in place just on the offchance they might be wanted at     */
/*      some point.  #ifdef'ed out so they won't waste ram ...          */
/*      They would need some work to adapt them, of course.     CrT     */
/*                                                                      */
/************************************************************************/

/* }}} */
/* {{{ --- history ---							*/

/* 92Apr24 jsp: Operational.						*/
/* 92Apr19 jsp: Created.						*/

/* }}} */
/* {{{ --- lyric ---							*/

/************************************************************************/
/*                              lyric                                CrT*/
/*                                                                      */
/*                       people are strange 	     	     	       	*/
/*                       when you're a stranger	     	     	       	*/
/*                       faces look ugly    	     	     	       	*/
/*                       when you're alone  	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       women seem wicked  	     	     	       	*/
/*                       when you're unwanted	     	     	       	*/
/*                       streets are uneven 	     	     	       	*/
/*                       when you're down   	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       faces come out of the rain  	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       no-one remembers your name  	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       people are strange 	     	     	       	*/
/*                       when you're a stranger	     	     	       	*/
/*                       faces look ugly    	     	     	       	*/
/*                       when you're alone  	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       women seem wicked  	     	     	       	*/
/*                       when you're unwanted	     	     	       	*/
/*                       streets are uneven 	     	     	       	*/
/*                       when you're down   	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       [instrumental]	    	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       faces come out of the rain  	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       no-one remembers your name  	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       alright, yeah ...  	     	     	       	*/
/*                       [instrumental]	    	     	     	       	*/
/*                       	    	    	     	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       FACES COME OUT OF THE RAIN  	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       NO-ONE REMEMBERS YOUR NAME  	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       when you're strange	     	     	       	*/
/*                       when you're StRaNgE ...     	     	       	*/
/*                                                                      */
/*                             -- Doors (of Perception)                 */
/*                                                                      */
/************************************************************************/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"

#include "../../include/tiffio.h"

#include <stdio.h>
#include <device.h>
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cmtl.h"
/*#include <varargs.h>*/

extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();

LVAL xtif89_Load_File();

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xtif87_Create_Grls                                                   */

LVAL xtif87_Create_Grls( rows, cols,  r,  g,  b, samplesPerPixel )
int                      rows, cols;
CSRY_UNSIGNED8                      **r,**g,**b;
int						 samplesPerPixel;
{   extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xf8v;

    extern LVAL k_pixelred;
    extern LVAL k_pixelgreen;
    extern LVAL k_pixelblue;

    extern LVAL k_setarray;

    extern LVAL k_show;

    extern LVAL k_pixelrelation;

    char *   err_msg = "bad TIFF file format!\n";

    LVAL lv_shape;
    LVAL lv_grl;

    LVAL lv_red;
    LVAL lv_grn;
    LVAL lv_blu;

    int        toProt = 5;
    xlstkcheck(toProt);
    xlsave(lv_shape );
    xlsave(lv_grl   );
    xlsave(lv_red   );
    xlsave(lv_grn   );
    xlsave(lv_blu   );

    /* Create our pixel relation: */
    lv_shape = cons(cvfixnum(cols),     NIL);
    lv_shape = cons(cvfixnum(rows),lv_shape);
    lv_grl		= xsendmsg1( lv_xgrl, k_new, lv_shape );

    /* Create pixel-red/green/blue arrays to go in relation: */
    if (samplesPerPixel > 1)  lv_red	= xsendmsg1( lv_xf8v, k_new, lv_shape );
    if (samplesPerPixel > 0)  lv_grn	= xsendmsg1( lv_xf8v, k_new, lv_shape );
    if (samplesPerPixel > 1)  lv_blu	= xsendmsg1( lv_xf8v, k_new, lv_shape );

    /* Insert pixel-red/green/blue arrays in pixel relation: */
    if (samplesPerPixel > 1)  xsendmsg2( lv_grl, k_setarray, k_pixelred  , lv_red );
    if (samplesPerPixel > 0)  xsendmsg2( lv_grl, k_setarray, k_pixelgreen, lv_grn );
    if (samplesPerPixel > 1)  xsendmsg2( lv_grl, k_setarray, k_pixelblue , lv_blu );

    /* Locate the actual pixel-buffers within pixel arrays: */
    *g     = (CSRY_UNSIGNED8*) csry_base( lv_grn );
    if (samplesPerPixel > 1) {
        *r = (CSRY_UNSIGNED8*) csry_base( lv_red );
        *b = (CSRY_UNSIGNED8*) csry_base( lv_blu );
    } else {
        *r = *g;
        *b = *g;
    }

    xlpopn(toProt);

    return lv_grl;
}

/* }}} */
/* {{{ xtif90_Load_TIFF_File_Fn -- Load TIFF (Tagged Image File Format) file*/

LVAL xtif90_Load_TIFF_File_Fn()
{   LVAL  xtifa1_main();
    LVAL  lv_filename = xlgastring();
    char*    filename = (char*)getstring( lv_filename );
    xllastarg();

    return xtifa1_main( filename );
}

/* }}} */
/* {{{ TIFFWarning   Replacement for standard libtiff warning fn.           */

void TIFFWarning( char*filename, char*warning, ... )
{   /* Can't think of anything nice to do with a warning */
    /* in the context of xlisp programs generally ...    */
}      

/* }}} */
/* {{{ TIFFError     Replacement for standard libtiff error   fn.           */

void TIFFError( char*module, char*fmt, ... )
{   char txt[ 256 ];
#ifdef DOESNT_PORT
    /* Haven't figured out the magic to make this portable these days ... */
    va_list ap;
    va_start(ap, fmt);
    sprintf(txt, fmt, ap);
    va_end(ap);
    xlfail(txt);      /* This is going to leak (buf) memory, likely.     */ 
#else
    /* So, punt: */
    xlfail(fmt);      /* This is going to leak (buf) memory, likely.     */ 
#endif
}

/* }}} */

/* {{{ SGI code copyright --						    */
/************************************************************************/
/* Following code to read .tiff files is adapted from the libtiff V2.4  */
/* 'tiffgt' utility, by sam@sgi.com, which carried the following        */
/* copyright.  The nifty stuff is likely his, the bugs and kludges are  */
/* likely me messing up his code ... :)                              CrT*/
/************************************************************************/

/*
 * Copyright (c) 1988, 1989, 1990, 1991 Sam Leffler
 * Copyright (c) 1991 Silicon Graphics, Inc.
 *
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names of
 * Sam Leffler and Silicon Graphics may not be used in any advertising or
 * publicity relating to the software without the specific, prior written
 * permission of Sam Leffler and Silicon Graphics.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,

 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL SAM LEFFLER OR SILICON GRAPHICS BE LIABLE FOR
 * ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF
 * LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THIS SOFTWARE.
 */
/* }}} */
/* {{{ -- header stuff -- 						    */

typedef	unsigned char U_char;
typedef	unsigned short U_short;
typedef	unsigned int U_int;
typedef	unsigned long U_long;

U_char *rRed, *rGrn, *rBlu; /* Red/green/blue raster components */
static U_long	width, height;		/* image width & height */
static U_short	bitspersample;
static U_short	samplesPerPixel;
static U_short	photometric;
static U_short	orientation;
static U_short	*redCMap;   /* Colormap for palette images. */
static U_short	*grnCMap;   /* Colormap for palette images. */
static U_short	*bluCMap;   /* Colormap for palette images. */

/* isRGB is set to:				*/
/*   1 if display is to be on RGB device;	*/
/*   0 if display is to be on colormap device;	*/
/*  -1 if we haven't made our mind up yet.	*/
static int	isRGB = -1;

static char	*filename;

static	xtifa4_gt();

#define	howmany(x, y)	(((x)+((y)-1))/(y))
U_char  **BWmap  = NULL;
U_long	**PALmap = NULL;

static	xtifa6_gtTileContig();
static	xtifa7_gtTileSeparate();
static	xtifa8_gtStripContig();
static	xtifa9_gtStripSeparate();

/* }}} */
/* {{{ xtifa1_main                                                          */

LVAL xtifa1_main( filnam )
char             *filnam;
{   char        *cp;
    char        *rindex();
    long         max;
    TIFF *       tif;
    int          fg = FALSE; /* foreground. Was commandline switch. */
    int          c;
    int          dirnum = -1;/* cmndline switch used this for multi-image files */
    int          order = 0;  /* -l/m used to mean FILLORDER_{LSB2MSB|MSB2LSB} */
    extern int   optind;
    extern char *optarg;
    LVAL         result;
    xlsave1(result);
    isRGB = -1; /* commandline switches used to set FALSE/TRUE for no/colormap */
    filename = filnam; /* Mostly for error reporting. */
    tif      = TIFFOpen(filename, "r");
    if (tif == NULL)   exit(-1);
    if (dirnum != -1   &&   !TIFFSetDirectory(tif, dirnum)) {
	TIFFError(filename, "Error, seeking to directory %d", dirnum);
	exit(-1);
    }
    if (order)   TIFFSetField(tif, TIFFTAG_FILLORDER, order);

    /* Figure bits-per-sample: */
    if (!TIFFGetField(tif, TIFFTAG_BITSPERSAMPLE, &bitspersample))
	    bitspersample = 1;
    switch (bitspersample) {
    case  1:
    case  2:
    case  4:
    case  8:
    case 16:
	break;
    default:
	TIFFError(filename, "Sorry, can't handle %d-bit pictures",bitspersample);
	exit(-1);
    }

    /* Figure samples-per-pixel: */
    if (!TIFFGetField(tif, TIFFTAG_SAMPLESPERPIXEL, &samplesPerPixel)) {
	samplesPerPixel = 1;
    }
    switch (samplesPerPixel) {
    case 1:
    case 3:
    case 4:
	break;
    default:
	TIFFError(filename,"Sorry, can't handle %d-channel images",samplesPerPixel);
	exit(-1);
    }

    /* Locate size-in-pixels of image: */
    TIFFGetField(tif, TIFFTAG_IMAGEWIDTH , &width );
    TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &height);

    cp = rindex(filename, '/');
    if (cp == NULL)		cp = filename;
    else			cp++;

    /* Create relation to hold image, locate actual pixel-plane buffers: */
    result = xtif87_Create_Grls( height, width, &rRed, &rGrn, &rBlu, samplesPerPixel );

    /* Deduce whether 0 in a pixel is black, white, or what: */
    if (!TIFFGetField(tif, TIFFTAG_PHOTOMETRIC, &photometric)) {
	switch (samplesPerPixel) {
	case 1:
	    photometric = PHOTOMETRIC_MINISBLACK;
	    break;
	case 3:
        case 4:
	    photometric = PHOTOMETRIC_RGB;
	    break;
	default:
	    TIFFError(
		filename,
		"Missing needed \"%s\" tag",
		"PhotometricInterpretation"
	    );
	    exit(-1);
	}
	TIFFError(
	    filename,
	    "No \"PhotometricInterpretation\" tag, assuming %s\n",
	    photometric == PHOTOMETRIC_RGB ? "RGB" : "min-is-black"
	);
    }


#ifdef ORIGINAL_CODE
    /* Use a full-color window if the image is */
    /* full color or a palette image and the   */
    /* hardware support is present.            */
    if (isRGB == -1) {
	isRGB = (
	    bitspersample >= 8 &&
	    (    photometric == PHOTOMETRIC_RGB ||
		 photometric == PHOTOMETRIC_PALETTE
            )
	);
    }
#else
    /* For xlisp/Skandha4, currently always want RGB: */
    isRGB = TRUE;
#endif

    if (!xtifa4_gt(tif, width, height, rRed, rGrn, rBlu))    exit(-1);

    TIFFClose(tif);

    /* Original code didn't seem to ever recycle BWMap or PALmap:  */
    if (BWmap  != NULL)   { free( BWmap);  BWmap=NULL; }
    if (PALmap != NULL)   { free(PALmap); PALmap=NULL; }
    xlpop();
    return result;
}

/* }}} */
/* {{{ xtifa2_checkCmap                                                     */

static int xtifa2_checkCmap( n, r, g, b )
int                          n;
U_short                        *r,*g,*b;
{
    while (n --> 0) {
	if (*r++ >= 256 || *g++ >= 256 || *b++ >= 256)   return 16;
    }
    TIFFWarning(filename, "Assuming 8-bit colormap");
    return 8;
}

/* {red,green,blue}_inverse are tables in libgutil.a that    */
/* do an inverse map from (r,g,b) to the closest colormap    */
/* index in the "standard" GL colormap.  grey_inverse is     */
/* the equivalent map for mapping greyscale values to        */
/* colormap indices.  We access these maps directly instead  */
/* of through the rgbi and greyi functions to avoid the      */
/* additional overhead of the color calls that they make.    */

/* }}} */
/* {{{ xtifa3_rgbi                                                          */

#ifdef SUPPORT_COLORMAP
static xtifa3_rgbi( r, g, b )
U_char              r, g, b;
{  return (
	r == g && g == b     ?
        grey_inverse[r]      :
	red_inverse[r] + green_inverse[g] + blue_inverse[b]
    );
}
#endif

/* }}} */
/* {{{ xtifa4_gt                                                            */

static xtifa4_gt( tif, w, h, rRed, rGrn, rBlu )
TIFF             *tif;
int                    w, h;
U_char                      *rRed,*rGrn,*rBlu;
{
    U_short   minSampleValue;
    U_short   maxSampleValue;
    U_short   planarConfig;
    U_char    *Map = NULL;
    int       e;

    if (!TIFFGetField(tif, TIFFTAG_MINSAMPLEVALUE, &minSampleValue)) {
	minSampleValue = 0;
    } 
    if (!TIFFGetField(tif, TIFFTAG_MAXSAMPLEVALUE, &maxSampleValue)) {
	maxSampleValue = (1<<bitspersample)-1;
    }
    Map = NULL;
    switch (photometric) {
    case PHOTOMETRIC_RGB:
	if (minSampleValue == 0 && maxSampleValue == 255)   break;
	/* FALL THRU... */
    case PHOTOMETRIC_MINISBLACK:
    case PHOTOMETRIC_MINISWHITE:
	{   register int x, range;

	    range = maxSampleValue - minSampleValue;
	    Map = (U_char*) malloc((range + 1) * sizeof(U_char));
	    if (Map == NULL) {
		TIFFError( filename, "No space for photometric conversion table");
		return 0;
	    }
	    if (photometric == PHOTOMETRIC_MINISWHITE) {
		for (x = 0; x <= range; x++) Map[x] = ((range - x) * 255) / range;
	    } else {
		for (x = 0; x <= range; x++) Map[x] = (         x  * 255) / range;
	    }
	    if (photometric != PHOTOMETRIC_RGB) {
		if (bitspersample != 8) {
		   /* Use photometric mapping table to construct */
		   /* unpacking tables for samples < 8 bits.     */
		   if (!xtifb0_makeBwMap(Map))   return 0;
		   /* No longer need Map, free it: */
		   free((char *)Map);
		   Map = NULL;
#ifdef SUPPORT_COLORMAP
		} else if (!isRGB) {
		    /* 8-bit greyscale image being displayed  */
		    /* in colormap mode.  Convert the mapping */
		    /* table to color indexes now so that the */
		    /* unpacking routines don't need to.      */
		    for (x = 0; x < 256; x++)   Map[x] = greyi(Map[x]);
#endif
	}   }	}
	break;

    case PHOTOMETRIC_PALETTE:
	if (
	    !TIFFGetField(tif, TIFFTAG_COLORMAP, &redCMap, &grnCMap, &bluCMap)
	) {
	    TIFFError(
		filename,
		"Missing required \"Colormap\" tag"
	    );
	    return 0;
	}

	/* Convert 16-bit colormap to 8-bit (unless it looks */
	/* like an old-style 8-bit colormap).		     */
	if (16 == xtifa2_checkCmap(
		1<<bitspersample,
		redCMap,
		grnCMap,
		bluCMap
	)   ) {
#define	CVT(x)		(((x) * 255) / ((1L<<16)-1))
	    int i;
	    for (i = (1 << bitspersample) -1;   i > 0;   i--) {
		redCMap[i] = CVT(redCMap[i]);
		grnCMap[i] = CVT(grnCMap[i]);
		bluCMap[i] = CVT(bluCMap[i]);
	    }
#undef	CVT
	}
	if (bitspersample <= 8) {
	    /* Use mapping table and colormap to construct */
	    /* unpacking tables for samples < 8 bits.      */
	    if (!xtifb1_makeCMap(redCMap, grnCMap, bluCMap))   return 0;
	}
	break;
    }

    TIFFGetField(tif, TIFFTAG_PLANARCONFIG, &planarConfig);
    if (planarConfig == PLANARCONFIG_SEPARATE   &&   samplesPerPixel > 1) {
	e = (TIFFIsTiled(          tif)		                     ?
	    xtifa7_gtTileSeparate( tif, rRed, rGrn, rBlu, Map, h, w) :
	    xtifa9_gtStripSeparate(tif, rRed, rGrn, rBlu, Map, h, w)
	);
    } else {
	e = (TIFFIsTiled(          tif)		                     ?
	    xtifa6_gtTileContig(   tif, rRed, rGrn, rBlu, Map, h, w) :
	    xtifa8_gtStripContig(  tif, rRed, rGrn, rBlu, Map, h, w)
	);
    }
    if (Map != NULL)   free((char*)Map);
    return e;
}

/* }}} */
/* {{{ xtifa5_setOrientation                                                */

U_long xtifa5_setOrientation(tif, h)
TIFF                        *tif;
U_long                            h;
{
    U_long y;

    if (!TIFFGetField(tif, TIFFTAG_ORIENTATION, &orientation)) {
	orientation = ORIENTATION_TOPLEFT;
    }
    switch (orientation) {
    case ORIENTATION_BOTRIGHT:
    case ORIENTATION_RIGHTBOT:	/* XXX */
    case ORIENTATION_LEFTBOT:	/* XXX */
	TIFFWarning(filename, "using bottom-left orientation");
	orientation = ORIENTATION_BOTLEFT;
	/* FALL THRU... */
    case ORIENTATION_BOTLEFT:
	y = 0;
	break;
    case ORIENTATION_TOPRIGHT:
    case ORIENTATION_RIGHTTOP:	/* XXX */
    case ORIENTATION_LEFTTOP:	/* XXX */
    default:
	TIFFWarning(filename, "using top-left orientation");
	orientation = ORIENTATION_TOPLEFT;
	/* FALL THRU... */
    case ORIENTATION_TOPLEFT:
	y = h-1;
	break;
    }
    return y;
}

typedef void (*tileContigRoutine)
    (U_char*,U_char*,U_char*, U_char*, U_char*, U_long, U_long, int, int);
static tileContigRoutine xtifc9_PickTileContigCase(U_char*);

/* }}} */
/* {{{ xtifa6_gtTileContig                                                  */

static xtifa6_gtTileContig(tif, rRed, rGrn, rBlu, Map, h, w)
TIFF                      *tif;
U_char                         *rRed,*rGrn,*rBlu;
U_char                                           *Map;
U_long                                                 h, w;
{   /* Get an tile-organized image that has                      */
    /*    PlanarConfiguration contiguous if SamplesPerPixel > 1  */
    /* or                                                        */
    /*    SamplesPerPixel == 1                                   */
    U_long            col, row, y;
    U_long            tw, th;
    U_char *          buf;
    int               fromSkew, toSkew;
    U_int             nrow;
    tileContigRoutine put;

    buf = (U_char*) malloc(TIFFTileSize(tif));
    if (buf == NULL) {
	TIFFError(filename, "No space for tile buffer");
	return 0;
    }
    put = xtifc9_PickTileContigCase(Map);
    TIFFGetField(tif, TIFFTAG_TILEWIDTH, &tw);
    TIFFGetField(tif, TIFFTAG_TILELENGTH, &th);
    y = xtifa5_setOrientation(tif, h);
    toSkew = (orientation == ORIENTATION_TOPLEFT ? -tw + -w : -tw + w);
    for (row = 0; row < h; row += th) {
	nrow = (row + th > h ? h - row : th);
	for (col = 0; col < w; col += tw) {
	    if (TIFFReadTile(tif, buf, col, row, 0, 0) < 0)   break;
	    if (col + tw > w) {
		/* Tile is clipped horizontally.  Calculate */
		/* visible portion and skewing factors.     */
		U_long npix = w - col;
		fromSkew = tw - npix;
		(*put)(
		    rRed + y*w + col,
		    rGrn + y*w + col,
		    rBlu + y*w + col,
		    buf,
		    Map,
		    npix,
		    nrow,
		    fromSkew,
		    toSkew + fromSkew
		);
	    } else {
		(*put)(
		    rRed + y*w + col,
		    rGrn + y*w + col,
		    rBlu + y*w + col,
		    buf,
		    Map,
		    tw,
		    nrow,
		    0,
		    toSkew
		);
    }	}   }
    free(buf);
    return 1;
}

typedef void (*tileSeparateRoutine)
    (U_char*,U_char*,U_char*,
     U_char*,U_char*,U_char*, U_char*, U_long, U_long, int, int);
static tileSeparateRoutine xtifd0_PickTileSeparateCase(U_char*);

/* }}} */
/* {{{ xtifa7_gtTileSeparate                                                */

static xtifa7_gtTileSeparate(tif, rRed, rGrn, rBlu, Map, h, w)
TIFF                        *tif;
U_char                           *rRed,*rGrn,*rBlu;
U_char                                             *Map;
U_long                                                   h, w;
{
    /* Get an tile-organized image that has    */
    /*     SamplesPerPixel > 1                 */
    /*     PlanarConfiguration separated       */
    /* We assume that all such images are RGB. */
    U_long col, row, y;
    U_long tw, th;
    U_char *buf;
    U_char *r, *g, *b;
    int                 tilesize;
    int                 fromSkew, toSkew;
    U_int               nrow;
    tileSeparateRoutine put;

    tilesize = TIFFTileSize(tif);
    buf      = (U_char*) malloc( 3 * tilesize );
    if (buf == NULL) {
	TIFFError(filename, "No space for tile buffer");
	return 0;
    }
    r = buf;
    g = r + tilesize;
    b = g + tilesize;
    put = xtifd0_PickTileSeparateCase(Map);
    TIFFGetField(tif, TIFFTAG_TILEWIDTH,  &tw);
    TIFFGetField(tif, TIFFTAG_TILELENGTH, &th);
    y = xtifa5_setOrientation(tif, h);
    toSkew = (orientation == ORIENTATION_TOPLEFT ? -tw + -w : -tw + w);
    for (row = 0; row < h; row += th) {
	nrow = (row + th > h ? h - row : th);
	for (col = 0; col < w; col += tw) {
	    if (TIFFReadTile(tif, r, col, row, 0, 0) < 0)   break;
	    if (TIFFReadTile(tif, g, col, row, 0, 1) < 0)   break;
	    if (TIFFReadTile(tif, b, col, row, 0, 2) < 0)   break;
	    if (col + tw > w) {
		/* Tile is clipped horizontally.  Calculate */
		/* visible portion and skewing factors.     */
		U_long npix = w - col;
		fromSkew = tw - npix;
		(*put)(
		    rRed + y*w + col,
		    rGrn + y*w + col,
		    rBlu + y*w + col,
		    r, g, b,
		    Map,
		    npix,
		    nrow,
		    fromSkew,
		    toSkew + fromSkew
		);
	    } else {
		(*put)(
		    rRed + y*w + col,
		    rGrn + y*w + col,
		    rBlu + y*w + col,
		    r, g, b,
		    Map,
		    tw,
		    nrow,
		    0,
		    toSkew
		);
    }	}   }
    free(buf);
    return 1;
}

/* }}} */
/* {{{ xtifa8_gtStripContig                                                 */

static xtifa8_gtStripContig(tif, rRed, rGrn, rBlu, Map, h, w)
TIFF                       *tif;
U_char                          *rRed,*rGrn,*rBlu;
U_char                                            *Map;
U_long                                                  h, w;
{
    /* Get a strip-organized image that has                      */
    /*    PlanarConfiguration contiguous if SamplesPerPixel > 1  */
    /* or                                                        */
    /*    SamplesPerPixel == 1                                   */
    U_long            row, y, nrow;
    U_char           *buf;
    tileContigRoutine put;
    U_long            rowsperstrip = (U_long) -1L;
    U_long            imagewidth;
    int               scanline;
    int               fromSkew, toSkew;

    buf = (U_char*) malloc( TIFFStripSize(tif) );
    if (buf == NULL) {
	TIFFError(filename, "No space for strip buffer");
	return 0;
    }
    put = xtifc9_PickTileContigCase(Map);
    y = xtifa5_setOrientation(tif, h);
    toSkew = (orientation == ORIENTATION_TOPLEFT ? -w + -w : -w + w);
    TIFFGetField(tif, TIFFTAG_ROWSPERSTRIP, &rowsperstrip);
    TIFFGetField(tif, TIFFTAG_IMAGEWIDTH,   &imagewidth  );
    scanline = TIFFScanlineSize(tif);
    fromSkew = (w < imagewidth ? imagewidth - w : 0);
    for (row = 0; row < h; row += rowsperstrip) {
	int outloc = y*w + row*(w+toSkew);	/* Last term is 93Nov17jsp addition. */
	nrow = (row + rowsperstrip > h ? h - row : rowsperstrip);
	if (TIFFReadEncodedStrip(
		tif,
		TIFFComputeStrip(tif, row, 0),
		buf,
		nrow*scanline
	    ) < 0
	) {
	    break;
	}
	(*put)(
	    rRed + outloc,
	    rGrn + outloc,
	    rBlu + outloc,
	    buf,
	    Map,
	    w,
	    nrow,
	    fromSkew,
	    toSkew
	);
    }
    free(buf);
    return 1;
}

/* }}} */
/* {{{ xtifa9_gtStripSeparate                                               */

static xtifa9_gtStripSeparate(tif, rRed, rGrn, rBlu, Map, h, w)
TIFF                         *tif;
U_char                            *rRed,*rGrn,*rBlu;
register U_char                                     *Map;
U_long                                                    h, w;
{
    /* Get a strip-organized image with        */
    /*     SamplesPerPixel > 1                 */
    /*     PlanarConfiguration separated       */
    /* We assume that all such images are RGB. */
    U_char              *buf;
    U_char              *r, *g, *b;
    U_long              row, y, nrow;
    int                 scanline;
    tileSeparateRoutine put;
    U_long              rowsperstrip = (U_long) -1L;
    U_long              imagewidth;
    U_int               stripsize;
    int                 fromSkew, toSkew;

    stripsize = TIFFStripSize(tif);

    r         = buf = (U_char*) malloc( 3 * stripsize );
    g         = r + stripsize;
    b         = g + stripsize;

    put       = xtifd0_PickTileSeparateCase(Map);
    y         = xtifa5_setOrientation(tif, h);
    toSkew    = (orientation == ORIENTATION_TOPLEFT  ?  -w + -w  :  -w + w);

    TIFFGetField(tif, TIFFTAG_ROWSPERSTRIP, &rowsperstrip);
    TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &imagewidth);

    scanline = TIFFScanlineSize(tif);
    fromSkew = (w < imagewidth   ?   imagewidth - w   :   0);

    for (row = 0; row < h; row += rowsperstrip) {
	int outloc = y*w + row*(w+toSkew);	/* Last term is 93Nov17jsp addition. */
	nrow = (row + rowsperstrip > h ? h - row : rowsperstrip);
	if (TIFFReadEncodedStrip(
		tif, TIFFComputeStrip(tif, row, 0), r, nrow*scanline
	    ) < 0
	) {
	    break;
	}
	if (TIFFReadEncodedStrip(
		tif, TIFFComputeStrip(tif, row, 1), g, nrow*scanline
	    ) < 0
	) {
	    break;
	}
	if (TIFFReadEncodedStrip(
		tif, TIFFComputeStrip(tif, row, 2), b, nrow*scanline
	    ) < 0
	) {
	    break;
	}
	(*put)(
	    rRed + outloc,
	    rGrn + outloc,
	    rBlu + outloc,
	    r, g, b,
	    Map,
	    w,
	    nrow,
	    fromSkew,
	    toSkew
	);
    }
    free(buf);
    return 1;
}

#define	PACK(r,g,b)	(r)|((g)<<8)|((b)<<16)
#define	RED(i)		(((i)    )&0xFF)
#define	GRN(i)		(((i)>> 8)&0xFF)
#define	BLU(i)		(((i)>>16)&0xFF)
#define	UNPACK(r,g,b,x)	{U_long qq=(x);(r)=RED(qq);(g)=GRN(qq);(b)=BLU(qq);}

/* }}} */
/* {{{ xtifb0_makeBwMap                                                     */

xtifb0_makeBwMap(Map)
U_char          *Map;
{
    /* Greyscale images with less than 8 bits/sample are handled         */
    /* with a table to avoid lots of shifts and masks.  The table        */
    /* is set up so that put*bwtile (below) can retrieve 8/bitspersample */
    /* pixel values simply by indexing into the table with one number.   */
    register int i;
    int nsamples = 8 / bitspersample;
    register U_char *p;

    BWmap = (U_char**) malloc(
	256 * sizeof(U_char*) + (256 * nsamples * sizeof(U_char))
    );
    if (BWmap == NULL) {
	TIFFError(filename, "No space for B&W mapping table");
	return 0;
    }
    p = (U_char*) (BWmap + 256);
    if (isRGB) {
	for (i = 0; i < 256; i++) {
	    BWmap[i] = p;
	    switch (bitspersample) {
		register U_char c;
#define	GREY(x)	c = Map[x]; *p++ = PACK(c,c,c);
	    case 1:
		GREY(i>>7);
		GREY((i>>6)&1);
		GREY((i>>5)&1);
		GREY((i>>4)&1);
		GREY((i>>3)&1);
		GREY((i>>2)&1);
		GREY((i>>1)&1);
		GREY(i&1);
		break;
	    case 2:
		GREY(i>>6);
		GREY((i>>4)&3);
		GREY((i>>2)&3);
		GREY(i&3);
		break;
	    case 4:
		GREY(i>>4);
		GREY(i&0xf);
		break;
#undef	GREY
	}   }
    } else {
#ifdef SUPPORT_COLORMAP
	for (i = 0; i < 256; i++) {
	    BWmap[i] = p;
	    switch (bitspersample) {
#define	GREY(x)	*p++ = greyi(Map[x]);
	    case 1:
		GREY(i>>7);
		GREY((i>>6)&1);
		GREY((i>>5)&1);
		GREY((i>>4)&1);
		GREY((i>>3)&1);
		GREY((i>>2)&1);
		GREY((i>>1)&1);
		GREY(i&1);
		break;
	    case 2:
		GREY(i>>6);
		GREY((i>>4)&3);
		GREY((i>>2)&3);
		GREY(i&3);
		break;
	    case 4:
		GREY(i>>4);
		GREY(i&0xf);
		break;
#undef	GREY
    	}    }
#endif
    }
    return 1;
}

/* }}} */
/* {{{ xtifb1_makeCMap                                                      */

xtifb1_makeCMap(rmap, gmap, bmap)
U_short        *rmap,*gmap,*bmap;
{
    /* Palette images with <= 8 bits/sample are handled                    */
    /* with a table to avoid lots of shifts and masks.  The table          */
    /* is set up so that put*cmaptile (below) can retrieve 8/bitspersample */
    /* pixel values simply by indexing into the table with one number.     */
    register int i;
    int nsamples = 8 / bitspersample;
    register U_long *p;

    PALmap = (U_long**)malloc(
	256*sizeof (U_long *)+(256*nsamples*sizeof(U_long))
    );
    if (PALmap == NULL) {
	TIFFError(filename, "No space for Palette mapping table");
	return 0;
    }
    p = (U_long *)(PALmap + 256);
    if (isRGB) {
	for (i = 0; i < 256; i++) {
	    PALmap[i] = p;
#define	CMAP(x)	\
    c = x; *p++ = PACK(rmap[c], gmap[c], bmap[c]);
	    switch (bitspersample) {
		register U_char c;
	    case 1:
		CMAP( i>>7   );
		CMAP((i>>6)&1);
		CMAP((i>>5)&1);
		CMAP((i>>4)&1);
		CMAP((i>>3)&1);
		CMAP((i>>2)&1);
		CMAP((i>>1)&1);
		CMAP(i&1);
		break;
	    case 2:
		CMAP( i>>6   );
		CMAP((i>>4)&3);
		CMAP((i>>2)&3);
		CMAP( i    &3);
		break;
	    case 4:
		CMAP(i>>4);
		CMAP(i & 0xf);
		break;
	    case 8:
		CMAP(i);
		break;
#undef CMAP
	}   }
    } else {
#ifdef SUPPORT_COLORMAP
	for (i = 0; i < 256; i++) {
	    PALmap[i] = p;
#define	CMAP(x)	\
    c = x; *p++ = xtifa3_rgbi(rmap[c], gmap[c], bmap[c]);
	    switch (bitspersample) {
		register U_char c;
	    case 1:
		CMAP( i>>7   );
		CMAP((i>>6)&1);
		CMAP((i>>5)&1);
		CMAP((i>>4)&1);
		CMAP((i>>3)&1);
		CMAP((i>>2)&1);
		CMAP((i>>1)&1);
		CMAP( i    &1);
		break;
	    case 2:
		CMAP(i>>6);
		CMAP((i>>4)&3);
		CMAP((i>>2)&3);
		CMAP(i&3);
		break;
	    case 4:
		CMAP(i>>4);
		CMAP(i&0xf);
		break;
	    case 8:
		CMAP(i);
		break;
#undef CMAP
    	}   }
#endif
    }
    return 1;
}

/* The following routines move decoded data returned      */
/* from the TIFF library into rasters that are suitable   */
/* for passing to lrecwrite.  They do the necessary       */
/* conversions based on whether the drawing mode is RGB   */
/* colormap and whether or not there is a mapping table.  */
/*                                                        */
/* The routines have been created according to the most   */
/* important cases and optimized.  xtifc9_PickTileContigCase and */
/* xtifd0_PickTileSeparateCase analyze the parameters and select */
/* the appropriate "put" routine to use.                  */
#define	REPEAT8(op)	REPEAT4(op); REPEAT4(op)
#define	REPEAT4(op)	REPEAT2(op); REPEAT2(op)
#define	REPEAT2(op)	op; op
#define	CASE8(x,op)				\
	switch (x) {				\
	case 7: op; case 6: op; case 5: op;	\
	case 4: op; case 3: op; case 2: op;	\
	case 1: op;				\
	}
#define	CASE4(x,op)	switch (x) { case 3: op; case 2: op; case 1: op; }

#define	UNROLL8(w, op1, op2) {		\
	register U_long x;		\
	for (x = w; x >= 8; x -= 8) {	\
		op1;			\
		REPEAT8(op2);		\
	}				\
	if (x > 0) {			\
		op1;			\
		CASE8(x,op2);		\
	}				\
}
#define	UNROLL4(w, op1, op2) {		\
	register U_long x;		\
	for (x = w; x >= 4; x -= 4) {	\
		op1;			\
		REPEAT4(op2);		\
	}				\
	if (x > 0) {			\
		op1;			\
		CASE4(x,op2);		\
	}				\
}
#define	UNROLL2(w, op1, op2) {		\
	register U_long x;		\
	for (x = w; x >= 2; x -= 2) {	\
		op1;			\
		REPEAT2(op2);		\
	}				\
	if (x) {			\
		op1;			\
		op2;			\
	}				\
}

/* }}} */
#define	SKEW(r,g,b,skew)	{ r += skew; g += skew; b += skew; }
/* {{{ xtifb2_PutContig_8BitTile   8-bit packed samples -> colormap         */

#ifdef SUPPORT_COLORMAP
static void xtifb2_PutContig_8BitTile(cp, pp, Map, w, h, fromSkew, toSkew)
register U_long                      *cp;
register U_char                          *pp;
register U_char                              *Map;
U_long                                             w, h;
int                                                      fromSkew, toSkew;
{   register U_long x;
    if (Map != NULL) {
	while (h --> 0) {
	    for (x = w;   x --> 0;) {
		*cp++ = xtifa3_rgbi(Map[pp[0]], Map[pp[1]], Map[pp[2]]);
		pp += samplesPerPixel;
	    }
	    cp += toSkew;
	    pp += fromSkew;
	}
    } else {
	while (h --> 0) {
	    for (x = w;   x --> 0;) {
		*cp++ = xtifa3_rgbi(pp[0], pp[1], pp[2]);
		pp += samplesPerPixel;
	    }
	    cp += toSkew;
	    pp += fromSkew;
    }	}
}
#endif

/* }}} */
/* {{{ xtifb3_PutContig16BitTile   16-bit packed samples -> colormap        */

#ifdef SUPPORT_COLORMAP
static void xtifb3_PutContig16BitTile(cp, pp, Map, w, h, fromSkew, toSkew)
register U_long                      *cp;
register U_short                         *pp;
register U_char                              *Map;
U_long                                             w, h;
int                                                      fromSkew, toSkew;
{   register U_long x;
    if (Map != NULL) {
	while (h --> 0) {
	    for (x = w; x --> 0;) {
		*cp++ = xtifa3_rgbi(Map[pp[0]], Map[pp[1]], Map[pp[2]]);
		pp += samplesPerPixel;
	    }
	    cp += toSkew;
	    pp += fromSkew;
	}
    } else {
	while (h --> 0) {
	    for (x = w; x --> 0;) {
		*cp++ = xtifa3_rgbi(pp[0], pp[1], pp[2]);
		pp += samplesPerPixel;
	    }
	    cp += toSkew;
	    pp += fromSkew;
    }	}
}
#endif

/* }}} */
/* {{{ xtifb4_PutSeparate_8BitTile   8-bit unpacked samples -> colormap     */

#ifdef SUPPORT_COLORMAP
static void xtifb4_PutSeparate_8BitTile(cp, r, g, b, Map, w, h, fromSkew, toSkew)
register U_long                        *cp;
register U_char                            *r,*g,*b;
register U_char                                     *Map;
U_long                                                    w, h;
int                                                             fromSkew, toSkew;
{   register U_long x;
    if (Map != NULL) {
	while (h --> 0) {
	    for (x = w; x --> 0;) *cp++ = xtifa3_rgbi(Map[*r++], Map[*g++], Map[*b++]);
	    SKEW(r, g, b, fromSkew);
	    cp += toSkew;
	}
    } else {
	while (h --> 0) {
	    for (x = w; x --> 0;) *cp++ = xtifa3_rgbi(*r++, *g++, *b++);
	    SKEW(r, g, b, fromSkew);
	    cp += toSkew;
    }	}
}
#endif

/* }}} */
/* {{{ xtifb5_PutSeparate16BitTile   16-bit unpacked samples -> colormap    */

#ifdef SUPPORT_COLORMAP
static void xtifb5_PutSeparate16BitTile(cp, r, g, b, Map, w, h, fromSkew, toSkew)
register U_long                        *cp;
register U_short                           *r,*g,*b;
register U_char                                     *Map;
U_long                                                    w, h;
int                                                             fromSkew, toSkew;
{   register U_long x;
    if (Map != NULL) {
	while (h --> 0) {
	    for (x = 0; x < w; x++) *cp++ = xtifa3_rgbi(Map[*r++], Map[*g++], Map[*b++]);
	    SKEW(r, g, b, fromSkew);
	    cp += toSkew;
	}
   } else {
	while (h --> 0) {
	    for (x = 0; x < w; x++) *cp++ = xtifa3_rgbi(*r++, *g++, *b++);
	    SKEW(r, g, b, fromSkew);
	    cp += toSkew;
    }	}
}
#endif

/* }}} */
/* {{{ xtifb6_Put8BitCMapTile   8-bit palette -> colormap/RGB               */

static void xtifb6_Put8BitCMapTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
register U_char                   *r,*g,*b;
register U_char                            *pp;
U_char                                         *Map;
U_long                                               w, h;
int                                                        fromSkew, toSkew;
{   while (h --> 0) {
	/* The '1' just suppresses 'null argument' warnings from compilers.*/
	UNROLL8(w,1,UNPACK(*r++,*g++,*b++,PALmap[*pp++][0]));
	r  += toSkew;
	g  += toSkew;
	b  += toSkew;
	pp += fromSkew;
    }
}

/* }}} */
/* {{{ xtifb7_Put4BitCMapTile   5-bit palette -> colormap/RGB               */

static void xtifb7_Put4BitCMapTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
register U_char                   *r,*g,*b;
register U_char                            *pp;
register U_char                                *Map;
U_long                                               w, h;
int                                                        fromSkew, toSkew;
{   register U_long *bw;
    fromSkew /= 2;
    while (h --> 0) {
	UNROLL2(w, bw = PALmap[*pp++], UNPACK(*r++,*g++,*b++,*bw++));
	r  += toSkew;
	g  += toSkew;
	b  += toSkew;
	pp += fromSkew;
    }
}

/* }}} */
/* {{{ xtifb8_Put2BitCMapTile   2-bit palette -> colormap/RGB               */

static void xtifb8_Put2BitCMapTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
register U_char                   *r,*g,*b;
register U_char                            *pp;
register U_char                                *Map;
U_long                                               w, h;
int                                                        fromSkew, toSkew;
{   register U_long *bw;
    fromSkew /= 4;
    while (h --> 0) {
	UNROLL4(w, bw = PALmap[*pp++], UNPACK(*r++,*g++,*b++,*bw++));
	r  += toSkew;
	g  += toSkew;
	b  += toSkew;
	pp += fromSkew;
    }
}

/* }}} */
/* {{{ xtifb9_Put1BitCMapTile   1-bit palette -> colormap/RGB               */

static void xtifb9_Put1BitCMapTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
register U_char                   *r,*g,*b;
register U_char                            *pp;
register U_char                                *Map;
U_long                                               w, h;
int                                                        fromSkew, toSkew;
{   register U_long *bw;
    fromSkew /= 8;
    while (h --> 0) {
	UNROLL8(w, bw = PALmap[*pp++], UNPACK(*r++,*g++,*b++,*bw++));
	r  += toSkew;
	g  += toSkew;
	b  += toSkew;
	pp += fromSkew;
    }
}

/* }}} */
/* {{{ xtifc0_PutGreyTile   8-bit greyscale -> colormap                     */

static void xtifc0_PutGreyTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
register U_char               *r,*g,*b;
register U_char                        *pp;
register U_char                            *Map;
U_long                                           w, h;
int                                                    fromSkew, toSkew;
{   while (h --> 0) {
	register U_long x;
	for (x = w; x --> 0;)   UNPACK(*r++,*g++,*b++,Map[*pp++]);
	r  += toSkew;
	g  += toSkew;
	b  += toSkew;
	pp += fromSkew;
    }
}

/* }}} */
/* {{{ xtifc1_Put1BitBWTile   1-bit bilevel -> colormap/RGB                 */

static void xtifc1_Put1BitBWTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
U_char                          *r,*g,*b;
U_char                                   *pp;
U_char                                      **Map;
U_long                                             w, h;
int                                                      fromSkew, toSkew;
{   register U_char *bw;
    fromSkew /= 8;
    while (h --> 0) {
	UNROLL8(w, bw = BWmap[*pp++], UNPACK(*r++,*g++,*b++,*bw++));
	r  += toSkew;
	g  += toSkew;
	b  += toSkew;
	pp += fromSkew;
    }
}

/* }}} */
/* {{{ xtifc2_Put2BitBWTile   2-bit greyscale -> colormap/RGB               */

static void xtifc2_Put2BitBWTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
U_char                          *r,*g,*b;
U_char                                   *pp;
U_char                                      **Map;
U_long                                             w, h;
int                                                      fromSkew, toSkew;
{   register U_char *bw;
    fromSkew /= 4;
    while (h --> 0) {
	UNROLL4(w, bw = BWmap[*pp++], UNPACK(*r++,*g++,*b++,*bw++));
	r  += toSkew;
	g  += toSkew;
	b  += toSkew;
	pp += fromSkew;
    }
}

/* }}} */
/* {{{ xtifc3_Put4BitBWTile   4-bit greyscale -> colormap/RGB               */

static void xtifc3_Put4BitBWTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
U_char                          *r,*g,*b;
U_char                                   *pp;
U_char                                      **Map;
U_long                                             w, h;
int                                                      fromSkew, toSkew;
{   register U_char *bw;
    fromSkew /= 2;
    while (h --> 0) {
	UNROLL2(w, bw = BWmap[*pp++], UNPACK(*r++,*g++,*b++,*bw++));
	r  += toSkew;
	g  += toSkew;
	b  += toSkew;
	pp += fromSkew;
    }
}

/* }}} */
/* {{{ xtifc4_PutRgbContig_8BitTile   8-bit packed samples -> RGB           */

static void xtifc4_PutRgbContig_8BitTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
register U_char                         *r,*g,*b;
register U_char                                  *pp;
register U_char                                      *Map;
U_long                                                     w, h;
int                                                              fromSkew, toSkew;
{
    if (Map != NULL) {
	while (h --> 0) {
	    register U_long x;
	    for (x = w; x --> 0;) {
		*r++ = Map[pp[0]];
		*g++ = Map[pp[1]];
		*b++ = Map[pp[2]];
		pp += samplesPerPixel;
	    }
	    r  += toSkew;
	    g  += toSkew;
	    b  += toSkew;
	    pp += fromSkew;
	}
   } else {
	while (h --> 0) {
	    /* '1' is just to cut down on "null arg" warnings from compilers: */
	    UNROLL8(w,1, {*r++=pp[0];*g++=pp[1];*b++=pp[2];}pp+=samplesPerPixel; );
	    r  += toSkew;
	    g  += toSkew;
	    b  += toSkew;
	    pp += fromSkew;
    }	}
}

/* }}} */
/* {{{ xtifc5_PutRgbContig16BitTile   16-bit packed samples -> RGB          */

static void xtifc5_PutRgbContig16BitTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
register U_char                         *r,*g,*b;
register U_short                                 *pp;
register U_char                                      *Map;
U_long                                                     w, h;
int                                                              fromSkew, toSkew;
{   register U_int x;
    if (Map != NULL) {
	while (h --> 0) {
	    for (x = w; x --> 0;) {
		*r++ = Map[pp[0]];
		*g++ = Map[pp[1]];
		*b++ = Map[pp[2]];
		pp += samplesPerPixel;
	    }
	    r  += toSkew;
	    g  += toSkew;
	    b  += toSkew;
	    pp += fromSkew;
	}
    } else {
	while (h --> 0) {
	    for (x = w; x --> 0;) {
		*r++ = pp[0];
		*g++ = pp[1];
		*b++ = pp[2];
		pp += samplesPerPixel;
	    }
	    r  += toSkew;
	    g  += toSkew;
	    b  += toSkew;
	    pp += fromSkew;
    }	}
}

/* }}} */
/* {{{ xtifc6_PutRgbSeparate_8BitTile   8-bit unpacked samples -> RGB       */

static void xtifc6_PutRgbSeparate_8BitTile(R, G, B, r, g, b, Map, w, h, fromSkew, toSkew)
register U_char                           *R,*G,*B;
register U_char                                    *r,*g,*b;
register U_char                                             *Map;
U_long                                                            w, h;
int                                                                     fromSkew, toSkew;
{   if (Map != NULL) {
	while (h --> 0) {
	    register U_long x;
	    for (x = w; x > 0; x--) {
		*R++ = *r++;
		*G++ = *g++;
		*B++ = *b++;
	    }
	    SKEW(r, g, b, fromSkew);
	    R += toSkew;
	    G += toSkew;
	    B += toSkew;
    }   } else {
	while (h --> 0) {
	    /* '1' is just to cut down on 'null arg' compiler warnings */
	    UNROLL8(w,1, {*R++ = *r++; *G++ = *g++; *B++ = *b++;});
	    SKEW(r, g, b, fromSkew);
	    R += toSkew;
	    G += toSkew;
	    B += toSkew;
    }	}
}

/* }}} */
/* {{{ xtifc7_PutRgbSeparate16BitTile   16-bit unpacked samples -> RGB      */

static void xtifc7_PutRgbSeparate16BitTile(R, G, B, r, g, b, Map, w, h, fromSkew, toSkew)
register U_char                           *R,*G,*B;
register U_short                                   *r,*g,*b;
register U_char                                             *Map;
U_long                                                            w, h;
int                                                                     fromSkew, toSkew;
{   register U_long x;
    if (Map != NULL) {
	while (h --> 0) {
	    for (x = w; x > 0; x--) {
		*R++ = Map[*r++];
		*G++ = Map[*g++];
		*B++ = Map[*b++];
	    }
	    SKEW(r, g, b, fromSkew);
	    R += toSkew;
	    G += toSkew;
	    B += toSkew;
	}
    } else {
	while (h --> 0) {
	    for (x = 0; x < w; x++) {
		*R++ = *r++;
		*G++ = *g++;
		*B++ = *b++;
	    }
	    SKEW(r, g, b, fromSkew);
	    R += toSkew;
	    G += toSkew;
	    B += toSkew;
    }	}
}

/* }}} */
/* {{{ xtifc8_PutRgbGreyTile   8-bit greyscale -> RGB                       */

static void xtifc8_PutRgbGreyTile(r, g, b, pp, Map, w, h, fromSkew, toSkew)
register U_char                  *r,*g,*b;
register U_char                           *pp;
register U_char                               *Map;
U_long                                              w, h;
int                                                       fromSkew, toSkew;
{
    while (h --> 0) {
	register U_long x;
	for (x = w;   x --> 0;) {
	    U_char c = Map[*pp++];
	    *r++ = c;
	    *g++ = c;
	    *b++ = c;
	}
	r  += toSkew;
	g  += toSkew;
	b  += toSkew;
	pp += fromSkew;
    }
}

/* }}} */
/* {{{ xtifc9_PickTileContigCase   Pick conversion fn for packed data.      */

static tileContigRoutine xtifc9_PickTileContigCase( Map )
U_char                                             *Map;
{   tileContigRoutine put = 0;
    if (isRGB) {
	switch (photometric) {
	case PHOTOMETRIC_RGB:
	    put = (
		bitspersample == 8           ?
		(tileContigRoutine) xtifc4_PutRgbContig_8BitTile :
		(tileContigRoutine) xtifc5_PutRgbContig16BitTile
	    );
	    break;
	case PHOTOMETRIC_PALETTE:
	    switch (bitspersample) {
	    case 8: put = (tileContigRoutine) xtifb6_Put8BitCMapTile; break;
	    case 4: put = (tileContigRoutine) xtifb7_Put4BitCMapTile; break;
	    case 2: put = (tileContigRoutine) xtifb8_Put2BitCMapTile; break;
	    case 1: put = (tileContigRoutine) xtifb9_Put1BitCMapTile; break;
	    }
	    break;
	case PHOTOMETRIC_MINISWHITE:
	case PHOTOMETRIC_MINISBLACK:
	    switch (bitspersample) {
	    case 8: put = (tileContigRoutine) xtifc8_PutRgbGreyTile; break;
	    case 4: put = (tileContigRoutine) xtifc3_Put4BitBWTile ; break;
	    case 2: put = (tileContigRoutine) xtifc2_Put2BitBWTile ; break;
	    case 1: put = (tileContigRoutine) xtifc1_Put1BitBWTile ; break;
	    }
	    break;
	}
    } else {
#ifdef SUPPORT_COLORMAP
	switch (photometric) {
	case PHOTOMETRIC_RGB:
	    put = (
		bitspersample == 8                            ?
		(tileContigRoutine) xtifb2_PutContig_8BitTile :
		(tileContigRoutine)  xtifb3_PutContig16BitTile
	    );
	    break;
	case PHOTOMETRIC_PALETTE:
	    switch (bitspersample) {
	    case 8: put = (tileContigRoutine) xtifb6_Put8BitCMapTile; break;
	    case 4: put = (tileContigRoutine) xtifb7_Put4BitCMapTile; break;
	    case 2: put = (tileContigRoutine) xtifb8_Put2BitCMapTile; break;
	    case 1: put = (tileContigRoutine) xtifb9_Put1BitCMapTile; break;
	    }
	    break;
	case PHOTOMETRIC_MINISWHITE:
	case PHOTOMETRIC_MINISBLACK:
	    switch (bitspersample) {
	    case 8: put = (tileContigRoutine) xtifc0_PutGreyTile  ; break;
	    case 4: put = (tileContigRoutine) xtifc3_Put4BitBWTile; break;
	    case 2: put = (tileContigRoutine) xtifc2_Put2BitBWTile; break;
	    case 1: put = (tileContigRoutine) xtifc1_Put1BitBWTile; break;
	    }
	    break;
    	}
#endif
    }
    return put;
}

/* }}} */
/* {{{ xtifd0_PickTileSeparateCase					      */

static tileSeparateRoutine xtifd0_PickTileSeparateCase( Map )
U_char                                                 *Map;
{   /* Select the appropriate conversion routine for unpacked data. */
    /* NB: we assume that unpacked single channel data is directed  */
    /*     to the "packed" routines.                                */
    tileSeparateRoutine put = NULL;
    if (isRGB) {
	put = (
	    bitspersample == 8                                   ?
	    (tileSeparateRoutine) xtifc6_PutRgbSeparate_8BitTile :
	    (tileSeparateRoutine) xtifc7_PutRgbSeparate16BitTile
	);
    } else {
#ifdef SUPPORT_COLORMAP
	put = (
	    bitspersample == 8                                   ?
	    (tileSeparateRoutine) xtifb4_PutSeparate_8BitTile    :
	    (tileSeparateRoutine) xtifb5_PutSeparate16BitTile
	);
#endif
    }
    return put;
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
