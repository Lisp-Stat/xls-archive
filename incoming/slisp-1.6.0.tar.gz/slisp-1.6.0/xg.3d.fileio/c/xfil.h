/* {{{ xfil.h -- Native lisp-level I/O support.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Apr26
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xfil;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xfil00_Is_New();
extern LVAL xfil03_Show_Msg();
extern LVAL xfil08_Copy_Msg();
extern LVAL xfil22_Expand_XfilRefs_Fn();
extern LVAL xfil23_Xfil_Ref_Fn();
extern LVAL xfil35_Set_File_Info_Msg();
extern LVAL xfil40_Get_Msg();
extern LVAL xfil42_Put_Msg();
extern LVAL xfil44_Set_Instance_Variable_Msg();
extern LVAL xfil46_Set_Anonymous_Variable_Msg();
extern LVAL xfil57_Get_Name_Of_Current_Graphics_File_Fn();
extern LVAL xfil58_Set_Current_Graphics_File_Fn();
extern LVAL xfil59_Get_Names_Of_Loaded_Graphics_Files_Fn();
extern LVAL xfil68_Save_Graphics_File_Fn();
extern LVAL xfil72_Write_Sexp_To_File_Fn();
extern LVAL xfil82_Load_Graphics_File_Fn();
extern LVAL xfil84_Unload_Graphics_File_Fn();
extern LVAL xfil91_ProplistLength_Msg();
extern LVAL xfil95_ProplistNth_Msg();
extern LVAL xfila1_Debug_Printout_Fn();

#ifndef EXTERNED_TRANSFORM
extern LVAL k_name;   /* Keyword ":name" */
#define EXTERNED_TRANSFORM
#endif

#ifndef EXTERNED_S_XFILTHIS
extern LVAL s_xfilthis;/* Symbol "XFIL-THIS" */
#define EXTERNED_S_XFILTHIS
#endif

#ifndef EXTERNED_S_XFILFD
extern LVAL s_xfilfd;/* Symbol "XFIL-FD" */
#define EXTERNED_S_XFILFD
#endif

#ifndef EXTERNED_S_XFILFDBINARY
extern LVAL s_xfilfdbinary;/* Symbol "XFIL-FD-BINARY" */
#define EXTERNED_S_XFILFDBINARY
#endif

#ifndef EXTERNED_S_XFILREF
extern LVAL s_xfilref;/* Symbol "XFIL-REF" */
#define EXTERNED_S_XFILREF
#endif

#ifndef EXTERNED_S_OBJECTLIST
extern LVAL s_objectlist;/* Symbol "OBJECT-LIST" */
#define EXTERNED_S_OBJECTLIST
#endif

#ifndef EXTERNED_S_FILELIST
extern LVAL s_filelist;/* Symbol "FILE-LIST" */
#define EXTERNED_S_FILELIST
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Most have NULL names because they are provided only as */
/* messages, not as xlisp functions:                      */
DEFINE_SUBR(	NULL,				xfil00_Is_New			)
DEFINE_SUBR(	NULL,				xfil03_Show_Msg			)
DEFINE_SUBR(	NULL,				xfil08_Copy_Msg			)
DEFINE_SUBR(	"XFIL-EXPAND",			xfil22_Expand_XfilRefs_Fn	)
DEFINE_SUBR(    "XFIL-REF",			xfil23_Xfil_Ref_Fn		)
DEFINE_SUBR(	NULL,				xfil40_Get_Msg			)
DEFINE_SUBR(    NULL    ,       		xfil35_Set_File_Info_Msg	)
DEFINE_SUBR(	NULL,				xfil42_Put_Msg			)
DEFINE_SUBR(    NULL    ,       		xfil44_Set_Instance_Variable_Msg)
DEFINE_SUBR(    NULL    ,       		xfil46_Set_Anonymous_Variable_Msg)
DEFINE_SUBR(    "XFIL-GET-NAME-OF-CURRENT-GRAPHICS-FILE",xfil57_Get_Name_Of_Current_Graphics_File_Fn)
DEFINE_SUBR(	"XFIL-SET-CURRENT-GRAPHICS-FILE",xfil58_Set_Current_Graphics_File_Fn)
DEFINE_SUBR(	"XFIL-GET-NAMES-OF-LOADED-GRAPHICS-FILES",xfil59_Get_Names_Of_Loaded_Graphics_Files_Fn)
DEFINE_SUBR(	"XFIL-SAVE-GRAPHICS-FILE",	xfil68_Save_Graphics_File_Fn	)
DEFINE_SUBR(	"XFIL-WRITE-SEXP-TO-FILE",	xfil72_Write_Sexp_To_File_Fn	)
DEFINE_SUBR(	"XFIL-LOAD-GRAPHICS-FILE",	xfil82_Load_Graphics_File_Fn	)
DEFINE_SUBR(	"XFIL-UNLOAD-GRAPHICS-FILE",	xfil84_Unload_Graphics_File_Fn	)
DEFINE_SUBR(	NULL,				xfil91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,				xfil95_ProplistNth_Msg		)
DEFINE_SUBR(    "XFIL-DEBUG-PRINTOUT",		xfila1_Debug_Printout_Fn	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLINIT
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xfil;
LOCAL struct xfil_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xfil_table[] = {
    {	":ISNEW",		xfil00_Is_New			},
    {	":COPY",		xfil08_Copy_Msg			},
    {	":SHOW",		xfil03_Show_Msg			},
    {	":GET", 		xfil40_Get_Msg			},
    {	":SET", 		xfil42_Put_Msg			},
    {	":PROPERTY-LIST-LENGTH",xfil91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xfil95_ProplistNth_Msg		},

    {	NULL,			NULL				}
};
LOCAL struct xfil_x03d_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xfil_x03d_table[] = {
    {   ":SET-FILE-INFO",		xfil35_Set_File_Info_Msg	},
    {   ":SET-INSTANCE-VARIABLE",	xfil44_Set_Instance_Variable_Msg},
    {   ":SET-ANONYMOUS-VARIABLE",	xfil46_Set_Anonymous_Variable_Msg},

    {	NULL,			NULL				}
};


#ifndef DEFINED_NAME
LVAL k_name;/* Keyword ":name" */
#define DEFINED_SHOW
#endif

#ifndef DEFINED_S_XFILFD
LVAL s_xfilfd;/* Symbol "XFIL-FD" */
#define DEFINED_S_XFILFD
#endif

#ifndef DEFINED_S_XFILFDBINARY
LVAL s_xfilfdbinary;/* Symbol "XFIL-FD-BINARY" */
#define DEFINED_S_XFILFDBINARY
#endif

#ifndef DEFINED_S_XFILTHIS
LVAL s_xfilthis;/* Symbol "XFIL-THIS" */
#define DEFINED_S_XFILTHIS
#endif

#ifndef DEFINED_S_XFILREF
LVAL s_xfilref;/* Symbol "XFIL-REF" */
#define DEFINED_S_XFILREF
#endif

#ifndef DEFINED_S_OBJECTLIST
LVAL s_objectlist;/* Symbol "OBJECT-LIST" */
#define DEFINED_S_OBJECTLIST
#endif

#ifndef DEFINED_S_FILELIST
LVAL s_filelist;/* Symbol "FILE-LIST" */
#define DEFINED_S_FILELIST
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS
    lv_xfil = getvalue(xlenter("CLASS-GRAPHIC-FILE"));

#ifndef CREATED_NAME
    k_name = xlenter(":NAME");
#define CREATED_NAME
#endif

#ifndef CREATED_S_XFILFD
    s_xfilfd = xlenter("XFIL-FD");
#define CREATED_S_XFILFD
#endif

#ifndef CREATED_S_XFILFDBINARY
    s_xfilfdbinary = xlenter("XFIL-FD-BINARY");
#define CREATED_S_XFILFDBINARY
#endif

#ifndef CREATED_S_XFILTHIS
    s_xfilthis = xlenter("XFIL-THIS");
#define CREATED_S_XFILTHIS
#endif

#ifndef CREATED_S_XFILREF
    s_xfilref = xlenter("XFIL-REF");
#define CREATED_S_XFILREF
#endif

#ifndef CREATED_S_OBJECTLIST
    s_objectlist = xlenter("OBJECT-LIST");
#define CREATED_S_OBJECTLIST
#endif

#ifndef CREATED_S_FILELIST
    s_filelist = xlenter("FILE-LIST");
#define CREATED_S_FILELIST
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xfil = xgbj58_Create_Class("CLASS-GRAPHIC-FILE",lv_x03d);
    xgbj57_Add_Instance_Variable( lv_xfil,"OBJECT-LIST");
    xgbj56_Enter_Messages( lv_xfil,  xfil_table );
    xgbj56_Enter_Messages( lv_x03d,  xfil_x03d_table );
    xgbj59_Add_Class_Variable( lv_xfil, cons(xlenter("FILE-LIST"),NIL) );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
