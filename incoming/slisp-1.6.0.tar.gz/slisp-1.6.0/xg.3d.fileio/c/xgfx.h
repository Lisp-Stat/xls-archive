/* {{{ xgfx.h -- Support for GFX (local lab file format) files.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jun04
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS

extern LVAL xgfx10_Write_File_Header_Fn();
extern LVAL xgfx20_Write_Tube_Header_Fn();
extern LVAL xgfx30_Write_Contour_Fn();
extern LVAL xgfx40_Write_File_Trailer_Fn();
extern LVAL xgfx60_Read_File_Header_Fn();
extern LVAL xgfx80_Read_Contour_Fn();

#ifndef EXTERNED_TRANSFORM
extern LVAL k_transform;/* Keyword ":TRANSFORM" */
#define EXTERNED_TRANSFORM
#endif

#ifndef EXTERNED_NAME
extern LVAL k_name;/* Keyword ":NAME" */
#define EXTERNED_NAME
#endif

#ifndef EXTERNED_FRAME
extern LVAL k_frame;/* Keyword ":FRAME" */
#define EXTERNED_FRAME
#endif

#ifndef EXTERNED_POINTX
extern LVAL k_pointx;/* Keyword ":POINT-X" */
#define EXTERNED_POINTX
#endif

#ifndef EXTERNED_POINTY
extern LVAL k_pointy;/* Keyword ":POINT-Y" */
#define EXTERNED_POINTY
#endif

#ifndef EXTERNED_POINTZ
extern LVAL k_pointz;/* Keyword ":POINT-Z" */
#define EXTERNED_POINTZ
#endif

#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	"XGFX-WRITE-FILE-HEADER",	xgfx10_Write_File_Header_Fn )
DEFINE_SUBR(	"XGFX-WRITE-TUBE-HEADER",	xgfx20_Write_Tube_Header_Fn )
DEFINE_SUBR(	"XGFX-WRITE-CONTOUR",		xgfx30_Write_Contour_Fn	    )
DEFINE_SUBR(	"XGFX-WRITE-FILE-TRAILER",	xgfx40_Write_File_Trailer_Fn)
DEFINE_SUBR(	"XGFX-READ-FILE-HEADER",	xgfx60_Read_File_Header_Fn)
DEFINE_SUBR(	"XGFX-READ-CONTOUR",		xgfx80_Read_Contour_Fn)
#endif



#ifdef MODULE_XLOBJ_C_GLOBALS

#ifndef DEFINED_TRANSFORM
LVAL k_transform;/* Keyword ":TRANSFORM" */
#define DEFINED_TRANSFORM
#endif

#ifndef DEFINED_NAME
LVAL k_name;/* Keyword ":NAME" */
#define DEFINED_NAME
#endif

#ifndef DEFINED_FRAME
LVAL k_frame;/* Keyword ":FRAME" */
#define DEFINED_FRAME
#endif

#ifndef DEFINED_POINTX
LVAL k_pointx;/* Keyword ":POINT-X" */
#define DEFINED_POINTX
#endif

#ifndef DEFINED_POINTY
LVAL k_pointy;/* Keyword ":POINT-Y" */
#define DEFINED_POINTY
#endif

#ifndef DEFINED_POINTZ
LVAL k_pointz;/* Keyword ":POINT-Z" */
#define DEFINED_POINTZ
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_TRANSFORM
    k_transform = xlenter(":TRANSFORM");
#define CREATED_TRANSFORM
#endif

#ifndef CREATED_NAME
    k_name = xlenter(":NAME");
#define CREATED_NAME
#endif

#ifndef CREATED_FRAME
    k_frame = xlenter(":FRAME");
#define CREATED_FRAME
#endif

#ifndef CREATED_POINTX
    k_pointx = xlenter(":POINT-X");
#define CREATED_POINTX
#endif

#ifndef CREATED_POINTY
    k_pointy = xlenter(":POINT-Y");
#define CREATED_POINTY
#endif

#ifndef CREATED_POINTY
    k_pointy = xlenter(":POINT-Y");
#define CREATED_POINTY
#endif

#ifndef CREATED_POINTZ
    k_pointz = xlenter(":POINT-Z");
#define CREATED_POINTZ
#endif

#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */

