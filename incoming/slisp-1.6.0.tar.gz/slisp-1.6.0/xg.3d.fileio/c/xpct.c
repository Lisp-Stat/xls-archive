/* {{{ xpct.c -- Fns to read/write PCT (Mac button format) files.     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94Jul11
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 94Jul11 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

  
#include <stdio.h>
#include <string.h>

#include "../../xcore/c/xlisp.h"

#include "../../xg.3d/c/geo.h"
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cflv.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/cthl.h"
#include "../../xg.3d/c/ctfm.h"

extern LVAL xsendmsg0(); 
extern LVAL xsendmsg1(); 
extern LVAL xsendmsg2(); 

extern LVAL k_name;
extern LVAL k_pointx;
extern LVAL k_pointy;
extern LVAL k_pointz;
extern LVAL k_transform;
extern LVAL k_x;
extern LVAL k_y;

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xpct10_Write_File_Header_Fn					*/

LVAL xpct10_Write_File_Header_Fn() {
    LVAL lv_fd  = xlgastream();
    FILE*fd     = getfile(lv_fd);
    char*name   = "unknown.pict";

    while (moreargs()) {
        LVAL key = xlgasymbol();
        if (key == k_name) {

            /* Handle ':name "jpS3I12.pict"': */
	    LVAL lv_name = xlgastring();
	    name         = (char*) getstring( lv_name );

	} else {

            xlerror("Bad XPCT-WRITE-FILE-HEADER keyword:",key);
        }
    }

    fprintf( fd, "PICTGRAPHIC %s\r", name );
    return NIL;
}

/* }}} */
/* {{{ xpct30_Write_Contour_Fn						*/

xpct19_Check_Array( lv )
LVAL                lv;
{
    if (!xflvp(lv))  xlerror("Not a float array:",lv);
}
int xpct29_Ary_Len( lv )
LVAL                lv;
{
    csry_rec* h 	= (csry_rec*) gobjimmbase( lv );
    int len		= h->size;
    int has_fillpointer = (h->rank == 1);
    int fillpointer	= h->dim[1];
    if (has_fillpointer  &&
	fillpointer > -1 &&
	fillpointer < len
    ) {
	len = fillpointer;
    }
    return len;
}

LVAL xpct30_Write_Contour_Fn() {

    LVAL lv_fd  = xlgastream();
    FILE*fd     = getfile(lv_fd);

    extern LVAL xgrl01_Get_A_XGRL();

    LVAL  lv_grl = xgrl01_Get_A_XGRL();
    LVAL  lv_x   = xgrl3c_Get_Array( lv_grl, k_pointx, NIL, /*got_default*/FALSE );
    LVAL  lv_y   = xgrl3c_Get_Array( lv_grl, k_pointy, NIL, /*got_default*/FALSE );
    LVAL  lv_z   = xgrl3c_Get_Array( lv_grl, k_pointz, NIL, /*got_default*/FALSE );
    int   len_x;
    int   len_y;
    int   len_z;
    int   len;
    int   row, col;
    float xpix   = 1024.0;
    float ypix   = 1024.0;
    geo_matrix m;
    float*px = (float*) csry_base( lv_x );
    float*py = (float*) csry_base( lv_y );
    float*pz = (float*) csry_base( lv_z );
    char*name = "(nameless structure)";


    /* Initialize transform matrix: */
    for     (row = 0;   row < 4;   ++row) {
        for (col = 0;   col < 4;   ++col) {
	    m.m[row][col] = (row==col) ? 1.0 : 0.0;
    }	}

    while (moreargs()) {
        LVAL key = xlgasymbol();
        if (key == k_name) {

            /* Handle ':name "left eyeball"': */
	    LVAL lv_name = xlgastring();
	    name         = (char*) getstring( lv_name );

        } else if (key == k_x) {

	    xpix = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

        } else if (key == k_y) {

	    ypix = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

	} else {

            xlerror("Bad XPCT-WRITE-CONTOUR keyword:",key);
        }
    }
    
    xpct19_Check_Array(     lv_x );
    xpct19_Check_Array(     lv_y );
    xpct19_Check_Array(	    lv_z );

    len_x = xpct29_Ary_Len( lv_x );
    len_y = xpct29_Ary_Len( lv_y );
    len_z = xpct29_Ary_Len( lv_z );

    if (len_x != len_y ||
	len_x != len_z
    ) {
	xlfail("XPCT-WRITE-CONTOUR: Bad grl!");
    }

    /* Read :TRANSFORM matrix off our contour relation: */
    {   LVAL lv_tfm = xthl8a_GetObjectProp( lv_grl, k_transform, NULL, TRUE );
	if  (lv_tfm) {
	    ctfm_rec* r	= (ctfm_rec*) gobjimmbase( lv_tfm );
	    m = r->m;
    }	}

    /* Print out button name: */
    fprintf(fd,	"STRUCTURE %s\r", name );

    /* Print out points proper: */
    {   int i;
	for (i = 0;   i < len_x;   ++i) {
	    float x = px[i];
	    float y = py[i];
	    float z = pz[i];
	    int   c = (int)(
                xpix * (x*m.m[0][0] + y*m.m[1][0] + z*m.m[2][0] + m.m[3][0])  +  0.5
            );
	    int   r = (int)(
                ypix * (x*m.m[0][1] + y*m.m[1][1] + z*m.m[2][1] + m.m[3][1])  +  0.5
            );
	    
	    if (i) fputc( ',', fd );
	    fprintf( fd, "%d,%d", c, ((int)ypix)-r ); /* "ypix-r" 'cause Mac has y==0 at top. */
    }	} 
    fputc( '\r', fd );

    return NIL;
}

/* }}} */
/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
