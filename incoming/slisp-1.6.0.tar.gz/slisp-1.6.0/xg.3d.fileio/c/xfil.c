/* {{{ xfil.c -- native lisp format I/O support.		     CrT*/

/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Apr28
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/************************************************************************/
/*                              comments                                */
/*                                                                      */
/*    Users need to be able to save a group of related graphics         */
/*  objects to disk in a file.  Also, objects in different files        */
/*  need to be able to refer to each other, so that users can           */
/*  break graphic objects up into conceptual hierarchies, and           */
/*  store each conceptual chunk in a separate file.  (This also         */
/*  allows sharing of chunks between separate graphic worlds --         */
/*  the same reconstruction of an eyeball may be used in multiple       */
/*  animation sequences, for example.)                                  */
/*                                                                      */
/*    We handle this need by assigning every object a home file,        */
/*  and a number within that file.  Objects created 'within' a file     */
/*  are consecutively numbered -- numbers are never recycled -- and     */
/*  may always be referred to as "myfile/102" (filename/number).        */
/*                                                                      */
/*    When the user requests us to write a file to disk, we iterate     */
/*  over all objects in RAM, and write each 3D object to the file,      */
/*  replacing all references to other 3D objects with                   */
/*      (XFIL-REF "file/number")                                        */
/*  calls.  XFIL-REF is a function we export which will translate       */
/*  the given string into a normal xlisp LVAL, and return the LVAL.     */
/*                                                                      */
/*    We actually write out a file in two passes.  The first pass       */
/*  writes out all the objects themselves, the second pass writes       */
/*  out the values associated with the objects.  Thus, when XFIL-REF    */
/*  is called to create an LVAL corresponding to a given object, we     */
/*  are guaranteed that the object at least exists to the extent of     */
/*  having an address in RAM which we can return, if not perhaps to     */
/*  the extent of being usable yet.  (If XFIL-REF is asked to deref     */
/*  a name/number reference to another file, it will, if need be,       */
/*  recursively load that other file before continuing.)                */
/*                                                                      */
/*    To implement this strategy, we need to be able to                 */
/*  (1) given any 3D object, tell which file it belongs in, and         */
/*      what it's number is within that file, and                       */
/*  (2) given a   name/number reference to any object, find and         */
/*      return the LVAL for that object, loading the relevant file      */
/*      if need be.                                                     */
/*                                                                      */
/*  Requirement (1) arises twice when scanning through memory to write  */
/*  out all objects in a file, once to determine if the current object  */
/*  belongs to the file to be written, and once to construct a          */
/*  filename/number reference to any other object referred to by our    */
/*  object, as we write it out.                                         */
/*                                                                      */
/*  Requirement (2) arises when loading objects from a file, when we    */
/*  need to translate filename/number references into internal LVALs.   */
/*                                                                      */
/*  We satisfy requrement (1) by placing a c03d_fileInfo record at      */
/*  the same offset in the binary-data segment of each 3d object.       */
/*  Since it is always at the same offset, we can scan objects          */
/*  quickly without worrying about their class.                         */
/*                                                                      */
/*  We satisfy requrement (2) by creating a GRAPHIC-FILE object for     */
/*  each file loaded.  A CLASS-GRAPHIC-FILE class variable associates   */
/*  every file with it's name on a propertylist, and each GRAPHIC-FILE  */
/*  object associates each 3D object in the file with it's number on    */
/*  a local propertylist.                                               */
/*                                                                      */
/*  The above implementation is simple, but not terribly efficient,     */
/*  of course.  Pragmatically, it is assumed for now that we are        */
/*  dealing with small numbers of files, with small numbers of          */
/*  objects per file, and that the filename/number lookup time isn't    */
/*  terribly critical.  If these assumptions fail, we may always        */
/*  re-implement using fast hashtables or even hacks to the lisp        */
/*  interpreter, without invalidating existing datafiles, so we're      */
/*  not painting ourselves into any corners here.                       */
/*                                                                      */
/************************************************************************/

/* }}} */
/* {{{ --- history ---							*/

/* 97Feb11 jsp: Fixed xfil81_Load_Graphics_File reload bug.		*/
/* 92Apr26 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

  
#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/cthl.h"
#include "cfil.h"

extern LVAL lv_xfil;
extern LVAL k_name;
extern LVAL xsendmsg0(); 
extern LVAL s_stdout;
extern LVAL lv_x03d;
extern LVAL s_filelist;
extern LVAL s_objectlist;
extern LVAL s_xfilfdbinary;
extern LVAL s_xfilref;
extern LVAL s_xfilthis;

LVAL  cfil0a_Current_xfil            = NULL;
LVAL* cfil0b_Current_xfil_ObjectList = NULL;

/* Forward declarations: */
LVAL* xfil13_pObjectList();
LVAL* xfil14_pFileList();
LVAL  xfil75_Find_Loaded_Graphics_File();
LVAL  xfil76_Load_One_Graphics_File();

/* }}} */

/* {{{ --- Public fns ---						*/

/* }}} */
/* {{{ xfil00_Is_New -- Initialize a new xfil instance.			*/

cfil_rec xfil_defaults = {
    C03D_xFIL,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */
    NULL,                       /* filename                     */
    0                           /* next_object_number_to_issue  */
};

LVAL xfil00_Is_New()
{   extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv_self  = xlgagobject();
    LVAL lv_filename = NULL;
    if (moreargs())   lv_filename = xlgastring();
    xllastarg();

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xfilp(lv_self))   xlbadtype(lv_self);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv_self, sizeof( cfil_rec ) );

    /* Initialize file record to reasonable default values: */
    {   cfil_rec* r;
        r   = (cfil_rec*) gobjimmbase( lv_self );
       *r   = xfil_defaults;
    }

    /* Remember name of our file: */
    if (lv_filename != NULL) {
	xfil38_Set_Filename( lv_self, getstring(lv_filename) );
    }

    /* Make us the "current file": */
    cfil0a_Current_xfil = lv_self;

    /* Thread us on list of all loaded files: */
    {   LVAL* pFileList = xfil14_pFileList();
	*pFileList = cons( lv_self, *pFileList );
    }

    /* Currently, we never let the user get direct */
    /* contact with an xfil instance:              */
    return NIL;
}

/* }}} */
/* {{{ xfil01_Get_A_XFIL -- Get arg, must be of class xfil.		*/

LOCAL LVAL xfil01_Get_A_XFIL()
/*-
    Get arg, must be of class xfil.
-*/
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XFIL has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xfil.  Similarly,          */
    /* nobody but nobody has any business resizing a xfil,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xfilp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) != sizeof(cfil_rec) 
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xfil03_Show_Msg -- Show the contents of a cfil.			*/

LVAL xfil03_Show_Msg()
/*-
    Show the contents of a lgt.
-*/
{
    LVAL self,fptr;

    /* get self and the file pointer */
    self = xfil01_Get_A_XFIL();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xfil08_Copy_Msg -- Build copy of given CFIL.			*/

LVAL xfil09_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given CFIL.
-*/
{
    /* Create a new gobject to hold result: */
    cfil_rec*mh = (cfil_rec*) gobjimmbase( m_as_lval );
    cfil_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xfil,k_new);
    xlpop();
    nh = (cfil_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}

LVAL xfil08_Copy_Msg()
/*-
    Build copy of given CFIL.
-*/
{
    LVAL m_as_lval = xfil01_Get_A_XFIL();
    xllastarg();
    return xfil09_Copy(m_as_lval);
}

/* }}} */
/* {{{ xfil13_pObjectList -- Return pointer to object list for xfil.	*/

LVAL* xfil13_pObjectList( m )
LVAL                      m;
{   LVAL*pObjectList;
    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
        m,
        getclass( m ),
        s_objectlist,
        &pObjectList
    );
    return pObjectList;
}

/* }}} */
/* {{{ xfil14_pFileList -- Return pointer to xfil list.			*/

LVAL* xfil14_pFileList()
{
    /* We sort of cheat here, and use lv_xfil as an 'object', since  */
    /* we can't count on having an instance of class lv_xfil around. */
    /* This will only fail if someone adds a instance variable      */
    /* FILE-LIST to lv_xfil, and then we're in deep trouble anyhow...*/
    LVAL*pFileList;
    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
        lv_xfil,     /* Dummy 'object', basically. */
        lv_xfil,     /* Class of dummy object.     */
        s_filelist, /* Symbol to look up.         */
        &pFileList
    );
    return pFileList;
}

/* }}} */
/* {{{ xfil22_Expand_XfilRefs_Fn -- (XFIL-REF "filename/number") -> lval.*/

xfil15_Crack_File_Info( buf, info )
char                   *buf,*info;
{
    /* Scan decimalNumber into 'num', and         */
    /* leave "filename" in 'buf':                 */
    char*t;
    int  object_number;
    if (!*info) xlfail("XFIL-REF: empty filename");
    strcpy( buf, info );
    t             = buf + strlen(buf) -1;
    while (t > buf && *t <= '9' && *t >= '0')   --t;
    *t            = '\0';
    object_number = atoi(++t);
    return object_number;
}
struct xfil16_rec {
    int   our_object_number;
    LVAL  lv_our_object;
};
xfil17_All_Objects_Find_Our_Object( r, lv_object_number, lv_object )
struct xfil16_rec                  *r;
LVAL                                   lv_object_number, lv_object;
{   if (!fixp(lv_object_number)) xlerror("xfil16 needs fixnum",lv_object_number);
    if (getfixnum(lv_object_number) == r->our_object_number) {
	r->lv_our_object = lv_object;
        return TRUE; /* Halt iteration. */
    }
    return FALSE; /* Continue iteration. */
}
LVAL xfil19_XfilRef_To_Lval( filename, object_number )
char                        *filename;
int                                    object_number;
{
    /* Need to find the xfil instance with given name,  */
    /* then return object_number'th obj from that file: */
    LVAL  lv_our_xfil;
    struct xfil16_rec r;

    /* Find our xfil instance, loading file if need be: */
    lv_our_xfil = xfil76_Load_One_Graphics_File( filename );

    /* Search loaded-objects list in file for our object: */
    {   LVAL*plv_objects_loaded = xfil13_pObjectList( lv_our_xfil );
	r.our_object_number = object_number;
	if (!x03d14_Map_PairList(
	    *plv_objects_loaded,
	    xfil17_All_Objects_Find_Our_Object,
	    &r)
	) {
	    char buf[256];
	    sprintf(buf,"xfil19: No such object: %s/%d",filename,object_number);
	    xlfail(buf);
	}
	return r.lv_our_object;
    }
}
LVAL xfil24_Crack_And_Expand_XfilRef( str )
char                                 *str;
{   char buf[ 256 ];
    int  object_number = xfil15_Crack_File_Info( buf, str );
    return  xfil19_XfilRef_To_Lval( buf, object_number );
}
LVAL xfil20_Expand_XfilRef( lv_expr )
LVAL                        lv_expr;
{   /* If lv_expr is of form (XFIL-REF "file/#")  */
    /* then return the corresponding lval, else   */
    /* just return lv_expr:                       */

    /* Return if list doesn't match our needs:    */
    LVAL lv_str_cons;
    LVAL lv_str;
    if (car(lv_expr) != s_xfilref                     ||
       (!consp(   lv_str_cons = cdr( lv_expr     )))  ||
       (!stringp( lv_str      = car( lv_str_cons )))  ||
       (!null(                  cdr( lv_str_cons )))
    ) {
	return lv_expr;
    }

    /* Scan decimalNumber into 'num', and         */
    /* leave "filename" in 'buf':                 */
    return xfil24_Crack_And_Expand_XfilRef( getstring(lv_str) );
}
LVAL xfil21_Expand_XfilRefs( lv_expr )
LVAL			     lv_expr;
{   /* Search complete lv_expr for lists of form */
    /* (XFIL-REF ...) and apply xfil20 to each:  */
    LVAL lv;
    if (!consp(lv_expr))     return    lv_expr;
    lv_expr = xfil20_Expand_XfilRef(   lv_expr );
    for (lv = lv_expr;   consp(lv);   lv = cdr(lv)) {
	rplaca( lv, xfil21_Expand_XfilRefs(car(lv)) );
    }
    return lv_expr;
}
LVAL xfil22_Expand_XfilRefs_Fn()
{   /* Read an expression, replace (xfil-ref "myfile/24") */
    /* by lval referring to object #24 in file 'myfile'   */
    /* (etc) throughout expression, and then return the   */
    /* expression as our result.                          */
    LVAL lv_expr = xlgetarg();
    xllastarg();
    return xfil21_Expand_XfilRefs(lv_expr);
}
LVAL xfil23_Xfil_Ref_Fn()
{   /* Handle (xfil-ref "myfile/24") */
    LVAL lv_expr = xlgastring();
    xllastarg();
    return xfil24_Crack_And_Expand_XfilRef( getstring(lv_expr) );
}

/* }}} */
/* {{{ xfil27_Write_Object_To_Graphics_File                                 */

xfil26_Number_And_Filename_Of_Gobject( filename,  lv ) /* Called from xfil.c too.*/
char                                 **filename;
LVAL                                              lv;
{   c03d_rec* r = (c03d_rec*) gobjimmbase( lv );
    int       n = r->fileInfo.object_number;
    LVAL      v = r->fileInfo.file_object;
    char     *f;
    cfil_rec* p;
    if (!xfilp(v)) xlerror("xfil26",v);
    p           = (cfil_rec*) gobjimmbase( v );
   *filename    = p->filename;
    return n;
}
xfil27_Write_Object_To_Graphics_File( fdoa, fdob, lv )
FILE                                 *fdoa,*fdob;
LVAL                                              lv;
{   char    * f;
    int       n = xfil26_Number_And_Filename_Of_Gobject( &f,  lv );
    c03d_rec* r = (c03d_rec*) gobjimmbase( lv );

    switch (r->k_class) {
    case C03D_x03D: x03dwo_Write_X03d_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_x01V: x01vwo_Write_X01v_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_x32V: x32vwo_Write_X32v_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xFLV: xflvwo_Write_Xflv_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xF8V: xf8vwo_Write_Xf8v_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xF6V: xf6vwo_Write_Xf6v_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xF2V: xf2vwo_Write_Xf2v_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xU8V: xu8vwo_Write_Xu8v_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xU6V: xu6vwo_Write_Xu6v_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xI6V: xi6vwo_Write_Xi6v_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xGRL: xgrlwo_Write_Xgrl_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xTFM: xtfmwo_Write_Xtfm_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xCMR: xcmrwo_Write_Xcmr_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xLGT: xlgtwo_Write_Xlgt_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xMDL: xmdlwo_Write_Xmdl_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xMTL: xmtlwo_Write_Xmtl_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xS1D: xs1dwo_Write_Xs1d_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xCHC: xchcwo_Write_Xchc_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xGTX: xgtxwo_Write_Xgtx_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xFRM: xfrmwo_Write_Xfrm_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xTUB: xtubwo_Write_Xtub_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xCLR: xclrwo_Write_Xclr_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xLID: xlidwo_Write_Xlid_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xLIT: xlitwo_Write_Xlit_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xSUB: xsubwo_Write_Xsub_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xTRN: xtrnwo_Write_Xtrn_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xLST: xlstwo_Write_Xlst_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xTXR: xtxrwo_Write_Xtxr_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xPGN: xpgnwo_Write_Xpgn_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xEDT: xedtwo_Write_Xedt_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xEYE: xeyewo_Write_Xeye_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xSLC: xslcwo_Write_Xslc_To_Graphics_File(fdoa,fdob, lv,f,n); break;
    case C03D_xSRY:
	xlfail("xfil27: xsry?");
	break;
    default:
	{   char buf[ 256 ];
	    sprintf(buf,"xfil27: unknown magic %x",r->k_class); 
	    xlfail(buf);
    }   }
    return FALSE;
}

/* }}} */
/* {{{ xfil30_Write_Objects_Lvals_To_Graphics_File                          */

xfil28_Write_Symbol_To_Graphics_File( fdoa, fdob, lv )
FILE                                 *fdoa,*fdob;
LVAL                                              lv;
{   /* This fn adapted from xlprin.c:putsymbol(): */
    extern LVAL k_const;
    extern LVAL k_nmacro;
    extern LVAL k_downcase;
    extern LVAL s_printcase;
    extern LVAL tentry(); /* xlread.c */
    char*str = (char*)getstring(getpname(lv));
    int downcase,ch;
    LVAL type;
    char *p;

    /* If symbol name does not start with */
    /* ':', prepend a single-quote:       */
    if (*str != ':') {
	fputc('\'',fdoa);
    }

    /* Check to see if symbol needs escape characters: */
    if (tentry(*str) == k_const) {
	for (p = str; *p; ++p) {
	    if (islower(*p)
	        ||  ((type = tentry(*p)) != k_const
	        && (!consp(type) || car(type) != k_nmacro))
	    ) {
		fputc('|',fdoa);
		while (*str) {
		    if (*str == '\\' || *str == '|')   fputc('\\',fdoa);
		    fputc(*str++,fdoa);
		}
		fputc('|',fdoa);
		return;
    }   }   }

    /* Get the case translation flag: */
    downcase = (getvalue(s_printcase) == k_downcase);

    /* Check for the first character being '#': */
    if (*str == '#' || *str == '.' || isnumber(str,NULL)) {
	fputc('\\',fdoa);
    }

    /* Output each character: */
    while ((ch = *str++) != '\0') {
	/* don't escape colon until we add support for packages */
	if (ch == '\\' || ch == '|' /* || ch == ':' */)	    fputc('\\',fdoa);
	fputc((downcase && isupper(ch) ? tolower(ch) : ch),fdoa);
    }
}
xfil29_Write_Sexp_To_Graphics_File( fdoa, fdob, lv )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
{   /* This fn adapted from xlprin.c:xlprint(): */
    LVAL nptr,next;
    int n,i;

    /* print nil */
    if (lv == NIL) {
	fputs("NIL",fdoa);
	return;
    }

    /* check value type */
    switch (ntype(lv)) {
    case GOBJECT:
	if (x03dA0_Is_A( lv_x03d, lv )) {
	    char* f;
	    int   n;
	    n = xfil26_Number_And_Filename_Of_Gobject( &f, lv );
	    fprintf(fdoa,"(xfil-ref \"%s/%d\")",f,n);
	    break;
	}
	/* FALLTHRU: */
    case SUBR:
    case FSUBR:
    case STREAM:
    case USTREAM:
    case STRUCT:
    case CLOSURE:
    case FREE:
    case OBJECT:
    default:
	xlerror("Can't save in graphics file:",lv);
	break;

    case CONS:
#ifdef OLD
	fputc('(',fdoa);
#else
	fputs("(list ",fdoa);
#endif
	for (nptr = lv; nptr != NIL; nptr = next) {
	    xfil29_Write_Sexp_To_Graphics_File(fdoa,fdob,car(nptr));
	    if ((next = cdr(nptr)) != NIL) {
		if (consp(next)) {
		    fputc(' ',fdoa);
		} else {
		    fputs(" . ",fdoa);
		    xfil29_Write_Sexp_To_Graphics_File(fdoa,fdob,next);
		    break;
	}	}   }
	fputc(')',fdoa);
	break;
    case SYMBOL:
	xfil28_Write_Symbol_To_Graphics_File( fdoa, fdob, lv );
	break;
    case FIXNUM:
	{   LVAL val;
	    extern LVAL s_ifmt;
	    unsigned char *fmt = (
		(val = getvalue(s_ifmt)) && stringp(val) ?
		 getstring(val)				 :
		 (unsigned char *)IFMT
	    );
	    fprintf(fdoa,(char*)fmt,getfixnum(lv));
	}
	break;
    case FLONUM:
	{   LVAL val;
#ifdef MORE_NORMAL
	    /* This is what the regular xlisp code does: */
	    extern LVAL s_ffmt;
	    unsigned char *fmt = (
		(val = getvalue(s_ffmt)) && stringp(val) ?
		 getstring(val)				 :
		 (unsigned char *)"%g"
	    );
#else
	    /* We ignore s_ffmt so we can force */
	    /* flonums to read back as flonums: */
	    unsigned char *fmt = (unsigned char *)"%#g";
#endif
	    fprintf(fdoa,(char*)fmt,getflonum(lv));
	}
	break;
    case CHAR:
	{   char ch = getchcode(lv);
	    switch (ch) {
	    case '\n':		fputs("#\\Newline",fdoa);		break;
	    case ' ':		fputs("#\\Space",fdoa);			break;
	    default:		fprintf(fdoa,"#\\%c",ch);		break;
	}   }
	break;
    case STRING:
	{   unsigned char *p;
	    int ch;
	    fputc('"',fdoa);
	    for (p = getstring(lv);   (ch = *p) != '\0';   ++p) {

		/* check for a control character */
		if (ch >= 040  &&  ch != '\\'  &&  ch <= 0176) {
		    fputc(ch,fdoa);
		} else {
		    fputc('\\',fdoa);
		    switch (ch) {
		    case '\011':    fputc( 't',fdoa);    break;
		    case '\012':    fputc( 'n',fdoa);    break;
		    case '\014':    fputc( 'f',fdoa);    break;
		    case '\015':    fputc( 'r',fdoa);    break;
		    case '\\':	    fputc('\\',fdoa);	 break;
		    default:
			fprintf(fdoa,"%03o",ch);
			break;
	    }	}   }
	    fputc('"',fdoa);
	}
	break;
    case VECTOR:
	fputs("#(",fdoa);
	for (i = 0, n = getsize(lv) - 1; i <= n; ++i) {
	    xfil29_Write_Sexp_To_Graphics_File( fdoa, fdob, getelement(lv,i) );
	    if (i != n) fputc(' ',fdoa);
	}
	fputc(')',fdoa);
	break;
    }
}
xfil30_Write_Objects_Lvals_To_Graphics_File( fdoa, fdob, lv )
FILE                                        *fdoa,*fdob;
LVAL                                                     lv;
{   /* This fn is designed to save all the named and anonymous LVALs */
    /* stored in any class in this directory to the given filepair,  */
    /* in the form of xlisp code that will restore those LVALS when  */
    /* the output file is later LOADed as a lisp file.               */

    /* First task is to find our file name and number, and to write  */
    /* out code to locate ourself via them during the load.  Note    */
    /* that the file-construction code guarantees that we will       */
    /* already exist at this point...  we need to bind ourself       */
    /* lexically because we may recursively load other files in the  */
    /* process of constructing ourself.                              */
    {   char* f;
        int   n = xfil26_Number_And_Filename_Of_Gobject( &f, lv );
        fprintf(fdoa,"(setq xfil-this (xfil-ref \"%s/%d\"))\n",f,n);
    }

    /* Save out all the named instance variables: */
    /* First, find list of named instance vars:   */
    {   LVAL cls = getclass(lv);
	/* Over all [super]classes of our object: */
	for (; objectp(cls); cls = getivar(cls,SUPERCLASS)) {

	    /* Over all instance variables declared by class: */
	    LVAL names = getivar(cls,IVARS);
	    int  ivtotal = getivcnt(cls,IVARTOTAL);
	    int  n;
	    for (n = ivtotal - getivcnt(cls,IVARCNT); n < ivtotal; ++n) {

		/* Save out value of instance variable: */
		LVAL varSymbol = car(names);
		fputs("(send xfil-this :set-instance-variable ",fdoa);
		xfil28_Write_Symbol_To_Graphics_File( fdoa, fdob, varSymbol );
#ifdef OLD
		fputs("\n  (XFIL-EXPAND '",fdoa);
#else
		fputs("\n  ",fdoa);
#endif
		{   LVAL*plv;
		    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
			    lv,getclass(lv),varSymbol,&plv
		    );
		    xfil29_Write_Sexp_To_Graphics_File(fdoa, fdob, *plv);
		}
#ifdef OLD
		fputs("))\n",fdoa);
#else
		fputs(")\n",fdoa);
#endif
		names = cdr(names);
    }	}   }

    /* Save out all the anonymous lvals: */
    {   int cnt = getgobjarraylvals(lv);
	/* Writing highest-numbered anonymous variable out first */
	/* means we only resize object once as we read it in:    */
	while (cnt --> 0) {
	    LVAL          xgbj04_Get_Lval(         );
	    LVAL lv_val = xgbj04_Get_Lval( lv, cnt );
	    fprintf(
		fdoa,
		/* The OLD code avoids building every input list */
		/* twice by using '(... instead of (list... but  */
		/* the xlisp user has to insert XFIL-EXAND by    */
		/* hand in the trailer section.  For now, I'm    */
		/* loading very short lists, so I won't worry    */
		/* about the redundant rebuild:                  */
#ifdef OLD
		"(send xfil-this :set-anonymous-variable %d\n(XFIL-EXPAND '",
#else
		"(send xfil-this :set-anonymous-variable %d\n ",
#endif
		cnt
	    );
	    xfil29_Write_Sexp_To_Graphics_File(fdoa, fdob, lv_val);
#ifdef OLD
	    fputs("))\n",fdoa);
#else
	    fputs(")\n",fdoa);
#endif
    }   }
    fputc('\n',fdoa);

    return FALSE;
}

/* }}} */
/* {{{ xfil34_Set_File_Info      Fill in fileInfo record from string.       */

xfil34_Set_File_Info( lv_self, info )
LVAL                  lv_self;
char*                          info;
{   char filename[ 256 ];
    extern LVAL xfil76_Load_One_Graphics_File();
    int  object_number = xfil15_Crack_File_Info( filename, info );
    LVAL lv_file_object= xfil76_Load_One_Graphics_File( filename );
    c03d_rec*h         = (c03d_rec*) gobjimmbase( lv_self );
    h->fileInfo.object_number   = object_number;
    h->fileInfo.file_object     = lv_file_object;

    /* If object number changed, and we're maintaining */
    /* numbers, we need to update our object list:     */
    {   cfil_rec*f     = (cfil_rec*) gobjimmbase(     lv_file_object );
        LVAL*plv_objects_loaded = xfil13_pObjectList( lv_file_object );
	if (f->next_object_number_to_issue <= object_number) {
	    f->next_object_number_to_issue  = object_number +1;
	}
	if (*plv_objects_loaded != NIL) {
	    LVAL this = *plv_objects_loaded;
	    LVAL next;
	    for (;   consp(this);   this=cdr(next)) {
		next = cdr(this);
		if (!fixp(car(this)))xlerror("xfil34a",this);/*Impossible :)*/
		if (!consp(next))    xlerror("xfil34b",next);/*Impossible :)*/

		if (car(next) == lv_self) {
		    rplaca( this, cvfixnum(object_number) );
    }   }   }   }
}

/* }}} */
/* {{{ xfil35_Set_File_Info_Msg  Fill in fileInfo record from string.       */

LVAL xfil35_Set_File_Info_Msg() {
    LVAL lv_self   = xlgagobject();
    LVAL lv_string = xlgastring();
    xllastarg();
    if (!x03dA0_Is_A( lv_x03d, lv_self )) {
	xlerror("Obj must be [sub]CLASS-3D",lv_self);
    }
    xfil34_Set_File_Info( lv_self, getstring(lv_string) );
    return NIL;
}

/* }}} */
/* {{{ xfil38_Set_Filename                                                  */

xfil38_Set_Filename( lv_self, filename )
LVAL                 lv_self;
char                         *filename;
{   cfil_rec*h      = (cfil_rec*) gobjimmbase( lv_self );
    if (h->filename != NULL)   free( h->filename );
    h->filename     = (char*) malloc( strlen(filename) + 1 );
    strcpy(h->filename,filename);
}

/* }}} */
/* {{{ xfil40_Get_Msg -- Get keyword properties.                            */

LVAL xfil39_Get( lv_self )
LVAL             lv_self;
{
    LVAL lv_key = xlgasymbol();
    LVAL lv;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if (lv_key == k_name) {

	char    * f;
	int       n = xfil26_Number_And_Filename_Of_Gobject( &f, lv_self );
	lv          = cvstring( f );

    } else {

	/* If this isn't a property we know, do a generic get property: */
        lv = xthl8a_GetObjectProp( lv_self, lv_key, default_val, got_default );
    }
    return lv;
}

LVAL xfil40_Get_Msg()
/*-
    Return keyword properties for a file object.
-*/
{
    return xfil39_Get( xfil01_Get_A_XFIL() );
}

/* }}} */
/* {{{ xfil42_Put_Msg -- Write keyword properties.                          */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Put, update XFIL_PROPS and xfil94_ProplistNth. */
#define XFIL_PROPS (1)

LVAL xfil41_Put( lv_self )
LVAL             lv_self;
{
    while (moreargs()) {
        LVAL init = xlgasymbol();
	LVAL arg;

	if (init == k_name) {

	    LVAL lv_filename= xlgastring();
	    xfil38_Set_Filename( lv_self, getstring(lv_filename) );

	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_self, init, xlgetarg() );
    }   }
    return lv_self;
}

LVAL xfil42_Put_Msg()
/*-
    Read keyword properties for a file object.
-*/
{
    LVAL   lv_self = xfil01_Get_A_XFIL();
    LVAL   result    = xfil41_Put( lv_self );
    return result;
}

/* }}} */
/* {{{ xfil44_Set_Instance_Variable_Msg  Set any named instance variable.   */

xfil43_Set_Instance_Variable( lv_self, lv_varSymbol, lv_varValue )
LVAL                          lv_self, lv_varSymbol, lv_varValue;
{   LVAL* plv_symVal;
    if (!x03dA0_Is_A( lv_x03d, lv_self )) xlerror("xfil42",lv_self);
    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
	    /*obj*/   lv_self,
	    /*cls*/   getclass(lv_self),
	    /*sym*/   lv_varSymbol,
	    /*ppval*/ &plv_symVal
    );
    *plv_symVal = lv_varValue;
}
LVAL xfil44_Set_Instance_Variable_Msg() {
    /* This little hack *totally* breaks the wall around the */
    /* (nonbinary) internals of an object, which is very     */
    /* handy for file-restore, and otherwise undocumented :) */
    LVAL lv_self      = xlgetarg();
    LVAL lv_varSymbol = xlgasymbol();
    LVAL lv_varValue  = xlgetarg();
    xllastarg();
    xfil43_Set_Instance_Variable( lv_self, lv_varSymbol, lv_varValue );
    return lv_varValue;
}

/* }}} */
/* {{{ xfil46_Set_Anonymous_Variable_Msg  Set any unnamed instance variable.*/

xfil45_Set_Anonymous_Variable( lv_self, varNumber, lv_varValue )
LVAL                           lv_self;
int                                     varNumber;
LVAL                                               lv_varValue;
{   if (!x03dA0_Is_A( lv_x03d, lv_self )) xlerror("x03d44",lv_self);
    if (varNumber >= getgobjarraylvals(lv_self)) {
	xgbj02_Set_Size_In_Lvals( lv_self, varNumber );
    }
    xgbj06_Set_Lval( lv_self, varNumber, lv_varValue );
}
LVAL xfil46_Set_Anonymous_Variable_Msg() {
    /* This little hack helps break the wall around the      */
    /* (nonbinary) internals of an object, which is very     */
    /* handy for file-restore, and otherwise undocumented :) */
    LVAL lv_self      = xlgetarg();
    LVAL lv_varNumber = xlgafixnum();
    LVAL lv_varValue  = xlgetarg();
    xllastarg();
    xfil45_Set_Anonymous_Variable( lv_self, getfixnum(lv_varNumber), lv_varValue );
    return lv_varValue;
}

/* }}} */
/* {{{ xfil50_Maybe_Note_New_3D_Object  Remember which file new obj is in.  */

xfil50_Maybe_Note_New_3D_Object( lv_self )
LVAL				 lv_self;
{   cfil_rec*f;
    cfil_rec*h      = (cfil_rec*) gobjimmbase( lv_self );

    /* See if there's a 'current file' 3d objects are supposed to go in: */
    if (cfil0a_Current_xfil == NULL) {
	/* No open file.  fileInfo record should be already  */
	/* initialized, but it's cheaper to do it again than */
	/* track down the bug if it's not *grin* so:         */
	h->fileInfo = c03d_fileInfo_Init;
	return;
    }



    /* Hee, there *is* a 'current file'.  Enter ourself in it, */
    /* and issue ourself a unique number within the file:      */
    f   = (cfil_rec*) gobjimmbase( cfil0a_Current_xfil );

    /* First, check that we've not run out of numbers to issue.*/
    /* Not very likely, but not very expensive to check:       */
    if (f->next_object_number_to_issue == ((unsigned)~0)>>1) {
	xlerror("xfil50:out of #s!",cfil0a_Current_xfil);
    }

    /* Remember what file we're in: */
    h->fileInfo.file_object   =      cfil0a_Current_xfil;


    /* Okie, if we're creating objects as part of loading a file,  */
    /* we need to thread ourself on the list of objects in current */
    /* file... but we don't need a real number, will get it later: */
    if (cfil0b_Current_xfil_ObjectList == NULL) {
	/* Now actually issue ourself a number: */
	h->fileInfo.object_number = f->next_object_number_to_issue++;
        return;
    }
    /* Allow dups 'cause we do *not* want all -1 props merged :) */
    xthl81_SetProp_Dups_Ok(
	cfil0b_Current_xfil_ObjectList,     /* pPropertylist */
        cvfixnum(-1),			    /* property      */
	lv_self                             /* value         */
    );
}

/* }}} */
/* {{{ xfil57_Get_Name_Of_Current_Graphics_File_Fn				*/

LVAL xfil57_Get_Name_Of_Current_Graphics_File_Fn() {
    cfil_rec* h;
    xllastarg();
    if (cfil0a_Current_xfil == NULL)   return NIL;
    h = (cfil_rec*) gobjimmbase( cfil0a_Current_xfil );
    return cvstring(h->filename);
}

/* }}} */
/* {{{ xfil58_Set_Current_Graphics_File_Fn					*/

LVAL xfil58_Set_Current_Graphics_File_Fn() {
#ifdef OLD
    LVAL lv_filename = xlgastring();
    LVAL result = xfil75_Find_Loaded_Graphics_File( getstring( lv_filename ) );
    xllastarg();
    if (result == NULL)   result = NIL;
    else {
	cfil0a_Current_xfil 		= result;
	cfil0b_Current_xfil_ObjectList  = NULL; /* A bug? */
    }
    return result;
#else
    LVAL lv_filename = xlgetarg();
    LVAL result;
    xllastarg();
    if (lv_filename == NIL) {
        result = NIL;
    } else if (stringp(lv_filename)) {
	result = xfil75_Find_Loaded_Graphics_File( getstring( lv_filename ) );
    } else {
	xlbadtype(lv_filename);
    }
    cfil0a_Current_xfil 		= result;
    cfil0b_Current_xfil_ObjectList  = NULL; /* A bug? */
    return result;
#endif
}

/* }}} */
/* {{{ xfil59_Get_Names_Of_Loaded_Graphics_Files_Fn				*/

LVAL xfil59_Get_Names_Of_Loaded_Graphics_Files_Fn() {
    LVAL lv_result;
    xllastarg();
    xlsave1(lv_result);
    {   LVAL*plv_files_loaded = xfil14_pFileList();
	LVAL  lv;
	for (lv = *plv_files_loaded;   consp(lv);   lv = cdr(lv)) {
	    cfil_rec* h;
	    LVAL lv_this_xfil = car(lv);
	    h = (cfil_rec*) gobjimmbase( lv_this_xfil );
	    lv_result = cons( cvstring(h->filename), lv_result );
    }	}
    xlpop();
    return lv_result;
}

/* }}} */
/* {{{ xfil68_Save_Graphics_File_Fn -- Save named graphics file.		*/

struct xfil60_rec {
    FILE* fdoa;
    FILE* fdob;
    LVAL  lv_xfil;
    int (*fn)();
};
xfil64_Write_Object( r, lv_obj )
struct xfil60_rec   *r;
LVAL                    lv_obj;
{   /* Don't assume c03d_fileInfo record is present */
    /* unless gobject is descended from x03d:       */
    if (x03dA0_Is_A( lv_x03d, lv_obj )) {

	/* Locate the c03d_fileInfo record in lv_obj. */
	/* Since we require it always to be present   */
	/* and at the same offset, it suffices to use */
	/* our own record structure in the cast, even */
	/* though it's likely not an xfil:            */
	cfil_rec* h = (cfil_rec*) gobjimmbase( lv_obj );

	/* Add object to our list iff it belongs to   */
	/* current file, keeping in mind that object  */
	/* may actually be garbage at moment, so we   */
	/* need to protect it to avoid hanging ptr:   */
	if (h->fileInfo.file_object == r->lv_xfil) {
	    r->fn( r->fdoa, r->fdob, lv_obj );
    }   }
    return FALSE; /* Continue iteration. */
}
LVAL xfil66_Save_Graphics_File( filename )
char		               *filename;
{   FILE* fdoa;
    FILE* fdob;
    FILE* osaopen();
    FILE* osbopen();
    char  buf[256];
    struct xfil60_rec r;
    extern xfil27_Write_Object_To_Graphics_File();
    extern xfil30_Write_Objects_Lvals_To_Graphics_File();

    /* Locate our xfil instance: */
    LVAL lv_our_xfil = xfil75_Find_Loaded_Graphics_File( filename );
    if  (lv_our_xfil == NULL) {
	sprintf(buf,"No file '%s' loaded!",filename);
	xlfail(buf);
    }

    /* Do a garbage collection to avoid saving out garbage: */
    gc();

    /* Open ascii output file: */
    if ((fdoa = osaopen( filename, "w" )) == NULL) {
	sprintf(buf,"Could not create '%s'",filename);
	xlfail(buf);
    }

    /* Open binary output file: */
    {   char binary_filename[256];
	xfil74_Construct_Name_Of_Binary_File( binary_filename, filename );
        if ((fdob = osbopen( binary_filename, "w" )) == NULL) {
	    sprintf(buf,"Could not create '%s'",binary_filename);
	    xlfail(buf);
        }

	/* Write a header to the file: */
	fprintf(
	    fdoa,
	    ";;; Skandha4 XFIL-SAVE-GRAPHICS-FILE filepair\n;;;   (%s %s)\n;;;\n",
	    filename,
	    binary_filename
	);
	fprintf(
	    fdoa,
	    ";;; Read by (XFIL-LOAD-GRAPHICS-FILE \"%s\")\n\n",
	    filename
	);
    }

    /* Make a pass writing out all the objects in file: */
    fputs(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n",fdoa);
    fputs(";;; Create all our objects ;;;\n",fdoa);
    fputs(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n",fdoa);
    r.fn      = xfil27_Write_Object_To_Graphics_File;
    r.fdoa    = fdoa;
    r.fdob    = fdob;
    r.lv_xfil = lv_our_xfil;
    xgbj64_All_Live_Gobjects( xfil64_Write_Object, &r );

    /* Make a pass writing out all the lvals in our objects: */
    fputs(";;;;;;;;;;;;;;;;;;;;;;;;;\n",fdoa);
    fputs(";;; Restore our LVALS ;;;\n",fdoa);
    fputs(";;;;;;;;;;;;;;;;;;;;;;;;;\n",fdoa);
    r.fn      = xfil30_Write_Objects_Lvals_To_Graphics_File;
    xgbj64_All_Live_Gobjects( xfil64_Write_Object, &r );

    /* Close file: */
    osclose( fdob ); /* Leave fdoa open so caller can add more stuff. */

    fputs(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n",fdoa);
    fputs(";;; Application-specific code ;;;\n",fdoa);
    fputs(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n",fdoa);

    return cvfile(fdoa);
}
LVAL xfil67_Save_Graphics_File( lv_filename )
LVAL		                lv_filename;
{
    return xfil66_Save_Graphics_File( getstring(lv_filename) );
}
LVAL xfil68_Save_Graphics_File_Fn()
{   LVAL lv_filename = xlgastring();
    xllastarg();
    return xfil67_Save_Graphics_File(lv_filename);
}

/* }}} */
/* {{{ xfil72_Write_Sexp_To_File_Fn                                         */

LVAL xfil72_Write_Sexp_To_File_Fn()
{   LVAL lv_exp = xlgetarg();
    LVAL lv_fd  = xlgastream();
    FILE*fd     = getfile(lv_fd);
    xllastarg();
    xfil29_Write_Sexp_To_Graphics_File( fd, fd, lv_exp );
    return NIL;
}

/* }}} */
/* {{{ xfil82_Load_Graphics_File_Fn -- Load named graphics file.	*/

struct xfil70_rec {
    LVAL lv_xfil;
    LVAL lv_list;
};
xfil74_Construct_Name_Of_Binary_File( buf, filename )
char                                 *buf,*filename;
{   /* Change .lsp extention to .bin: */
    int   len = strlen(filename);
    char* ext;
    strcpy( buf, filename );
    ext = &buf[len-4];

    if (len > 4   &&   !strcmp(".lsp",ext))   strcpy(ext,".bin");
    else                                      strcat(buf,".bin");
}
LVAL xfil75_Find_Loaded_Graphics_File( filename )
char*                                 *filename;
{   LVAL*plv_files_loaded = xfil14_pFileList();
    LVAL  lv;
    for (lv = *plv_files_loaded;   consp(lv);   lv = cdr(lv)) {
	cfil_rec* h;
	LVAL lv_this_xfil = car(lv);
        if (!x03dA0_Is_A( lv_xfil, lv_this_xfil)) xlerror("not xfil",lv_this_xfil);
	h = (cfil_rec*) gobjimmbase( lv_this_xfil );
	if (!strcmp( h->filename, filename )) {
	    return lv_this_xfil;
    }	}
    return NULL;
}
LVAL xfil76_Load_One_Graphics_File( filename )
char*                              *filename;
{   /* If file is already loaded, we merely return the xfil instance. */

    /* Create xfil instance for file being loaded, checking that    */
    /* it doesn't already exist, and leave it as current-file:      */
    struct xfil70_rec r;
    LVAL lv_xfile = xfil75_Find_Loaded_Graphics_File( filename );
/*printf("xfil76_Load_One_Graphics_File called, filename s='%s'...\n",filename);*/
    if  (lv_xfile != NULL)   return lv_xfile;

    /* Create       xfil instance for given file: */
    lv_xfile    = xsendmsg0(lv_xfil,k_new);
    xfil38_Set_Filename( lv_xfile, filename );

    {   /* Switch 'current' xfil to be the one we're loading, so that */
	/* all 3d-dir objects loaded will create themselves "in" the  */
	/* correct file:                                              */
	LVAL lv_old_xfilthis      = getvalue(s_xfilthis);
	LVAL lv_old_xfilfdbinary  = getvalue(s_xfilfdbinary);
	LVAL lv_old_xfil          = cfil0a_Current_xfil;
	LVAL*old_xfil_objList     = cfil0b_Current_xfil_ObjectList;
	char  binary_filename[256];
	FILE *osbopen();
	FILE *fp;
	/* Shouldn't really need most of these protects, but why not: */
	int  toProtect = 4;
	xlstkcheck(toProtect);
	xlprotect(lv_xfile);
	xlprotect(lv_old_xfil);
	xlprotect(lv_old_xfilthis);
	xlprotect(lv_old_xfilfdbinary);
	cfil0a_Current_xfil            = lv_xfile                      ;
	cfil0b_Current_xfil_ObjectList = xfil13_pObjectList( lv_xfile );

	/* Open binary input file if we can find it: */
	xfil74_Construct_Name_Of_Binary_File( binary_filename, filename );
/*printf("xfil76_Load_One_Graphics_File called, binary_filename s='%s'...\n",binary_filename);*/
	if ((fp = osbopen(binary_filename,"r")) != NULL) {
/*printf("xfil76_Load_One_Graphics_File called, opened binary_filename s='%s' ok...\n",binary_filename);*/
	    setvalue(s_xfilfdbinary,cvfile(fp));
        }

	/* Actually load the file: */
	xlload( filename, /*verbose:*/FALSE, /*print:*/FALSE );

	/* Restore status quo ante: */
	setvalue(s_xfilthis,lv_old_xfilthis);
	setvalue(s_xfilfdbinary,lv_old_xfilfdbinary);
	cfil0a_Current_xfil            = lv_old_xfil     ;
	cfil0b_Current_xfil_ObjectList = old_xfil_objList;
	xlpopn(toProtect);
    }
/*printf("xfil76_Load_One_Graphics_File return x=%x\n",lv_xfile);*/
    return lv_xfile;
}
xfil78_All_Gobjects_BuildList( r, lv_obj )
struct xfil70_rec             *r;
LVAL                              lv_obj;
{   /* Don't assume c03d_fileInfo record is present */
    /* unless gobject is descended from x03d:       */
    if (x03dA0_Is_A( lv_x03d, lv_obj )) {

	/* Locate the c03d_fileInfo record in lv_obj. */
	/* Since we require it always to be present   */
	/* and at the same offset, it suffices to use */
	/* our own record structure in the cast, even */
	/* though it's likely not an xfil:            */
	cfil_rec* h = (cfil_rec*) gobjimmbase( lv_obj );

	/* Add object to our list iff it belongs to   */
	/* current file, keeping in mind that object  */
	/* may actually be garbage at moment, so we   */
	/* need to protect it to avoid hanging ptr:   */
	if (h->fileInfo.file_object == r->lv_xfil) {
	    xlprot1(lv_obj);
	    r->lv_list = cons( lv_obj, r->lv_list );
	    xlpop();
    }   }
    return FALSE; /* Continue iteration. */
}
xfil79_All_Files_BuildList( lv_xfile )
LVAL                        lv_xfile;
{   /* Find address in which to place list */
    /* of all objects loaded in this file: */
    LVAL*plv_objects_loaded = xfil13_pObjectList( lv_xfile );
    struct xfil70_rec r;

    /* Build list of all ram objects belonging in our file: */
    r.lv_xfil = lv_xfile;
    r.lv_list = NIL;	/* List we're building. */
    xlprot1(r.lv_list);
    xgbj64_All_Live_Gobjects( xfil78_All_Gobjects_BuildList, &r );

    /* Save list of objects belonging to file. */
    /* OBJECT-LIST should normally be NIL at   */
    /* this point, in any event we overwrite:  */
    *plv_objects_loaded = r.lv_list;

    xlpop();
    return FALSE; /* continue iteration. */
}
LVAL xfil81_Load_Graphics_File( lv_filename )
LVAL		                lv_filename;
{   LVAL  lv_objects_loaded;
    LVAL  lv_files_loaded;
    LVAL*plv_files_loaded;
    LVAL  lv_xfile;
    LVAL  lv_result;
    char*    filename = (char*)getstring( lv_filename );
    int  to_protect = 4;

    /* Check that file is not already loaded: */
    if (xfil75_Find_Loaded_Graphics_File(filename) != NULL) {
	xlerror("Graphics file already loaded!",lv_filename);
    }

    xlstkcheck(to_protect);
    xlprotect( lv_filename       );
    xlsave(    lv_objects_loaded );
    xlsave(    lv_files_loaded   );
    xlsave(    lv_xfile          );
    xlsave(    lv_result         );

    /* Get list of already-loaded graphics files from class object: */
    plv_files_loaded = xfil14_pFileList();
    lv_files_loaded  = *plv_files_loaded;
    
    /* Have each already-loaded graphics file, make a list of all   */
    /* objects in that file, by scanning memory:                    */
    {   LVAL  lv;
	for (lv = lv_files_loaded;   consp(lv);   lv = cdr(lv)) {
	    xfil79_All_Files_BuildList( car(lv) );
    }	}

    /* Now that we have the datastructures initialized which        */
    /* XFIL-REF will need, proceed to actually load our file:       */
    lv_result = xfil76_Load_One_Graphics_File( filename );

    /* Have all the graphics files forget their lists of objects,   */
    /* so their objects can get garbage-collected normally:         */
    plv_files_loaded = xfil14_pFileList();	/* 97Feb11jsp fix   */
    lv_files_loaded  = *plv_files_loaded;	/* 97Feb11jsp fix   */
    {   LVAL  lv;
        for  (lv = lv_files_loaded;   consp(lv);   lv = cdr(lv)) {
	    LVAL*plv_objects_loaded = xfil13_pObjectList( car(lv) );
	    *plv_objects_loaded = NIL;
    }	}

    /* Do a garbage collection, since we just freed a bunch of      */
    /* stuff, and since it can hardly slow down loading any :)      */
    xlpopn(to_protect);
    gc();

    return   lv_result;
}
LVAL xfil82_Load_Graphics_File_Fn()
{   LVAL lv_filename = xlgastring();
/*printf("xfil82_Load_Graphics_File called...\n");*/
    xllastarg();
    return xfil81_Load_Graphics_File(lv_filename);
}

/* }}} */
/* {{{ xfil84_Unload_Graphics_File_Fn -- Unload named graphics file.	*/

LVAL xfil84_Unload_Graphics_File_Fn()
{   LVAL lv_filename = xlgastring();
    char*   filename = (char*)getstring(lv_filename);
    LVAL lv_xfile    = xfil75_Find_Loaded_Graphics_File( filename );
    xllastarg();
    if (lv_xfile == NULL)   xlerror("Graphics file not loaded",lv_filename);
    xthl97_Remove( xfil14_pFileList(), lv_xfile );
    return NIL;
}

/* }}} */
/* {{{ xfil91_ProplistLength_Msg -- Return length of propertylist.          */

LVAL xfil90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{   LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XFIL_PROPS + x03d89_PropListLength( *pPropList ) );
}
LVAL xfil91_ProplistLength_Msg()
{   return xfil90_ProplistLength( xfil01_Get_A_XFIL() );
}

/* }}} */
/* {{{ xfil95_ProplistNth_Msg -- Return Nth prop from propertylist.         */

LVAL xfil94_ProplistNth( g_as_lval )
LVAL                     g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL n_as_lval  = xlgafixnum();
    int  n          = getfixnum(n_as_lval);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case 0:    return k_name;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XFIL_PROPS,
	    n_as_lval,
	    default_val,
	    got_default
	);
    }
}

LVAL xfil95_ProplistNth_Msg()
/*-
    Return Nth item from propertylist.
-*/
{
    return xfil94_ProplistNth( xfil01_Get_A_XFIL() );
}

/* }}} */

/* {{{ State printout for debugging					*/

void
xfila0_Debug_Printout( LVAL lv_xfile )
{   /* Find address in which to place list */
    /* of all objects loaded in this file: */
    LVAL*plv_objects_loaded = xfil13_pObjectList( lv_xfile );
    LVAL  lv_objects_loaded = *plv_objects_loaded;
    LVAL  lv;

    for (lv = lv_objects_loaded;  consp(lv);  lv = cdr(lv)) {
	printf("    %x\n",car(lv));
    }
}
LVAL xfila1_Debug_Printout_Fn()
/*-
    Debug printout
-*/
{
    LVAL* plv_files_loaded = xfil14_pFileList();
    LVAL   lv_files_loaded  = *plv_files_loaded;
    LVAL   lv;    
    for (lv = lv_files_loaded;   consp(lv);   lv = cdr(lv)) {
	cfil_rec*  p;
	if (!xfilp(car(lv))) {
	    xlerror("xfila1",car(lv));
        }
	p = (cfil_rec*) gobjimmbase( car(lv) );
	printf("  car(lv) %x == '%s'\n",car(lv),p->filename);
	xfila0_Debug_Printout( car(lv) );
    }

    return NIL;
}


/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */




