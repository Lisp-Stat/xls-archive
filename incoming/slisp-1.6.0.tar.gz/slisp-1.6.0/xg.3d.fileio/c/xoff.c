/* {{{ xoff.c -- Fns to read OFF (neutral file format) files.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Mar08
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Mar08 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"

#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cmtl.h"

extern LVAL xsendmsg0(); 
extern LVAL xsendmsg1(); 
extern LVAL xsendmsg2(); 

#define PaSCII  (1)
#define PbINARY (2)

#define UsAMEsTRING (0)

union uAnyType {
    int       uI;
    int   *   uP;
    float     uF;
    float *   uFP;
    char  *   uT;
    LVAL      uL;
    short *   uSP;
    int     (*uFn)();
};
#define uAny		union uAnyType

LVAL xoff89_Load_File();

#define XOFF_MAX_TEXT (200)
char  xoff00_Text_Buffer[ XOFF_MAX_TEXT ];

int  xoff04_Point_Grl_Valid = FALSE;
LVAL xoff05_Point_Grl;

int  xoff06_Facet_Grl_Valid = FALSE;
LVAL xoff07_Facet_Grl;

int  xoff0a_Material_Valid  = FALSE;
LVAL xoff0b_Material;

LVAL xoffol_ThingList;

int  xoffpn_PointCount;
LVAL xoffpx_PointX;
LVAL xoffpy_PointY;
LVAL xoffpz_PointZ;
/* Point(vertex) normals: */
LVAL xoffvx_PtNmlX;
LVAL xoffvy_PtNmlY;
LVAL xoffvz_PtNmlZ;

int  xofffn_FacetCount;
LVAL xofff0_Facet0;
LVAL xofff1_Facet1;
LVAL xofff2_Facet2;

int xofftp_TotalPolygons;
int xoffig_IgnoreThisOne;

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xoff10_viewing_vectors_and_angles                                */

xoff10_viewing_vectors_and_angles( fd )
FILE *	    			   fd;
{
    float f;

    xoff88_Read_Line( fd );
    xoff88_Read_Line( fd );
    xoff88_Read_Line( fd );
    xoff88_Read_Line( fd );
    xoff88_Read_Line( fd );
    xoff88_Read_Line( fd );
#ifdef CRIB
    from %g %g %g
    at %g %g %g
    up %g %g %g
    angle %g
    hither %g
    "resolution" xres yres
#endif
}

/* }}} */
/* {{{ xoff20_positional_light_location                                     */

xoff20_positional_light_location( fd )
FILE *	    			  fd;
{
#ifdef CRIB
    l %g %g %g
#endif
}

/* }}} */
/* {{{ xoff3_background_color                                               */

xoff30_background_color( fd )
FILE *	    		 fd;
{
#ifdef CRIB
    b %g %g %g
#endif
}

/* }}} */
/* {{{ xoff40_thing_material_properties                                    */

xoff40_thing_material_properties( fd )
FILE *	    		 	   fd;
{
#ifdef CRIB
    f %g %g %g %g %g %g %g %g
#endif
}

/* }}} */
/* {{{ xoff50_cone_or_cylinder_primitive                                    */

xoff50_cone_or_cylinder_primitive( fd )
FILE *	    		 	   fd;
{
    printf("OFF Cones and Cylinders not supported yet\n");
    exit(1);
}

/* }}} */
/* {{{ xoff60_sphere_primitive                                              */

xoff60_sphere_primitive( fd )
FILE *	    		 fd;
{
    printf("OFF Spheres not supported yet\n");
    exit(1);
}

/* }}} */
/* {{{ xoff70_polygon_primitive                                             */

xoff70_polygon_primitive( fd )
FILE *	    		  fd;
{
#ifdef MORE_CORRECT
    printf("OFF polygon primitives not supported yet\n");
    exit(1);
#endif
    xoff88_Read_Line( fd );
    xoff88_Read_Line( fd );
    xoff88_Read_Line( fd );
}

/* }}} */
/* {{{ xoff80_polygon_patch_primitive                                       */

xoff80_polygon_patch_primitive( fd )
FILE *	    		        fd;
{
    extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xflv;

    extern LVAL k_pointx;
    extern LVAL k_pointy;
    extern LVAL k_pointz;

    extern LVAL k_pointnormalx;
    extern LVAL k_pointnormaly;
    extern LVAL k_pointnormalz;

    extern LVAL k_setarray;
    extern LVAL k_adjustarray;

    int* array0;
    int* array1;
    int* array2;

    float* arrayX;
    float* arrayY;
    float* arrayZ;

    float* normlX;
    float* normlY;
    float* normlZ;

    int    pbase = xoffpn_PointCount;
    int    fbase = xofffn_FacetCount;

    LVAL lv_facetcount;
    LVAL lv_pointcount;

    int total_vertices;
    int i;
    float  x,  y,  z; 
    float nx, ny, nz; 
    sscanf( xoff00_Text_Buffer, "pp %d", &total_vertices ); 
    if (total_vertices != 3) {
	printf("nontriangle patches not handled yet!\n");
	exit(1);
    }

    ++xofffn_FacetCount;
/*printf("\nresizing facet array to %d\n",xofffn_FacetCount);*/
    lv_facetcount      = cvfixnum( xofffn_FacetCount );
    xsendmsg1( xoff07_Facet_Grl, k_adjustarray, lv_facetcount );

    xoffpn_PointCount += 3;
/*printf("\nresizing point array to %d\n",xoffpn_PointCount);*/
    lv_pointcount      = cvfixnum( xoffpn_PointCount );
    xsendmsg1( xoff05_Point_Grl, k_adjustarray, lv_pointcount );

    /* Get pointers to the actual int areas, for speed.   */
    /* note that these areas can move during a resize,    */
    /* hence this must follow the above resize...	      */
    array0 = (int*) (csry_base( xofff0_Facet0 ));
    array1 = (int*) (csry_base( xofff1_Facet1 ));
    array2 = (int*) (csry_base( xofff2_Facet2 ));

    /* Get pointers to the actual float areas, for speed. */
    /* note that these areas can move during a resize,    */
    /* hence this must follow the above resize...	      */
    arrayX = (float*) (csry_base( xoffpx_PointX ));
    arrayY = (float*) (csry_base( xoffpy_PointY ));
    arrayZ = (float*) (csry_base( xoffpz_PointZ ));

    normlX = (float*) (csry_base( xoffvx_PtNmlX ));
    normlY = (float*) (csry_base( xoffvy_PtNmlY ));
    normlZ = (float*) (csry_base( xoffvz_PtNmlZ ));

    for (i = 0;   i < total_vertices;   ++i) {
	xoff88_Read_Line( fd );
	sscanf( xoff00_Text_Buffer, "%f %f %f %f %f %f",
	   & x, & y, & z,
	   &nx, &ny, &nz
	); 
/*printf("Line scanfed: %g %g %g %g %g %g\n",
x, y, z,nx, ny, nz); */
        arrayX[ pbase + i ] =  x;
        arrayY[ pbase + i ] =  y;
        arrayZ[ pbase + i ] =  z;

        normlX[ pbase + i ] = nx;
        normlY[ pbase + i ] = ny;
        normlZ[ pbase + i ] = nz;
    }

    array0[ fbase ] = pbase + 0;
    array1[ fbase ] = pbase + 1;
    array2[ fbase ] = pbase + 2;
}

/* }}} */
/* {{{ xoff88_Read_Line             Read line of text from given input file */

xoff88_Read_Line( fd )
FILE *	     fd;
{ 
    int      i; 
    char *   s; 
    int      c; 
  
    do {
	i   = XOFF_MAX_TEXT;
	s   = xoff00_Text_Buffer; 
	while (i-- && ((c=fgetc( fd )) != EOF) && (c != '\n')) { 
	    if (c == '\t')   c = ' '; 
	    if (c != '\r'   &&   c != 0xFF)   *s++ = c; 
	} 
	if (i < 1)	 xlfail("xoff88_Read_Line");
	*s = '\0'; 

    } while (*xoff00_Text_Buffer == '#');

/*printf("input line=%s\n", xoff00_Text_Buffer);*/
    return   c != EOF; 
} 

LVAL xoff87_Create_Grls( fd )
FILE *			 fd;
{
    extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xflv;
    extern LVAL lv_x32v;

    extern LVAL k_pointx;
    extern LVAL k_pointy;
    extern LVAL k_pointz;

    extern LVAL k_pointnormalx;
    extern LVAL k_pointnormaly;
    extern LVAL k_pointnormalz;

    extern LVAL k_facet0;
    extern LVAL k_facet1;
    extern LVAL k_facet2;

    extern LVAL k_setarray;

    extern LVAL k_show;

    extern LVAL k_material;
    extern LVAL k_pointrelation;
    extern LVAL k_facetrelation;

    char *   err_msg = "bad OFF file format!\n";

    int self_tubRefCount;

    LVAL lv_result;
    LVAL lv_tubName;
    LVAL lv_pointCount;
    LVAL lv_facetCount;

    int        toProt = 15;
/*printf("top of tub...\n");*/
    xlstkcheck(toProt);

    xlsave(lv_result);

    xlsave(xoff05_Point_Grl);
    xlsave(xoff07_Facet_Grl);

    xlsave(lv_tubName);
    xlsave(lv_pointCount);
    xlsave(lv_facetCount);

    xlsave(xoffpx_PointX);
    xlsave(xoffpy_PointY);
    xlsave(xoffpz_PointZ);

    xlsave(xoffvx_PtNmlX);
    xlsave(xoffvy_PtNmlY);
    xlsave(xoffvz_PtNmlZ);

    xlsave(xofff0_Facet0);
    xlsave(xofff1_Facet1);
    xlsave(xofff2_Facet2);

    /* Sanity check ... skandha3 lets them get away with murder ...	*/
    /* shouldn't really crash, of course ...				*/
    if (xoff04_Point_Grl_Valid)  xlfail("nested tubes!");
    if (xoff06_Facet_Grl_Valid)  xlfail("nested tubes!");



    /* Create our point relation: */
    xoffpn_PointCount	= 0;
    lv_pointCount	= cvfixnum(xoffpn_PointCount);
    xoff05_Point_Grl	= xsendmsg1( lv_xgrl, k_new, lv_pointCount );
    xoff04_Point_Grl_Valid = TRUE;

    /* Create point-x/y/z arrays to go in point relation: */
    xoffpx_PointX	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xoffpy_PointY	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xoffpz_PointZ	= xsendmsg1( lv_xflv, k_new, lv_pointCount );

    /* Insert point-x/y/z arrays in point relation: */
    xsendmsg2( xoff05_Point_Grl, k_setarray, k_pointx, xoffpx_PointX );
    xsendmsg2( xoff05_Point_Grl, k_setarray, k_pointy, xoffpy_PointY );
    xsendmsg2( xoff05_Point_Grl, k_setarray, k_pointz, xoffpz_PointZ );

    /* Create point-normal-x/y/z arrays to go in point relation: */
    xoffvx_PtNmlX	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xoffvy_PtNmlY	= xsendmsg1( lv_xflv, k_new, lv_pointCount );
    xoffvz_PtNmlZ	= xsendmsg1( lv_xflv, k_new, lv_pointCount );

    /* Insert point-normal-x/y/z arrays in point relation: */
    xsendmsg2( xoff05_Point_Grl, k_setarray, k_pointnormalx, xoffvx_PtNmlX );
    xsendmsg2( xoff05_Point_Grl, k_setarray, k_pointnormaly, xoffvy_PtNmlY );
    xsendmsg2( xoff05_Point_Grl, k_setarray, k_pointnormalz, xoffvz_PtNmlZ );



    /* Create our facet relation: */
    xofffn_FacetCount	= 0;
    lv_facetCount	= cvfixnum(xofffn_FacetCount);
    xoff07_Facet_Grl	= xsendmsg1( lv_xgrl, k_new, lv_facetCount );
    xoff06_Facet_Grl_Valid = TRUE;

    /* Create facet-0/1/2 arrays to go in facet relation: */
    xofff0_Facet0	= xsendmsg1( lv_x32v, k_new, lv_facetCount );
    xofff1_Facet1	= xsendmsg1( lv_x32v, k_new, lv_facetCount );
    xofff2_Facet2	= xsendmsg1( lv_x32v, k_new, lv_facetCount );

    /* Insert facet-0/1/2 arrays in facet relation: */
    xsendmsg2( xoff07_Facet_Grl, k_setarray, k_facet0, xofff0_Facet0 );
    xsendmsg2( xoff07_Facet_Grl, k_setarray, k_facet1, xofff1_Facet1 );
    xsendmsg2( xoff07_Facet_Grl, k_setarray, k_facet2, xofff2_Facet2 );



    while (xoff88_Read_Line( fd )) {
	switch (*xoff00_Text_Buffer) {
	case '#':						break;
        case 'v': xoff10_viewing_vectors_and_angles( fd );	break;
        case 'l': xoff20_positional_light_location(  fd );	break;
        case 'b': xoff30_background_color(	     fd );	break;
        case 'f': xoff40_thing_material_properties( fd );	break;
        case 'c': xoff50_cone_or_cylinder_primitive( fd );	break;
        case 's': xoff60_sphere_primitive(	     fd );	break;
        case 'p':
	    switch (xoff00_Text_Buffer[1]) {
	    case ' ':     xoff70_polygon_primitive(  	   fd );break;
	    case 'p':     xoff80_polygon_patch_primitive(  fd );break;
	    default:
		printf(err_msg);
		abort();
	    }		
	    break;
	default:
	    printf("Unrecognized OFF operator: %c\n",*xoff00_Text_Buffer);
	    printf(err_msg);
	    abort();
	}
    }
/*printf("done reading input file...\n");*/

    /* Close file: */ 
    fclose( fd );
/*printf("xoff80: Total polygons d=%d\n",xofffn_FacetCount);*/

/*printf("xoff80: Facet grl:\n");
xsendmsg0( xoff07_Facet_Grl, k_show );
printf("xoff80: Point grl:\n");
xsendmsg0( xoff05_Point_Grl, k_show );*/

    /* Construct return value: */
    lv_result     = cons( xoff07_Facet_Grl,       NIL );
    lv_result     = cons( k_facetrelation , lv_result );
    lv_result     = cons( xoff05_Point_Grl, lv_result );
    lv_result     = cons( k_pointrelation , lv_result );
    if (xoff0a_Material_Valid) {
printf("xoff80: MATERIAL IS VALID?\n");
	lv_result = cons( xoff0b_Material , lv_result );
	lv_result = cons( k_material      , lv_result );
    }

    /* Prepend return value (new thing) to global thinglist: */
    xoffol_ThingList = cons( lv_result, xoffol_ThingList );

    xlpopn(toProt);

    xoff04_Point_Grl_Valid = FALSE;
    xoff06_Facet_Grl_Valid = FALSE;

    return lv_result;
}

/* }}} */
/* {{{ xoff89_Load_File                                                     */

LVAL xoff89_Load_File( fileName )
char		      *fileName; 
{ 
    FILE *   fd; 
    int      fileType; 
    char     model[ 1000 ]; 
    char     typ[   1000 ]; 
    LVAL     child; 
  
    /* Open input file: */ 
    { 
        char *   t; 
  
	if (! (fd = fopen( fileName, "rb" ))) {
	    /* Buggo ... shouldn't really crash on file not found: */
	    sprintf(model, "File not found: %s", fileName);
            xlfail( model ); 
        } 
    } 
  
    return xoff87_Create_Grls( fd );
} 

/* }}} */
/* {{{ xoff90_Load_OFF_File_Fn -- Load a OFF (neutral file format) file.	*/

LVAL xoff90_Load_OFF_File_Fn()
{
    LVAL  lv_filename = xlgastring();
    char*    filename = (char*) getstring( lv_filename );
    xllastarg();

    /* Concatenate all tubes together into an thinglist, and return: */
    xlsave1(xoffol_ThingList);
    xofftp_TotalPolygons = 0;
    xoff89_Load_File( filename );
printf("xoff90_Load_OFF_File_Fn: Total polygons d=%d\n",xofftp_TotalPolygons);
    xlpop();
    {   LVAL   lv_result = xoffol_ThingList;
	xoffol_ThingList= NIL;
        return lv_result;
    }
}

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

