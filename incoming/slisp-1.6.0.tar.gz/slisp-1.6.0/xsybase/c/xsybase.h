/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xsybase.h
* Description:  Template for xlisp extension-module file headers.
* Author:       Kraig Eno
* Created:      90Nov16
* Modified:     Jim Brinkley   
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Kraig Eno and Jim Brinkley)
*
*********************************************************************************/ /* Not infrequently, implementing a new xlisp class requires adding some  */
/* new primitive (== "implemented in C") functions to xlisp.  The new	  */
/* primitives may be needed to access special hardware resources, or they */
/* may be speed hacks needed to achieve acceptable performance.		  */
/* 								          */
/* This file is a template showing how to do so.  Make a copy of this	  */
/* file called, say, "xmyclass.h", insert a '#include "xmyclass.h"' line  */
/* xmodules.h, and then edit "xmyclass.h" following the directions below. */
/* REMEMBER TO DELETE ALL THE EXAMPLE CODE FROM YOUR COPY OF THIS FILE!   */
/**************************************************************************/

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLINIT
/* code to be executed on startup  */
sybaseinit();
#endif


#ifdef MODULE_XLDMEM_H_GLOBALS
/* New macros to appear in xldmem.h. */
/* New extern declarations to appear in xldmem.h. */
/**********************************************************/
/* In this section, you should declare all your primitive */
/* functions -- those which will be visible to the xlisp  */
/* programmer. Examples:                                  */
/**********************************************************/
/* DB-Library access commands */
extern LVAL xldbaddlogin();
extern LVAL xldbremovelogin();
extern LVAL xldbopen();
extern LVAL xldbclose();
extern LVAL xldbsql();
extern LVAL xldbformatstr();
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
/**********************************************************/
/* In this section, you specify the native xlisp name of  */
/* each of your primitive SUBR functions -- those which   */
/* want their arguments evaluated. (Most likely, all of   */
/* your primitives will be of this type.)		  */
/*							  */
/* Each line has two parts.				  */
/*							  */
/* The first part gives the xlisp name for your		  */
/* primitive.  Make it all upper case.  If your primitive */
/* is to be a message rather than a function, make this   */
/* this entry NULL.					  */
/*							  */
/* The second part is the name of your C function.	  */
/*							  */
/**********************************************************/
DEFINE_SUBR( "DB-ADD-LOGIN", xldbaddlogin)
DEFINE_SUBR( "DB-REMOVE-LOGIN", xldbremovelogin )
DEFINE_SUBR( "DB-OPEN", xldbopen )
DEFINE_SUBR( "DB-CLOSE", xldbclose )
DEFINE_SUBR( "DB-SQL", xldbsql )
DEFINE_SUBR( "DB-FORMATSTR", xldbformatstr)
#endif


#ifdef MODULE_XLISP_H_PROVIDE
/* Define a macro indicating that your module is being     */
/* compiled into xlisp.  This will let future modules that */
/* depend on yours test for its presence (see next).  By   */
/* convention, such macros begin with "PROVIDE_":          */
#define PROVIDE_XSYBASE
#endif





