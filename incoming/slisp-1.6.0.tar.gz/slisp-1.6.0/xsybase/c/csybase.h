/* csybase.h   */

#include <sybfront.h>
#include <sybdb.h>
#define DB_MAX_LOGINS 50
#define MAX_SERVER_NAME 20
#define MAX_FORMATTED_STRING 1000
extern void sybaseinit();
extern LVAL dbaddlogin();
extern LVAL cdbopen();
extern LVAL cdbclose();
extern LVAL dbremovelogin();
extern LVAL sqlcmd();
extern int error_handler();
extern LVAL err_return();
extern LVAL ok_return();

struct {
  int mark;
  char server[MAX_SERVER_NAME];
  LOGINREC *dblogin;
  DBPROCESS *db;
  }  dblogins[DB_MAX_LOGINS];

