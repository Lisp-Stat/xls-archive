/* xsybase.c  */

#include "../../xcore/c/xlisp.h"
#include "csybase.h"

#define INITIAL_BUF_LENGTH 2
/* Forward declarations: */
static void buf_putc();
static void buf_reset();
static void buf_double();
static void buf_init();

/* A buffer in which we return string values: */
static char* result_buf     = NULL;
static int   result_buf_len = 0;
static int   result_buf_ptr = 0;


LVAL xldbaddlogin()
{
    /* (DB-ADD-LOGIN server user password)
    Add loging record for server, user and password at next available
    login slot   */   
    LVAL nserver, nusername, npwd;
    nserver = xlgastring();
    nusername = xlgastring();
    npwd = xlgastring();
    xllastarg();
    return dbaddlogin
	(getstring(nserver), getstring(nusername), getstring(npwd) );
}

LVAL xldbremovelogin()
{  
    /* (DB-REMOVE-LOGIN  loginslot)
    Remove login record at loginslot number */
    LVAL loginslot;
    loginslot = xlgafixnum();
    xllastarg();
    return dbremovelogin(getfixnum(loginslot));
}

LVAL xldbopen()
{
    /* (DB-OPEN loginslot )
    Open database connection specified by record at loginslot */
    LVAL loginslot;
    loginslot = xlgafixnum();
    xllastarg();
    return cdbopen(getfixnum(loginslot));
}

LVAL xldbclose()
{
    /* (DB-OPEN loginslot )
    Close database connection specified by record at loginslot */
    LVAL loginslot;
    loginslot = xlgafixnum();
    xllastarg();
    return cdbclose(getfixnum(loginslot));
}

LVAL xldbsql()
/* (DB-SQL loginslot sqlquery)
Execute sqlquery for login record specified by loginslot */
{   
    LVAL str1, int1;
    int1 = xlgafixnum();
    str1 = xlgastring();
    xllastarg();
    return sqlcmd( getfixnum(int1), getstring(str1) );
}


LVAL xldbformatstr()
/* (DB-FORMATSTR format &rest args)
Generated formatted string from string arguments */
{
    LVAL fmtstring, arg;
    char *fmt, *argstr;
    int ch, field, direction, arglength, fillamount, argamount, i;
    int nlvals=2;

    /* protect some pointers */
    xlstkcheck(nlvals);
    xlsave(fmtstring);
    xlsave(arg);

    /* Get the format string and initialize result buffer */
    fmtstring = xlgastring();
    fmt = getstring(fmtstring);
    buf_reset();

    /* process the format string */
    while (ch = *fmt++)
      if (ch == '~') {
	field=0;
	direction=0;
	if (*fmt && (*fmt== '%')) {
	   buf_putc('\n');
	   fmt++;
	   }
        else  {
	   if (*fmt && ('0' <= *fmt) && (*fmt  <= '9')) {
	     field = (int)(*fmt++ - '0');
	     while (*fmt && ('0' <= *fmt) && (*fmt <= '9')) {
		field = 10*field + (int)(*fmt - '0');
		fmt++;
		}
	     }
	   if (*fmt && (*fmt == '@')) {
		direction = 1;
		fmt++;
		}
	   if (!*fmt || !(*fmt++ == 'A')) {
		xlpopn(nlvals);
		xlfail("DB-FORMATSTR: Incorrect format string");
		}
	   /* Now fill in the string */
	   arg = xlgastring();
	   argstr = getstring(arg);
	   arglength = strlen(argstr);
	   if (!field) {
	      fillamount=0;
	      argamount=arglength;
	      }
	   else {
	      fillamount = field - arglength;
	      argamount = arglength;
	      if (fillamount < 0) {
		fillamount = 0;
		argamount = field;
		}
	      }
	   if (direction) {
	     for (i=0; i <fillamount; i++) buf_putc(' ');
	     for (i=0; i <argamount; i++) buf_putc(argstr[i]);
	     }
	   else {
	     for (i=0; i <argamount; i++) buf_putc(argstr[i]);
	     for (i=0; i <fillamount; i++) buf_putc(' ');
	     }
          }
        }
      else
	buf_putc(ch);
      /* Make into an Xlisp string and return */
      xlpopn(nlvals);
      return cvstring(result_buf);
}

/* --- Internal routines ---						*/
/* {{{ buf_init -- Establish result_buf.				*/
	
static void buf_init( void ) {
    result_buf_len = INITIAL_BUF_LENGTH;
    result_buf = (char*) malloc( result_buf_len );
    if (!result_buf) {
	fputs("xsybase.c:buf_init: out of ram!?\n",stderr);
	abort();
    }
    buf_reset();
}

/* }}} */
/* {{{ buf_double -- Double size of result_buf.				*/
	
static void buf_double( void ) {
    result_buf_len *= 2;
    result_buf = (char*) realloc( result_buf, result_buf_len );
    if (!result_buf) {
	fputs("xsybase.c:buf_double: out of ram!?\n",stderr);
	abort();
    }
}

/* }}} */
/* {{{ buf_putc -- Append one char to result_buf.			*/

	
static void buf_putc( c )
int                   c;
{
    if (result_buf_ptr + 2 >= result_buf_len)   buf_double();
    result_buf[ result_buf_ptr++ ] =   c ;
    result_buf[ result_buf_ptr   ] = '\0';
}

/* }}} */
/* {{{ buf_reset -- Set result_buf to empty string 				*/
	
static void buf_reset( void ) 
{ 
    if (!result_buf_len) buf_init();
    result_buf_ptr = 0; 
    result_buf[ result_buf_ptr   ] = '\0';
}

/* }}} */
