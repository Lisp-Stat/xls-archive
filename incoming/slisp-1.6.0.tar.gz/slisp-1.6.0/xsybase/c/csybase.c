/* csybase.c  */

#include "../../xcore/c/xlisp.h"
#include "csybase.h"
#define MAXCOLCOUNT	50
#define MAXCOLSIZE	2048
#define min(a,b)	((a) > (b) ? (b) : (a))
extern LVAL true;

int currentloginslot;

/* Forward declarations */
int error_handler();
int message_handler();

void sybaseinit()
/* Initialize sybase db library and install error handler */
{
    int i;
    /* initialize the DB-Library */
    if (dbinit()==FAIL) exit(ERREXIT);
    /* Initialize arrays of db-logins */
    for (i=0; i<DB_MAX_LOGINS; i++)
 	dblogins[i].mark=0;
    dberrhandle( error_handler);
    dbmsghandle(message_handler);
     /* See db-sql for reasons I call dbexit here jfb */
    dbexit();
}

LVAL dbaddlogin(server, username,pwd)
char *server, *username,*pwd;
{
    /* Determine if there are login record slots available. If so fill the
    next available one with the arguments and return the slot number */
    int i;
    for (i=0; i < DB_MAX_LOGINS; i++) {
	if (!dblogins[i].mark) 
	    break;
	}
    if (i == DB_MAX_LOGINS)
	xlfail("xsybase: Not enough login slots, DB-REMOVE-LOGIN one first");
    /*	Get a Sybase LOGINREC structure, fill with appropriate access info */
    dblogins[i].dblogin=dblogin();
    dblogins[i].mark = 1;
    dblogins[i].db=0;
    strcpy(dblogins[i].server,server);
    DBSETLUSER(dblogins[i].dblogin, username );
    DBSETLPWD( dblogins[i].dblogin, pwd );
    /* Return the slot number */
    return(cvfixnum(i));
}

LVAL dbremovelogin(loginslot)
int loginslot;
{
    /* Free up login slot given by loginslot */
    if ( loginslot >= 0 && loginslot < DB_MAX_LOGINS) {
	dblogins[loginslot].mark = 0;
	return(true);
	}
    else
	xlfail("xsybase: Slot number out of bounds");
}

LVAL cdbopen(loginslot)
int loginslot;
/* Open database connection to server specified in loginslot */
{
    DBPROCESS *dbproc;
    /* Check to be sure loginslot is within bounds */
    if ( loginslot < 0 || loginslot >= DB_MAX_LOGINS) 
	xlfail("xsybase: Slot number out of bounds");
    /* Check to be sure a valid login record is at loginslot */
    if (!dblogins[loginslot].mark)
	xlfail("xsybase: Invalid login record at loginslot");
    /* Try to open connection to database. dbopen and dbclose do not remove
     connections to server so for limited sybase dataserver only five 
     connections are allowed. After that you won't be able to dbopen another 
     connection if only dbclose is used. To get around that I call dbexit
     after dbclose, and then dbinit at the beginning of dbopen. 
     I don't know how badly
     this will affect efficiency, but it works. jfb 10/14/93 */
     dbinit();
     dbproc = dbopen( dblogins[loginslot].dblogin, dblogins[loginslot].server);
     if (!dbproc)
	/* This will generally not be reached because errhandler will trap */	
	xlfail("xsybase: Unable to connect to database");
     dblogins[loginslot].db = dbproc;
     return(true);
}
     
LVAL cdbclose(loginslot)
int loginslot;
/* Close database connection to server specified in loginslot */
{
    DBPROCESS *dbproc;
    /* Check to be sure loginslot is within bounds */
    if ( loginslot < 0 || loginslot >= DB_MAX_LOGINS) 
	xlfail("xsybase: Slot number out of bounds");
    /* Check to be sure a valid login record is at loginslot */
    if (!dblogins[loginslot].mark)
	xlfail("xsybase: Invalid login record at loginslot");
    /* Close connection to database. */
     dbexit();
     dblogins[loginslot].db =0;
     return(true);
}
     


LVAL sqlcmd(loginslot, cmd)
int loginslot;
char *cmd;
{
    /* Execute cmd for given loginslot record */
    int i;
    LVAL result_list, rec_list, next, tail, tail_record, cell;
    char bufarray[MAXCOLCOUNT][MAXCOLSIZE], EORbuf[10];
    DBPROCESS *dbproc;
    RETCODE result;
    int keepopen=0;
    int nlvals=6;
    xlstkcheck(nlvals);
    xlsave(result_list);
    xlsave(rec_list);
    xlsave(next);
    xlsave(tail);
    xlsave(tail_record);
    xlsave(cell);
    /* Check to be sure loginslot is within bounds */
    if ( loginslot < 0 || loginslot >= DB_MAX_LOGINS) 
	xlfail("xsybase: Slot number out of bounds");
    /* Check to be sure a valid login record is at loginslot */
    if (!dblogins[loginslot].mark)
	xlfail("xsybase: Invalid login record at loginslot");
    /* Keep globalvariable currentloginslot so error handler can close
     connection if it is called */
    currentloginslot = loginslot;
    /* If cdbopen has previously been called (by DB-OPEN) then a valid
    process should exist in the login record. If so this process should
    be kept open at the end of this routine */
    dbproc = dblogins[loginslot].db;
    if (dbproc) 
	keepopen = 1;
    else {
	cdbopen(loginslot);
	dbproc = dblogins[loginslot].db;
	}
    /* Execute command */ 
    dbcmd( dbproc, cmd );
    dbsqlexec( dbproc );

    /* Construct a list of lists to save results, each field is a string, each
    row is a list, and the returned table is a list of lists */
    result_list=NIL;
    tail_record=result_list;

    while ((result=dbresults(dbproc)) != NO_MORE_RESULTS)
	if (result==SUCCEED)
	if (DBROWS(dbproc)==SUCCEED)  {  /* there are results to send */

	    /*  Bind the columns to program variables */
	    for (i=0; i<min(dbnumcols(dbproc),MAXCOLCOUNT); i++)  {
	        dbbind(dbproc, i+1, NTBSTRINGBIND, (DBINT) 0, bufarray[i] );
	    }

	    /* For each row */
	    while (result=dbnextrow(dbproc) != NO_MORE_ROWS)  {
		/* build a list of strings for this row;
		   see XLIST in xllist.c */

		rec_list = NIL;
		for (i=0; i<min(dbnumcols(dbproc),MAXCOLCOUNT); i++)  {
		    cell=cvstring(bufarray[i]);
		    next = consa(cell);
		    if (rec_list) rplacd(tail, next);
		    else rec_list = next;
		    tail = next;
		}

		/* then put the row list into a list of rows */
		next = consa( rec_list );
		if (result_list) rplacd(tail_record,next);
		else result_list = next;
		tail_record = next;
	    }
	}
    xlpopn(nlvals);
    /* Close connection depending on keepopen, and return constructed list */
    if (!keepopen) cdbclose(loginslot);
    return(result_list);
}

int error_handler( dbproc, severity, dberr, oserr, dberrstr, oserrstr )
DBPROCESS	*dbproc;
int	severity, dberr, oserr;
char	*dberrstr, oserrstr;
/* Handle error messages generated by db-library routines.  */
{
    char buf[255];

    sprintf( buf, "xsybase: DB-Library: %s", dberrstr );
    xlfail(buf);
    return( INT_CANCEL );
}

int message_handler(dbproc, msgno, msgstate, severity, msgtext, 
                srvname, procname, line)

DBPROCESS       *dbproc;
DBINT           msgno;
int             msgstate;
int             severity;
char            *msgtext;
char            *srvname;
char            *procname;
DBUSMALLINT     line;
/* Handle error messages generated by  database server */
{
    char buf[400];
    /* Severity level 10 and below are informational messages only,
    do not report these (see Sybase System Administrator's Guide, chapter 6).
    */
    if (severity <= 10 ) return(0);
    if (strlen(srvname) > 0)
	sprintf (buf, "xsybase: Server: %s  %s", srvname, msgtext);
    else
	sprintf (buf, "xsybase: Server: %s", msgtext);
    cdbclose(currentloginslot);
    xlfail(buf);
}
