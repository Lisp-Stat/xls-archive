/* {{{ xhsy.c -- HerSheY fonts: portable, modular stroke fonts.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      86Dec11
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Feb23 jsp  xhsy89/90_Char/StringStats. Doing only ~3.5K char/sec. Sigh.
 *              (Later: -g.  -O yields ~11K char/sec, which isn't too bad.
 *              Caching some/all symbols uncompressed would double it.)
 * 92Feb04 jsp  Clean.
 * 92Jan05 jdp  Operational.
 * 91Nov29 jdp	Began porting Hershey fonts to Skandha4 from Skandha3.
 * 88Aug18 jsp	Call mdcFontFile() for hershey.fnt pathname.
 * 87Jun17 jsp	fscanf("%d\n"...) doesn't eat the \n any more!	hsyGetLine().
 * 87Jun17 jsp	Start port to micro.
 * 87Jan20 jsp	Operational.
 * 87Jan20 jsp	Changed from absolute to relative vectors, saving about 6K.
 * 87Jan20 jsp  Last char in last alphabet had been lost:  restored.
 * 87Jan15 jsp  Nybble-encoding saves 100K, leaves just over 64K of char defs.
 * 87Jan14 jsp  locIndex[] now holds byte offsets (was word offsets).
 * 87Jan14 jsp  lenIndex[] was redundant:  eliminated it.
 * 87Jan13 jsp  Split index proper off from character-definition data.
 * 87Jan13 jsp  2502 zero entries deleted from index.  (1594 entries left.)
 * 87Jan13 jsp  Font table now yields neededIndex (was neededIndex+1).
 * 87Jan13 jsp  Font table index is now c instead of c-1.
 * 87Jan13 jsp  Shorten fonts from 512 entries to 128 entries (rest were zero).
 * 87Jan12 jsp  Keep data in RAM.  Beautify code.
 * 86Dec11 jsp	Created, using National Bureau of Standards Hershey font
 *              datafiles cannabalized from NASA GAS code.
 */

/***************************************/
/* "It sounds great, from a distance." */
/* "Gadgets, gadgets, gadgets!"	       */
/* -- Alfred Prothero, on VR.	       */
/***************************************/

/*******************************************/
/*					   */
/*	         |	    |		   */
/*	     ---------      /--------	   */
/*	       \   /	   /	 |	   */
/*	    -----------    \	/	   */
/*	    |    |    |	    \  /	   */
/*	    |  -----  |	     \/		   */
/*	    |    |    |	     /\		   */
/*	    |   ---   |	    /  \	   */
/*	    |   | |   |	   /	\	   */
/*	    |   ---  / 			   */
/*					   */
/*		    Techie		   */
/*******************************************/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

extern LVAL xsendmsg0(); 

#include <math.h>
#undef getenv
#include <stdlib.h>
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"


#define MAXnYBBLESpERcHAR	310
#define NONcHAR  -1
#define MAXfONT  12
#define FONTlEN 128
#define MAXbIN  55000
#define MAXiDX  1600
unsigned hsy_MaxFont;
unsigned hsy_FontLen;
unsigned hsy_BinLen = 0;
unsigned hsy_MaxIdx;
unsigned hsy_NxtIdx;

/* hsy_FontTable maps a font plus an ascii char into a hsy_LocIndex index: */
short hsy_FontTable[ MAXfONT ][ FONTlEN ];

/* hsy_LocIndex records the location in hsy_Bin of each Hershey char: */
unsigned             hsy_LocIndex[ MAXiDX ];
char                 hsy_RgtIndex[ MAXiDX ];
char                 hsy_LftIndex[ MAXiDX ];

unsigned char	     hsy_PtsInSym[ MAXiDX ];
unsigned char	     hsy_LnsInSym[ MAXiDX ];

/* hsy_Bin contains the defs of all Hershey chars in terms of vectors: */
char                 hsy_Bin[ MAXbIN ];

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xhsy09_Statistics  						*/

#ifdef TINKERING
struct xhsy07_rec {
    int maxx;
    int maxy;
    int minx;
    int miny;
    int points;
    int facets;
};
xhsy08_DummyDraw(  r, penDown, x, y )
struct xhsy07_rec *r;
int         	      penDown, x, y;
{
    /* This version just counts points and lines. */
    if (penDown != -1) {
	++               r->points;
	if (penDown)   ++r->facets;
	if (x < r->minx) r->minx = x;
	if (y < r->miny) r->miny = y;
	if (x > r->maxx) r->maxx = x;
	if (y > r->maxy) r->maxy = y;
    }
}
xhsy09_Statistics()
{
    /* Quick and dirty hack to compute some stuff about our database :) */
    int  symbols   = 0;
    int  i,j;
    int  totpoints = 0;
    int  totfacets = 0;
    int  maxpoints = 0;
    int  maxfacets = 0;
    struct xhsy07_rec r;
    r.maxx = -32000;
    r.maxy = -32000;
    r.minx =  32000;
    r.miny =  32000;
    printf(" >>>> START <<<<\n");
    for (j = 10; j --> 0; ) {
	for (i = 0;   i < hsy_NxtIdx;   ++i) {
    /*	int idx  = hsy_FontTable[ 1 ][ i ];*/
	    int idx  = i;
	    ++symbols;
	    r.points = 0;
	    r.facets = 0;
	    xhsy60_Char( idx, 0, xhsy08_DummyDraw, &r );
	    totpoints += r.points;
	    totfacets += r.facets;
	    if (r.points > maxpoints) maxpoints = r.points;
	    if (r.facets > maxfacets) maxfacets = r.facets;
	}
    }
    printf(" >>>> STOP! <<<<\n");
    printf("symbols d=%d\n",symbols);
    printf("r.minx d=%d\n",r.minx);
    printf("r.miny d=%d\n",r.miny);
    printf("r.maxx d=%d\n",r.maxx);
    printf("r.maxy d=%d\n",r.maxy);
    printf("maxpoints d=%d\n",maxpoints);
    printf("maxfacets d=%d\n",maxfacets);
    printf("totpoints d=%d\n",totpoints);
    printf("totfacets d=%d\n",totfacets);
    printf("avepoints d=%d\n",totpoints/symbols);
    printf("avefacets d=%d\n",totfacets/symbols);
}
#endif

/* }}} */
/* {{{ 	xhsy10_GetLine  						*/

xhsy10_GetLine( fdi, buf )
FILE *          fdi;
char *		     buf;
{
    int      c;
    char *   t;

    /* Read a line in: */
    t   = buf;
    while ((c = fgetc( fdi )) != -1   &&   (c&0x7F) != '\n')	*t++ = c;

    /* Suppress trailing whitespace: */
    while (t > buf   &&   t[-1] <= ' ')   --t;

    /* Terminate string: */
    *t++ = '\0';
}

/* }}} */
/* {{{      xhsy20_Init_Msg                                             */ 

xhsy20_Init_Msg() { 
    FILE *      fdi;
    int 	len;
    register	i;
    register	j;
    char     *  t;
    char        version;
    char	buf[ 80 ];
/* Buggo ... this stuff needs to be rewritten using ospopen when 21d arrives.*/
#define XHSY20_PATH_MAX (8192)
/* xlisp defines a macro for getenv in xldmem.h... we want the real getenv: */
#undef getenv
    unsigned char *path;
    char fname[ XHSY20_PATH_MAX ];
    char *fontFile = "hershey.fnt";
    char* xetc00_Find_Xlpath_Library();

    {
#ifdef OLD
	/* Copy path because I don't want xetc00_...() */
	/* hacking the environment:   */
        char buf[ XHSY20_PATH_MAX ];
	if (strlen(path) >= XHSY20_PATH_MAX) {
	    xlfail("XLPATH exceeds XHSY20_PATH_MAX!");
	}
	strcpy( buf, path );
#endif

	/* Expand name to full pathname if found */
	/* in XLPATH, stored in fname[]:  */
        fontFile = xetc00_Find_Xlpath_Library( fontFile, fname );
    }

    /* Open the file: */
    if (!  (fdi = fopen( fontFile, "r" ))  ) {
        printf( "\nCannot find '%s'!", fontFile ); 
        abort(); 
    } 
 
    /************************************/
    /* Read everything from fonts file: */
    /************************************/

    /**************************************************************/
    /* The following code originally used fscanf, but encountered */
    /* portability problems.  Hence xhsy10_GetLine & sscanf.	  */
    /**************************************************************/

    /* Read filetype and version letter: */
    xhsy10_GetLine( fdi, buf );
    if (strcmp( buf, "fonts" )) {
        printf("\nInvalid 'fonts.dat'!");
	abort();
    }
    xhsy10_GetLine( fdi, buf );
    version = buf[ 0 ];
    if (version < 'a'   ||   version > 'a') {
        printf("\nUnsupported 'fonts.dat' file format!");
	abort();
    }

    /* Read length of index: */
    xhsy10_GetLine( fdi, buf );
    sscanf( buf, "%d", &hsy_MaxIdx );
    if (hsy_MaxIdx > MAXiDX) {
        printf("\nMAXiDX too small!");
	abort();
    }

    /* Read first free loc in index: */
    xhsy10_GetLine( fdi, buf );
    sscanf( buf, "%d", &hsy_NxtIdx );
    if (hsy_NxtIdx >= MAXiDX) {
        printf("\nhsy_NxtIdx corrupt! x=%x, MAXiDX x=%x", hsy_NxtIdx,MAXiDX);
	abort();
    }


    /* Read length of hershey file proper: */
    xhsy10_GetLine( fdi, buf );
    sscanf( buf, "%d", &hsy_BinLen );
    if (hsy_BinLen > MAXbIN) {
        printf("\nMAXbIN too small!");
	abort();
    }

    /* Read number of font files: */
    xhsy10_GetLine( fdi, buf );
    sscanf( buf, "%d", &hsy_MaxFont );
    if (hsy_MaxFont > MAXfONT) {
        printf("\nMAXfONT too small!");
	abort();
    }

    /* Read size of each fontfile: */
    xhsy10_GetLine( fdi, buf );
    sscanf( buf, "%d", &hsy_FontLen );
    if (hsy_FontLen > FONTlEN) {
        printf("\nFONTlEN too small!");
	abort();
    }

    /* Clear our points/lines indices: */
    for (i = MAXiDX;  i --> 0;  ) {
	hsy_PtsInSym[ i ] = 0xFF;
	hsy_LnsInSym[ i ] = 0xFF;
    }

    /* Read hershey file index: */
    for (i = 0;   i < hsy_MaxIdx;   ++i) {

        unsigned u;
	u		    = fgetc( fdi ) <<	8;
	u		   |= fgetc( fdi ) & 0xFF;
	hsy_LocIndex[ i ]   = u;
    }
    if (
        hsy_LocIndex[ hsy_NxtIdx   ] == 0xFFFF
        ||
        hsy_LocIndex[ hsy_NxtIdx+1 ] != 0xFFFF
    ) {
        printf("\nhsy_LocIndex corrupt!");
        exit(1);
    }
    for (t = ((char*)hsy_RgtIndex), i = hsy_MaxIdx;   i--;   ) {
        *t++ = fgetc( fdi );
    }
    for (t = ((char*)hsy_LftIndex), i = hsy_MaxIdx;   i--;   ) {
        *t++ = fgetc( fdi );
    }

    /* Read hershey file proper: */
    for (t = hsy_Bin, i = hsy_BinLen;   i--;   ) {
        *t++ = fgetc( fdi );
    }

    /* Read in the font files: */
    for (i = 0;   i < hsy_MaxFont;   ++i) {
        t  = (char *) &hsy_FontTable[ i ][ 0 ];
        for (j = hsy_FontLen * sizeof(short);   j--;   ) {
            *t++ = fgetc( fdi );
        }
    }

    /* Close input file: */
    fclose( fdi );
#ifdef TINKERING
xhsy09_Statistics();
#endif
}

/* }}} */
/* {{{      xhsy30_Wrapup_Msg   Close down hershey font module.         */

LVAL xhsy30_Wrapup_Msg()
{
    /* Close Hershey font module. */
}

/* }}} */
/* {{{      xhsy40_Font       Return pointer to nth Hershey font.       */

short* xhsy40_Font( i )
unsigned            i;
{
    if (i >= MAXfONT)   xlerror( "Bad font index", cvfixnum(i) );
    return   &hsy_FontTable[ i ][ 0 ];
}

/* }}} */
/* {{{      xhsy50_String      Draw a complete string in given font.	*/

xhsy50_String( t, font, fn, fa )
char  *        t;
short *		  font;
int                   (*fn);
char*                       fa;
{   
    int		xbase = 0;
    int         idx, c;
  
    /**********************************************/
    /* Draw the given string using the given font.*/
    /**********************************************/
  
    /* Over all chars in string: */
    while (c = (*t++ & 0x7F)) {

        /* Ascii code plus font implies a hershey char index; draw it: */
        idx     = font[ c ];
        xbase  += xhsy60_Char( idx, xbase, fn, fa );
    }

    /* Return the x-span of the string: */
    return   xbase;
}

/* }}} */
/* {{{      xhsy60_Char                                                 */

xhsy60_Char( idx, orgX, fn, fa )
unsigned     idx;
int               orgX;
int                   (*fn)();
int                         fa;
{    
    int                 orgY = 0; 
    int                 c; 
    int                 x, y; 
    int                 nybbles[ MAXnYBBLESpERcHAR ];
    int                 coords[  MAXnYBBLESpERcHAR ];
    short               left, right;
    int                 width;
    char             *  thisC;
    char             *  lastC;
    int              *  out;
    int              *  thisI;
    int              *  lastI;
    int                 count;

    /* Sanity check: */
    if (idx >= hsy_NxtIdx) {
        /* The font indices map nonprinting chars to -1.	*/
        /* For now, at least, we'll channel all these to our	*/
        /* newline hack:					*/
	if (idx == (unsigned)-1) {
	   (*fn)( fa, -1, orgX, orgY );
	    return -orgX;
	}

 	xlerror( "Bad Hershey index", cvfixnum(idx) );
    }

    /* Remember width of this char: */
    right = hsy_RgtIndex[ idx ];
    left  = hsy_LftIndex[ idx ];
    width = right + left;
           
    /* Unpack nybbles into ints: */
    count = hsy_LocIndex[ idx+1 ]   -   hsy_LocIndex[ idx ];
    count = xhsy80_Unpack( nybbles, &hsy_Bin[ hsy_LocIndex[idx] ], count );
    count = xhsy70_Decode( coords, nybbles, count );
  
    /* Over all curves in char definition: */
    for (thisI = coords, lastI = thisI+count;   thisI < lastI;   ) {
  
        c = *thisI++;
  
	/* If c > 0, we position ourselves with an invisible 1st vector: */
        if (c <= 0) {
  
            c = -c;
   
        } else {
  
            /* Record first (invisible) line segment: */
            x =  *thisI++;
            y = -*thisI++;

	   (*fn)( fa, 0, left+x+orgX, y+orgY );

            --c; 
            orgX += x; 
            orgY += y; 
        } 
  
        /* Record all remaining (visible) line segments in curve: */
        while (c--) { 
  
            x     =  *thisI++; 
            y     = -*thisI++; 

	   (*fn)( fa, 1, left+x+orgX, y+orgY );

            orgX += x; 
            orgY += y; 
        } 
    } 
  
    return   width; 
} 

/* }}} */
/* {{{      xhsy70_Decode      Collapse int sequences to single ints.   */

xhsy70_Decode( dst, src, count )
int *          dst;
int *               src;
int                      count;
{
    register int  *  end;
    register int     j;
    register int  *  d;
    register int  *  s;
    register int     c;

    for (s=src, d=dst, end=s+count, j=0;   s<end;   ) {

        c = *s++;
 
        if (c < 8)           *d++ = c;
        else if (c != 0x8)   *d++ =   -8 + (c &  0x7);
        else {
            c      = (s[0] << 4)   |   s[1];
            s     += 2;
            if (c & 0x80)     c     = -128 + (c & 0x7F);
            *d++ = c;
            ++j;
        }
    }
    return   count - 2*j;
}

/* }}} */
/* {{{      xhsy80_Unpack   Expand nybble sequence into int sequence.   */

xhsy80_Unpack( dst, src, count )
int  *         dst;
char *              src;
int                      count;
{
    register int     i;
    register int  *  d;
    register char *  s;
    register char    c;

    /* Unpack nybbles into ints.  Don't assume chars are/aren't signed: */
    for (s=src, d=dst, i=count;   i --> 0;   ) {
        c      = *s++;
        *d++   = (c >> 4)   &   0xF;
        *d++   = (c     )   &   0xF;
    }

    return   2*count;
}

/* }}} */
/* {{{      xhsy89_StringStats Compute points and lines needed for symbol. */


struct xhsy87_rec {
    int points;
    int facets;
};
xhsy88_DummyDraw(  r, penDown, x, y )
struct xhsy87_rec *r;
int         	      penDown, x, y;
{
    /* This version just counts points and lines. */
    if (penDown != -1) {
	++               r->points;
	if (penDown)   ++r->facets;
    }
}
xhsy89_CharStats( idx, pointsNeeded, facetsNeeded )
unsigned	  idx;
int		      *pointsNeeded,*facetsNeeded;
{
    if (hsy_PtsInSym[ idx ] == 0xFF) {
	struct xhsy87_rec r;
	r.points  = 0;
	r.facets  = 0;
	xhsy60_Char(  idx, 0, xhsy88_DummyDraw, &r );
	hsy_PtsInSym[ idx ] = r.points;
	hsy_LnsInSym[ idx ] = r.facets;
    }
    *pointsNeeded = hsy_PtsInSym[ idx ];
    *facetsNeeded = hsy_LnsInSym[ idx ];
}

/* }}} */
/* {{{      xhsy90_StringStats Compute points and lines needed for string. */

xhsy90_StringStats( t, font, pointsNeeded, facetsNeeded )
char  *             t;
short *		       font;
int			    *pointsNeeded,*facetsNeeded;
{   
    /* Compute number of lines and points xhsy50 will use: */
    struct xhsy87_rec r;
    int pts = 0;
    int lns = 0;
    int idx, c;
  
    /* Over all chars in string: */
    while (c = (*t++ & 0x7F)) {

        /* Ascii code plus font implies a hershey char index; draw it: */
        idx  = font[ c ];
	if (idx == -1)   continue;
	if (hsy_PtsInSym[ idx ] == 0xFF) {int x;xhsy89_CharStats(idx,&x,&x);}
	pts += hsy_PtsInSym[ idx ];
	lns += hsy_LnsInSym[ idx ];
    }
    *pointsNeeded = pts;
    *facetsNeeded = lns;
}
/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

