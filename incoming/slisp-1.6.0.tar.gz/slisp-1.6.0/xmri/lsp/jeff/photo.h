/* File: photo.h
** Purpose: Structures and contants for photogrammetry software
** Author: Ken Thornton
** LastModified: 3 October 1992
*/

#include <stdio.h>
#include <math.h>

#define same    !strcmp
#define ITER 30
#define STEP 100
#define DEBUG 0
#define LABEL 1000
#define PI 3.141592654
#define TORAD PI/180.0
