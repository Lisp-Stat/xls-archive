/* File: Math.c
** Purpose: General matrix, vector operations
** Author: Ken Thornton
**
** Contains: Multiply
**           Transpose
**           Distance
**           Cross
**           Dot
**           Length
**           OutputM
*/

#include "photo.h"

/********************************************************************
 MULTIPLY 

 Here n is the # columns in matrix A and the # of rows in matrix B.
 The mode says whether either of the matrices are to be transposed.

 It is up to the user to verify that C is the correct size!
*********************************************************************/

void Multiply(C,A,B,mode,ra,ca,rb,cb)
   float *C;
   float *A;
   float *B;
   int mode;
   int ra;
   int ca;
   int rb;
   int cb;
{
   int i, j, k, n, rc, cc;

   switch(mode) {
      case 00: /* Transpose neither */
         rc = ra; cc = cb; n = ca;
         if (ca != rb) {
            fprintf(stderr,"Multiply: parameter error\n");
            exit(1);
         }
         for (i=0; i<rc; i++)
            for (j=0; j<cc; j++) {
               *(C+j+i*cc) = 0.0; 
               /* Form A[i][k]*B[k][j] */ 
               for (k=0; k<n; k++) *(C+j+i*cc) += *(A+k+i*ca) * 
                  *(B+j+k*cb);
            }
         break; 
      case 01: /* Transpose B */
         rc = ra; cc = rb; n = ca;
         if (ca != cb) {
            fprintf(stderr,"Multiply: parameter error\n");
            exit(1);
         }
         for (i=0; i<rc; i++)
            for (j=0; j<cc; j++) {
               *(C+j+i*cc) = 0.0; 
               /* Form A[i][k]*B[j][k] */ 
               for (k=0; k<n; k++) *(C+j+i*cc) += *(A+k+i*ca) * 
                  *(B+k+j*cb);
            }
         break; 
      case 10: /* Transpose A */
         rc = ca; cc = cb; n = ra;
         if (ra != rb) {
            fprintf(stderr,"Multiply: parameter error\n");
            exit(1);
         }
         for (i=0; i<rc; i++)
            for (j=0; j<cc; j++) {
               *(C+j+i*cc) = 0.0; 
               /* Form A[i][k]*B[k][j] */ 
               for (k=0; k<n; k++) *(C+j+i*cc) += *(A+i+k*ca) * 
                  *(B+j+k*cb);
            }
         break; 
      case 11: /* Transpose A and B */
         rc = ca; cc = rb; n = ra;
         if (ra != cb) {
            fprintf(stderr,"Multiply: parameter error\n");
            exit(1);
         }
         for (i=0; i<rc; i++)
            for (j=0; j<cc; j++) {
               *(C+j+i*cc) = 0.0; 
               /* Form A[i][k]*B[k][j] */ 
               for (k=0; k<n; k++) *(C+j+i*cc) += *(A+i+k*ca) * 
                  *(B+k+j*cb);
            }
         break; 
      default:
         fprintf(stderr,"Multiply: error\n");
         exit(1);
   }
}

/*************************************************************
TRANSPOSE

Compute the transpose of a matrix or vector.
*************************************************************/

void Transpose(A,B,rb,cb)
   float *A;
   float *B;
   int rb;
   int cb;
{
   int i, j;

   for (i=0; i<rb; i++)
      for (j=0; j<cb; j++) 
         *(A+i+j*rb) = *(B+j+i*cb);
}


/*************************************************************
DISTANCE

Compute the distance between 2 vectors of dimension N.

Keep 10-01-92
*************************************************************/

void Distance(dis,A,B,n)
   float *dis;
   float *A;
   float *B;
   int n;
{
   int i; float t = 0.0;

   for (i=0; i<n; i++) 
      t += (A[i]-B[i])*(A[i]-B[i]);

   if (signbit(t)) {
      fprintf(stderr,"Distance: sqrt arg is %+e\n",t);
      exit(1);
   }

   *dis = sqrt(t);
}

/*************************************************************
CROSS

Compute the cross product of 2 vectors of dimension 3.
               A = B x C
*************************************************************/
 
void Cross(A,B,C)
   float A[3];
   float B[3];
   float C[3];
{   

   A[0] = B[1]*C[2] - C[1]*B[2];
   A[1] = B[2]*C[0] - B[0]*C[2];
   A[2] = B[0]*C[1] - C[0]*B[1];
}

/*************************************************************
DOT

Compute the dot product of 2 vectors of dimension 3.
             A = B . C
*************************************************************/

void Dot(dot,A,B)
   float *dot;
   float A[3];
   float B[3];
{
   *dot = A[0]*B[0] + A[1]*B[1] + A[2]*B[2];
}

/*************************************************************
LENGTH

Compute the length of a vector of dimension n.
**************************************************************/

void Length(len,A,n)
   float *len;
   float *A;
   int n;
{
   int i;
   float sum = 0;

   for (i=0; i<n; i++) sum += A[i]*A[i];
   if (signbit(sum)) {
      fprintf(stderr,"Length: sqrt arg is %+e\n",sum);
      exit(1);
   }
   *len = sqrt(sum); 
}

void OutputM(A,ra,ca,s)
   float *A;  
   int ra;
   int ca;
   char *s;
{
   int i, j;

   fprintf(stdout,"Matrix: %s is [%d x %d]\n",s,ra,ca);
   for (i=0; i<ra; i++) {
      for (j=0; j<ca; j++)
         fprintf(stdout,"%e ",*(A+j+i*ca));
      fprintf(stdout,"\n");
   }
   fprintf(stdout,"\n");
}

signbit(value)
float value ;
{
 if(value < 0.0 ) return 1;
 else return 0 ;
}

