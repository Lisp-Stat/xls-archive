/* File: solve.c
** Purpose: to solve a linear system of equations
** Author: Ken Thornton
** LastModified: 3 October 1992
**
** Contains: Solve
**
** Calls: ludcmp
**        lubksb
*/

#include "photo.h"

/*
**  Solve the system  Dx - d = 0 for x.
**
**  D is N x N 
**  d is N x 1
**  x is N x 1
**
**  Since we use Numerical Recipes, we copy
**  our matrices into their format.
**
*/

void Solve(x,D,d,a,b,indx,N)
   float *x;       /* x[0..N-1] */
   float *D;       /* D[0..N-1][0..N-1] */
   float *d;       /* d[0..N-1] */
   float **a;      /* a[1..N][1..N] */
   float *b;       /* b[1..N] */
   int *indx;      /* index[1..N] */
   int N;          /* dimension */         
{
   int i, j;
   float k;
   void ludcmp(), lubksb();

   /* Copy d into b and D into a: */
   for (i=1; i<=N; i++) {
      b[i] = *(d+(i-1));
      for (j=1; j<=N; j++)   a[i][j] = *(D+(i-1)*N+(j-1));
   }

   /* Do lower/upper decomposition: */
   ludcmp(a,N,indx,&k);

   /* Use backsubstitution to produce solutions: */
   lubksb(a,N,indx,b);

   /* Copy result from b into x: */
   for (i=1; i<=N; i++) x[i-1] = b[i];
}
  
   


