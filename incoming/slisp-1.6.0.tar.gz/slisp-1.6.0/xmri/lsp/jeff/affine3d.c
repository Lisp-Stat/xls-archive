/* File: affine3d.c
** Purpose: Find the best affine mapping between a
**          3D model point set and a 2D observed image point set
** Author: Ken Thornton
** Last Modified: 28 Jan 1992
**
**
** Input: Set of (x,y,z) model points
**        Set of (u,v)   image points
**
** Transformation:
**
**                                | a11 |
**                                | a12 |
**  | u |     | x y z 1 0 0 0 0 | | a13 |
**  |   |  =  |                 | | a14 | 
**  | v |     | 0 0 0 0 x y z 1 | | a21 |
**                                | a22 |
**                                | a23 |
**                                | a24 |
**
** Given N pairs, we then have
**
**       U    =     X        A
**   (2N x 1)   (2N x 8)  (8 x 1)
**
** The least-squares solution is
**
**  Ah = (X'X)^-1 X'U
*/

#include <stdio.h>
#include <math.h>

#define N  7
#define P  8

affine3d(in1,in2,out,projfile)
   FILE *in1, *in2, *out , *projfile;
/*
 * in1 is the modelfile
 * 
 * The data format for model points is
 * x1 y1 z1 
 * x2 y2 z2 
 * ...
 *
 * in2 is the imagefile
 *
 * The data format for image points is
 *
 * u1 v1
 * u2 v2
 * ...
 *
 *
 * The correspondences are implicit in the order of the points in the
 * two files. i.e. (x1,y1,z1) corresponds to (u1,v1). (x2,y2,z2) corresponds
 * to (u2,v2) and so on.
 * 
 * out is the output data file
 *
 * profile is the least-squares projected model points
 *
*/
{
   int i, *indx, *ivector();
   float X[2*N][P], A[P], U[2*N], Uh[2*N], a, b, c;
   float D[P][P], d[P], s1, s2, s3;
   void Multiply(), Solve();
   /* For Solve */
   float Bt[P][P], Z[P][P], T[P][P], S[P], E[P], V[P][P], W[P][P];
   float *bv, *vector(), **am, **matrix();
   int cnt;
   int x,y,z ;
   float fx, fy,fz ;

   bv = vector(1,8);
   am = matrix(1,8,1,8);
   indx = ivector(1,8);

   /* Get model points */
   for (i=0; i<N; i++) {
      fscanf(in1,"%f %f %f",&a,&b,&c);
printf("affine3d.c/lup1 point %d = %g %g %g\n",i,a,b,c);
      X[i*2+0][0] = a;     X[i*2+1][0] = 0.0;
      X[i*2+0][1] = b;     X[i*2+1][1] = 0.0;
      X[i*2+0][2] = c;     X[i*2+1][2] = 0.0;
      X[i*2+0][3] = 1.0;   X[i*2+1][3] = 0.0;
      X[i*2+0][4] = 0.0;   X[i*2+1][4] = a;
      X[i*2+0][5] = 0.0;   X[i*2+1][5] = b;
      X[i*2+0][6] = 0.0;   X[i*2+1][6] = c;
      X[i*2+0][7] = 0.0;   X[i*2+1][7] = 1.0;
   }
   /* Get image points */
   for (i=0; i<N; i++) {
      fscanf(in2,"%f %f",&a,&b);
      U[i*2+0] = a;
      U[i*2+1] = b;
   }
    
   /* Form normal equations */
   Multiply(D,X,X,10,2*N,P,2*N,P);	/* D = transpose(X)*X;	*/
   Multiply(d,X,U,10,2*N,P,2*N,1);	/* d = transpose(X)*U;	*/

   /* Solve D*A-d==0 for A. */
   /* am and bv are NR-format temporaries into which */
   /* D and d (respectively) are copied: */
   Solve(A,D,d,am,bv,indx,8);

   for (i=0; i<8; i++) fprintf(stdout,"A[%d]: %f\n",i,A[i]);

   /* Now, transform model points */
   for (i=0; i<N; i++) {
      Uh[i*2+0] = X[i*2+0][0]*A[0] + X[i*2+0][1]*A[1] + X[i*2+0][2]*A[2] + A[3];
printf("affine3d.c/lup2 %g*%g + %g*%g + %g*%g + %g == %g\n",
X[i*2+0][0],A[0], X[i*2+0][1],A[1] , X[i*2+0][2],A[2] , A[3],      Uh[i*2+0]);
      Uh[i*2+1] = X[i*2+1][4]*A[4] + X[i*2+1][5]*A[5] + X[i*2+1][6]*A[6] + A[7];
printf("                %g*%g + %g*%g + %g*%g + %g == %g\n",
X[i*2+1][4],A[4] , X[i*2+1][5],A[5] , X[i*2+1][6],A[6] , A[7],      Uh[i*2+1]);
   }

   /* Now, output points */
   fprintf(out,"#Observed Image Points\n");
   for (i=0; i<N; i++) fprintf(out,"%+f %+f\n",U[i*2+0],U[i*2+1]);
   fprintf(out,"&\n");
   fprintf(out,"#Predicted Image Points\n");
   for (i=0; i<N; i++) fprintf(out,"%+f %+f\n",Uh[i*2+0],Uh[i*2+1]);

   fclose(in1) ; fclose(in2) ; fclose(out) ;

#ifdef OLD
    in1 = fopen("c1c.3d","r") ;

    fscanf(in1,"%*d") ;

    while( fscanf(in1,"%f %f %f ",&fx,&fy,&fz) != EOF){
     printf("%f %f \n",fx*A[0] + fy*A[1] + fz*A[2] + A[3],
		       fx*A[4] + fy*A[5] + fz*A[6] + A[7] ) ;
     fprintf(projfile,"%f %f \n",fx*A[0] + fy*A[1] + fz*A[2] + A[3],
		       fx*A[4] + fy*A[5] + fz*A[6] + A[7] ) ;
    }
#endif
fclose(projfile);
   
}
