#include <stdio.h>
main() {
    FILE *in1, *in2, *out, *projfile;
    in1 = fopen("in1","r");
    in2 = fopen("in2","r");
    out = fopen("out","w");
    projfile = fopen("projfile","w");
    affine3d(in1,in2,out,projfile);
    exit(0);
}
