 /*- xmth.c -- math support code for solving linear equation sets.	*/
/*- This file is formatted for outline-minor-mode in emacs19.		*/
/*-^C^O^A shows All of file.						*/
/* ^C^O^Q Quickfolds entire file. (Leaves only top-level headings.)	*/
/* ^C^O^T hides all Text. (Leaves all headings.)			*/
/* ^C^O^I shows Immediate children of node.				*/
/* ^C^O^S Shows all of a node.						*/
/* ^C^O^D hiDes all of a node.						*/
/* ^HFoutline-mode gives more details.					*/
/* (Or do ^HI and read emacs:outline mode.)				*/

/************************************************************************/
/*-    Copyright.							*/
/************************************************************************/

/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      97Feb12
* Language:     C
* Package:      N/A
*
* Copyright (c) 1998, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************

/************************************************************************/
/*-	history								*/
/************************************************************************/

/* 97Feb12 jsp: Created.						*/

/************************************************************************/
/*-	Overview							*/
/************************************************************************/
/*

This code is adapted from Numerical Recipes;  Using it probably
introduces some copyright problems into Skandha4, at least in
theory.

There are good freely distributable alternatives available if
this becomes an issue:  See http://www.netlib.org/liblist.html.
One example is included in the Appendix to this program.
 */


/************************************************************************/
/*-	header stuff							*/
/************************************************************************/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/cf2v.h"
#include "../../xg.3d/c/cf8v.h"
#include "../../xg.3d/c/cflv.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/geo.h"
#include "../../xg.3d/c/ctfm.h"
#include "../../xvol/c/cvol.h"

extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();

extern LVAL lv_xflv;

extern LVAL k_matrix;
extern LVAL k_b;
extern LVAL k_left;
extern LVAL k_right;
extern LVAL k_result_in;
extern LVAL k_transpose_right;
extern LVAL k_transpose_left;

/* I suspect some of these aren't needed any more: */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <string.h>
#include <device.h>
#include <fcntl.h>
#include <termio.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#include <malloc.h>
#include <unistd.h>

#ifndef ERR
#define ERR (-1)
#endif

#undef  loop
#define loop for(;;)

/************************************************************************/
/*- xmth04_Ludcmp -- Lower/Upper DeCoMPosition of a matrix		*/
/************************************************************************/

#define TINY 1.0e-20;

LVAL xmth00_matrix;
int  xmth0c_n;	/* Above is nxn */

int* xmth01_indx;
int  xmth02_indx_len = 0;

float** xmth03_base;
int     xmth04_base_len = 0;

float*  xmth0a_vv;
int     xmth0b_vv_len = 0;

extern LVAL true;
LVAL
xmth05_Ludcmp( a, n, indx, d )
float        **a;		/* nxn matrix to solve.	*/
int               n;		/* size of matrix.	*/
int                 *indx;	/* Permutation vector (return value) */
float                     *d;	/* odd/even permutation flag ? (return val ) */
{
    int i, imax, j, k;
    float big, dum, sum, temp;
    float *vv;

    /****************************************/
    /* First task is to find some scale     */
    /* factors.  For each row i, we set     */
    /* vv[i] to 1/(biggest value in row i): */
    /****************************************/
    vv = xmth0a_vv;
    *d =1.0;
    /* Over each row in matrix: */
    for (i = 1;  i <= n;   i++) {
	big = 0.0;
	/* Over each col in matrix: */
	for (j = 1;  j <= n; j++) {
	    if ((temp=fabs(a[i][j])) > big) big=temp;
	}
	if (big == 0.0)  return NIL;
	vv[i]=1.0/big;
    }

    /* Now for the main Gaussian elimination */
    /* stuff. Over each col j in the matrix: */          
    for     (j = 1;   j <= n;   j++) {

	/* Fill in part of column above diagonal: */
	for (i = 1;   i < j;    i++) {
	    sum=a[i][j];
	    for (k = 1;   k < i;   k++) sum -= a[i][k]*a[k][j];
	    a[i][j]=sum;
	}

	/* Fill in part of column below diagonal. */
	/* We use 'big' and 'imax' to find the    */
	/* largest value in the column which is   */
	/* not above the diagonal -- this will be */
	/* our pivot value:			  */
	big=0.0;
	for (i = j;   i <= n;   i++) {
	    sum=a[i][j];
	    for (k = 1;   k < j;   k++) {
		sum -= a[i][k]*a[k][j];
	    }
	    a[i][j]=sum;
	    if ( (dum=vv[i]*fabs(sum)) >= big) {
		big=dum;
		imax=i;
	    }
	}

	/* If pivot wasn't on the diagonal, */
	/* swap rows to bring it up to the  */
	/* diagonal:                        */
	if (j != imax) {
	    for (k = 1;   k <= n;   k++) {
		dum        = a[imax][k];
		a[imax][k] = a[j][k];
		a[j][k]    = dum;
	    }
	    vv[imax]=vv[j];	/* Update row-scaling information.       */
	    *d = -(*d);		/* Track whether permutation is odd/even */
	}

	/* Remember how we've permuted rows so far: */
	indx[j]=imax;

	/* Divide bottom half of col by pivot: */
	if (a[j][j] == 0.0)   a[j][j] = TINY;	/* Avoid divide by zero */
	if (j != n) {
	    dum=1.0/(a[j][j]);
	    for (i = j+1;  i <= n;   i++)   a[i][j] *= dum;
	}
    }
    return true;
}

#undef TINY

/************************************************************************/
/*- xmth06_Ludcmp_Fn -- Decompose square matrix				*/
/************************************************************************/

LVAL
xmth06_Ludcmp_Fn() {
    int n;
    float*  p;

    LVAL lv_matrix = NIL;
    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_matrix) {
	    lv_matrix = xflv04_Get_A_XFLV();
	} else {
	    xlerror("Bad XMTH-LUDCMP keyword",lv);
	}
    }
    if (!lv_matrix) xlfail("XMTH-LUDCMP: missing :MATRIX keyword");

    /* Matrix must be two-dimensional and square: */
    {   csry_rec* h  = xsry9c_Find_Immediate_Base( lv_matrix );
	if (h->rank != 2) {
	    xlfail("XMTH-LUDCMP: Matrix must be two-dimensional");
	}
	if (h->dim[0] != h->dim[1]) {
	    xlfail("XMTH-LUDCMP: Matrix must be square");
	}
	n = h->dim[0];
	p = (float*) csry_base( lv_matrix );
    }

/* buggo, should really check for malloc/realloc failures below... */

    /* Make sure our scratch storage is big enough: */
    if (!xmth02_indx_len) {
	int* p          = (int*) malloc( (n+1)*sizeof(int) );
	if (!p)  xlfail("XMTH-LUDCMP: out of ram");
	xmth02_indx_len = n+1;
	xmth01_indx     = p;
    } else if (xmth02_indx_len < n+1) {
	int* p          = (int*) realloc( xmth01_indx,(n+1)*sizeof(int) );
	if (!p)  xlfail("XMTH-LUDCMP: out of ram");
	xmth02_indx_len = n+1;
	xmth01_indx     = p;
    }
    if (!xmth04_base_len) {
	float**p        = (float**) malloc( (n+1)*sizeof(float*) );
	if (!p)  xlfail("XMTH-LUDCMP: out of ram");
	xmth04_base_len = n+1;
	xmth03_base     = p;
    } else if (xmth04_base_len < n+1) {
	float**p        = (float**) realloc( xmth03_base,(n+1)*sizeof(float*) );
	if (!p)  xlfail("XMTH-LUDCMP: out of ram");
	xmth04_base_len = n+1;
	xmth03_base     = p;
    }
    if (!xmth0b_vv_len) {
	float*p       = (float*) malloc( (n+1)*sizeof(float) );
	if (!p)  xlfail("XMTH-LUDCMP: out of ram");
	xmth0b_vv_len = n+1;
	xmth0a_vv     = p;
    } else if (xmth0b_vv_len < n+1) {
	float*p       = (float*) realloc( xmth0a_vv,(n+1)*sizeof(float) );
	if (!p)  xlfail("XMTH-LUDCMP: out of ram");
	xmth0b_vv_len = n+1;
	xmth0a_vv     = p;
    }

    /* Fill in the row index vector: */
    {   float* q = p;
        int  i;
        for (i = 0;   i < n;   ++i) {
	    xmth03_base[i] = q-1;	/* -1 to support 1->N (vs 0->N-1) indexing */
	    q += n;
    }	}

    /* Do the actual call: */
    {   float d;
        LVAL  result;

	/* The '-1' address offsets in the call are so that we  */
	/* can use the 1..N addressing the function was written */
	/* for (ForTran style array indexing).  Be mildly nice  */
	/* and not too hard to rewrite the fn to avoid this:    */
	result=xmth05_Ludcmp( &xmth03_base[-1], n, &xmth01_indx[-1], &d );

	/* For now, we ignore the 'd' permutation even/odd return */
        /* value.  We could make it the return value from the     */
	/* function at some point.                                */

	/* To simplify the lisp programmer's interface, currently */
	/* we maintain the permutation index internally as hidden */
	/* state.  If this proves to be a nuisance, we can add an */
	/* optional keyword parameter to the call allowing the    */
	/* user to specify an array to hold the returned vector.  */
	/* In the meantime, we at least remember which matrix the */
	/* hidden permutation vector applies to, so we can issue  */
	/* an error message if lubksb is called with the wrong    */
	/* LU array:                                              */
	xmth00_matrix = (result==NIL) ? NIL : lv_matrix;

	/* We also remember n, to catch cases of the matrix */
	/* being redimensioned between ludcmp and lubksb:   */ 
	xmth0c_n = (result==NIL) ? 0 : n;

	return result;
    }
}    

/************************************************************************/
/*- xmth14_Lubksb -- Lower/Upper BacKSuBstitute				*/
/************************************************************************/

void
xmth14_Lubksb( a, n, indx, b )
float        **a;		/* nxn matrix returned by Ludcmp. */
int               n;		/* Size of matrix.		  */
int                 *indx;	/* Permutation vector returned by ludcmp */
float                      b[]; /* Solution vector (return value)	 */
{
    int ii=0;

    int i,j;
    int ip;
    float sum;

    /* Over all rows in matrix (and cols in solution vector): */
    for (i = 1;   i <= n;   i++) {
	/* Remember where that row got permuted to: */
	ip    = indx[i];
	sum   = b[ip];
	b[ip] = b[i];
	if (ii) {
	    for (j = ii;  j <= i-1;   j++)  sum -= a[i][j] * b[j];
	} else {
	    if (sum) ii=i;
	}
	b[i]=sum;
    }
    for (i = n;   i >= 1;   i--) {
	sum=b[i];
	for (j = i+1;    j <= n;    j++)    sum -= a[i][j] * b[j];
	b[i] = sum/a[i][i];
    }
}

/************************************************************************/
/*- xmth20_Lubksb_Fn -- Backsubstitution on LU-decomposed matrix	*/
/************************************************************************/

LVAL
xmth20_Lubksb_Fn() {
    int n;
    float*  p;
    float*  b;

    LVAL lv_matrix = NIL;
    LVAL lv_vector = NIL;
    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_matrix) {
	    lv_matrix = xflv04_Get_A_XFLV();
	} else if (lv == k_b) {
	    lv_vector = xflv04_Get_A_XFLV();
	} else {
	    xlerror("Bad XMTH-LUBKSB keyword",lv);
	}
    }
    if (!lv_matrix) xlfail("XMTH-LUBKSB: missing :MATRIX keyword");
    if (!lv_vector) xlfail("XMTH-LUBKSB: missing :VECTOR keyword");

    /* Matrix must be two-dimensional and square: */
    {   csry_rec* h  = xsry9c_Find_Immediate_Base( lv_matrix );
	if (h->rank != 2) {
	    xlfail("XMTH-LUBKSB: Matrix must be two-dimensional");
	}
	if (h->dim[0] != h->dim[1]) {
	    xlfail("XMTH-LUBKSB: Matrix must be square");
	}
	n = h->dim[0];
	p = (float*) csry_base( lv_matrix );
    }

    /* Matrix must be last one ludcmp was called */
    /* on, and must not have changed shape: */
    if (lv_matrix != xmth00_matrix) {
	xlfail("XMTH-LUBKSB: Matrix must have just been given to xmth-ludcmp");
    }
    if (n != xmth0c_n) {
	xlfail("XMTH-LUBKSB: Matrix must not have been resized since calling xmth-ludcmp");
    }

    /* Vector must be one-dimensional and match matrix. */
    /* Actually, we allow Nx1 and 1xN arrays as well,   */
    /* for convenience:                                 */
    {   csry_rec* h  = xsry9c_Find_Immediate_Base( lv_vector );
	if (h->rank == 1) {
	    if (h->dim[0] != n) {
		xlfail("XMTH-LUBKSB: Vector :b length must match matrix");
	    }
	} else {
	    if (h->rank != 2) {
		xlfail("XMTH-LUBKSB: Vector :b must be one-dimensional");
	    } else {
		if (h->dim[0]==1) {
		    if (h->dim[1] != n) {
			xlfail("XMTH-LUBKSB: 1xN matrix :b length must match matrix");
		    }
		} else if (h->dim[1]==1) {
		    if (h->dim[0] != n) {
			xlfail("XMTH-LUBKSB: Nx1 matrix :b length must match matrix");
		    }
		} else {
		    xlfail("XMTH-LUBKSB: Vector :b must be one-dimensional");
	        }
	    }
	}
	b = (float*) csry_base( lv_vector );
    }

    /* Do the actual call: */
    xmth14_Lubksb( &xmth03_base[-1], n, &xmth01_indx[-1], &b[-1] );

    return NIL;
}

/************************************************************************/
/*- xmth27_Create_Matrix                                             	*/
/************************************************************************/

#undef NONE
#undef LEFT
#undef ROIT
#undef BOTH

#define NONE 0
#define LEFT 1
#define ROIT 2
#define BOTH 3

LVAL
xmth27_Create_Matrix(
    int lrow, int lcol,
    int rrow, int rcol,
    int transpose
) {
    LVAL lv_shape;
    LVAL lv_mat;

    int        toProt = 2;
    xlstkcheck(toProt);
    xlsave(lv_shape );
    xlsave(lv_mat   );

    /* Create our pixel relation: */
    switch (transpose) {
    case NONE:
	lv_shape = cons(cvfixnum(rcol),     NIL);
	lv_shape = cons(cvfixnum(lrow),lv_shape);
	break;
    case LEFT:
	lv_shape = cons(cvfixnum(rcol),     NIL);
	lv_shape = cons(cvfixnum(lcol),lv_shape);
	break;
    case ROIT:
	lv_shape = cons(cvfixnum(rrow),     NIL);
	lv_shape = cons(cvfixnum(lrow),lv_shape);
	break;
    case BOTH:
	lv_shape = cons(cvfixnum(rrow),     NIL);
	lv_shape = cons(cvfixnum(lcol),lv_shape);
	break;
    }
    lv_mat   = xsendmsg1( lv_xflv, k_new, lv_shape );

    xlpopn(toProt);

    return lv_mat;
}

/************************************************************************/
/*- xmth38_Mult -- Matrix multiplication				*/
/************************************************************************/

#define flt float

void
xmth38_Mult( o, r, l, lrow,lcol,rrow,rcol, transpose )
float       *o;				/* output matrix */
float          *r;			/* right  matrix */
float             *l;			/* left   matrix */
int		      lrow,lcol,rrow,rcol, transpose;
{
    int i, j, k;

printf("\n-----------\n");
    switch (transpose) {

    case NONE:
	for         (i = 0;   i < lrow;   ++i) {    /* lrow      */
	    for     (j = 0;   j < rcol;   ++j) {    /* rcol      */
		float f = 0.0;
printf("\n");
		for (k = 0;   k < lcol;   ++k) {    /* lcol/rrow */
printf("%g * %g   ",l[i*lcol+k],r[k*rcol+j]);
		     f+= l[i*lcol+k] * r[k*rcol+j];
		}
printf(" == %g\n",f);
		o[i*rcol+j] = (float)f;
	    }
	}
	break;

    case LEFT:
	for         (i = 0;   i < lcol;   ++i) {    /* lrow      */
	    for     (j = 0;   j < rcol;   ++j) {    /* rcol      */
		flt  f = 0.0;
		for (k = 0;   k < lrow;   ++k) {    /* lcol/rrow */
		     f+= l[k*lcol+i] * r[k*rcol+j];
		}
		o[i*rcol+j] = f;
	    }
	}
	break;

    case ROIT:
	for         (i = 0;   i < lrow;   ++i) {    /* lrow      */
	    for     (j = 0;   j < rrow;   ++j) {    /* rcol      */
		flt  f = 0.0;
		for (k = 0;   k < lcol;   ++k) {    /* lcol/rrow */
		     f+= l[i*lcol+k] * r[j*rcol+k];
		}
		o[i*rrow+j] = f;
	    }
	}
	break;

    case BOTH:
	for         (i = 0;   i < lcol;   ++i) {    /* lrow      */
	    for     (j = 0;   j < rrow;   ++j) {    /* rcol      */
		flt  f = 0.0;
		for (k = 0;   k < lrow;   ++k) {    /* lcol/rrow */
		     f+= l[k*lcol+i] * r[j*rcol+k];
		}
		o[i*rrow+j] = f;
	    }
	}
	break;
    }
}

#undef flt

/************************************************************************/
/*- xmth39_Mult_Fn -- Matrix multiplication				*/
/************************************************************************/

LVAL
xmth39_Mult_Fn() {
    float*l;    int  lrow;    int  lcol;
    float*r;    int  rrow;    int  rcol;
    float*o;

    LVAL lv_left = NIL;
    LVAL lv_roit = NIL;
    LVAL lv_rslt = NIL;
    int  transpose_right = FALSE;
    int  transpose_left  = FALSE;
    int  transpose;
    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_left) {
	    lv_left = xflv04_Get_A_XFLV();
	} else if (lv == k_right) {
	    lv_roit = xflv04_Get_A_XFLV();
	} else if (lv == k_result_in) {
	    lv_rslt = xlgetarg();
	} else if (lv == k_transpose_left) {
	    transpose_left = (xlgetarg() != NIL);
	} else if (lv == k_transpose_right) {
	    transpose_right = (xlgetarg() != NIL);
	} else {
	    xlerror("Bad XMTH-MULT keyword",lv);
	}
    }
    if (!lv_left) xlfail("XMTH-MULT: missing :LEFT keyword");
    if (!lv_roit) xlfail("XMTH-MULT: missing :RIGHT keyword");

    /* transpose = (transpose_left | (transpose_roit << 1)); :) */
    if (transpose_left) {
	if (transpose_right)   transpose = BOTH;
	else		       transpose = LEFT;
    } else {			      
	if (transpose_right)   transpose = ROIT;
	else		       transpose = NONE;
    }

    /* Right matrix must be two-dimensional: */
    {   csry_rec* h  = xsry9c_Find_Immediate_Base( lv_roit );
	if (h->rank != 2) {
	    xlfail("XMTH-MULT: :right matrix must be two-dimensional");
	}
	
	rrow = h->dim[0];
	rcol = h->dim[1];
	r = (float*) csry_base( lv_roit );
    }

    /* Left matrix must be two-dimensional: */
    {   csry_rec* h  = xsry9c_Find_Immediate_Base( lv_left );
	if (h->rank != 2) {
	    xlfail("XMTH-MULT: :left matrix must be two-dimensional");
	}

	lrow = h->dim[0];
	lcol = h->dim[1];
	l = (float*) csry_base( lv_left );
    }

    /* Left cols must equal right columns: */
    switch (transpose) {
    case NONE: if (lcol != rrow) xlfail("XMTH-MULT: :left cols /= :right rows"); break;
    case LEFT: if (lrow != rrow) xlfail("XMTH-MULT: :left cols /= :right rows"); break;
    case ROIT: if (lcol != rcol) xlfail("XMTH-MULT: :left cols /= :right rows"); break;
    case BOTH: if (lrow != rcol) xlfail("XMTH-MULT: :left cols /= :right rows"); break;
    }

    /* If result-in matrix doesn't exist, create it: */
    if (lv_rslt == NIL || !xflvp(lv_rslt)) {
	lv_rslt = xmth27_Create_Matrix( lrow, lcol, rrow, rcol, transpose );
    } else {

	/* Result matrix must be two-dimensional &tc: */
        csry_rec* h  = xsry9c_Find_Immediate_Base( lv_rslt );
	if (h->rank != 2) {
	    lv_rslt = xmth27_Create_Matrix( lrow, lcol, rrow, rcol, transpose );
	} else {
	    switch (transpose) {
	    case NONE:
		if (h->dim[0] != lrow
		||  h->dim[1] != rcol
		){
		    lv_rslt = xmth27_Create_Matrix( lrow, lcol, rrow, rcol, transpose );
		}
		break;
	    case LEFT:
		if (h->dim[0] != lcol
		||  h->dim[1] != rcol
		){
		    lv_rslt = xmth27_Create_Matrix( lrow, lcol, rrow, rcol, transpose );
		}
		break;
	    case ROIT:
		if (h->dim[0] != lrow
		||  h->dim[1] != rrow
		){
		    lv_rslt = xmth27_Create_Matrix( lrow, lcol, rrow, rcol, transpose );
		}
		break;
	    case BOTH:
		if (h->dim[0] != lcol
		||  h->dim[1] != rrow
		){
		    lv_rslt = xmth27_Create_Matrix( lrow, lcol, rrow, rcol, transpose );
		}
		break;
	    }
	}
    }
    o = (float*) csry_base( lv_rslt );

    /* Do the actual call: */
    xmth38_Mult( o,r,l, lrow,lcol,rrow,rcol, transpose );

    return lv_rslt;
}

/************************************************************************/
/*-    Appendix -- Alternate numerical codes				*/
/************************************************************************/

/* Here's some alternate sample code that could be
   plugged in without prohibitive effort.  See also
   the meschach[012].shar files on netlib.  Maybe the
   most standard and well-tested looking code is the
   netlib SGEFA/SGESL package extracted from the
   Fortran LINPACK and translated to C, along with
   the needed BLAS funcntions.
*/

#ifdef APPENDIX_CODE

/*
From bryant@sioux.stanford.edu Sat Apr  3 14:57:54 1993
Return-Path: <bryant@sioux.stanford.edu>
Received: from sioux.stanford.edu by alnitak.usc.edu (4.1/SMI-4.1+ucs-3.6)
	id AA12724; Sat, 3 Apr 93 14:57:52 PST
Received: from oglala.ice (oglala.Stanford.EDU) by sioux.stanford.edu (4.1/inc-1.0)
	id AA07300; Sat, 3 Apr 93 14:53:25 PST
Date: Sat, 3 Apr 93 14:53:25 PST
From: bryant@sioux.stanford.edu (Bryant Marks)
Message-Id: <9304032253.AA07300@sioux.stanford.edu>
To: ajayshah@rcf.usc.edu
Subject: Re:  SVD
Status: ORr

 
> Hi!   Long ago you sent me an svd routine in C based on code
> from Nash in Pascal.  Has this changed any over the years?  (Your
> email is dated July 1992).  Is your code available by anon ftp?
 
Hi Ajay,
 
I don't think I have changed the code -- but here's my most recent
version of the code, you can check to see if it's any different.
Currently it's not available via anonymous ftp but feel free to
redistribute the code -- it seems to work well in the application
I'm using it in.
 
 
Bryant
 
*/ 
/* This SVD routine is based on pgs 30-48 of "Compact Numerical Methods
   for Computers" by J.C. Nash (1990), used to compute the pseudoinverse.
   Modifications include:
        Translation from Pascal to ANSI C.
        Array indexing from 0 rather than 1.
        Float replaced by double everywhere.
        Support for the Matrix structure.
        I changed the array indexing so that the matricies (float [][])
           could be replaced be a single list (double *) for more
           efficient communication with Mathematica.
*/

#define TOLERANCE 1.0e-22

void SVD(double *W, double *Z, int nRow, int nCol)
{
  int i, j, k, EstColRank, RotCount, SweepCount, slimit;
  double eps, e2, tol, vt, p, h2, x0, y0, q, r, c0, s0, c2, d1, d2;
  eps = TOLERANCE;
  slimit = nCol/4;
  if (slimit < 6.0)
    slimit = 6;
  SweepCount = 0;
  e2 = 10.0*nRow*eps*eps;
  tol = eps*.1;
  EstColRank = nCol;
  for (i=0; i<nCol; i++)
    for (j=0; j<nCol; j++)
      {
        W[nCol*(nRow+i)+j] = 0.0;
        W[nCol*(nRow+i)+i] = 1.0;
      }
  RotCount = EstColRank*(EstColRank-1)/2;
  while (RotCount != 0 && SweepCount <= slimit)
    {
      RotCount = EstColRank*(EstColRank-1)/2;
      SweepCount++;
      for (j=0; j<EstColRank-1; j++)
        {
          for (k=j+1; k<EstColRank; k++)
            {
              p = q = r = 0.0;
              for (i=0; i<nRow; i++)
                {
                  x0 = W[nCol*i+j]; y0 = W[nCol*i+k];
                  p += x0*y0; q += x0*x0; r += y0*y0;
                }
              Z[nCol*j+j] = q; Z[nCol*k+k] = r;
              if (q >= r)
                {
                  if (q<=e2*Z[0] || fabs(p)<=tol*q) RotCount--;
                  else
                    {
                      p /= q; r = 1 - r/q; vt = sqrt(4*p*p+r*r);
                      c0 = sqrt(fabs(.5*(1+r/vt))); s0 = p/(vt*c0);
                      for (i=0; i<nRow+nCol; i++)
                        {
                          d1 = W[nCol*i+j]; d2 = W[nCol*i+k];
                          W[nCol*i+j] = d1*c0+d2*s0; W[nCol*i+k] = -d1*s0+d2*c0;
                        }
                    }
                }
              else
                {
                  p /= r; q = q/r-1; vt = sqrt(4*p*p+q*q);
                  s0 = sqrt(fabs(.5*(1-q/vt)));
                  if (p<0) s0 = -s0;
                  c0 = p/(vt*s0);
                  for (i=0; i<nRow+nCol; i++)
                    {
                      d1 = W[nCol*i+j]; d2 = W[nCol*i+k];
                      W[nCol*i+j] = d1*c0+d2*s0; W[nCol*i+k] = -d1*s0+d2*c0;
                    }
                }
            }
        }
      while (EstColRank>=3 && Z[nCol*(EstColRank-1)+(EstColRank-1)]<=Z[0]*tol+tol*tol)
        EstColRank--;
    }
#if DEBUG
  if (SweepCount > slimit)
    fprintf(stderr, "Sweeps = %d\n", SweepCount);
#endif
}
 

/*

---------------------------------------------------------------------------

The older version (using matrix addressing) is:


From bryant@sioux.stanford.edu Tue Oct 29 09:07:15 1991
Return-Path: <bryant@sioux.stanford.edu>
Received: from usc.edu by almaak.usc.edu (4.1/SMI-3.0DEV3) id AA08601; 
                Tue, 29 Oct 91 09:07:14 PST
Received: from sioux.Stanford.EDU by usc.edu (5.64+/SMI-3.0DEV3) id AA19557; 
                Tue, 29 Oct 91 09:07:15 PST
Received: from apache.stanford.edu by sioux.stanford.edu (4.1/inc-1.0)
	id AA15909; Tue, 29 Oct 91 09:04:40 PST
Date: Tue, 29 Oct 91 09:04:40 PST
From: bryant@sioux.stanford.edu (Bryant Marks)
Message-Id: <9110291704.AA15909@sioux.stanford.edu>
Received: by apache.stanford.edu (4.1/SMI-4.0)
	id AA10942; Tue, 29 Oct 91 09:07:02 PST
To: ajayshah@usc.edu
Subject: SVD
Status: RO

Thanx for the help, the SVD route to the pseudoinverse works like a charm!!

I did find another SVD algorithm in JC Nash's "Compact Numerical Methods for
Computers" (I think it was published in 1990).  I was not able to get the
routine in NR to work so I couldn't get a timing comparison between the two
of them.  I've checked Nash's routine against Mathematica and it's been doing
fine so far with the matricies I've tested.  I've translated Nash's code from
Pascal to C, and I've made a few minor modifications; here's the function along 
with a driver program.  Nash's program is well commented but I've left these 
out because I can't type fast. 

A couple of things to note: A needs to have twice as much room allocated for
it (2*n + 2*m) since the W in the svd function requires this (part of a 
rotation algorithm).  After the routine has run W contains two maticies
of the decomposition  A = USV'.  The first nRow rows contain the product US
and the next nCol rows contain V (not V').  Z is equal to the vector of the
sqares of the diagonal elements of S.

compile file with : gcc -o svd svd.c -lm

Let me know if you have any difficulties,
Thanx again,
Bryant

*/

#include <stdio.h>
#include <math.h>

void svd(double [][], double [], int, int);

main()
{
  int i, j, nRow = 2, nCol = 2;
  double a[4][4], z[2];
/*
  a[0][0]=0; a[0][1]=0; a[0][2]=0; 
  a[1][0]=0; a[1][1]=0; a[1][2]=0; 
  a[2][0]=0; a[2][1]=0; a[2][2]=0; 
*/
/*
  a[0][0]=5; a[0][1]=.000001; a[0][2]=1; 
  a[1][0]=6; a[1][1]=.999999; a[1][2]=1; 
  a[2][0]=7; a[2][1]=2.00001; a[2][2]=1; 
  a[3][0]=8; a[3][1]=2.9999;  a[3][2]=1; 
*/

  a[0][0]=1; a[0][1]=3;  
  a[1][0]=-4; a[1][1]=3;

  svd(a, z, nRow, nCol);
  for (i=0; i<3; i++)
    printf("%f ", sqrt(z[i]));
  printf("\n");
  for (i=0; i<2*nRow; i++)
    {
      for (j=0; j<nCol; j++)
	printf("%f ", a[i][j]);
      printf("\n");
    }
}

void svd(double W[][4], double Z[], int nRow, int nCol)
{
  int i, j, k, EstColRank, RotCount, SweepCount, slimit;
  double eps, e2, tol, vt, p, h2, x0, y0, q, r, c0, s0, c2, d1, d2;
  eps = .0000001;  /* some small tolerance value */
  slimit = nCol/4;
  if (slimit < 6.0)
    slimit = 6;
  SweepCount = 0;
  e2 = 10.0*nRow*eps*eps;
  tol = eps*.1;
  EstColRank = nCol;
  for (i=0; i<nCol; i++)
    for (j=0; j<nCol; j++)
      {
	W[nRow+i][j] = 0.0;
	W[nRow+i][i] = 1.0;
      }
  RotCount = EstColRank*(EstColRank-1)/2;
  while (RotCount != 0 && SweepCount <= slimit)
    {
      RotCount = EstColRank*(EstColRank-1)/2;
      SweepCount++;
      for (j=0; j<EstColRank-1; j++)
	{
	  for (k=j+1; k<EstColRank; k++)
	    {
	      p = q = r = 0.0;
	      for (i=0; i<nRow; i++)
		{
		  x0 = W[i][j]; y0 = W[i][k];
		  p += x0*y0; q += x0*x0; r += y0*y0;
		}
	      Z[j] = q; Z[k] = r;
	      if (q >= r)
		{
		  if (q<=e2*Z[0] || fabs(p)<=tol*q) RotCount--;
		  else
		    {
		      p /= q; r = 1 - r/q; vt = sqrt(4*p*p+r*r);
		      c0 = sqrt(.5*(1+r/vt)); s0 = p/(vt*c0);
		      for (i=0; i<nRow+nCol; i++)
			{
			  d1 = W[i][j]; d2 = W[i][k];
			  W[i][j] = d1*c0+d2*s0; W[i][k] = -d1*s0+d2*c0;
			}
		    }
		}
	      else
		{
		  p /= r; q /= (r-1); vt = sqrt(4*p*p+q*q);
		  s0 = sqrt(.5*(1-q/vt));
		  if (p<0) s0 = -s0;
		  c0 = p/(vt*s0);
		  for (i=0; i<nRow+nCol; i++)
		    {
		      d1 = W[i][j]; d2 = W[i][k];
		      W[i][j] = d1*c0+d2*s0; W[i][k] = -d1*s0+d2*c0;
		    }
		}
	    }
	}
      fprintf(stderr, "Sweep = %d  # of rotations performed = %d\n", SweepCount, RotCount);
      while (EstColRank>=3 && Z[EstColRank]<=Z[0]*tol+tol*tol)
	EstColRank--;
    }
  if (SweepCount > slimit)
    fprintf(stderr, "Sweep Limit exceeded\n");
}

/*

---------------------------------------------------------------------------


Newsgroups: sci.math.num-analysis
Path: usc!news.service.uci.edu!network.ucsd.edu!sdd.hp.com!nigel.msen.com!spool.mu.edu!uwm.edu!wupost!uunet!psinntp!itsmail1.hamilton.edu!NewsWatcher!user
From: bcollett@hamilton.edu (Brian Collett)
Subject: Re: SVD algorithm of Numerical Recipes
Message-ID: <bcollett-140493084847@150.209.16.5>
Followup-To: sci.math.num-analysis
Sender: news@itsmail1.hamilton.edu (USENET News System)
Nntp-Posting-Host: 150.209.16.5
Organization: Hamilton College
References: <1993Apr13.191856.26733@cv.ruu.nl>
Date: Wed, 14 Apr 1993 13:51:28 GMT
Lines: 300

In article <1993Apr13.191856.26733@cv.ruu.nl>, ger@cv.ruu.nl (Ger Timmens)
wrote:
> 
> I'm looking for a singular value decomposition algorithm in C or C++.
> I'm currently using the SVDCMP algorithm of Numerical Recipes, but it
> seems to fail in some cases, e.g. when I try to decompose the following
> 3x3 matrix:

I also tried using this algorithm a number of years ago and found problems
with it. I translated the Algol SVD routine of Golub and Reinsch into C and
I include a copy of that here.
*/
/*
*       This is a translation of the Singular Value Decomposition algorithm
of
*       Golub and Reinsch (Numerische Mathematik 14(1970) pp403-470) from  
      
*       Algol 60 to C. The routine takes a single matrix (A) and computes
two
*       additional matrices (U and V) and a vector W such that
*               A = UWV'
*       The calling sequence is
*       svd(a,m,n,u,w,v,eps,flags)
*       where
*       a is the original, m by n matrix
*       u is the upper resultant
*       w is the vector of singular values
*       v is the lower resultant
*       eps is a convergence test constant
*       flags tells what to do, values:-
*                                       0 produce only w
*                                       1 produce w and u
*                                       2 produce w and v
*                                       3 produce u, w, and v.
*       NOTE m must be greater than n or an error is signaled
*
*       BC 5/11/87
*       Moved to 0->n-1 indices for vectors BC 5/12/87
*/
#define WITHV   1
#define WITHU   2

int svd(a,m,n,u,w,v,eps,flags,temp)
double *a,                      /* The original matrix [m,n] */
       *u,                      /* The new upper matrix [m,n] */
       *v,                      /* The new lower matrix [m,n] */
       *w,                      /* The vector of singular values [n] */
       *temp,                   /* A temporary vector */
        eps;                    /* Convergence factor */
int m,                          /* Number of rows */
    n,                          /* Number of columns (n <= m) */
    flags;                      /* Flags controlling what gets computed. */
{
        extern double TINY;     /* The smallest representable value */
        int i,j,k,l,l1;         /* Mostly loop variables */
        double tol = TINY / eps,/* tells about machine tolerance */
               c,f,g,h,s,x,y,z; /* Temporaries */
        if (m < n) 
                return(-1);
/*
*       First copy a into u.
*/
        for (i = 0; i <= m * n; ++i) {
             u[i] = a[i];
             }
/*parray("initial array",u,n,m);
/*
*       Reduce the u matrix to bidiagonal form with Householder transforms.
*/
        g = (x = 0.0);
        for(i = 0; i < n; ++i) {
                temp[i] = g;
                s = 0.0;
                l = i + 1;
                for (j = i; j < m; j++) {
                        s += u[j * n + i] * u[j * n + i];
                        }
                if (s < tol) {
                        g = 0.0;
                        }
                else {
                        f = u[i * n + i];
                        g = (f < 0.0) ? sqrt(s) : -sqrt(s);
                        h = f * g - s;
                        u[i * n + i] = f - g;
                        for(j = l; j < n; ++j) {
                                s = 0.0;
                                for(k = i; k < m; ++k) {
                                        s += u[k * n + i] * u[k * n + j];
                                        }
                                f = s / h;
                                for(k = i; k < m; ++k) {
                                        u[k * n + j] += f * u[k * n + i];
                                        }
                                }
/*parray("First loop u =",u,n,m);*/
                        }
                w[i] = g;
                s = 0.0;
                for (j = l; j < n; ++j) {
                        s += u[i * n + j] * u[i * n + j];
                        }
                if (s < tol) {
                        g = 0.0;
                        }
                else {
                        f = u[i * n + i + 1];
                        g = (f < 0.0) ? sqrt(s) : -sqrt(s);
                        h = f * g - s;
                        u[i * n + i + 1] = f - g;
                        for (j = l; j < n; ++j) {
                                temp[j] = u[i * n + j] / h;
                                }
                        for (j = l; j < m; ++j) {
                                s = 0.0;
                                for (k = l; k < n; ++k) {
                                        s += u[j * n + k] * u[i*n+k];
                                        }
                                for (k = l; k < n; ++k) {
                                        u[j*n+k] += s * temp[k];
                                        }
                                }
/*parray("Second loop u = ",u,n,m);*/
                        }
                y = fabs(w[i]) + fabs(temp[i]);
                if (y > x) {
                        x = y;
                        }
                }
/*parray("after bidiag u =",u,n,m);
/*
*       Now accumulate right-hand transforms if we are building v too.
*/
        if (flags & WITHV) for (i = n - 1; i >= 0; --i) {
                if (g != 0.0) {
                        h = u[i * n + i + 1] * g;
                        for (j = l; j < n; ++j) {
                                v[j * n + i] = u[i * n + j] / h;
                                }
                        for (j = l; j < n; ++j) {
                                s = 0.0;
                                for (k = l; k < n; ++k) {
                                        s += u[i * n + k] * v[k * n + j];
                                        }
                                for (k = l; k < n; ++k) {
                                        v[k * n + j] += s * v[k * n + i];
                                        }
                                }
                        }
                for (j = l; j < n; ++j) {
                        v[i * n + j] = (v[j * n + i] = 0.0);
                        }
                v[i * n + i] = 1.0;
                g = temp[i];
                l = i;
                }
/*parray("Computed v =",v,n,m);
/*
*       Now accumulate the left-hand transforms.
*/
        if (flags & WITHU) for (i = n - 1; i >= 0; --i) {
                l = i + 1;
                g = w[i];
                for (j = l; j < n; ++j) {
                        u[i * n + j] = 0.0;
                        }
                if (g != 0.0) {
                        h = u[i * n + i] * g;
                        for (j = l; j < n; ++j) {
                                s = 0.0;
                                for (k = l; k < m; ++k) {
                                        s += u[k * n + i] * u[k * n + j];
                                        }
                                f = s / h;
                                for (k = i; k < m; ++k) {
                                        u[k * n + j] += f * u[k * n + i];
                                        }
                                }
                        for (j = i; j < m; ++j) {
                                u[j * n + i] /= g;
                                }
                        }
                else {
                        for (j = i; j < m; ++j) {
                                u[j * n + i] = 0.0;
                                }
                        }
                u[i * n + i] += 1.0;
                }
/*parray("Computed u =",u,n,m);
/*
*       Now diagonalise the bidiagonal form. BEWARE GOTO's IN THE LOOP!!
*/
        eps = eps * x;
        for (k = n - 1; k >= 0; --k) {
testsplitting:
                for (l = k; l >= 0; --l) {
                        if (fabs(temp[l]) <= eps) 
                                goto testconvergence;
                        if (fabs(w[l - 1]) <= eps)
                                goto cancellation;
                        }
/*
*               Cancellation of temp[l] if l > 0;
*/
cancellation:
                c = 0.0;
                s = 1.0;
                l1 = l - 1;
                for (i = l; i <= k; ++i) {
                        f = s * temp[i];
                        temp[i] *= c;
                        if (fabs(f) <= eps) 
                                goto testconvergence;
                        g = w[i];
                        h = (w[i] = sqrt(f * f + g * g));
                        c = g/h;
                        s = -f/h;
                        if (flags & WITHU) for (j = 0; j < m; ++j) {
                                y = u[j * n + l1];
                                z = u[j * n + i];
                                u[j * n + l1] = y * c + z * s;
                                u[j * n + i] = -y * s + z * c;
                                }
                        }
testconvergence:
/*
parray("at test conv u =",u,n,m);
parray("w = ",w,1,m);
parray("v =",v,n,m);
*/
                z = w[k];
                if (l == k) goto convergence;
/*
*               Shift from bottom 2x2 minor.
*/
                x = w[l];
                y = w[k - 1];
                g = temp[k - 1];
                h = temp[k];
                f = ((y - z)*(y + z) + (g - h)*(g + h)) / (2 * h * y);
                g = sqrt(f * f + 1);
                f = ((x - z)*(x + z) + h*(y/((f < 0.0)?f-g:f+g) - h)) / x;
/*
*               Next QR transformation.
*/
                c = (s = 1);
                for (i = l + 1; i <= k; ++i) {
                        g = temp[i];
                        y = w[i];
                        h = s * g;
                        g *= c;
                        temp[i - 1] = (z = sqrt(f * f + h * h));
                        c = f / z;
                        s = h/z;
                        f = x * c + g * s;
                        g = -x * s + g * c;
                        h = y * s;
                        y *= c;
                        if (flags & WITHV) for (j = 0; j < n; ++j) {
                                x = v[j * n + i - 1];
                                z = v[j * n + i];
                                v[j * n + i - 1] = x * c + z * s;
                                v[j * n + i] = -x * s + z * c;
                                }
                        w[i - 1] = (z = sqrt(f * f + h * h));
                        c = f / z;
                        s = h / z;
                        f = c * g + s * y;
                        x = -s * g + c * y;
                        if (flags & WITHU) for (j = 0 ; j < m; ++j) {
                                y = u[j * n + i - 1];
                                z = u[j * n + i];
                                u[j * n + i - 1] = y * c + z * s;
                                u[j * n + i] = -y * s + z * c;
                                }
                        }
                temp[l] = 0.0;
                temp[k] = f;
                w[k] = x;
                goto testsplitting;

convergence:
                if (z < 0.0) {
/*
*                       w[k] is made non-negative.
*/
                        w[k] = -z;
                        if (flags & WITHV) for (j = 0; j < n; ++j) {
                                v[j * n + k] = -v[j * n + k];
                                }
                        }
                }
        }

/*
The calls to parray were just debugging calls to a routine that could print
the contents of an array in a form that a human could read. I have had no
problems with this code.
Hope that helps.
	Brian.
*/
#endif /* SAMPLE */



/************************************************************************/
/*-    File variables							*/
/************************************************************************/
/*

Local variables:
mode: outline-minor
outline-regexp: "[ \\t]*\/\\*-"
End:
*/

