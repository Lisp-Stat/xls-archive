 /*- xmri.c -- support code for handling MRI images.			*/
/*- This file is formatted for outline-minor-mode in emacs19.		*/
/*-^C^O^A shows All of file.						*/
/* ^C^O^Q Quickfolds entire file. (Leaves only top-level headings.)	*/
/* ^C^O^T hides all Text. (Leaves all headings.)			*/
/* ^C^O^I shows Immediate children of node.				*/
/* ^C^O^S Shows all of a node.						*/
/* ^C^O^D hiDes all of a node.						*/
/* ^HFoutline-mode gives more details.					*/
/* (Or do ^HI and read emacs:outline mode.)				*/

/************************************************************************/
/*-    Copyright.							*/
/************************************************************************/

/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94Jul28
* Language:     C
* Package:      N/A
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************

/************************************************************************/
/*-	history								*/
/************************************************************************/

/* 95Jul14 jsp: xvol split off.						*/
/* 95Jun01 jsp: xmri-resample-volume.					*/
/* 94Jul28 jsp: Created.						*/

/************************************************************************/
/*-	header stuff							*/
/************************************************************************/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/cf2v.h"
#include "../../xg.3d/c/cf8v.h"
#include "../../xg.3d/c/cflv.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/geo.h"
#include "../../xg.3d/c/ctfm.h"
#include "../../xvol/c/cvol.h"

extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();

/* I suspect some of these aren't needed any more: */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <string.h>
#include <device.h>
#include <fcntl.h>
#include <termio.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#include <malloc.h>
#include <unistd.h>



#include "ge.h"

#ifndef ERR
#define ERR (-1)
#endif

#undef  loop
#define loop for(;;)


extern LVAL k_ge_u_char;
extern LVAL k_ge_char;
extern LVAL k_ge_u_short;
extern LVAL k_ge_short;
extern LVAL k_ge_u_int;
extern LVAL k_ge_int;
extern LVAL k_ge_float;
extern LVAL k_ge_double;

extern LVAL k_intensity;
extern LVAL k_min;
extern LVAL k_max;
extern LVAL k_result_in;

extern LVAL k_min_left;
extern LVAL k_max_left;
extern LVAL k_min_anterior;
extern LVAL k_max_anterior;
extern LVAL k_min_superior;
extern LVAL k_max_superior;

extern LVAL k_pixelred;
extern LVAL k_pixelgreen;
extern LVAL k_pixelblue;
extern LVAL k_pixeldepth;
extern LVAL k_setarray;
extern LVAL k_show;
extern LVAL k_pixelrelation;
extern LVAL k_axis;
extern LVAL k_transform;

extern LVAL k_plane;
extern LVAL k_depth_in_bits;
extern LVAL k_endian;
extern LVAL k_big;
extern LVAL k_little;
extern LVAL k_padding;

extern LVAL k_slice;
extern LVAL k_filename;
extern LVAL k_subsample_by;
extern LVAL k_zoom_by;
extern LVAL k_voxels;
extern LVAL k_bin_size;
extern LVAL k_pointx;
extern LVAL k_pointy;
extern LVAL k_pointz;
extern LVAL k_rendering_relation;

extern LVAL k_material;
extern LVAL k_diffuse_red;
extern LVAL k_diffuse_green;
extern LVAL k_diffuse_blue;
extern LVAL k_alpha;
extern LVAL k_range;
extern LVAL k_depth;
extern LVAL k_rows;
extern LVAL k_cols;
extern LVAL k_file_offset;
extern LVAL k_distance;
extern LVAL k_dst_min;
extern LVAL k_dst_max;
extern LVAL k_src_min;
extern LVAL k_src_max;
extern LVAL k_filter_shape;
extern LVAL k_impulse;
extern LVAL k_box;
extern LVAL k_triangle;
extern LVAL k_quadratic;
extern LVAL k_mitchell;
extern LVAL k_zero_rest;

extern LVAL k_format;
extern LVAL k_avs_uniform_field;

extern LVAL k_minx;  extern LVAL k_maxx;
extern LVAL k_miny;  extern LVAL k_maxy;
extern LVAL k_minz;  extern LVAL k_maxz;

extern LVAL lv_xf8v;

/************************************************************************/
/*- xmri06_Get_U_Char_Fn -- return unsigned byte as int.		*/
/************************************************************************/

LVAL
xmri06_Get_U_Char_Fn() {
    
    LVAL  lv_str = xlgastring();
    LVAL  lv_loc = xlgafixnum();

    char* str    = (char*) getstring(  lv_str )   ;
    int   len    =         getslength( lv_str ) -1;
    /* (xlisp appends a '\0' to all strings, and */
    /* doesn't count it in the LENGTH (lisp op)  */
    /* but _does_ include it in getslength.)     */

    int   loc    =         getfixnum(  lv_loc );

    xllastarg();

    if (loc < 0   ||   loc+sizeof(Ge_U_Char) > len) {
	xlerror("Bad xmri-get-u-char index:",cvfixnum(loc));
    }

    return cvfixnum( ge_Get_U_Char( str, loc ) );
}

/************************************************************************/
/*- xmri08_Get_Char_Fn -- return signed byte as int.			*/
/************************************************************************/

LVAL
xmri08_Get_Char_Fn() {
    
    LVAL  lv_str = xlgastring();
    LVAL  lv_loc = xlgafixnum();

    char* str    = (char*) getstring(  lv_str )   ;
    int   len    =         getslength( lv_str ) -1;
    /* (xlisp appends a '\0' to all strings, and */
    /* doesn't count it in the LENGTH (lisp op)  */
    /* but _does_ include it in getslength.)     */

    int   loc    =         getfixnum(  lv_loc );

    xllastarg();

    if (loc < 0   ||   loc+sizeof(Ge_Char) > len) {
	xlerror("Bad xmri-get-char index:",cvfixnum(loc));
    }

    return cvfixnum( ge_Get_Char( str, loc ) );
}

/************************************************************************/
/*- xmri10_Get_U_Short_Fn -- return unsigned short as int.		*/
/************************************************************************/

LVAL
xmri10_Get_U_Short_Fn() {
    
    LVAL  lv_str = xlgastring();
    LVAL  lv_loc = xlgafixnum();

    char* str    = (char*) getstring(  lv_str )   ;
    int   len    =         getslength( lv_str ) -1;
    /* (xlisp appends a '\0' to all strings, and */
    /* doesn't count it in the LENGTH (lisp op)  */
    /* but _does_ include it in getslength.)     */

    int   loc    =         getfixnum(  lv_loc );

    xllastarg();

    if (loc < 0   ||   loc+sizeof(Ge_U_Short) > len) {
	xlerror("Bad xmri-get-u-short index:",cvfixnum(loc));
    }

    return cvfixnum( ge_Get_U_Short( str, loc ) );
}

/************************************************************************/
/*- xmri12_Get_Short_Fn -- return signed short as int.			*/
/************************************************************************/

LVAL
xmri12_Get_Short_Fn() {
    
    LVAL  lv_str = xlgastring();
    LVAL  lv_loc = xlgafixnum();

    char* str    = (char*) getstring(  lv_str )   ;
    int   len    =         getslength( lv_str ) -1;
    /* (xlisp appends a '\0' to all strings, and */
    /* doesn't count it in the LENGTH (lisp op)  */
    /* but _does_ include it in getslength.)     */

    int   loc    =         getfixnum(  lv_loc );

    xllastarg();

    if (loc < 0   ||   loc+sizeof(Ge_Short) > len) {
	xlerror("Bad xmri-get-short index:",cvfixnum(loc));
    }

    return cvfixnum( ge_Get_Short( str, loc ) );
}

/************************************************************************/
/*- xmri14_Get_U_Int_Fn -- return unsigned int as int.			*/
/************************************************************************/

LVAL
xmri14_Get_U_Int_Fn() {
    
    LVAL  lv_str = xlgastring();
    LVAL  lv_loc = xlgafixnum();

    char* str    = (char*) getstring(  lv_str )   ;
    int   len    =         getslength( lv_str ) -1;
    /* (xlisp appends a '\0' to all strings, and */
    /* doesn't count it in the LENGTH (lisp op)  */
    /* but _does_ include it in getslength.)     */

    int   loc    =         getfixnum(  lv_loc );

    xllastarg();

    if (loc < 0   ||   loc+sizeof(Ge_U_Int) >= len) {
	xlerror("Bad xmri-get-u-int index:",cvfixnum(loc));
    }

    return cvfixnum( ge_Get_U_Int( str, loc ) );
}

/************************************************************************/
/*- xmri16_Get_Int_Fn -- return unsigned int as int.			*/
/************************************************************************/

LVAL
xmri16_Get_Int_Fn() {
    
    LVAL  lv_str = xlgastring();
    LVAL  lv_loc = xlgafixnum();

    char* str    = (char*) getstring(  lv_str )   ;
    int   len    =         getslength( lv_str ) -1;
    /* (xlisp appends a '\0' to all strings, and */
    /* doesn't count it in the LENGTH (lisp op)  */
    /* but _does_ include it in getslength.)     */

    int   loc    =         getfixnum(  lv_loc );

    xllastarg();

    if (loc < 0   ||   loc+sizeof(Ge_Int) >= len) {
	xlerror("Bad xmri-get-int index:",cvfixnum(loc));
    }

    return cvfixnum( ge_Get_Int( str, loc ) );
}

/************************************************************************/
/*- xmri18_Get_Float_Fn -- return float as flonum.			*/
/************************************************************************/

LVAL
xmri18_Get_Float_Fn() {
    
    LVAL  lv_str = xlgastring();
    LVAL  lv_loc = xlgafixnum();

    char* str    = (char*) getstring(  lv_str )   ;
    int   len    =         getslength( lv_str ) -1;
    /* (xlisp appends a '\0' to all strings, and */
    /* doesn't count it in the LENGTH (lisp op)  */
    /* but _does_ include it in getslength.)     */

    int   loc    =         getfixnum(  lv_loc );

    xllastarg();

    if (loc < 0   ||   loc+sizeof(Ge_Float) >= len) {
	xlerror("Bad xmri-get-float index:",cvfixnum(loc));
    }

    return cvflonum( ge_Get_Float( str, loc ) );
}

/************************************************************************/
/*- xmri20_Get_Double_Fn -- return double as flonum.			*/
/************************************************************************/

LVAL
xmri20_Get_Double_Fn() {
    
    LVAL  lv_str = xlgastring();
    LVAL  lv_loc = xlgafixnum();

    char* str    = (char*) getstring(  lv_str )   ;
    int   len    =         getslength( lv_str ) -1;
    /* (xlisp appends a '\0' to all strings, and */
    /* doesn't count it in the LENGTH (lisp op)  */
    /* but _does_ include it in getslength.)     */

    int   loc    =         getfixnum(  lv_loc );

    xllastarg();

    if (loc < 0   ||   loc+sizeof(Ge_Double) >= len) {
	xlerror("Bad xmri-get-double index:",cvfixnum(loc));
    }

    return cvflonum( ge_Get_Double( str, loc ) );
}

/************************************************************************/
/*- xmri40_Crack_Field_Description -- Parse a lisp field description.	*/
/************************************************************************/

void
xmri40_Crack_Field_Description(
    Ge_Field* f,	/* Result structure.	*/
    LVAL      lv_fd	/* field description.	*/
) {
    /* Check argument list: */
    static char* bad_field = "Bad field description:";
    LVAL lv  = lv_fd;
    int  len;
    if (!listp(lv_fd))  xlerror(bad_field, lv_fd);
    for (len = 0;   consp(lv);   ++len, lv = cdr(lv)) {
	switch (len) {

	case 0:
	    /* First field is a keyword (symbol) giving field type: */
	    {   LVAL lv_typ = car(lv);
		if (!symbolp(lv_typ))   xlerror(bad_field, lv_fd);
		/* Should be one of the six sacred types: */
		if      (lv_typ == k_ge_u_char)	f->base_type = GE_U_CHAR;
		else if (lv_typ == k_ge_char) 	f->base_type = GE_CHAR;
		else if (lv_typ == k_ge_u_short)f->base_type = GE_U_SHORT;
		else if (lv_typ == k_ge_short)	f->base_type = GE_SHORT;
		else if (lv_typ == k_ge_u_int)	f->base_type = GE_U_INT;
		else if (lv_typ == k_ge_int)	f->base_type = GE_INT;
		else if (lv_typ == k_ge_float)	f->base_type = GE_FLOAT;
		else if (lv_typ == k_ge_double)	f->base_type = GE_DOUBLE;
		else {
		    xlerror(bad_field, lv_fd);
	    }   }
	    break;

	case 1:
	    /* Second field is a fixnum giving field length in basetypes: */
	    {   LVAL lv_len = car(lv);
		if (!fixp(lv_len))       xlerror(bad_field, lv_fd);
		f->base_len = getfixnum(lv_len);
		if (f->base_len <= 0) xlerror(bad_field, lv_fd);
	    }
	    break;
	case 2:
	    /* Third field is a fixnum giving field offset in section: */
	    {   LVAL lv_pos = car(lv);
		if (!fixp(lv_pos))       xlerror(bad_field, lv_fd);
		f->offset = getfixnum(lv_pos);
		if (f->offset < 0) xlerror(bad_field, lv_fd);
	    }
	    break;
	case 3:
	    /* Fourth field is a string giving field name basetypes: */
	    {   LVAL nam = car(lv);
		if (!stringp(nam))       xlerror(bad_field, lv_fd);
		f->name  = (char*) getstring(nam);
		/* Also set section based on name: */
		if        (!strncmp( "IH", f->name, 2 )) {
		    f->section = 0;
		} else if (!strncmp( "HS", f->name, 2 )) {
		    f->section = 80;  /* IH_img_p_histo */
		} else if (!strncmp( "SU", f->name, 2 )) {
		    f->section = 124; /* IH_img_p_suite */
		} else if (!strncmp( "EX", f->name, 2 )) {
		    f->section = 132; /* IH_img_p_exam */
		} else if (!strncmp( "SE", f->name, 2 )) {
		    f->section = 140; /* IH_img_p_series */
		} else if (!strncmp( "CT", f->name, 2 )) {
		    f->section = 148; /* IH_img_p_image */
		} else if (!strncmp( "MR", f->name, 2 )) {
		    f->section = 148; /* Same as above, yes. */
		} else {
		    xlerror(bad_field, lv_fd);
	    }   }
	    break;
	case 4:
	    /* Fifth field is a string giving description: */
	    {   LVAL des = car(lv);
		if (!stringp(des)) {
		    xlerror(bad_field, lv_fd);
		}
		f->description = (char*) getstring(des);
	    }
	    break;
	}
    }
    if (len != 5) {
	xlerror(bad_field, lv_fd);
    }
}    

/************************************************************************/
/*- xmri42_Int    -- return signed int as fixnum.			*/
/************************************************************************/

static LVAL
xmri42_Int_Fn(
    Ge_Type typ,		/* GE_INT         or such */
    int     siz,		/* sizeof(Ge_Int) or such */
    int   (*fn)(void*,int)      /* ge_Get_Int()   or such */
) {
    Ge_Field f;

    LVAL lv_hdr = xlgastring();	/* Read file header.		*/
    LVAL lv_fd  = xlgalist(  );	/* Read field description.	*/
    char*   hdr = (char*) getstring(  lv_hdr );
    int     len =         getslength( lv_hdr );
    xllastarg();

    xmri40_Crack_Field_Description( &f, lv_fd );

    /* Check that we indeed have an int field: */
    if (f.base_type != typ
    ||  f.base_len  != 1
    ){
	xlerror("XMRI: wrong-type description!",lv_fd);	
    }

    /* Fetch section offset: */
    {   int section_offset = f.section ? ge_Get_Int( hdr, f.section ) : 0;

	/* Fetch int value proper, convert to fixnum and return: */
	int offset         = section_offset + f.offset;
	if (offset < 0 || offset+siz >= len) {
	    xlerror( "XMRI: bad offset!", cvfixnum(offset) );
	}
        return cvfixnum( fn( hdr, offset ) );
    }
}

/************************************************************************/
/*- xmri46_U_Char_Fn -- return unsigned char as fixnum.			*/
/************************************************************************/

LVAL
xmri46_U_Char_Fn() {
    return xmri42_Int_Fn( GE_U_CHAR, sizeof(Ge_U_Char), ge_Get_U_Char );
}    

/************************************************************************/
/*- xmri48_Char_Fn -- return signed char as fixnum.			*/
/************************************************************************/

LVAL
xmri48_Char_Fn() {
    return xmri42_Int_Fn( GE_CHAR, sizeof(Ge_Char), ge_Get_Char );
}    

/************************************************************************/
/*- xmri50_U_Short_Fn -- return unsigned short as fixnum.		*/
/************************************************************************/

LVAL
xmri50_U_Short_Fn() {
    return xmri42_Int_Fn( GE_U_SHORT, sizeof(Ge_U_Short), ge_Get_U_Short );
}    

/************************************************************************/
/*- xmri52_Short_Fn -- return signed short as fixnum.			*/
/************************************************************************/

LVAL
xmri52_Short_Fn() {
    return xmri42_Int_Fn( GE_SHORT, sizeof(Ge_Short), ge_Get_Short );
}    

/************************************************************************/
/*- xmri54_U_Int_Fn -- return unsigned int as fixnum.			*/
/************************************************************************/

LVAL
xmri54_U_Int_Fn() {
    return xmri42_Int_Fn( GE_U_INT, sizeof(Ge_U_Int), ge_Get_Int );
}    

/************************************************************************/
/*- xmri56_Int_Fn -- return signed int as fixnum.			*/
/************************************************************************/

LVAL
xmri56_Int_Fn(
    void
) {
    return xmri42_Int_Fn( GE_INT, sizeof(Ge_Int), ge_Get_Int );
}    

/************************************************************************/
/*- xmri58_Float_Fn -- return float as flonum.				*/
/************************************************************************/

LVAL
xmri58_Float_Fn() {
    Ge_Field f;

    LVAL lv_hdr = xlgastring();	/* Read file header.		*/
    LVAL lv_fd  = xlgalist(  );	/* Read field description.	*/
    char*   hdr = (char*) getstring(  lv_hdr );
    int     len =         getslength( lv_hdr );
    xllastarg();

    xmri40_Crack_Field_Description( &f, lv_fd );

    /* Check that we indeed have an int field: */
    if (f.base_type != GE_FLOAT
    ||  f.base_len  != 1
    ){
	xlerror("XMRI: wrong-type description!",lv_fd);	
    }

    /* Fetch section offset: */
    {   int section_offset = f.section ? ge_Get_Int( hdr, f.section ) : 0;

	/* Fetch int value proper, convert to fixnum and return: */
	int offset         = section_offset + f.offset;
	if (offset < 0 || offset+sizeof(Ge_Float) >= len) {
	    xlerror( "XMRI: bad offset!", cvfixnum(offset) );
	}
        return cvflonum( ge_Get_Float( hdr, offset ) );
    }
}    

/************************************************************************/
/*- xmri60_Double_Fn -- return double as flonum.			*/
/************************************************************************/

LVAL
xmri60_Double_Fn() {
    Ge_Field f;

    LVAL lv_hdr = xlgastring();	/* Read file header.		*/
    LVAL lv_fd  = xlgalist(  );	/* Read field description.	*/
    char*   hdr = (char*) getstring(  lv_hdr );
    int     len =         getslength( lv_hdr );
    xllastarg();

    xmri40_Crack_Field_Description( &f, lv_fd );

    /* Check that we indeed have an int field: */
    if (f.base_type != GE_DOUBLE
    ||  f.base_len  != 1
    ){
	xlerror("XMRI: wrong-type description!",lv_fd);	
    }

    /* Fetch section offset: */
    {   int section_offset = f.section ? ge_Get_Int( hdr, f.section ) : 0;

	/* Fetch int value proper, convert to fixnum and return: */
	int offset         = section_offset + f.offset;
	if (offset < 0 || offset+sizeof(Ge_Double) >= len) {
	    xlerror( "XMRI: bad offset!", cvfixnum(offset) );
	}
        return cvflonum( ge_Get_Double( hdr, offset ) );
    }
}    

/************************************************************************/
/*- xmri62_String_Fn -- return char* as string.				*/
/************************************************************************/

LVAL
xmri62_String_Fn() {
    return NIL;
}    

/************************************************************************/
/*- xmri80_Read_File_Header_Fn -- return file header.			*/
/************************************************************************/

LVAL
xmri80_Read_File_Header_Fn() {

    /* Read filename: */
    LVAL lv_filename = NULL;
    char*   filename = NULL;
    FILE*   fd;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_filename) {
	    lv_filename = xlgastring();
	    filename = (char*) getstring( lv_filename );
	} else {
	    xlerror("Bad XMRI-READ-FILE-HEADER keyword",lv);
	}
    }
    if (!filename) xlfail("XMRI-READ-FILE-HEADER: missing :FILENAME keyword");

    /* Open file from which to read header: */
    fd  = fopen( filename, "r" );
    if (!fd)	{
	xlerror( "Can't open file!", lv_filename );
    }

    /* Read first 8 bytes of file to see how big it is: */
    {   char buf8[2*sizeof(Ge_Int)];
        int bytes_read  = fread( buf8, 1, 2*sizeof(Ge_Int), fd );

	if (bytes_read != 2*sizeof(Ge_Int)) {
	    fclose( fd );
	    xlerror( "Can't access file header!", lv_filename );
	}

	/* Create a string of required length and read header into it: */
	{   int  len   = ge_Get_Int( buf8, sizeof(Ge_Int) );
	    LVAL lv_h  = newstring( len+1 );	/* +1 for xlisp's terminal nul */
	    char*hdr   = (char*) getstring( lv_h );
	    int  toread= len - 2*sizeof(Ge_Int);
	    memcpy( hdr, buf8, 2*sizeof(Ge_Int) );

            bytes_read = fread( &hdr[ 2*sizeof(Ge_Int) ], 1, toread, fd );
	    fclose( fd );
	    if (bytes_read != toread) {
		xlerror( "Can't access file header!", lv_filename );
	    }
	    hdr[len]   = '\0';

	    return lv_h;
    }	}
}    

/************************************************************************/
/*- xmri90_Read_RGB_Image_Fn -- Return image as :PIXEL-GREEN grl.	*/
/************************************************************************/

/* Statically compiled descriptions of the header fields I */
/* care about.   (I don't feel like compiling the complete */
/* header description table ge_tab.c into this module.)    */

#undef G
#define G static Ge_Field
G img_width  = {GE_INT,1,0,0x8,"IH_img_width","width (pixels) of image" };
G img_height = {GE_INT,1,0,0xc,"IH_img_height","height (pixels) of image" };
G img_depth  = {GE_INT,1,0,0x10,"IH_img_depth","depth (1, 8, 16, or 24 bits) of " };
G imatrix_x  = {GE_SHORT,1,0x94,0x1e,"MR_imatrix_X","Image matrix size - X" };
G imatrix_y  = {GE_SHORT,1,0x94,0x20,"MR_imatrix_Y","Image matrix size - Y" };
#undef G

LVAL
xmri90_Read_RGB_Image_Fn(
    void
){

    /* Read filename: */
    LVAL lv_filename = NULL;
    char*   filename = NULL;
    int     fd;
    int       lo_lim =   0;	/* Lowest  pixel value not rounded up.   */
    int       hi_lim = 256;	/* Highest pixel value not rounded down. */
    LVAL      lv_pix = NULL;	/* Relation holding output pixels.	*/
    LVAL      lv_grn = NULL;	/* :PIXEL-GREEN array in above.		*/
    int       offset = -1;
    int       rows   = -1;
    int       cols   = -1;
    LVAL      lv_plane =  k_pixelgreen;
    int       depth  = 16;
    int  big_endian  =  TRUE;
    int      padding =  0;
    CSRY_UNSIGNED8 *pixel;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_min) {
	    lo_lim = getfixnum( xlgafixnum() );
	} else if (lv == k_max) {
	    hi_lim = getfixnum( xlgafixnum() );
	} else if (lv == k_result_in) {
	    lv_pix = xlgetarg();
	} else if (lv == k_filename) {
	    lv_filename = xlgastring();
	    filename = (char*) getstring( lv_filename );
	} else if (lv == k_file_offset) {
	    LVAL lv = xlgafixnum();
	    offset  = getfixnum( lv );
	    if (offset < 0) xlerror("Bad XMRI-READ-RGB-IMAGE :FILE-OFFSET val",lv);
	} else if (lv == k_rows) {
	    LVAL lv = xlgafixnum();
	    rows  = getfixnum( lv );
	    if (rows < 0) xlerror("Bad XMRI-READ-RGB-IMAGE :ROWS val",lv);
	} else if (lv == k_cols) {
	    LVAL lv = xlgafixnum();
	    cols  = getfixnum( lv );
	    if (cols < 0) xlerror("Bad XMRI-READ-RGB-IMAGE :COLS val",lv);
	} else if (lv == k_plane) {
	    lv_plane = xlgasymbol();
	    if (lv_plane != k_pixelred
	    &&  lv_plane != k_pixelgreen
	    &&  lv_plane != k_pixelblue
	    ){
		xlerror("Bad XMRI-READ-RGB-IMAGE :PLANE val",lv);
	    }
	} else if (lv == k_depth_in_bits) {
	    LVAL lv = xlgafixnum();
	    depth = getfixnum( lv );
	    if (depth != 8
            &&  depth != 16
        /*  &&  depth != 4 *//* Not supported yet. */
            ){
		xlerror("Bad XMRI-READ-RGB-IMAGE :DEPTH-IN-BITS val",lv);
	    }
	} else if (lv == k_endian) {
	    LVAL lv = xlgasymbol();
	    if      (lv == k_big   )   big_endian = TRUE ;
	    else if (lv == k_little)   big_endian = FALSE;
	    else xlerror("Bad XMRI-READ-RGB-IMAGE :ENDIAN val",lv);
	} else if (lv == k_padding) {
	    LVAL lv = xlgafixnum();
	    padding = getfixnum( lv );
	    if (padding<0) xlerror("Bad XMRI-READ-RGB-IMAGE :PADDING val",lv);
	} else {
	    xlerror("Bad XMRI-READ-RGB-IMAGE keyword",lv);
    }   }
    if (!filename) xlfail("XMRI-READ-RGB-IMAGE: missing :FILENAME keyword");

    /* Open file from which to read header: */
    fd  = open( filename, O_RDONLY );
    if (fd < 0)	{
	xlerror( "Can't open file!", lv_filename );
    }

    /* Read first 8 bytes of file to see how big it is: */
    {   char buf[0x20000];
        int bytes_read;
	int len;
	int toread;
	int width;
	int height;
	int mat_x;
	int mat_y;

	/* Handle special case of not having a header: */
	if (rows   != -1
	||  cols   != -1
	||  offset != -1
	){
	    if (rows   == -1) xlfail("Bad XMRI-READ-RGB-IMAGE missing :ROWS val");
	    if (cols   == -1) xlfail("Bad XMRI-READ-RGB-IMAGE missing :COLS val");
	    if (offset == -1) xlfail("Bad XMRI-READ-RGB-IMAGE missing :FILE-OFFSET val");

	    /* Seek to requested offset: */
	    if (offset != lseek( fd, offset, SEEK_SET )) {
		close( fd );
		xlerror(
		    "XMRI-READ-RGB-IMAGE: couldn't seek to offset:",
		    cvfixnum( offset )
		);
	    }

	    width  = mat_x = cols;
	    height = mat_y = rows;

	} else {

	    bytes_read  = read( fd, buf, 2*sizeof(Ge_Int) );
	    if (bytes_read != 2*sizeof(Ge_Int)) {
		close( fd );
		xlerror( "Can't access file header!", lv_filename );
	    }

	    /* Read header into temp buffer: */
	    len   = ge_Get_Int( buf, sizeof(Ge_Int) );
	    toread= len - 2*sizeof(Ge_Int);
	    if (len > 0x20000) xlerror("XMRI: header too long",cvfixnum(len));

            bytes_read = read( fd, &buf[ 2*sizeof(Ge_Int) ], toread );
	    if (bytes_read != toread) {
		close( fd );
		xlerror( "Can't access file header!", lv_filename );
	    }

	    /* Read image dimensions: */
	    width  = ge_Int(   buf, &img_width  );
	    height = ge_Int(   buf, &img_height );
	    depth  = ge_Int(   buf, &img_depth  );
	    mat_x  = ge_Short( buf, &imatrix_x  );
	    mat_y  = ge_Short( buf, &imatrix_y  );
	}

	/* Make sure lv_pix is a graphic relation  */
	/* of appropriate shape, creating a new    */
        /* one if it is not:                       */
	if (!      lv_pix
	||  !xgrlp(lv_pix)
#ifdef PRODUCTION
        ||  !xvol94_Check_X_And_Y_Dimensions(lv_pix,width,height,0)
#else
        ||  !xvol94_Check_X_And_Y_Dimensions(lv_pix,width,width,0)
#endif
	){
	    /* Create graphic relation to hold result: */
	    CSRY_UNSIGNED8 *dummy;
	    lv_pix = xvol87_Create_Pixels(
#ifdef PRODUCTION
		height,	/*rows*/
#else
		width,	/*rows*/
#endif
		width,	/*cols*/
		&dummy
	    );
	}
	/* Make sure lv_pix contains a properly    */
	/* typed and shaped array under the given  */
        /* name (one of :pixel-{red|green|blue}),  */
        /* creating a new one if need be:          */
	if (!(     lv_grn = xgrl3c_Get_Array( lv_pix, lv_plane, NIL, TRUE ))
	||  !xf8vp(lv_grn)
#ifdef PRODUCTION
        ||  !xvol94_Check_X_And_Y_Dimensions(lv_grn,width,height,0)
#else
        ||  !xvol94_Check_X_And_Y_Dimensions(lv_grn,width,width,0)
#endif
	){
#ifdef PRODUCTION
            pixel = xvol86_Create_Plane( lv_pix, lv_plane, rows, cols, lv_xf8v );
#else
            pixel = xvol86_Create_Plane( lv_pix, lv_plane, cols, cols, lv_xf8v );
#endif
	} else {
	    pixel = (CSRY_UNSIGNED8*) csry_base( lv_grn );
	}

	/* Set up translation table from 12 bits down to 8: */
	xvol8b_Init_Map( lo_lim, hi_lim );

	/* Over all rows in image: */
	if (rows   != -1
	||  cols   != -1
	||  offset != -1
	){
	
#define BUFFER_SIZE 1024
	    int  row;
	    /*********************************************/
	    /* At one read() per byte, reading an image  */
	    /* took about a second per scanline.  I was  */
	    /* amazed.  The old rule of thumb that a     */
	    /* syscall always takes ~1ms seems to be     */
	    /* holding up despite x100 faster processors.*/
	    /* so we buffer:                             */
	    /*********************************************/
	    unsigned char buf[ BUFFER_SIZE ];
	    unsigned char*lim =  &buf[BUFFER_SIZE];
	    unsigned char*p   =  lim-padding;
	    int  bytes_left_to_read = height*width;

	    if (depth == 16) bytes_left_to_read *= 2;

	    /* "-1" because we shouldn't expect */
	    /* padding after last pixel:        */
	    bytes_left_to_read += (height*width-1)*padding;
	    for (row = 0;   row < height;   ++row) {

		/* Compute location of this row in pixel[]: */
		int row_loc = ((height-1)-row) * mat_x;

		/* Over all valid pixels in row: */
		int  col;
		for (col = 0;   col < width;   ++col) {

		    /* Maybe refill the buffer: */
		    if (
			/* If we're guaranteed that we can slide   */
			/* remaining buffer contents back to start */
			/* of buffer without worrying about which  */
			/* direction memcpy() copies (this also    */
			/* keeps us from spending too much time    */
			/* copying stuff) ...			   */
			p-buf > (BUFFER_SIZE>>1)
			/* ... and if file holds more stuff which  */
			/* we want to read:                        */
                        && bytes_left_to_read
		    ) {

			/* Slide remaining buffer contents */
			/* to start of buffer:             */
			int bytes = lim-p;
			memcpy( buf, p, bytes );
			p = buf; lim = p+bytes;			

			/* Append more stuff to buffer: */
			bytes = &buf[BUFFER_SIZE] - lim;
			if (bytes > bytes_left_to_read) {
			    bytes = bytes_left_to_read;
			}
			bytes = read( fd, lim, bytes );
			if (!bytes) {
			    close(fd);
			    xlerror("xmri: File too short:",lv_filename);
			}
			lim                += bytes;
			bytes_left_to_read -= bytes;
		    }

		    /* Skip any unwanted interleaved data: */
		    p += padding;


		    /* Read required number of bytes: */
		    {   unsigned byte0 = *p++;

			/* Assemble the bytes into desired value: */
			if (depth == 8) {

			    pixel[ row_loc + col ] = byte0;

			} else {

			    unsigned byte1 = *p++;
			    unsigned val;

			    if (big_endian)   val = (byte0 << 8) | byte1;
			    else              val = (byte1 << 8) | byte0;

			    /* These are supposed to be 12-bit values: */
			    val    &= 0xfff;

			    /* Map pixel down to 8 bits and save: */
			    pixel[ row_loc + col ] = xvol8a_map[ val ];
		        }

		        if (p > lim) {
			    close(fd);
			    xlerror("xmri: Bug reading image:",lv_filename);
	    }   }   }   }

#undef BUFFER_SIZE
	} else {
	    char buf[ 4096 ];
	    int  row;

	    /* Sanity-check dimensions: */
	    if (depth  != 16) {
		close( fd );
		xlfail("Not a 16-bit image! Generalize xmri.c");
	    }

	    for (row = 0;   row < height;   ++row) {
		int col;

		/* Compute location of this row in pixel[]: */
		int row_loc = ((height-1)-row) * mat_x;

		/* Compute bytes per imatrix row: */
		int want = mat_x * sizeof(Ge_Short);

		/* Read next pixel row from input file: */
		int got  = read( fd, buf, want );
		if (got != want) {
		    close(fd);
		    xlerror("xmri: Couldn't read image:",lv_filename);
		}

		/* Over all valid pixels in row: */
		for (col = 0;   col < width;   ++col) {

		    /* Read 16-bit pixel val, maybe byteswapping: */
		    int pix = ge_Get_Short( buf, col*2 );

		    /* These are supposed to be 12-bit values: */
		    pix    &= 0xfff;

		    /* Map pixel down to 8 bits and save: */
		    pixel[ row_loc + col ] = xvol8a_map[ pix ];
	}   }   }
	close(fd);

	/* Return resulting relation: */
	return lv_pix;
    }
}    

/************************************************************************/
/*- xmria0_Read_Voxel_Slice_Fn -- Load image into voxel-grl slice.	*/
/************************************************************************/

 /***********************************************************************/
 /*- xmria0_Read_Voxel_Slice_Fn -- Load image into voxel-grl slice.	*/
 /***********************************************************************/

LVAL
xmria0_Read_Voxel_Slice_Fn(
    void
){
    /* Read filename: */
    LVAL lv_voxels       = NULL;
    LVAL lv_ary          = NULL;
    LVAL lv_slice        = NULL;
    LVAL lv_filename     = NULL;
    LVAL lv_subsample_by = NULL;
    int     subsample_by = 1;
    int     slice;
    char*   filename;
    int     x_dim;
    int     y_dim;
    int     z_dim;
    CSRY_UNSIGNED16* voxel;

    FILE*   fd;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_slice) {

	    lv_slice = xlgafixnum();
            slice    = getfixnum( lv_slice );

	} else if (lv == k_result_in) {

	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;

	} else if (lv == k_filename) {

	    lv_filename = xlgastring();
	    filename = (char*) getstring( lv_filename );

	} else if (lv == k_subsample_by) {

	    lv_subsample_by = xlgafixnum();
	    subsample_by    = getfixnum( lv_subsample_by );

	} else {
	    xlerror("Bad XMRI-GET-VOXEL-SLICE keyword",lv);
    }   }

    if (!lv_filename) xlfail("XMRI-GET-VOXEL-SLICE: No :FILENAME!");

    /* Open file from which to read header: */
    fd  = fopen( filename, "r" );
    if (!fd)	{
	xlerror( "Can't open file!", lv_filename );
    }

    /* Read first 8 bytes of file to see how big it is: */
    {   int  len;
	int  toread;
	char buf[0x20000];
        int  bytes_read  = fread( buf, 1, 2*sizeof(Ge_Int), fd );

	if (bytes_read != 2*sizeof(Ge_Int)) {
	    fclose( fd );
	    xlerror( "Can't access file header!", lv_filename );
	}

	/* Read header into temp buffer: */
	len   = ge_Get_Int( buf, sizeof(Ge_Int) );
	toread= len - 2*sizeof(Ge_Int);
	if (len > 0x20000) xlerror("XMRI: header too long",cvfixnum(len));

	bytes_read = fread( &buf[ 2*sizeof(Ge_Int) ], 1, toread, fd );
	if (bytes_read != toread) {
	    fclose( fd );
	    xlerror( "Can't access file header!", lv_filename );
	}

	/* Read image dimensions: */
	{   int width  = ge_Int(   buf, &img_width  );
	    int height = ge_Int(   buf, &img_height );
	    int depth  = ge_Int(   buf, &img_depth  );
	    int mat_x  = ge_Short( buf, &imatrix_x  );
	    int mat_y  = ge_Short( buf, &imatrix_y  );
	    int row;
	    int v_width;	/* Width  in voxel[] */
	    int v_height;	/* Height in voxel[] */
	    int v_slice_size;	/* v_width*v_height  */
	    int v_shift;	/* log2(subsample_by)*/

	    /* Ugly hack 'cause a 512x512x512 cube swamps memory: */
	    if (width==512 || height==512) subsample_by = 2;

	    switch (subsample_by) {
	    case 1:
		v_width  = width;
		v_height = height;
		v_shift  = 0;
		break;
	    case 2:
		v_width  = width  /2;
		v_height = height /2;
		v_shift  = 1;
		break;
	    default:
		xlerror(
		    "Bad XMRI-GET-VOXEL-SLICE :SUBSAMPLE-BY value",
		    lv_subsample_by
		);
	    }
	    v_slice_size = v_width * v_height;

	    /* Sanity-check dimensions: */
	    if (depth  != 16) {
		fclose( fd );
		xlfail("Not a 16-bit image! Generalize xmri.c");
	    }
	    if (slice < 0 || slice >= width) {
		fclose( fd );
		xlerror("XMRI-READ-VOXEL-SLICE: Bad slice#",lv_slice);
	    }

	    /* If image isn't congruent with voxel */
	    /* array or voxel array doesn't exist, */
	    /* create a congruent voxel array:     */
	    if (lv_ary && xgrlp( lv_ary )) {
		lv_ary = xgrl3c_Get_Array( lv_ary, k_intensity, NIL, TRUE );
	    }
	    if (lv_ary && xf2vp( lv_ary )) {
		xvol95_Get_X_Y_Z_Dimensions( &x_dim, &y_dim, &z_dim, lv_ary );
	    }
	    if (!lv_ary
	    ||  !xf2vp( lv_ary )
	    ||  x_dim != v_width
	    ||  y_dim != v_height
	    ||  z_dim != v_width
	    ){
		lv_voxels = xvol88_Create_Voxels(
		    v_height, /* rows   */
		    v_width,  /* cols   */
		    v_width,  /* slices */
		    &voxel
		);
	    } else {
		voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );
	    }

	    /* Over all rows in image: */
	    for (row = 0;   row < height;   ++row) {
		int col;
		CSRY_UNSIGNED16* r;
		int want;
		int got;

#ifdef XYZZY
		if (v_shift && (row&1))  continue;
#endif

		/* Compute location of this row in voxels[]: */
		r = (
		    &voxel[
			v_slice_size*slice +
			v_width*((v_height-1)-(row>>v_shift))
		    ]
		);

		/* Compute bytes per imatrix row: */
		want = mat_x * sizeof(Ge_Short);

		/* Read next pixel row from input file: */
		got  = fread( buf, 1, want, fd );

		if (got != want) {
		    fclose(fd);
		    xlerror(
			"XMRI-READ-VOXEL-SLICE: Couldn't read image:",
			lv_filename
		    );
		}

		if (!v_shift) {
		    /* Copy pixels to r, doing any needed */
		    /* byteswapping in the process:       */
		    ge_Get_Shorts( r, buf, 0, width );
		} else {
		    /* Over all valid pixels in row: */
		    for (col = 0;   col < width;   ++col) {

			/* Read 16-bit pixel val, maybe byteswapping: */
			int pixel = ge_Get_Short( buf, col*2 );

			/* These are supposed to be 12-bit values: */
			pixel    &= 0xfff;

			/* Save pixel: */
			r[ col >> v_shift ] = pixel;
	}   }   }   }

	fclose(fd);

	return lv_voxels;
    }
}    

/************************************************************************/
/*-    File variables							*/
/************************************************************************/
/*

Local variables:
mode: outline-minor
outline-regexp: "[ \\t]*\/\\*-"
End:
*/

