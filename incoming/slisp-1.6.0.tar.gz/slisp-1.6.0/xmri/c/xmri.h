/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xmri.h
* Description:  Hybrid-class header for GE CAT/MRI file format support.
* Author:       Jeff Prothero
* Created:      94Jul28
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#include "xmth.h"

#ifdef MODULE_XLDMEM_H_GLOBALS

extern LVAL xmri06_Get_U_Char_Fn();
extern LVAL xmri08_Get_Char_Fn();

extern LVAL xmri10_Get_U_Short_Fn();
extern LVAL xmri12_Get_Short_Fn();

extern LVAL xmri14_Get_U_Int_Fn();
extern LVAL xmri16_Get_Int_Fn();

extern LVAL xmri18_Get_Float_Fn();
extern LVAL xmri20_Get_Double_Fn();


extern LVAL xmri46_U_Char_Fn();
extern LVAL xmri48_Char_Fn();

extern LVAL xmri50_U_Short_Fn();
extern LVAL xmri52_Short_Fn();

extern LVAL xmri54_U_Int_Fn();
extern LVAL xmri56_Int_Fn();

extern LVAL xmri58_Float_Fn();
extern LVAL xmri60_Double_Fn();

extern LVAL xmri62_String_Fn();

extern LVAL xmri80_Read_File_Header_Fn();
extern LVAL xmri90_Read_RGB_Image_Fn();
extern LVAL xmria0_Read_Voxel_Slice_Fn();

#ifndef EXTERNED_K_GE_U_CHAR
extern LVAL k_ge_u_char;/* Symbol ":GE-U-CHAR" */
#define EXTERNED_K_GE_U_CHAR
#endif

#ifndef EXTERNED_K_GE_CHAR
extern LVAL k_ge_char;/* Symbol ":GE-CHAR" */
#define EXTERNED_K_GE_CHAR
#endif

#ifndef EXTERNED_K_GE_U_SHORT
extern LVAL k_ge_u_short;/* Symbol ":GE-U-SHORT" */
#define EXTERNED_K_GE_U_SHORT
#endif

#ifndef EXTERNED_K_GE_SHORT
extern LVAL k_ge_short;/* Symbol ":GE-SHORT" */
#define EXTERNED_K_GE_SHORT
#endif

#ifndef EXTERNED_K_GE_U_INT
extern LVAL k_ge_u_int;/* Symbol ":GE-U-INT" */
#define EXTERNED_K_GE_U_INT
#endif

#ifndef EXTERNED_K_GE_INT
extern LVAL k_ge_int;/* Symbol ":GE-INT" */
#define EXTERNED_K_GE_INT
#endif

#ifndef EXTERNED_K_GE_FLOAT
extern LVAL k_ge_float;/* Symbol ":GE-FLOAT" */
#define EXTERNED_K_GE_FLOAT
#endif

#ifndef EXTERNED_K_GE_DOUBLE
extern LVAL k_ge_double;/* Symbol ":GE-DOUBLE" */
#define EXTERNED_K_GE_DOUBLE
#endif

#ifndef EXTERNED_K_MIN_LEFT
extern LVAL k_min_left;/* Symbol ":MIN-LEFT" */
#define EXTERNED_K_MIN_LEFT
#endif

#ifndef EXTERNED_K_MAX_LEFT
extern LVAL k_max_left;/* Symbol ":MAX-LEFT" */
#define EXTERNED_K_MAX_LEFT
#endif

#ifndef EXTERNED_K_MIN_ANTERIOR
extern LVAL k_min_anterior;/* Symbol ":MIN-ANTERIOR" */
#define EXTERNED_K_MIN_ANTERIOR
#endif

#ifndef EXTERNED_K_MAX_ANTERIOR
extern LVAL k_max_anterior;/* Symbol ":MAX-ANTERIOR" */
#define EXTERNED_K_MAX_ANTERIOR
#endif

#ifndef EXTERNED_K_MIN_SUPERIOR
extern LVAL k_min_superior;/* Symbol ":MIN-SUPERIOR" */
#define EXTERNED_K_MIN_SUPERIOR
#endif

#ifndef EXTERNED_K_MAX_SUPERIOR
extern LVAL k_max_superior;/* Symbol ":MAX-SUPERIOR" */
#define EXTERNED_K_MAX_SUPERIOR
#endif

#ifndef EXTERNED_K_MIN
extern LVAL k_min;/* Symbol ":MIN" */
#define EXTERNED_K_MIN
#endif

#ifndef EXTERNED_K_MAX
extern LVAL k_max;/* Symbol ":MAX" */
#define EXTERNED_K_MAX
#endif

#ifndef EXTERNED_K_INTENSITY
extern LVAL k_intensity;/* Symbol ":INTENSITY" */
#define EXTERNED_K_INTENSITY
#endif

#ifndef EXTERNED_K_RESULT_IN
extern LVAL k_result_in;/* Symbol ":RESULT-IN" */
#define EXTERNED_K_RESULT_IN
#endif

#ifndef EXTERNED_K_AXIS
extern LVAL k_axis;/* Symbol ":AXIS" */
#define EXTERNED_K_AXIS
#endif

#ifndef EXTERNED_K_FILENAME
extern LVAL k_filename;/* Symbol ":FILENAME" */
#define EXTERNED_K_FILENAME
#endif

#ifndef EXTERNED_K_SLICE
extern LVAL k_slice;/* Symbol ":SLICE" */
#define EXTERNED_K_SLICE
#endif

#ifndef EXTERNED_K_SUBSAMPLE_BY
extern LVAL k_subsample_by;/* Symbol ":SUBSAMPLE-BY" */
#define EXTERNED_K_SUBSAMPLE_BY
#endif

#ifndef EXTERNED_K_ZOOM_BY
extern LVAL k_zoom_by;/* Symbol ":ZOOM-BY" */
#define EXTERNED_K_ZOOM_BY
#endif

#ifndef EXTERNED_K_VOXELS
extern LVAL k_voxels;/* Symbol ":VOXELS" */
#define EXTERNED_K_VOXELS
#endif

#ifndef EXTERNED_K_BIN_SIZE
extern LVAL k_bin_size;/* Symbol ":BIN-SIZE" */
#define EXTERNED_K_BIN_SIZE
#endif

#ifndef EXTERNED_K_RENDERING_RELATION
extern LVAL k_rendering_relation;/* Symbol ":RENDERING-RELATION" */
#define EXTERNED_K_RENDERING_RELATION
#endif

#ifndef EXTERNED_K_DIFFUSE_RED
extern LVAL k_diffuse_red;/* Symbol ":DIFFUSE-RED" */
#define EXTERNED_K_DIFFUSE_RED
#endif

#ifndef EXTERNED_K_DIFFUSE_GREEN
extern LVAL k_diffuse_green;/* Symbol ":DIFFUSE-GREEN" */
#define EXTERNED_K_DIFFUSE_GREEN
#endif

#ifndef EXTERNED_K_DIFFUSE_BLUE
extern LVAL k_diffuse_blue;/* Symbol ":DIFFUSE-BLUE" */
#define EXTERNED_K_DIFFUSE_BLUE
#endif

#ifndef EXTERNED_K_ALPHA
extern LVAL k_alpha;/* Symbol ":ALPHA" */
#define EXTERNED_K_ALPHA
#endif

#ifndef EXTERNED_K_RANGE
extern LVAL k_range;/* Symbol ":RANGE" */
#define EXTERNED_K_RANGE
#endif

#ifndef EXTERNED_K_SRC_MIN
extern LVAL k_src_min;/* Symbol ":SRC-MIN" */
#define EXTERNED_K_SRC_MIN
#endif

#ifndef EXTERNED_K_SRC_MAX
extern LVAL k_src_max;/* Symbol ":SRC-MAX" */
#define EXTERNED_K_SRC_MAX
#endif

#ifndef EXTERNED_K_DST_MIN
extern LVAL k_dst_min;/* Symbol ":DST-MIN" */
#define EXTERNED_K_DST_MIN
#endif

#ifndef EXTERNED_K_DST_MAX
extern LVAL k_dst_max;/* Symbol ":DST-MAX" */
#define EXTERNED_K_DST_MAX
#endif

#ifndef EXTERNED_K_DEPTH
extern LVAL k_depth;/* Symbol ":DEPTH" */
#define EXTERNED_K_DEPTH
#endif

#ifndef EXTERNED_K_PIXELDEPTH
extern LVAL k_pixeldepth;/* Symbol ":PIXEL-DEPTH" */
#define EXTERNED_K_PIXELDEPTH
#endif

#ifndef EXTERNED_K_FILE_OFFSET
extern LVAL k_file_offset;/* Symbol ":FILE-OFFSET" */
#define EXTERNED_K_FILE_OFFSET
#endif

#ifndef EXTERNED_K_ROWS
extern LVAL k_rows;/* Symbol ":ROWS" */
#define EXTERNED_K_ROWS
#endif

#ifndef EXTERNED_K_COLS
extern LVAL k_cols;/* Symbol ":COLS" */
#define EXTERNED_K_COLS
#endif

#ifndef EXTERNED_K_DISTANCE
extern LVAL k_distance;/* Symbol ":DISTANCE" */
#define EXTERNED_K_DISTANCE
#endif

#ifndef EXTERNED_K_FILTER_SHAPE
extern LVAL k_filter_shape;/* Symbol ":FILTER-SHAPE" */
#define EXTERNED_K_FILTER_SHAPE
#endif

#ifndef EXTERNED_K_IMPULSE
extern LVAL k_impulse;/* Symbol ":IMPULSE" */
#define EXTERNED_K_IMPULSE
#endif

#ifndef EXTERNED_K_BOX
extern LVAL k_box;/* Symbol ":BOX" */
#define EXTERNED_K_BOX
#endif

#ifndef EXTERNED_K_TRIANGLE
extern LVAL k_triangle;/* Symbol ":TRIANGLE" */
#define EXTERNED_K_TRIANGLE
#endif

#ifndef EXTERNED_K_QUADRATIC
extern LVAL k_quadratic;/* Symbol ":QUADRATIC" */
#define EXTERNED_K_QUADRATIC
#endif

#ifndef EXTERNED_K_MITCHELL
extern LVAL k_mitchell;/* Symbol ":MITCHELL" */
#define EXTERNED_K_MITCHELL
#endif

#ifndef EXTERNED_K_ZERO_REST
extern LVAL k_zero_rest;/* Symbol ":ZERO-REST" */
#define EXTERNED_K_ZERO_REST
#endif

#ifndef EXTERNED_K_PLANE
extern LVAL k_plane;/* Symbol ":PLANE" */
#define EXTERNED_K_PLANE
#endif

#ifndef EXTERNED_K_PLANE
extern LVAL k_plane;/* Symbol ":PLANE" */
#define EXTERNED_K_PLANE
#endif

#ifndef EXTERNED_K_DEPTH_IN_BITS
extern LVAL k_depth_in_bits;/* Symbol ":DEPTH-IN-BITS" */
#define EXTERNED_K_DEPTH_IN_BITS
#endif

#ifndef EXTERNED_K_ENDIAN
extern LVAL k_endian;/* Symbol ":ENDIAN" */
#define EXTERNED_K_ENDIAN
#endif

#ifndef EXTERNED_K_BIG
extern LVAL k_big;/* Symbol ":BIG" */
#define EXTERNED_K_BIG
#endif

#ifndef EXTERNED_K_LITTLE
extern LVAL k_little;/* Symbol ":LITTLE" */
#define EXTERNED_K_LITTLE
#endif

#ifndef EXTERNED_K_ENDIAN
extern LVAL k_endian;/* Symbol ":ENDIAN" */
#define EXTERNED_K_ENDIAN
#endif

#ifndef EXTERNED_K_PADDING
extern LVAL k_padding;/* Symbol ":PADDING" */
#define EXTERNED_K_PADDING
#endif

#ifndef EXTERNED_K_FORMAT
extern LVAL k_format;/* Symbol ":FORMAT" */
#define EXTERNED_K_FORMAT
#endif

#ifndef EXTERNED_K_AVS_UNIFORM_FIELD
extern LVAL k_avs_uniform_field;/* Symbol ":AVS-UNIFORM-FIELD" */
#define EXTERNED_K_AVS_UNIFORM_FIELD
#endif

#ifndef EXTERNED_K_MINX
extern LVAL k_minx;/* Symbol ":MIN-X" */
#define EXTERNED_K_MINX
#endif

#ifndef EXTERNED_K_MAXX
extern LVAL k_maxx;/* Symbol ":MAX-X" */
#define EXTERNED_K_MAXX
#endif

#ifndef EXTERNED_K_MINY
extern LVAL k_miny;/* Symbol ":MIN-Y" */
#define EXTERNED_K_MINY
#endif

#ifndef EXTERNED_K_MAXY
extern LVAL k_maxy;/* Symbol ":MAX-Y" */
#define EXTERNED_K_MAXY
#endif

#ifndef EXTERNED_K_MINZ
extern LVAL k_minz;/* Symbol ":MIN-Z" */
#define EXTERNED_K_MINZ
#endif

#ifndef EXTERNED_K_MAXZ
extern LVAL k_maxz;/* Symbol ":MAX-Z" */
#define EXTERNED_K_MAXZ
#endif


#endif


#ifdef MODULE_XLFTAB_C_FUNTAB_S

DEFINE_SUBR( "XMRI-GET-U-CHAR",			xmri06_Get_U_Char_Fn	)
DEFINE_SUBR( "XMRI-GET-CHAR",			xmri08_Get_Char_Fn	)

DEFINE_SUBR( "XMRI-GET-U-SHORT",		xmri10_Get_U_Short_Fn	)
DEFINE_SUBR( "XMRI-GET-SHORT",			xmri12_Get_Short_Fn	)

DEFINE_SUBR( "XMRI-GET-U-INT",			xmri14_Get_U_Int_Fn	)
DEFINE_SUBR( "XMRI-GET-INT",			xmri16_Get_Int_Fn	)

DEFINE_SUBR( "XMRI-GET-FLOAT",			xmri18_Get_Float_Fn	)
DEFINE_SUBR( "XMRI-GET-DOUBLE",			xmri20_Get_Double_Fn	)

DEFINE_SUBR( "XMRI-U-CHAR",			xmri46_U_Char_Fn	)
DEFINE_SUBR( "XMRI-CHAR",			xmri48_Char_Fn		)

DEFINE_SUBR( "XMRI-U-SHORT",			xmri50_U_Short_Fn	)
DEFINE_SUBR( "XMRI-SHORT",			xmri52_Short_Fn		)

DEFINE_SUBR( "XMRI-U-INT",			xmri54_U_Int_Fn		)
DEFINE_SUBR( "XMRI-INT",			xmri56_Int_Fn		)

DEFINE_SUBR( "XMRI-FLOAT",			xmri58_Float_Fn		)
DEFINE_SUBR( "XMRI-DOUBLE",			xmri60_Double_Fn	)

DEFINE_SUBR( "XMRI-STRING",			xmri62_String_Fn	)

DEFINE_SUBR( "XMRI-READ-FILE-HEADER",		xmri80_Read_File_Header_Fn)
DEFINE_SUBR( "XMRI-READ-RGB-IMAGE",		xmri90_Read_RGB_Image_Fn)
DEFINE_SUBR( "XMRI-READ-VOXEL-SLICE",		xmria0_Read_Voxel_Slice_Fn)
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS

#ifndef DEFINED_K_GE_U_CHAR
LVAL k_ge_u_char;/* Symbol ":GE-U-CHAR" */
#define DEFINED_K_GE_U_CHAR
#endif

#ifndef DEFINED_K_GE_CHAR
LVAL k_ge_char;/* Symbol ":GE-CHAR" */
#define DEFINED_K_GE_CHAR
#endif

#ifndef DEFINED_K_GE_U_SHORT
LVAL k_ge_u_short;/* Symbol ":GE-U-SHORT" */
#define DEFINED_K_GE_U_SHORT
#endif

#ifndef DEFINED_K_GE_SHORT
LVAL k_ge_short;/* Symbol ":GE-SHORT" */
#define DEFINED_K_GE_SHORT
#endif

#ifndef DEFINED_K_GE_U_INT
LVAL k_ge_u_int;/* Symbol ":GE-U-INT" */
#define DEFINED_K_GE_U_INT
#endif

#ifndef DEFINED_K_GE_INT
LVAL k_ge_int;/* Symbol ":GE-INT" */
#define DEFINED_K_GE_INT
#endif

#ifndef DEFINED_K_GE_FLOAT
LVAL k_ge_float;/* Symbol ":GE-FLOAT" */
#define DEFINED_K_GE_FLOAT
#endif

#ifndef DEFINED_K_GE_DOUBLE
LVAL k_ge_double;/* Symbol ":GE-DOUBLE" */
#define DEFINED_K_GE_DOUBLE
#endif

#ifndef DEFINED_K_MIN
LVAL k_min;/* Symbol ":MIN" */
#define DEFINED_K_MIN
#endif

#ifndef DEFINED_K_MAX
LVAL k_max;/* Symbol ":MAX" */
#define DEFINED_K_MAX
#endif

#ifndef DEFINED_K_MIN_LEFT
LVAL k_min_left;/* Symbol ":MIN-LEFT" */
#define DEFINED_K_MIN_LEFT
#endif

#ifndef DEFINED_K_MAX_LEFT
LVAL k_max_left;/* Symbol ":MAX-LEFT" */
#define DEFINED_K_MAX_LEFT
#endif

#ifndef DEFINED_K_MIN_ANTERIOR
LVAL k_min_anterior;/* Symbol ":MIN-ANTERIOR" */
#define DEFINED_K_MIN_ANTERIOR
#endif

#ifndef DEFINED_K_MAX_ANTERIOR
LVAL k_max_anterior;/* Symbol ":MAX-ANTERIOR" */
#define DEFINED_K_MAX_ANTERIOR
#endif

#ifndef DEFINED_K_MIN_SUPERIOR
LVAL k_min_superior;/* Symbol ":MIN-SUPERIOR" */
#define DEFINED_K_MIN_SUPERIOR
#endif

#ifndef DEFINED_K_MAX_SUPERIOR
LVAL k_max_superior;/* Symbol ":MAX-SUPERIOR" */
#define DEFINED_K_MAX_SUPERIOR
#endif

#ifndef DEFINED_K_INTENSITY
LVAL k_intensity;/* Symbol ":INTENSITY" */
#define DEFINED_K_INTENSITY
#endif

#ifndef DEFINED_K_RESULT_IN
LVAL k_result_in;/* Symbol ":RESULT-IN" */
#define DEFINED_K_RESULT_IN
#endif

#ifndef DEFINED_K_AXIS
LVAL k_axis;/* Symbol ":AXIS" */
#define DEFINED_K_AXIS
#endif

#ifndef DEFINED_K_FILENAME
LVAL k_filename;/* Symbol ":FILENAME" */
#define DEFINED_K_FILENAME
#endif

#ifndef DEFINED_K_SLICE
LVAL k_slice;/* Symbol ":SLICE" */
#define DEFINED_K_SLICE
#endif

#ifndef DEFINED_K_SUBSAMPLE_BY
LVAL k_subsample_by;/* Symbol ":SUBSAMPLE-BY" */
#define DEFINED_K_SUBSAMPLE_BY
#endif

#ifndef DEFINED_K_ZOOM_BY
LVAL k_zoom_by;		/* Symbol ":ZOOM-BY" */
#define DEFINED_K_ZOOM_BY
#endif

#ifndef DEFINED_K_VOXELS
LVAL k_voxels;		/* Symbol ":VOXELS" */
#define DEFINED_K_VOXELS
#endif

#ifndef DEFINED_K_BIN_SIZE
LVAL k_bin_size;	/* Symbol ":BIN-SIZE" */
#define DEFINED_K_BIN_SIZE
#endif

#ifndef DEFINED_K_RENDERING_RELATION
LVAL k_rendering_relation;	/* Symbol ":RENDERING-RELATION" */
#define DEFINED_K_RENDERING_RELATION
#endif

#ifndef DEFINED_K_DIFFUSE_RED
LVAL k_diffuse_red;	/* Symbol ":DIFFUSE-RED" */
#define DEFINED_K_DIFFUSE_RED
#endif

#ifndef DEFINED_K_DIFFUSE_GREEN
LVAL k_diffuse_green;	/* Symbol ":DIFFUSE-GREEN" */
#define DEFINED_K_DIFFUSE_GREEN
#endif

#ifndef DEFINED_K_DIFFUSE_BLUE
LVAL k_diffuse_blue;	/* Symbol ":DIFFUSE-BLUE" */
#define DEFINED_K_DIFFUSE_BLUE
#endif

#ifndef DEFINED_K_ALPHA
LVAL k_alpha;	/* Symbol ":ALPHA" */
#define DEFINED_K_ALPHA
#endif

#ifndef DEFINED_K_RANGE
LVAL k_range;	/* Symbol ":RANGE" */
#define DEFINED_K_RANGE
#endif

#ifndef DEFINED_K_DST_MIN
LVAL k_dst_min;	/* Symbol ":DST-MIN" */
#define DEFINED_K_DST_MIN
#endif

#ifndef DEFINED_K_DST_MAX
LVAL k_dst_max;	/* Symbol ":DST-MAX" */
#define DEFINED_K_DST_MAX
#endif

#ifndef DEFINED_K_SRC_MIN
LVAL k_src_min;	/* Symbol ":SRC-MIN" */
#define DEFINED_K_SRC_MIN
#endif

#ifndef DEFINED_K_SRC_MAX
LVAL k_src_max;	/* Symbol ":SRC-MAX" */
#define DEFINED_K_SRC_MAX
#endif

#ifndef DEFINED_K_DEPTH
LVAL k_depth;	/* Symbol ":DEPTH" */
#define DEFINED_K_DEPTH
#endif

#ifndef DEFINED_K_PIXELDEPTH
LVAL k_pixeldepth;	/* Symbol ":PIXEL-DEPTH" */
#define DEFINED_K_PIXELDEPTH
#endif

#ifndef DEFINED_K_FILE_OFFSET
LVAL k_file_offset;	/* Symbol ":FILE-OFFSET" */
#define DEFINED_K_FILE_OFFSET
#endif

#ifndef DEFINED_K_ROWS
LVAL k_rows;	/* Symbol ":ROWS" */
#define DEFINED_K_ROWS
#endif

#ifndef DEFINED_K_COLS
LVAL k_cols;	/* Symbol ":COLS" */
#define DEFINED_K_COLS
#endif

#ifndef DEFINED_K_DISTANCE
LVAL k_distance;/* Symbol ":DISTANCE" */
#define DEFINED_K_DISTANCE
#endif

#ifndef DEFINED_K_FILTER_SHAPE
LVAL k_filter_shape;/* Symbol ":FILTER-SHAPE" */
#define DEFINED_K_FILTER_SHAPE
#endif

#ifndef DEFINED_IMPULSE
LVAL k_impulse;   /* Keyword ":impulse" */
#define DEFINED_IMPULSE
#endif

#ifndef DEFINED_TRIANGLE
LVAL k_triangle;   /* Keyword ":triangle" */
#define DEFINED_IMPULSE
#endif

#ifndef DEFINED_BOX
LVAL k_box;   /* Keyword ":box" */
#define DEFINED_BOX
#endif

#ifndef DEFINED_QUADRATIC
LVAL k_quadratic;   /* Keyword ":quadratic" */
#define DEFINED_QUADRATIC
#endif

#ifndef DEFINED_MITCHELL
LVAL k_mitchell;   /* Keyword ":mitchell" */
#define DEFINED_MITCHELL
#endif

#ifndef DEFINED_K_ZERO_REST
LVAL k_zero_rest;/* Symbol ":ZERO-REST" */
#define DEFINED_K_ZERO_REST
#endif

#ifndef DEFINED_K_PLANE
LVAL k_plane;/* Symbol ":PLANE" */
#define DEFINED_K_PLANE
#endif

#ifndef DEFINED_K_DEPTH_IN_BITS
LVAL k_depth_in_bits;/* Symbol ":DEPTH-IN-BITS" */
#define DEFINED_K_DEPTH_IN_BITS
#endif

#ifndef DEFINED_K_ENDIAN
LVAL k_endian;/* Symbol ":ENDIAN" */
#define DEFINED_K_ENDIAN
#endif

#ifndef DEFINED_K_BIG
LVAL k_big;/* Symbol ":BIG" */
#define DEFINED_K_BIG
#endif

#ifndef DEFINED_K_LITTLE
LVAL k_little;/* Symbol ":LITTLE" */
#define DEFINED_K_LITTLE
#endif

#ifndef DEFINED_K_PADDING
LVAL k_padding;/* Symbol ":PADDING" */
#define DEFINED_K_PADDING
#endif

#ifndef DEFINED_K_FORMAT
LVAL k_format;/* Symbol ":FORMAT" */
#define DEFINED_K_FORMAT
#endif

#ifndef DEFINED_K_AVS_UNIFORM_FIELD
LVAL k_avs_uniform_field;/* Symbol ":AVS-UNIFORM-FIELD" */
#define DEFINED_K_AVS_UNIFORM_FIELD
#endif

#ifndef DEFINED_K_MINX
LVAL k_minx;/* Symbol ":MIN-X" */
#define DEFINED_K_MINX
#endif

#ifndef DEFINED_K_MAXX
LVAL k_maxx;/* Symbol ":MAX-X" */
#define DEFINED_K_MAXX
#endif

#ifndef DEFINED_K_MINY
LVAL k_miny;/* Symbol ":MIN-Y" */
#define DEFINED_K_MINY
#endif

#ifndef DEFINED_K_MAXY
LVAL k_maxy;/* Symbol ":MAX-Y" */
#define DEFINED_K_MAXY
#endif

#ifndef DEFINED_K_MINZ
LVAL k_minz;/* Symbol ":MIN-Z" */
#define DEFINED_K_MINZ
#endif

#ifndef DEFINED_K_MAXZ
LVAL k_maxz;/* Symbol ":MAX-Z" */
#define DEFINED_K_MAXZ
#endif

#endif


#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_K_GE_U_CHAR
    k_ge_u_char = xlenter(":GE-U-CHAR");
#define CREATED_K_GE_U_CHAR
#endif

#ifndef CREATED_K_GE_CHAR
    k_ge_char = xlenter(":GE-CHAR");
#define CREATED_K_GE_CHAR
#endif

#ifndef CREATED_K_GE_U_SHORT
    k_ge_u_short = xlenter(":GE-U-SHORT");
#define CREATED_K_GE_U_SHORT
#endif

#ifndef CREATED_K_GE_SHORT
    k_ge_short = xlenter(":GE-SHORT");
#define CREATED_K_GE_SHORT
#endif

#ifndef CREATED_K_GE_U_INT
    k_ge_u_int = xlenter(":GE-U-INT");
#define CREATED_K_GE_U_INT
#endif

#ifndef CREATED_K_GE_INT
    k_ge_int= xlenter(":GE-INT");
#define CREATED_K_GE_INT
#endif

#ifndef CREATED_K_GE_FLOAT
    k_ge_float= xlenter(":GE-FLOAT");
#define CREATED_K_GE_FLOAT
#endif

#ifndef CREATED_K_GE_DOUBLE
    k_ge_double= xlenter(":GE-DOUBLE");
#define CREATED_K_GE_DOUBLE
#endif

#ifndef CREATED_K_MIN
    k_min= xlenter(":MIN");
#define CREATED_K_MIN
#endif

#ifndef CREATED_K_MAX
    k_max= xlenter(":MAX");
#define CREATED_K_MAX
#endif

#ifndef CREATED_K_MIN_LEFT
    k_min_left= xlenter(":MIN-LEFT");
#define CREATED_K_MIN_LEFT
#endif

#ifndef CREATED_K_MAX_LEFT
    k_max_left= xlenter(":MAX-LEFT");
#define CREATED_K_MAX_LEFT
#endif

#ifndef CREATED_K_MIN_ANTERIOR
    k_min_anterior= xlenter(":MIN-ANTERIOR");
#define CREATED_K_MIN_ANTERIOR
#endif

#ifndef CREATED_K_MAX_ANTERIOR
    k_max_anterior= xlenter(":MAX-ANTERIOR");
#define CREATED_K_MAX_ANTERIOR
#endif

#ifndef CREATED_K_MIN_SUPERIOR
    k_min_superior= xlenter(":MIN-SUPERIOR");
#define CREATED_K_MIN_SUPERIOR
#endif

#ifndef CREATED_K_MAX_SUPERIOR
    k_max_superior= xlenter(":MAX-SUPERIOR");
#define CREATED_K_MAX_SUPERIOR
#endif

#ifndef CREATED_K_INTENSITY
    k_intensity= xlenter(":INTENSITY");
#define CREATED_K_INTENSITY
#endif

#ifndef CREATED_K_RESULT_IN
    k_result_in= xlenter(":RESULT-IN");
#define CREATED_K_RESULT_IN
#endif

#ifndef CREATED_K_AXIS
    k_axis= xlenter(":AXIS");
#define CREATED_K_AXIS
#endif

#ifndef CREATED_K_FILENAME
    k_filename= xlenter(":FILENAME");
#define CREATED_K_FILENAME
#endif

#ifndef CREATED_K_SLICE
    k_slice= xlenter(":SLICE");
#define CREATED_K_SLICE
#endif

#ifndef CREATED_K_SUBSAMPLE_BY
    k_subsample_by= xlenter(":SUBSAMPLE-BY");
#define CREATED_K_SUBSAMPLE_BY
#endif

#ifndef CREATED_K_ZOOM_BY
    k_zoom_by= xlenter(":ZOOM-BY");
#define CREATED_K_ZOOM_BY
#endif

#ifndef CREATED_K_VOXELS
    k_voxels= xlenter(":VOXELS");
#define CREATED_K_VOXELS
#endif

#ifndef CREATED_K_BIN_SIZE
    k_bin_size= xlenter(":BIN-SIZE");
#define CREATED_K_BIN_SIZE
#endif

#ifndef CREATED_K_RENDERING_RELATION
    k_rendering_relation= xlenter(":RENDERING-RELATION");
#define CREATED_K_RENDERING_RELATION
#endif

#ifndef CREATED_K_DIFFUSE_RED
    k_diffuse_red= xlenter(":DIFFUSE-RED");
#define CREATED_K_DIFFUSE_RED
#endif

#ifndef CREATED_K_DIFFUSE_GREEN
    k_diffuse_green= xlenter(":DIFFUSE-GREEN");
#define CREATED_K_DIFFUSE_GREEN
#endif

#ifndef CREATED_K_DIFFUSE_BLUE
    k_diffuse_blue= xlenter(":DIFFUSE-BLUE");
#define CREATED_K_DIFFUSE_BLUE
#endif

#ifndef CREATED_K_ALPHA
    k_alpha= xlenter(":ALPHA");
#define CREATED_K_ALPHA
#endif

#ifndef CREATED_K_RANGE
    k_range= xlenter(":RANGE");
#define CREATED_K_RANGE
#endif

#ifndef CREATED_K_SRC_MIN
    k_src_min= xlenter(":SRC-MIN");
#define CREATED_K_SRC_MIN
#endif

#ifndef CREATED_K_SRC_MAX
    k_src_max= xlenter(":SRC-MAX");
#define CREATED_K_SRC_MAX
#endif

#ifndef CREATED_K_DST_MIN
    k_dst_min= xlenter(":DST-MIN");
#define CREATED_K_DST_MIN
#endif

#ifndef CREATED_K_DST_MAX
    k_dst_max= xlenter(":DST-MAX");
#define CREATED_K_DST_MAX
#endif

#ifndef CREATED_K_DEPTH
    k_depth= xlenter(":DEPTH");
#define CREATED_K_DEPTH
#endif

#ifndef CREATED_K_PIXELDEPTH
    k_pixeldepth= xlenter(":PIXEL-DEPTH");
#define CREATED_K_PIXELDEPTH
#endif

#ifndef CREATED_K_FILE_OFFSET
    k_file_offset= xlenter(":FILE-OFFSET");
#define CREATED_K_FILE_OFFSET
#endif

#ifndef CREATED_K_ROWS
    k_rows= xlenter(":ROWS");
#define CREATED_K_ROWS
#endif

#ifndef CREATED_K_COLS
    k_cols= xlenter(":COLS");
#define CREATED_K_COLS
#endif

#ifndef CREATED_K_DISTANCE
    k_distance= xlenter(":DISTANCE");
#define CREATED_K_DISTANCE
#endif

#ifndef CREATED_K_FILTER_SHAPE
    k_filter_shape= xlenter(":FILTER-SHAPE");
#define CREATED_K_FILTER_SHAPE
#endif

#ifndef CREATED_IMPULSE
    k_impulse = xlenter(":IMPULSE");
#define CREATED_IMPULSE
#endif

#ifndef CREATED_TRIANGLE
    k_triangle = xlenter(":TRIANGLE");
#define CREATED_TRIANGLE
#endif

#ifndef CREATED_BOX
    k_box = xlenter(":BOX");
#define CREATED_BOX
#endif

#ifndef CREATED_QUADRATIC
    k_quadratic = xlenter(":QUADRATIC");
#define CREATED_QUADRATIC
#endif

#ifndef CREATED_MITCHELL
    k_mitchell = xlenter(":MITCHELL");
#define CREATED_MITCHELL
#endif

#ifndef CREATED_K_ZERO_REST
    k_zero_rest= xlenter(":ZERO-REST");
#define CREATED_K_ZERO_REST
#endif

#ifndef CREATED_K_PLANE
    k_plane= xlenter(":PLANE");
#define CREATED_K_PLANE
#endif

#ifndef CREATED_K_DEPTH_IN_BITS
    k_depth_in_bits = xlenter(":DEPTH-IN-BITS");
#define CREATED_K_DEPTH_IN_BITS
#endif

#ifndef CREATED_K_ENDIAN
    k_endian = xlenter(":ENDIAN");
#define CREATED_K_ENDIAN
#endif

#ifndef CREATED_K_BIG
    k_big = xlenter(":BIG");
#define CREATED_K_BIG
#endif

#ifndef CREATED_K_LITTLE
    k_little = xlenter(":LITTLE");
#define CREATED_K_LITTLE
#endif

#ifndef CREATED_K_PADDING
    k_padding = xlenter(":PADDING");
#define CREATED_K_PADDING
#endif

#ifndef CREATED_K_FORMAT
    k_format = xlenter(":FORMAT");
#define CREATED_K_FORMAT
#endif

#ifndef CREATED_K_AVS_UNIFORM_FIELD
    k_avs_uniform_field = xlenter(":AVS-UNIFORM-FIELD");
#define CREATED_K_AVS_UNIFORM_FIELD
#endif

#ifndef CREATED_K_MINX
    k_minx = xlenter(":MIN-X");
#define CREATED_K_MINX
#endif

#ifndef CREATED_K_MAXX
    k_maxx = xlenter(":MAX-X");
#define CREATED_K_MAXX
#endif

#ifndef CREATED_K_MINY
    k_miny = xlenter(":MIN-Y");
#define CREATED_K_MINY
#endif

#ifndef CREATED_K_MAXY
    k_maxy = xlenter(":MAX-Y");
#define CREATED_K_MAXY
#endif

#ifndef CREATED_K_MINZ
    k_minz = xlenter(":MIN-Z");
#define CREATED_K_MINZ
#endif

#ifndef CREATED_K_MAXZ
    k_maxz = xlenter(":MAX-Z");
#define CREATED_K_MAXZ
#endif

#endif
