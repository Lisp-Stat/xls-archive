/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xmth.h
* Description:  Hybrid-class header for math support.
* Author:       Jeff Prothero
* Created:      97Feb12
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1998, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifdef MODULE_XLDMEM_H_GLOBALS

extern LVAL xmth06_Ludcmp_Fn();
extern LVAL xmth20_Lubksb_Fn();
extern LVAL xmth39_Mult_Fn();

#ifndef EXTERNED_K_MATRIX
extern LVAL k_matrix;/* Symbol ":MATRIX" */
#define EXTERNED_K_MATRIX
#endif

#ifndef EXTERNED_K_B
extern LVAL k_b;/* Symbol ":B" */
#define EXTERNED_K_B
#endif

#ifndef EXTERNED_K_LEFT
extern LVAL k_left;/* Symbol ":LEFT" */
#define EXTERNED_K_LEFT
#endif

#ifndef EXTERNED_K_RIGHT
extern LVAL k_right;/* Symbol ":RIGHT" */
#define EXTERNED_K_RIGHT
#endif

#ifndef EXTERNED_K_TRANSPOSE_RIGHT
extern LVAL k_transpose_right;/* Symbol ":TRANSPOSE-RIGHT" */
#define EXTERNED_K_TRANSPOSE_RIGHT
#endif

#ifndef EXTERNED_K_TRANSPOSE_LEFT
extern LVAL k_transpose_left;/* Symbol ":TRANSPOSE-LEFT" */
#define EXTERNED_K_TRANSPOSE_LEFT
#endif

#endif


#ifdef MODULE_XLFTAB_C_FUNTAB_S

DEFINE_SUBR( "XMTH-LUDCMP",			xmth06_Ludcmp_Fn	)
DEFINE_SUBR( "XMTH-LUBKSB",			xmth20_Lubksb_Fn	)
DEFINE_SUBR( "XMTH-MULT",			xmth39_Mult_Fn		)

#endif


#ifdef MODULE_XLOBJ_C_GLOBALS

#ifndef DEFINED_K_MATRIX
LVAL k_matrix;/* Symbol ":MATRIX" */
#define DEFINED_K_MATRIX
#endif

#ifndef DEFINED_K_B
LVAL k_b;/* Symbol ":B" */
#define DEFINED_K_B
#endif

#ifndef DEFINED_K_LEFT
LVAL k_left;/* Symbol ":LEFT" */
#define DEFINED_K_LEFT
#endif

#ifndef DEFINED_K_RIGHT
LVAL k_right;/* Symbol ":RIGHT" */
#define DEFINED_K_RIGHT
#endif

#ifndef DEFINED_K_TRANSPOSE_RIGHT
LVAL k_transpose_right;/* Symbol ":TRANSPOSE-RIGHT" */
#define DEFINED_K_TRANSPOSE_RIGHT
#endif

#ifndef DEFINED_K_TRANSPOSE_LEFT
LVAL k_transpose_left;/* Symbol ":TRANSPOSE-LEFT" */
#define DEFINED_K_TRANSPOSE_LEFT
#endif

#endif


#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_K_MATRIX
    k_matrix = xlenter(":MATRIX");
#define CREATED_K_MATRIX
#endif

#ifndef CREATED_K_B
    k_b = xlenter(":B");
#define CREATED_K_B
#endif

#ifndef CREATED_K_LEFT
    k_left = xlenter(":LEFT");
#define CREATED_K_LEFT
#endif

#ifndef CREATED_K_RIGHT
    k_right = xlenter(":RIGHT");
#define CREATED_K_RIGHT
#endif

#ifndef CREATED_K_TRANSPOSE_RIGHT
    k_transpose_right = xlenter(":TRANSPOSE-RIGHT");
#define CREATED_K_TRANSPOSE_RIGHT
#endif

#ifndef CREATED_K_TRANSPOSE_LEFT
    k_transpose_left = xlenter(":TRANSPOSE-LEFT");
#define CREATED_K_TRANSPOSE_LEFT
#endif

#endif
