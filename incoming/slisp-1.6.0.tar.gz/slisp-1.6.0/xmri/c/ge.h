/* {{{  ge.h -- ge.c exports					        */
/************************************************************************/

#ifndef INCLUDED_GE_H
#define INCLUDED_GE_H

/* }}} */

/* {{{  typedefs						        */

typedef struct VARTYP {
	unsigned long	length;	/* length of the data */
	char *	data;	/* pointer to the data */
}  VARTYPE;

/* enum for the various sorts of fields found  */
/* found in header files.  Some fields are     */
/* actually arrays of one of these base types: */
typedef enum {
    GE_U_CHAR,	/* unsigned char  */
    GE_CHAR,	/* char           */
    GE_U_SHORT,	/* unsigned short */
    GE_SHORT,	/* short          */
    GE_U_INT,	/* unsigned int   */
    GE_INT,	/* int            */
    GE_FLOAT,	/* float	  */
    GE_DOUBLE,	/* double	  */
    GE_VARTYPE,	/* VARTYPE	  */
    GE_,	/* No type. For the IC* macros, which are values to */
		/* put in the _IH_img_compress field, not fields themselves */
    GE_SECTSIZE	/* sizeof: not a field, but total size of a given section. */
} Ge_Type;

/* Define actual types in header, since these may */
/* differ in length from the host types of the    */
/* same name:                                     */
typedef unsigned char   Ge_U_Char;
typedef          char   Ge_Char;
typedef unsigned short  Ge_U_Short;
typedef          short  Ge_Short;
typedef unsigned int    Ge_U_Int;
typedef          int    Ge_Int;
typedef          float  Ge_Float;
typedef          double Ge_Double;

/* Type holding information on one ge field: */
typedef struct {
    Ge_Type base_type;	/* Type   of basic unit  in field: int/char/float... */
    int     base_len;	/* Number of basic units in full field.		     */
    int     section;	/* Offset of section offset in file header.	     */
    int     offset;	/* Offset of field within section.		     */
    char*   name;	/* Name of field, from ge_raw.h macro.		     */
    char*   description;/* Descrion of field, from ge_raw.h macro comment.   */
} Ge_Field;

/* Functions to extract values from header: */
extern          int ge_Get_U_Char(  void*, int);
extern          int ge_Get_Char(    void*, int);
extern          int ge_Get_U_Short( void*, int);
extern          int ge_Get_Short(   void*, int);
extern unsigned int ge_Get_U_Int(   void*, int);
extern          int ge_Get_Int(     void*, int);
extern        float ge_Get_Float(   void*, int);
extern       double ge_Get_Double(  void*, int);

extern         void ge_Get_Shorts(  void*, void*, int, int );

extern          int ge_U_Char( void*, Ge_Field* );
extern          int ge_Char(   void*, Ge_Field* );
extern          int ge_U_Short(void*, Ge_Field* );
extern          int ge_Short(  void*, Ge_Field* );
extern unsigned int ge_U_Int(  void*, Ge_Field* );
extern          int ge_Int(    void*, Ge_Field* );
extern        float ge_Float(  void*, Ge_Field* );
extern       double ge_Double( void*, Ge_Field* );
extern          int ge_String( char*,int, void*, Ge_Field* );

extern         void ge_Startup( void );
extern	       void*ge_Read_File_Header(FILE*);

/* Look up offset of section within file: */
extern int ge_Section_Offset( int section, void* header );

/* Format contents of a field: */
extern int ge_Sprint(char*,int,void*,Ge_Field*,int,int);

/* }}} */
/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
#endif	/* INCLUDED_GE_H */
/* }}} */
