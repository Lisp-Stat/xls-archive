/* {{{ xgtm.h -- Gnuplotlib TerMinal library.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      90Dec19
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xgtm;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xgtm00_Is_New();
extern LVAL xgtm16_Copy();
extern LVAL xgtm03_Show();
extern LVAL xgtm04_List_Avail_Terminals();
extern LVAL xgtm09_Change_File();
extern LVAL xgtm10_Change_File();
extern LVAL xgtm12_Change_Terminal();
extern LVAL xgtm13_Test_Terminal();
extern LVAL xgtm18_List_Avail_Terminals();
extern LVAL xgtm19_Graphics_Mode_Msg();
extern LVAL xgtm20_Graphics_Mode_Fn();
extern LVAL xgtm22_Text_Mode_Msg();
extern LVAL xgtm23_Text_Mode_Fn();
extern LVAL xgtm25_2D_Point_Msg();
extern LVAL xgtm26_2D_Point_Fn();
extern LVAL xgtm28_2D_Arrow_Msg();
extern LVAL xgtm29_2D_Arrow_Fn();
extern LVAL xgtm31_2D_Move_Msg();
extern LVAL xgtm32_2D_Move_Fn();
extern LVAL xgtm34_2D_Draw_Msg();
extern LVAL xgtm35_2D_Draw_Fn();
extern LVAL xgtm37_2D_Line_Type_Msg();
extern LVAL xgtm38_2D_Line_Type_Fn();
extern LVAL xgtm40_2D_X_Max_Msg();
extern LVAL xgtm41_2D_X_Max_Fn();
extern LVAL xgtm43_2D_Y_Max_Msg();
extern LVAL xgtm44_2D_Y_Max_Fn();
extern LVAL xgtm46_2D_Text_Angle_Msg();
extern LVAL xgtm47_2D_Text_Angle_Fn();
extern LVAL xgtm49_2D_Justify_Text_Msg();
extern LVAL xgtm50_2D_Justify_Text_Fn();
extern LVAL xgtm52_2D_Put_Text_Msg();
extern LVAL xgtm53_2D_Put_Text_Fn();
extern LVAL xgtm55_2D_V_Char_Msg();
extern LVAL xgtm56_2D_V_Char_Fn();
extern LVAL xgtm58_2D_H_Char_Msg();
extern LVAL xgtm59_2D_H_Char_Fn();
extern LVAL xgtm61_2D_V_Tic_Msg();
extern LVAL xgtm62_2D_V_Tic_Fn();
extern LVAL xgtm64_2D_H_Tic_Msg();
extern LVAL xgtm65_2D_H_Tic_Fn();
extern LVAL xgtm67_Get_Color_Msg();
extern LVAL xgtm68_Get_Color_Fn();
extern LVAL xgtm72_Set_Color_Msg();
extern LVAL xgtm73_Set_Color_Fn();
extern LVAL xgtm75_3D_Point_Msg();
extern LVAL xgtm76_3D_Point_Fn();
extern LVAL xgtm78_3D_Move_Msg();
extern LVAL xgtm79_3D_Move_Fn();
extern LVAL xgtm81_3D_Draw_Msg();
extern LVAL xgtm82_3D_Draw_Fn();
extern LVAL xgtm84_3D_Overlay_Draw_Msg();
extern LVAL xgtm85_3D_Overlay_Draw_Fn();
extern LVAL xgtm87_3D_Overlay_Erase_Msg();
extern LVAL xgtm88_3D_Overlay_Erase_Fn();
extern LVAL xgtm90_3D_Flat_Triangle_Msg();
extern LVAL xgtm91_3D_Flat_Triangle_Fn();
extern LVAL xgtm93_3D_Gouraud_Triangle_Msg();
extern LVAL xgtm94_3D_Gouraud_Triangle_Fn();
extern LVAL xgtm96_3D_Swap_Triangle_Msg();
extern LVAL xgtm97_3D_Swap_Triangle_Fn();
extern LVAL xgtm99_Get_Zbuffering_Is_On_Msg();
extern LVAL xgtmA0_Get_Zbuffering_Is_On_Fn();
extern LVAL xgtmA2_Set_Zbuffering_Is_On_Msg();
extern LVAL xgtmA3_Set_Zbuffering_Is_On_Fn();
extern LVAL xgtmA5_Get_Double_Buffering_Is_On_Msg();
extern LVAL xgtmA6_Get_Double_Buffering_Is_On_Fn();
extern LVAL xgtmA8_Set_Double_Buffering_Is_On_Msg();
extern LVAL xgtmA9_Set_Double_Buffering_Is_On_Fn();
extern LVAL xgtmB1_Get_Depthcueing_Is_On_Msg();
extern LVAL xgtmB2_Get_Depthcueing_Is_On_Fn();
extern LVAL xgtmB4_Set_Depthcueing_Is_On_Msg();
extern LVAL xgtmB5_Set_Depthcueing_Is_On_Fn();
extern LVAL xgtmB7_Swap_Buffers_Msg();
extern LVAL xgtmB8_Swap_Buffers_Fn();
extern LVAL xgtmC0_Raster_Support_Msg();
extern LVAL xgtmC1_Raster_Support_Fn();
extern LVAL xgtmC3_Clear_Viewport_Msg();
extern LVAL xgtmC4_Clear_Viewport_Fn();
extern LVAL xgtmE2_Get_Viewport_Msg();
extern LVAL xgtmE3_Get_Viewport_Fn();
extern LVAL xgtmE7_Set_Viewport_Msg();
extern LVAL xgtmE8_Set_Viewport_Fn();
extern LVAL xgtmF2_Mouse_Position_Msg();
extern LVAL xgtmF3_Mouse_Position_Fn();
extern LVAL xgtmF6_Get_Window_Msg();
extern LVAL xgtmF7_Get_Window_Fn();
extern LVAL xgtmFa_Set_Window_Msg();
extern LVAL xgtmFb_Set_Window_Fn();
extern LVAL xgtmG2_Blocking_Queue_Read_Msg();
extern LVAL xgtmG3_Blocking_Queue_Read_Fn();
extern LVAL xgtmG6_Nonblocking_Queue_Read_Msg();
extern LVAL xgtmG7_Nonblocking_Queue_Read_Fn();
extern LVAL xgtmH1_Set_Blanktime_Msg();
extern LVAL xgtmH2_Set_Blanktime_Fn();
extern LVAL xgtmH6_Sleep_Msg();
extern LVAL xgtmH7_Sleep_Fn();
extern LVAL xgtmI1_Finish_Msg();
extern LVAL xgtmI2_Finish_Fn();
extern LVAL xgtmI6_to_NTSC_video_Msg();
extern LVAL xgtmI7_to_NTSC_video_Fn();
extern LVAL xgtmJ1_to_normal_video_Msg();
extern LVAL xgtmJ2_to_normal_video_Fn();
extern LVAL xgtmJ6_Cursor_Move_Msg();
extern LVAL xgtmJ7_Cursor_Move_Fn();
extern LVAL xgtmK1_Ring_Bell_Msg();
extern LVAL xgtmK2_Ring_Bell_Fn();




#ifndef EXTERNED_REDRAW
extern LVAL k_redraw;/* Keyword ":redraw" */
#define EXTERNED_REDRAW
#endif

#ifndef EXTERNED_UPCLICK
extern LVAL k_upclick;/* Keyword ":upclick" */
#define EXTERNED_UPCLICK
#endif

#ifndef EXTERNED_DOWNCLICK
extern LVAL k_downclick;/* Keyword ":downclick" */
#define EXTERNED_DOWNCLICK
#endif

#ifndef EXTERNED_KEYBOARDCHAR
extern LVAL k_keyboardchar;/* Keyword ":keyboard-char" */
#define EXTERNED_KEYBOARDCHAR
#endif

#ifndef EXTERNED_OUTPUT_FILE
extern LVAL k_outfl;/* Keyword ":output-file" */
#define EXTERNED_OUTPUT_FILE
#endif

#ifndef EXTERNED_INITIAL_WINDOW_TYPE
extern LVAL k_iwtype;/* Keyword ":initial-window-type" */
#define EXTERNED_INITIAL_WINDOW_TYPE
#endif

#ifndef EXTERNED_SYMBOL_LEFT
extern LVAL s_left;/* Symbol 'LEFT */
#define EXTERNED_SYMBOL_LEFT
#endif

#ifndef EXTERNED_SYMBOL_CENTRE
extern LVAL s_centre;/* Symbol 'CENTRE */
#define EXTERNED_SYMBOL_CENTRE
#endif

#ifndef EXTERNED_SYMBOL_RIGHT
extern LVAL s_right;/* Symbol 'RIGHT */
#define EXTERNED_SYMBOL_RIGHT
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following with NULL names because are provided only as */
/* messages, not as xlisp functions.                      */
DEFINE_SUBR(	NULL,			xgtm00_Is_New			)
DEFINE_SUBR(	NULL,			xgtm16_Copy			)
DEFINE_SUBR(	NULL,			xgtm03_Show			)
DEFINE_SUBR(    NULL,			xgtm04_List_Avail_Terminals	)
DEFINE_SUBR(    NULL,			xgtm09_Change_File		)
DEFINE_SUBR("GT-CHANGE-FILE",		xgtm10_Change_File		)
DEFINE_SUBR("GT-CHANGE-TERMINAL",       xgtm12_Change_Terminal		)
DEFINE_SUBR("GT-TEST-TERMINAL",		xgtm13_Test_Terminal		)
DEFINE_SUBR("GT-AVAILABLE-TERMINALS",   xgtm18_List_Avail_Terminals	)
DEFINE_SUBR(	NULL,			xgtm19_Graphics_Mode_Msg	)
DEFINE_SUBR("GT-GRAPHICS-MODE",		xgtm20_Graphics_Mode_Fn		)
DEFINE_SUBR(	NULL,			xgtm22_Text_Mode_Msg		)
DEFINE_SUBR("GT-TEXT-MODE",		xgtm23_Text_Mode_Fn		)
DEFINE_SUBR(	NULL,			xgtm25_2D_Point_Msg		)
DEFINE_SUBR("GT-2D-POINT",		xgtm26_2D_Point_Fn		)
DEFINE_SUBR(	NULL,			xgtm28_2D_Arrow_Msg		)
DEFINE_SUBR("GT-2D-ARROW",		xgtm29_2D_Arrow_Fn		)
DEFINE_SUBR(	NULL,			xgtm31_2D_Move_Msg		)
DEFINE_SUBR("GT-2D-MOVE",		xgtm32_2D_Move_Fn		)
DEFINE_SUBR(	NULL,			xgtm34_2D_Draw_Msg		)
DEFINE_SUBR("GT-2D-DRAW",		xgtm35_2D_Draw_Fn		)
DEFINE_SUBR(	NULL,			xgtm37_2D_Line_Type_Msg		)
DEFINE_SUBR("GT-2D-LINE-TYPE",		xgtm38_2D_Line_Type_Fn		)
DEFINE_SUBR(	NULL,			xgtm40_2D_X_Max_Msg		)
DEFINE_SUBR("GT-2D-X-MAX",		xgtm41_2D_X_Max_Fn		)
DEFINE_SUBR(	NULL,			xgtm43_2D_Y_Max_Msg		)
DEFINE_SUBR("GT-2D-Y-MAX",		xgtm44_2D_Y_Max_Fn		)
DEFINE_SUBR(	NULL,			xgtm46_2D_Text_Angle_Msg	)
DEFINE_SUBR("GT-2D-TEXT-ANGLE",		xgtm47_2D_Text_Angle_Fn		)
DEFINE_SUBR(	NULL,			xgtm49_2D_Justify_Text_Msg	)
DEFINE_SUBR("GT-2D-JUSTIFY-TEXT",	xgtm50_2D_Justify_Text_Fn	)
DEFINE_SUBR(	NULL,			xgtm52_2D_Put_Text_Msg		)
DEFINE_SUBR("GT-2D-PUT-TEXT",		xgtm53_2D_Put_Text_Fn		)
DEFINE_SUBR(	NULL,			xgtm55_2D_V_Char_Msg		)
DEFINE_SUBR("GT-2D-V-CHAR",		xgtm56_2D_V_Char_Fn		)
DEFINE_SUBR(	NULL,			xgtm58_2D_H_Char_Msg		)
DEFINE_SUBR("GT-2D-H-CHAR",		xgtm59_2D_H_Char_Fn		)
DEFINE_SUBR(	NULL,			xgtm61_2D_V_Tic_Msg		)
DEFINE_SUBR("GT-2D-V-TIC",		xgtm62_2D_V_Tic_Fn		)
DEFINE_SUBR(	NULL,			xgtm64_2D_H_Tic_Msg		)
DEFINE_SUBR("GT-2D-H-TIC",		xgtm65_2D_H_Tic_Fn		)
DEFINE_SUBR(	NULL,			xgtm67_Get_Color_Msg		)
DEFINE_SUBR("GT-GET-COLOR",		xgtm68_Get_Color_Fn		)
DEFINE_SUBR(	NULL,			xgtm72_Set_Color_Msg		)
DEFINE_SUBR("GT-SET-COLOR",		xgtm73_Set_Color_Fn		)
DEFINE_SUBR(	NULL,			xgtm75_3D_Point_Msg		)
DEFINE_SUBR("GT-3D-POINT",		xgtm76_3D_Point_Fn		)
DEFINE_SUBR(	NULL,			xgtm78_3D_Move_Msg		)
DEFINE_SUBR("GT-3D-MOVE",		xgtm79_3D_Move_Fn		)
DEFINE_SUBR(	NULL,			xgtm81_3D_Draw_Msg		)
DEFINE_SUBR("GT-3D-DRAW",		xgtm82_3D_Draw_Fn		)
DEFINE_SUBR(	NULL,			xgtm84_3D_Overlay_Draw_Msg	)
DEFINE_SUBR("GT-3D-OVERLAY-DRAW",	xgtm85_3D_Overlay_Draw_Fn	)
DEFINE_SUBR(	NULL,			xgtm87_3D_Overlay_Erase_Msg	)
DEFINE_SUBR("GT-3D-OVERLAY-ERASE",	xgtm88_3D_Overlay_Erase_Fn	)
DEFINE_SUBR(	NULL,			xgtm90_3D_Flat_Triangle_Msg	)
DEFINE_SUBR("GT-3D-FLAT-TRIANGLE",	xgtm91_3D_Flat_Triangle_Fn	)
DEFINE_SUBR(	NULL,			xgtm93_3D_Gouraud_Triangle_Msg	)
DEFINE_SUBR("GT-3D-GOURAUD-TRIANGLE",	xgtm94_3D_Gouraud_Triangle_Fn	)
DEFINE_SUBR(	NULL,			xgtm96_3D_Swap_Triangle_Msg	)
DEFINE_SUBR("GT-3D-SWAP-TRIANGLE",	xgtm97_3D_Swap_Triangle_Fn	)
DEFINE_SUBR(	NULL,			xgtm99_Get_Zbuffering_Is_On_Msg	)
DEFINE_SUBR("GT-GET-ZBUFFERING-IS-ON",	xgtmA0_Get_Zbuffering_Is_On_Fn	)
DEFINE_SUBR(	NULL,			xgtmA2_Set_Zbuffering_Is_On_Msg	)
DEFINE_SUBR("GT-SET-ZBUFFERING-IS-ON",	xgtmA3_Set_Zbuffering_Is_On_Fn	)
DEFINE_SUBR(	NULL,			xgtmA5_Get_Double_Buffering_Is_On_Msg	)
DEFINE_SUBR("GT-GET-DOUBLE-BUFFERING-IS-ON",	xgtmA6_Get_Double_Buffering_Is_On_Fn	)
DEFINE_SUBR(	NULL,			xgtmA8_Set_Double_Buffering_Is_On_Msg	)
DEFINE_SUBR("GT-SET-DOUBLE-BUFFERING-IS-ON",	xgtmA9_Set_Double_Buffering_Is_On_Fn	)
DEFINE_SUBR(	NULL,			xgtmB1_Get_Depthcueing_Is_On_Msg	)
DEFINE_SUBR("GT-GET-DEPTHCUEING-IS-ON",	xgtmB2_Get_Depthcueing_Is_On_Fn	)
DEFINE_SUBR(	NULL,			xgtmB4_Set_Depthcueing_Is_On_Msg	)
DEFINE_SUBR("GT-SET-DEPTHCUEING-IS-ON",	xgtmB5_Set_Depthcueing_Is_On_Fn	)
DEFINE_SUBR(	NULL,			xgtmB7_Swap_Buffers_Msg		)
DEFINE_SUBR("GT-SWAP-BUFFERS",		xgtmB8_Swap_Buffers_Fn		)
DEFINE_SUBR(	NULL,			xgtmC0_Raster_Support_Msg	)
DEFINE_SUBR("GT-RASTER-SUPPORT",	xgtmC1_Raster_Support_Fn	)
DEFINE_SUBR(	NULL,			xgtmC3_Clear_Viewport_Msg	)
DEFINE_SUBR("GT-CLEAR-VIEWPORT",	xgtmC4_Clear_Viewport_Fn	)
DEFINE_SUBR(	NULL,			xgtmE2_Get_Viewport_Msg 	)
DEFINE_SUBR("GT-GET-VIEWPORT",	        xgtmE3_Get_Viewport_Fn  	)
DEFINE_SUBR(	NULL,			xgtmE7_Set_Viewport_Msg		)
DEFINE_SUBR("GT-SET-VIEWPORT",	        xgtmE8_Set_Viewport_Fn		)
DEFINE_SUBR(	NULL,			xgtmF2_Mouse_Position_Msg	)
DEFINE_SUBR("GT-MOUSE-POSITION",        xgtmF3_Mouse_Position_Fn	)
DEFINE_SUBR(	NULL,			xgtmF6_Get_Window_Msg	 	)
DEFINE_SUBR("GT-GET-WINDOW",	        xgtmF7_Get_Window_Fn  		)
DEFINE_SUBR(	NULL,			xgtmFa_Set_Window_Msg		)
DEFINE_SUBR("GT-SET-WINDOW",	        xgtmFb_Set_Window_Fn		)
DEFINE_SUBR(	NULL,			xgtmG2_Blocking_Queue_Read_Msg	)
DEFINE_SUBR("GT-BLOCKING-QUEUE-READ",   xgtmG3_Blocking_Queue_Read_Fn	)
DEFINE_SUBR(	NULL,			xgtmG6_Nonblocking_Queue_Read_Msg)
DEFINE_SUBR("GT-NONBLOCKING-QUEUE-READ",xgtmG7_Nonblocking_Queue_Read_Fn)

DEFINE_SUBR(    NULL,			xgtmH1_Set_Blanktime_Msg	)
DEFINE_SUBR("GT-SET-BLANKTIME",		xgtmH2_Set_Blanktime_Fn		)
DEFINE_SUBR(    NULL,			xgtmH6_Sleep_Msg		)
DEFINE_SUBR("GT-SLEEP",			xgtmH7_Sleep_Fn			)
DEFINE_SUBR(    NULL,			xgtmI1_Finish_Msg		)
DEFINE_SUBR("GT-FINISH",		xgtmI2_Finish_Fn		)
DEFINE_SUBR(    NULL,			xgtmI6_to_NTSC_video_Msg	)
DEFINE_SUBR("GT-TO-NTSC-VIDEO",		xgtmI7_to_NTSC_video_Fn		)
DEFINE_SUBR(    NULL,			xgtmJ1_to_normal_video_Msg	)
DEFINE_SUBR("GT-TO-NORMAL-VIDEO",	xgtmJ2_to_normal_video_Fn	)
DEFINE_SUBR(    NULL,			xgtmJ6_Cursor_Move_Msg		)
DEFINE_SUBR("GT-MOVE-CURSOR",		xgtmJ7_Cursor_Move_Fn		)
DEFINE_SUBR(    NULL,			xgtmK1_Ring_Bell_Msg		)
DEFINE_SUBR("GT-RING-BELL",		xgtmK2_Ring_Bell_Fn		)

#endif



#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#endif

#ifdef MODULE_XLINIT_C_XLINIT
    /* Initialize gterm.c: */
    gt_init_terminal();

    /* Complain if no default terminal defined: */
    if (!GTterm) {
        xoserror("You need to set environment variable GNUTERM.");
        gt_list_terms();
        exit(1);
    }
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xgtm;
LOCAL struct xgtm_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xgtm_table[] = {
    {	":ISNEW",		xgtm00_Is_New			},
    {	":COPY",		xgtm16_Copy			},
    {	":SHOW",		xgtm03_Show			},
    {	":AVAILABLE-TERMINALS",	xgtm04_List_Avail_Terminals	},
    {   ":CHANGE-FILE",		xgtm09_Change_File		},
    {   ":GRAPHICS-MODE",	xgtm19_Graphics_Mode_Msg	},
    {   ":TEXT-MODE",		xgtm22_Text_Mode_Msg		},
    {   ":2D-POINT",		xgtm25_2D_Point_Msg		},
    {   ":2D-ARROW",		xgtm28_2D_Arrow_Msg		},
    {   ":2D-MOVE",		xgtm31_2D_Move_Msg		},
    {   ":2D-DRAW",		xgtm34_2D_Draw_Msg		},
    {   ":2D-LINE-TYPE",	xgtm37_2D_Line_Type_Msg		},
    {   ":2D-X-MAX",		xgtm40_2D_X_Max_Msg		},
    {   ":2D-Y-MAX",		xgtm43_2D_Y_Max_Msg		},
    {   ":2D-TEXT-ANGLE",	xgtm46_2D_Text_Angle_Msg	},
    {   ":2D-JUSTIFY-TEXT",	xgtm49_2D_Justify_Text_Msg	},
    {   ":2D-PUT-TEXT",		xgtm52_2D_Put_Text_Msg		},
    {   ":2D-V-CHAR",		xgtm55_2D_V_Char_Msg		},
    {   ":2D-H-CHAR",		xgtm58_2D_H_Char_Msg		},
    {   ":2D-V-TIC",		xgtm61_2D_V_Tic_Msg		},
    {   ":2D-H-TIC",		xgtm64_2D_H_Tic_Msg		},
    {   ":GET-COLOR",		xgtm67_Get_Color_Msg		},
    {   ":SET-COLOR",		xgtm72_Set_Color_Msg		},
    {   ":3D-POINT",		xgtm75_3D_Point_Msg		},
    {   ":3D-MOVE",		xgtm78_3D_Move_Msg		},
    {   ":3D-DRAW",		xgtm81_3D_Draw_Msg		},
    {   ":3D-OVERLAY-DRAW",	xgtm84_3D_Overlay_Draw_Msg	},
    {   ":3D-OVERLAY-ERASE",	xgtm87_3D_Overlay_Erase_Msg	},
    {   ":3D-FLAT-TRIANGLE",	xgtm90_3D_Flat_Triangle_Msg	},
    {   ":3D-GOURAUD-TRIANGLE",	xgtm93_3D_Gouraud_Triangle_Msg	},
    {   ":3D-SWAP-TRIANGLE",	xgtm96_3D_Swap_Triangle_Msg	},
    {   ":GET-ZBUFFERING-IS-ON",xgtm99_Get_Zbuffering_Is_On_Msg	},
    {   ":SET-ZBUFFERING-IS-ON",xgtmA2_Set_Zbuffering_Is_On_Msg	},
    {   ":GET-DOUBLE-BUFFERING-IS-ON",xgtmA5_Get_Double_Buffering_Is_On_Msg	},
    {   ":SET-DOUBLE-BUFFERING-IS-ON",xgtmA8_Set_Double_Buffering_Is_On_Msg	},
    {   ":GET-DEPTHCUEING-IS-ON",xgtmB1_Get_Depthcueing_Is_On_Msg	},
    {   ":SET-DEPTHCUEING-IS-ON",xgtmB4_Set_Depthcueing_Is_On_Msg	},
    {   ":SWAP-BUFFERS",	xgtmB7_Swap_Buffers_Msg		},
    {   ":RASTER-SUPPORT",	xgtmC0_Raster_Support_Msg	},
    {   ":CLEAR-VIEWPORT",	xgtmC3_Clear_Viewport_Msg	},
    {   ":GET-VIEWPORT",	xgtmE2_Get_Viewport_Msg		},
    {   ":SET-VIEWPORT",	xgtmE7_Set_Viewport_Msg		},
    {   ":MOUSE-POSITION",	xgtmF2_Mouse_Position_Msg	},
    {   ":GET-WINDOW",		xgtmF6_Get_Window_Msg		},
    {   ":SET-WINDOW",		xgtmFa_Set_Window_Msg		},
    {   ":BLOCKING-QUEUE-READ",	xgtmG2_Blocking_Queue_Read_Msg	},
    {   ":NONBLOCKING-QUEUE-READ",xgtmG6_Nonblocking_Queue_Read_Msg},
    {   ":SET-BLANKTIME",	xgtmH1_Set_Blanktime_Msg	},
    {   ":SLEEP",		xgtmH6_Sleep_Msg		},
    {   ":FINISH",		xgtmI1_Finish_Msg		},
    {   ":TO-NTSC-VIDEO",	xgtmI6_to_NTSC_video_Msg	},
    {   ":TO-NORMAL-VIDEO",	xgtmJ1_to_normal_video_Msg	},
    {   ":MOVE-CURSOR",		xgtmJ6_Cursor_Move_Msg		},
    {   ":RING-BELL",		xgtmK1_Ring_Bell_Msg		},

    {	NULL,			NULL				}
};



#ifndef DEFINED_REDRAW
LVAL k_redraw;/* Keyword ":redraw" */
#define DEFINED_REDRAW
#endif

#ifndef DEFINED_UPCLICK
LVAL k_upclick;/* Keyword ":upclick" */
#define DEFINED_UPCLICK
#endif

#ifndef DEFINED_DOWNCLICK
LVAL k_downclick;/* Keyword ":downclick" */
#define DEFINED_DOWNCLICK
#endif

#ifndef DEFINED_KEYBOARDCHAR
LVAL k_keyboardchar;/* Keyword ":keyboard-char" */
#define DEFINED_KEYBOARDCHAR
#endif

#ifndef DEFINED_OUTPUT_FILE
LVAL k_outfl;/* Keyword ":output-file" */
#define DEFINED_OUTPUT_FILE
#endif

#ifndef DEFINED_INITIAL_WINDOW_TYPE
LVAL k_iwtype;/* Keyword ":initial-window-type" */
#define DEFINED_INITIAL_WINDOW_TYPE
#endif

#ifndef DEFINED_SYMBOL_LEFT
LVAL s_left;/* Symbol 'LEFT */
#define DEFINED_SYMBOL_LEFT
#endif

#ifndef DEFINED_SYMBOL_CENTRE
LVAL s_centre;/* Symbol 'CENTRE */
#define DEFINED_SYMBOL_CENTRE
#endif

#ifndef DEFINED_SYMBOL_RIGHT
LVAL s_right;/* Symbol 'RIGHT */
#define DEFINED_SYMBOL_RIGHT
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS
    lv_xgtm = getvalue(xlenter("CLASS-GPLOTLIB-TERMINAL"));

#ifndef CREATED_REDRAW
    k_redraw = xlenter(":REDRAW");
#define CREATED_REDRAW
#endif

#ifndef CREATED_UPCLICK
    k_upclick = xlenter(":UPCLICK");
#define CREATED_UPCLICK
#endif

#ifndef CREATED_DOWNCLICK
    k_downclick = xlenter(":DOWNCLICK");
#define CREATED_DOWNCLICK
#endif

#ifndef CREATED_KEYBOARDCHAR
    k_keyboardchar = xlenter(":KEYBOARD-CHAR");
#define CREATED_KEYBOARDCHAR
#endif

#ifndef CREATED_OUTPUT_FILE
    k_outfl = xlenter(":OUTPUT-FILE");
#define CREATED_OUTPUT_FILE
#endif

#ifndef CREATED_INITIAL_WINDOW_TYPE
    k_iwtype = xlenter(":INITIAL-WINDOW-TYPE");
#define CREATED_INITIAL_WINDOW_TYPE
#endif

#ifndef CREATED_SYMBOL_LEFT
    s_left = xlenter("LEFT");
#define CREATED_SYMBOL_LEFT
#endif

#ifndef CREATED_SYMBOL_CENTRE
    s_centre = xlenter("CENTRE");
#define CREATED_SYMBOL_CENTRE
#endif

#ifndef CREATED_SYMBOL_RIGHT
    s_right = xlenter("RIGHT");
#define CREATED_SYMBOL_RIGHT
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xgtm = xlclass("CLASS-GPLOTLIB-TERMINAL",0);
    setivar(lv_xgtm,SUPERCLASS,k_closed_gobject);
    xgbj56_Enter_Messages( lv_xgtm,  xgtm_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
