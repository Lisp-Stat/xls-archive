/* {{{ xgtm.c -- Hybrid-class code for gterm interface..		*/
/*******************************************************************************
*
* Author:       Jeff Prothero
* Created:      90Dec19
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

/* {{{ --- history ---							*/
/*									*/
/* 92Feb07 jsp: [non]blocking-queue-read.				*/
/* 92Jan20 jsp: get/set window.						*/
/* 90Dec19 jsp: Created.						*/

/* }}} */
/* {{{ --- quotables ---						*/
  
/************************************************************************/
/*    Experience shows that most programs crash first run, producing    */
/* no output.  Which is why it is said that:				*/
/*    Anything is possible in software. But nothing is probable. :) 	*/
/************************************************************************/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

#include "dist/gplotlib/gtplot.h"

struct xtrm_struct {
    struct gt_stat_struct   state;
};
typedef struct xtrm_struct   usRec;

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 

#define xgtmp(o) (getclass(o) == lv_xgtm)

extern LVAL xgbj11_Set_Size_In_Bytes();
  
extern LVAL k_currentstate;
extern LVAL k_downclick;
extern LVAL k_get;
extern LVAL k_initializefromfile;
extern LVAL k_initialstate;
extern LVAL k_iwtype;
extern LVAL k_keyboardchar;
extern LVAL k_label;
extern LVAL k_outfl;
extern LVAL k_redraw;
extern LVAL k_subtree;
extern LVAL k_upclick;
extern LVAL lv_xgtm;
extern LVAL lv_xlgt;
extern LVAL s_centre;
extern LVAL s_currentstate;
extern LVAL s_initialstate;
extern LVAL s_left;
extern LVAL s_right;
extern LVAL s_strcat;
extern LVAL s_subtree;

/* }}} */
/* {{{ xgtm00_Is_New -- Initialize a new xgtm instance.			*/

LVAL xgtm00_Is_New()
/*-
    Initialize a new xgtm instance.
-*/
{
    LVAL   gtm   = xlgagobject();
    LVAL   keyw;
    LVAL   name_as_lval;
    char*  name  = NULL;
    int    xsize = -1;
    int    ysize = -1;
    int    xpos  = -1;
    int    ypos  = -1;
    usRec* self;

    xlsave1(name_as_lval);

    if (!xgtmp(gtm))   xlbadtype( gtm );

    xgbj11_Set_Size_In_Bytes(     gtm, sizeof( usRec ) );
    self = (usRec*) gobjimmbase(  gtm );

    while (moreargs()) {

        keyw = xlgasymbol();

        if (keyw == k_iwtype) {

            /* Handle '... :initial-window-type "iris4d" ...': */
            name_as_lval = xlgastring();
            name         = (char*)getstring( name_as_lval );

        } else if (keyw == k_outfl) {

            /* Handle '... :output-file "myfile.lst" ...': */
            LVAL filename_as_lval = xlgastring();
            char*filename         = (char*)getstring( filename_as_lval );
            FILE*osaopen();       /* From xcore/unixstuff.c or equiv */
            FILE*filefd           = osaopen( filename, "w" );
	    if (filefd == NULL) {
                xlerror("cannot open output file",filename_as_lval);
	    }
	    self->state.out_file = filefd;

        } else {

            xlbadtype( keyw );
        }
    }
    xllastarg();

    /* Initialize terminal: */
    {
        struct gt_stat_struct *  old_state = gt_stat;
        int result;
        gt_stat = &self->state;
        result   = gt_struct_init( name );
        gt_stat = old_state;
        if (result < 0)   xlbadinit(name_as_lval);
    }

    return gtm;
}



/* }}} */
/* {{{ xgtm01_Get_A_XGTM -- Get arg, must be of class xgtm.		*/

LOCAL LVAL xgtm01_Get_A_XGTM()
/*-
    Get arg, must be of class xgtm.
-*/
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XGTM has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xgtm.  Similarly,          */
    /* nobody but nobody has any business resizing a xgtm,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xgtmp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) != sizeof(usRec)
    ) {
        xlerror("bad argument type",m_as_lval);
    }
    return m_as_lval;
}



/* }}} */
/* {{{ xgtm0A_Get_XGTM_State -- Get xgtm arg, return addr of state rec. */

struct gt_stat_struct* xgtm0A_Get_XGTM_State() /* Also called by xgrl.c */
/*-
    Get xgtm arg, return address of state rec.
-*/
{
    LVAL gtm    = xgtm01_Get_A_XGTM(); /* Can't have side-effects in */
    usRec* self = (usRec*) gobjimmbase( gtm );   /* gobjimmbase args!*/
    return &self->state;
}



/* }}} */
/* {{{ xgtm02_List_To_XY -- Convert (x y) list to int x,y.		*/

xgtm02_List_To_XY( x, y, p_as_lval )
int	          *x,*y;
LVAL			 p_as_lval;
/*-
    Convert (x y) list to float x,y.
-*/
{
    LVAL x_cell;
    LVAL y_cell;

    LVAL x_as_lval;
    LVAL y_as_lval;

    /* If initializer is null, use default values: */
    if (p_as_lval == NIL) xlbadtype(p_as_lval);

    x_cell = p_as_lval  ;if (!consp(x_cell)) xlbadtype(p_as_lval);
    y_cell = cdr(x_cell);if (!consp(y_cell)) xlbadtype(p_as_lval);

    if (cdr(y_cell) != NIL)                  xlbadtype(p_as_lval);

    x_as_lval = car(x_cell);
    y_as_lval = car(y_cell);

    {
	FLOTYPE xgbj00_Get_Fix_Or_Flo_Num();
	*x = (int)xgbj00_Get_Fix_Or_Flo_Num( x_as_lval );
	*y = (int)xgbj00_Get_Fix_Or_Flo_Num( y_as_lval );
    }
}



/* }}} */
/* {{{ xgtm03_Show -- Show the contents of a xgtm.			*/

LVAL xgtm03_Show()
/*-
    Show the contents of a xgtm.
-*/
{
    LVAL self,fptr;
    int i,j;
    usRec*m;

    /* get self and the file pointer */
    self = xgtm01_Get_A_XGTM();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the usRec proper: */
    m = (usRec*) gobjimmbase(self);
#if SOON
    /* buggo! */
#endif

    return self;
}



/* }}} */
/* {{{ xgtm04_List_Avail_Terminals -- List installed gterm drivers.	*/

LVAL xgtm05_List_Avail_Terminals( self )
LVAL				  self;
/*-
    Build and return list of installed gterm drivers.
-*/
{
    LVAL list, string;
    struct termentry * term = &GTterm_tbl[1];

    xlstkcheck(2);
    xlsave( list   );
    xlsave( string );

    for (  ;   term->name != NULL;   ++term) {
        string = cvstring( term->name );
        list   = cons( string, list );
    }

    xlpopn(2);
    return list;
}
LVAL xgtm04_List_Avail_Terminals()
/*-
    Build and return list of installed gterm drivers.
    This fn pops "self" off stack (message discipline).
-*/
{
    /* Get self: */
    LVAL self = xgtm01_Get_A_XGTM();
    xllastarg();

    /* Return the list of strings: */
    return xgtm05_List_Avail_Terminals( gt_stat );
}
LVAL xgtm18_List_Avail_Terminals()
/*-
    Build and return list of installed gterm drivers.
    This fn expects no args (fn-call discipline).
-*/
{
    xllastarg();
    return xgtm05_List_Avail_Terminals( gt_stat );
}



/* }}} */
/* {{{ xgtm10_Change_File -- Change current output file.		*/

LVAL xgtm07_Change_File( state, fd )
struct gt_stat_struct * state;
FILE*                           fd;
/*-
    Change current output file.
-*/
{
    struct gt_stat_struct *  old_state = gt_stat;

    gt_stat = state;
    gt_change_file( fd );
    gt_stat = old_state;

    return NIL;
}

LVAL xgtm08_Change_File( state )
struct gt_stat_struct * state;
/*-
    Change current output file.
-*/
{
    LVAL   fd_as_lval = xlgastream();
    FILE*  fd         = getfile( fd_as_lval );
    xllastarg();
    return xgtm07_Change_File( state, fd );
}

LVAL xgtm09_Change_File()
/*-
    Change current output file.
    This fn expects self + stream arg (message discipline).
-*/
{
    return xgtm08_Change_File( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm10_Change_File()
/*-
    Change current output file.
    This fn expects 1 stream arg (fn-call discipline).
-*/
{
    return xgtm08_Change_File( gt_stat );
}



/* }}} */
/* {{{ xgtm12_Change_Terminal -- Change current device driver.		*/

xgtm11_Change_Terminal( newterm )
char*			newterm;
/*-
    Change current terminal driver
-*/
{
    return gt_change_term( newterm, -1 ) >= 0;
}

LVAL xgtm12_Change_Terminal()
/*-
    Change current terminal driver (fn-call discipline).
-*/
{
    LVAL name_as_lval = xlgastring();
    xllastarg();
    xlprot1(name_as_lval);
    if (!xgtm11_Change_Terminal( getstring( name_as_lval ) )) {
        xlerror( "no such terminal driver", name_as_lval );
    }
    xlpop();
    return NIL;
}



/* }}} */
/* {{{ xgtm13_Test_Terminal -- Draw test pat using current device driver*/

LVAL xgtm13_Test_Terminal()
/*-
    Draw test pattern using current device driver.
-*/
{
    gt_test_term();
    return NIL;
}



/* }}} */
/* {{{ xgtm14_List_To_XYZ -- Convert (x y z) list to point.		*/
/* This is essentially identical to xpnt00_List_To_Point(). */

xgtm14_List_To_XYZ( p, p_as_lval )
gt_pnt*		    p;
LVAL		       p_as_lval;
/*-
    Convert (x y z) list to point.
-*/
{
    LVAL x_cell;
    LVAL y_cell;
    LVAL z_cell;

    LVAL x_as_lval;
    LVAL y_as_lval;
    LVAL z_as_lval;

    /* If initializer is null, use default values: */
    if (p_as_lval == NIL) {
        p->x = p->y = p->z = 1.0;
        return;
    }

    x_cell = p_as_lval  ;if (!consp(x_cell)) xlbadinit(p_as_lval);
    y_cell = cdr(x_cell);if (!consp(y_cell)) xlbadinit(p_as_lval);
    z_cell = cdr(y_cell);if (!consp(z_cell)) xlbadinit(p_as_lval);

    if (cdr(z_cell) != NIL)                  xlbadinit(p_as_lval);

    x_as_lval = car(x_cell);
    y_as_lval = car(y_cell);
    z_as_lval = car(z_cell);

    p->x = xgbj00_Get_Fix_Or_Flo_Num(x_as_lval);
    p->y = xgbj00_Get_Fix_Or_Flo_Num(y_as_lval);
    p->z = xgbj00_Get_Fix_Or_Flo_Num(z_as_lval);
}



/* }}} */
/* {{{ xgtm15_Point_To_List -- Convert point to (x y z) list.		*/
/* This is essentially identical to xpnt01_Point_To_List() */

LVAL xgtm15_Point_To_List( p )
gt_pnt*			   p;
/*-
    Convert point to (x y z) list.
-*/
{
    LVAL result;
    xlsave1(result);
    result = cons( cvflonum(p->z), NIL		);
    result = cons( cvflonum(p->y), result	);
    result = cons( cvflonum(p->x), result	);
    xlpop();
    return result;
}



/* }}} */
/* {{{ xgtm16_Copy -- Build copy of given XGTM.				*/

LVAL xgtm17_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given XGTM.
-*/
{
    /* Create a new gterm to hold result: */
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval = xsendmsg0(lv_xgtm,k_new);
    xlpop();

    /* Copy contents of old gterm to new and return new: */
    {
        usRec * m = (usRec*) gobjimmbase(m_as_lval);
        usRec * r = (usRec*) gobjimmbase(r_as_lval);
        *r = *m;
    }
    return r_as_lval;
}

LVAL xgtm16_Copy()
/*-
    Build copy of given XGTM.
-*/
{
    LVAL m_as_lval = xgtm01_Get_A_XGTM();
    xllastarg();
    return xgtm17_Copy(m_as_lval);
}



/* }}} */
/* {{{ xgtm18_Graphics_Mode -- Switch terminal driver to graphics mode.	*/

LVAL xgtm18_Graphics_Mode( state )
struct gt_stat_struct *    state;
/*-
    Switch terminal driver to graphics mode.
-*/
{
    xllastarg();
    (*GTterm_tbl[ state->terminal ].graphics)();
    return NIL;
}

LVAL xgtm19_Graphics_Mode_Msg()
/*-
    Switch terminal driver to graphics mode.
    This fn expects self arg (message discipline).
-*/
{
    return xgtm18_Graphics_Mode( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm20_Graphics_Mode_Fn()
/*-
    Switch terminal driver to graphics mode.
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtm18_Graphics_Mode( gt_stat );
}

xgtm2a_Graphics_Mode()
/*-
    This fn expects no arg (C fn-call discipline).
-*/
{
    (*GTterm_tbl[ gt_stat->terminal ].graphics)();
}



/* }}} */
/* {{{ xgtm21_Text_Mode -- Switch terminal driver to text mode.		*/

LVAL xgtm21_Text_Mode(   state )
struct gt_stat_struct * state;
/*-
    Switch terminal driver to text mode.
-*/
{
    xllastarg();
    (*GTterm_tbl[ state->terminal ].text)();
    return NIL;
}

LVAL xgtm22_Text_Mode_Msg()
/*-
    Switch terminal driver to text mode.
    This fn expects self arg (message discipline).
-*/
{
    return xgtm21_Text_Mode( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm23_Text_Mode_Fn()
/*-
    Switch terminal driver to graphics mode.
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtm21_Text_Mode( gt_stat );
}



/* }}} */
/* {{{ xgtm24_2D_Point -- Plot a 2-D pointoid.				*/

LVAL xgtm24_2D_Point(    state )
struct gt_stat_struct * state;
/*-
    Plot a 2-D pointoid.
-*/
{
    LVAL pt_as_lval   = xlgacons();
    int x,y;

    LVAL type_as_lval;
    int  type         = -1;

    xgtm02_List_To_XY( &x, &y, pt_as_lval );

    if (moreargs()) {
        type_as_lval = xlgafixnum();
        type         = getfixnum( type_as_lval );
    }
    if (type < -1) xlbadtype( type_as_lval );

    xllastarg();

    (*GTterm_tbl[ state->terminal ].point)(x,y);

    return NIL;
}

LVAL xgtm25_2D_Point_Msg()
/*-
    Plot a 2-D pointoid.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm24_2D_Point( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm26_2D_Point_Fn()
/*-
    Plot a 2-D pointoid.
    This fn expects point arg (fn-call discipline).
-*/
{
    return xgtm24_2D_Point( gt_stat );
}



/* }}} */
/* {{{ xgtm27_2D_Arrow -- Plot a 2-D arrow.				*/

LVAL xgtm27_2D_Arrow(    state )
struct gt_stat_struct * state;
/*-
    Plot a 2-D arrow.
-*/
{
    LVAL spt_as_lval   = xlgacons();
    LVAL ept_as_lval   = xlgacons();
    int sx,sy;
    int ex,ey;

    xgtm02_List_To_XY( &sx, &sy, spt_as_lval );
    xgtm02_List_To_XY( &ex, &ey, ept_as_lval );
    xllastarg();

    (*GTterm_tbl[ state->terminal ].arrow)(sx,sy,ex,ey);

    return NIL;
}

LVAL xgtm28_2D_Arrow_Msg()
/*-
    Plot a 2-D arrow.
    This fn expects self arg + points (message discipline).
-*/
{
    return xgtm27_2D_Arrow( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm29_2D_Arrow_Fn()
/*-
    Plot a 2-D arrow.
    This fn expects point args (fn-call discipline).
-*/
{
    return xgtm27_2D_Arrow( gt_stat );
}



/* }}} */
/* {{{ xgtm30_2D_Move -- Set 2-D cursor.				*/

LVAL xgtm30_2D_Move(     state )
struct gt_stat_struct * state;
/*-
    Set 2-D cursor.
-*/
{
    LVAL  pt_as_lval   = xlgacons();
    int   x,y;

    xgtm02_List_To_XY( &x, &y, pt_as_lval );
    xllastarg();

    (*GTterm_tbl[ state->terminal ].move)(x,y);

    return NIL;
}

LVAL xgtm31_2D_Move_Msg()
/*-
    Set 2-D cursor.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm30_2D_Move( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm32_2D_Move_Fn()
/*-
    Set 2-D cursor.
    This fn expects point args (fn-call discipline).
-*/
{
    return xgtm30_2D_Move( gt_stat );
}



/* }}} */
/* {{{ xgtm33_2D_Draw -- Draw line segment, update 2-D cursor.		*/

LVAL xgtm33_2D_Draw(     state )
struct gt_stat_struct * state;
/*-
    Draw line segment, update 2-D cursor.
-*/
{
    LVAL  pt_as_lval   = xlgacons();
    int   x,y;

    xgtm02_List_To_XY( &x, &y, pt_as_lval );
    xllastarg();

    (*GTterm_tbl[ state->terminal ].vector)(x,y);

    return NIL;
}

LVAL xgtm34_2D_Draw_Msg()
/*-
    Draw line segment, update 2-D cursor.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm33_2D_Draw( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm35_2D_Draw_Fn()
/*-
    Draw line segment, update 2-D cursor.
    This fn expects point args (fn-call discipline).
-*/
{
    return xgtm33_2D_Draw( gt_stat );
}



/* }}} */
/* {{{ xgtm36_2D_Line_Type -- Select type of line to draw.		*/

LVAL xgtm36_2D_Line_Type( state )
struct gt_stat_struct *  state;
/*-
    Select type of line to draw.
-*/
{
    LVAL  type_as_lval   = xlgafixnum();
    int   type_as_int    = getfixnum( type_as_lval );
    if (type_as_int < -2)  xlbadtype( type_as_lval );
    xllastarg();

    (*GTterm_tbl[ state->terminal ].linetype)( type_as_int );

    return NIL;
}

LVAL xgtm37_2D_Line_Type_Msg()
/*-
    Select type of line to draw.
    This fn expects self arg + type (message discipline).
-*/
{
    return xgtm36_2D_Line_Type( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm38_2D_Line_Type_Fn()
/*-
    Select type of line to draw.
    This fn expects type arg (fn-call discipline).
-*/
{
    return xgtm36_2D_Line_Type( gt_stat );
}



/* }}} */
/* {{{ xgtm39_2D_X_Max -- Return max usable x coordinate (+1).		*/

int xgtm3a_2D_X_Max(     state )
struct gt_stat_struct * state;
/*-
    Return max usable x coordinate (+1).
-*/
{
    return GTterm_tbl[ state->terminal ].xmax;
}

LVAL xgtm39_2D_X_Max(     state )
struct gt_stat_struct *  state;
/*-
    Return max usable x coordinate (+1).
-*/
{
    xllastarg();
    return cvfixnum( xgtm3a_2D_X_Max( state ) );
}

LVAL xgtm40_2D_X_Max_Msg()
/*-
    Return max usable x coordinate (+1).
    This fn expects self arg (message discipline).
-*/
{
    return xgtm39_2D_X_Max( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm41_2D_X_Max_Fn()
/*-
    Return max usable x coordinate (+1).
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtm39_2D_X_Max( gt_stat );
}



/* }}} */
/* {{{ xgtm42_2D_Y_Max -- Return max usable y coordinate (+1).		*/

int xgtm4a_2D_Y_Max(     state )   /* WARNING:  called from xcmr. */
struct gt_stat_struct * state;
/*-
    Return max usable y coordinate (+1).
-*/
{
    return GTterm_tbl[ state->terminal ].ymax;
}

LVAL xgtm42_2D_Y_Max(     state )
struct gt_stat_struct *  state;
/*-
    Return max usable y coordinate (+1).
-*/
{
    xllastarg();
    return cvfixnum( xgtm4a_2D_Y_Max( state ) );
}

LVAL xgtm43_2D_Y_Max_Msg()
/*-
    Return max usable y coordinate (+1).
    This fn expects self arg (message discipline).
-*/
{
    return xgtm42_2D_Y_Max( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm44_2D_Y_Max_Fn()
/*-
    Return max usable y coordinate (+1).
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtm42_2D_Y_Max( gt_stat );
}



/* }}} */
/* {{{ xgtm45_2D_Text_Angle -- Set text-draw angle (0==normal 1==up)	*/

LVAL xgtm45_2D_Text_Angle( state )
struct gt_stat_struct *   state;
/*-
    Set text-draw angle (0==normal 1==up).
    Return T if text can be rotated, else NIL.
-*/
{
    LVAL angle_as_lval   = xlgafixnum();
    int  angle_as_int    = getfixnum( angle_as_lval );
    if (angle_as_int != 0 && 
        angle_as_int != 1
    ) {
	xlbadtype( angle_as_lval );
    }
    xllastarg();
    if ((*GTterm_tbl[ state->terminal ].text_angle)( angle_as_int )) {
        extern LVAL true;/*xlglob.c*/
        return true;
    } else {
        return NIL;
    }
}

LVAL xgtm46_2D_Text_Angle_Msg()
/*-
    Set text-draw angle (0==normal 1==up).
    Return T if text can be rotated, else NIL.
    This fn expects self + angle arg (message discipline).
-*/
{
    return xgtm45_2D_Text_Angle( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm47_2D_Text_Angle_Fn()
/*-
    Set text-draw angle (0==normal 1==up).
    Return T if text can be rotated, else NIL.
    This fn expects angle arg (fn-call discipline).
-*/
{
    return xgtm45_2D_Text_Angle( gt_stat );
}



/* }}} */
/* {{{ xgtm48_2D_Justify_Text -- Specify LEFT/CENTRE/RIGHT justification*/

LVAL xgtm48_2D_Justify_Text( state )
struct gt_stat_struct *     state;
/*-
    Specify LEFT/CENTRE/RIGHT justification.
    Return T if text can be justified, else NIL (flush-left only).
-*/
{
    int  arg;
    LVAL lcr   = xlgasymbol();
    if      (lcr == s_left)    arg = LEFT;
    else if (lcr == s_centre)  arg = CENTRE;
    else if (lcr == s_right)   arg = RIGHT;
    else xlbadtype( lcr );
    xllastarg();

    if ((*GTterm_tbl[ state->terminal ].justify_text)( arg )) {
        extern LVAL true;/*xlglob.c*/
        return true;
    } else {
        return NIL;
    }
}

LVAL xgtm49_2D_Justify_Text_Msg()
/*-
    Specify LEFT/CENTRE/RIGHT justification.
    Return T if text can be justified, else NIL (flush-left only).
    This fn expects self + arg (message discipline).
-*/
{
    return xgtm48_2D_Justify_Text( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm50_2D_Justify_Text_Fn()
/*-
    Specify LEFT/CENTRE/RIGHT justification.
    Return T if text can be justified, else NIL (flush-left only).
    This fn expects arg (fn-call discipline).
-*/
{
    return xgtm48_2D_Justify_Text( gt_stat );
}



/* }}} */
/* {{{ xgtm51_2D_Put_Text -- Write text in graphics mode.		*/

LVAL xgtm51_2D_Put_Text( state )
struct gt_stat_struct * state;
/*-
    Write text in graphics mode.
-*/
{
    LVAL  pt_as_lval  = xlgacons();
    LVAL  tx_as_lval  = xlgastring();
    char* tx          = (char*)getstring( tx_as_lval );
    int   x,y; xgtm02_List_To_XY( &x, &y, pt_as_lval );
    xllastarg();

    (*GTterm_tbl[ state->terminal ].put_text)( x,y,tx );

    return NIL;
}

LVAL xgtm52_2D_Put_Text_Msg()
/*-
    Write text in graphics mode.
    This fn expects self + args (message discipline).
-*/
{
    return xgtm51_2D_Put_Text( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm53_2D_Put_Text_Fn()
/*-
    Write text in graphics mode.
    This fn expects args (fn-call discipline).
-*/
{
    return xgtm51_2D_Put_Text( gt_stat );
}



/* }}} */
/* {{{ xgtm54_2D_V_Char -- Return vertical size of char in pixels.	*/

LVAL xgtm54_2D_V_Char(   state )
struct gt_stat_struct * state;
/*-
    Return vertical size of char in pixels.
-*/
{
    xllastarg();
    return cvfixnum( GTterm_tbl[ state->terminal ].v_char );
}

LVAL xgtm55_2D_V_Char_Msg()
/*-
    Return vertical size of char in pixels.
    This fn expects self (message discipline).
-*/
{
    return xgtm54_2D_V_Char( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm56_2D_V_Char_Fn()
/*-
    Return vertical size of char in pixels.
    This fn expects no args (fn-call discipline).
-*/
{
    return xgtm54_2D_V_Char( gt_stat );
}



/* }}} */
/* {{{ xgtm57_2D_H_Char -- Return horizontal size of char in pixels.	*/

LVAL xgtm57_2D_H_Char(   state )
struct gt_stat_struct * state;
/*-
    Return horizontal size of char in pixels.
-*/
{
    xllastarg();
    return cvfixnum( GTterm_tbl[ state->terminal ].h_char );
}

LVAL xgtm58_2D_H_Char_Msg()
/*-
    Return horizontal size of char in pixels.
    This fn expects self (message discipline).
-*/
{
    return xgtm57_2D_H_Char( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm59_2D_H_Char_Fn()
/*-
    Return vertical size of char in pixels.
    This fn expects no args (fn-call discipline).
-*/
{
    return xgtm57_2D_H_Char( gt_stat );
}



/* }}} */
/* {{{ xgtm60_2D_V_Tic -- Return vertical size of tic-mark in pixels.	*/

LVAL xgtm60_2D_V_Tic(    state )
struct gt_stat_struct * state;
/*-
    Return vertical size of tic-mark in pixels.
-*/
{
    xllastarg();
    return cvfixnum( GTterm_tbl[ state->terminal ].v_tic );
}

LVAL xgtm61_2D_V_Tic_Msg()
/*-
    Return vertical size of tic-mark in pixels.
    This fn expects self (message discipline).
-*/
{
    return xgtm60_2D_V_Tic( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm62_2D_V_Tic_Fn()
/*-
    Return vertical size of tic-mark in pixels.
    This fn expects no args (fn-call discipline).
-*/
{
    return xgtm60_2D_V_Tic( gt_stat );
}



/* }}} */
/* {{{ xgtm63_2D_H_Tic -- Return horizontal size of tic-mark in pixels.	*/

LVAL xgtm63_2D_H_Tic(    state )
struct gt_stat_struct * state;
/*-
    Return horizontal size of tic-mark in pixels.
-*/
{
    xllastarg();
    return cvfixnum( GTterm_tbl[ state->terminal ].h_tic );
}

LVAL xgtm64_2D_H_Tic_Msg()
/*-
    Return horizontal size of tic-mark in pixels.
    This fn expects self (message discipline).
-*/
{
    return xgtm63_2D_H_Tic( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm65_2D_H_Tic_Fn()
/*-
    Return horizontal size of tic-mark in pixels.
    This fn expects no args (fn-call discipline).
-*/
{
    return xgtm63_2D_H_Tic( gt_stat );
}


/* }}} */
/* {{{ xgtm66_Get_Color -- Return currently selected color as '(r g b).	*/

LVAL xgtm66_Get_Color(   state )
struct gt_stat_struct * state;
/*-
    Return currently selected color as '(r g b).
-*/
{
    gt_fhue h;
    xllastarg();
    GTterm_tbl[ state->terminal ].gt_get_color( &h );
    return xgtm15_Point_To_List( &h );
}

LVAL xgtm67_Get_Color_Msg()
/*-
    Return currently selected color as '(r g b).
    This fn expects self (message discipline).
-*/
{
    return xgtm66_Get_Color( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm68_Get_Color_Fn()
/*-
    Return currently selected color as '(r g b).
    This fn expects no args (fn-call discipline).
-*/
{
    return xgtm66_Get_Color( gt_stat );
}


/* }}} */
/* {{{ xgtm71_Set_Color -- Set color as from '(r g b) list.		*/

float xgtm69__01( pf )
float*            pf;
/*-
    Check that a number is in [0,1]
-*/
{
    float f = *pf;
    if (f < 0.0) {
        /* Allow a little floating-point imprecision: */
        if (f < -0.0001) xlfail("float is < 0.0");
        *pf = 0.0;
    }
    if (f > 1.0) {
        /* Allow a little floating-point imprecision: */
        if (f > 1.0001) xlfail("float is > 1.0");
        *pf = 1.0;
    }
}
xgtm70_Set_Color(       state, h ) /* Called from xwmr.c */
struct gt_stat_struct * state;
gt_fhue*		       h;
{
    float f;
    f = h->fr; xgtm69__01( &f ); h->fr = f;
    f = h->fg; xgtm69__01( &f ); h->fg = f;
    f = h->fb; xgtm69__01( &f ); h->fb = f;
    GTterm_tbl[ state->terminal ].gt_set_color( h );
}
LVAL xgtm71_Set_Color(   state )
struct gt_stat_struct * state;
/*-
    Set color as from '(r g b) list.
-*/
{
    LVAL    hue_as_lval  = xlgacons();
    gt_fhue h;
    float   f;
    xllastarg();
    xgtm14_List_To_XYZ( &h, hue_as_lval );
    xgtm70_Set_Color(   state, &h );
    return hue_as_lval;
}

LVAL xgtm72_Set_Color_Msg()
/*-
    Set color as from '(r g b) list.
    This fn expects self (message discipline).
-*/
{
    return xgtm71_Set_Color( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm73_Set_Color_Fn()
/*-
    Set color as from '(r g b) list.
    This fn expects no 'self' arg (fn-call discipline).
-*/
{
    return xgtm71_Set_Color( gt_stat );
}

xgtm7a_Set_Color( hue )
gt_fhue          *hue;
/*-
    This fn expects no C arg (C fn-call discipline).
-*/
{
    xgtm70_Set_Color( gt_stat, hue );
}



/* }}} */
/* {{{ xgtm74_3D_Point -- Plot a 3-D point.				*/

LVAL xgtm74_3D_Point(    state )
struct gt_stat_struct * state;
/*-
    Plot a 3-D point.
-*/
{
    LVAL pt_as_lval   = xlgacons();
    gt_pnt pt;        xgtm14_List_To_XYZ( &pt, pt_as_lval );
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_3d_point)( &pt );
    return NIL;
}

LVAL xgtm75_3D_Point_Msg()
/*-
    Plot a 3-D point.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm74_3D_Point( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm76_3D_Point_Fn()
/*-
    Plot a 3-D point.
    This fn expects point arg (fn-call discipline).
-*/
{
    return xgtm74_3D_Point( gt_stat );
}



/* }}} */
/* {{{ xgtm77_3D_Move -- Set 3-D cursor.				*/

LVAL xgtm77_3D_Move(     state )
struct gt_stat_struct * state;
/*-
    Set 3-D cursor.
-*/
{
    LVAL pt_as_lval   = xlgacons();
    gt_pnt pt;        xgtm14_List_To_XYZ( &pt, pt_as_lval );
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_3d_move)( &pt );
    return NIL;
}

LVAL xgtm78_3D_Move_Msg()
/*-
    Set 3-D cursor.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm77_3D_Move( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm79_3D_Move_Fn()
/*-
    Set 3-D cursor.
    This fn expects point arg (fn-call discipline).
-*/
{
    return xgtm77_3D_Move( gt_stat );
}



/* }}} */
/* {{{ xgtm80_3D_Draw -- Draw 3-D line segment.				*/

LVAL xgtm80_3D_Draw(     state )
struct gt_stat_struct * state;
/*-
    Draw 3-D line segment.
-*/
{
    LVAL pt_as_lval   = xlgacons();
    gt_pnt pt;        xgtm14_List_To_XYZ( &pt, pt_as_lval );
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_3d_draw)( &pt );
    return NIL;
}

LVAL xgtm81_3D_Draw_Msg()
/*-
    Draw 3-D line segment.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm80_3D_Draw( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm82_3D_Draw_Fn()
/*-
    Draw 3-D line segment.
    This fn expects point arg (fn-call discipline).
-*/
{
    return xgtm80_3D_Draw( gt_stat );
}



/* }}} */
/* {{{ xgtm83_3D_Overlay_Draw -- Draw erasable 3-D line segment.	*/

LVAL xgtm83_3D_Overlay_Draw( state )
struct gt_stat_struct *     state;
/*-
    Draw erasable 3-D line segment.
-*/
{
    LVAL pt_as_lval   = xlgacons();
    gt_pnt pt;        xgtm14_List_To_XYZ( &pt, pt_as_lval );
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_3d_overlay_draw)( &pt );
    return NIL;
}

LVAL xgtm84_3D_Overlay_Draw_Msg()
/*-
    Draw erasable 3-D line segment.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm83_3D_Overlay_Draw( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm85_3D_Overlay_Draw_Fn()
/*-
    Draw erasable 3-D line segment.
    This fn expects point arg (fn-call discipline).
-*/
{
    return xgtm83_3D_Overlay_Draw( gt_stat );
}



/* }}} */
/* {{{ xgtm86_3D_Overlay_Erase -- Erase erasable 3-D line segment.	*/

LVAL xgtm86_3D_Overlay_Erase( state )
struct gt_stat_struct *     state;
/*-
    Erase erasable 3-D line segment.
-*/
{
    LVAL pt_as_lval   = xlgacons();
    gt_pnt pt;        xgtm14_List_To_XYZ( &pt, pt_as_lval );
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_3d_overlay_erase)( &pt );
    return NIL;
}

LVAL xgtm87_3D_Overlay_Erase_Msg()
/*-
    Erase erasable 3-D line segment.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm86_3D_Overlay_Erase( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm88_3D_Overlay_Erase_Fn()
/*-
    Erase erasable 3-D line segment.
    This fn expects point arg (fn-call discipline).
-*/
{
    return xgtm86_3D_Overlay_Erase( gt_stat );
}

/* }}} */
/* {{{ xgtm89_3D_Flat_Triangle -- Draw flat-shaded triangle.		*/

LVAL xgtm89_3D_Flat_Triangle( state )
struct gt_stat_struct *      state;
/*-
    Draw flat-shaded triangle.
-*/
{
    LVAL pt_as_lval   = xlgacons();
    gt_pnt pt;        xgtm14_List_To_XYZ( &pt, pt_as_lval );
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_3d_flat_triangle)( &pt );
    return NIL;
}

LVAL xgtm90_3D_Flat_Triangle_Msg()
/*-
    Draw flat-shaded triangle.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm89_3D_Flat_Triangle( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm91_3D_Flat_Triangle_Fn()
/*-
    Draw flat-shaded triangle.
    This fn expects point arg (fn-call discipline).
-*/
{
    return xgtm89_3D_Flat_Triangle( gt_stat );
}



/* }}} */
/* {{{ xgtm92_3D_Gouraud_Triangle -- Draw Gouraud-shaded triangle.	*/

LVAL xgtm92_3D_Gouraud_Triangle( state )
struct gt_stat_struct *         state;
/*-
    Draw Gouraud-shaded triangle.
-*/
{
    LVAL pt_as_lval   = xlgacons();
    gt_pnt pt;        xgtm14_List_To_XYZ( &pt, pt_as_lval );
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_3d_gouraud_triangle)( &pt );
    return NIL;
}

LVAL xgtm93_3D_Gouraud_Triangle_Msg()
/*-
    Draw Gouraud-shaded triangle.
    This fn expects self arg + point (message discipline).
-*/
{
    return xgtm92_3D_Gouraud_Triangle( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm94_3D_Gouraud_Triangle_Fn()
/*-
    Draw Gouraud-shaded triangle.
    This fn expects point arg (fn-call discipline).
-*/
{
    return xgtm92_3D_Gouraud_Triangle( gt_stat );
}



/* }}} */
/* {{{ xgtm95_3D_Swap_Triangle -- Reverse orientation of next triangle.	*/

LVAL xgtm95_3D_Swap_Triangle( state )
struct gt_stat_struct *      state;
/*-
    Reverse orientation of next triangle.
-*/
{
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_3d_swap_triangle)();
    return NIL;
}

LVAL xgtm96_3D_Swap_Triangle_Msg()
/*-
    Reverse orientation of next triangle.
    This fn expects self arg (message discipline).
-*/
{
    return xgtm95_3D_Swap_Triangle( xgtm0A_Get_XGTM_State() );
}

LVAL xgtm97_3D_Swap_Triangle_Fn()
/*-
    Reverse orientation of next triangle.
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtm95_3D_Swap_Triangle( gt_stat );
}



/* }}} */
/* {{{ xgtm98_Get_Zbuffering_Is_On -- Return NIL iff zbuffering is off.	*/

LVAL xgtm98_Get_Zbuffering_Is_On( state )
struct gt_stat_struct *          state;
/*-
    Return NIL iff zbuffering is off.
-*/
{
    xllastarg();
    if ((*GTterm_tbl[ state->terminal ].gt_get_zbuffering_is_on)()) {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
    return NIL;
}

LVAL xgtm99_Get_Zbuffering_Is_On_Msg()
/*-
    Return NIL iff zbuffering is off.
    This fn expects self arg (message discipline).
-*/
{
    return xgtm98_Get_Zbuffering_Is_On( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmA0_Get_Zbuffering_Is_On_Fn()
/*-
    Return NIL iff zbuffering is off.
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtm98_Get_Zbuffering_Is_On( gt_stat );
}



/* }}} */
/* {{{ xgtmA1_Set_Zbuffering_Is_On -- (setq zbuf_is_on (not null arg))	*/

LVAL xgtmA1_Set_Zbuffering_Is_On( state )
struct gt_stat_struct *          state;
/*-
    (setq zbuffering_is_on (not null arg))
-*/
{
    LVAL arg = xlgetarg();
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_set_zbuffering_is_on)(
	arg != NIL
    );
    return arg;
}

LVAL xgtmA2_Set_Zbuffering_Is_On_Msg()
/*-
    (setq zbuffering_is_on (not null arg))
    This fn expects self + arg (message discipline).
-*/
{
    return xgtmA1_Set_Zbuffering_Is_On( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmA3_Set_Zbuffering_Is_On_Fn()
/*-
    (setq zbuffering_is_on (not null arg))
    This fn expects just arg (fn-call discipline).
-*/
{
    return xgtmA1_Set_Zbuffering_Is_On( gt_stat );
}

xgtmAb_Set_Zbuffering_Is_On( bool )
int			     bool;	
/*-
    This fn expects just int arg (C fn-call discipline).
-*/
{
    (*GTterm_tbl[ gt_stat->terminal ].gt_set_zbuffering_is_on)(
	bool
    );
}



/* }}} */
/* {{{ xgtmA4_Get_Double_Buffering_Is_On -- Return NIL iff not so.	*/

LVAL xgtmA4_Get_Double_Buffering_Is_On( state )
struct gt_stat_struct *                state;
/*-
    Return NIL iff double buffering is off.
-*/
{
    xllastarg();
    if ((*GTterm_tbl[ state->terminal ].gt_get_double_buffering_is_on)()) {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
    return NIL;
}

LVAL xgtmA5_Get_Double_Buffering_Is_On_Msg()
/*-
    Return NIL iff double buffering is off.
    This fn expects self arg (message discipline).
-*/
{
    return xgtmA4_Get_Double_Buffering_Is_On( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmA6_Get_Double_Buffering_Is_On_Fn()
/*-
    Return NIL iff double buffering is off.
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtmA4_Get_Double_Buffering_Is_On( gt_stat );
}



/* }}} */
/* {{{ xgtmA7_Set_Double_Buffering_Is_On -- (setq zbuffering_is_on ...) */

LVAL xgtmA7_Set_Double_Buffering_Is_On( state )
struct gt_stat_struct *                state;
/*-
    (setq double_buffering_is_on (not null arg))
-*/
{
    LVAL arg = xlgetarg();
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_set_double_buffering_is_on)(
	arg != NIL
    );
    return arg;
}

LVAL xgtmA8_Set_Double_Buffering_Is_On_Msg()
/*-
    (setq double_buffering_is_on (not null arg))
    This fn expects self + arg (message discipline).
-*/
{
    return xgtmA7_Set_Double_Buffering_Is_On( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmA9_Set_Double_Buffering_Is_On_Fn()
/*-
    (setq double_buffering_is_on (not null arg))
    This fn expects just arg (fn-call discipline).
-*/
{
    return xgtmA7_Set_Double_Buffering_Is_On( gt_stat );
}

xgtmAa_Set_Double_Buffering_Is_On(bool)
int				  bool;
/*-
    This fn expects just in arg (C fn-call discipline).
-*/
{
    (*GTterm_tbl[ gt_stat->terminal ].gt_set_double_buffering_is_on)(
	bool
    );
}



/* }}} */
/* {{{ xgtmB0_Get_Depthcueing_Is_On -- Return NIL iff not so.		*/

LVAL xgtmB0_Get_Depthcueing_Is_On( state )
struct gt_stat_struct *           state;
/*-
    Return NIL iff depth-cueing is off.
-*/
{
    xllastarg();
    if ((*GTterm_tbl[ state->terminal ].gt_get_depthcueing_is_on)()) {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
    return NIL;
}

LVAL xgtmB1_Get_Depthcueing_Is_On_Msg()
/*-
    Return NIL iff depthcueing is off.
    This fn expects self arg (message discipline).
-*/
{
    return xgtmB0_Get_Depthcueing_Is_On( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmB2_Get_Depthcueing_Is_On_Fn()
/*-
    Return NIL iff depthcueing is off.
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtmB0_Get_Depthcueing_Is_On( gt_stat );
}



/* }}} */
/* {{{ xgtmB3_Set_Depthcueing_Is_On -- (setq depthcueing_is_on ...)     */

LVAL xgtmB3_Set_Depthcueing_Is_On( state )
struct gt_stat_struct *           state;
/*-
    (setq depthcueing_is_on (not null arg))
-*/
{
    LVAL arg = xlgetarg();
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_set_depthcueing_is_on)(
	arg != NIL
    );
    return arg;
}

LVAL xgtmB4_Set_Depthcueing_Is_On_Msg()
/*-
    (setq depthcueing_is_on (not null arg))
    This fn expects self + arg (message discipline).
-*/
{
    return xgtmB3_Set_Depthcueing_Is_On( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmB5_Set_Depthcueing_Is_On_Fn()
/*-
    (setq depthcueing_is_on (not null arg))
    This fn expects just arg (fn-call discipline).
-*/
{
    return xgtmB3_Set_Depthcueing_Is_On( gt_stat );
}



/* }}} */
/* {{{ xgtmB6_Swap_Buffers -- Swap front and back screen buffers.     	*/

LVAL xgtmB6_Swap_Buffers( state )
struct gt_stat_struct *  state;
/*-
    Swap front and back screen buffers.
-*/
{
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_swap_buffers)();
    return NIL;
}

LVAL xgtmB7_Swap_Buffers_Msg()
/*-
    Swap front and back screen buffers.
    This fn expects self arg (message discipline).
-*/
{
    return xgtmB6_Swap_Buffers( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmB8_Swap_Buffers_Fn()
/*-
    Swap front and back screen buffers.
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtmB6_Swap_Buffers( gt_stat );
}



/* }}} */
/* {{{ xgtmB9_Raster_Support -- Return NIL iff no raster extensions.	*/

LVAL xgtmB9_Raster_Support( state )
struct gt_stat_struct *    state;
/*-
    Return NIL iff no raster extensions.
-*/
{
    xllastarg();
    if ((*GTterm_tbl[ state->terminal ].gt_raster_support)()) {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
    return NIL;
}

LVAL xgtmC0_Raster_Support_Msg()
/*-
    Return NIL iff no raster extensions.
    This fn expects self arg (message discipline).
-*/
{
    return xgtmB9_Raster_Support( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmC1_Raster_Support_Fn()
/*-
    Return NIL iff no raster extensions.
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtmB9_Raster_Support( gt_stat );
}



/* }}} */
/* {{{ xgtmC2_Clear_Viewport -- Clear viewport(+zbuffer) to crrnt color.*/

LVAL xgtmC2_Clear_Viewport( state )
struct gt_stat_struct *    state;
/*-
    Clear viewport to current color, clear (at least) matching zbuffer area.
-*/
{
    xllastarg();
    (*GTterm_tbl[ state->terminal ].gt_clear_viewport)();
    return NIL;
}

LVAL xgtmC3_Clear_Viewport_Msg()
/*-
    Clear viewport to current color, clear (at least) matching zbuffer area.
    This fn expects self arg (message discipline).
-*/
{
    return xgtmC2_Clear_Viewport( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmC4_Clear_Viewport_Fn()
/*-
    Clear viewport to current color, clear (at least) matching zbuffer area.
    This fn expects no arg (fn-call discipline).
-*/
{
    return xgtmC2_Clear_Viewport( gt_stat );
}

/* }}} */
/* {{{ xgtmC5_Clear_Zbuffer						*/

xgtmC5_Clear_Zbuffer()
/*-
    This fn expects no arg (C fn-call discipline).
-*/
{
    (*GTterm_tbl[ gt_stat->terminal ].gt_clear_zbuffer)();
}

/* }}} */
/* {{{ xgtmC7_Clear_Overlay_Bitplanes					*/

xgtmC7_Clear_Overlay_Bitplanes()
/*-
    This fn expects no arg (C fn-call discipline).
-*/
{
    return (*GTterm_tbl[ gt_stat->terminal ].gt_clear_overlay_bitplanes)();
}

/* }}} *//* {{{ xgtmDx_Draw_Lotsa_Stuff						*/

LVAL xgtmDx_Draw_Lotsa_Stuff(state, r )
struct gt_stat_struct *      state;
gt_tri_rec            *             r;
/*-
    Draw a vector of points, line-segs, triangles or rectangles.
-*/
{
    /* Set current color to match current material: */
    register struct termentry *t = &GTterm_tbl[ state->terminal ];
    gt_fhue old_hue;
    gt_fhue new_hue;
    new_hue.fr = r->material->diffuse_color.r;
    new_hue.fg = r->material->diffuse_color.g;
    new_hue.fb = r->material->diffuse_color.b;
    GTterm_tbl[ state->terminal ].gt_get_color( &old_hue );
    GTterm_tbl[ state->terminal ].gt_set_color( &new_hue );
    t->gt_draw_lotsa_stuff( state, r );
    GTterm_tbl[ state->terminal ].gt_set_color( &old_hue );
    return NIL;
}

/* }}} */
/* {{{ xgtmD9_2D_4_Int_To_List -- Convert 4 ints to a list.		*/

LVAL xgtmD9_2D_4_Int_To_List( i, j, k, l )
int                           i, j, k, l;
/*-
    Convert 4 ints to a list.
-*/
{
    LVAL result;
    xlsave1(result);
    result = cons( cvfixnum(l), NIL    );
    result = cons( cvfixnum(k), result );
    result = cons( cvfixnum(j), result );
    result = cons( cvfixnum(i), result );
    xlpop();
    return result;
}



/* }}} */
/* {{{ xgtmE0_Get_Viewport -- Get viewport size and location on window.	*/

xgtmE0_Get_Viewport(     state, x_min, x_max, y_min, y_max )
struct gt_stat_struct * state;
int			       *x_min,*x_max,*y_min,*y_max; 	
/*-
    Get viewport size and location.
-*/
{
    (*GTterm_tbl[ state->terminal ].gt_get_viewport)(
        x_min, x_max, y_min, y_max
    );
}

LVAL xgtmE1_Get_Viewport( state )
struct gt_stat_struct *  state;
/*-
    Get viewport size and location.
-*/
{
    int x_min, x_max, y_min, y_max;
    xllastarg();
    xgtmE0_Get_Viewport( state, &x_min, &x_max, &y_min, &y_max );
    return xgtmD9_2D_4_Int_To_List( x_min, x_max, y_min, y_max );
}

LVAL xgtmE2_Get_Viewport_Msg()
/*-
    Get viewport size and location.
-*/
{
    return xgtmE1_Get_Viewport( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmE3_Get_Viewport_Fn()
/*-
    Get viewport size and location.
-*/
{
    return xgtmE1_Get_Viewport( gt_stat );
}



/* }}} */
/* {{{ xgtmE5_Set_Viewport -- Set viewport size and location on window.	*/

xgtmE5_Set_Viewport(     state, x_min, x_max, y_min, y_max )
struct gt_stat_struct * state;
int			        x_min, x_max, y_min, y_max;
/*-
    Set viewport size and location.
-*/
{
    (*GTterm_tbl[ state->terminal ].gt_set_viewport)(
        x_min, x_max, y_min, y_max
    );
}

LVAL xgtmE6_Set_Viewport( state )
struct gt_stat_struct *  state;
/*-
    Set viewport size and location.
-*/
{
    int x_min, x_max, y_min, y_max; 
    LVAL pt_list = xlgacons();
    xllastarg();
    libE4_2D_List_To_4_Int( &x_min, &x_max, &y_min, &y_max, pt_list );
    xgtmE5_Set_Viewport( state, x_min, x_max, y_min, y_max );
    return NIL;
}

LVAL xgtmE7_Set_Viewport_Msg()
/*-
    Set viewport size and location.
-*/
{
    return xgtmE6_Set_Viewport( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmE8_Set_Viewport_Fn()
/*-
    Set viewport size and location.
-*/
{
    return xgtmE6_Set_Viewport( gt_stat );
}

/* }}} */
/* {{{ xgtmF0_Mouse_Position -- Nonblocking read of mouse loc in window.*/

xgtmF0_Mouse_Position(   state, x, y )
struct gt_stat_struct * state;
int			       *x,*y;
/*-
    Nonblocking read of mouse location relative to window.
-*/
{
    (*GTterm_tbl[ state->terminal ].gt_mouse_position)( x, y );
}

LVAL xgtmF1_Mouse_Position( state )
struct gt_stat_struct *    state;
{
    LVAL lib34_2D_Int_Point_To_List();
    int x, y; 
    xllastarg();
    xgtmF0_Mouse_Position(   state, &x, &y );
    return lib34_2D_Int_Point_To_List( x, y );
}

LVAL xgtmF2_Mouse_Position_Msg()
{
    return xgtmF1_Mouse_Position( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmF3_Mouse_Position_Fn()
{
    return xgtmF1_Mouse_Position( gt_stat );
}

/* }}} */
/* {{{ xgtmF4_Get_Window -- Get window size and location on screen.	*/

xgtmF4_Get_Window(      state, x_min, x_max, y_min, y_max ) /* Called from xwmr.c */
struct gt_stat_struct * state;
int			      *x_min,*x_max,*y_min,*y_max; 	
/*-
    Get window size and location.
-*/
{
    (*GTterm_tbl[ state->terminal ].gt_get_window)(
        x_min, x_max, y_min, y_max
    );
}

LVAL xgtmF5_Get_Window(  state )
struct gt_stat_struct *  state;
/*-
    Get window size and location.
-*/
{
    int x_min, x_max, y_min, y_max;
    xllastarg();
    xgtmF4_Get_Window( state, &x_min, &x_max, &y_min, &y_max );
    return xgtmD9_2D_4_Int_To_List( x_min, x_max, y_min, y_max );
}

LVAL xgtmF6_Get_Window_Msg()
/*-
    Get window size and location.
-*/
{
    return xgtmF5_Get_Window( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmF7_Get_Window_Fn()
/*-
    Get window size and location.
-*/
{
    return xgtmF5_Get_Window( gt_stat );
}

/* }}} */
/* {{{ xgtmF8_Set_Window -- Set window size and location on screen.	*/

xgtmF8_Set_Window(      state, x_min, x_max, y_min, y_max ) /* Called from xwmr.c */
struct gt_stat_struct * state;
int			       x_min, x_max, y_min, y_max;
/*-
    Set window size and location.
-*/
{
    return (*GTterm_tbl[ state->terminal ].gt_set_window)(
        x_min, x_max, y_min, y_max
    );
}

LVAL xgtmF9_Set_Window( state )
struct gt_stat_struct * state;
/*-
    Set window size and location.
-*/
{
    int x_min, x_max, y_min, y_max; 
    LVAL pt_list = xlgacons();
    xllastarg();
    libE4_2D_List_To_4_Int( &x_min, &x_max, &y_min, &y_max, pt_list );
    if (xgtmF8_Set_Window( state, x_min, x_max, y_min, y_max )) {
        extern LVAL true;/*xlglob.c*/
        return true;
    } else {
        return NIL;
    }
}

LVAL xgtmFa_Set_Window_Msg()
/*-
    Set window size and location.
-*/
{
    return xgtmF9_Set_Window( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmFb_Set_Window_Fn()
/*-
    Set window size and location.
-*/
{
    return xgtmF9_Set_Window( gt_stat );
}

/* }}} */
/* {{{ xgtmG0_Blocking_Queue_Read -- Read an event from input queue.	*/

/* This fn is exported to xwmr.c: */
xgtmFz_Blocking_Queue_Read( state, event, value, x, y )
struct gt_stat_struct *     state;
LVAL                              *event;
int                                      *value,*x,*y;
/*-
    Read in event from input queue.
-*/
{
    int ievent;
    xgtmG0_Blocking_Queue_Read( state, &ievent, value, x, y );
    switch (ievent) {
    case GT_KEYBOARD:	*event = k_keyboardchar;	break;
    case GT_DOWNCLICK:	*event = k_downclick;		break;
    case GT_UPCLICK:	*event = k_upclick;		break;
    default:
	*                event = k_redraw;
    }

    return TRUE;
}

xgtmG0_Blocking_Queue_Read( state, event, value, x, y )
struct gt_stat_struct *     state;
int                               *event,*value,*x,*y;
/*-
    Read in event from input queue.
-*/
{
    (*GTterm_tbl[ state->terminal ].gt_blocking_input)(
	state, event, value, x, y
    );
    return TRUE;
}

LVAL xgtmG1_Blocking_Queue_Read( state )
struct gt_stat_struct * state;
{
    LVAL result;
    LVAL click;
    int event, value, x, y;
    xgtmG0_Blocking_Queue_Read( state, &event, &value, &x, &y );
    switch (event) {

    case GT_REDRAW:
	/* Return (:REDRAW). List for consistency and to  */
        /* allow adding additional return info in future: */
        xlsave1(result);
        result = cons( k_redraw, NIL    );
        xlpop();
        return result;

    case GT_KEYBOARD:
	/* Return (:KEYBOARD-CHAR <character>): */
        xlsave1(result);
        result = cons( cvchar(value),  NIL    );
        result = cons( k_keyboardchar, result );
        xlpop();
        return result;

    case GT_DOWNCLICK:
	/* Return (:DOWNCLICK <x> <y>): */
        click = k_downclick;
	goto click_join;
    case GT_UPCLICK:
	/* Return (:DOWNCLICK <x> <y>): */
        click = k_upclick;
    click_join:
        xlsave1(result);
        result = cons( cvfixnum(y), NIL    );
        result = cons( cvfixnum(x), result );
        result = cons( click,       result );
        xlpop();
        return result;

    default:
	/* Can only happen on broken driver: */
	exit(1);
    }
}

LVAL xgtmG2_Blocking_Queue_Read_Msg()
{
    return xgtmG1_Blocking_Queue_Read( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmG3_Blocking_Queue_Read_Fn()
{
    return xgtmG1_Blocking_Queue_Read( gt_stat );
}

/* }}} */
/* {{{ xgtmG4_Nonblocking_Queue_Read -- Maybe read an event from input q*/

int xgtmG4_Queue_Input_Available( state )
struct gt_stat_struct *           state;
{
    return (*GTterm_tbl[ state->terminal ].gt_input_available)();
}

LVAL xgtmG5_Nonblocking_Queue_Read( state )
struct gt_stat_struct *             state;
{
    if (!xgtmG4_Queue_Input_Available( state ))   return NIL;
    return xgtmG1_Blocking_Queue_Read( state );
}

LVAL xgtmG6_Nonblocking_Queue_Read_Msg()
{
    return xgtmG5_Nonblocking_Queue_Read( xgtm0A_Get_XGTM_State() );
}

LVAL xgtmG7_Nonblocking_Queue_Read_Fn()
{
    return xgtmG5_Nonblocking_Queue_Read( gt_stat );
}

/* }}} */
/* {{{ xgtmG8_State -- Export state to other modules.			*/

char* xgtmG8_State() {
    /* This is exported *not* so that other modules can peek inside */
    /* the state (they shouldn't), but so that they can call fns    */
    /* such as xgtmF4 that need a state argument.  See 3d/c/xwmr.c  */
    /* for an example of this.                                      */ 
    return (char*) gt_stat;
}

/* }}} */
/* {{{ xgtmH0_Set_Blanktime -- Set screensaver time in seconds.		*/

xgtmH0_Set_Blanktime( state )
struct gt_stat_struct*state;
{
    LVAL lv_secs  = xlgafixnum();
    int     secs  = getfixnum( lv_secs );
    xllastarg();
    return (*GTterm_tbl[ state->terminal ].gt_set_blanktime)(state,secs);
}
LVAL xgtmH1_Set_Blanktime_Msg()
{
    xgtmH0_Set_Blanktime( xgtm0A_Get_XGTM_State() );
    return NIL;
}

LVAL xgtmH2_Set_Blanktime_Fn()
{
    xgtmH0_Set_Blanktime( gt_stat );
    return NIL;
}

/* }}} */
/* {{{ xgtmH5_Sleep -- Sleep given number of seconds.			*/

xgtmH5_Sleep(         state )
struct gt_stat_struct*state;
{
    LVAL lv_secs  = xlgafixnum();
    int     secs  = getfixnum( lv_secs );
    xllastarg();
    return (*GTterm_tbl[ state->terminal ].gt_sleep)(state,secs);
}
LVAL xgtmH6_Sleep_Msg()
{
    xgtmH5_Sleep( xgtm0A_Get_XGTM_State() );
    return NIL;
}

LVAL xgtmH7_Sleep_Fn()
{
    xgtmH5_Sleep( gt_stat );
    return NIL;
}

/* }}} */
/* {{{ xgtmI0_Finish -- Block until graphics pipeline is empty.		*/

xgtmI0_Finish(        state )
struct gt_stat_struct*state;
{
    xllastarg();
    return (*GTterm_tbl[ state->terminal ].gt_finish)(state);
}
LVAL xgtmI1_Finish_Msg()
{
    xgtmI0_Finish( xgtm0A_Get_XGTM_State() );
    return NIL;
}

LVAL xgtmI2_Finish_Fn()
{
    xgtmI0_Finish( gt_stat );
    return NIL;
}

/* }}} */
/* {{{ xgtmI5_to_NTSC_video -- Switch to NTSC signal generation.	*/

xgtmI5_to_NTSC_video( state )
struct gt_stat_struct*state;
{
    xllastarg();
    return (*GTterm_tbl[ state->terminal ].gt_to_NTSC_video)(state);
}
LVAL xgtmI6_to_NTSC_video_Msg()
{
    xgtmI5_to_NTSC_video( xgtm0A_Get_XGTM_State() );
    return NIL;
}

LVAL xgtmI7_to_NTSC_video_Fn()
{
    xgtmI5_to_NTSC_video( gt_stat );
    return NIL;
}

/* }}} */
/* {{{ xgtmJ0_to_normal_video -- Switch from NTSC signal generation.	*/

xgtmJ0_to_normal_video( state )
struct gt_stat_struct*  state;
{
    xllastarg();
    return (*GTterm_tbl[ state->terminal ].gt_to_normal_video)(state);
}
LVAL xgtmJ1_to_normal_video_Msg()
{
    xgtmJ0_to_normal_video( xgtm0A_Get_XGTM_State() );
    return NIL;
}

LVAL xgtmJ2_to_normal_video_Fn()
{
    xgtmJ0_to_normal_video( gt_stat );
    return NIL;
}


/* }}} */
/* {{{ xgtmJ5_Cursor_Move -- Move visible screen cursor.		*/

xgtmJ5_Cursor_Move(     state )
struct gt_stat_struct*  state;
{
    LVAL lv_x = xlgafixnum();
    int     x = getfixnum( lv_x );
    LVAL lv_y = xlgafixnum();
    int     y = getfixnum( lv_y );
    xllastarg();
    return (*GTterm_tbl[ state->terminal ].gt_cursor_move)(state,x,y);
}
LVAL xgtmJ6_Cursor_Move_Msg()
{
    xgtmJ5_Cursor_Move( xgtm0A_Get_XGTM_State() );
    return NIL;
}

LVAL xgtmJ7_Cursor_Move_Fn()
{
    xgtmJ5_Cursor_Move( gt_stat );
    return NIL;
}


/* }}} */
/* {{{ xgtmK0_Ring_Bell -- Make audible beep.				*/

xgtmK0_Ring_Bell(      state )
struct gt_stat_struct* state;
{
    xllastarg();
    return (*GTterm_tbl[ state->terminal ].gt_ring_bell)(state);
}
LVAL xgtmK1_Ring_Bell_Msg()
{
    xgtmK0_Ring_Bell( xgtm0A_Get_XGTM_State() );
    return NIL;
}

LVAL xgtmK2_Ring_Bell_Fn()
{
    xgtmK0_Ring_Bell( gt_stat );
    return NIL;
}

/* }}} */

/* {{{ (crib)								*/
#if CRIB

i4d20 _get_transform( m )
gt_mat*               m;
{
    *m = gt_stat->transform;
}



i4d21 _set_transform( m )
gt_mat*		      m;
{
    gt_stat->transform = *m;
    {
	Matrix sgi_m;
	int i,j;
	for     (i = 4;  i --> 0; ) {
	    for (j = 4;  j --> 0; ) {
		sgi_m[i][j] = m[i][j];
	    }
	}
	loadmatrix( s->trm.i4d.clip[i][j] );
	multmatrix( sgi_m                 ); /* pre-multiply */
    }
}



i4d22 _get_clipcube( pmin, pmax )
gt_pnt             *pmin,*pmax;
{
    *pmin = gt_stat->clip_min;
    *pmax = gt_stat->clip_max;
}



i4d23 _set_clipcube( pmin, pmax )
gt_pnt             *pmin,*pmax;
{
    register struct gt_stat_struct *s = gt_stat;
    gt_stat->clip_min = *pmin;
    gt_stat->clip_max = *pmax;

    /* The Iris hardware clips everything outside the */
    /* (-1,1)^3 cube, so we implement clipping by     */
    /* scaling the given volume into this cube:       */
    {
	/* First, clear matrix to zero: */
        int   i, j;
        for     (i = 4;  i --> 0;) {
	    for (j = 4;  j --> 0;) {
		s->trm.i4d.clip[i][j] = 0;
	    }
	}

	/* Now implement the scaling.  We also  */
	/* take this opportunity to flip our    */
        /* left-handed coordinates to match the */
        /* right-handed Iris convention:        */
        {
	    float xrange = pmax->x - pmin->x;
	    float yrange = pmax->y - pmin->y;
	    float zrange = pmax->z - pmin->z;

	    float xscale = 2.0 / xrange;
	    float yscale = 2.0 / yrange;
	    float zscale = 2.0 / zrange;

	    float xmid   =  (pmax->x + pmin->x) * 0.5;
	    float ymid   =  (pmax->y + pmin->y) * 0.5;
	    float zmid   =  (pmax->z + pmin->z) * 0.5;

	    s->trm.i4d.clip[0][0] =  xscale;
	    s->trm.i4d.clip[1][1] =  yscale;
	    s->trm.i4d.clip[2][2] = -zscale;

	    s->trm.i4d.clip[3][3] = 1.0         ;

	    s->trm.i4d.clip[4][0] = - xmid * xscale;
	    s->trm.i4d.clip[4][1] = - ymid * yscale;
	    s->trm.i4d.clip[4][2] =   zmid * zscale;
	}
    }
}



float i4d18 _get_opacity()
{
    return gt_stat->opacity;
}



i4d19 _set_opacity( o )
float              o; /* 0.0 -> 1.0 */
{
    if (opacity < 0.0 || opacity > 1.0) {
	fprintf(stderr,"iris4d.trm: bad opacity %g\n",o);
    } else {
	gt_stat->opacity = o;
        /*buggo! No action taken yet*/
    }
}



i4d24 _filled_rectangle( xmin,xmax, ymin,ymax )
int                     xmin,xmax, ymin,ymax;
{
    /*buggo! No action taken yet*/
}






i4d29 _set_FHUE_pixel_row( ph, count )
gt_fhue*                  ph;
int                           count;
{
    /*buggo! No action taken yet*/
}



i4d30 _set_FHUE_pixel_raster( pph, rows, cols )
gt_fhue**                    pph;
int				  rows, cols;
{
    /*buggo! No action taken yet*/
}



i4d31 _set_BHUE_pixel_raster( pph, rows, cols )
gt_bhue**                    pph;
int				  rows, cols;
{
    /*buggo! No action taken yet*/
}



i4d32 _screen_area_bytes( x_size, y_size )
int			 x_size, y_size;
{
    /*buggo! No action taken yet*/
}



i4d33 _screen_area_save( where, x_size, y_size )
char*                   where;
int			       x_size, y_size;
{
    /*buggo! No action taken yet*/
}



i4d34 _screen_area_restore( where, x_size, y_size )
char*                      where;
int				  x_size, y_size;
{
    /*buggo! No action taken yet*/
}



i4d35 _mouse_position( x, y )
int                  *x,*y;
{
}



i4d36 _blocking_input( event, value, x, y )
int                  *event,*value,*x,*y;
{
}



i4d37 _input_available()
{
}



i4d39 _get_onexit_fnfa( int(**fn)(), void**fa )
{
}



i4d40 _set_onexit_fnfa( int(*fn)(),  void*fa  )
{
}



i4d41 _get_redraw_fnfa( void(**fn)(), void**fa )
{
}



i4d42_set_redraw_fnfa( void(*fn)(),  void*fa  )
{
}



i4d43 _get_state()
{
}



i4d44 _set_state()
{
}



i4d45 _count_terminal_parameters()
{
}



i4d46 _get_terminal_parameter()
{
}



i4d47 _set_terminal_parameter()
{
}
#endif/*crib*/

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
