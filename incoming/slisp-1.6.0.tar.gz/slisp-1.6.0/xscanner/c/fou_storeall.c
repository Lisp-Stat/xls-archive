/*---------------------------------------------------------------------------

fou_storeall.c - UW/Seattle implementation of STORE ALL 	

For the UW/Seattle environment: Prism treatment planning system.

This file was developed under VAX/VMS, but is written in portable C, so it
could be compiled and used anywhere that Prism-format files are found.    These
are sequential text files where  each object and each attribute are indicated
by keywords.

In this implementation the data set is a single file and the data_id input
parameter is simply the file name. In the VMS world this is actually quite
flexible, since the VAX/VMS C environent interprets this string as a logical
name.  That means the input file can be anything you wish; you simply define
the logical name before calling this function, for example by typing a DCL
command as follows:

	$ define mydata dua0:[rtpt]sample-patient.dat

This is the only VMS-dependent behavior in the function.

This version writes some messages to the standard output as it goes.

NOTE - 1-Apr-1992 (no, this is not a joke) - The current implementation of
Store for Grid Values and Grid Geometry is little strange, in that each RTPT
instance of these two classes is stored in the data set as a separate instance
of a Prism object of class plan,  with nothing else in it except the slots for
the respective the RTPT object (Grid Values or Grid Geometry).   The two
instances have the same value for their NAME field, which allows you to match
them up.

This should not be a practical problem in the near term, because none of the
RTPT C tools currently under development stores these classes, they only read
them (Fetch All deals with these in a reasonable way).  

In fact, the only reason for implementating branches of Store All for these two
classes is to write back out what Fetch All read in, as a way of checking our
implementation of Fetch All.

---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 Revision History:

 Date             Pgmr                 Comments
 =============================================================================

8/ 7/91		J. Jacky		Begun; extracted from fetchall_driver.c
8/ 8/91		J. Jacky		put_object writes data for Point
8/ 9/91		J. Jacky		put_object writes data for Contour
8/13/91		J. Jacky		Add put_all_objects
8/13/91		J. Jacky		Completed support for Point, Contour,
					 Volume and Solid
20-Mar-1992     J. Jacky                New prototype compliant with TR-92-1.
					Extract repeated code fragments into
					 macros indent, indent2, oname, oend.
					Correct comment for lookup_keyword.
					Extract function put_volume.
					Consistent if-else-if- in put_object.
					Class macro from rtpt.h in put_object.
23-Mar-1992     J. Jacky                Don't use oname macro - doesn't work
26-Mar-1992  J. Jacky  Modify lookup_key to work with new format table
 1-Apr-1992  J. Jacky  Add support for Grid Values and Grid Geometry
 5-Apr-1992  J. Jacky  Finished (for now) with Grid Values and Grid Geometry;
			comment out almost all the printf's used for debugging
 5-Apr-1992  J. Jacky  Add support for Image, Image 2D, Image 3D.
17-Apr-1992  J. Jacky  Try using Jonathan Unger's bin-array.c (from Prism) 
			 to actually write the binary image arrays.
16-Jun-1992  J. Jacky  Finally fix error in writing grid values arrays;
			 new code for GRID VALUES copied from put_dose_matrix.c
22-Jun-1992  J. Jacky  Clear up confusion between nx (highest index in 
			 array) and grid_geom_p -> n_x (n of elements in array)
 1-Sep-1992  J. Jacky  Rename class macro to rtpt_class macro to avoid name
			clash with X code (first encountered in UNC's DRR tool)
 7-Oct-1992  J. Jacky  Change RTP:: to PRISM:: throughout per new Prism design.
		       Don't write Image ID field to file; not needed.
		       Check whether pixels (or voxels) pointer is NULL before
			attempting to write out 2D (or 3D) binary image array.
			GE image unpack program doesn't store image array in 
			image object; it just writes it out to the binary file, 
			sets pointer to NULL, and calls fou_fetchall to write
			description to image set file.
 8-Oct-1992  J. Jacky  Changes/additions to Image 2D per latest Prism file spec
			- Image ID field returns: original study slice number
			- size field for 2D is only a two-element list; 
			   thickness is a separate item.
			- 2D x-orient: #(1.0 0.0 0.0 1.0) for transverse 
			- 2D y-orient: #(0.0 -1.0 0.0 1.0) for transverse 
			- 2D pix-per-cm field
 9-Dec-1992  J. Unger  Add explicit type cast info to code to avoid warning
                        messages when compiled under eowyn's ansi c compiler.
24-Dec-1992  J. Unger  Modify portions of code which write transform array 
                        values so that they explicitly cast their values back 
                        to floats from large_floats, to insure that this data 
                        is written out correctly.
30-Dec-1992  J. Jacky  Add support for Beam, Beam Delivery System, Block
10-Aug-1993  J. Jacky  Handle NULL where string expected in Image 2D attrib's
                        id, descrip, date, time, scanner and units; Grid 
			Geom attribute name.
27-Oct-1993  J. Jacky  fclose the output data set at top level per
                        Gregg Tracton's advice.  
			Also, SAFEPRINT macro to guard against printing null
			pointers.
			Also, generate a new filename each time for binary
			image files written out
			Also, fake Prism's hidden x_orient etc.
 3-Feb-1994. J. Jacky   Don't fake x_orient etc. - print them out.
----------------------------------------------------------------------------*/

#include <stdio.h>	/* Declares FILE which is needed by rtpt.h */
#include <string.h>	/* We use some strcmp etc. but for for some reason
			/* it seems to work without this #include */

#include "rtpt.h"

/* Some simple macros to save typing and shorten the file */
#define  indent   for (i = 1; i <= spaces; i++) fputc(' ', fp)
#define  indent2  for (i = 1; i <= spaces + 2; i++) fputc(' ', fp)
#define  oend     fprintf(fp, ":END\n")

/* Can't get this one to work

#define oname(n) fprintf(fp, "PRISM::NAME \"%s\"\n", n)
              ^                                  ^   ^
*** And here's why it didn't work!  The use of n here - see
    - Gregg Tracton, 10/27/93 ****

Here's a source line:

  indent2; oname(point_p -> name);

And here's the result in the output file! (The PRISM::X stuff is from another
source line - what happens is, the \n isn't executed).  Probably something 
about quotes inside macros.  

  PRISM::NAME "prescription pt"point_p -> name  PRISM::X 0.000


*/ 

/* From Gregg T., 10/27/93 */

#define SAFEPRINT(STR) ((STR) ? (STR) : RTPT_ABSENT) 

/***************************************************************************

lookup_key. This function is used by put_object.  It returns the Prism keyword
corresponding to an RTPT class name, if there is one. If there is none, returns
the string "no match". 

This function is used to match the class name found in the in-memory RTPT data
structure (*not* in the file) with the *third* column in the keyword/class-name
table in rtpt.h. Then the keyword found in the *first* column in the matching
row is written to the output file.

This function is the inverse of the lookup_class, used by fou_fetchall.  

This is similar to the example in K&R 2nd ed, section 6.3, "Arrays of
Structures", pps. 132 - 133

This function uses typdef prism_rtpt_class_t, #define'd integer N_RTPT_CLASSES,
and the initialized array prism_rtpt_classes, all defined in rtpt.h

******************************************************************************/

char *lookup_key(char *class_s)

{
   int i;

   /* printf("Calling lookup_key; seeking match with %s\n", class_s); */

   /* This is C idiom for processing consecutive array elements, 
      K&R 2nd ed. p 61 */

   for (i = 0;
	((i < N_RTPT_CLASSES) && 
	 (strcmp(class_s, prism_rtpt_classes[i].found_class) != 0));
	i++) {

/*    printf("i %d, prism_key = |%s|, rtpt_class = |%s|\n",
	i, prism_rtpt_classes[i].prism_key, prism_rtpt_classes[i].found_class);
*/
   }

   return prism_rtpt_classes[i].prism_key;
}

/***************************************************************************

put_volume.  This function is called by put_object.  It writes a single volume,
including all its contained contours, to the output file.   Since the contours
are themselves objects, this procedure is indirectly recursive; it calls
put_all_objects, which calls put_object for each contour.

This is written as an independent function, rather than an inline case branch
in put_object, because it is used for writing out both volumes and solids.

Input params are the file pointer, a pointer to a volume,  and the number of
leading spaces to indent the keyword at the beginning of the object (this is
used in the expansion of the indent2 macro).

******************************************************************************/

int put_volume(FILE *fp, rtpt_volume_t *volume_p, int spaces)

{
        int i, pstatus;

	indent2; fprintf(fp, "PRISM::NAME \"%s\"\n", 
			 SAFEPRINT(volume_p -> name));
	indent2; fprintf(fp, "PRISM::CONTOURS\n"); /* Series of contours */

	/* Gregg T notes that -> next_p should be -> set_element_p !?!? */
	pstatus = put_all_objects(fp, volume_p -> contours_p -> next_p, 
							spaces + 4); 

				/* nested contours, indent 4 spaces */
	if (pstatus != RTPT_ST_OK) return pstatus; /* put_volume failed */
	indent2; oend; /* End of series of contours */
        return RTPT_ST_OK; /* If we got this far, we succeeded */
}


/***************************************************************************

put_object. This function is called by put_all_objects. It writes a single
object to the output file.  Since objects can contain other objects, it is
indirectly recursive; it may call put_all_objects (which calls put_object).

This is the workhorse function that actually writes the data to the file; it
has to know how each class is represented in the file.   It's structured as
a great big switch statement, one case for each class.

Input params are the file pointer, a pointer to a  set element (which then
points to the struct containing the object data), and the number of leading
spaces to indent the keyword at the beginning of the object.  Also input is the
top-level object list, so this function can match Grid Geometries with the
corresponding Grid Values.

Returns an integer status value. 

******************************************************************************/

int put_object(FILE *fp, rtpt_set_t *current_obj, rtpt_set_t *object_list,
								int spaces)

{
   int pstatus, i;
   rtpt_id_t *class_name_p;
   rtpt_string_t current_class;

   char *hounsfield = RTPT_UNITS_HOUNSFIELD; /* must match corresponding ... */
   char *no_name = RTPT_ABSENT;		     /* items in fou_fetchall get_.. */

   rtpt_point_t *point_p;
   rtpt_contour_t *contour_p;
   rtpt_block_t *block_p;
   rtpt_solid_t *solid_p;
   rtpt_volume_t *volume_p;
   rtpt_grid_geom_t *grid_geom_p;
   rtpt_grid_values_t *grid_values_p;
   rtpt_image_t *image_p;
   rtpt_image_2d_t *image_2d_p;
   rtpt_image_3d_t *image_3d_p;
   rtpt_beam_t *beam_p;
   rtpt_s_beam_t *s_beam_p;
   rtpt_c_beam_t *c_beam_p;
   rtpt_vj_beam_t *vj_beam_p;
   rtpt_m_beam_t *m_beam_p;
   rtpt_beam_delivery_t *beam_deliv_p;
   rtpt_s_beam_delivery_t *s_beam_deliv_p;
   rtpt_c_beam_delivery_t *c_beam_deliv_p;
   rtpt_vj_beam_delivery_t *vj_beam_deliv_p;
   rtpt_m_beam_delivery_t *m_beam_deliv_p;

   int iv,nv,ic; /* Used with Contour */

   /* Used with Grid Values */
   int iplane, irow, icol, ie, ne;
   int nx, ny, nz; /* Highest array indices; each dimension goes 0..nx (etc.).  
			Not to be confused with n of elements.  These are
			assigned as follows: 

			   nx = (grid_geom_p -> n_x) - 1; 

			etc.  See TR-91-1 p. 31. */
   rtpt_set_t *obj_p;
   rtpt_string_t obj_class;
   rtpt_id_t *obj_class_name_p;
   rtpt_grid_geom_t *obj_geom_p;

   for (i = 1; i <= spaces; i++) putchar(' '); /* No macro; std. out, not fp */
   printf("  Entering put_object\n"); 

   /* Must account for NULL objects */
   if (current_obj -> set_element_p == NULL) {
      for (i = 1; i <= spaces; i++) putchar(' '); /* No macro, ditto */
      printf("   Element type in this link is NULL\n"); 
      } else {

/* 

Don't know if this is legitimate or not... At compile time the type of the 
structure pointed to by set_element_p isn't known; it's declared as *void.  
Here I'm saying it's an rtpt_id_t.  Actually it isn't, but we do know that it
is a struct whose first element is always an rtpt_id_t.  

Legitimate or not, it does compile and run and produce the hoped-for output.

*/
      /* Figure out what class this object is */
      class_name_p = current_obj -> set_element_p; /* Is this a hack? */
      current_class = class_name_p -> type;

      for (i = 1; i <= spaces; i++) putchar(' '); /* No macro, std out */
      printf("   Element type in this link is %s\n", current_class);

      /* Print class name, properly indented, on a line by itself */
      indent; fprintf(fp, "PRISM::%s\n", lookup_key(current_class));

      /* 
         Do things specific to this class 

         RTPT class names are strings, not integers 
         so we can't use switch - must use if-then-else 
      */

      if rtpt_class(current_class, RTPT_POINT) {
	point_p = current_obj -> set_element_p;
	indent2; fprintf(fp, "PRISM::NAME \"%s\"\n", point_p -> name); 
	indent2; fprintf(fp, "PRISM::X %.3f\n", point_p -> x);
	indent2; fprintf(fp, "PRISM::Y %.3f\n", point_p -> y);
	indent2; fprintf(fp, "PRISM::Z %.3f\n", point_p -> z);
	} /* end POINT */

      /* Block is almost the same as contour */
      else if (rtpt_class(current_class, RTPT_CONTOUR) ||
		rtpt_class(current_class, RTPT_BLOCK)) {

        if rtpt_class(current_class, RTPT_CONTOUR) {
		contour_p = current_obj -> set_element_p;
		}
        else if rtpt_class(current_class, RTPT_BLOCK) {
		block_p = current_obj -> set_element_p;
		contour_p = &(block_p -> contour);
		indent2; fprintf(fp, "PRISM::TRANSMISSION %.3f\n", 
						block_p -> transmission);
		}

	indent2; fprintf(fp, "PRISM::Z %.3f\n", 
		contour_p -> poly.trans.transform[2][3]);
	indent2; fprintf(fp, "PRISM::VERTICES ("); /* note opening "(" */
	iv = 0; 
	nv = 3; /* room for only 3 vertices on first line */
	while (iv < (int) contour_p -> poly.nvertices) { 
	   for (ic = 0; 
                 (ic < nv) && (iv < (int) contour_p->poly.nvertices); ic++) {
		fprintf(fp, "(%.3f %.3f) ",
			contour_p -> poly.vertices_p[iv].x,
			contour_p -> poly.vertices_p[iv].y); 
		iv++;
		}
	   if (iv == contour_p -> poly.nvertices) fprintf(fp, ")"); 
	   fprintf(fp, "\n");
	   nv = 5; /* after first line print 5 vertices per line */
	   } 
	} /* end CONTOUR */

      else if rtpt_class(current_class, RTPT_VOLUME) {
	volume_p = current_obj -> set_element_p;
        pstatus = put_volume(fp, volume_p, spaces);
        if (pstatus != RTPT_ST_OK) return pstatus; /* put_volume failed */
	} /* end VOLUME */

      else if rtpt_class(current_class, RTPT_SOLID) {
	solid_p = current_obj -> set_element_p; 
	indent2; fprintf(fp, "PRISM::DENSITY %.3f\n", solid_p -> density);
        pstatus = put_volume(fp, &(solid_p -> volume), spaces);
        if (pstatus != RTPT_ST_OK) return pstatus; /* put_volume failed */
	} /* end SOLID */

      else if rtpt_class(current_class, RTPT_GRID_GEOM) {

      /* Note this is specific to the Grid Geom associated with a dose array, 
	 because of the Prism keywords.  Grid geom's associated with 
	 images must be handled by a different branch */

      /* Remeber to cast transform entries back to float to ensure that they
         are written out correctly.  jmu */

	grid_geom_p = current_obj -> set_element_p; 

	if (grid_geom_p && grid_geom_p -> name) {
	   indent2; fprintf(fp, "PRISM::NAME \"%s\"\n", grid_geom_p -> name);}
	indent2; fprintf(fp, "PRISM::DOSE-ARRAY-SIZE (%.3f %.3f %.3f)\n",
	 grid_geom_p -> x_size, grid_geom_p -> y_size, grid_geom_p -> z_size);
	indent2; fprintf(fp, "PRISM::DOSE-ORIGIN #(%.3f %.3f %.3f 1.0)\n",
	 (float) grid_geom_p -> trans.transform[0][3], 
	 (float) grid_geom_p -> trans.transform[1][3], 
	 (float) grid_geom_p -> trans.transform[2][3]);
	} /* end RTPT_GRID_GEOM */

      else if rtpt_class(current_class, RTPT_GRID_VALUES) {

	grid_values_p = current_obj -> set_element_p; 
	indent2; fprintf(fp, "PRISM::NAME \"%s\"\n", grid_values_p -> grid);

	/* Must find corresponding Grid Geom. to get plane, row, col counts */
	grid_geom_p = NULL;
	for (obj_p = object_list; obj_p != NULL; obj_p = obj_p -> next_p) {
	   if (obj_p -> set_element_p != NULL) {
		obj_class_name_p = obj_p -> set_element_p; 
		obj_class = obj_class_name_p -> type;
		if rtpt_class(obj_class, RTPT_GRID_GEOM) {
		   obj_geom_p = obj_p -> set_element_p;
		   if (strcmp(obj_geom_p -> name, grid_values_p -> grid) == 0){
			grid_geom_p = obj_geom_p;
		   } /* If Grid Geom name matches Grid Values grid string */
		} /* If this is a Grid Geom object */
	   } /* if not null link */
         } /* end for loop walking linked list */

	/* Make sure we got the right geometry */
printf("\n    name in corresponding grid geometry: \"%s\"\n", 
						grid_geom_p -> name); 
printf("    size in grid geometry: %d planes, %d rows, %d cols\n",  
		 grid_geom_p -> n_z, grid_geom_p -> n_y, grid_geom_p -> n_x);

	/* Note distinction here between highest array indices 
	   nx, etc. and number of array elements n_x, etc.
	   Array indices go 0..nx (etc.), so number of elements
	   are nx + 1 (etc.).  See TR-91-1 p. 31. */

       nz = (grid_geom_p -> n_z) - 1; 
       ny = (grid_geom_p -> n_y) - 1;
       nx = (grid_geom_p -> n_x) - 1;

       if (grid_geom_p != NULL) {

	fprintf(fp, "PRISM::DOSE-ARRAY #3A"); /* opening string*/
	ne = 6; /* on this initial keyword line print no more than 6 elts */ 

	fprintf(fp, "("); 	
   	for (iplane = 0; iplane <= nz; iplane++) {
	   fprintf(fp, "("); 	
	   for (irow = 0; irow <= ny; irow++) {
	      fprintf(fp, "("); 	
	      icol = 0; /* Odd loop structure because rows include linebreaks */
	      while (icol <= nx) { /* loop over rows */
		/* Innermost loop, writes one line of text to the file -
			generally, only a part of a matrix row */
		for (ie = 0; (ie < ne) && (icol <= nx); ie ++) {

			fprintf(fp, " %.3f", *((grid_values_p -> values)
			 + iplane*(nx + 1)*(ny + 1) + irow*(nx + 1) + icol));

			icol++; /* can't forget this! ie++ in loop header */
			} /* end loop over a single text line */
		if (icol < nx) fprintf(fp, "\n"); 
				/* Linebreak only if *not* at end of row */
		ne = 10; /* After first text line, 10 elements per line */
		} /* end while icol */
		fprintf(fp, ")"); /* close row --- always */
		if (irow == ny) fprintf(fp, ")"); /* plane */
		if ((irow == ny) && /* close whole array */
		    (iplane == nz)) fprintf(fp, ")"); 
		fprintf(fp, "\n"); /* break line only after all parens */

	       } /* end for irow --- reached end of array plane */
	   } /* end for iplane - reached end of array */

       } /* end if grid_geom_p != NULL */

	} /* end RTPT_GRID_VALUES */

      else if (rtpt_class(current_class, RTPT_IMAGE) 
	|| rtpt_class(current_class, RTPT_IMAGE_2D)
	|| rtpt_class(current_class, RTPT_IMAGE_3D)) {

       if rtpt_class(current_class, RTPT_IMAGE) { 
	image_p = current_obj -> set_element_p; 
	}
       else if rtpt_class(current_class, RTPT_IMAGE_2D) { 
	image_2d_p = current_obj -> set_element_p; 
	image_p = &(image_2d_p -> image); 
	}
       else if rtpt_class(current_class, RTPT_IMAGE_3D) { 
	image_3d_p = current_obj -> set_element_p; 
	image_p = &(image_3d_p -> image);
	}

	grid_geom_p = &(image_p -> grid);

        if (image_p && image_p -> id) {
	  indent2; fprintf(fp, "PRISM::ID %s\n", image_p -> id);}
                                                            /* no quotes */
        if (image_p && image_p -> descrip) {
	  indent2; fprintf(fp, "PRISM::DESCRIPTION \"%s\"\n", 
			   image_p -> descrip); }
        if (image_p && image_p -> date) {
	  indent2; fprintf(fp, "PRISM::ACQ-DATE \"%s\"\n", image_p -> date); }
        if (image_p && image_p -> time) {
	  indent2; fprintf(fp, "PRISM::ACQ-TIME \"%s\"\n", image_p -> time); }
        if (image_p && image_p -> scanner) {
	  indent2; fprintf(fp, "PRISM::SCANNER-TYPE \"%s\"\n", 
			   image_p -> scanner); }
	indent2; fprintf(fp, "PRISM::HOSP-NAME \"%s\"\n", image_p -> hosp_name);

	if (image_p -> type == RTPT_IMTYPE_CT) {
	   indent2; fprintf(fp, "PRISM::IMG-TYPE \"X-ray CT\"\n");
	} else { 
	   indent2; fprintf(fp, "PRISM::IMG-TYPE \"Other than X-ray CT\"\n");
	}	/* fill this out later ... */


      /* Remeber to cast transform entries back to float to ensure that they
         are written out correctly.  jmu */

	indent2; fprintf(fp, "PRISM::ORIGIN #(%.3f %.3f %.3f 1.0)\n",
	 (float) grid_geom_p -> trans.transform[0][3], 
	 (float) grid_geom_p -> trans.transform[1][3], 
	 (float) grid_geom_p -> trans.transform[2][3]);

	if rtpt_class(current_class, RTPT_IMAGE_2D) { 
	   indent2; fprintf(fp, "PRISM::SIZE (%.3f %.3f)\n",
		grid_geom_p -> x_size, grid_geom_p -> y_size);
    	}
        else if rtpt_class(current_class, RTPT_IMAGE_3D) { 
	   indent2; fprintf(fp, "PRISM::SIZE (%.3f %.3f %.3f)\n",
		grid_geom_p -> x_size, grid_geom_p -> y_size, 
					grid_geom_p -> z_size);
	}

       /* Gregg T warns this should be high - low + 1, not range_high */
	indent2; fprintf(fp, "PRISM::RANGE %d\n", image_p -> range_high); 

	/* Units - Hounsfield is a special case */
        if (image_p && image_p -> units && hounsfield) {
	 if (strcmp(image_p -> units, hounsfield) == 0) {
	   indent2; fprintf(fp, "PRISM::UNITS  \"H - 1024\"\n");
	  } else {
	 indent2; fprintf(fp, "PRISM::UNITS \"%s\"\n", image_p -> units); 
	 }
        }

	if rtpt_class(current_class, RTPT_IMAGE_2D) { 

	   indent2; fprintf(fp, "PRISM::THICKNESS %.3f\n", 
						image_2d_p -> thickness);

	   /* Gregg T notes that x_orient etc. are hidden fields which
	      could well be uninitialized.  The intent was to generate these
	      from transformation matrix.  For DRR it doesn't matter */
	   indent2; fprintf(fp, "PRISM::X-ORIENT #(%.3f %.3f %.3f %.3f)\n",
		 image_2d_p -> x_orient[0], image_2d_p -> x_orient[1],
		 image_2d_p -> x_orient[2], image_2d_p -> x_orient[3]);

	   indent2; fprintf(fp, "PRISM::Y-ORIENT #(%.3f %.3f %.3f %.3f)\n",
		 image_2d_p -> y_orient[0], image_2d_p -> y_orient[1],
		 image_2d_p -> y_orient[2], image_2d_p -> y_orient[3]); 
		 
	   /* For now just comment this whole block out and fake it 
	      indent2; fprintf(fp, "PRISM::X-ORIENT #(%.3f %.3f %.3f %.3f)\n",
	      0.0, 0.0, 0.0, 0.0);
	      indent2; fprintf(fp, "PRISM::Y-ORIENT #(%.3f %.3f %.3f %.3f)\n",
	      0.0, 0.0, 0.0, 0.0);
	      */

	   indent2; fprintf(fp, "PRISM::PIX-PER-CM %.3f\n", 
			    image_2d_p -> pix_per_cm);

	   /* Gregg T notes we need to generate a unique filename for all 
	      of these new images (DRR's etc) we might be writing out */
	   if (!image_p -> filename)
	     {
	       char im_filename[L_tmpnam];
	       image_p -> filename = tmpnam(im_filename);
	     }

	   indent2; fprintf(fp, "PRISM::PIXELS (\"%s\" %d %d)\n",
		image_p -> filename, grid_geom_p -> n_x, grid_geom_p -> n_y);

	   if (image_2d_p -> pixels != NULL)
	      write_bin_array_2(image_p -> filename, grid_geom_p -> n_x, 
		grid_geom_p -> n_y, image_2d_p -> pixels);
		/* From Jonathan Unger's bin-array.c, written for Prism */

	}
       else if rtpt_class(current_class, RTPT_IMAGE_3D) { 

	   indent2; fprintf(fp, "PRISM::VOXELS (\"%s\" %d %d %d)\n",
		image_p -> filename, grid_geom_p -> n_z, 
			grid_geom_p -> n_x, grid_geom_p -> n_y);

	   if (image_3d_p -> voxels != NULL)
              write_bin_array_3(image_p -> filename, grid_geom_p -> n_x, 
		grid_geom_p -> n_y, grid_geom_p -> n_z, image_3d_p -> voxels);
		/* From Jonathan Unger's bin-array.c, written for Prism */
	}

	} /* end Image classes */

      /*  etc.. add support for other classes here */	                                    

      else if (rtpt_class(current_class, RTPT_BEAM) 
	|| rtpt_class(current_class, RTPT_S_BEAM)
	|| rtpt_class(current_class, RTPT_C_BEAM)
	|| rtpt_class(current_class, RTPT_VJ_BEAM)
	|| rtpt_class(current_class, RTPT_M_BEAM)) {

       if rtpt_class(current_class, RTPT_BEAM) { 
	beam_p = current_obj -> set_element_p; 
	}
       else if rtpt_class(current_class, RTPT_S_BEAM) { 
	s_beam_p = current_obj -> set_element_p; 
	beam_p = &(s_beam_p -> beam); 
	}
       else if rtpt_class(current_class, RTPT_C_BEAM) { 
	c_beam_p = current_obj -> set_element_p; 
	beam_p = &(c_beam_p -> beam); 
	}
       else if rtpt_class(current_class, RTPT_VJ_BEAM) { 
	vj_beam_p = current_obj -> set_element_p; 
	beam_p = &(vj_beam_p -> beam); 
	}
       else if rtpt_class(current_class, RTPT_M_BEAM) { 
	m_beam_p = current_obj -> set_element_p; 
	beam_p = &(m_beam_p -> beam); 
	}

	indent2; fprintf(fp, "PRISM::NAME \"%s\"\n", beam_p -> name); 
	indent2; fprintf(fp, "PRISM::MACHINE \"%s\"\n", beam_p -> delivery);
	indent2; fprintf(fp, "PRISM::DISPLAY-COLOR %s\n", 
						beam_p -> display_color); 
	indent2; fprintf(fp, "PRISM::MONITOR-UNITS %.3f\n", beam_p -> units); 
	indent2; fprintf(fp, "PRISM::TABLE-POSITION #(%.3f %.3f %.3f 1.0)\n",
			(beam_p -> table_position[0]),
			(beam_p -> table_position[1]),
			(beam_p -> table_position[2]));
	indent2; fprintf(fp, "PRISM::COUCH-LONGITUDINAL %.1f\n", 
							beam_p -> longit); 
	indent2; fprintf(fp, "PRISM::COUCH-LATERAL %.1f\n", beam_p -> lateral); 
	indent2; fprintf(fp, "PRISM::COUCH-HEIGHT %.1f\n", beam_p -> height); 
	indent2; fprintf(fp, "PRISM::GANTRY-ANGLE %.1f\n", beam_p -> g_angle); 
	indent2; fprintf(fp, "PRISM::ARC-SIZE %.1f\n", beam_p -> arc_size); 

	if rtpt_class(current_class, RTPT_S_BEAM) { 
	   indent2; fprintf(fp, "PRISM::COLLIMATOR\n");
	   spaces = spaces + 2;
	   indent2; fprintf(fp, "PRISM::SYMMETRIC-JAW-COLL\n");
	   spaces = spaces + 2;
	   indent2; fprintf(fp, "PRISM::X %.2f\n", s_beam_p -> coll_x);
	   indent2; fprintf(fp, "PRISM::Y %.2f\n", s_beam_p -> coll_y);
	   spaces = spaces - 2;
           indent2; oend;
	   spaces = spaces - 2;
	}

       else if rtpt_class(current_class, RTPT_C_BEAM) { 
	   indent2; fprintf(fp, "PRISM::COLLIMATOR\n");
	   spaces = spaces + 2;
	   indent2; fprintf(fp, "PRISM::COMBINATION-COLL\n");
	   spaces = spaces + 2;
	   indent2; fprintf(fp, "PRISM::Y-SUP %.2f\n",
						c_beam_p -> coll_sup);
	   indent2; fprintf(fp, "PRISM::Y-INF %.2f\n",
						c_beam_p -> coll_inf);
	   indent2; fprintf(fp, "PRISM::X %.2f\n", 
						c_beam_p -> coll_width);
           spaces = spaces - 2;
	   indent2; oend;
	   spaces = spaces - 2;
	}

       else if rtpt_class(current_class, RTPT_VJ_BEAM) { 
	   indent2; fprintf(fp, "PRISM::COLLIMATOR\n");
	   spaces = spaces + 2;
	   indent2; fprintf(fp, "PRISM::VARIABLE-JAW-COLL\n");
	   spaces = spaces + 2;
	   indent2; fprintf(fp, "PRISM::X-SUP %.2f\n",
						vj_beam_p -> coll_supx);
	   indent2; fprintf(fp, "PRISM::X-INF %.2f\n",
						vj_beam_p -> coll_infx);
	   indent2; fprintf(fp, "PRISM::Y-SUP %.2f\n",
						vj_beam_p -> coll_supy);
	   indent2; fprintf(fp, "PRISM::Y-INF %.2f\n",
						vj_beam_p -> coll_infy);
           spaces = spaces - 2;
	   indent2; oend;
	   spaces = spaces - 2;
	}

       else if rtpt_class(current_class, RTPT_M_BEAM) { 
	   indent2; fprintf(fp, "PRISM::COLLIMATOR\n");
	   spaces = spaces + 2;
	   indent2; fprintf(fp, "PRISM::MULTILEAF-COLL\n");
	   spaces = spaces + 2;

	   /* We haven't defined how to print out the leaves yet 12/30/92 */

           spaces = spaces - 2;
	   indent2; oend;
	   spaces = spaces - 2;

	} /* end different collimator classes */

	indent2; fprintf(fp, "PRISM::COLLIMATOR-ANGLE %.1f\n", 
						beam_p -> coll_angle); 
	indent2; fprintf(fp, "PRISM::N-TREATMENTS %d\n", 
						beam_p -> n_treatments);

	if (strcmp(beam_p -> wedge, no_name) != 0) {
	   indent2; fprintf(fp, "PRISM::WEDGE-NUMBER %s\n", beam_p -> wedge); 
	   indent2; fprintf(fp, "PRISM::WEDGE-ORIENTATION %.1f\n", 
							beam_p -> orientation); 
	}

	if (beam_p -> blocks_p != NULL) {
	  indent2; fprintf(fp, "PRISM::BLOCKS\n"); /* Series of blocks */
	   pstatus = put_all_objects(fp, beam_p -> blocks_p -> next_p, 
							spaces + 4); 
				/* nested contours, indent 4 spaces */
	   if (pstatus != RTPT_ST_OK) return pstatus; /* put_all_... failed */
	   indent2; oend; /* End of series of blocks */
	}

      } /* end beams */

      else if (rtpt_class(current_class, RTPT_BEAM_DELIV) 
	|| rtpt_class(current_class, RTPT_S_BEAM_DELIV)
	|| rtpt_class(current_class, RTPT_C_BEAM_DELIV)
	|| rtpt_class(current_class, RTPT_VJ_BEAM_DELIV)
	|| rtpt_class(current_class, RTPT_M_BEAM_DELIV)) {

       if rtpt_class(current_class, RTPT_BEAM_DELIV) { 
	beam_deliv_p = current_obj -> set_element_p; 
	}
       else if rtpt_class(current_class, RTPT_S_BEAM_DELIV) { 
	s_beam_deliv_p = current_obj -> set_element_p; 
	beam_deliv_p = &(s_beam_deliv_p -> beam_deliv); 
	}
       else if rtpt_class(current_class, RTPT_C_BEAM_DELIV) { 
	c_beam_deliv_p = current_obj -> set_element_p; 
	beam_deliv_p = &(c_beam_deliv_p -> beam_deliv); 
	}
       else if rtpt_class(current_class, RTPT_VJ_BEAM_DELIV) { 
	vj_beam_deliv_p = current_obj -> set_element_p; 
	beam_deliv_p = &(vj_beam_deliv_p -> beam_deliv); 
	}
       else if rtpt_class(current_class, RTPT_M_BEAM_DELIV) { 
	m_beam_deliv_p = current_obj -> set_element_p; 
	beam_deliv_p = &(m_beam_deliv_p -> beam_deliv); 
	}

	indent2; fprintf(fp, "PRISM::NAME \"%s\"\n",beam_deliv_p -> unit_name); 

	indent2; fprintf(fp, "PRISM::PARTICLE  ");
	if (beam_deliv_p -> modality == RTPT_BEAM_PHOTON) {
			fprintf(fp, "PHOTONS\n");
		} 
	else if (beam_deliv_p -> modality == RTPT_BEAM_ELECTRON) {
			fprintf(fp, "ELECTRONS\n");
		}
	else if (beam_deliv_p -> modality == RTPT_BEAM_NEUTRON) {
			fprintf(fp, "NEUTRONS\n");
		}
	else if (beam_deliv_p -> modality == RTPT_BEAM_PROTON) {
			fprintf(fp, "PROTONS\n");
		} else {			
			fprintf(fp, "UNKNOWN\n");
		}

	indent2; fprintf(fp, "PRISM::ENERGY %.0f\n", beam_deliv_p -> energy); 

	if rtpt_class(current_class, RTPT_S_BEAM_DELIV) { 
	   indent2; fprintf(fp, "PRISM::COLLIMATOR  SYMMETRIC-JAW-COLL\n");
	}
       else if rtpt_class(current_class, RTPT_C_BEAM_DELIV) { 
	   indent2; fprintf(fp, "PRISM::COLLIMATOR  COMBINATION-COLL\n");
	}
       else if rtpt_class(current_class, RTPT_VJ_BEAM_DELIV) { 
	   indent2; fprintf(fp, "PRISM::COLLIMATOR  VARIABLE-JAW-COLL\n");
	}
       else if rtpt_class(current_class, RTPT_M_BEAM_DELIV) { 
	   indent2; fprintf(fp, "PRISM::COLLIMATOR  MULTILEAF-COLL\n");
	}
       else { 
	   indent2; fprintf(fp, "PRISM::COLLIMATOR  %s\n", RTPT_UNKNOWN);
	}

	indent2; fprintf(fp, "PRISM::CAL-DISTANCE %.1f\n", 
						beam_deliv_p -> source_axis); 
	indent2; fprintf(fp, "PRISM::PENUMBRA %.2f\n", 
						beam_deliv_p -> source_size); 

       } /* end beam delivery systems */

      /* etc. ... Add support for any additional classes here */

      /* Print end object marker, properly indented, on a line by itself */
      indent; oend; 

      } /* end else not NULL */

   return RTPT_ST_OK; /* If we got this far, we succeeded */
}
/****************************************************************************

put_all_objects.   Writes to output data file all objects from the current
pointer to the end of the list.  Called from the main Store All function, also
called by put_object to write out nested objects, e.g. the contours within a
solid.

Input params are the file pointer, a pointer to a  set element (which is the 
head of the list of objects), and the number of leading spaces to indent the
keyword at the beginning of the object.  This is 0 for top-level objects (e.g.
solids), and 4 for objects nested at the first level (e.g. contours withing
solids).

Returns an integer status value. 

*****************************************************************************/

int put_all_objects(FILE *fp, rtpt_set_t *object_list, int spaces)

{
  int i, pstatus;
  rtpt_set_t *obj_p;


   for (i = 1; i <= spaces; i++) putchar(' '); /* use a macro? */
   printf(" Entering put_all_objects\n"); 

  /* Walk linked list of objects */
  for (obj_p = object_list; obj_p != NULL; obj_p = obj_p -> next_p) {
      pstatus = put_object(fp, obj_p, object_list, spaces); 
      if (pstatus != RTPT_ST_OK) return pstatus; /* put_object failed */
   } /* end for loop walking linked list */

  return RTPT_ST_OK;  /* If we got this far, success! */
}

/****************************************************************************

The Store All function.  Writes items to a sequential text file where 
each object and each attribute are indicated by keywords.

*****************************************************************************/

enum rtpt_status_e fou_storeall(        /* output: status */
    rtpt_string_t      data_id,         /* input: data set identifier */
    rtpt_set_t       * objects_p        /* input: objects */
    )

{

  FILE *fp; 
  rtpt_set_t *current_obj;
  int pstatus;
  
  /* For now, data set name is VMS logical name for input file.
     Try to open data set.  If open fails, then exit.   
     Code for opening file copied from K&R 2nd ed p. 162. */

  if ((fp = fopen(data_id, "w")) == NULL) {
    printf("fou_storeall: Can't open %s\n", data_id);
    return RTPT_ST_FAIL;

  } else {

    printf("Opened data set %s\n", data_id);
    pstatus = put_all_objects(fp, objects_p, 0); /* top-level; spaces = 0 */
    fclose(fp);
    if (pstatus != RTPT_ST_OK) return pstatus; /* put_object failed */
  } /* end else opened file */

  return RTPT_ST_OK;  /* If we got this far, success! */
}
