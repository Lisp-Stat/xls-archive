/*--------------------------------------------------------------------------

fou_util.c 

Utility functions used by more than one of Fetch All, Store All, driver.

20-Mar-1992	J. Jacky	Extract alloc_set from fou_driver.c
18-Jun-1992	J. Jacky	Extract list_objects from fou_driver.c
14-Dec-1992     J. Unger        Add explicit cast to return stmt of alloc_set()
----------------------------------------------------------------------------*/

#include <stdio.h>      /* Needed here because it defines NULL */

#include "rtpt.h"

/*---------------------------------------------------------------------------

alloc_set - Parameterless function that simply returns a pointer to a newly
allocated and initialized instance of rtpt_set_t

-----------------------------------------------------------------------------*/

struct rtpt_set_t *alloc_set() 

{
 rtpt_set_t *set_p;

 set_p = (rtpt_set_t *) malloc (sizeof(rtpt_set_t));
 set_p -> obj_id.type = RTPT_SET;
 set_p -> next_p = NULL;
 set_p -> set_element_p = NULL;
 return (struct rtpt_set_t *) set_p;
}


/*---------------------------------------------------------------------------

list_objects - print on stdout the class names of each object in a list

----------------------------------------------------------------------------*/

void list_objects(rtpt_set_t * objects_p) 

{
 rtpt_set_t *current_obj;
 rtpt_id_t *class_name_p;

  /* Walk linked list of objects */
  for (current_obj = objects_p; /* point at head of list */
   	current_obj != NULL; current_obj = current_obj -> next_p) {

   /* Must account for NULL objects */
   if (current_obj -> set_element_p == NULL) {
      printf(" Element type in this link is NULL\n"); 
      } else {

/* 

Don't know if this is legitimate or not... At compile time the type of the 
structure pointed to by set_element_p isn't know; it's declared as *void.  
Here I'm saying it's an rtpt_id_t.  Actually it isn't, but we do know that it
is a struct whose first element is always an rtpt_id_t.  

(later) Golly, it works!

*/
     
      class_name_p = current_obj -> set_element_p; /* Is this a hack? */
      printf(" Element type in this link is %s\n", 
		class_name_p -> type);
      } /* end else not NULL */
   } /* end for loop walking linked list */
}
