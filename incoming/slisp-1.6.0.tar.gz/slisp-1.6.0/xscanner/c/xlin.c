/* {{{ xlin.c -- various line operations for scanner    	     CrT*/

/*************************************************************************
*
* Author:       Kevin Hinshaw
* Created:      94Sep17
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 96Jul18 kph  Adding support for line extraction from 3D volumes.     */
/* 96Jun06 kph  Fixed bug in line extraction that caused stepping in    */
/*              wrong direction in some cases.  Also included checks    */
/*              for horizontal/vertical lines that could have been      */
/*              causing divide-by-zero crashes.                         */
/* 95Sep18 kph  One year and a day later!  Changed line extraction to   */
/*              work on non-integer coordinates.  Moved old version     */
/*              to xlin24_extractLineBresenham.                         */
/* 94Sep17 kph  Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cf2v.h"
#include <math.h>

extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();
extern LVAL xgrl01_Get_A_XGRL();
extern LVAL xsry09_Copy();
extern LVAL xthl74_GetProp();
extern LVAL *xgrl13_pArrayList();

extern LVAL k_pixelred;
extern LVAL k_pixelgreen;
extern LVAL k_pixelblue;
extern LVAL k_setarray;
extern LVAL k_getarray;
extern LVAL k_adjustarray;
extern LVAL k_show;
extern LVAL k_pixelrelation;
extern LVAL k_new;
extern LVAL k_get;
extern LVAL lv_xgrl;
extern LVAL lv_xf8v;
extern LVAL lv_xflv;
extern LVAL lv_x32v;
extern LVAL lv_xf2v;

/* all the keywords I define here (some may exist elsewhere) */
extern LVAL k_xstart;
extern LVAL k_ystart;
extern LVAL k_zstart;
extern LVAL k_xend;
extern LVAL k_yend;
extern LVAL k_zend;
extern LVAL k_pointx;
extern LVAL k_pointy;
extern LVAL k_pointz;
extern LVAL k_xmin;
extern LVAL k_ymin;
extern LVAL k_zmin;
extern LVAL k_xmax;
extern LVAL k_ymax;
extern LVAL k_zmax;
extern LVAL k_image;
extern LVAL k_volume;
extern LVAL k_intensity;
extern LVAL k_original_intensity;
extern LVAL k_voxels;

LVAL xlin20_extractLineFromImage(LVAL, 
				 double, double, double, double,
				 double, double, double, double);
LVAL xlin21_extractLineFromVolume(LVAL, 
				  double, double, double, 
				  double, double, double, 
				  double, double, double, 
				  double, double, double);
void xlin22_computeGradient(unsigned char *, int *, int);
void xlin23_computeIntensityGradient(CSRY_UNSIGNED16 *, int *, int);
LVAL xlin24_extractLineBresenham(LVAL, int, int, int, int);

/* }}} */
/* {{{ --- macros ---                                                   */

/* image bounds check macro (inclusive for min, exclusive for max) */
#define XLIN_IMAGE_INBOUNDS(x, y, xmin, ymin, xmax, ymax) \
  (((x) >= (xmin)) && \
   ((x) <  (xmax)) && \
   ((y) >= (ymin)) && \
   ((y) <  (ymax)))
 
/* volume bounds check macro (inclusive for min, exclusive for max) */
#define XLIN_VOLUME_INBOUNDS(x, y, z, xmin, ymin, zmin, xmax, ymax, zmax) \
  (((x) >= (xmin)) && \
   ((x) <  (xmax)) && \
   ((y) >= (ymin)) && \
   ((y) <  (ymax)) && \
   ((z) >= (zmin)) && \
   ((z) <  (zmax)))

/* macros to compute maximum of two and three numbers, respectively */

#define XLIN_MAX(x, y) (((x) > (y) ? (x) : (y)))

#define XLIN_MAX3(x, y, z) (XLIN_MAX((x), (XLIN_MAX((y),(z)))))

/* }}} */

/* {{{ --- Public fns ---						*/

/* }}} */
/* {{{ xlin07_Get_X_And_Y_Dimensions					*/

xlin07_Get_X_And_Y_Dimensions( px, py, lv )
int                           *px,*py;
LVAL                                   lv;
{   csry_rec* h = (csry_rec*) gobjimmbase( lv );
    if (h->rank != 2)  xlerror("Image array not 2-D!",lv);
    *py = h->dim[0];
    *px = h->dim[1];
}

/* }}} */
/* {{{ xlin08_Get_Volume_Dimensions					*/

xlin08_Get_Volume_Dimensions( px, py, pz, lv )
int                          *px,*py, *pz;
LVAL                                      lv;
{   csry_rec* h = (csry_rec*) gobjimmbase( lv );
    if (h->rank != 3)  xlerror("Volume array not 3D!",lv);
    *pz = h->dim[0];
    *py = h->dim[1];
    *px = h->dim[2];
}

/* }}} */
/* {{{ xlin15_Extract_Line_Fn	                	         	*/

/* Lisp name: XLIN-EXTRACT-LINE
 *
 * Top-level function for extracting a line from an image or a volume
 * dataset.  It grabs the calling parameters and then hands them off
 * to the function that does the extraction work.
 *
 * (Should the [x|y|z]_[min|max] parameters also be specifiable
 * by keyword?)  
 */

LVAL xlin15_Extract_Line_Fn() {

  LVAL     lv_dataset = NIL;        /* image GRL or volume property list */
  LVAL     lv_num;                  /* dummy var for reading numbers */
  LVAL     lv_line;                 /* GRL for extracted line */
  LVAL     lv_dataset_type = NIL;   /* type of dataset that was specified */
  LVAL     lv_voxels;               /* voxel GRL for volumes */
  int      x_size, y_size;          /* image dimensions (in pixels) */
  double   x_start = 0.0;           /* line endpoints */
  double   y_start = 0.0;
  double   z_start = 0.0;
  double   x_end   = 0.0;
  double   y_end   = 0.0;
  double   z_end   = 0.0;
  double   x_min;                   /* image/volume bounds */
  double   y_min;
  double   z_min;
  double   x_max;
  double   y_max;
  double   z_max;
  
  int        toProt = 5;
  xlstkcheck(toProt);
  xlsave(lv_dataset);
  xlsave(lv_num);
  xlsave(lv_line);
  xlsave(lv_dataset_type);
  xlsave(lv_voxels);

  /* read the arguments */
  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();

    if        (key == k_xstart) {
      x_start = (double) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    }
    else if   (key == k_ystart) {
      y_start = (double) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    }
    else if   (key == k_zstart) {
      z_start = (double) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    }
    else if   (key == k_xend) {
      x_end = (double) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    }
    else if   (key == k_yend) {
      y_end = (double) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    }
    else if   (key == k_zend) {
      z_end = (double) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    }
    else if   (key == k_image) {
      lv_dataset_type = k_image;
      lv_dataset = xgrl01_Get_A_XGRL();  /* image GRL */
    }
    else if   (key == k_volume) {
      lv_dataset_type = k_volume;
      lv_dataset = xlgalist();           /* 3D dataset property list */
    }
    else {
      xlerror("XLIN-EXTRACT-LINE: bad keyword", key);
    }
  }

  /* decide what type of dataset we got and handle it appropriately */
  if (!lv_dataset) {
    xlerror("XLIN-EXTRACT-LINE: must specify dataset with :IMAGE or :VOLUME");
  }

  /* IMAGE */
  else if (lv_dataset_type == k_image) {
    /* set default image boundaries (one pixel per sample unit) */
    xlin07_Get_X_And_Y_Dimensions( &x_size, &y_size, lv_dataset );
    x_max = (double) x_size;
    y_max = (double) y_size;

    /* get size properties stored with the image */
    lv_num = xsendmsg1( lv_dataset, k_get, k_xmin);
    if      (  fixp(lv_num)) { x_min = (FLOTYPE) getfixnum(lv_num); }
    else if (floatp(lv_num)) { x_min =           getflonum(lv_num); }
    else                     { xlerror("Non-numeric value for image bound"); }
    lv_num = xsendmsg1( lv_dataset, k_get, k_ymin);
    if      (  fixp(lv_num)) { y_min = (FLOTYPE) getfixnum(lv_num); }
    else if (floatp(lv_num)) { y_min =           getflonum(lv_num); }
    else                     { xlerror("Non-numeric value for image bound"); }
    lv_num = xsendmsg1( lv_dataset, k_get, k_xmax);
    if      (  fixp(lv_num)) { x_max = (FLOTYPE) getfixnum(lv_num); }
    else if (floatp(lv_num)) { x_max =           getflonum(lv_num); }
    else                     { xlerror("Non-numeric value for image bound"); }
    lv_num = xsendmsg1( lv_dataset, k_get, k_ymax);
    if      (  fixp(lv_num)) { y_max = (FLOTYPE) getfixnum(lv_num); }
    else if (floatp(lv_num)) { y_max =           getflonum(lv_num); }
    else                     { xlerror("Non-numeric value for image bound"); }

    /* do the real work */
    lv_line = xlin20_extractLineFromImage(lv_dataset, 
					  x_start, y_start, 
					  x_end, y_end, 
					  x_min, y_min, 
					  x_max, y_max);
  }

  /* VOLUME */
  else if (lv_dataset_type == k_volume) {
    /* pull out the GRL of voxels */
    /* (may want to do this in extractLineFromVolume instead) */

    lv_voxels = xthl74_GetProp(&lv_dataset, k_voxels, NULL, 1);
    xgrl0h_Must_Be_A_XGRL(lv_voxels);

    /* set default voxel boundaries -- for now, use [-1,1] for each */
    /* axis, but this should be changed to use machine coordinates  */

    x_min = -1.0;  y_min = -1.0;  z_min = -1.0;
    x_max =  1.0;  y_max =  1.0;  z_max =  1.0;

    /* do the real work */
    lv_line = xlin21_extractLineFromVolume(lv_voxels, 
					   x_start, y_start, z_start,
					   x_end, y_end, z_end,
					   x_min, y_min, z_min,
					   x_max, y_max, z_max);
  }

  /* unknown dataset type */
  else {
    xlerror("XLIN-EXTRACT-LINE: bad dataset type");
  }

  xlpopn(toProt);
  return lv_line;
}

/* }}} */
/* {{{ xlin16_Compute_Gradient_Fn		                	*/

/* Lisp name:  XLIN-COMPUTE-GRADIENT
 *
 * Top-level function for computing gradient info from a line grl.
 * This is usually used on the output of XLIN-EXTRACT-LINE.
 */

LVAL xlin16_Compute_Gradient_Fn() {

  LVAL           lv_line, lv_line_red, lv_line_green, lv_line_blue;
  LVAL           lv_grad, lv_grad_red, lv_grad_green, lv_grad_blue;
  LVAL           lv_grad_x, lv_grad_y, lv_grad_z;
  LVAL           lv_line_intensity, lv_grad_intensity;
  csry_rec       *h;
  int            length;
  unsigned char  *line;       /* R/G/B value array */
  CSRY_UNSIGNED16 *int_line;  /* intensity array */
  int            *grad;       /* gradient array:                     */
                              /* Would signed 16-bit integers work?  */
                              /* Range should be [-512,512] for RGB, */
                              /* [-8192, 8192] for intensity.        */

  int        toProt = 13;
  xlstkcheck(toProt);
  xlsave(lv_line);
  xlsave(lv_line_red);
  xlsave(lv_line_green);
  xlsave(lv_line_blue);
  xlsave(lv_line_intensity);
  xlsave(lv_grad);
  xlsave(lv_grad_red);
  xlsave(lv_grad_green);
  xlsave(lv_grad_blue);
  xlsave(lv_grad_intensity);
  xlsave(lv_grad_x);
  xlsave(lv_grad_y);
  xlsave(lv_grad_z);

  /* Read our arguments: */
  lv_line = xgrl01_Get_A_XGRL();
  xllastarg();

  /* fetch line's length */
  h = (csry_rec*) gobjimmbase( lv_line );
  length = h->dim[0];

  /* fetch line's RGB bitplanes */
  xthl3a_GetPixelRedGreenBlueIfPresent(
	 &lv_line_red, &lv_line_green, &lv_line_blue, lv_line);

  /* fetch line's intensity bitplane, if it has one */
  xlin30_GetIntensityIfPresent(&lv_line_intensity, lv_line);

  /* create gradient grl and the coordinate bitplanes */
  lv_grad = xsendmsg1( lv_xgrl, k_new, cvfixnum(length) );
  lv_grad_x = xsry09_Copy( xsendmsg1(lv_line, k_getarray, k_pointx) );
  lv_grad_y = xsry09_Copy( xsendmsg1(lv_line, k_getarray, k_pointy) );
  xsendmsg2( lv_grad, k_setarray, k_pointx, lv_grad_x);
  xsendmsg2( lv_grad, k_setarray, k_pointy, lv_grad_y);
  if (xsendmsg2(lv_line, k_getarray, k_pointz, NULL)) {
    lv_grad_z = xsry09_Copy( xsendmsg1(lv_line, k_getarray, k_pointz) );
    xsendmsg2( lv_grad, k_setarray, k_pointz, lv_grad_z);
  }

  /* handle whichever bitplanes are in the line */
  if (lv_line_red) {
    lv_grad_red = xsendmsg1( lv_x32v, k_new, cvfixnum(length) );
    xsendmsg2( lv_grad, k_setarray, k_pixelred, lv_grad_red );
    line = (unsigned char*) (csry_base( lv_line_red ));
    grad = (int *)          (csry_base( lv_grad_red ));
    xlin22_computeGradient(line, grad, length);
  }

  if (lv_line_green) {
    lv_grad_green = xsendmsg1( lv_x32v, k_new, cvfixnum(length) );
    xsendmsg2( lv_grad, k_setarray, k_pixelgreen, lv_grad_green );
    line = (unsigned char*) (csry_base( lv_line_green ));
    grad = (int *)          (csry_base( lv_grad_green ));
    xlin22_computeGradient(line, grad, length);
  }

  if (lv_line_blue) {
    lv_grad_blue = xsendmsg1( lv_x32v, k_new, cvfixnum(length) );
    xsendmsg2( lv_grad, k_setarray, k_pixelblue, lv_grad_blue );
    line = (unsigned char*) (csry_base( lv_line_blue ));
    grad = (int *)          (csry_base( lv_grad_blue ));
    xlin22_computeGradient(line, grad, length);
  }

  if (lv_line_intensity) {
    lv_grad_intensity = xsendmsg1( lv_x32v, k_new, cvfixnum(length) );
    xsendmsg2( lv_grad, k_setarray, k_intensity, lv_grad_intensity );
    int_line = (CSRY_UNSIGNED16 *) (csry_base( lv_line_intensity ));
    grad     = (int *)             (csry_base( lv_grad_intensity ));
    xlin23_computeIntensityGradient(int_line, grad, length);
  }

  xlpopn(toProt);
  return lv_grad;
}

/* }}} */
/* {{{ xlin20_extractLineFromImage     					*/

/* This routine will extract a line from an existing image 
 * (pixel relation).  In addition to any of the three pixel arrays
 * (:PIXEL-GREEN, :PIXEL-RED, :PIXEL-BLUE) that are in the image,
 * the line relation will have :PIXEL-X and :PIXEL-Y arrays to 
 * store the original coordinates of the pixels.
 */

/* In an attempt to minimize the number of floating point multiplications,
 * this function maintains the current sample location in both the default
 * coordinate space (variables 'x' and 'y') and in pixel coordinate space
 * (variables 'xp' and 'yp').  Step sizes in both spaces ('x_step' and 
 * 'y_step' for default, 'xp_step' and 'yp_step' for pixel) are computed
 * so that most of the work in the main sampling loop uses additions
 * rather than multiplications.
 */ 

LVAL xlin20_extractLineFromImage( 
  LVAL lv_im, 
  double x1,    double y1, 
  double x2,    double y2,
  double x_min, double y_min, 
  double x_max, double y_max )
{
  int     src_planes;
  LVAL    lv_line;                            /* GRL for extracted line */
  LVAL    lv_line_red;                        /* line's sampling arrays */
  LVAL    lv_line_green;
  LVAL    lv_line_blue;                       
  LVAL    lv_line_x, lv_line_y;               /* arrays for line GRL coords */
  LVAL    lv_im_red, lv_im_green, lv_im_blue; /* image's pixel planes */
  int     length = 0;                         /* length of line GRL */
  int     xp_size, yp_size;                   /* image dimensions */
  int     i = 0;                              /* index into line GRL */
  int     index = 0;                          /* loop index */
  int     offset;                             /* index into the 1D image array */
  float   *x_line, *y_line;                   /* local pointers to line coords */
  double  dx = x2 - x1;                       /* line's length in x */
  double  dy = y2 - y1;                       /* line's length in y */
  double  dxp, dyp;                           /* line's length (in pixels) */
  double  x, y;                               /* current sample location */
  double  xp, yp;                             /* current location (in pixels) */
  double  x_step, y_step;                     /* step sizes between samples */
  double  xp_step, yp_step;                   /* step sizes (in pixels) */
  double  x1p, y1p, x2p, y2p;                 /* line endpoints (in pixels) */
  double  x_size = x_max - x_min;             /* image size in x dimension */
  double  y_size = y_max - y_min;             /* image size in y dimension */
  char    last_inbounds = 0;                  /* flag for line clipping */
  unsigned char  *r_im,   *b_im,   *g_im;     /* pixel planes from image */
  unsigned char  *r_line, *b_line, *g_line;   /* pixel planes from line */
  unsigned char  DEBUG = 0;                   /* flag for debug comments */

  int        toProt = 10;
  xlstkcheck(toProt);
  xlprotect(lv_im);
  xlsave(lv_line);
  xlsave(lv_line_green);
  xlsave(lv_line_red);
  xlsave(lv_line_blue);
  xlsave(lv_line_x);
  xlsave(lv_line_y);
  xlsave(lv_im_green);
  xlsave(lv_im_red);
  xlsave(lv_im_blue);

  /***************************/
  /*                         */
  /* graphics relation setup */
  /*                         */
  /***************************/

  /* get image dimensions */
  xlin07_Get_X_And_Y_Dimensions( &xp_size, &yp_size, lv_im );

  /* compute rise and run of line in pixel space */
  x1p = ((x1 - x_min) * xp_size) / x_size;
  y1p = ((y1 - y_min) * yp_size) / y_size;
  x2p = ((x2 - x_min) * xp_size) / x_size;
  y2p = ((y2 - y_min) * yp_size) / y_size;
  dxp = x2p - x1p;
  dyp = y2p - y1p;

  /* compute the length of the line relation and the 
   * step size in the x and y directions (for both regular
   * and pixel coordinates)
   */ 

  /* Should probably allow some tolerance around 0 */

  /* vertical line */
  if (dxp == 0) {
    length  = (int) ceil(fabs(dyp)) + 1;
    yp_step = ((dyp >= 0) ? 1.0 : -1.0);
    xp_step = 0;
    y_step  = (y_size / yp_size) * yp_step;
    x_step  = 0;
  }
  /* horizontal line */
  else if (dyp == 0) {
    length  = (int) ceil(fabs(dxp)) + 1;
    xp_step = ((dxp >= 0) ? 1.0 : -1.0);
    yp_step = 0;
    x_step  = (x_size / xp_size) * xp_step;
    y_step  = 0;
  }
  /* step along x */
  else if (fabs(dxp) > fabs(dyp)) {
    length  = (int) ceil(fabs(dxp)) + 1;
    xp_step = ((dxp >= 0) ? 1.0 : -1.0);
    yp_step = dyp / fabs(dxp);
    x_step  = (x_size / xp_size) * xp_step;
    y_step  = (y_size / yp_size) * yp_step;
  }
  /* step along y */
  else {
    length  = (int) ceil(fabs(dyp)) + 1;
    yp_step = ((dyp >= 0) ? 1.0 : -1.0);
    xp_step = dxp / fabs(dyp);
    y_step  = (y_size / yp_size) * yp_step;
    x_step  = (x_size / xp_size) * xp_step;
  }

  if (DEBUG) {
    printf("=================================================================\n");
    printf("line:    (%lf,%lf) to (%lf,%lf) (image)\n", x1, y1, x2, y2);
    printf("         (%lf,%lf) to (%lf,%lf) (pixel)\n", x1p, y1p, x2p, y2p);
    printf("bounds:  (%lf,%lf) to (%lf,%lf)\n", x_min, y_min, x_max, y_max);
    printf("length:  %d\n", length);
    printf("steps:   %lf and %lf (image)\n", x_step, y_step);
    printf("         %lf and %lf (pixel)\n", xp_step, yp_step);
  }

  /* Create our pixel relation for the extracted line: */
  lv_line = xsendmsg1( lv_xgrl, k_new, cvfixnum(length) );

  /* Create arrays for new line relation: */
  lv_line_x = xsendmsg1( lv_xflv, k_new, cvfixnum(length) );
  lv_line_y = xsendmsg1( lv_xflv, k_new, cvfixnum(length) );

  /* Insert coordinate arrays into line relation: */
  xsendmsg2( lv_line, k_setarray, k_pointx, lv_line_x);
  xsendmsg2( lv_line, k_setarray, k_pointy, lv_line_y);
  x_line = (float *) (csry_base( lv_line_x ));
  y_line = (float *) (csry_base( lv_line_y ));

  /* Process red/grn/blu image-plane arrays in our graphic relation: */
  src_planes = xthl3a_GetPixelRedGreenBlueIfPresent(
	    &lv_im_red, &lv_im_green, &lv_im_blue, lv_im);

  if (lv_im_red  ) {
    lv_line_red   = xsendmsg1( lv_xf8v, k_new, cvfixnum(length) );
    xsendmsg2( lv_line, k_setarray, k_pixelred,   lv_line_red   );
    r_im =  (unsigned char*) (csry_base( lv_im_red   ));
    r_line = (unsigned char*) (csry_base( lv_line_red ));
  }
  if (lv_im_green) {
    lv_line_green = xsendmsg1( lv_xf8v, k_new, cvfixnum(length) );
    xsendmsg2( lv_line, k_setarray, k_pixelgreen, lv_line_green );
    g_im  = (unsigned char*) (csry_base( lv_im_green ));
    g_line = (unsigned char*) (csry_base( lv_line_green ));
  }
  if (lv_im_blue ) {
    lv_line_blue  = xsendmsg1( lv_xf8v, k_new, cvfixnum(length) );
    xsendmsg2( lv_line, k_setarray, k_pixelblue,  lv_line_blue  );
    b_im  = (unsigned char*) (csry_base( lv_im_blue  ));
    b_line = (unsigned char*) (csry_base( lv_line_blue ));
  }

  /***************************/
  /*                         */
  /*      sampling code      */
  /*                         */
  /***************************/

  /* initialize x and y, in regular and pixel coordinates */
  x = x1;
  y = y1;
  xp = x1p;
  yp = y1p;

  /* start sampling */
  for (index = 0; index < length; index++) {

    if (DEBUG) printf("\n%2d:  x=%0.3lf  y=%0.3lf  xp=%0.3lf  yp=%0.3lf", 
			index, x, y, xp, yp);

    /* add this location if it is inside the image boundaries */
    if (XLIN_IMAGE_INBOUNDS(x, y, x_min, y_min, x_max, y_max)) {

      last_inbounds = 1;
/* compute floor instead of rounding? */
      offset = rint(yp) * xp_size + rint(xp);

      if (DEBUG) printf("  offset=%d  green=%hd", offset, g_im[offset]);

/* why were these being cast as float values? */
;      if (lv_im_red)   r_line[i] = (float) r_im[offset];
;      if (lv_im_green) g_line[i] = (float) g_im[offset];
;      if (lv_im_blue)  b_line[i] = (float) b_im[offset];
      if (lv_im_red)   r_line[i] = r_im[offset];
      if (lv_im_green) g_line[i] = g_im[offset];
      if (lv_im_blue)  b_line[i] = b_im[offset];

      x_line[i] = (float) x;
      y_line[i] = (float) y;
      i++;
    }

    /* stop if we move outside the image */
    else if (last_inbounds) {
      break;
    }

    /* always advance the coordinates */
    x  += x_step;
    y  += y_step;
    xp += xp_step;
    yp += yp_step;
  }
  
  if (DEBUG) printf("\n");

  /* fix up the grl arrays if the line was clipped */
  if (i < length) {
    if (DEBUG) printf("CLIPPING grl arrays from %d to %d...\n", length, i);
    xsendmsg1( lv_line, k_adjustarray, cvfixnum(i) );
  }

  xlpopn(toProt);
  
  return lv_line;
}

/* }}} */
/* {{{ xlin21_extractLineFromVolume					*/

/* This routine will extract a line from an existing voxel dataset.
 * In addition to the :INTENSITY array, the line relation will have
 * :PIXEL-X, :PIXEL-Y, and :PIXEL-Z arrays to store the original
 * coordinates of the pixels. 
 */

/* In an attempt to minimize the number of floating point
 * multiplications, this function maintains the current sample
 * location in both the default coordinate space (variables x, y, z)
 * and in pixel coordinate space (variables xp, yp, zp).  Step sizes
 * in both spaces (x/y/z_step for default, x/y/zp_step for pixel) are
 * computed so that most of the work in the main sampling loop uses
 * additions rather than multiplications. 
 */

LVAL xlin21_extractLineFromVolume( 
  LVAL lv_dataset, 
  double x1,    double y1,    double z1,
  double x2,    double y2,    double z2,
  double x_min, double y_min, double z_min,
  double x_max, double y_max, double z_max )
{
  LVAL    lv_line;                            /* GRL for extracted line */
  LVAL    lv_line_intensity;                  /* line's sampling array */
  LVAL    lv_line_x, lv_line_y, lv_line_z;    /* arrays for line GRL coords */
  LVAL    lv_dataset_intensity;               /* dataset's intensity array */
  int     length = 0;                         /* length of line GRL */
  int     xp_size, yp_size, zp_size;          /* dataset dimensions */
  int     i = 0;                              /* index into line GRL */
  int     index = 0;                          /* loop index */
  int     offset;                             /* index into 1D dataset array */
  float   *x_line, *y_line, *z_line;          /* local pointers to line coords */
  double  dx = x2 - x1;                       /* line's length in x */
  double  dy = y2 - y1;                       /* line's length in y */
  double  dz = z2 - z1;                       /* line's length in z */
  double  dxp, dyp, dzp;                      /* line's length (in pixels) */
  double  dmax, dmaxp;                        /* line's extreme length */
  double  x, y, z;                            /* current sample location */
  double  xp, yp, zp;                         /* current location (in pixels) */
  double  x_step, y_step, z_step;             /* step sizes between samples */
  double  xp_step, yp_step, zp_step;          /* step sizes (in pixels) */
  double  x1p, y1p, x2p, y2p, z1p, z2p;       /* line endpoints (in pixels) */
  double  x_size = x_max - x_min;             /* dataset size in x dimension */
  double  y_size = y_max - y_min;             /* dataset size in y dimension */
  double  z_size = z_max - z_min;             /* dataset size in z dimension */
  char    last_inbounds = 0;                  /* flag for line clipping */
  CSRY_UNSIGNED16 *dataset_intensity;         /* voxel plane from dataset */
  CSRY_UNSIGNED16 *line_intensity;            /* voxel plane from line */
  unsigned char  DEBUG = 0;                   /* flag for debug comments */

/*  unsigned char  *r_im,   *b_im,   *g_im;     /* pixel planes from image */
/*  unsigned char  *r_line, *b_line, *g_line;   /* pixel planes from line */

  int        toProt = 7;
  xlstkcheck(toProt);
  xlprotect(lv_dataset);
  xlsave(lv_line);
  xlsave(lv_line_x);
  xlsave(lv_line_y);
  xlsave(lv_line_z);
  xlsave(lv_line_intensity);
  xlsave(lv_dataset_intensity);

  /***************************/
  /*                         */
  /* graphics relation setup */
  /*                         */
  /***************************/

  /* get dataset dimensions */
  xlin08_Get_Volume_Dimensions( &xp_size, &yp_size, &zp_size, lv_dataset );

  /* compute rise and run of line in pixel space */
  x1p = ((x1 - x_min) * xp_size) / x_size;
  y1p = ((y1 - y_min) * yp_size) / y_size;
  z1p = ((z1 - z_min) * zp_size) / z_size;
  x2p = ((x2 - x_min) * xp_size) / x_size;
  y2p = ((y2 - y_min) * yp_size) / y_size;
  z2p = ((z2 - z_min) * zp_size) / z_size;
  dxp = x2p - x1p;
  dyp = y2p - y1p;
  dzp = z2p - z1p;

  /* compute the length of the line relation and the step size in the
   * x, y, and z directions (for both regular and pixel coordinates) 
   */

  dmaxp = XLIN_MAX3(fabs(dxp),fabs(dyp),fabs(dzp));
/*  dmax =  XLIN_MAX3(fabs(dx),fabs(dy),fabs(dz)); */


  /* endpoints are the same (allow some tolerance around 0?) */
  if (dmaxp == 0) {
    xp_step = 0;
    yp_step = 0;
    zp_step = 0;
    x_step  = 0;
    y_step  = 0;
    z_step  = 0;
    length = 1;
  }
  else {
    xp_step = dxp / dmaxp;
    yp_step = dyp / dmaxp;
    zp_step = dzp / dmaxp;
    x_step  = dx  / dmaxp;
    y_step  = dy  / dmaxp;
    z_step  = dz  / dmaxp;
    length  = (int) ceil(fabs(dmaxp)) + 1;
  }

  if (DEBUG) {
    printf("=================================================================\n");
    printf("line:    (%0.3lf,%0.3lf,%0.3lf) to (%0.3lf,%0.3lf,%0.3lf) (native)\n", 
	   x1, y1, z1, x2, y2, z2);
    printf("         (%0.3lf,%0.3lf,%0.3lf) to (%0.3lf,%0.3lf,%0.3lf) (voxel)\n", 
	   x1p, y1p, z1p, x2p, y2p, z2p);
    printf("bounds:  (%0.3lf,%0.3lf,%0.3lf) to (%0.3lf,%0.3lf,%0.3lf)\n", 
	   x_min, y_min, z_min, x_max, y_max, z_max);
    printf("length:  %d\n", length);
    printf("steps:   %0.3lf, %0.3lf, %0.3lf (native)\n", x_step, y_step, z_step);
    printf("         %0.3lf, %0.3lf, %0.3lf (voxel)\n", xp_step, yp_step, zp_step);
  }

  /* Create our pixel relation for the extracted line: */
  lv_line = xsendmsg1( lv_xgrl, k_new, cvfixnum(length) );

  /* Create arrays for new line relation: */
  lv_line_x = xsendmsg1( lv_xflv, k_new, cvfixnum(length) );
  lv_line_y = xsendmsg1( lv_xflv, k_new, cvfixnum(length) );
  lv_line_z = xsendmsg1( lv_xflv, k_new, cvfixnum(length) );

  /* Insert coordinate arrays into line relation: */
  xsendmsg2( lv_line, k_setarray, k_pointx, lv_line_x);
  xsendmsg2( lv_line, k_setarray, k_pointy, lv_line_y);
  xsendmsg2( lv_line, k_setarray, k_pointz, lv_line_z);
  x_line = (float *) (csry_base( lv_line_x ));
  y_line = (float *) (csry_base( lv_line_y ));
  z_line = (float *) (csry_base( lv_line_z ));

   /* pull out the intensity array from the dataset.  If it has been */
  /* rotated, then we want the :original-intensity array.           */
  lv_dataset_intensity =
    xthl74_GetProp( xgrl13_pArrayList(lv_dataset), 
		   k_original_intensity, NULL, 1 );
  if (!lv_dataset_intensity) {
    lv_dataset_intensity =
      xthl74_GetProp( xgrl13_pArrayList(lv_dataset), 
		     k_intensity, NULL, 1 );
  }
  /* make sure the intensity array is the right type */
  xlinEk_Error_If_Not_12BitFloatArray( lv_dataset_intensity, k_intensity );

  /* set up the line GRL with an intensity array */
  lv_line_intensity   = xsendmsg1( lv_xf2v, k_new, cvfixnum(length) );
  xsendmsg2( lv_line, k_setarray, k_intensity, lv_line_intensity );
  dataset_intensity = (CSRY_UNSIGNED16 *) (csry_base(lv_dataset_intensity));
  line_intensity    = (CSRY_UNSIGNED16 *) (csry_base(lv_line_intensity));


  /***************************/
  /*                         */
  /*      sampling code      */
  /*                         */
  /***************************/

  /* initialize x and y, in regular and pixel coordinates */
  x  = x1;
  y  = y1;
  z  = z1;
  xp = x1p;
  yp = y1p;
  zp = z1p;

  /* start sampling */
  for (index = 0; index < length; index++) {

    if (DEBUG) {
      printf("%2d:  ", index);
      printf(  "x =%0.3lf  y =%0.3lf  z =%0.3lf", x, y, z);
      printf("  xp=%0.3lf  yp=%0.3lf  zp=%0.3lf\n", xp, yp, zp);
    }

/* NOTE: this macro was designed with integer values in mind, so it */
/* returns NULL when a value is equal to an upper bound.  Since we now */
/* allow floating point values, we might want to change that.  Some */
/* extra tricks might be needed to accomodate that change, but it */
/* would avoid the problem of having lines dropped completely if they */
/* fall within one of the volume's bounding planes. */

    /* if location is inside the dataset boundaries, add it to the line */
    if (XLIN_VOLUME_INBOUNDS(x, y, z, 
			     x_min, y_min, z_min, 
			     x_max, y_max, z_max)) {

      last_inbounds = 1;
      offset = (int) (floor(xp) + xp_size * ( floor(yp) + yp_size * floor(zp) ));

      if (DEBUG) printf("     offset=%d  intensity=%hd\n", 
			offset, dataset_intensity[offset]);

      line_intensity[i] = dataset_intensity[offset];
      x_line[i] = (float) x;
      y_line[i] = (float) y;
      z_line[i] = (float) z;
      i++;
    }

    /* stop if we move outside the dataset */
    else if (last_inbounds) {
      break;
    }

    /* always advance the coordinates */
    x  += x_step;
    y  += y_step;
    z  += z_step;
    xp += xp_step;
    yp += yp_step;
    zp += zp_step;
  }
  
  if (DEBUG) printf("\n");

  /* fix up the grl arrays if the line was clipped */
  if (i < length) {
    if (DEBUG) printf("CLIPPING grl arrays from %d to %d...\n", length, i);
    xsendmsg1( lv_line, k_adjustarray, cvfixnum(i) );
  }

  xlpopn(toProt);
  
  return lv_line;
}

/* }}} */
/* {{{ xlin22_computeGradient						*/

/* computes a simple gradient along the line by convolving the
 * values with the mask (-1, 0, 1)
 */

void xlin22_computeGradient(unsigned char *line, 
			    int           *grad, 
			    int            n)
{
  int  i;

  if (n == 0) 
    return;

  else if (n==1) {
    grad[0] = 0;
    return;
  }

  /* boundary pixels -- assume that: line[-1] = line[0]
                                     line[n]  = line[n-1]   */
  grad[0]   = line[1]   - line[0];
  grad[n-1] = line[n-1] - line[n-2];

  for (i = 1; i < n-1; i++)
    grad[i] = line[i+1] - line[i-1];
}

/* }}} */
/* {{{ xlin23_computeIntensityGradient			       		*/

/* computes a simple gradient along the line by convolving the
 * values with the mask (-1, 0, 1).
 * 
 * (Identical to xlin22_computeGradient, except for type of the
 * arguments.)
 */

void xlin23_computeIntensityGradient(CSRY_UNSIGNED16 *line, 
				     int             *grad, 
				     int              n)
{
  int  i;

  if (n == 0) 
    return;

  else if (n==1) {
    grad[0] = 0;
    return;
  }

  /* boundary pixels -- assume that: line[-1] = line[0]
                                     line[n]  = line[n-1]   */
  grad[0]   = line[1]   - line[0];
  grad[n-1] = line[n-1] - line[n-2];

  for (i = 1; i < n-1; i++)
    grad[i] = line[i+1] - line[i-1];
}

/* }}} */
/* {{{ xlin24_extractLineBresenham     					*/

/* This routine will extract a line from an existing image 
 * (pixel relation).  In addition to any of the three pixel arrays
 * (:PIXEL-GREEN, :PIXEL-RED, :PIXEL-BLUE) that are in the image,
 * the line relation will have :PIXEL-X and :PIXEL-Y arrays to 
 * store the original coordinates of the pixels.
 *
 * This routine uses Bresenham's algorithm to generate the points
 * on the line.  (This assumes, of course, that pixel coordinates
 * are integers.)  It is also set up to clip the lines based on 
 * the image boundaries.
 *
 */

LVAL xlin24_extractLineBresenham( LVAL lv_im, int x1, int y1, int x2, int y2 )
{
  int    length;
  int    x_size;
  int    y_size;
  int    src_planes;
  LVAL   lv_line;
  LVAL   lv_line_red, lv_line_green, lv_line_blue, lv_line_x, lv_line_y;
  LVAL   lv_im_red, lv_im_green, lv_im_blue;
  int    dx, dy, p, const1, const2, step;
  int    x = x1, y = y1, i = 0;
  int    offset;
  float  slope;
  char   last_inbounds;
  unsigned char  *r_im,   *b_im,   *g_im;    /* pixel planes from image */
  unsigned char  *r_line, *b_line, *g_line;  /* pixel planes from line */
  int            *x_line, *y_line;
  int j, found;
  unsigned char  DEBUG = 0;


  int        toProt = 10;
  xlstkcheck(toProt);
  xlprotect(lv_im);
  xlsave(lv_line);
  xlsave(lv_line_green);
  xlsave(lv_line_red);
  xlsave(lv_line_blue);
  xlsave(lv_line_x);
  xlsave(lv_line_y);
  xlsave(lv_im_green);
  xlsave(lv_im_red);
  xlsave(lv_im_blue);

  /* compute how long the line grl needs to be */
  dx = abs(x1 - x2);
  dy = abs(y1 - y2);
  length = ((dx > dy) ? (dx + 1) : (dy + 1));

  /* Create our pixel relation for the extracted line: */
  lv_line = xsendmsg1( lv_xgrl, k_new, cvfixnum(length) );

  /* Create arrays for new line relation: */
  lv_line_x = xsendmsg1( lv_x32v, k_new, cvfixnum(length) );
  lv_line_y = xsendmsg1( lv_x32v, k_new, cvfixnum(length) );

  /* Insert coordinate arrays into line relation: */
  xsendmsg2( lv_line, k_setarray, k_pointx, lv_line_x);
  xsendmsg2( lv_line, k_setarray, k_pointy, lv_line_y);
  x_line = (int*) (csry_base( lv_line_x ));
  y_line = (int*) (csry_base( lv_line_y ));

  /* Process red/grn/blu image-plane arrays in our graphic relation: */
  src_planes = xthl3a_GetPixelRedGreenBlueIfPresent(
	    &lv_im_red, &lv_im_green, &lv_im_blue, lv_im);

  if (lv_im_red  ) {
    lv_line_red   = xsendmsg1( lv_xf8v, k_new, cvfixnum(length) );
    xsendmsg2( lv_line, k_setarray, k_pixelred,   lv_line_red   );
    r_im =  (unsigned char*) (csry_base( lv_im_red   ));
    r_line = (unsigned char*) (csry_base( lv_line_red ));
  }
  if (lv_im_green) {
    lv_line_green = xsendmsg1( lv_xf8v, k_new, cvfixnum(length) );
    xsendmsg2( lv_line, k_setarray, k_pixelgreen, lv_line_green );
    g_im  = (unsigned char*) (csry_base( lv_im_green ));
    g_line = (unsigned char*) (csry_base( lv_line_green ));
  }
  if (lv_im_blue ) {
    lv_line_blue  = xsendmsg1( lv_xf8v, k_new, cvfixnum(length) );
    xsendmsg2( lv_line, k_setarray, k_pixelblue,  lv_line_blue  );
    b_im  = (unsigned char*) (csry_base( lv_im_blue  ));
    b_line = (unsigned char*) (csry_base( lv_line_blue ));
  }

  xlin07_Get_X_And_Y_Dimensions( &x_size, &y_size, lv_im );
  last_inbounds = 0;

  /* initialize offset into image matrix */
  offset = y * x_size + x;

  /* Look at slope and point order to determine where to
     start and which axis to step along.  Also make sure
     that we start with the smaller coordinate value. */

  /* vertical line */
  if (dx == 0) { 
    
    /* bottom-to-top */
    if (y1 <= y2) {
      if (DEBUG) printf("B->T, VERTICAL LINE\n");
      
      while (y <= y2) {
	 if (DEBUG) printf("-- looking at (%d,%d), offset=%d  g=%d\n", 
			   x, y, offset, g_im[offset]); 
	if (XLIN_IMAGE_INBOUNDS(y, x, 0, 0, x_size, y_size)) {
	  last_inbounds = 1;
	  if (lv_im_red)   r_line[i] = r_im[offset];
	  if (lv_im_green) g_line[i] = g_im[offset];
	  if (lv_im_blue)  b_line[i] = b_im[offset];
	  x_line[i] = x;
	  y_line[i] = y;
	  i++;
	}
	else if (last_inbounds) {
	  break;
	}
	y++;
	offset += x_size;
      }
    }
    
    /* top-to-bottom */
    else {    
      if (DEBUG) printf("T->B, VERTICAL LINE\n");

      while (y >= y2) {
	 if (DEBUG) printf("-- looking at (%d,%d), offset=%d  g=%d\n", 
			   x, y, offset, g_im[offset]); 
	if (XLIN_IMAGE_INBOUNDS(y, x, 0, 0, x_size, y_size)) {
	  last_inbounds = 1;
	  if (lv_im_red)   r_line[i] = r_im[offset];
	  if (lv_im_green) g_line[i] = g_im[offset];
	  if (lv_im_blue)  b_line[i] = b_im[offset];
	  x_line[i] = x;
	  y_line[i] = y;
	  i++;
	}
	else if (last_inbounds) {
	  break;
	}
	y--;
	offset -= x_size;
      }
    }
  }
  
  /* non-vertical line */
  else {
    slope = ((float) (y1 - y2)) / (x1 - x2);
    step = ((slope >= 0) ? 1 : -1);
    
    /* left-to-right, step along x-axis */
    if ((x1 < x2) && (fabs(slope) <= 1.0)) {
      if (DEBUG) printf("L->R, | SLOPE | <= 1.0  (%f)\n", slope);

      const1 = 2 * dy;
      const2 = 2 * (dy - dx);
      p = const1 - dx;

      while (x <= x2) {
	if (DEBUG) printf("-- looking at (%d,%d), offset=%d, g=%d\n", 
			  x, y, offset, g_im[offset]); 
	if (XLIN_IMAGE_INBOUNDS(x, y, 0, 0, x_size, y_size)) {
	  last_inbounds = 1;
	  if (lv_im_red)   r_line[i] = r_im[offset];
	  if (lv_im_green) g_line[i] = g_im[offset];
	  if (lv_im_blue)  b_line[i] = b_im[offset];
	  x_line[i] = x;
	  y_line[i] = y;
	  i++;
	}
	else if (last_inbounds) {
	  break;
	}
	x++;  
	offset++;

	if (p < 0)
	  p += const1;
	else {
	  y += step;
	  p += const2;
	  offset += x_size * step;
	}
      }
    }
  
    /* bottom-to-top, step along y-axis */
    else if ((y1 <= y2) && (fabs(slope) > 1.0)) {
      if (DEBUG) printf("B->T, | SLOPE | > 1.0  (%f)\n", slope);

      const1 = 2 * dx;
      const2 = 2 * (dx - dy);
      p = const1 - dy;
      
      while (y <= y2) {
	if (DEBUG) printf("-- looking at (%d,%d), offset=%d  g=%d\n", 
			  x, y, offset, g_im[offset]); 
	if (XLIN_IMAGE_INBOUNDS(x, y, 0, 0, x_size, y_size)) {
	  last_inbounds = 1;
	  if (lv_im_red)   r_line[i] = r_im[offset];
	  if (lv_im_green) g_line[i] = g_im[offset];
	  if (lv_im_blue)  b_line[i] = b_im[offset];
	  x_line[i] = x;
	  y_line[i] = y;
	  i++;
	}
	else if (last_inbounds) {
	  break;
	}
	y++;
	offset += x_size;

	if (p < 0)
	  p += const1;
	else {
	  x += step;
	  p += const2;
	  offset += step;
	}
      }
    }

    /* right-to-left, step along x-axis */
    else if ((x1 > x2) && (fabs(slope) <= 1.0)) {
      if (DEBUG) printf("R->L, | SLOPE | <= 1.0  (%f)\n", slope);

      const1 = 2 * dy;
      const2 = 2 * (dy - dx);
      p = dx - const1;

      while (x >= x2) {
	if (DEBUG) printf("-- looking at (%d,%d), offset=%d, g=%d\n", 
			  x, y, offset, g_im[offset]); 
	if (XLIN_IMAGE_INBOUNDS(x, y, 0, 0, x_size, y_size)) {
	  last_inbounds = 1;
	  if (lv_im_red)   r_line[i] = r_im[offset];
	  if (lv_im_green) g_line[i] = g_im[offset];
	  if (lv_im_blue)  b_line[i] = b_im[offset];
	  x_line[i] = x;
	  y_line[i] = y;
	  i++;
	}
	else if (last_inbounds) {
	  break;
	}
	x--;  
	offset--;

	if (p >= 0)
	  p -= const1;
	else {
	  y -= step;
	  p -= const2;
	  offset -= x_size * step;
	}
      }
    }
  
    /* top-to-bottom, step along y-axis */
    else if ((y1 > y2) && (fabs(slope) > 1.0)) {
      if (DEBUG) printf("T->B, | SLOPE | > 1.0  (%f)\n", slope);

      const1 = 2 * dx;
      const2 = 2 * (dx - dy);
      p = dy - const1;

      while (y >= y2) {
	if (DEBUG) printf("-- looking at (%d,%d), offset=%d  g=%d\n", 
			  x, y, offset, g_im[offset]); 
	if (XLIN_IMAGE_INBOUNDS(x, y, 0, 0, x_size, y_size)) {
	  last_inbounds = 1;
	  if (lv_im_red)   r_line[i] = r_im[offset];
	  if (lv_im_green) g_line[i] = g_im[offset];
	  if (lv_im_blue)  b_line[i] = b_im[offset];
	  x_line[i] = x;
	  y_line[i] = y;
	  i++;
	}
	else if (last_inbounds) {
	  break;
	}
	y--;
	offset -= x_size;

	if (p >= 0)
	  p -= const1;
	else {
	  x -= step;
	  p -= const2;
	  offset -= step;
	}
      }
    }
  }
  
  /* fix up the grl arrays if the line was clipped */
  if (i < length) {
    if (DEBUG) printf("CLIPPING grl arrays from %d to %d...\n", length, i);
    xsendmsg1( lv_line, k_adjustarray, cvfixnum(i) );
  }

  xlpopn(toProt);
  
  return lv_line;
}

/* }}} */
/* {{{ xlin30_GetIntensityIfPresent      				*/

/* derived from xthl3a_GetPixelRedGreenBlueIfPresent */

xlin30_GetIntensityIfPresent( b0, lv_grl )
LVAL			     *b0;
LVAL				  lv_grl;
{
    extern LVAL k_intensity;
    LVAL lv_intensity;
    LVAL*p = xgrl13_pArrayList( lv_grl );
    int  n = 0;
    if (((lv_intensity = xthl74_GetProp(p, k_intensity, NULL ,1 )) != NULL)) ++n;

    if (lv_intensity) 
      xlinEk_Error_If_Not_12BitFloatArray(lv_intensity, k_intensity);

    *b0 = lv_intensity;

    return n;
}

/* }}} */
/* {{{ xlinEk_Error_If_Not_12BitFloatArray				*/

/* Should be in xthl.c, but I couldn't find one. */

xlinEk_Error_If_Not_12BitFloatArray( obj, sym )
LVAL				    obj, sym;
{
    if (!xf2vp(obj))   xlerror("Need 12-bit-float-array for",sym);
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
