/* {{{ xrtp.c -- Interface for Scanner and RTPT system in Rad. Oncology.  */

/*************************************************************************
*
* Author:       Kevin Hinshaw
* Created:      95Jul17
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 95Nov04 kph: Changed method for creating lists to avoid garbage      */
/*              collection problems.                                    */
/* 95Jul17 kph: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/csry.h"
#include <math.h>
#include "rtpt.h"

extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();

extern LVAL k_new;
extern LVAL k_class_point2d;
extern LVAL k_numradials;
extern LVAL k_set;
extern LVAL k_bestx;
extern LVAL k_besty;
extern LVAL k_convertpointfromccs;
extern LVAL k_x;
extern LVAL k_y;
extern LVAL k_contour;
extern LVAL k_data_id;
extern LVAL k_name;
extern LVAL k_contourlist;
extern LVAL k_imagefilename;
extern LVAL k_structure;
extern LVAL k_z;
extern LVAL k_start;
extern LVAL k_end;

extern rtpt_set_t *alloc_set();     /* declared in fou_utils.c */

/* function prototypes (probably only needed for local functions) */
rtpt_contour_t *xrtp01_Scanner_To_Rtpt_Contour(LVAL);
LVAL            xrtp02_Save_Contour_Fn();
void            xrtp03_Status_Handler(enum rtpt_status_e);
LVAL            xrtp04_Save_Volume_Fn();
rtpt_volume_t  *xrtp05_Scanner_To_Rtpt_Volume(LVAL, rtpt_string_t);
LVAL            xrtp06_Fetch_Image_Filenames_Fn();
LVAL            xrtp07_Rtpt_To_Image_Filenames(rtpt_set_t *);
LVAL            xrtp11_Fetch_Segmentation_Data_Fn();
LVAL            xrtp12_Fetch_Segmentation_Data(rtpt_string_t);

LVAL            xrtp08_Rtpt_To_Scanner_Images(rtpt_set_t *);
LVAL            xrtp09_Fetch_Volume_Fn();
LVAL            xrtp10_Rtpt_To_Scanner_Volumes(rtpt_set_t *);

/* }}} */

/* {{{ --- Public fns ---						*/

/* }}} */
/* {{{ xrtp01_Scanner_To_Rtpt_Contour   		       		*/

/* Convert a Scanner contour into a RTPT contour. */

rtpt_contour_t *xrtp01_Scanner_To_Rtpt_Contour(LVAL lv_contour) {

  LVAL              lv_point, lv_class_point2d, lv_radials;
  LVAL              lv_bestx, lv_besty, lv_x, lv_y;
  rtpt_contour_t   *new_contour_p;    /* our new RTPT contour */
  FIXTYPE           n;                /* number of contour vertices */
  int               i, j;
  large_float       transform[4][4] = {{1,0,0,0},
				       {0,1,0,0},
				       {0,0,1,0},
				       {0,0,0,1}};

  int        toProt = 8;
  xlstkcheck(toProt);
  xlprotect(lv_contour);
  xlsave(lv_point);
  xlsave(lv_class_point2d);
  xlsave(lv_radials);
  xlsave(lv_bestx);
  xlsave(lv_besty);
  xlsave(lv_x);
  xlsave(lv_y);

  /* allocate space for a new RTPT contour */
  new_contour_p = (rtpt_contour_t *) malloc(sizeof(rtpt_contour_t));
  if (!new_contour_p) xlerror("memory allocation error");
  new_contour_p -> obj_id.type = RTPT_CONTOUR;
  new_contour_p -> poly.obj_id.type = RTPT_POLYLINE;

  /* figure out how many points we have and allocate space for them */
  lv_radials = xsendmsg0(lv_contour, k_numradials);
  if (fixp(lv_radials))
    n = getfixnum(lv_radials);
  else
    xlerror("bad argument type", lv_radials);
  new_contour_p -> poly.nvertices = n;
  new_contour_p -> poly.vertices_p = 
    (rtpt_vertex_t *) malloc(sizeof(rtpt_vertex_t) * n);
  if (!(new_contour_p -> poly.vertices_p))
    xlerror("memory allocation error");

  /* create a dummy point object */
  lv_class_point2d = getvalue(k_class_point2d);
  if (!objectp(lv_class_point2d)) 
    xlerror("Class point2D has been trashed!");
  lv_point = xsendmsg2(lv_class_point2d, k_new, cvfixnum(0), cvfixnum(0));

  /* initialize the contour's viewing transformation */
  for (i = 0; i < 4; i++) {
    for (j = 0; j < 4; j++) {
      new_contour_p -> poly.trans.transform[i][j] = transform[i][j];
    }
  }
  /* set the Z-translation in the transformation */
  /*  new_contour_p -> poly.trans.transform[2][3] = (large_float) z;  */

  /* Question:  Do we want to completely transform points out of contour
   *            space, or just factor out the orientation?
   */

  /* transform each point out of contour space and store its coordinates */
  for (i = 0; i < n; i++) {
    lv_bestx = xsendmsg1(lv_contour, k_bestx, cvfixnum(i));
    lv_besty = xsendmsg1(lv_contour, k_besty, cvfixnum(i));
    xsendmsg2(lv_point, k_set, lv_bestx, lv_besty);
    xsendmsg1(lv_contour, k_convertpointfromccs, lv_point);
    lv_x = xsendmsg0(lv_point, k_x);
    lv_y = xsendmsg0(lv_point, k_y);
    if (fixp(lv_x))
      new_contour_p -> poly.vertices_p[i].x = (small_float) getfixnum(lv_x);
    else if (floatp(lv_x))
      new_contour_p -> poly.vertices_p[i].x = (small_float) getflonum(lv_x);
    else
      xlerror("bad argument type", lv_x);
    if (fixp(lv_y))
      new_contour_p -> poly.vertices_p[i].y = (small_float) getfixnum(lv_y);
    else if (floatp(lv_y))
      new_contour_p -> poly.vertices_p[i].y = (small_float) getflonum(lv_y);
    else
      xlerror("bad argument type",lv_y);
  }

  xlpopn(toProt);
  return new_contour_p;
}

/* }}} */
/* {{{ xrtp02_Save_Contour_Fn           		       		*/

/* Save a Scanner contour to a file in RTPT format.
   (This is probably what we'll use to communicate with Prism.) 
*/

LVAL xrtp02_Save_Contour_Fn() {

  LVAL                 lv_contour, lv_data_id;
  rtpt_contour_t      *new_contour_p;
  rtpt_set_t          *contour_set_p;
  rtpt_string_t        data_id;
  enum rtpt_status_e   status;

  int        toProt = 2;
  xlstkcheck(toProt);
  xlsave(lv_contour);
  xlsave(lv_data_id);

  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();
    
    if        (key == k_contour) {
      lv_contour = xlgaobject();
    }
    else if   (key == k_data_id) {
      lv_data_id = xlgastring();
    }
    else {
      xlerror("Bad XRTP-SAVE-CONTOUR keyword", key);
    }
  }

  /* convert the contour from Scanner to RTPT format */
  new_contour_p = xrtp01_Scanner_To_Rtpt_Contour(lv_contour);

  /* create a set containing the contour */
  contour_set_p                   = alloc_set();
  contour_set_p -> set_element_p  = new_contour_p;
  contour_set_p -> next_p         = NULL;

  /* use the RTPT library to save the contour */
  if (!stringp(lv_data_id)) xlerror("Data ID wasn't specified.");
  data_id = (rtpt_string_t) getstring(lv_data_id);
  status = fou_storeall(data_id, contour_set_p);
  xrtp03_Status_Handler(status);

  xlpopn(toProt);
  return NIL;
}

/* }}} */
/* {{{ xrtp03_Status_Handler             		       		*/

/* Generate a Lisp-level response for the specified RTPT status code. 
 * Do nothing if it's an "OK" status. 
 */

void xrtp03_Status_Handler(enum rtpt_status_e status) {

  if (status == RTPT_ST_FAIL) {
    xlerror("RTPT function failed");
  }
  else if (status == RTPT_ST_OUTOFMEM) {
    xlerror("RTPT memory allocation error");
  }
  else if (status == RTPT_ST_COMPDOSEFAIL) {
    xlerror("RTPT dose computation failed");
  }
}

/* }}} */
/* {{{ xrtp04_Save_Volume_Fn            		       		*/

/* Save a list of Scanner contours to a file in RTPT format. */


LVAL xrtp04_Save_Volume_Fn() {

  LVAL                 lv_contour_list, lv_data_id, lv_name;
  rtpt_volume_t       *new_volume_p;
  rtpt_set_t          *volume_set_p;
  rtpt_string_t        data_id, name;
  enum rtpt_status_e   status;

  int        toProt = 3;
  xlstkcheck(toProt);
  xlsave(lv_contour_list);
  xlsave(lv_data_id);
  xlsave(lv_name);

  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();
    
    if        (key == k_contourlist) {
      lv_contour_list = xlgalist();
    }
    else if   (key == k_data_id) {
      lv_data_id = xlgastring();
    }
    else if   (key == k_name) {
      lv_name = xlgastring();
    }
    else {
      xlerror("Bad XRTP-SAVE-VOLUME keyword", key);
    }
  }

  /* convert the contours from Scanner to RTPT format */
  name = (rtpt_string_t) getstring(lv_name);
  new_volume_p = xrtp05_Scanner_To_Rtpt_Volume(lv_contour_list, name);

  /* create a set containing the volume */
  volume_set_p                   = alloc_set();
  volume_set_p -> set_element_p  = new_volume_p;
  volume_set_p -> next_p         = NULL;

  /* use the RTPT library to save the volume */
  if (!stringp(lv_data_id)) xlerror("Data ID wasn't specified.");
  data_id = (rtpt_string_t) getstring(lv_data_id);
  status = fou_storeall(data_id, volume_set_p);
  xrtp03_Status_Handler(status);

  xlpopn(toProt);
  return NIL;
}

/* }}} */
/* {{{ xrtp05_Scanner_To_Rtpt_Volume    		       		*/

/* Convert a Scanner contour list into a RTPT volume. */

rtpt_volume_t *xrtp05_Scanner_To_Rtpt_Volume(LVAL lv_contour_list, 
					     rtpt_string_t name) {

  LVAL              lv_contours;    /* contours that still need processing */
  rtpt_volume_t    *new_volume_p;   /* our new RTPT volume */
  rtpt_set_t       *contour_set_p;  /* set of contours in volume */
  rtpt_set_t       *tail_node_p;    /* temp variable for last node in set */
  rtpt_contour_t   *new_contour_p;  /* temp variable for current contour */
  int               i = 2;

  int        toProt = 2;
  xlstkcheck(toProt);
  xlprotect(lv_contour_list);
  xlsave(lv_contours);

  /* Allocate space for a new RTPT volume */
  new_volume_p = (rtpt_volume_t *) malloc(sizeof(rtpt_volume_t));
  if (!new_volume_p)
    xlerror("memory allocation error");

  /* Flag the contour set as uninitialized (this will be set to point 
   * to the first element in the created list)
   */
  contour_set_p = NULL;

  /* Convert each Scanner contour in the contour list to 
   * an RTPT contour and add it to the RTPT contour set.
   */
  for (lv_contours = lv_contour_list ; 
       ! null(lv_contours) ;
       lv_contours = cdr(lv_contours)) {
    new_contour_p = xrtp01_Scanner_To_Rtpt_Contour(car(lv_contours));
    
    /* testing the z-translation business... */
    new_contour_p -> poly.trans.transform[2][3] = i++;

    /* first set element -- we should put the first contour in 
     * the first element, but a bug in the Fetch All and Store All
     * functions ignores the contents of the first element in a set.  
     * So we'll make the first set element empty and put the first 
     * contour in the second element.
     */
    if (!contour_set_p) {

      /* make the first empty set element */
      contour_set_p                  = alloc_set();
      contour_set_p -> set_element_p = NULL;
      contour_set_p -> next_p        = NULL;
      tail_node_p = contour_set_p;

      /* put the contour in the second set element */
      tail_node_p -> next_p                  = alloc_set();
      tail_node_p -> next_p -> set_element_p = new_contour_p;
      tail_node_p -> next_p -> next_p        = NULL;
      tail_node_p = tail_node_p -> next_p;
    }
    /* other set elements */
    else {
      tail_node_p -> next_p                  = alloc_set();
      tail_node_p -> next_p -> set_element_p = new_contour_p;
      tail_node_p -> next_p -> next_p        = NULL;
      tail_node_p = tail_node_p -> next_p;
    }
  }

  /* Set attributes of the volume */
  new_volume_p -> obj_id.type = RTPT_VOLUME;
  new_volume_p -> name        = name;
  new_volume_p -> contours_p  = contour_set_p;
  new_volume_p -> z_plus      = 0;
  new_volume_p -> z_minus     = 0;

  xlpopn(toProt);
  return new_volume_p;
}

/* }}} */
/* {{{ xrtp06_Fetch_Image_Filenames_Fn     		       		*/

/* Load an image in RTPT format and convert to Scanner format */

LVAL xrtp06_Fetch_Image_Filenames_Fn() {

  LVAL                 lv_image_list, lv_data_id;
  rtpt_contour_t      *new_contour_p;
  rtpt_set_t          *type_set_p;
  rtpt_set_t          *image_set_p;
  rtpt_id_t           *type_image_2d_p;
  rtpt_string_t        data_id;
  enum rtpt_status_e   status;

  int        toProt = 2;
  xlstkcheck(toProt);
  xlsave(lv_image_list);
  xlsave(lv_data_id);

  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();
    
    if        (key == k_data_id) {
      lv_data_id = xlgastring();
    }
    else {
      xlerror("Bad XRTP-LOAD-IMAGE keyword", key);
    }
  }

  /* create a set containing the type(s) of images we want to load */
  type_image_2d_p         = (rtpt_id_t *) malloc(sizeof(rtpt_id_t));
  type_image_2d_p -> type = RTPT_IMAGE_2D;
  type_set_p                  = alloc_set();
  type_set_p -> set_element_p = type_image_2d_p;
  type_set_p -> next_p        = NULL;

  /* use the RTPT library to load the images */
  if (!stringp(lv_data_id)) xlerror("Data ID wasn't specified.");
  data_id = (rtpt_string_t) getstring(lv_data_id);
  image_set_p = alloc_set();
  status = fou_fetchall(data_id, type_set_p, image_set_p);
  xrtp03_Status_Handler(status);

  /* grab the filenames for the images */
  lv_image_list = xrtp07_Rtpt_To_Image_Filenames(image_set_p);

  xlpopn(toProt);
  return lv_image_list;
}

/* }}} */
/* {{{ xrtp07_Rtpt_To_Image_Filenames    		       		*/

/* Convert a set of loaded RTPT images into a list of Scanner images */

LVAL xrtp07_Rtpt_To_Image_Filenames(rtpt_set_t *image_set_p) {

  LVAL               lv_filename_list;  /* list of image filenames */
  LVAL               lv_filename;
  rtpt_set_t        *node_p;            /* current element in image set */
  rtpt_string_t      node_class;        /* class of the current node */
  rtpt_image_t      *image_p = NULL;
  rtpt_image_2d_t   *image_2d_p;
  rtpt_image_3d_t   *image_3d_p;
  rtpt_contour_t    *contour_p;
  medium_uint        n_x = PRISM_DIM;
  medium_uint        n_y = PRISM_DIM;
  medium_uint        n_z;
  enum pixel_type_e  pixel_type = RTPT_PIXTYPE_MEDIUM_UINT;
  small_float        pix_per_cm;

  int        toProt = 2;
  xlstkcheck(toProt);
  xlsave(lv_filename_list);
  xlsave(lv_filename);

  /* empty image set */
  if (image_set_p == NULL) {
    lv_filename_list = NIL;
  }

  /* non-empty image set */
  else {

    /* figure out what is in the first element
     * 
     * (All RTPT objects have the obj_id field as the first member,
     * so casting the set element as any one of them should allow
     * us to read the obj_id field properly.)
     */
    if (image_set_p -> set_element_p) {
      node_class = ((rtpt_image_t *)(image_set_p -> set_element_p)) -> obj_id.type;

      if (rtpt_class(node_class, RTPT_IMAGE)) {

	printf("       This is a base class image.\n");
	image_p = (rtpt_image_t *) (image_set_p -> set_element_p);
	
      }
      else if (rtpt_class(node_class, RTPT_IMAGE_2D)) {

	printf("       This is a 2D image.\n");
	image_2d_p = (rtpt_image_2d_t *) (image_set_p -> set_element_p);
	image_p = &(image_2d_p -> image);
      }
      else if (rtpt_class(node_class, RTPT_IMAGE_3D)) {

	printf("       This is a 3D image.\n");
	image_3d_p = (rtpt_image_3d_t *) (image_set_p -> set_element_p);
	image_p = &(image_3d_p -> image);
      }
    }
  

    /* If it is an image, get its filename and return it in a list
     * with filenames from subsequent elements (generated recursively).  
     * Otherwise, just return list from subsequent elements.
     */
    if (image_p) {
      lv_filename_list = 
	cons(cvstring(image_p -> filename),
	     xrtp07_Rtpt_To_Image_Filenames(image_set_p -> next_p));

      pix_per_cm = (image_p -> grid.n_x) / (image_p -> grid.x_size);
    }
    else {
      lv_filename_list = 
	xrtp07_Rtpt_To_Image_Filenames(image_set_p -> next_p);
    }
  }

  xlpopn(toProt);
  return lv_filename_list;
}

/* }}} */
/* {{{ xrtp11_Fetch_Segmentation_Data_Fn             	       		*/

/* Load a volume in RTPT format and convert to Scanner format */

LVAL xrtp11_Fetch_Segmentation_Data_Fn() {

  LVAL             lv_data_id, lv_result;
  rtpt_string_t    data_id;

  int        toProt = 2;
  xlstkcheck(toProt);
  xlsave(lv_data_id);
  xlsave(lv_result);

  /* parse the arguments */
  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();
    
    if (key == k_data_id) {
      lv_data_id = xlgastring();
    }
    else {
      xlerror("Bad XRTP-FETCH-SEGMENTATION-DATA keyword", key);
    }
  }

  /* do the real work */
  if (!stringp(lv_data_id)) xlerror("Data ID wasn't specified.");
  data_id = (rtpt_string_t) getstring(lv_data_id);
  lv_result = xrtp12_Fetch_Segmentation_Data(data_id);
  xlpopn(toProt);
  return lv_result;
}

/* }}} */
/* {{{ xrtp12_Fetch_Segmentation_Data             	       		*/

/* Load a volume in RTPT format and convert to Scanner format */

LVAL xrtp12_Fetch_Segmentation_Data(rtpt_string_t data_id) {

  LVAL                 lv_solid, lv_start, lv_end, lv_image_list;
  LVAL                 lv_z, lv_image_filename, lv_organ_name, lv_data;
  rtpt_set_t          *type_set_p, *image_set_p;
  rtpt_set_t          *solid_set_p, *set_p;
  rtpt_id_t           *type_solid_p;
  rtpt_id_t           *type_image_2d_p;
  enum rtpt_status_e   status;
  rtpt_contour_t      *contour_p;
  rtpt_vertex_t       *verts;
  rtpt_solid_t        *solid_p;

  int        toProt = 8;
  xlstkcheck(toProt);
  xlsave(lv_solid);
  xlsave(lv_start);
  xlsave(lv_end);
  xlsave(lv_z);
  xlsave(lv_image_filename);
  xlsave(lv_organ_name);
  xlsave(lv_data);
  xlsave(lv_image_list);

  /******** load the image filename ********/

  /* create a set containing the type(s) of images we want to load */
  type_image_2d_p         = (rtpt_id_t *) malloc(sizeof(rtpt_id_t));
  type_image_2d_p -> type = RTPT_IMAGE_2D;
  type_set_p                  = alloc_set();
  type_set_p -> set_element_p = type_image_2d_p;
  type_set_p -> next_p        = NULL;

  /* use the RTPT library to load the images */
  /* should make sure the data_id exists... */
  image_set_p = alloc_set();
  status = fou_fetchall(data_id, type_set_p, image_set_p);
  xrtp03_Status_Handler(status);

  /* grab the first image filename */
  lv_image_list = xrtp07_Rtpt_To_Image_Filenames(image_set_p);
  lv_image_filename = car(lv_image_list);


  /******** load the rest of the parameters ********/

  /* create a set containing the type(s) of objects we want to load */
  type_solid_p               = (rtpt_id_t *) malloc(sizeof(rtpt_id_t));
  type_solid_p -> type       = RTPT_SOLID;
  type_set_p                  = alloc_set();
  type_set_p -> set_element_p = type_solid_p;
  type_set_p -> next_p        = NULL;

  /* use the RTPT library to load the solid */
  /* should make sure the data_id exists... */
  solid_set_p = alloc_set();
  status = fou_fetchall(data_id, type_set_p, solid_set_p);
  xrtp03_Status_Handler(status);

  /* find the first solid in the list */
  for (set_p = solid_set_p;   
       set_p;   
       set_p = set_p -> next_p) {
    if (set_p -> set_element_p) { 
      solid_p = (rtpt_solid_t *) set_p -> set_element_p;
      break;
    }
  }
  if (! solid_p) { return NULL; }

  /* find first contour in the set */
  for (set_p = solid_p -> volume.contours_p; 
       set_p; 
       set_p = set_p -> next_p) {
    if (set_p -> set_element_p) { 
      contour_p = (rtpt_contour_t *) set_p -> set_element_p;
      break;
    }
  }

  /* get long-axis vertices */
  if (contour_p -> poly.nvertices != 2) {
    xlerror("Invalid long axis");
  }
  else {
    verts = contour_p -> poly.vertices_p;
    lv_start = cons(cvflonum(verts[0].y), NIL);
    lv_start = cons(cvflonum(verts[0].x), lv_start);
    lv_end   = cons(cvflonum(verts[1].y), NIL);
    lv_end   = cons(cvflonum(verts[1].x), lv_end);
  }

  /* get remaining parameters */
  lv_organ_name = cvstring(solid_p -> volume.name);
  lv_z          = cvflonum(contour_p -> poly.trans.transform[2][3]);

  /* build list of keyword/value pairs */
  lv_data = cons(lv_end,             NIL);
  lv_data = cons(k_end,              lv_data);
  lv_data = cons(lv_start,           lv_data);
  lv_data = cons(k_start,            lv_data);
  lv_data = cons(lv_z,               lv_data);
  lv_data = cons(k_z,                lv_data);
  lv_data = cons(lv_organ_name,      lv_data);
  lv_data = cons(k_structure,        lv_data);
  lv_data = cons(lv_image_filename,  lv_data);
  lv_data = cons(k_imagefilename,    lv_data);

  xlpopn(toProt);
  return lv_data;
}

/* }}} */

/* in progress... */
/* {{{ xrtp08_Rtpt_To_Scanner_Images    		       		*/

/* Convert a set of loaded RTPT images into a list of Scanner images */

LVAL xrtp08_Rtpt_To_Scanner_Images(rtpt_set_t *image_set_p) {

  LVAL               lv_image_list;  /* list of Scanner images */
  rtpt_set_t        *node_p;         /* current element in image set */
  rtpt_string_t      node_class;     /* class of the current node */
  rtpt_image_t      *image_p;
  rtpt_image_2d_t   *image_2d_p;
  rtpt_image_3d_t   *image_3d_p;
  rtpt_contour_t    *contour_p;
  medium_uint        n_x = PRISM_DIM;
  medium_uint        n_y = PRISM_DIM;
  medium_uint        n_z;
  enum pixel_type_e  pixel_type = RTPT_PIXTYPE_MEDIUM_UINT;

  int        toProt = 1;
  xlstkcheck(toProt);
  xlsave(lv_image_list);

  /* create an empty image list */
  lv_image_list = NIL;

  /* Convert each RTPT image in the image set to 
   * a Scanner image and add it to the Scanner image list.
   */
  for (node_p = image_set_p; node_p; node_p = node_p -> next_p) {

    /* figure out what type of image is in this node
     * 
     * (All RTPT objects have the obj_id field as the first member,
     * so casting the set element as any of them should allow
     * us to read the obj_id field properly.)
     */
    if (node_p -> set_element_p) {
      node_class = ((rtpt_image_t *)(node_p -> set_element_p)) -> obj_id.type;

      if (rtpt_class(node_class, RTPT_IMAGE)) {

	printf("       This is a base class image.\n");
	image_p = (rtpt_image_t *) (node_p -> set_element_p);
      }
      else if (rtpt_class(node_class, RTPT_IMAGE_2D)) {

	printf("       This is a 2D image.\n");
	image_2d_p = (rtpt_image_2d_t *) (node_p -> set_element_p);
	image_p = &(image_2d_p -> image);
      }
      else if (rtpt_class(node_class, RTPT_IMAGE_3D)) {

	printf("       This is a 3D image.\n");
	image_3d_p = (rtpt_image_3d_t *) (node_p -> set_element_p);
	image_p = &(image_3d_p -> image);
      }
      else {

	image_p = NULL;
      }
    }

    /* We should read these values, but in the examples I've looked
     * at, they haven't been set!  Just use default values for now.
     */
    /* n_x        = image_p -> grid.n_x; */
    /* n_y        = image_p -> grid.n_y; */
    /* pixel_type = image_p -> pixtype;  */
    
    /* create a Scanner image from the data in the RTPT image */
    
    /* base class case -- what do we do?  Use filename directly? */
    if (rtpt_class(node_class, RTPT_IMAGE)) {
      printf("Image base class -- not implemented yet.\n");
    }
    /* 2D case */
    else if (rtpt_class(node_class, RTPT_IMAGE_2D)) {
      
      /* for now, just cheat -- use the filename so 
       * we can use the image read function in xmri.
       */
      
    }
    /* 3D case */
    else if (rtpt_class(node_class, RTPT_IMAGE_3D)) {
      n_z = image_p -> grid.n_z;
      printf("3D image class -- not implemented yet.\n");
    }
    else {
      printf("This object is not an image.\n");
    }


    
  }

  xlpopn(toProt);
  return lv_image_list;
}

/* }}} */
/* {{{ xrtp09_Fetch_Volume_Fn            		       		*/

/* Load a volume in RTPT format and convert to Scanner format */

LVAL xrtp09_Fetch_Volume_Fn() {

  LVAL                 lv_volume, lv_data_id;
  rtpt_contour_t      *new_contour_p;
  rtpt_set_t          *type_set_p;
  rtpt_set_t          *volume_set_p;
  rtpt_id_t           *type_solid_p;
  rtpt_string_t        data_id;
  enum rtpt_status_e   status;

  int        toProt = 2;
  xlstkcheck(toProt);
  xlsave(lv_volume);
  xlsave(lv_data_id);

  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();
    
    if        (key == k_data_id) {
      lv_data_id = xlgastring();
    }
    else {
      xlerror("Bad XRTP-LOAD-ORGAN keyword", key);
    }
  }

  /* create a set containing the type(s) of objects we want to load */
  type_solid_p                = (rtpt_id_t *) malloc(sizeof(rtpt_id_t));
  type_solid_p -> type        = RTPT_VOLUME;
  type_set_p                  = alloc_set();
  type_set_p -> set_element_p = type_solid_p;
  type_set_p -> next_p        = NULL;

  /* use the RTPT library to load the volume */
  if (!stringp(lv_data_id)) xlerror("Data ID wasn't specified.");
  data_id = (rtpt_string_t) getstring(lv_data_id);
  volume_set_p = alloc_set();
  status = fou_fetchall(data_id, type_set_p, volume_set_p);
  xrtp03_Status_Handler(status);

  /* grab the filenames for the images */
  lv_volume = xrtp10_Rtpt_To_Scanner_Volumes(volume_set_p);

  xlpopn(toProt);
  return lv_volume;
}

/* }}} */
/* {{{ xrtp10_Rtpt_To_Scanner_Volumes   		       		*/

/* Convert a set of loaded RTPT volumes into a list of Scanner volumes */

LVAL xrtp10_Rtpt_To_Scanner_Volumes(rtpt_set_t *volume_set_p) {

  LVAL               lv_volume_list;
  LVAL               lv_volume;
  rtpt_set_t        *node_p;              /* current element in volume set */
  rtpt_string_t      node_class;          /* class of the current node */
  rtpt_volume_t     *volume_p = NULL;
  rtpt_contour_t    *contour_p;

  int        toProt = 2;
  xlstkcheck(toProt);
  xlsave(lv_volume);
  xlsave(lv_volume_list);

  /* empty volume set */
  if (volume_set_p == NULL) {
    lv_volume_list = NIL;
  }

  /* non-empty volume set */
  else {

    /* figure out what is in the first element
     * 
     * (All RTPT objects have the obj_id field as the first member,
     * so casting the set element as any one of them should allow
     * us to read the obj_id field properly.)
     */
    if (volume_set_p -> set_element_p) {
      node_class = ((rtpt_volume_t *)(volume_set_p -> set_element_p)) -> obj_id.type;

      if (rtpt_class(node_class, RTPT_VOLUME)) {
	volume_p = (rtpt_volume_t *) (volume_set_p -> set_element_p);
      }
    }

    /* If it is a volume, convert it and return it in a list
     * with subsequent elements (generated recursively).  
     * Otherwise, just return list from subsequent elements.
     */
    if (volume_p) {

/*      lv_volume = ; */

      lv_volume_list = 
	cons(lv_volume,
	     xrtp10_Rtpt_To_Scanner_Volumes(volume_set_p -> next_p));
    }
    else {
      lv_volume_list = 
	xrtp10_Rtpt_To_Scanner_Volumes(volume_set_p -> next_p);
    }
  }

  xlpopn(toProt);
  return lv_volume_list;
}

/* }}} */

/* {{{ File variables							*/

/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
