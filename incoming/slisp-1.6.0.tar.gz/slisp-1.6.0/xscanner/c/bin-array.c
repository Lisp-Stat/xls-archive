/*
 * bin-array.c
 *
 * These are the C language binary array read and write routines that are
 * imported into lisp as foreign functions and used by the read-bin-array
 * and write-bin-array routines in Prism's sys-tools package.
 *
 *  3-Apr-1992 - Copied for NCI-RTPT project from Jonathan Unger, who wrote
 *               them for Prism
 */

#include <stdio.h>

#define DIM 512 


/*
 *  Reads in a one-dimensional array of xdim unsigned shorts from filename
 *  and returns it via the array parameter.
 */
void read_bin_array_1 (filename, xdim, array)
char filename[];
int xdim;
unsigned short array[];
{
  FILE *fp;

  fp = fopen(filename, "rb");

  fread(array, 2, xdim, fp);

  fclose(fp);
}


/*
 *  Reads in a two-dimensional array of xdim x DIM unsigned shorts from 
 *  filename and returns it via the array parameter.
 */
void read_bin_array_2 (filename, xdim, ydim, array)
char filename[];
int xdim, ydim;
unsigned short array[][DIM];
{
  FILE *fp;
  int row;

  if (xdim != DIM) 
    fprintf(stderr, "C lang read_bin_array_2: x dim must = %d \n", DIM);

  fp = fopen(filename, "rb");

  for (row = 0; row < ydim; ++row)
    fread(array[row], 2, DIM, fp);

  fclose(fp);
}


/*
 *  Reads in a three-dimensional array of xdim x DIM x DIM unsigned shorts
 *  from filename and returns it via the array parameter.
 */
void read_bin_array_3 (filename, xdim, ydim, zdim, array)
char filename[];
int xdim, ydim, zdim;
unsigned short array[][DIM][DIM];
{
  FILE *fp;
  int plane, row;

  if ((xdim != DIM) || (ydim != DIM))
    fprintf(stderr, "C lang read_bin_array_3: x & y dim must = %d \n", DIM);

  fp = fopen(filename, "rb");

  for (plane = 0; plane < zdim; ++plane)
    for (row = 0; row < DIM; ++row)
      fread(array[plane][row], 2, DIM, fp);

  fclose(fp);
}


/*
 *  Writes out a one-dimensional array of xdim unsigned shorts to filename.
 */
void write_bin_array_1 (filename, xdim, array)
char filename[];
int xdim;
unsigned short array[];
{
  FILE *fp;

  fp = fopen(filename, "wb");

  fwrite(array, 2, xdim, fp);

  fclose(fp);
}


/*
 *  Writes out a two-dimensional array of xdim x ydim unsigned shorts to
 *  filename.
 */
void write_bin_array_2 (filename, xdim, ydim, array)
char filename[];
int xdim, ydim;
unsigned short array[][DIM];
{
  FILE *fp;
  int row;

  if (xdim != DIM) 
    fprintf(stderr, "C lang write_bin_array_2: x dim must = %d \n", DIM);

  fp = fopen(filename, "wb");

  for (row = 0; row < ydim; ++row)
    fwrite(array[row], 2, DIM, fp);

  fclose(fp);
}


/*
 *  Writes out a three-dimensional array of xdim x ydim x zdim unsigned shorts
 *  to filename.
 */
void write_bin_array_3 (filename, xdim, ydim, zdim, array)
char filename[];
int xdim, ydim, zdim;
unsigned short array[][DIM][DIM];
{
  FILE *fp;
  int plane, row;

  if ((xdim != DIM) || (ydim != DIM))
    fprintf(stderr, "C lang write_bin_array_3: x & y dim must = %d \n", DIM);

  fp = fopen(filename, "wb");

  for (plane = 0; plane < zdim; ++plane)
    for (row = 0; row < DIM; ++row)
      fwrite(array[plane][row], 2, DIM, fp);

  fclose(fp);
}

