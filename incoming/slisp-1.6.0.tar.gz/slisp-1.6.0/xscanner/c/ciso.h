/* {{{ ciso.h -- xiso.c isosurface stuff.			     	CrT*/
/*************************************************************************
*
* Author:       Kevin Hinshaw
* Created:      96Oct19
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifndef INCLUDED_CISO_H
#define INCLUDED_CISO_H

/* }}} */

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/csry.h"

/* constants */
#define XISO_RESOLUTION    0.1   /* default size of isosurface cubes */
#define XISO_MAX_INTENSITY 4096  /* max intensity value */

/* macros */
#define XISO_MAX(x,y) ((x) > (y) ? (x) : (y))
#define XISO_MAX3(x,y,z) (XISO_MAX(XISO_MAX((x),(y)),(z)))

/* macro for referencing a 3D point (x,y,z) in a 1D voxel dataset d */
#define XISO_GET_VOXEL(d,x,y,z) \
((((x) < 0) || ((x) >= (d)->xsize) || \
  ((y) < 0) || ((y) >= (d)->ysize) || \
  ((z) < 0) || ((z) >= (d)->zsize))   \
 ? 0 \
 : (d)->intensity[(int) (floor(z) + \
   (d)->zsize * (floor(y) + \
   (d)->ysize * floor(x)))] \
)

/* arrays quick access to seed point information */
typedef struct xiso_seeds {
  int             count;        /* number of seed points */
  int             *x;           /* coords of seed points */
  int             *y;
  int             *z;
  int             *xmin;        /* min bound coords of seed points */
  int             *ymin;
  int             *zmin;
  int             *xmax;        /* max bound coords of seed points */
  int             *ymax;
  int             *zmax;
} XISO_SEEDS;

/* Nov2196 -- probably obsolete now */
/* a data structure for holding dataset components */
typedef struct xiso_dataset {
  int              num_seeds;        /* number of seed points */
  int             *xseed;            /* coords of seed points */
  int             *yseed;
  int             *zseed;
  int             *xseed_min;        /* min bound coords of seed points */
  int             *yseed_min;
  int             *zseed_min;
  int             *xseed_max;        /* max bound coords of seed points */
  int             *yseed_max;
  int             *zseed_max;
  int              xsize;            /* dimensions of dataset */
  int              ysize;
  int              zsize;
  CSRY_UNSIGNED16 *intensity;        /* dataset's intensity values */
  CSRY_UNSIGNED16 *threshold_array;  /* dataset's threshold values */
  double          threshold;         /* dataset's single threshold */
  double          resolution;        /* size of cubes used in isosurface */
  int             mode;              /* mode for running isosurface */
} XISO_DATASET;

/* global vars */
extern LVAL     XISO_LV_FACETS;  /* facet relation for isosurface */


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
#endif
/* }}} */
