/* {{{ xcut.c -- surface-cutting routines.  */

/*************************************************************************
*
* Author:       Kevin Hinshaw
* Created:      97Feb12
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 
 * 98Mar13 kph: moved point normal manipulations into xvol.c
 * 97Feb12 kph: Created.
 */

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/x01v.h"
#include "../../xg.3d/c/c01v.h"
#include "../../xg.3d/c/geo.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/cf2v.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#include <math.h>
#include <string.h>
#include <unistd.h>

extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();
extern LVAL xsendmsg3();
extern xthlB1_Process_Thing();
extern LVAL xthl82_SetProp();
extern LVAL xthl74_GetProp();

extern LVAL lv_x01v;
extern LVAL k_new;
extern LVAL k_getarray;
extern LVAL k_setarray;
extern LVAL k_facetif;
extern LVAL k_facetrelation;
extern LVAL k_initialelement;
extern LVAL k_fillpointer;
extern LVAL k_setffillpointer;
extern LVAL k_radius;
extern LVAL k_point;
extern LVAL k_start;
extern LVAL k_end;

extern LVAL k_mini;  extern LVAL k_maxi;
extern LVAL k_minj;  extern LVAL k_maxj;
extern LVAL k_mink;  extern LVAL k_maxk;

/* all the keywords I define here (some may exist elsewhere) */
extern LVAL k_thing;
extern LVAL k_facet;
extern LVAL k_levels;
extern LVAL k_mask;
extern LVAL k_innerradius;
extern LVAL k_outerradius;
extern LVAL k_seed;

/* function prototypes (probably only needed for local functions) */
void xcut01_Remove_Neighbors(LVAL, int, int);
LVAL xcut02_Remove_Neighbors_Fn();
void xcut03_Remove_Region(LVAL, geo_point, float);
LVAL xcut04_Remove_Region_Fn();
void xcut05_Compute_Shell(LVAL, LVAL, int, int, float, float, 
			 int, int, int,
			 int, int, int, int, int, int);
LVAL xcut06_Compute_Shell_Fn();
void xcut07_Compute_Mask(LVAL, LVAL, int, int, float, float,
			 int, int, int,
			 geo_point,
			 int, int, int, int, int, int);
LVAL xcut08_Compute_Mask_Fn();
void xcut09_Boundary_Fill(char *, int,
			  int, int, int, int, int, int,
			  int, int, int, int, int, int);
void xcut09_Boundary_Fill_OLD(char *, int,
			  int, int, int, int, int, int,
			  int, int, int, int, int, int);
void xcut10_Boundary_Fill_Rec(char *, int,
			      int, int, int, int, int, int,
			      int, int, int, int, int, int);

/* structure for plane equation coefficients */
typedef struct xcut_plane {
  float  a, b, c, d;
} xcut_plane;

/* vector of 3 integers */
typedef struct vec3i {
  int x, y, z;
} vec3i;

/* vector of 3 unsigned chars (used by boundary fill routine) */
typedef struct vec3c {
  unsigned char x, y, z;
} vec3c;

/* }}} */
/* {{{ --- macros ---                                                   */

/* determine if triangles a and b share a vertex */
/* (coords are indices into the point array)     */
#define XCUT_TRI_SHARED_VERTEX(a0, a1, a2, b0, b1, b2) \
 (((a0) == (b0)) || ((a0) == (b1)) || ((a0) == (b2)) || \
  ((a1) == (b0)) || ((a1) == (b1)) || ((a1) == (b2)) || \
  ((a2) == (b0)) || ((a2) == (b1)) || ((a2) == (b2)))

/* bitvector operations (derived from code in xg.3d/c/x01v.c)
 *   i >> 3         =  byte number
 *   i  & 7         =  bit number
 *   ~(1 << (i&7))  =  mask 
 */
#define XCUT_GET_BIT(ary, i) ((ary[(i) >> 3] >> ((i) & 7)) & 1)

/* Function version of XCUT_SET_BIT that I was using for debugging.
 * Seems okay.  (And bugs I was having are still happening, so problem
 * must be elsewhere.  kph, 98Mar16)
 */
/*
 * char XCUT_SET_BIT(char *ary, int i, int val) {
 *  int  byte = i >> 3;
 *  int  bit  = i & 7;
 *  char mask = ~(1 << ((i) & 7));
 * 
 *  printf("XCUT_SET_BIT:\n");
 *  printf("  i    = %d\n", i);
 *  printf("  byte = %d\n", byte);
 *  printf("  bit  = %d\n", bit);
 *  printf("  mask = %x\n", mask);
 *  printf("  old  = %x\n", ary[byte]);
 *  ary[byte] = (ary[byte] & mask) |
 *              (val << bit);
 *  printf("  new  = %x\n", ary[byte]);
 *  sleep(2);
 * }
 */

#define XCUT_SET_BIT(ary, i, val) \
  (ary[(i) >> 3] = ((ary[(i) >> 3] & ~(1 << ((i) & 7))) | \
		    ((val) << ((i) & 7))))

/* compute distance between two points */
#define XCUT_DIST(a,b) (sqrt((double) ((a.x - b.x)*(a.x - b.x) + \
				       (a.y - b.y)*(a.y - b.y) + \
				       (a.z - b.z)*(a.z - b.z))))

#define XCUT_SQR(a) ((a) * (a))

/* compute the SQUARED distance between two points */			     
#define XCUT_SQR_DIST(ax,ay,az,bx,by,bz) ((ax - bx)*(ax - bx) + \
					  (ay - by)*(ay - by) + \
					  (az - bz)*(az - bz))

#define XCUT_SQR_DIST_OLD(a,b) ((a.x - b.x)*(a.x - b.x) + \
			    (a.y - b.y)*(a.y - b.y) + \
			    (a.z - b.z)*(a.z - b.z))
			     
/* return the minimum of three numbers */
#define XCUT_MIN3(a,b,c) \
  (((a) < (b)) ? (((a) < (c)) ? (a) : (c)) \
               : (((b) < (c)) ? (b) : (c)))

/* return the maximum of three numbers */
#define XCUT_MAX3(a,b,c) \
  (((a) > (b)) ? (((a) > (c)) ? (a) : (c)) \
               : (((b) > (c)) ? (b) : (c)))

/* }}} */

/* {{{ --- Public fns ---						*/

/* }}} */
/* {{{ xcut00_Tri_Shared_Vertex            		       		*/

int xcut00_Tri_Shared_Vertex(s, a, b)
     gt_tri_rec              s;
     int                        a;
     int                           b; 
{
  /* return 1 if the facets a and b share a vertex, 0 otherwise */
  /* (there may be a more efficient method, but this works)     */

  int  af0 = s.f0[a];    /* facet indices for facet a */
  int  af1 = s.f1[a];
  int  af2 = s.f2[a];
  int  bf0 = s.f0[b];    /* facet indices for facet b */
  int  bf1 = s.f1[b];
  int  bf2 = s.f2[b];

  float  ax0 = s.x[af0];   /* coordinates for a's vertices */
  float  ay0 = s.y[af0];
  float  az0 = s.z[af0];
  float  ax1 = s.x[af1];
  float  ay1 = s.y[af1];
  float  az1 = s.z[af1];
  float  ax2 = s.x[af2];
  float  ay2 = s.y[af2];
  float  az2 = s.z[af2];
  
  float  bx0 = s.x[bf0];   /* coordinates for b's vertices */
  float  by0 = s.y[bf0];
  float  bz0 = s.z[bf0];
  float  bx1 = s.x[bf1];
  float  by1 = s.y[bf1];
  float  bz1 = s.z[bf1];
  float  bx2 = s.x[bf2];
  float  by2 = s.y[bf2];
  float  bz2 = s.z[bf2];
  
  return (((ax0 == bx0) && (ay0 == by0) && (az0 == bz0)) ||
	  ((ax0 == bx1) && (ay0 == by1) && (az0 == bz1)) ||
	  ((ax0 == bx2) && (ay0 == by2) && (az0 == bz2)) ||
	  ((ax1 == bx0) && (ay1 == by0) && (az1 == bz0)) ||
	  ((ax1 == bx1) && (ay1 == by1) && (az1 == bz1)) ||
	  ((ax1 == bx2) && (ay1 == by2) && (az1 == bz2)) ||
	  ((ax2 == bx0) && (ay2 == by0) && (az2 == bz0)) ||
	  ((ax2 == bx1) && (ay2 == by1) && (az2 == bz1)) ||
	  ((ax2 == bx2) && (ay2 == by2) && (az2 == bz2)));
}

/* }}} */
/* {{{ xcut0a_Tri_Shared_Vertex            		       		*/

int xcut0a_Tri_Shared_Vertex(s, a, b)
     gt_tri_rec              s;
     int                        a;
     int                           b; 
{
  /* return 1 if the facets a and b share a vertex, 0 otherwise */
  /* (there may be a more efficient method, but this works)     */

  int  af0 = s.f0[a];    /* facet indices for facet a */
  int  af1 = s.f1[a];
  int  af2 = s.f2[a];
  int  bf0 = s.f0[b];    /* facet indices for facet b */
  int  bf1 = s.f1[b];
  int  bf2 = s.f2[b];

  return 
    (((s.x[af0] == s.x[bf0]) && (s.y[af0] == s.y[bf0]) && (s.z[af0] == s.z[bf0])) ||
     ((s.x[af0] == s.x[bf1]) && (s.y[af0] == s.y[bf1]) && (s.z[af0] == s.z[bf1])) ||
     ((s.x[af0] == s.x[bf2]) && (s.y[af0] == s.y[bf2]) && (s.z[af0] == s.z[bf2])) ||
     ((s.x[af1] == s.x[bf0]) && (s.y[af1] == s.y[bf0]) && (s.z[af1] == s.z[bf0])) ||
     ((s.x[af1] == s.x[bf1]) && (s.y[af1] == s.y[bf1]) && (s.z[af1] == s.z[bf1])) ||
     ((s.x[af1] == s.x[bf2]) && (s.y[af1] == s.y[bf2]) && (s.z[af1] == s.z[bf2])) ||
     ((s.x[af2] == s.x[bf0]) && (s.y[af2] == s.y[bf0]) && (s.z[af2] == s.z[bf0])) ||
     ((s.x[af2] == s.x[bf1]) && (s.y[af2] == s.y[bf1]) && (s.z[af2] == s.z[bf1])) ||
     ((s.x[af2] == s.x[bf2]) && (s.y[af2] == s.y[bf2]) && (s.z[af2] == s.z[bf2])));
}

/* }}} */
/* {{{ XCUT0B_TRI_SHARED_VERTEX            		       		*/

#define xcut_points_equal(s, a, b) \
  ((((s).x[(a)] == (s).x[(b)]) &&   \
    ((s).y[(a)] == (s).y[(b)]) &&   \
    ((s).z[(a)] == (s).z[(b)])))
  
#define XCUT0B_TRI_SHARED_VERTEX(s, a0, a1, a2, b0, b1, b2) \
  (xcut_points_equal(s, a0, b0) || \
   xcut_points_equal(s, a0, b1) || \
   xcut_points_equal(s, a0, b2) || \
   xcut_points_equal(s, a1, b0) || \
   xcut_points_equal(s, a1, b1) || \
   xcut_points_equal(s, a1, b2) || \
   xcut_points_equal(s, a2, b0) || \
   xcut_points_equal(s, a2, b1) || \
   xcut_points_equal(s, a2, b2))

/* }}} */
/* {{{ xcut01_Remove_Neighbors            		       		*/

/* Remove neighbors of a particular facet.  This routine assumes that
 * any facets that share a vertex are neighbors. 
 */

void xcut01_Remove_Neighbors(LVAL lv_thing, int facet, int levels) {

  LVAL            lv_facets;     /* thing's facet relation */
  LVAL            lv_facet_if;   /* facet_if bitvector (as an LVAL) */
  LVAL            lv_shape;      /* LVAL dimensions */
  LVAL            lv_fillptr;    /* fillpointer location for facets */
  char            *facet_if;     /* facet_if bitvector */
  gt_tri_rec      s;             /* thing data structure */
  csry_rec        *m;            /* the thing's facet array */
  int             num_facets;    /* number of facets */
  int             *cut_q;        /* queue of indices of cut facets */
  int             head = -1;     /* element *before* head of cut queue */
  int             tail = -1;      /* tail of cut queue */
  int             stopper = 0;   /* marker for end of a level */
  int             h;             /* facet index at head of queue */
  int             f0, f1, f2;    /* facet vertex indices */
  int             g0, g1, g2;    /* facet vertex indices */
  int             l, f;          /* loop indices */

  int        toProt = 5;
  xlstkcheck(toProt);
  xlprotect(lv_thing);
  xlsave(lv_facets);
  xlsave(lv_facet_if);
  xlsave(lv_shape);
  xlsave(lv_fillptr);

  /* parse the thing we're playing with */
  xthlC2_Init_Tri_Rec(&s, NIL, NIL, NULL);
  xthlB1_Process_Thing(&s, lv_thing);
  num_facets = s.fLen;

  if ((facet < 0) || (facet >= num_facets)) 
    xlerror("facet out of range", facet);

  /* create an array to track which facets need to be dropped --     */
  /* make it as big as the number of facets to guarantee enough room */
printf("allocating space (%d facets)...\n", num_facets);
  cut_q = (int *) calloc(num_facets, sizeof(int));
  if (!cut_q) xlerror("xcut01_Remove_Neighbors: calloc failed!");

  /* get facet_if bitvector (if needed, create one with all facets visible) */
printf("getting :facet-if vector...\n");
  lv_facets   = xthl74_GetProp(&lv_thing, k_facetrelation, NIL, 0);
  lv_facet_if = xsendmsg2(lv_facets, k_getarray, k_facetif, NIL);

  if (null(lv_facet_if)) {
printf("don't have :facet-if, so make one...\n");
    m = (csry_rec*) gobjimmbase(lv_facets);
    lv_shape = cons(cvfixnum(m->dim[0]), NIL);
    lv_facet_if = xsendmsg3(lv_x01v, k_new, lv_shape,
			    k_initialelement, cvfixnum(1));
    xsendmsg2(lv_facets, k_setarray, k_facetif, lv_facet_if);

    /* set fill pointer to proper place */

    lv_fillptr = xsendmsg0(lv_facets, k_fillpointer);
    xsendmsg1(lv_facet_if, k_setffillpointer, lv_fillptr);

  }
  facet_if = csry_base(lv_facet_if);

  /* initialize queue with starting facet */
  cut_q[++tail] = facet;
  XCUT_SET_BIT(facet_if, facet, 0);

  /* triangle case */
  if (s.f3 == NULL) {
    for (l = levels; l --> 0; ) {
printf("running level %d...\n", l);
      stopper = tail;
      while (head < stopper) {
	head++;
	h = cut_q[head];
	f0 = s.f0[h];       /* get point indices */
	f1 = s.f1[h];
	f2 = s.f2[h];
	
	/* add all visible neighbor facets to the cut queue */
	for (f = num_facets; f --> 0; ) {
	  g0 = s.f0[f];  g1 = s.f1[f];  g2 = s.f2[f];
	  if (XCUT_GET_BIT(facet_if, f) && 
/*	      xcut0a_Tri_Shared_Vertex(s, h, f)) */
	      XCUT0B_TRI_SHARED_VERTEX(s, f0, f1, f2, g0, g1, g2))
	    {
	    cut_q[++tail] = f;
	    XCUT_SET_BIT(facet_if, f, 0);
	  }
	}   /* end for f */
      }     /* end while */
    }       /* end for l */
  }         /* end triangle case */
  
  /* rectangle case */
  else {
    printf("Add the rectangle case here!\n");
  }         /* end rectangle case */

  free(cut_q);
  xlpopn(toProt);
}

/* }}} */
/* {{{ xcut02_Remove_Neighbors_Fn           		       		*/

/* Lisp name:  XCUT-REMOVE-NEIGHBORS
 *
 * Make polygons within a certain neighborhood invisible. 
 */

LVAL xcut02_Remove_Neighbors_Fn() {

  LVAL                lv_thing;  /* the object of interest */
  LVAL                lv_num;    /* temporary number LVAL */
  int                 facet;     /* index of the starting facet */
  int                 levels;    /* # of hops away from start to cut */
 
  int        toProt = 2;
  xlstkcheck(toProt);
  xlsave(lv_thing);
  xlsave(lv_num);

  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();
    
    if        (key == k_thing) {   /* :THING */
      lv_thing = xlgalist();
    }
    else if   (key == k_facet) {   /* :FACET */
      lv_num = xlgafixnum();
      facet  = getfixnum(lv_num);
    }
    else if   (key == k_levels) {  /* :LEVELS */
      lv_num = xlgafixnum();
      levels = getfixnum(lv_num);
    }
    else {
      xlerror("Bad XCUT-REMOVE-NEIGHBORS keyword", key);
    }
  }

  /* error-checking */
  if (!lv_thing) xlfail("XCUT-REMOVE-NEIGHBORS: missing :THING");

  xcut01_Remove_Neighbors(lv_thing, facet, levels);

  xlpopn(toProt);
  return lv_thing;
}

/* }}} */
/* {{{ xcut03_Remove_Region                                             */

/* Remove spherical region around a selected point. */

void xcut03_Remove_Region(LVAL lv_thing, geo_point p, float radius) {

  LVAL            lv_facets;     /* thing's facet relation */
  LVAL            lv_facet_if;   /* facet_if bitvector (as an LVAL) */
  LVAL            lv_shape;      /* LVAL dimensions */
  LVAL            lv_fillptr;    /* fillpointer location for facets */
  char            *facet_if;     /* facet_if bitvector */
  gt_tri_rec      s;             /* thing data structure */
  csry_rec        *m;            /* the thing's facet array */
  int             num_facets;    /* number of facets */
  geo_point       p0, p1, p2;    /* facet vertices */
  int             f;             /* loop indices */
  double          d0, d1, d2;
  float           c0x_2, c0y_2, c0z_2, c0_2;
  double          c0;

  int        toProt = 5;
  xlstkcheck(toProt);
  xlprotect(lv_thing);
  xlsave(lv_facets);
  xlsave(lv_facet_if);
  xlsave(lv_shape);
  xlsave(lv_fillptr);

  /* parse the thing we're playing with */
  xthlC2_Init_Tri_Rec(&s, NIL, NIL, NULL);
  xthlB1_Process_Thing(&s, lv_thing);
  num_facets = s.fLen;

  /* get facet_if bitvector (if needed, create one with all facets visible) */
printf("getting :facet-if vector...\n");
  lv_facets   = xthl74_GetProp(&lv_thing, k_facetrelation, NIL, 0);
  lv_facet_if = xsendmsg2(lv_facets, k_getarray, k_facetif, NIL);

  if (null(lv_facet_if)) {
printf("don't have :facet-if, so make one...\n");
    m = (csry_rec*) gobjimmbase(lv_facets);
    lv_shape = cons(cvfixnum(m->dim[0]), NIL);
    lv_facet_if = xsendmsg3(lv_x01v, k_new, lv_shape,
			    k_initialelement, cvfixnum(1));
    xsendmsg2(lv_facets, k_setarray, k_facetif, lv_facet_if);

    /* set fill pointer to proper place */
    lv_fillptr = xsendmsg0(lv_facets, k_fillpointer);
    xsendmsg1(lv_facet_if, k_setffillpointer, lv_fillptr);
  }
  facet_if = csry_base(lv_facet_if);

  /* triangle case */
  if (s.f3 == NULL) {
    /* compute facet's centroid */
/*
    c.x = (s.x[s.f0[facet]] + s.x[s.f1[facet]] + s.x[s.f2[facet]]) / 3.0;
    c.y = (s.y[s.f0[facet]] + s.y[s.f1[facet]] + s.y[s.f2[facet]]) / 3.0;
    c.z = (s.z[s.f0[facet]] + s.z[s.f1[facet]] + s.z[s.f2[facet]]) / 3.0;
printf("cx = (%f,%f,%f)\n", c.x, c.y, c.z);
*/
printf("p = (%f,%f,%f)\n", p.x, p.y, p.z);

    /* run through facets and remove any with a vertex in range */
    for (f = num_facets; f --> 0; ) {
      p0.x = s.x[s.f0[f]];  p0.y = s.y[s.f0[f]];  p0.z = s.z[s.f0[f]];
      p1.x = s.x[s.f1[f]];  p1.y = s.y[s.f1[f]];  p1.z = s.z[s.f1[f]];
      p2.x = s.x[s.f2[f]];  p2.y = s.y[s.f2[f]];  p2.z = s.z[s.f2[f]];
      
/*
      c0x_2 = (c.x - p0.x)*(c.x - p0.x);
      c0y_2 = (c.y - p0.y)*(c.y - p0.y);
      c0z_2 = (c.z - p0.z)*(c.z - p0.z);
      c0_2  = c0x_2 + c0y_2 + c0z_2;
      c0    = sqrt((double) c0_2);
*/
      d0 = XCUT_DIST(p,p0);
      d1 = XCUT_DIST(p,p1);
      d2 = XCUT_DIST(p,p2);
/*
printf("\n");
printf("p0 = (%f,%f,%f)\n", p0.x, p0.y, p0.z);
printf("p1 = (%f,%f,%f)\n", p1.x, p1.y, p1.z);
printf("p2 = (%f,%f,%f)\n", p2.x, p2.y, p2.z);
printf("d0 = %lf, d1 = %lf, d2 = %lf\n", d0, d1, d2);
*/
      if ((XCUT_DIST(p,p0) <= radius) ||
	  (XCUT_DIST(p,p1) <= radius) ||
	  (XCUT_DIST(p,p2) <= radius)) {
	XCUT_SET_BIT(facet_if, f, 0);
      } /* end if */
    }   /* end for f */
  }     /* end triangle case */
  
  /* rectangle case */
  else {
    printf("Add the rectangle case here!\n");
  }         /* end rectangle case */

  xlpopn(toProt);
}

/* }}} */
/* {{{ xcut04_Remove_Region_Fn           		       		*/

/* Lisp name:  XCUT-REMOVE-REGION
 *
 * Make polygons within a certain region invisible
 */

LVAL xcut04_Remove_Region_Fn() {

  LVAL       lv_thing;  /* the object of interest */
  LVAL       lv_num;    /* temporary number LVAL */
  float      radius;    /* radius of removal region */
  geo_point  point;     /* point where user clicked */
 
  int        toProt = 2;
  xlstkcheck(toProt);
  xlsave(lv_thing);
  xlsave(lv_num);

  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();
    
    if        (key == k_thing) {   /* :THING */
      lv_thing = xlgalist();
    }
    else if   (key == k_point) {   /* :POINT */
      lv_num = xlgalist();
      lib16_List_To_Point(&point, lv_num);
    }
    else if   (key == k_radius) {  /* :RADIUS */
      radius = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
    }
    else {
      xlerror("Bad XCUT-REMOVE-REGION keyword", key);
    }
  }

  /* error-checking */
  if (!lv_thing) xlfail("XCUT-REMOVE-REGION: missing :THING");

  xcut03_Remove_Region(lv_thing, point, radius);

  xlpopn(toProt);
  return lv_thing;
}

/* }}} */
/* {{{ xcut05_Compute_Shell                                             */

/* Compute a voxel shell from a radial surface.  Voxels in the shell
 * will be set to 1 if they are in the region of interest, else 0.
 *
 * New strategy:
 *
 * Reorder the loops, so the facet loop is on the outside.  This way,
 * we can build a bounding box around the *facet*, which will remove 
 * most of the voxels from consideration.
 *
 */

void xcut05_Compute_Shell(
     LVAL     lv_mask,           /* storage for voxel shell */
     LVAL     lv_thing,          /* the surface for computing the shell */
     int      start,             /* start/end points in thing's point array */
     int      end,
     float    inner_radius,      /* radius of inclusion inside */
     float    outer_radius,      /* radius of inclusion outside */
     int      x_dim,             /* dimensions of voxel dataset */
     int      y_dim,
     int      z_dim,
     int      min_i, int max_i,  /* voxel range to consider */
     int      min_j, int max_j,
     int      min_k, int max_k
){
/*  CSRY_UNSIGNED16* mask;      /* the mask's actual voxel array */
  char            *mask;      /* the mask's actual voxel bit array */
  gt_tri_rec       r;         /* record for the thing */
  geo_point        p;         /* current vertex */
  geo_point        v;         /* current voxel */
  geo_point        min,max;   /* bounding box for thing */
  int              x,y,z;     /* voxel coords */
  int              i;         /* loop indices */
  int              v0,v1,v2;  /* indices into point array */
  int              mask_val = 1; /* value assigned to masked voxels */
  int              index;     /* index into the voxel array */
  float            *D;        /* D values for plane equations */
  double           d_plane;   /* distance from voxel to facet plane */
  double           d_tri;     /* distance from voxel to triangle */
  geo_point        e;         /* vector for a facet edge */
  xcut_plane       *e0, *e1, *e2; /* plane equations for facet edges */ 
  float            d0,d1,d2;  /* voxel-to-edge-plane distances */
  int              dim = x_dim * y_dim * z_dim;
  int              loc;       /* encoded location of voxel rel to facet */
  float            sqr_inner_radius = XCUT_SQR(inner_radius);
  float            sqr_outer_radius = XCUT_SQR(outer_radius);
  float            max_radius; /* max of [inner/outer]_radius */
  int              step = 1;   /* test a downsampled version (kph, 98Mar15) */

  /* stats variables */
  int              out = 0;   /* count of voxels outside bbox */
  long             far = 0;   /* count of voxels too far from planes */
  long             close = 0; /* count of voxels close to planes */
  int              total_voxels; /* number of voxels */
  int    c000=0,c001=0,c010=0,c011=0;    /* case counts */
  int    c100=0,c101=0,c110=0,c111=0;
  int    zeroes=0;

  int        toProt = 2;
  xlstkcheck(toProt);
  xlprotect(lv_mask);
  xlprotect(lv_thing);

/*
   printf("Computing mask with INNER=%f, OUTER=%f\n", 
       inner_radius, outer_radius);
*/

  /* parse the LVAL arguments */
/*  mask = (CSRY_UNSIGNED16*) csry_base(lv_mask); */
  mask = (char *) csry_base(lv_mask);
  xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
  xthlB1_Process_Thing( &r, lv_thing );

  /* clear out the entire mask bit array */
  memset( (void *)mask, 0, ((dim +7) >> 3) );

  /* decide how much we'll need to pad bounding boxes */
  max_radius = (inner_radius > outer_radius ? inner_radius : outer_radius);

  /* error-checking */
  if (! r.got_facet_normals) 
    xlfail("XCUT-COMPUTE-SHELL: need facet normals");
  if (! r.got_triangles)
    xlfail("XCUT-COMPUTE-SHELL: only works with triangles (for now)");

  /* allocate extra arrays we need for plane equation info */
  if ((D = (float*) calloc(sizeof(float), r.fLen)) == NULL) {
    xlfail("XCUT-COMPUTE-SHELL: can't allocate space"); }
  if ((e0 = (xcut_plane*) calloc(sizeof(xcut_plane), r.fLen)) == NULL) {
    xlfail("XCUT-COMPUTE-SHELL: can't allocate space"); }
  if ((e1 = (xcut_plane*) calloc(sizeof(xcut_plane), r.fLen)) == NULL) {
    xlfail("XCUT-COMPUTE-SHELL: can't allocate space"); }
  if ((e2 = (xcut_plane*) calloc(sizeof(xcut_plane), r.fLen)) == NULL) {
    xlfail("XCUT-COMPUTE-SHELL: can't allocate space"); }

  /* sanity-check the min/max values. (should be done by caller, but */
  /* better to be safe than have random seg faults.)
  if (min_i < 0)  min_i = 0;    if (max_i > x_dim)  max_i = x_dim;
  if (min_j < 0)  min_j = 0;    if (max_j > y_dim)  max_j = y_dim;
  if (min_k < 0)  min_k = 0;    if (max_k > z_dim)  max_k = z_dim;

  /* for each facet... */
  for (i = r.fLen; i-->0; ) {
/*    printf("facet %d...\n", i); */

    /* grab vertex indices */
    v0 = r.f0[i];  v1 = r.f1[i];  v2 = r.f2[i];

    /* compute the D values for each triangle's plane equation */
    /* P in plane = (Px, Py, Pz),  D = - (A*Px + B*Py + C*Pz)  */
    D[i] = -(r.fnx[i]*r.x[v0] + r.fny[i]*r.y[v0] + r.fnz[i]*r.z[v0]);

    /* Compute equations for the planes through facet's edges, */
    /* perpendicular to the facet's plane.                     */
    /* (These are NOT normalized at the moment.)               */

    /* compute vector for v0->v1 */
    e.x = r.x[v1] - r.x[v0];
    e.y = r.y[v1] - r.y[v0];
    e.z = r.z[v1] - r.z[v0];
    /* compute cross-product of vector with plane's normal */
    /* (from p. 1104 of Foley & VanDam, v = e and w = fn)  */
    e0[i].a = e.y * r.fnz[i] - e.z * r.fny[i];
    e0[i].b = e.z * r.fnx[i] - e.x * r.fnz[i];
    e0[i].c = e.x * r.fny[i] - e.y * r.fnx[i];
    e0[i].d = -(e0[i].a*r.x[v0] + e0[i].b*r.y[v0] + e0[i].c*r.z[v0]);

    /* check values */
/*
    printf("v0->v1:       (%f,%f,%f)\n", e.x, e.y, e.z);
    printf("facet plane:  (%f,%f,%f), D = %f\n", 
	   r.fnx[i], r.fny[i], r.fnz[i], D[i]);
    printf("edge plane:   (%f,%f,%f), D = %f\n", 
	   e0[i].a, e0[i].b, e0[i].c, e0[i].d);
    printf("edge dot facet: %f\n",
	   e.x*r.fnx[i] + e.y*r.fny[i] + e.z*r.fnz[i]);
    printf("facet dot plane: %f\n",
	   e0[i].a*r.fnx[i] + e0[i].b*r.fny[i] + e0[i].c*r.fnz[i]);
    printf("edge dot plane: %f\n", 
	   e.x*e0[i].a + e.y*e0[i].b + e.z*e0[i].c);
    printf("\n");
*/
    /* v1->v2 */
    e.x = r.x[v2] - r.x[v1];
    e.y = r.y[v2] - r.y[v1];
    e.z = r.z[v2] - r.z[v1];
    e1[i].a = e.y * r.fnz[i] - e.z * r.fny[i];
    e1[i].b = e.z * r.fnx[i] - e.x * r.fnz[i];
    e1[i].c = e.x * r.fny[i] - e.y * r.fnx[i];
    e1[i].d = -(e1[i].a*r.x[v1] + e1[i].b*r.y[v1] + e1[i].c*r.z[v1]);

    /* v2->v0 */
    e.x = r.x[v0] - r.x[v2];
    e.y = r.y[v0] - r.y[v2];
    e.z = r.z[v0] - r.z[v2];
    e2[i].a = e.y * r.fnz[i] - e.z * r.fny[i];
    e2[i].b = e.z * r.fnx[i] - e.x * r.fnz[i];
    e2[i].c = e.x * r.fny[i] - e.y * r.fnx[i];
    e2[i].d = -(e2[i].a*r.x[v2] + e2[i].b*r.y[v2] + e2[i].c*r.z[v2]);    

    /* compute the bounding box for the facet */
    min.x = XCUT_MIN3(r.x[v0], r.x[v1], r.x[v2]);
    min.y = XCUT_MIN3(r.y[v0], r.y[v1], r.y[v2]);
    min.z = XCUT_MIN3(r.z[v0], r.z[v1], r.z[v2]);
    max.x = XCUT_MAX3(r.x[v0], r.x[v1], r.x[v2]);
    max.y = XCUT_MAX3(r.y[v0], r.y[v1], r.y[v2]);
    max.z = XCUT_MAX3(r.z[v0], r.z[v1], r.z[v2]);

    /* extend bounding box to include radius */
    min.x -= max_radius;  min.y -= max_radius;  min.z -= max_radius;
    max.x += max_radius;  max.y += max_radius;  max.z += max_radius;

    /* clip as necessary */
    /* (BUGFIX: kph, 98Jun05) */
    /* (added check relative to ijk bounds: kph, 98Jul01) */

    if (min.x < min_i)  min.x = min_i;
    if (min.y < min_j)  min.y = min_j;
    if (min.z < min_k)  min.z = min_k;
    if (max.x > max_i)  max.x = max_i;
    if (max.y > max_j)  max.y = max_j;
    if (max.z > max_k)  max.z = max_k;

    /* clip as necessary (BUGFIX: kph, 98Jun05) */
/*
    if (min.x < 0)      min.x = 0;
    if (min.y < 0)      min.y = 0;
    if (min.z < 0)      min.z = 0;
    if (max.x > x_dim)  max.x = x_dim;
    if (max.y > y_dim)  max.y = y_dim;
    if (max.z > z_dim)  max.z = z_dim;
*/

/*
    if ((min.x < 0)     || (min.y < 0)     || (min.z < 0) ||
	(max.x > x_dim) || (max.y > y_dim) || (max.z > z_dim)) {
printf("*************************************************\n");
printf("BOUNDS PROBLEM!~%");
printf("Min: (%0.2f, %0.2f, %0.2f)\n", min.x, min.y, min.z);
printf("Max: (%0.2f, %0.2f, %0.2f)\n", max.x, max.y, max.z);
printf("*************************************************\n");
    }
*/
    /* run through the voxels, checking distance to each vertex */
/*
    for (    z = min.z;   z < max.z;   z++) {
      for (  y = min.y;   y < max.y;   y++) {
	for (x = min.x;   x < max.x;   x++) {
*/
    for (    z = min.z;   z < max.z;   z += step) {
      for (  y = min.y;   y < max.y;   y += step) {
	for (x = min.x;   x < max.x;   x += step) {

	  index = (z*y_dim + y)*x_dim + x;

	  /* if this voxel is already in the mask, then move on */
	  if (mask_val == XCUT_GET_BIT(mask, index)) {
	    continue; 
	  }

	  /* should I normalize to be safe? */
	  d_plane = x*r.fnx[i] + y*r.fny[i] + z*r.fnz[i] + D[i];

	  if (( d_plane <= inner_radius) &&  /* + is inside, - is out */
	      ( -outer_radius <= d_plane)) {
	    close++;

	    /* perform half-plane tests to see where point is */
	    d0 = e0[i].a*x + e0[i].b*y + e0[i].c*z + e0[i].d;
	    d1 = e1[i].a*x + e1[i].b*y + e1[i].c*z + e1[i].d;
	    d2 = e2[i].a*x + e2[i].b*y + e2[i].c*z + e2[i].d;
	    loc = ((d2 > 0) << 2) + ((d1 > 0) << 1) + (d0 > 0);
	    switch (loc) {
	    case 0:  /* --- (inside triangle) */
	      XCUT_SET_BIT(mask, index, mask_val);  
	      break;
	    case 1:  /* --+ (edge 01)  */
	      break;
	    case 2:  /* -+- (edge 12)  */
	      break;
	    case 3:  /* -++ (vertex 1) */
	      v1 = r.f1[i];
	      d_tri = XCUT_SQR_DIST(r.x[v1], r.y[v1], r.z[v1], x, y, z);
	      if (((d_plane >= 0) ? (d_tri <= sqr_inner_radius)
		                  : (d_tri <= sqr_outer_radius))) {
		XCUT_SET_BIT(mask, index, mask_val); }
	      break;

	    case 4:  /* +-- (edge 20)  */
	      break;
	    case 5:  /* +-+ (vertex 0) */
	      v0 = r.f0[i];
	      d_tri = XCUT_SQR_DIST(r.x[v0], r.y[v0], r.z[v0], x, y, z);
	      if (((d_plane >= 0) ? (d_tri <= sqr_inner_radius)
		                  : (d_tri <= sqr_outer_radius))) {
		XCUT_SET_BIT(mask, index, mask_val); }
	      break;

	    case 6:  /* ++- (vertex 2) */
	      v2 = r.f2[i];
	      d_tri = XCUT_SQR_DIST(r.x[v2], r.y[v2], r.z[v2], x, y, z);
	      if (((d_plane >= 0) ? (d_tri <= sqr_inner_radius)
		                  : (d_tri <= sqr_outer_radius))) {
		XCUT_SET_BIT(mask, index, mask_val); }
	      break;

	    default: /* shouldn't happen */
	      printf("ALL-POSITIVE CASE: WHAT HAPPENED???\n");
	    }
	  } else {
	    far++;
	  }
	} /* end for x */
      }   /* end for y */
    }     /* end for z */
  }       /* end for each facet */

  /* print stats */
  total_voxels = ((max_k - min_k + 1) * 
		  (max_j - min_j + 1) * 
		  (max_i - min_i + 1));
/*
  printf("min: (%f,%f,%f)\n", min.x, min.y, min.z);
  printf("max: (%f,%f,%f)\n", max.x, max.y, max.z);
  printf("\n");
  printf("Voxels outside bounding box:  %9d\n", out);
  printf("Voxels inside bounding box:   %9d\n", total_voxels - out);
  printf("----------------------------------------\n");
  printf("\n");
  printf("Total Voxels:                 %11d\n", total_voxels);
  printf("Voxel/facet pairs ruled out:  %11ld\n", far);
  printf("Voxel/facet pairs to check:   %11ld\n", close);
  printf("All zeroes:                   %11d\n", zeroes);
  printf("Case 000:                     %11d\n", c000);
  printf("Case 001:                     %11d\n", c001);
  printf("Case 010:                     %11d\n", c010);
  printf("Case 011:                     %11d\n", c011);
  printf("Case 100:                     %11d\n", c100);
  printf("Case 101:                     %11d\n", c101);
  printf("Case 110:                     %11d\n", c110);
  printf("Case 111:                     %11d\n", c111);
  printf("-------------------------------------------\n");
  printf("Total Voxel/facet pairs:      %11ld\n", close+far);
  printf("\n");
*/

  /* free up temp space we allocated here */
  free(D);
  free(e0);
  free(e1);
  free(e2);

  xlpopn(toProt);
}

/* }}} */
/* {{{ xcut06_Compute_Shell_Fn                                          */

/* Lisp name:  XCUT-COMPUTE-SHELL
 *
 * Compute a voxel shell from a radial surface.  Voxels in the shell
 * will be set to 1 if they are in the region of interest, else 0.
 */

LVAL xcut06_Compute_Shell_Fn() {

  LVAL       lv_mask;       /* the voxel array for the mask */
  LVAL       lv_val;        /* temporary LVAL */
  LVAL       lv_thing;      /* thing to use as a mask */
  int        start = 0;     /* start & end points in thing's point array */
  int        end = 0; 
  float      inner_radius = 2.0;  /* radius of inclusion when making mask */
  float      outer_radius = 2.0;
  int        x_dim;         /* dimensions of voxel dataset */
  int        y_dim;
  int        z_dim;
  int     min_i = 0, max_i = 256;  /* voxel range to consider */
  int     min_j = 0, max_j = 256;
  int     min_k = 0, max_k = 256;
  int     using_default_radius = 1;  /* flag if caller sets radius val */

  int        toProt = 3;
  xlstkcheck(toProt);
  xlsave(lv_mask);
  xlsave(lv_val);
  xlsave(lv_thing);

  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();
    
    if        (key == k_mask) {     /* :MASK */
      lv_mask = xlgaobject();
    }
    else if   (key == k_thing) {    /* :THING */
      lv_thing = xlgalist();
    }
    else if   (key == k_start) {    /* :START */
      lv_val = xlgafixnum();
      start  = getfixnum(lv_val);
    }
    else if   (key == k_end) {      /* :END */
      lv_val = xlgafixnum();
      end    = getfixnum(lv_val);
    }
    else if   (key == k_innerradius) {   /* :INNER-RADIUS */
      inner_radius = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
      using_default_radius = 0;
    }
    else if   (key == k_outerradius) {   /* :OUTER-RADIUS */
      outer_radius = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
      using_default_radius = 0;

    } else if (key == k_mini) {  min_i = getfixnum(xlgafixnum());
    } else if (key == k_maxi) {  max_i = getfixnum(xlgafixnum());
    } else if (key == k_minj) {  min_j = getfixnum(xlgafixnum());
    } else if (key == k_maxj) {  max_j = getfixnum(xlgafixnum());
    } else if (key == k_mink) {  min_k = getfixnum(xlgafixnum());
    } else if (key == k_maxk) {  max_k = getfixnum(xlgafixnum());
				  
    } else {
      xlerror("Bad XCUT-COMPUTE-SHELL keyword", key);
    }
  }


  /* error-checking */
  if (!lv_mask)   xlfail("XCUT-COMPUTE-SHELL: missing voxel :MASK");
  if (!lv_thing)  xlfail("XCUT-COMPUTE-SHELL: missing :THING");

  /* get dimensions of voxel array */
/*  if (lv_mask && xf2vp( lv_mask )) { */
  if (lv_mask && x01vp( lv_mask )) {
    xvol95_Get_X_Y_Z_Dimensions( &x_dim, &y_dim, &z_dim, lv_mask );
  } else {
    xlerror("XCUT-COMPUTE-SHELL: bad :MASK arg", lv_mask);
  }
  if (min_i < 0)  min_i = 0;    if (max_i > x_dim)  max_i = x_dim;
  if (min_j < 0)  min_j = 0;    if (max_j > y_dim)  max_j = y_dim;
  if (min_k < 0)  min_k = 0;    if (max_k > z_dim)  max_k = z_dim;

  /* need a thicker default shell for full-size datasets */
/*
  if (using_default_radius &&
      ((x_dim > 128) || (y_dim > 128) || (z_dim > 128))) {
    inner_radius *= 2;
    outer_radius *= 2;
  }
*/
  xcut05_Compute_Shell(lv_mask, lv_thing, start, end, 
		      inner_radius, outer_radius,
		      x_dim, y_dim, z_dim,
		      min_i, max_i,
		      min_j, max_j,
		      min_k, max_k
		      );

  xlpopn(toProt);
  return lv_mask;
}

/* }}} */
/* {{{ xcut07_Compute_Mask                                              */

/* Compute a filled voxel mask from a radial surface.  Voxels in the mask
 * will be set to 1 if they are in the region of interest, else 0.
 */

void xcut07_Compute_Mask(
     LVAL     lv_mask,           /* storage for voxel mask */
     LVAL     lv_thing,          /* the surface for computing the mask */
     int      start,             /* start/end points in thing's point array */
     int      end,
     float    inner_radius,      /* radius of inclusion inside */
     float    outer_radius,      /* radius of inclusion outside */
     int      x_dim,             /* dimensions of voxel dataset */
     int      y_dim,
     int      z_dim,
     geo_point seed,             /* point inside surface (for flood fill) */
     int      min_i, int max_i,  /* voxel range to consider */
     int      min_j, int max_j,
     int      min_k, int max_k
){
  char            *mask;         /* the mask's actual voxel bit array */
  int              mask_val = 1; /* value assigned to masked voxels */

  int        toProt = 2;
  xlstkcheck(toProt);
  xlprotect(lv_mask);
  xlprotect(lv_thing);

  /* need a thicker shell for full-size datasets? */
/*
  if ((x_dim > 128) || (y_dim > 128) || (z_dim > 128)) {
    radius = 2.0;
  }
*/
  /* start by building a shell from the surface */

  xcut05_Compute_Shell(lv_mask, lv_thing, start, end, 
		      inner_radius, outer_radius,
		      x_dim, y_dim, z_dim,
		      min_i, max_i,
		      min_j, max_j,
		      min_k, max_k
		      );

  /* get actual mask array */
  mask = (char *) csry_base(lv_mask);

  /* start the fill */
  xcut09_Boundary_Fill(mask, mask_val,
		       seed.x, seed.y, seed.z,
		       x_dim, y_dim, z_dim,
		       min_i, max_i,
		       min_j, max_j,
		       min_k, max_k
		       );
  xlpopn(toProt);
}

/* }}} */
/* {{{ xcut08_Compute_Mask_Fn                                           */

/* Lisp name:  XCUT-COMPUTE-MASK
 *
 * Compute a filled voxel mask from a radial surface.  Voxels in the mask
 * will be set to 1 if they are in the region of interest, else 0.
 */

LVAL xcut08_Compute_Mask_Fn() {

  LVAL       lv_mask;       /* the voxel array for the mask */
  LVAL       lv_val;        /* temporary LVAL */
  LVAL       lv_thing;      /* thing to use as a mask */
  int        start = 0;     /* start & end points in thing's point array */
  int        end = 0; 
  float      inner_radius = 2.0;  /* radius of inclusion when making mask */
  float      outer_radius = 2.0;
  int        x_dim;         /* dimensions of voxel dataset */
  int        y_dim;
  int        z_dim;
  int     min_i = 0, max_i = 256;  /* voxel range to consider */
  int     min_j = 0, max_j = 256;
  int     min_k = 0, max_k = 256;
  geo_point  seed;          /* seed point inside region (for flood fill) */

  int        toProt = 3;
  xlstkcheck(toProt);
  xlsave(lv_mask);
  xlsave(lv_val);
  xlsave(lv_thing);

  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();
    
    if        (key == k_mask) {     /* :MASK */
      lv_mask = xlgaobject();
    }
    else if   (key == k_thing) {    /* :THING */
      lv_thing = xlgalist();
    }
    else if   (key == k_start) {    /* :START */
      lv_val = xlgafixnum();
      start  = getfixnum(lv_val);
    }
    else if   (key == k_end) {      /* :END */
      lv_val = xlgafixnum();
      end    = getfixnum(lv_val);
    }
    else if   (key == k_innerradius) {   /* :INNER-RADIUS */
      inner_radius = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
    }
    else if   (key == k_outerradius) {   /* :OUTER-RADIUS */
      outer_radius = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
    }
    else if   (key == k_seed) {     /* :SEED */
      lv_val = xlgalist();
      lib16_List_To_Point(&seed, lv_val);
    } else if (key == k_mini) {  min_i = getfixnum(xlgafixnum());
    } else if (key == k_maxi) {  max_i = getfixnum(xlgafixnum());
    } else if (key == k_minj) {  min_j = getfixnum(xlgafixnum());
    } else if (key == k_maxj) {  max_j = getfixnum(xlgafixnum());
    } else if (key == k_mink) {  min_k = getfixnum(xlgafixnum());
    } else if (key == k_maxk) {  max_k = getfixnum(xlgafixnum());
				  
    } else {
      xlerror("Bad XCUT-COMPUTE-MASK keyword", key);
    }
  }


  /* error-checking */
  if (!lv_mask)   xlfail("XCUT-COMPUTE-MASK: missing voxel :MASK");
  if (!lv_thing)  xlfail("XCUT-COMPUTE-MASK: missing :THING");

  /* get dimensions of voxel array */
/*  if (lv_mask && xf2vp( lv_mask )) { */
  if (lv_mask && x01vp( lv_mask )) {
    xvol95_Get_X_Y_Z_Dimensions( &x_dim, &y_dim, &z_dim, lv_mask );
  } else {
    xlerror("XCUT-COMPUTE-MASK: bad :MASK arg", lv_mask);
  }
  if (min_i < 0)  min_i = 0;    if (max_i > x_dim)  max_i = x_dim;
  if (min_j < 0)  min_j = 0;    if (max_j > y_dim)  max_j = y_dim;
  if (min_k < 0)  min_k = 0;    if (max_k > z_dim)  max_k = z_dim;

  xcut07_Compute_Mask(lv_mask, lv_thing, start, end, 
		      inner_radius, outer_radius,
		      x_dim, y_dim, z_dim,
		      seed,
		      min_i, max_i,
		      min_j, max_j,
		      min_k, max_k
		      );

  xlpopn(toProt);
  return lv_mask;
}

/* }}} */
/* {{{ xcut09_Boundary_Fill                                             */

/* Core function for doing a boundary-based flood fill.  If voxel
 * (x,y,z) is inside bounds and not part of the boundary, fill it and
 * check its neighbors.  (This version uses a queue of voxels to
 * search instead of recursive calls to itself.) 
 *
 * In the queue, head should always point to the first element, and
 * tail should point to the element *after* the last element (i.e. 
 * the next slot to fill).  An empty queue is signaled when head and
 * tail are equal.
 *
 * IN THIS VERSION: voxels are checked before adding to the queue
 * (trying to keep queue size under control)
 */

void xcut09_Boundary_Fill(
     char *mask,                 /* voxel array */
     int  mask_val,              /* boundary value */
     int  seed_x,                /* current voxel */
     int  seed_y, 
     int  seed_z,               
     int  x_dim,                 /* voxel array bounds */
     int  y_dim, 
     int  z_dim,   
     int  min_i, int max_i,      /* range being considered */
     int  min_j, int max_j,
     int  min_k, int max_k
){
  vec3c  *Q;                  /* the queue of voxels to check */
  int    base_Qsize = 1<<16;  /* initial size of voxel queue */
  int    Qsize = base_Qsize;  /* current size of the voxel queue */
  int    head;                /* head of queue */
  int    tail;                /* tail of queue */
  int    count;               /* number of elements in queue */
  int    index;               /* index into voxel array */
  int    nx,ny,nz;            /* neighbor voxel coords */
/*  int    i,j,k;             /* coord offsets */
  unsigned char    x,y,z;            /* current voxel coords */
  int    num_neighbors=6;  /* number of voxel's neighbors */

  int    step = 1;   /* test doing a downsampled version (kph, 98Mar15) */

  /* return immediately if seed is outside bounds */
  if ((seed_x < min_i) || (seed_y < min_j) || (seed_z < min_k) &&
      (seed_x > max_i) || (seed_y > max_j) || (seed_z > max_k)) {
    return;
  }

  /* hack for downsampled version test -- need seed to fall onto same
     grid as voxels in the shell (kph, 98Mar15) */
/*
  seed_x = seed_x & 0;
  seed_y = seed_y & 0;
  seed_z = seed_z & 0;
*/

  /* make sure voxel coords can be stored in 3 bytes */
  if ((x_dim > 256) || (y_dim > 256) | (z_dim > 256)) {
    xlfail("XCUT-BOUNDARY-FILL: need larger queue entries!"); }

  /* allocate initial queue */
  if ((Q = (vec3c*) calloc(Qsize, sizeof(vec3c))) == NULL) {
    xlfail("XCUT-BOUNDARY-FILL: can't allocate space for voxel queue"); }

  /* initialize with starting point */
  Q[0].x = seed_x;
  Q[0].y = seed_y;
  Q[0].z = seed_z;
  head = 0;
  tail = 1;
  count = 1;

/*
printf("bounds:  %d->%d, %d->%d, %d->%d\n",
	 min_i, max_i,
	 min_j, max_j,
	 min_k, max_k);
printf("seed:  %d, %d, %d\n", seed_x, seed_y, seed_z);
*/

/*  while (head != tail) { */

  /* try an emergency bail-out if we go too low -- probably a sign
     that there's a hole in the shell */

  while ((head != tail) &&
	 (Q[head].y > 0)) {

    /* remove next element from queue */
    x = Q[head].x;
    y = Q[head].y;
    z = Q[head].z;
    head = (head + 1) % Qsize;
    count--;

    /* expand queue if needed (conservative) */
    while ((count + num_neighbors) >= (Qsize - 1)) {
      Qsize += base_Qsize;
      printf("Allocating more space (%d entries)...\n", Qsize);
      Q = (vec3c *) realloc(Q, Qsize * sizeof(vec3c));
      if (Q == NULL) {
	xlfail("XCUT-BOUNDARY-FILL: can't reallocate space for queue");
      }
      printf("continuing...\n");
    }

    /* check each neighbor -- if a voxel is in bounds and not */
    /* filled, then fill and add to queue */

    /* x-axis neighbors */
/*    nx = x-1;   ny = y;   nz = z; */
    nx = x-step;   ny = y;   nz = z;
    if ((nx >= min_i) && (ny >= min_j) && (nz >= min_k) &&
	(nx <  max_i) && (ny <  max_j) && (nz <  max_k)) {
      index = (nz*y_dim + ny)*x_dim + nx;
      if (XCUT_GET_BIT(mask, index) != mask_val) {
	XCUT_SET_BIT(mask, index, mask_val);
	Q[tail].x = nx;  Q[tail].y = ny;  Q[tail].z = nz;
	tail = (tail + 1) % Qsize;
	count++;
      }
    }
/*    nx = x+1; */
    nx = x+step;
    if ((nx >= min_i) && (ny >= min_j) && (nz >= min_k) &&
	(nx <  max_i) && (ny <  max_j) && (nz <  max_k)) {
      index = (nz*y_dim + ny)*x_dim + nx;
      if (XCUT_GET_BIT(mask, index) != mask_val) {
	XCUT_SET_BIT(mask, index, mask_val);
	Q[tail].x = nx;  Q[tail].y = ny;  Q[tail].z = nz;
	tail = (tail + 1) % Qsize;
	count++;
      }
    }

    /* y-axis neighbors */
/*    nx = x;   ny = y-1;  */
    nx = x;   ny = y-step;
    if ((nx >= min_i) && (ny >= min_j) && (nz >= min_k) &&
	(nx <  max_i) && (ny <  max_j) && (nz <  max_k)) {
      index = (nz*y_dim + ny)*x_dim + nx;
      if (XCUT_GET_BIT(mask, index) != mask_val) {
	XCUT_SET_BIT(mask, index, mask_val);
	Q[tail].x = nx;  Q[tail].y = ny;  Q[tail].z = nz;
	tail = (tail + 1) % Qsize;
	count++;
      }
    }
/*    ny = y+1; */
    ny = y+step;
    if ((nx >= min_i) && (ny >= min_j) && (nz >= min_k) &&
	(nx <  max_i) && (ny <  max_j) && (nz <  max_k)) {
      index = (nz*y_dim + ny)*x_dim + nx;
      if (XCUT_GET_BIT(mask, index) != mask_val) {
	XCUT_SET_BIT(mask, index, mask_val);
	Q[tail].x = nx;  Q[tail].y = ny;  Q[tail].z = nz;
	tail = (tail + 1) % Qsize;
	count++;
      }
    }

    /* z-axis neighbors */
/*    ny = y;   nz = z-1; */
    ny = y;   nz = z-step; 
    if ((nx >= min_i) && (ny >= min_j) && (nz >= min_k) &&
	(nx <  max_i) && (ny <  max_j) && (nz <  max_k)) {
      index = (nz*y_dim + ny)*x_dim + nx;
      if (XCUT_GET_BIT(mask, index) != mask_val) {
	XCUT_SET_BIT(mask, index, mask_val);
	Q[tail].x = nx;  Q[tail].y = ny;  Q[tail].z = nz;
	tail = (tail + 1) % Qsize;
	count++;
      }
    }
/*    nz = z+1; */
    nz = z+step;
    if ((nx >= min_i) && (ny >= min_j) && (nz >= min_k) &&
	(nx <  max_i) && (ny <  max_j) && (nz <  max_k)) {
      index = (nz*y_dim + ny)*x_dim + nx;
      if (XCUT_GET_BIT(mask, index) != mask_val) {
	XCUT_SET_BIT(mask, index, mask_val);
	Q[tail].x = nx;  Q[tail].y = ny;  Q[tail].z = nz;
	tail = (tail + 1) % Qsize;
	count++;
      }
    }
  }       /* end while head != tail */

  /* for feedback on queue size, print final queue size */
/*
  printf("****************************************\n");
  printf("FINAL QUEUE SIZE: %d entries\n", Qsize);
  printf("****************************************\n");
*/
if (count > 0) { printf("WARNING!  DANGER, WILL ROBINSON!  PROBABLE LEAK!\n"); }

  free(Q);
}

/* }}} */
/* {{{ xcut10_Boundary_Fill_Rec                                         */

/* Core function for doing a boundary-based flood fill -- recursive
 * version.  If voxel (x,y,z) is inside bounds and not part of the
 * boundary, fill it and check its neighbors.
 */

void xcut10_Boundary_Fill_Rec(
     char *mask,                 /* voxel array */
     int  mask_val,              /* boundary value */
     int  x,                     /* current voxel */
     int  y, 
     int  z,               
     int  x_dim,                 /* voxel array bounds */
     int  y_dim, 
     int  z_dim,   
     int  min_i, int max_i,      /* range being considered */
     int  min_j, int max_j,
     int  min_k, int max_k
){
  /* skip voxels outside the bounding box */
  if ((x >= min_i) && (y >= min_j) && (z >= min_k) &&
      (x <= max_i) && (y <= max_j) && (z <= max_k)) {

    int index = (z*y_dim + y)*x_dim + x;
    int i,j,k;

    if (XCUT_GET_BIT(mask, index) != mask_val) {
/*      printf("  filling (%d,%d,%d)\n", x, y, z); */
      XCUT_SET_BIT(mask, index, mask_val);  
      /* check 6 neighbors */
      for (i = -1; i <= 1; i += 2) {
	for (j = -1; j <= 1; j += 2) {
	  for (k = -1; k <= 1; k += 2) {
	    xcut10_Boundary_Fill_Rec(mask, mask_val,
				 x+i, y+j, z+k,
				 x_dim, y_dim, z_dim,
				 min_i, max_i,
				 min_j, max_j,
				 min_k, max_k
				 );
	  }
	}
      } /* end nested fors */
    }   /* end if mask */
  }     /* end bounds check */
}

/* }}} */

/* {{{ --- obsolete functions ---                                       */

/* }}} */
/* {{{ xcutxx_Compute_Mask_From_Vertices                                */

/* Compute a voxel mask from a radial surface.  Voxels in the mask
 * will be set to 1 if they are in the region of interest, else 0.
 *
 * This is the old version, that worked by checking distances between
 * voxels and vertices, rather than facets.
 */

void xcutxx_Compute_Mask_From_Vertices(
     LVAL     lv_mask,   /* storage for voxel mask */
     LVAL     lv_thing,  /* the surface for computing the mask */
     int      start,     /* start/end points in thing's point array */
     int      end,
     float    radius,    /* radius of inclusion */
     int      x_dim,     /* dimensions of voxel dataset */
     int      y_dim,
     int      z_dim
){
  CSRY_UNSIGNED16* mask;      /* the mask's actual voxel array */
  gt_tri_rec       r;         /* record for the thing */
  geo_point        p;         /* current vertex */
  geo_point        v;         /* current voxel */
  geo_point        min,max;   /* bounding box for thing */
  int              x,y,z;     /* voxel coords */
  int              i;         /* loop indices */
  float            sqr_radius = radius*radius;  /* squared radius */
  int              mask_val = 4095; /* value for masked voxels */
  int              out_of_bounds = 0;  /* count of voxels outside bbox */

  int        toProt = 2;
  xlstkcheck(toProt);
  xlprotect(lv_mask);
  xlprotect(lv_thing);

  /* parse the LVAL arguments */
  mask = (CSRY_UNSIGNED16*) csry_base(lv_mask);
  xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
  xthlB1_Process_Thing( &r, lv_thing );

  /* compute the bounding box for the surface */
  min.x = r.x[0];  min.y = r.y[0];  min.z = r.z[0];
  max.x = r.x[0];  max.y = r.y[0];  max.z = r.z[0];
  for (i = 1; i < r.pLen; i++) {
    if      (r.x[i] < min.x)  min.x = r.x[i];
    else if (r.x[i] > max.x)  max.x = r.x[i];
    if      (r.y[i] < min.y)  min.y = r.y[i];
    else if (r.y[i] > max.y)  max.y = r.y[i];
    if      (r.z[i] < min.z)  min.z = r.z[i];
    else if (r.z[i] > max.z)  max.z = r.z[i];
  }
  /* extend bounding box to include radius */
  min.x -= radius;  min.y -= radius;  min.z -= radius;
  max.x += radius;  max.y += radius;  max.z += radius;

  /* run through the voxels, checking distance to each vertex */
  for (z = 0;   z < z_dim;   z++) {
    printf("plane %d...\n", z);
    for (y = 0;   y < y_dim;   y++) {
      for (x = 0;   x < x_dim;   x++) {
	mask[ (z*y_dim + y)*x_dim + x ] = 0;  /* init each mask voxel */

	/* skip voxels outside the bounding box */
	if ((x < min.x) || (y < min.y) || (z < min.z) ||
	    (x > max.x) || (y > max.y) || (z > max.z)) {
	  out_of_bounds++;
	  continue;
	}
	    
	/* inside box, so start comparisons */
	for (i = start; i <= end; i++) {

	  p.x = r.x[i];  p.y = r.y[i];  p.z = r.z[i];
	  v.x = x;       v.y = y;       v.z = z;
	  
	  /* if a voxel is close to a vertex, mark it and move on */
	  if (XCUT_SQR_DIST_OLD(p,v) <= sqr_radius) {
	    printf("  marking (%d,%d,%d)\n", x, y, z);
	    mask[ (z*y_dim + y)*x_dim + x ] = mask_val; 
	    break;
	  }
	}
      }
    }
  }

  /* print stats */
  printf("min: (%f,%f,%f)\n", min.x, min.y, min.z);
  printf("max: (%f,%f,%f)\n", max.x, max.y, max.z);
  printf("Voxels outside bounding box: %d\n", out_of_bounds);
  printf("Total Voxels: %d\n", x_dim*y_dim*z_dim);

  xlpopn(toProt);
}

/* }}} */
/* {{{ xcutyy_Compute_Shell_OLD                                         */

/* Compute a voxel shell from a radial surface.  Voxels in the shell
 * will be set to 1 if they are in the region of interest, else 0.
 *
 * This version was retired because it was so SLOW!  It was running
 * through all voxels and looking for close facets, instead of vice versa.
 */

void xcutyy_Compute_Shell_OLD(
     LVAL     lv_mask,           /* storage for voxel shell */
     LVAL     lv_thing,          /* the surface for computing the shell */
     int      start,             /* start/end points in thing's point array */
     int      end,
     float    inner_radius,      /* radius of inclusion inside */
     float    outer_radius,      /* radius of inclusion outside */
     int      x_dim,             /* dimensions of voxel dataset */
     int      y_dim,
     int      z_dim,
     int      min_i, int max_i,  /* voxel range to consider */
     int      min_j, int max_j,
     int      min_k, int max_k
){
/*  CSRY_UNSIGNED16* mask;      /* the mask's actual voxel array */
  char            *mask;      /* the mask's actual voxel bit array */
  gt_tri_rec       r;         /* record for the thing */
  geo_point        p;         /* current vertex */
  geo_point        v;         /* current voxel */
  geo_point        min,max;   /* bounding box for thing */
  int              x,y,z;     /* voxel coords */
  int              i;         /* loop indices */
  int              v0,v1,v2;  /* indices into point array */
  int              mask_val = 1; /* value assigned to masked voxels */
  int              index;     /* index into the voxel array */
  float            *D;        /* D values for plane equations */
  double           d_plane;   /* distance from voxel to facet plane */
  double           d_tri;     /* distance from voxel to triangle */
  geo_point        e;         /* vector for a facet edge */
  xcut_plane       *e0, *e1, *e2; /* plane equations for facet edges */ 
  float            d0,d1,d2;  /* voxel-to-edge-plane distances */
  int              dim = x_dim * y_dim * z_dim;
  int              loc;       /* encoded location of voxel rel to facet */
  float            sqr_inner_radius = XCUT_SQR(inner_radius);
  float            sqr_outer_radius = XCUT_SQR(outer_radius);

  /* stats variables */
  int              out = 0;   /* count of voxels outside bbox */
  long             far = 0;   /* count of voxels too far from planes */
  long             close = 0; /* count of voxels close to planes */
  int              total_voxels; /* number of voxels */
  int    c000=0,c001=0,c010=0,c011=0;    /* case counts */
  int    c100=0,c101=0,c110=0,c111=0;
  int    zeroes=0;

  int        toProt = 2;
  xlstkcheck(toProt);
  xlprotect(lv_mask);
  xlprotect(lv_thing);

  /* parse the LVAL arguments */
/*  mask = (CSRY_UNSIGNED16*) csry_base(lv_mask); */
  mask = (char *) csry_base(lv_mask);
  xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
  xthlB1_Process_Thing( &r, lv_thing );

  /* error-checking */
  if (! r.got_facet_normals) 
    xlfail("XCUT-COMPUTE-SHELL: need facet normals");
  if (! r.got_triangles)
    xlfail("XCUT-COMPUTE-SHELL: only works with triangles (for now)");

  /* compute the bounding box for the surface */
  min.x = r.x[0];  min.y = r.y[0];  min.z = r.z[0];
  max.x = r.x[0];  max.y = r.y[0];  max.z = r.z[0];
  for (i = 1; i < r.pLen; i++) {
    if      (r.x[i] < min.x)  min.x = r.x[i];
    else if (r.x[i] > max.x)  max.x = r.x[i];
    if      (r.y[i] < min.y)  min.y = r.y[i];
    else if (r.y[i] > max.y)  max.y = r.y[i];
    if      (r.z[i] < min.z)  min.z = r.z[i];
    else if (r.z[i] > max.z)  max.z = r.z[i];
  }
  /* extend bounding box to include radius */
  min.x -= outer_radius;  min.y -= outer_radius;  min.z -= outer_radius;
  max.x += outer_radius;  max.y += outer_radius;  max.z += outer_radius;

  /* allocate extra arrays we need for plane equation info */
  if ((D = (float*) calloc(sizeof(float), r.fLen)) == NULL) {
    xlfail("XCUT-COMPUTE-SHELL: can't allocate space"); }
  if ((e0 = (xcut_plane*) calloc(sizeof(xcut_plane), r.fLen)) == NULL) {
    xlfail("XCUT-COMPUTE-SHELL: can't allocate space"); }
  if ((e1 = (xcut_plane*) calloc(sizeof(xcut_plane), r.fLen)) == NULL) {
    xlfail("XCUT-COMPUTE-SHELL: can't allocate space"); }
  if ((e2 = (xcut_plane*) calloc(sizeof(xcut_plane), r.fLen)) == NULL) {
    xlfail("XCUT-COMPUTE-SHELL: can't allocate space"); }

  printf("computing edge plane equations...\n");

  /* for each facet... */
  for (i = r.fLen; i-->0; ) {
    /* grab vertex indices */
    v0 = r.f0[i];  v1 = r.f1[i];  v2 = r.f2[i];

    /* compute the D values for each triangle's plane equation */
    /* P in plane = (Px, Py, Pz),  D = - (A*Px + B*Py + C*Pz)  */
    D[i] = -(r.fnx[i]*r.x[v0] + r.fny[i]*r.y[v0] + r.fnz[i]*r.z[v0]);

    /* Compute equations for the planes through facet's edges, */
    /* perpendicular to the facet's plane.                     */
    /* (These are NOT normalized at the moment.)               */

    /* compute vector for v0->v1 */
    e.x = r.x[v1] - r.x[v0];
    e.y = r.y[v1] - r.y[v0];
    e.z = r.z[v1] - r.z[v0];
    /* compute cross-product of vector with plane's normal */
    /* (from p. 1104 of Foley & VanDam, v = e and w = fn)  */
    e0[i].a = e.y * r.fnz[i] - e.z * r.fny[i];
    e0[i].b = e.z * r.fnx[i] - e.x * r.fnz[i];
    e0[i].c = e.x * r.fny[i] - e.y * r.fnx[i];
    e0[i].d = -(e0[i].a*r.x[v0] + e0[i].b*r.y[v0] + e0[i].c*r.z[v0]);

    /* check values */
/*
    printf("v0->v1:       (%f,%f,%f)\n", e.x, e.y, e.z);
    printf("facet plane:  (%f,%f,%f), D = %f\n", 
	   r.fnx[i], r.fny[i], r.fnz[i], D[i]);
    printf("edge plane:   (%f,%f,%f), D = %f\n", 
	   e0[i].a, e0[i].b, e0[i].c, e0[i].d);
    printf("edge dot facet: %f\n",
	   e.x*r.fnx[i] + e.y*r.fny[i] + e.z*r.fnz[i]);
    printf("facet dot plane: %f\n",
	   e0[i].a*r.fnx[i] + e0[i].b*r.fny[i] + e0[i].c*r.fnz[i]);
    printf("edge dot plane: %f\n", 
	   e.x*e0[i].a + e.y*e0[i].b + e.z*e0[i].c);
    printf("\n");
*/
    /* v1->v2 */
    e.x = r.x[v2] - r.x[v1];
    e.y = r.y[v2] - r.y[v1];
    e.z = r.z[v2] - r.z[v1];
    e1[i].a = e.y * r.fnz[i] - e.z * r.fny[i];
    e1[i].b = e.z * r.fnx[i] - e.x * r.fnz[i];
    e1[i].c = e.x * r.fny[i] - e.y * r.fnx[i];
    e1[i].d = -(e1[i].a*r.x[v1] + e1[i].b*r.y[v1] + e1[i].c*r.z[v1]);

    /* v2->v0 */
    e.x = r.x[v0] - r.x[v2];
    e.y = r.y[v0] - r.y[v2];
    e.z = r.z[v0] - r.z[v2];
    e2[i].a = e.y * r.fnz[i] - e.z * r.fny[i];
    e2[i].b = e.z * r.fnx[i] - e.x * r.fnz[i];
    e2[i].c = e.x * r.fny[i] - e.y * r.fnx[i];
    e2[i].d = -(e2[i].a*r.x[v2] + e2[i].b*r.y[v2] + e2[i].c*r.z[v2]);    

  } /* end for each facet */

  /* clear out the entire mask bit array */
  memset( (void *)mask, 0, ((dim +7) >> 3) );

  /* run through the voxels, checking distance to each vertex */
  for (z = min_k;   z < max_k;   z++) {
    printf("plane %d...\n", z);
    for (y = min_j;   y < max_j;   y++) {
      for (x = min_i;   x < max_i;   x++) {
	index = (z*y_dim + y)*x_dim + x;

	/* skip voxels outside the bounding box */
	if ((x < min.x) || (y < min.y) || (z < min.z) ||
	    (x > max.x) || (y > max.y) || (z > max.z)) {
	  out++;   /* just needed for stats */
	  continue;
	}

	for (i = r.fLen; i-->0; ) {

	  /* should I normalize to be safe? */
	  d_plane = x*r.fnx[i] + y*r.fny[i] + z*r.fnz[i] + D[i];

	  if (( d_plane <= inner_radius) &&  /* + is inside, - is out */
	      ( -outer_radius <= d_plane)) {
	    close++;

	    /* perform half-plane tests to see where point is */
	    d0 = e0[i].a*x + e0[i].b*y + e0[i].c*z + e0[i].d;
	    d1 = e1[i].a*x + e1[i].b*y + e1[i].c*z + e1[i].d;
	    d2 = e2[i].a*x + e2[i].b*y + e2[i].c*z + e2[i].d;
	    loc = ((d2 > 0) << 2) + ((d1 > 0) << 1) + (d0 > 0);
	    switch (loc) {
	    case 0:  /* --- (inside triangle) */
	      XCUT_SET_BIT(mask, index, mask_val);  
	      break;
	    case 1:  /* --+ (edge 01)  */
	      break;
	    case 2:  /* -+- (edge 12)  */
	      break;
	    case 3:  /* -++ (vertex 1) */
	      v1 = r.f1[i];
	      d_tri = XCUT_SQR_DIST(r.x[v1], r.y[v1], r.z[v1], x, y, z);
	      if (((d_plane >= 0) ? (d_tri <= sqr_inner_radius)
		                  : (d_tri <= sqr_outer_radius))) {
		XCUT_SET_BIT(mask, index, mask_val); }
	      break;

	    case 4:  /* +-- (edge 20)  */
	      break;
	    case 5:  /* +-+ (vertex 0) */
	      v0 = r.f0[i];
	      d_tri = XCUT_SQR_DIST(r.x[v0], r.y[v0], r.z[v0], x, y, z);
	      if (((d_plane >= 0) ? (d_tri <= sqr_inner_radius)
		                  : (d_tri <= sqr_outer_radius))) {
		XCUT_SET_BIT(mask, index, mask_val); }
	      break;

	    case 6:  /* ++- (vertex 2) */
	      v2 = r.f2[i];
	      d_tri = XCUT_SQR_DIST(r.x[v2], r.y[v2], r.z[v2], x, y, z);
	      if (((d_plane >= 0) ? (d_tri <= sqr_inner_radius)
		                  : (d_tri <= sqr_outer_radius))) {
		XCUT_SET_BIT(mask, index, mask_val); }
	      break;

	    default: /* shouldn't happen */
	      printf("ALL-POSITIVE CASE: WHAT HAPPENED???\n");
	    }
	  } else {
	    far++;
	  }
	}
      }
    }
  }

  /* print stats */
  total_voxels = ((max_k - min_k + 1) * 
		  (max_j - min_j + 1) * 
		  (max_i - min_i + 1));
  printf("min: (%f,%f,%f)\n", min.x, min.y, min.z);
  printf("max: (%f,%f,%f)\n", max.x, max.y, max.z);
  printf("\n");
  printf("Voxels outside bounding box:  %9d\n", out);
  printf("Voxels inside bounding box:   %9d\n", total_voxels - out);
  printf("----------------------------------------\n");
  printf("Total Voxels:                 %9d\n", total_voxels);
  printf("\n");
  printf("Voxel/facet pairs ruled out:  %11ld\n", far);
  printf("Voxel/facet pairs to check:   %11ld\n", close);

/*
  printf("All zeroes:                   %11d\n", zeroes);
  printf("Case 000:                     %11d\n", c000);
  printf("Case 001:                     %11d\n", c001);
  printf("Case 010:                     %11d\n", c010);
  printf("Case 011:                     %11d\n", c011);
  printf("Case 100:                     %11d\n", c100);
  printf("Case 101:                     %11d\n", c101);
  printf("Case 110:                     %11d\n", c110);
  printf("Case 111:                     %11d\n", c111);
*/
  printf("-------------------------------------------\n");
  printf("Total Voxel/facet pairs:      %11ld\n", close+far);
  printf("\n");

  /* free up temp space we allocated here */
  free(D);
  free(e0);
  free(e1);
  free(e2);

  xlpopn(toProt);
}

/* }}} */
/* {{{ xcut09_Boundary_Fill_OLD                                         */

/* Core function for doing a boundary-based flood fill.  If voxel
 * (x,y,z) is inside bounds and not part of the boundary, fill it and
 * check its neighbors.  (This version uses a queue of voxels to
 * search instead of recursive calls to itself.) 
 *
 * In the queue, head should always point to the first element, and
 * tail should point to the element *after* the last element (i.e. 
 * the next slot to fill).  An empty queue is signaled when head and
 * tail are equal.
 */

void xcut09_Boundary_Fill_OLD(
     char *mask,                 /* voxel array */
     int  mask_val,              /* boundary value */
     int  seed_x,                /* current voxel */
     int  seed_y, 
     int  seed_z,               
     int  x_dim,                 /* voxel array bounds */
     int  y_dim, 
     int  z_dim,   
     int  min_i, int max_i,      /* range being considered */
     int  min_j, int max_j,
     int  min_k, int max_k
){
  vec3c  *Q;                  /* the queue of voxels to check */
  int    base_Qsize = 1<<20;  /* initial size of voxel queue */
  int    Qsize = base_Qsize;  /* current size of the voxel queue */
  int    head;                /* head of queue */
  int    tail;                /* tail of queue */
  int    count;               /* number of elements in queue */
  int    index;               /* index into voxel array */
/*  int    x,y,z;             /* current voxel coords */
/*  int    i,j,k;             /* coord offsets */
  unsigned char    x,y,z;            /* current voxel coords */
  int    num_neighbors=6;  /* number of voxel's neighbors */

  printf("*** Old version of boundary fill! ***\n");

  /* make sure voxel coords can be stored in 3 bytes */
  if ((x_dim > 256) || (y_dim > 256) | (z_dim > 256)) {
    xlfail("XCUT-BOUNDARY-FILL: need larger queue entries!"); }

  /* allocate initial queue */
  if ((Q = (vec3c*) calloc(Qsize, sizeof(vec3c))) == NULL) {
    xlfail("XCUT-BOUNDARY-FILL: can't allocate space for voxel queue"); }

  /* initialize with starting point */
  Q[0].x = seed_x;
  Q[0].y = seed_y;
  Q[0].z = seed_z;
  head = 0;
  tail = 1;
  count = 1;

  while (head != tail) {

    /* remove next element from queue */
    x = Q[head].x;
    y = Q[head].y;
    z = Q[head].z;
    head = (head + 1) % Qsize;

    /* skip voxels outside the bounding box */
    if ((x >= min_i) && (y >= min_j) && (z >= min_k) &&
	(x <= max_i) && (y <= max_j) && (z <= max_k)) {

      /* if voxel isn't filled, fill it and check neighbors */
      index = (z*y_dim + y)*x_dim + x;
      if (XCUT_GET_BIT(mask, index) != mask_val) {
/*	printf("  filling (%d,%d,%d)\n", x, y, z);  */
	XCUT_SET_BIT(mask, index, mask_val);

	/* expand queue if needed */
	while ((count + num_neighbors) >= (Qsize - 1)) {
	  Qsize += base_Qsize;
	  printf("Allocating more space (%d entries)...\n", Qsize);
	  Q = (vec3c *) realloc(Q, Qsize * sizeof(vec3c));
	  if (Q == NULL) {
	    xlfail("XCUT-BOUNDARY-FILL: can't reallocate space for queue");
	  }
	}

	/* add 6 neighbors to queue */
	Q[tail].x = x-1; Q[tail].y = y;   Q[tail].z = z;
	tail = (tail + 1) % Qsize;
	Q[tail].x = x+1; Q[tail].y = y;   Q[tail].z = z;
	tail = (tail + 1) % Qsize;
	Q[tail].x = x;   Q[tail].y = y-1; Q[tail].z = z;
	tail = (tail + 1) % Qsize;
	Q[tail].x = x;   Q[tail].y = y+1; Q[tail].z = z;
	tail = (tail + 1) % Qsize;
	Q[tail].x = x;   Q[tail].y = y;   Q[tail].z = z-1;
	tail = (tail + 1) % Qsize;
	Q[tail].x = x;   Q[tail].y = y;   Q[tail].z = z+1;
	tail = (tail + 1) % Qsize;
	count += 6;

      }   /* end if mask */
    }     /* end bounds check */
  }       /* end while head != tail */

  /* for feedback on queue size, print final queue size */
  printf("****************************************\n");
  printf("FINAL QUEUE SIZE: %d entries\n", Qsize);
  printf("****************************************\n");

  free(Q);
}

/* }}} */

/* {{{ File variables							*/

/*

Local variables:
case-fold-search: t
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
