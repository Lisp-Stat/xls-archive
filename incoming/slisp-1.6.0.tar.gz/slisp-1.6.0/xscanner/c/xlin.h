/* {{{ xlin.h -- Histogram equalization on 8-bit images.	     CrT*/

/*************************************************************************
*
* Author:       Kevin Hinshaw
* Created:      94Sep17
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
#ifdef EXAMPLE
extern LVAL xlin05_Extract_Line_Msg();
#endif
extern LVAL xlin15_Extract_Line_Fn();
extern LVAL xlin16_Compute_Gradient_Fn();

#ifndef EXTERNED_XSTART
extern LVAL k_xstart;   /* Keyword ":X-START" */
#define EXTERNED_XSTART
#endif

#ifndef EXTERNED_YSTART
extern LVAL k_ystart;   /* Keyword ":Y-START" */
#define EXTERNED_YSTART
#endif

#ifndef EXTERNED_ZSTART
extern LVAL k_zstart;   /* Keyword ":Z-START" */
#define EXTERNED_ZSTART
#endif

#ifndef EXTERNED_XEND
extern LVAL k_xend;   /* Keyword ":X-END" */
#define EXTERNED_XEND
#endif

#ifndef EXTERNED_YEND
extern LVAL k_yend;   /* Keyword ":Y-END" */
#define EXTERNED_YEND
#endif

#ifndef EXTERNED_ZEND
extern LVAL k_zend;   /* Keyword ":Z-END" */
#define EXTERNED_ZEND
#endif

#ifndef EXTERNED_POINTX
extern LVAL k_pointx;   /* Keyword ":POINT-X" */
#define EXTERNED_POINTX
#endif

#ifndef EXTERNED_POINTY
extern LVAL k_pointy;   /* Keyword ":POINT-Y" */
#define EXTERNED_POINTY
#endif

#ifndef EXTERNED_POINTZ
extern LVAL k_pointz;   /* Keyword ":POINT-Z" */
#define EXTERNED_POINTZ
#endif

#ifndef EXTERNED_XMIN
extern LVAL k_xmin;   /* Keyword ":X-MIN" */
#define EXTERNED_XMIN
#endif

#ifndef EXTERNED_YMIN
extern LVAL k_ymin;   /* Keyword ":Y-MIN" */
#define EXTERNED_YMIN
#endif

#ifndef EXTERNED_ZMIN
extern LVAL k_zmin;   /* Keyword ":Z-MIN" */
#define EXTERNED_ZMIN
#endif

#ifndef EXTERNED_XMAX
extern LVAL k_xmax;   /* Keyword ":X-MAX" */
#define EXTERNED_XMAX
#endif

#ifndef EXTERNED_YMAX
extern LVAL k_ymax;   /* Keyword ":Y-MAX" */
#define EXTERNED_YMAX
#endif

#ifndef EXTERNED_ZMAX
extern LVAL k_zmax;   /* Keyword ":Z-MAX" */
#define EXTERNED_ZMAX
#endif

#ifndef EXTERNED_IMAGE
extern LVAL k_image;   /* Keyword ":IMAGE" */
#define EXTERNED_IMAGE
#endif

#ifndef EXTERNED_VOLUME
extern LVAL k_volume;   /* Keyword ":VOLUME" */
#define EXTERNED_VOLUME
#endif

#ifndef EXTERNED_INTENSITY
extern LVAL k_intensity;   /* Keyword ":INTENSITY" */
#define EXTERNED_INTENSITY
#endif

#ifndef EXTERNED_ORIGINAL_INTENSITY
extern LVAL k_original_intensity;   /* Keyword ":ORIGINAL_INTENSITY" */
#define EXTERNED_ORIGINAL_INTENSITY
#endif

#ifndef EXTERNED_VOXELS
extern LVAL k_voxels;   /* Keyword ":VOXELS" */
#define EXTERNED_VOXELS
#endif

#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
#ifdef EXAMPLE
DEFINE_SUBR(	NULL,		    xlin05_Extract_Line_Msg		)
#endif
DEFINE_SUBR(	"XLIN-EXTRACT-LINE", xlin15_Extract_Line_Fn	)
DEFINE_SUBR(    "XLIN-COMPUTE-GRADIENT", xlin16_Compute_Gradient_Fn )
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS


#ifndef DEFINED_XSTART
LVAL k_xstart;   /* Keyword ":X-START" */
#define DEFINED_XSTART
#endif

#ifndef DEFINED_YSTART
LVAL k_ystart;   /* Keyword ":Y-START" */
#define DEFINED_YSTART
#endif

#ifndef DEFINED_ZSTART
LVAL k_zstart;   /* Keyword ":Z-START" */
#define DEFINED_ZSTART
#endif

#ifndef DEFINED_XEND
LVAL k_xend;     /* Keyword ":X-END" */
#define DEFINED_XEND
#endif

#ifndef DEFINED_YEND
LVAL k_yend;     /* Keyword ":Y-END" */
#define DEFINED_YEND
#endif

#ifndef DEFINED_ZEND
LVAL k_zend;     /* Keyword ":Z-END" */
#define DEFINED_ZEND
#endif

#ifndef DEFINED_POINTX
LVAL k_pointx;   /* Keyword ":POINT-X" */
#define DEFINED_POINTX
#endif

#ifndef DEFINED_POINTY
LVAL k_pointy;   /* Keyword ":POINT-Y" */
#define DEFINED_POINTY
#endif

#ifndef DEFINED_POINTZ
LVAL k_pointz;   /* Keyword ":POINT-Z" */
#define DEFINED_POINTZ
#endif

#ifndef DEFINED_XMIN
LVAL k_xmin;     /* Keyword ":X-MIN" */
#define DEFINED_XMIN
#endif

#ifndef DEFINED_YMIN
LVAL k_ymin;     /* Keyword ":Y-MIN" */
#define DEFINED_YMIN
#endif

#ifndef DEFINED_ZMIN
LVAL k_zmin;     /* Keyword ":Z-MIN" */
#define DEFINED_ZMIN
#endif

#ifndef DEFINED_XMAX
LVAL k_xmax;     /* Keyword ":X-MAX" */
#define DEFINED_XMAX
#endif

#ifndef DEFINED_YMAX
LVAL k_ymax;     /* Keyword ":Y-MAX" */
#define DEFINED_YMAX
#endif

#ifndef DEFINED_ZMAX
LVAL k_zmax;     /* Keyword ":Z-MAX" */
#define DEFINED_ZMAX
#endif

#ifndef DEFINED_IMAGE
LVAL k_image;     /* Keyword ":IMAGE" */
#define DEFINED_IMAGE
#endif

#ifndef DEFINED_VOLUME
LVAL k_volume;     /* Keyword ":VOLUME" */
#define DEFINED_VOLUME
#endif

#ifndef DEFINED_INTENSITY
LVAL k_intensity;     /* Keyword ":INTENSITY" */
#define DEFINED_INTENSITY
#endif

#ifndef DEFINED_ORIGINAL_INTENSITY
LVAL k_original_intensity;     /* Keyword ":ORIGINAL_INTENSITY" */
#define DEFINED_ORIGINAL_INTENSITY
#endif

#ifndef DEFINED_VOXELS
LVAL k_voxels;     /* Keyword ":VOXELS" */
#define DEFINED_VOXELS
#endif

#ifdef EXAMPLE
LOCAL struct xlin_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xlin_xf8v_table[] = {
    {	":EXTRACT_LINE",	xlin05_Extract_Line_Msg  	},

    {	NULL,			NULL	                	}
};
#endif
#endif

#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_XSTART
    k_xstart = xlenter(":X-START");
#define CREATED_XSTART
#endif

#ifndef CREATED_YSTART
    k_ystart = xlenter(":Y-START");
#define CREATED_YSTART
#endif

#ifndef CREATED_ZSTART
    k_zstart = xlenter(":Z-START");
#define CREATED_ZSTART
#endif

#ifndef CREATED_XEND
    k_xend   = xlenter(":X-END");
#define CREATED_XEND
#endif

#ifndef CREATED_YEND
    k_yend   = xlenter(":Y-END");
#define CREATED_YEND
#endif

#ifndef CREATED_ZEND
    k_zend   = xlenter(":Z-END");
#define CREATED_ZEND
#endif

#ifndef CREATED_POINTX
    k_pointx = xlenter(":POINT-X");
#define CREATED_POINTX
#endif

#ifndef CREATED_POINTY
    k_pointy = xlenter(":POINT-Y");
#define CREATED_POINTY
#endif

#ifndef CREATED_POINTZ
    k_pointz = xlenter(":POINT-Z");
#define CREATED_POINTZ
#endif

#ifndef CREATED_XMIN
    k_xmin   = xlenter(":X-MIN");
#define CREATED_XMIN
#endif

#ifndef CREATED_YMIN
    k_ymin   = xlenter(":Y-MIN");
#define CREATED_YMIN
#endif

#ifndef CREATED_ZMIN
    k_zmin   = xlenter(":Z-MIN");
#define CREATED_ZMIN
#endif

#ifndef CREATED_XMAX
    k_xmax   = xlenter(":X-MAX");
#define CREATED_XMAX
#endif

#ifndef CREATED_YMAX
    k_ymax   = xlenter(":Y-MAX");
#define CREATED_YMAX
#endif

#ifndef CREATED_ZMAX
    k_zmax   = xlenter(":Z-MAX");
#define CREATED_ZMAX
#endif

#ifndef CREATED_IMAGE
    k_image   = xlenter(":IMAGE");
#define CREATED_IMAGE
#endif

#ifndef CREATED_VOLUME
    k_volume   = xlenter(":VOLUME");
#define CREATED_VOLUME
#endif

#ifndef CREATED_INTENSITY
    k_intensity   = xlenter(":INTENSITY");
#define CREATED_INTENSITY
#endif

#ifndef CREATED_ORIGINAL_INTENSITY
    k_original_intensity   = xlenter(":ORIGINAL_INTENSITY");
#define CREATED_ORIGINAL_INTENSITY
#endif

#ifndef CREATED_VOXELS
    k_voxels   = xlenter(":VOXELS");
#define CREATED_VOXELS
#endif

#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
#ifdef EXAMPLE
    xgbj56_Enter_Messages( lv_xf8v,  xlin_xf8v_table );
#endif
#endif


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
