/* {{{ xiso.h -- isosurface code.                                      CrT*/

/*************************************************************************
*
* Author:       Kevin Hinshaw
* Created:      96Aug21
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
#ifdef EXAMPLE
extern LVAL xlin05_Extract_Line_Msg();
#endif
extern LVAL Compute_Thresholds_Fn();
extern LVAL Compute_Isosurface_Fn();

#ifndef EXTERNED_SEEDS
extern LVAL k_seeds;   /* Keyword ":SEEDS" */
#define EXTERNED_SEEDS
#endif

#ifndef EXTERNED_THRESHOLD
extern LVAL k_threshold;   /* Keyword ":THRESHOLD" */
#define EXTERNED_THRESHOLD
#endif

#ifndef EXTERNED_INTENSITY
extern LVAL k_intensity;   /* Keyword ":INTENSITY" */
#define EXTERNED_INTENSITY
#endif

#ifndef EXTERNED_ORIGINAL_INTENSITY
extern LVAL k_original_intensity;   /* Keyword ":ORIGINAL_INTENSITY" */
#define EXTERNED_ORIGINAL_INTENSITY
#endif

#ifndef EXTERNED_VOXELS
extern LVAL k_voxels;   /* Keyword ":VOXELS" */
#define EXTERNED_VOXELS
#endif

#ifndef EXTERNED_POINTX
extern LVAL k_pointx;   /* Keyword ":POINT-X" */
#define EXTERNED_POINTX
#endif

#ifndef EXTERNED_POINTY
extern LVAL k_pointy;   /* Keyword ":POINT-Y" */
#define EXTERNED_POINTY
#endif

#ifndef EXTERNED_POINTZ
extern LVAL k_pointz;   /* Keyword ":POINT-Z" */
#define EXTERNED_POINTZ
#endif

#ifndef EXTERNED_POINT_NORMALX
extern LVAL k_point_normalx;   /* Keyword ":POINT-NORMAL-X" */
#define EXTERNED_POINT_NORMALX
#endif

#ifndef EXTERNED_POINT_NORMALY
extern LVAL k_point_normaly;   /* Keyword ":POINT-NORMAL-Y" */
#define EXTERNED_POINT_NORMALY
#endif

#ifndef EXTERNED_POINT_NORMALZ
extern LVAL k_point_normalz;   /* Keyword ":POINT-NORMAL-Z" */
#define EXTERNED_POINT_NORMALZ
#endif

#ifndef EXTERNED_FACET0
extern LVAL k_facet0;   /* Keyword ":FACET-0" */
#define EXTERNED_FACET0
#endif

#ifndef EXTERNED_FACET1
extern LVAL k_facet1;   /* Keyword ":FACET-1" */
#define EXTERNED_FACET1
#endif

#ifndef EXTERNED_FACET2
extern LVAL k_facet2;   /* Keyword ":FACET-2" */
#define EXTERNED_FACET2
#endif

#ifndef EXTERNED_SETF_FILL_POINTER
extern LVAL k_setf_fill_pointer;   /* Keyword ":SETF-FILL-POINTER" */
#define EXTERNED_SETF_FILL_POINTER
#endif

#ifndef EXTERNED_POINT_RELATION
extern LVAL k_point_relation;   /* Keyword ":POINT-RELATION" */
#define EXTERNED_POINT_RELATION
#endif

#ifndef EXTERNED_FACET_RELATION
extern LVAL k_facet_relation;   /* Keyword ":FACET-RELATION" */
#define EXTERNED_FACET_RELATION
#endif

#ifndef EXTERNED_INTERPOLATE
extern LVAL k_interpolate;   /* Keyword ":INTERPOLATE" */
#define EXTERNED_INTERPOLATE
#endif

#ifndef EXTERNED_REUSE_IF_AVAILABLE
extern LVAL k_reuse_if_available;   /* Keyword ":REUSE-IF-AVAILABLE" */
#define EXTERNED_REUSE_IF_AVAILABLE
#endif

#ifndef EXTERNED_RESOLUTION
extern LVAL k_resolution;   /* Keyword ":RESOLUTION" */
#define EXTERNED_RESOLUTION
#endif

#ifndef EXTERNED_USE_TETRAHEDRONS
extern LVAL k_use_tetrahedrons;   /* Keyword ":USE-TETRAHEDRONS" */
#define EXTERNED_USE_TETRAHEDRONS
#endif

#ifndef EXTERNED_ARRAY_DIMENSIONS
extern LVAL k_array_dimensions;   /* Keyword ":ARRAY-DIMENSIONS" */
#define EXTERNED_ARRAY_DIMENSIONS
#endif

#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
#ifdef EXAMPLE
DEFINE_SUBR(	NULL,		    xlin05_Extract_Line_Msg		)
#endif
DEFINE_SUBR(	"XISO-COMPUTE-THRESHOLDS", Compute_Thresholds_Fn	)
DEFINE_SUBR(	"XISO-COMPUTE-ISOSURFACE", Compute_Isosurface_Fn	)
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS


#ifndef DEFINED_SEEDS
LVAL k_seeds;     /* Keyword ":SEEDS" */
#define DEFINED_SEEDS
#endif

#ifndef DEFINED_THRESHOLD
LVAL k_threshold;     /* Keyword ":THRESHOLD" */
#define DEFINED_THRESHOLD
#endif

#ifndef DEFINED_INTENSITY
LVAL k_intensity;     /* Keyword ":INTENSITY" */
#define DEFINED_INTENSITY
#endif

#ifndef DEFINED_ORIGINAL_INTENSITY
LVAL k_original_intensity;     /* Keyword ":ORIGINAL_INTENSITY" */
#define DEFINED_ORIGINAL_INTENSITY
#endif

#ifndef DEFINED_VOXELS
LVAL k_voxels;     /* Keyword ":VOXELS" */
#define DEFINED_VOXELS
#endif

#ifndef DEFINED_POINTX
LVAL k_pointx;   /* Keyword ":POINT-X" */
#define DEFINED_POINTX
#endif

#ifndef DEFINED_POINTY
LVAL k_pointy;   /* Keyword ":POINT-Y" */
#define DEFINED_POINTY
#endif

#ifndef DEFINED_POINTZ
LVAL k_pointz;   /* Keyword ":POINT-Z" */
#define DEFINED_POINTZ
#endif

#ifndef DEFINED_POINT_NORMALX
LVAL k_point_normalx;   /* Keyword ":POINT-NORMAL-X" */
#define DEFINED_POINT_NORMALX
#endif

#ifndef DEFINED_POINT_NORMALY
LVAL k_point_normaly;   /* Keyword ":POINT-NORMAL-Y" */
#define DEFINED_POINT_NORMALY
#endif

#ifndef DEFINED_POINT_NORMALZ
LVAL k_point_normalz;   /* Keyword ":POINT-NORMAL-Z" */
#define DEFINED_POINT_NORMALZ
#endif

#ifndef DEFINED_FACET0
LVAL k_facet0;   /* Keyword ":FACET-0" */
#define DEFINED_FACET0
#endif

#ifndef DEFINED_FACET1
LVAL k_facet1;   /* Keyword ":FACET-1" */
#define DEFINED_FACET1
#endif

#ifndef DEFINED_FACET2
LVAL k_facet2;   /* Keyword ":FACET-2" */
#define DEFINED_FACET2
#endif

#ifndef DEFINED_SETF_FILL_POINTER
LVAL k_setf_fill_pointer;   /* Keyword ":SETF-FILL-POINTER" */
#define DEFINED_SETF_FILL_POINTER
#endif

#ifndef DEFINED_POINT_RELATION
LVAL k_point_relation;   /* Keyword ":POINT-RELATION" */
#define DEFINED_POINT_RELATION
#endif

#ifndef DEFINED_FACET_RELATION
LVAL k_facet_relation;   /* Keyword ":FACET-RELATION" */
#define DEFINED_FACET_RELATION
#endif

#ifndef DEFINED_INTERPOLATE
LVAL k_interpolate;   /* Keyword ":INTERPOLATE" */
#define DEFINED_INTERPOLATE
#endif

#ifndef DEFINED_REUSE_IF_AVAILABLE
LVAL k_reuse_if_available;   /* Keyword ":REUSE-IF-AVAILABLE" */
#define DEFINED_REUSE_IF_AVAILABLE
#endif

#ifndef DEFINED_RESOLUTION
LVAL k_resolution;   /* Keyword ":RESOLUTION" */
#define DEFINED_RESOLUTION
#endif

#ifndef DEFINED_USE_TETRAHEDRONS
LVAL k_use_tetrahedrons;   /* Keyword ":USE-TETRAHEDRONS" */
#define DEFINED_USE_TETRAHEDRONS
#endif

#ifndef DEFINED_ARRAY_DIMENSIONS
LVAL k_array_dimensions;   /* Keyword ":ARRAY-DIMENSIONS" */
#define DEFINED_ARRAY_DIMENSIONS
#endif

#ifdef EXAMPLE
LOCAL struct xlin_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xlin_xf8v_table[] = {
    {	":EXTRACT_LINE",	xlin05_Extract_Line_Msg  	},

    {	NULL,			NULL	                	}
};
#endif
#endif

#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_SEEDS
    k_seeds   = xlenter(":SEEDS");
#define CREATED_SEEDS
#endif

#ifndef CREATED_THRESHOLD
    k_threshold   = xlenter(":THRESHOLD");
#define CREATED_THRESHOLD
#endif

#ifndef CREATED_INTENSITY
    k_intensity   = xlenter(":INTENSITY");
#define CREATED_INTENSITY
#endif

#ifndef CREATED_ORIGINAL_INTENSITY
    k_original_intensity   = xlenter(":ORIGINAL_INTENSITY");
#define CREATED_ORIGINAL_INTENSITY
#endif

#ifndef CREATED_VOXELS
    k_voxels   = xlenter(":VOXELS");
#define CREATED_VOXELS
#endif

#ifndef CREATED_POINTX
    k_pointx = xlenter(":POINT-X");
#define CREATED_POINTX
#endif

#ifndef CREATED_POINTY
    k_pointy = xlenter(":POINT-Y");
#define CREATED_POINTY
#endif

#ifndef CREATED_POINTZ
    k_pointz = xlenter(":POINT-Z");
#define CREATED_POINTZ
#endif

#ifndef CREATED_POINT_NORMALX
    k_point_normalx = xlenter(":POINT-NORMAL-X");
#define CREATED_POINT_NORMALX
#endif

#ifndef CREATED_POINT_NORMALY
    k_point_normaly = xlenter(":POINT-NORMAL-Y");
#define CREATED_POINT_NORMALY
#endif

#ifndef CREATED_POINT_NORMALZ
    k_point_normalz = xlenter(":POINT-NORMAL-Z");
#define CREATED_POINT_NORMALZ
#endif

#ifndef CREATED_FACET0
    k_facet0 = xlenter(":FACET-0");
#define CREATED_FACET0
#endif

#ifndef CREATED_FACET1
    k_facet1 = xlenter(":FACET-1");
#define CREATED_FACET1
#endif

#ifndef CREATED_FACET2
    k_facet2 = xlenter(":FACET-2");
#define CREATED_FACET2
#endif

#ifndef CREATED_SETF_FILL_POINTER
    k_setf_fill_pointer = xlenter(":SETF-FILL-POINTER");
#define CREATED_SETF_FILL_POINTER
#endif

#ifndef CREATED_POINT_RELATION
    k_point_relation = xlenter(":POINT-RELATION");
#define CREATED_POINT_RELATION
#endif

#ifndef CREATED_FACET_RELATION
    k_facet_relation = xlenter(":FACET-RELATION");
#define CREATED_FACET_RELATION
#endif

#ifndef CREATED_INTERPOLATE
    k_interpolate = xlenter(":INTERPOLATE");
#define CREATED_INTERPOLATE
#endif

#ifndef CREATED_REUSE_IF_AVAILABLE
    k_reuse_if_available = xlenter(":REUSE-IF-AVAILABLE");
#define CREATED_REUSE_IF_AVAILABLE
#endif

#ifndef CREATED_RESOLUTION
    k_resolution = xlenter(":RESOLUTION");
#define CREATED_RESOLUTION
#endif

#ifndef CREATED_USE_TETRAHEDRONS
    k_use_tetrahedrons = xlenter(":USE-TETRAHEDRONS");
#define CREATED_USE_TETRAHEDRONS
#endif

#ifndef CREATED_ARRAY_DIMENSIONS
    k_array_dimensions = xlenter(":ARRAY-DIMENSIONS");
#define CREATED_ARRAY_DIMENSIONS
#endif

#endif


#ifdef MODULE_XLOBJ_C_XLOINIT
#ifdef EXAMPLE
    xgbj56_Enter_Messages( lv_xf8v,  xlin_xf8v_table );
#endif
#endif


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
