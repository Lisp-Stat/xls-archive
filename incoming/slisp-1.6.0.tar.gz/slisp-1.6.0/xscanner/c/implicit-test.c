/*
 * C code from the article
 * "An Implicit Surface Polygonizer"
 * by Jules Bloomenthal, jbloom@beauty.gmu.edu
 * in "Graphics Gems IV", Academic Press, 1994
 */

/* implicit-test.c
 *
 * 96Oct20  kph
 * This is the code that demos the implicit surface routines.  I moved
 * them to a separate file to avoid having multiple main functions.
 */

/**** A Test Program ****/

#include "implicit.h"

/* torus: a torus with major, minor radii = 0.5, 0.1, try size = .05 */

double torus (x, y, z, dataset)
double x, y, z;
CSRY_UNSIGNED16 *dataset;
{
    double x2 = x*x, y2 = y*y, z2 = z*z;
    double a = x2+y2+z2+(0.5*0.5)-(0.1*0.1);
    return a*a-4.0*(0.5*0.5)*(y2+z2);
}


/* sphere: an inverse square function (always positive) */

double sphere (x, y, z, dataset)
double x, y, z;
CSRY_UNSIGNED16 *dataset;
{
    double rsq = x*x+y*y+z*z;
    return 1.0/(rsq < 0.00001? 0.00001 : rsq);
}


/* blob: a three-pole blend function, try size = .1 */

double blob (x, y, z, dataset)
double x, y, z;
CSRY_UNSIGNED16 *dataset;
{
    return 4.0 - sphere(x+1.0,y,z,dataset) -
      sphere(x,y+1.0,z,dataset) - sphere(x,y,z+1.0,dataset);
}


#ifdef SGIGFX /**************************************************************/

#include "gl.h"

/* triangle: called by polygonize() for each triangle; set SGI lines */

triangle (i1, i2, i3, vertices)
int i1, i2, i3;
VERTICES vertices;
{
    float v[3];
    int i, ids[3];
    ids[0] = i1;
    ids[1] = i2;
    ids[2] = i3;
    bgnclosedline();
    for (i = 0; i < 3; i++) {
	POINT *p = &vertices.ptr[ids[i]].position;
	v[0] = p->x; v[1] = p->y; v[2] = p->z;
	v3f(v);
    }
    endclosedline();
    return 1;
}


/* main: call polygonize() with torus function
 * display lines on SGI */

main ()
{
    char *err, *polygonize();

    keepaspect(1, 1);
    winopen("implicit");
    doublebuffer();
    gconfig();
    perspective(450, 1.0/1.0, 0.1, 10.0);
    color(7);
    clear();
    swapbuffers();
    makeobj(1);
    if ((err = polygonize(thresh, .1, 10, 0.,0.,0., triangle, TET, NULL)) != NULL) {
	fprintf(stderr, "%s\n", err);
	exit(1);
    }
/*
    if ((err = polygonize(torus, .05, 20, 0.,0.,0., triangle, TET, NULL)) != NULL) {
	fprintf(stderr, "%s\n", err);
	exit(1);
    }
*/
    closeobj();
    translate(0.0, 0.0, -2.0);
    pushmatrix();
    while(1) { /* spin the object */
	reshapeviewport();
	color(7);
	clear();
	color(0);
	callobj(1);
	rot(0.8, 'x');
	rot(0.3, 'y');
	rot(0.1, 'z');
	swapbuffers();

    }
}

#else /***********************************************************************/

int gntris;	     /* global needed by application */
VERTICES gvertices;  /* global needed by application */


/* triangle: called by polygonize() for each triangle; write to stdout */

triangle (i1, i2, i3, vertices)
int i1, i2, i3;
VERTICES vertices;
{
    gvertices = vertices;
    gntris++;
    fprintf(stdout, "%d %d %d\n", i1, i2, i3);
    return 1;
}


/* main: call polygonize() with torus function
 * write points-polygon formatted data to stdout */

main ()
    {
    int i;
    char *err, *polygonize();
    gntris = 0;
    fprintf(stdout, "triangles\n\n");
    if ((err = polygonize(torus, .05, 20, 0.,0.,0., triangle, TET, NULL)) != NULL) {
	fprintf(stdout, "%s\n", err);
	exit(1);
	}
    fprintf(stdout, "\n%d triangles, %d vertices\n", gntris, gvertices.count);
    fprintf(stdout, "\nvertices\n\n");
    for (i = 0; i < gvertices.count; i++) {
	VERTEX v;
	v = gvertices.ptr[i];
	fprintf(stdout, "%f  %f	 %f\t%f	 %f  %f\n",
	    v.position.x, v.position.y,	 v.position.z,
	    v.normal.x,	  v.normal.y,	 v.normal.z);
    }
    fprintf(stderr, "%d triangles, %d vertices\n", gntris, gvertices.count);
    exit(0);
}

#endif /**********************************************************************/



