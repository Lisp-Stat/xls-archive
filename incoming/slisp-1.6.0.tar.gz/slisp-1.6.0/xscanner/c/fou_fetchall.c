/*---------------------------------------------------------------------------

fou_fetchall.c - UW/Seattle implementation of FETCH ALL 	

For the UW/Seattle environment: Prism treatment planning system.

This file was developed under VAX/VMS, but is written in portable C, so it
could be compiled and used anywhere that Prism-format data files are found.   
These are sequential text files where  each object and each attribute are
indicated by keywords.

In this implementation the data set is a single file and the data_id input
parameter is simply the file name. In the VMS world this is actually quite
flexible, since the VAX/VMS C environent interprets this string as a logical
name.  That means the input file can be anything you wish; you simply define
the logical name before calling this function, for example by typing a DCL
command as follows:

	$ define mydata dua0:[rtpt]sample-patient.dat

This is the only VMS-dependent behavior in the function.

This version writes some messages to the standard output as it goes.

---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 Revision History:

 Date             Pgmr                 Comments
 =============================================================================

7/30/91		J. Jacky		Begun
8/ 1/91		J. Jacky		First successful compile/run (as stub)
8/ 5/91 	J. Jacky		Completed find_next_key function
8/ 5/91		J. Jacky		Completed lookup_class function
8/ 6/91		J. Jacky		Input param classes is a linked list
8/ 6/91		J. Jacky		Begin get_object function
8/ 7/91		J. Jacky		Skeletal get_object working
8/ 8/91		J. Jacky		Extract prism_rtpt_classes table to
					  rtpt.h; also used by fou_storeall
					get-object reads data items for Point
					get_object returns (int) status value;
					 &current_object is input parameter.
8/ 9/91		J. Jacky		Add eof_flag to find_next_key in params
8/12/91		J. Jacky		Begin SOLID - includes CONTOUR objects
8/13/91		J. Jacky		Add get_all_objects 
8/13/91		J. Jacky		Completed support for Point, Contour,
					 Volume and Solid
2/18/92		J. Jacky		Add documentation - pseudocode for
					 most functions 
20-Mar-1992     J. Jacky                New prototype compliant with TR-92-1.
					Class macro from rtpt.h in put_object.
23-Mar-1992	J. Jacky		Extract get_volume procedure
25-Mar-1992     J. Jacky                get_volume not a good idea after all;
					 use get_name and get_contours instead.
					Oh, get_name doesn't work either - 
					 extract wreckage to get_name_frg.c,
					 and repeat code all over the place.
26-Mar-1992	J. Jacky		Neither does get_contours - extract
					 the remains to get_contours_frg.c,
26-Mar-1992   J. Jacky   New 3-column form for prism_rtpt_classes table, to 
                          fetch all derived classes when base class only is 
                          requested.  Change lookup_class and get_all_objects.
30-Mar-1992   J. Jacky   Begin support for Dose Grid and Dose Distribution
31-Mar-1992   J. Jacky   Add code to fetch dose array elements
 3-Apr-1992   J. Jacky   In main fou_fetchall, correctly handle case where
			  get_all_objects finds no instances of requested class
 5-Apr-1992   J. Jacky  Finished (for now) with Grid Values and Grid Geometry;
			 comment out almost all the printf's used for debugging.
		        Error remains: in grid values array, first row in each
			 plane after the first is a duplicate of last row of 
			 previous plane. All other rows ok.
 5-Apr-1992   J. Jacky  Add support for Images.
16-Apr-1992   J. Jacky  Image transformation details.
17-Apr-1992   J. Jacky  Try using Jonathan Unger's bin-array.c (from Prism) 
			 to actually read the binary image arrays.
			set z_size to thickness when reading Image 2D
16-Jun-1992   J. Jacky  Finally fix error in reading grid values arrays;
			 new code for GRID VALUES copied from get_dose_matrix.c
22-Jun-1992   J. Jacky  Clear up confusion between nx (highest index in 
			 array) and grid_geom_p -> n_x (n of elements in array)
			Also include computation of transform. matrix scale
			 factors for dose grids
26-Jun-1992   J. Jacky  Fix error regarding sign of z in coord transform 
			 for dose matrices 
30-Jun-1992   J. Jacky  More fixes in transform matrices: in contour, set
			 all scale factor (diagonal) elements to 1.0
			In grid values, scale factors = size/(n-1) not /n
   			Yikes! Fix errors in loops to initialize transfm 
			 matrices should be i <= 3 not i < 3
31-Aug-1992   J. Jacky  Add support for Beam and all its derived classes.
			 *However* multileaf contour portal not yet read in;
			 also, contained blocks in beams not yet read in.
 1-Sep-1992   J. Jacky  Add support for Beam Delivery System, including 
			 all its derived classes.  Reads delivery systems
			 from file named treatment-machines; this is
			 *hard-coded*, can either be file in current default
			 directory, or (for example) VMS logical name.
			 Some beam delivery system members set to UNKNOWN, NULL
			NOT! - 28-Dec-1992 - couldn't find implementation for
			 this - I think I wrote note but never implemented
 1-Sep-1992  J. Jacky  Rename class macro to rtpt_class macro to avoid name
			clash with X code (first encountered in UNC's DRR tool)
 2-Sep-1992  J. Jacky  Change image pixtype from ...SMALL_UINT to ...MEDIUM...
			(mistake noticed by G. Tracton)
 6-Oct-1992  J. Jacky  Move #define MAXLINE 80 to rtpt.h
13-Nov-1992  J. Jacky  Prism keyword prefix is now PRISM:: not RTP::
			See if we can just look for <string>:: so we can deal 
			with both (in fact, any) introducers.  However, most
			comments in this file are *not* changed, so we still
			refer to RTP:: in many places.
 7-Dec-1992  J. Unger Change type of jstatus in find_next_key from int to 
                        char *, since fgets returns a pointer to a char.
 7-Dec-1992  J. Unger Add external declaration for alloc_set(), which is 
                        defined in fou_utils.c and is used twice below in
                        get_object.
 9-Dec-1992  J. Unger Add numerous explicit type casts throughout the code
                        to avoid warnings from eowyn's ansi c compiler.
23-Dec-1992  J. Unger Modify the read of the 'Z' attribute of contours in 
                        get_object so that it explicitly casts the type of
                        the value read to large_float.
24-Dec-1992  J. Unger Modify find_next_key so that the fscanf correctly 
                        reads data files when compiled under unix; see 
                        comment in source below.
24-Dec-1992  J. Unger Modify other parts of code where numbers are read 
                        into entries of a transform array from a file -
                        the numbers need to be cast explicitly to 
                        large_float's (the type of each transform array
                        entry) after being read in to work in unix.
24-Dec-1992  J. Jacky Initialize and read hosp_name in IMAGE, 
			x_orient and y_orient in IMAGE_2D
28-Dec-1992  J. Jacky Revise implementation of BEAM to match recent Prism spec
29-Dec-1992  J. Jacky Implement Blocks and Beam Delivery System 
			- as promised but not delivered in 1-Sep-1992 note
 5-Jan-1993  J. Unger Modify code that reads n_treatments attribute of a beam
                        to use a temp variable and explicitly cast the value
                        read before assigning it to the appropriate data struct
 5-Jan-1993  J. Jacky Fix allocation problem in collim_type of Beam Delivery
			System discovered by J. Unger.  In fact, set slen to
			MAXLINE (not strlen(no_name) + 1) before initializing
			strings in *all* classes,  not just Beam Delivery
 5-Jan-1993  J. Unger Modify code that reads n_z in from VOXELS attribute of
                        image-3D to use a temp variable and explicitly cast 
                        the value read before assigning it to the appropriate 
                        data structure
 7-Jan-1993  J. Jacky Be sure to initialize all slots in the instance
			of rtpt_set_t pointed to by objects_p param
 7-May-1993  J. Unger Replace find_next_key with a character based reading
                        mechanism.  Jon Jacky's approach used fscanf's 
                        formatting facilities, was higher level, and more
                        elegant, but apparently more susceptible to 
                        unforseen problems with running the foundation in
                        new (ie: AIX) environments.
 2-Aug-1993  J. Jacky Fix sign error in z scale of image transform matrix.
                      Fix data structure error when beam has no blocks;
		       initialize blocks_p with alloc_set, not NULL.
		       Forestall similar errors: contours_p is already ok;
		       but fix wedges_p in beam delivery system.
14-Dec-1993  J. Jacky Change fetch of grid values to accommodate
                       actual Prism dose array order in files: z index
 		       first, then y, then x.  So planes in Prism dose
		       files are actually *sagittal* planes, while in
		       RTPT they are *transverse* planes.
18-Feb-1994  J. Jacky Accomodate latest Prism case file format.
                      find_next_key must deal w/ one or two colons:
		        PRISM::KEYWORD or PRISM:KEYWORD
		      Today: CONTOUR. Must deal with PRISM:VERTICES  NIL
19-Feb-1994  J. Jacky Today: GRID-GEOMETRY and SUM-DOSE.
                      There is no more GRID-GEOMETRY in IMAGE.  GRID-GEOMETRY
		       is now for dose only and is quite different.
20-Feb-1994  J. Jacky Calculate n_x in grid geom. from voxel size.
24-Feb-1994  J. Jacky Accommodate DOSE-RESULT block in BEAM
25-Feb-1994  J. Jacky Read MLC portal coords into hidden seg member in m_beam
 9-Jun-1994  J. Jacky Read Prism TABLE-POSITION as an RTPT-POINT named DRP,
                       (delivery reference position) as TR-91-1 demands.
 6-Jul-1994  J. Jacky Change documentation with GRID_GEOMETRY and
                       GRID_VALUES to conform to new Prism dose1 etc. files
 7-Jul-1994  J. Jacky Beams again - Prism files might have 0 blocks
                       NOTE -- we're just skipping over Prism wedges for now!
13-Jul-1994  J. Jacky Don't crash if binary image file cannot be opened
                       (e.g. if current directory is not image file directory)
14-Jul-1994  J. Jacky Now handle Prism wedges properly
                      Omit DOSE RESULT from Prism beams --- gone now
18-Jul-1994  J. Jacky Deal with DENSITY NIL in addition to DENSITY <float>
03-Aug-1998  K. Hinshaw  Fixed type bug in find_next_key.

----------------------------------------------------------------------------*/

#include <stdio.h>	/* Declares FILE which is needed by rtpt.h */
#include <string.h>	/* We use some strcmp etc. but for for some reason
			/* it seems to work without this #include */

#include "rtpt.h"

#define FALSE 	0	/* For clarity */
#define TRUE 	1	/* Any non-zero int would work */

extern rtpt_set_t *alloc_set();   /* fwd decl; def'ed in fou_utils.c (jmu) */

/***************************************************************************

find_next_key.  This function is called by Fetch All and also get_object.  It
reads forward from the current position of the file pointer until it reads a
keyword or reaches a terminator.  The terminator may be end of file, or a
special terminator string, such as ":END".

This function is used by by get_all_objects to find the lable for the next
object, and by get_object to find the label for the next object attribute.

This function works much like fscanf.  It returns an integer which is EOF if
end of file was reached and no keyword was found; otherwise it returns a small
non-negative integer, the number of items read.  The second argument is a
pointer to the keyword.  If a keyword is found, the file pointer is left
pointing to the first character after the keyword.

Keywords always occur after the prefix, "RTP::".  The keyword is the sequence
of characters immediately following this prefix up to but not including the
first blank,tab, or linebreak.    The keyword may be a variable number of
characters long.  The prefix, if it occurs, is the first non-(blank,tab) string
on the line.  Here is a fragment from a sample input file:

         RTP::CONTOURS  
           RTP::CONTOUR  
             RTP::Z  0.0  
             RTP::VERTICES  ((0.051 2.978) (-0.995 2.418) (-1.99 1.934) (-2.526 1.552) (-2.807 1.12)
 (-2.883 0.076) (-2.858 -0.433) (-2.475 -1.094) (-1.863 -1.425) (0.128 -1.603))
           :END  
         :END  
         RTP::DOSE-HISTOGRAM  NIL  

Successively calling find_next_key on this fragment should return the keywords 
CONTOURS, CONTOUR, Z, VERTICES and DOSE-HISTOGRAM.

If the input_parameter stop_flag is false (zero), this program will always
search to end of file for the next RTP::....  If stop_flag is true (nonzero),
the  function will return as soon as it reads the terminator string :END.  In
this case, :END is returned as the keyword.  (If stop_flag is true, the
function  will still search to end of file if no :END is seen).   

Call this function with stop_flag set to false to scan for objects, as in the
call to get_all_objects in the main Fetch All function; call it with stop_flag
true to scan for items within an object, as when scanning for attribute labels 
in the get_object function, or scanning for contained objects when calling
get_all_objects from the get_object function.

****************************************************************************

13-Nov-1992 - NOTE - Now the Prism keyword prefix is
"PRISM::", not "RTPT::".   Today I modified the code so it searches for any 
"<string>::". So the preceding comments apply whether the prefix is RTP::, 
PRISM::, or anything else.  In fact you could even mix different prefixes in
the same file.  Now we only require that there be a prefix, but it doesn't 
matter what it is.

*****************************************************************************

find_next_key

    Modified 18-Feb-1994 because Prism files may have *one or two*
    colons before the keyword, e.g. PRISM::KEYA or PRISM:KEYB

    In both cases, returned key should be KEYA or KEYB - no initial colons.

Variables

    left: portion of input file that has already been read.
    right: portion of input file that has yet to be read.

    key_s: keyword string (passed parameter, updated by this function)

Precondition (if not satisfied, may crash somewhere if fscanf hits EOF)

    EOF \/ ":%s" in right

Return conditions (used to define postcondition)

    0.  EOF

    1.  (end of left = "END") /\ stop_flag

    2.  (end of left = ":%s") /\ s != "END"

    When end of left = "END" but stop_flag is FALSE, we do NOT return.

Postcondition (return codes and strings just copied from older version)

     0. return EOF

     1. return 1 /\ key_s = ":END"  (inital ':' must be included)

     2. return 2 /\ key_s = s       (after any initial ':' removed)

***************************************************************************/

int find_next_key(FILE *fp, char *key_s, int stop_flag)

{
    /* BUGFIX:  c changed from char to int (kph, 98Aug03) */
    int  istart, c;
    char temp_s[MAXLINE];

    while ((c = getc(fp)) != EOF) {

	/* Check for first ':' */
	if (c == ':') {
	    fscanf(fp, "%s", temp_s); /* temp_s holds string after 1st ':' */
	    
	    /* Check for END */
	    if (strcmp (temp_s, "END") == 0) {
		if (stop_flag) {
		    strcpy(key_s, ":END"); /* Caller expects leading ':' */
		    return 1;
		}
		/* if NOT stop_flag, do nothing - just keep reading */
	    } 

	    /* Other keywords (not END) */
	    else {
		istart = 0;
		if (temp_s[0] == ':') istart = 1; /* Don't return 2nd ':' */
		strcpy(key_s, temp_s + istart);
		return 2;
	    }
	}
    }
    return EOF;
}

/***************************************************************************

lookup_class.   This function is called by Fetch All.  Used to determine the 
class of an object instance encountered in a Prism format data file, based on
its labelling keyword.

This function uses typedef prism_rtpt_class_t, #define'd integer N_RTPT_CLASSES,
and the initialized array prism_rtpt_classes, all defined in rtpt.h

The array prism_rtpt_classes is a table.  Here are the column names and a few
sample entries:

prism_key     fetch_class        found_class

"ORGAN"       RTPT_VOLUME        RTPT_SOLID
"ORGAN"       RTPT_SOLID         RTPT_SOLID

There are *three* columns in the table.  The first column holds the prism
keyword that labels an object instance in the file.  The other two columns are
the RTPT classes that are associated with that keyword.  The second column is
the RTPT class Fetch All has been instructed to fetch.  The third column is the
RTPT class actually found. These two classes can be different because Fetch All
is defined so that if  we are searching for a base class, we are also supposed
to fetch its derived classes.  Therefore, derived classes appear in the
table multiple times in the found_class column, paired with themselves and all
of their ancestor classes in the fetch_class column.

The two input parameters to this function are a prism_key and a fetch_class. If
a table entry is found whose first two columns matches both, the  found_class
from the third column of that entry is returned.  Otherwise, RTPT_ABSENT is
returned.

In other words, the lookup_class function matches the keyword found in the
input file *and* the sought-after class passed into fou_fetchall with the first
and second columns of the table in rtpt.h, respectively, and returns the third
column from the matching row, which is then built into the in-memory RTPT data
structure. 


This is similar to example in K&R 2nd ed, section 6.3, "Arrays of Structures",
pps. 132 - 133

******************************************************************************/

char *lookup_class(char *key_s, rtpt_string_t current_class)

{
   int i;

  /*   printf("Calling lookup_class; seeking match with key %s, class %s\n", 
		key_s, current_class); */

   /* This is C idiom for processing consecutive array elements, 
      K&R 2nd ed. p 61 */

   for (i = 0;
	 (i < N_RTPT_CLASSES) &&
	 !((strcmp(key_s, prism_rtpt_classes[i].prism_key) == 0) &&
           (strcmp(current_class, prism_rtpt_classes[i].fetch_class) == 0));
       i++) {

/* printf("i %d, prism_key = |%s|, fetch_class = |%s|, found_class = |%s|\n",
   i, prism_rtpt_classes[i].prism_key, 
   prism_rtpt_classes[i].fetch_class, prism_rtpt_classes[i].found_class); */
   }

   return prism_rtpt_classes[i].found_class;
}

/***************************************************************************

get_object. This function is called by get_all_objects. It reads a single
object from the input file.  Since objects can contain other objects, it is
indirectly recursive; it may call get_all_objects (which calls get_object).

This is the workhorse function that actually digs reads the data from the file
and has to know how each class is represented in the file.  It's structured as
a great big switch statement, one case for each class.

Input params are file pointer and object type.  Output param is a pointer to a 
set element (which then points to the struct containing the object data).

Returns an integer status value.

When this function is called, it is assumed that the file pointer is positioned
immediately after the keyword that marks the beginning of the object.  In other
words, the file pointer has not moved since find_next_key returned the keyword
marking the beginning of the object.

When this function exits, the file pointer... (what?) or is positioned at the
end of the file. 

Each data item is preceded by a keyword. There are three *kinds*
of keyword/value pairs.  Select the appropriate method for the keyword:		

   1. Simple (single value or small array, including contour vertices) 
   2. Compound (a list of objects, such as contours) - recurse 
   3. Binary image array (you have to open and read a binary file) 

Within each branch, keep track of which Prism keywords are associated with
which C struct members. It could be as simple as (Prism keyword/C member) or as
bad as (Prism class/prism keyword/C class/C member) 	

(Handle special case for Grid Geometry here inside get_object?)

Here is the pseudocode for get_object

   On entry, we have just read the keyword for the object class we were 
   looking for.

	Allocate an rtpt_set_t and initialize its pointers and id

	Switch on class 
	(actually using if ... on matching class name *string*)

	Simple class (Point, Contour, etc.):

		Allocate rtpt_point_t (or whatever) and initialize its 
		pointers and id, hook up to its rtpt_set_t

		do
			find_next_key
			
			if eof then return failure immediately
			
			if key = "ATTRIBUTE_1_LABEL" 
				then object.attribute_1_value := read blah blah

			if key = ... (and so on)

		while not eof and not end of object
			

	Complex classes that include sets of objects (Solid, Volume etc.):

		Allocate rtpt_point_t (or whatever) and initialize its 
		pointers and id, hook up to its rtpt_set_t

		do
			find_next_key
			
			if eof then return failure immediately
			
			if key = "ATTRIBUTE_1_LABEL" 
				then object.attribute_1_value := read blah blah

			if key = ... (and so on for simple attributes)

			if key = "CONTOURS" (indicating set of objects)

				allocate another rtpt_set_t, initialize

				get_all_objects with stop flag true

				Hook list of returned objects onto 
				recently allocated rtpt_set_t

		while not eof and not end of object

	Return success			

****************************************************************************/

int get_object(FILE *fp, rtpt_string_t current_class, 
				rtpt_set_t **current_object)

	/* Note the pointer to a pointer - its the only way 
	   to change a pointer parameter given call-by-value */

{
   /* For scanning the file */
   int fstatus;
   char current_label[MAXLINE]; /* rtpt_string_t current_key; CRASHES! */

   /* For each of the classes */   
   rtpt_set_t *obj_p;
   rtpt_volume_t *volume_p;
   rtpt_solid_t *solid_p;
   rtpt_contour_t *contour_p;
   rtpt_point_t *point_p;
   rtpt_grid_geom_t *grid_geom_p;
   rtpt_grid_values_t *grid_values_p;
   rtpt_image_t *image_p;
   rtpt_image_2d_t *image_2d_p;
   rtpt_image_3d_t *image_3d_p;

   /* For name field, a string */   
   char *no_name = RTPT_ABSENT;		     /* Must match corresponding...  */
   char *hounsfield = RTPT_UNITS_HOUNSFIELD; /* items in fou_storeall put... */
   int slen;
   char temp_s[MAXLINE]; 

   /* For points */
   char *drp_name = "DRP";

   /* For contours and their vertices */
   int i,j, nv, ic, num_contours;
   char ch[1];	/* For reading past initial "(" */
   int	iv;  /* index of current vertex */
   rtpt_vertex_t vbuf[MAX_VERTICES];

   /* For Grid Geometry */
   float tmp, voxel_size;
   int temp_int; /* Needed to swap n_x and n_z in grid_geom */

   /* For dose arrays */ 
#define MAX_ELEMENTS 320 /*  Max dose plane row, col.  Mark P. may use 320 */
   int row_size;
   int iplane, irow, icol;  /* indices of current element */ 
   int nx, ny, nz; /* Highest array indices; each dimension goes 0..nx (etc.).  
			Not to be confused with n of elements.  These are
			assigned as follows: 

			   grid_geom_p -> n_x = nx + 1;

			etc.  See TR-91-1 p. 31. */
   int end_plane, end_array; /* boolean flags */
   rtpt_set_t *rows_p, *tmp_p; /* pointer to list of row buffers, current row */
   small_float *row_p, *array_p; /* current row buffer, array buffer */
   char ch4[4], parens[4]; 
    /* For reading labels, parens at start and end of rows, planes, array */

   /* Binary image files */
   FILE *imf; 

   /* Beam and Beam Delivery System */
   rtpt_beam_t *beam_p, *temp_beam_p;
   rtpt_s_beam_t *s_beam_p;
   rtpt_c_beam_t *c_beam_p;
   rtpt_vj_beam_t *vj_beam_p;
   rtpt_m_beam_t *m_beam_p;
   int ileaf, num_blocks; 
   small_float coll_x, coll_infy, coll_supy;
   int nsegs;
   rtpt_string_t this_class, collim_type;
   rtpt_block_t *block_p;
   rtpt_beam_delivery_t *temp_beam_deliv_p, *beam_deliv_p;
   rtpt_s_beam_delivery_t *s_beam_deliv_p;
   rtpt_c_beam_delivery_t *c_beam_deliv_p;
   rtpt_vj_beam_delivery_t *vj_beam_deliv_p;
   rtpt_m_beam_delivery_t *m_beam_deliv_p;

   /* For collecting contained objects */ 
   rtpt_set_t *contained_objects, *tail;
   int gstatus;

   printf("  Entering get_object seeking %s\n", current_class);

   /* Do generic things needed for all classes */
   
   obj_p = alloc_set();
   /* was: obj_p = (rtpt_set_t *) malloc(sizeof(rtpt_set_t)); note cast 
      ...but this may not set fields to null properly */
   *current_object = obj_p; /* current_obj is a pointer to a pointer */
   /* obj_p -> obj_id.type = RTPT_SET;  This is now done by alloc_set */
   
  /* 
      Do things specific to this class 

      RTPT class names are strings, not integers 
      so we can't use switch - must use if-then-else 
  */

   /* Delivery reference point (DRP) is special case --- different label in */
   /* Prism file, becomes instance of RTPT_POINT named DRP per TR-91-1 */
   if rtpt_class(current_class, DRP) {
       printf("   found DRP\n");
       obj_p -> set_element_p = (rtpt_point_t *) malloc(sizeof(rtpt_point_t));
       point_p = obj_p -> set_element_p;
       point_p -> obj_id.type = RTPT_POINT;
       slen = MAXLINE; 			/* Safer - was strlen(no_name) + 1; */
       point_p -> name = (rtpt_string_t) malloc(slen);
       strcpy(point_p -> name, drp_name); /* This seems safest */
       point_p->point_no = -1; /* flag for DRP */

       /* Data looks like PRISM:TABLE-POSITION  #(-0.337 -10.917 13.0 1.0) */
       fstatus = fscanf(fp, " #(%f %f %f", 
			&(point_p->x), &(point_p->y), &(point_p->z));
       printf("   read DRP; name = %s, no = %d, x,y,z = %8.3f,%8.3f,%8.3f\n",
	      point_p->name, point_p->point_no,
	      point_p->x, point_p->y, point_p->z);
   } /* end DRP */

   else if rtpt_class(current_class, RTPT_POINT) {
      obj_p -> set_element_p = (rtpt_point_t *) malloc(sizeof(rtpt_point_t));
      point_p = obj_p -> set_element_p;
      point_p -> obj_id.type = RTPT_POINT;
      slen = MAXLINE; 			/* Safer - was strlen(no_name) + 1; */
      point_p -> name = (rtpt_string_t) malloc(slen);
      strcpy(point_p -> name, no_name); /* This seems safest */

      do {
	fstatus = find_next_key(fp, current_label, TRUE);
	if (fstatus == EOF) {
	   return RTPT_ST_FAIL; /* Reached EOF while scanning inside object */
	   }

	if (strcmp(current_label, "ID") == 0) {
	    /* printf("   strcmp in get_obj detects label ID\n"); DEBUG*/
	    fstatus = fscanf(fp, "%d", &(point_p->point_no));
	    if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	    printf("   read point_no %d\n",point_p->point_no);
	} 


	if (strcmp(current_label, "NAME") == 0) {
		/* printf("   strcmp in get_obj detects label NAME\n"); */
	   /* printf("  We haven't figured out how to read strings yet\n"); */

	/*********************************************************

		The name is delimited in the input file by " characters
		that are *not* part of the name, and the name may include
		embedded blanks that *are* part of the name.
		Try to read it in using fancy scanf format.

	*******************************************************/

		fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
	   /* printf("   name read into temp_s buffer as |%s|, length %d\n", 
			temp_s, slen); */
		point_p -> name = (rtpt_string_t) malloc(slen);
		strcpy(point_p -> name, temp_s);
	   /* printf("   name read into struct as |%s|\n", point_p -> name); */
	
		} 

	   if (strcmp(current_label, "X") == 0) {
		/* printf("   strcmp in get_obj detects label X\n"); DEBUG */
		fstatus = fscanf(fp, "%f", &(point_p -> x));
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		/* printf("   x has been read as %.3f\n", point_p -> x); */
		} 

	   if (strcmp(current_label, "Y") == 0) {
		/* printf("   strcmp in get_obj detects label Y\n"); DEBUG */
		fstatus = fscanf(fp, "%f", &(point_p -> y));
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		/* printf("   y has been read as %.3f\n", point_p -> y); */
		} 

	   if (strcmp(current_label, "Z") == 0) {
		/* printf("   strcmp in get_obj detects label Z\n"); DEBUG */
		fstatus = fscanf(fp, "%f", &(point_p -> z));
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		/* printf("   z has been read as %.3f\n", point_p -> z); */
  		} 

      } /* end do-while body */
      while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));

      } /* end RTPT_POINT */

   /* In RTPT, a CONTOUR and BLOCK are almost the same thing */
   else if (rtpt_class(current_class, RTPT_CONTOUR) ||
		rtpt_class(current_class, RTPT_BLOCK)) {

      if rtpt_class(current_class, RTPT_CONTOUR) {
	      obj_p -> set_element_p = (rtpt_contour_t *) 
					malloc(sizeof(rtpt_contour_t));
	      contour_p = obj_p -> set_element_p;
      } 
      else if rtpt_class(current_class, RTPT_BLOCK) {
	      obj_p -> set_element_p = (rtpt_block_t *) 
					malloc(sizeof(rtpt_block_t));
	      block_p = obj_p -> set_element_p;
	      block_p -> obj_id.type = RTPT_BLOCK;
	      block_p -> transmission = 0.05; /* Prism default */
	      contour_p = &(block_p -> contour);
      }

      contour_p -> obj_id.type = RTPT_CONTOUR;
      contour_p -> poly.nvertices = 0;          /* This seems safest */
      contour_p -> poly.vertices_p = NULL;	/*  "		"    */

      /* In Prism, all contours are transverse, in the patient coordinate
	system.  Therefore, all the elements of the transformation matrix
	are 0 except one element, the Z displacement component of 
	the translation vector.  So, we always need to zero out the
	transformation matrix, except row 4, column 4 which is always 1.0,
	because it's a homogeneous transformation matrix. */

      for (i = 0; i <= 3; i++) {
	for (j = 0; j <= 3; j++) {
	   contour_p -> poly.trans.transform[i][j] = 0.0;
	}
      }
      for (i = 0; i <= 3; i++) {
	   contour_p -> poly.trans.transform[i][i] = 1.0; /* scale factors */
      }

      do {
	fstatus = find_next_key(fp, current_label, TRUE);
	if (fstatus == EOF) {
	    /* printf("   Returned from find_next_key: status %d, EOF or :END\n",
		   fstatus); */
	   return RTPT_ST_FAIL; /* Reached EOF while scanning inside object */
	   }

	/* printf("  Returned from find_next_key: status %d, keyword |%s|\n", 
	       fstatus, current_label);  */

	/* Read in all the slots */
	
	   /* This slot *only* exists in BLOCK, not BEAM.  It's a "hidden"
		attribute, not known to portable RTPT world, only to Prism */
	   if (strcmp(current_label, "TRANSMISSION") == 0) {
		fstatus = fscanf(fp, "%f", &(block_p -> transmission));
		} 

	   /* The Z translation is in row 4, column 3 of the transformation 
		matrix - see p. 24 of TR-91-1. In this C binding, column is
		1st index and indexing is 0-based: [column:0..3][row:0..3] */

	   if (strcmp(current_label, "Z") == 0) {
                float temp_z;                   /* temp storage for z value; */
                                                /* explicitly cast here; jmu */
		fstatus = fscanf(fp, "%f", &temp_z);
		contour_p -> poly.trans.transform[2][3] = (large_float) temp_z;

		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	   /*  printf("   z displ read into transformation matrix as %.3f\n", 
			contour_p -> poly.trans.transform[2][3]); */
		} 

/***************************************************************************

		In Prism files the vertices are just Lisp lists; there is no 
		preceding count.  We have to read all the vertices into a 
		(sufficiently large) buffer first, counting as we go; then,
		allocate a new array just large enough to hold them all. 

		Here is a fragment of a Prism input file showing how 
		vertices are stored:

	             RTP::VERTICES  ((0.026 -9.224) (2.457 -9.07) (3.942 -8.713) (5.145 -8.304) (5.81 -6.694)
 (5.989 -4.727) (6.015 -1.891) (6.015 0.051) (5.631 2.504) (5.145 4.19)
	.
	. 	... several lines omitted ...
	.
 (-1.613 -8.892) (0.026 -9.224))  

		At the beginning of the list we find "(" then any number of
		vertices of the form "(%f %f)" and finally a closing ")". 

		18-Feb-1994 - Some Prism case files include lines that
		say: PRISM:VERTICES  NIL.   They're not supposed to,
		but they do.   In that case, don't return FAIL; just
		leave nvertices = 0 and contour_p -> poly.vertices_p = NULL
		
******************************************************************************/

	   if (strcmp(current_label, "VERTICES") == 0) {
		fstatus = fscanf(fp, "%1s", ch); /* read first nonwhite char */
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */

		if (strcmp(ch,"(") == 0) { /* start of list of coords */
		    fstatus = 2; /* Needed to init. for loop */
		    for (iv = 0; (fstatus == 2) && (iv < MAX_VERTICES); iv++) {
			fstatus = fscanf(fp," (%f %f)", 
					 &(vbuf[iv].x), &(vbuf[iv].y));
			/* printf("%d (%.3f %.3f) \n", 
			   iv, vbuf[iv].x, vbuf[iv].y); */
		    }
		    contour_p -> poly.nvertices = --iv; 
		    /* had to go one too far */
		    printf("   %d vertices read in\n", 
			   contour_p -> poly.nvertices); 
		    contour_p -> poly.vertices_p = 
			(rtpt_vertex_t *) 
			    malloc(contour_p->poly.nvertices * 
				   sizeof(rtpt_vertex_t));
		    for (iv = 0; iv < (int) contour_p -> poly.nvertices; iv++){
			contour_p -> poly.vertices_p[iv].x = vbuf[iv].x;
			contour_p -> poly.vertices_p[iv].y = vbuf[iv].y;
		    } 
		} /* end if "(" at start of list of coords found */
		else obj_p -> set_element_p = NULL;
		/* We might not find that initial "(" --- might be NIL */
		/* If so, leave nvertices = 0 and contour_p = NULL */
		/* Better yet, make whole contour NULL */
	    } /* end if VERTICES */

    } /* end do-while find_next_key... body */
      while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));

  } /* end RTPT_CONTOUR, RTPT_BLOCK */

   /* VOLUME */
   else if rtpt_class(current_class, RTPT_VOLUME) {
      obj_p -> set_element_p = (rtpt_volume_t *) malloc(sizeof(rtpt_volume_t));
      volume_p = obj_p -> set_element_p;
      volume_p -> obj_id.type = RTPT_VOLUME;
      slen = MAXLINE; 			/* Safer - was strlen(no_name) + 1; */
      volume_p -> name = (rtpt_string_t) malloc(slen);
      strcpy(volume_p -> name, no_name); /* This seems safest */
      volume_p -> z_plus = 0.0;  /* These are always 0 in Prism */
      volume_p -> z_minus = 0.0; 
      do {
	fstatus = find_next_key(fp, current_label, TRUE);
	if (fstatus == EOF) {
	   return RTPT_ST_FAIL; /* Reached EOF while scanning inside object */
	   }

	/* Read in the slots */

	if (strcmp(current_label, "NAME") == 0) {
	   fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
	   if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	   slen = strlen(temp_s) + 1;
	   volume_p -> name = (rtpt_string_t) malloc(slen);
	   strcpy(volume_p -> name, temp_s);
	   } 

	if (strcmp(current_label, "CONTOURS") == 0) {

	   /* Allocate root node for this set of objects */
	   volume_p -> contours_p = 
			(rtpt_set_t *) malloc(sizeof(rtpt_set_t));
	   volume_p -> contours_p -> obj_id.type = RTPT_SET;
	   volume_p -> contours_p -> next_p = NULL;
	   volume_p -> contours_p -> set_element_p = NULL;

	   /* Indirect recursive call to get the constituent contours */
           gstatus = get_all_objects(fp, RTPT_CONTOUR, &contained_objects, 
			&tail, TRUE, &num_contours);
	   if (gstatus != RTPT_ST_OK) return gstatus; /* get_all_... failed */
	   printf("get_all_objects returned %d contours in VOLUME\n",
			num_contours);
	   tail -> next_p = NULL; 
	   volume_p -> contours_p -> next_p = contained_objects;
	   } 

      } /* end do-while find_next_key... body */
      while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));

      } /* end RTPT_VOLUME */

   else if rtpt_class(current_class, RTPT_SOLID) {  
      obj_p -> set_element_p = (rtpt_solid_t *) malloc(sizeof(rtpt_solid_t));
      solid_p = obj_p -> set_element_p;
      solid_p -> obj_id.type = RTPT_SOLID; 
      slen = MAXLINE; 		/* Safer - was strlen(no_name) + 1; */
      solid_p -> volume.name = (rtpt_string_t) malloc(slen);
      strcpy(solid_p -> volume.name, no_name); /* This seems safest */
      solid_p -> volume.z_plus = 0.0;  /* These are always 0 in Prism */
      solid_p -> volume.z_minus = 0.0; 
      solid_p -> density = 1.0; /* Reasonable default */
      do {
	fstatus = find_next_key(fp, current_label, TRUE);
	if (fstatus == EOF) {
	   return RTPT_ST_FAIL; /* Reached EOF while scanning inside object */
	   }

	/* Read in all the slots */

	if (strcmp(current_label, "NAME") == 0) {
	   fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
	   if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	   slen = strlen(temp_s) + 1;
	   solid_p -> volume.name = (rtpt_string_t) malloc(slen);
	   strcpy(solid_p -> volume.name, temp_s);
	   } 

	if (strcmp(current_label, "DENSITY") == 0) {
		fstatus = fscanf(fp, "%s", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		if (strcmp(temp_s, "NIL") == 0) {
		    /* Do nothing --- density remains at default */
		} else {
		   fstatus = sscanf(temp_s, "%f", &(solid_p -> density));
		   if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		} 
	    }

	if (strcmp(current_label, "CONTOURS") == 0) {

	   /* Allocate root node for this set of objects */
	   solid_p -> volume.contours_p = 
			(rtpt_set_t *) malloc(sizeof(rtpt_set_t));
	   solid_p -> volume.contours_p -> obj_id.type = RTPT_SET;
	   solid_p -> volume.contours_p -> next_p = NULL;
	   solid_p -> volume.contours_p -> set_element_p = NULL;

	   /* Indirect recursive call to get the constituent contours */
           gstatus = get_all_objects(fp, RTPT_CONTOUR, &contained_objects, 
			&tail, TRUE, &num_contours);
	   if (gstatus != RTPT_ST_OK) return gstatus; /* get_all_... failed */
	   printf("get_all_objects returned %d contours in SOLID\n",
			num_contours);
	   tail -> next_p = NULL; 
	   solid_p -> volume.contours_p -> next_p = contained_objects;
	   } 

      } /* end do-while find_next_key... body */
      while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));

  } /* end RTPT_SOLID */


   /*  Dose distributions: Grid Geometry and Grid Values 

       RTPT_GRID_GEOM is the Prism GRID-GEOMETRY.  
       RTPT_GRID_VALUES is the Prism DOSE-RESULT (its GRID attribute).

       The objects and attributes are nested inside a Prism dose1
       (etc.) files as follows:

	  PLAN
	    ...
	    SUM-DOSE
	      ...
	      DOSE-RESULT
	        ...
		GRID ...
		...
            DOSE-GRID
	      ...
	      GRID-GEOMETRY
		 ...
		 X-SIZE ...
		 ...
            BEAMS
	      ...
	      BEAM 
		...
		RESULT
		  ...
		  DOSE-RESULT
		    ...
		    GRID ...
		    ...
                ...
	      BEAM 
		...
		RESULT
		  ...
		  DOSE-RESULT
		    ...
		    GRID ...
		    ...
                ...

       There is just one GRID-GEOMETRY and DOSE-RESULT in each Prism 
       dose1 (dose2, dose3) file.

       */

   else if (rtpt_class(current_class, RTPT_GRID_GEOM)) {

       printf("    Entering get_object branch for %s\n", current_class);

       obj_p -> set_element_p = 
	   (rtpt_grid_geom_t *) malloc(sizeof(rtpt_grid_geom_t));
       grid_geom_p = obj_p -> set_element_p;
       grid_geom_p -> obj_id.type = RTPT_GRID_GEOM;

       /* Value of this name attribute was intended to match value of 
	  grid attribute in corresponding Grid Values object.  I don't 
	  think its needed anymore --- can only be one of each in each plan. */
       slen = MAXLINE; 			/* Safer - was strlen(no_name) + 1; */
       grid_geom_p -> name = (rtpt_string_t) malloc(slen);
       strcpy(grid_geom_p -> name, no_name); /* This seems safest */

       grid_geom_p -> x_size = 0.0;
       grid_geom_p -> y_size = 0.0;
       grid_geom_p -> z_size = 0.0;
       grid_geom_p -> n_x = 0;
       grid_geom_p -> n_y = 0;
       grid_geom_p -> n_z = 0;
       for (i = 0; i <= 3; i++) {
	   for (j = 0; j <= 3; j++) {
	       grid_geom_p -> trans.transform[i][j] = 0.0;
	   }
       }
       for (i = 0; i <= 3; i++) {
	   grid_geom_p -> trans.transform[i][i] = 1.0; /* scale factors */
       }

       do {
	   fstatus = find_next_key(fp, current_label, TRUE);
	   if (fstatus == EOF) {
	       return RTPT_ST_FAIL; /* Reached EOF scanning inside object */
	   }

	   /* Read in all the slots */

	   /* I think this attribute is not present in current Prism files */
	   if (strcmp(current_label, "NAME") == 0) {
	       fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
	       if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	       slen = strlen(temp_s) + 1;
	       grid_geom_p -> name = (rtpt_string_t) malloc(slen);
	       strcpy(grid_geom_p -> name, temp_s); /* This seems safest */
	       grid_values_p -> grid = (rtpt_string_t) malloc(slen);
	       strcpy(grid_values_p -> grid, temp_s); /* This seems safest */
	   }

	   /* In latest Prism, GRID-GEOMETRY, X-SIZE etc. separated, not like
	      SIZE in IMAGE-2D object.  Likewise X-ORIGIN vs. ORIGIN */
	   if (strcmp(current_label, "X-SIZE") == 0) {
	       fstatus = fscanf(fp, "%f", &(grid_geom_p -> x_size));
	       if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	       printf("      x_size %.3f\n", grid_geom_p -> x_size);
	   }
	   if (strcmp(current_label, "Y-SIZE") == 0) {
	       fstatus = fscanf(fp, "%f", &(grid_geom_p -> y_size));
	       if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	       printf("      y_size %.3f\n", grid_geom_p -> y_size);
	   }
	   if (strcmp(current_label, "Z-SIZE") == 0) {
	       fstatus = fscanf(fp, "%f", &(grid_geom_p -> z_size));
	       if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	       printf("      z_size %.3f\n", grid_geom_p -> z_size);
	   }

	   /* Explicitly cast the values to be assigned to transform array 
	      entries to large_float; jmu*/
	   if (strcmp(current_label, "X-ORIGIN") == 0) {
	       fstatus = fscanf(fp, "%f", &tmp);
	       if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	       grid_geom_p -> trans.transform[0][3] = (large_float) tmp;
	   }
	   if (strcmp(current_label, "Y-ORIGIN") == 0) {
	       fstatus = fscanf(fp, "%f", &tmp);
	       if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	       grid_geom_p -> trans.transform[1][3] = (large_float) tmp;
	   }
	   if (strcmp(current_label, "Z-ORIGIN") == 0) {
	       fstatus = fscanf(fp, "%f", &tmp);
	       if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	       grid_geom_p -> trans.transform[2][3] = (large_float) tmp;
	   }

	   /* VOXEL-SIZE is not an RTPT_GRID_GEOM attribute, but is in Prism.
	      Used to calculate n_x etc. */
	   if (strcmp(current_label, "VOXEL-SIZE") == 0) {
	       fstatus = fscanf(fp, "%f", &voxel_size);
	       if (fstatus != 1) return RTPT_ST_FAIL; /* bad input */
						      /* file */
	       printf("      voxel size %.3f\n", voxel_size);
	   }

       } /* end do-while find_next_key... body */
       while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));
   
       /* Calc n_x etc. as in Prism dose-objects.cl methods x-dim etc.
	  K&R2 p. 45 promises truncation when assign int = float */
       grid_geom_p -> n_x = 1 + (grid_geom_p -> x_size)/voxel_size;
       grid_geom_p -> n_y = 1 + (grid_geom_p -> y_size)/voxel_size;
       grid_geom_p -> n_z = 1 + (grid_geom_p -> z_size)/voxel_size;

       printf("      Grid geom calcs %d planes, %d rows, %d cols\n",
	      grid_geom_p -> n_z, grid_geom_p -> n_y, grid_geom_p -> n_x);
      
       /* Calculate array scale factors.  For dose matrices these are 
	  all positive */
       grid_geom_p -> trans.transform[0][0] =                 /* x scale */
	   grid_geom_p -> x_size / ( (small_float) (grid_geom_p -> n_x) - 1.0);
       grid_geom_p -> trans.transform[1][1] =                 /* y scale */
	   grid_geom_p -> y_size / ( (small_float) (grid_geom_p -> n_y) - 1.0);
       grid_geom_p -> trans.transform[2][2] =                 /* z scale */
	   grid_geom_p -> z_size / ( (small_float) (grid_geom_p -> n_z) - 1.0); 
   }   /* end GRID_GEOM */

   else if (rtpt_class(current_class, RTPT_GRID_VALUES)) {

       printf("    Entering get_object branch for %s\n", current_class);

       obj_p -> set_element_p = 
	   (rtpt_grid_values_t *) malloc(sizeof(rtpt_grid_values_t));
       grid_values_p = obj_p -> set_element_p;
       grid_values_p -> obj_id.type = RTPT_GRID_VALUES;

       /* Value of this grid attribute was intended to match value of 
	  name attribute in corresponding Grid Geometry object.  I don't 
	  think its needed anymore --- can only be one of each in each plan. */
       slen = MAXLINE; 			/* Safer - was strlen(no_name) + 1; */
       grid_values_p -> grid  = (rtpt_string_t) malloc(slen);
       strcpy(grid_values_p -> grid, no_name); /* This seems safest */

       grid_values_p -> values = NULL;

       do {
	   fstatus = find_next_key(fp, current_label, TRUE);
	   if (fstatus == EOF) {
	       return RTPT_ST_FAIL; /* Reached EOFscanning inside object */
	   }
	   
	   /* Read in all the slots */

	   printf("     Entering get_object branch for class %s, label %s\n", 
		  current_class, current_label);

	   if (strcmp(current_label, "GRID") == 0) {

/***************************************************************************

In Prism files the dose arrays are just Lisp 3-D arrays as written out by Lisp;
there are no  preceding element counts.  We have to read all the elements into
a linked list of (sufficiently large) row buffers first, counting as we go;
then, allocate a new array just large enough to hold them all. 

Here is a fragment of a Prism input file showing how array are stored.  This 
array has columns 0..20, and each plane has rows 0..3.

  PRISM:GRID  #3A(((0.000 0.001 0.002 0.003 0.004 0.005 
0.006 0.007 0.008 0.009 0.010 0.011 0.012 0.013 0.014 0.015 
0.016 0.017 0.018 0.019 0.020) 
(0.100 0.101 0.102 0.103 0.104 0.105 0.106 0.107 0.108 0.109 
0.110 0.111 0.112 0.113 0.114 0.115 0.116 0.117 0.118 0.119
0.120) 
(0.200 0.201 0.202 0.203 0.204 0.205 0.206 0.207 0.208 0.209 
0.210 0.211 0.212 0.213 0.214 0.215 0.216 0.217 0.218 0.219
0.220) 
(0.300 0.301 0.302 0.303 0.304 0.305 0.306 0.307 0.308 0.309 
0.310 0.311 0.312 0.313 0.314 0.315 0.316 0.317 0.318 0.319
0.320))
	.
	. 	... many lines omitted ...
	.
(2.300 2.301 2.302 2.303 2.304 2.305 2.306 2.307 2.308 2.309 
2.310 2.311 2.312 2.313 2.314 2.315 2.316 2.317 2.318 2.319
2.320)))

At the beginning of the list we find "#3A(((", then a row of any number of
array elements in %f form, then ")" at the end of the row.  All subsequent rows
have the same number of elements.  After any number of rows, we reach the end
of a row which is also the end of a plane, marked by "))".  After any number of
planes we reach the end of the array, indicated by ")))".

It isn't necessary that a line break follow each row, files may have:
.... ) ( .....  in them

Here is the pseudocode for reading the array:

	read past initial "#3A" marker

	(Now positioned at start of array)
	read past initial "(" marking start of whole array
	
	loop over whole array, all planes

	   (Now positioned at start of plane)
	   read past initial "(" marking start of plane

	   loop over one plane, all rows 

		allocate new row buffer and hook into linked list.

		(Now positioned at start of row)
		read past initial "(" marking start of row

		   loop over single row
		     read one value from file and assign to proper element 
			in row buffer, based on index calculated from 
			column counter
		     increment column counter
		   when read fails, done with row.

		   case n of parens after last array element
			1: end of row
			   decrement column counter 
			     and assign to column size
			2: end of plane
			   assign row loop counter to row count
			3: end of array
			   assign plane loop counter to plane count

	   end of loop over plane 

        end of loop over array

        ******************************

	When all finished, allocate just enough space for entire 3d array
	and copy all the row buffer contents into it.

        THIS IS THE STEP WHERE WE ACCOUNT FOR DIFFERENT INDEXING
        CONVENTIONS IN PRISM AND RTPT -- Jon Jacky, 14-Dec-1993

        *******************************

	Free all row buffers

******************************************************************************/

	   /* Beginning array - should be "#3A" at start */
           fstatus = fscanf(fp, "%3s", &ch4); /* read first 3 nonblank ch */
	   if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	   if (strcmp(ch4,"#3A") != 0) return RTPT_ST_FAIL; /* bad fl */

		/* On first turn through row loop, 
				allocate largest possible row buffer */
		row_size = MAX_ELEMENTS;

		rows_p = NULL; /* initialize linked list of rows */

                /* Positioned at start of array */ 
                fstatus = fscanf(fp, "%1s", &parens); 
			/* read past initial "(", don't skip spaces */
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		if (strcmp(parens,"(") != 0) return RTPT_ST_FAIL; /* bad file */

		/* Loop to read entire array */
                end_array = FALSE;
                for (iplane = 0; !end_array; iplane++) {

                 /* Positioned at start of plane */ 
                 end_plane = FALSE; 
                 fstatus = fscanf(fp, "%1s", &parens); 
			/* read past initial "(", don't skip spaces */
		 if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		 if (strcmp(parens,"(") != 0) return RTPT_ST_FAIL; /* bad file */

		 /* Loop to read one plane */
                 for (irow = 0; 
		       !end_array && !end_plane && (irow < MAX_ELEMENTS); 
                       irow++) {

		 /* Allocate next row buffer */
                 tmp_p = alloc_set();
		 tmp_p -> next_p = rows_p;
		 rows_p = tmp_p;
		 rows_p -> set_element_p = 
		    (small_float *) malloc(row_size * sizeof(small_float));
                 if ((tmp_p -> set_element_p) == NULL) 
		   return RTPT_ST_OUTOFMEM; /* A big chunk, so check failure */
		 row_p = rows_p -> set_element_p;

		  /* Positioned at start of row */
                  fstatus = 1; /* Needed to init. for loop */
                  fstatus = fscanf(fp, "%1s", parens); 
			/* read past initial "(", don't skip spaces */
		  if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		  if (strcmp(parens,"(") != 0) return RTPT_ST_FAIL; /* bad file */

                  /* Loop to read one row */ 
		  for (icol = 0; 
		           (fstatus == 1) && (icol < MAX_ELEMENTS); icol++) {
                    fstatus = fscanf(fp," %f", row_p + icol);
                    } /* end "for icol" loop, end of row */
		  --icol; /* Had to go one too far */
		
		/* At this point icol holds the
		   actual number of elements in the row, including element
		   zero.  So, if columns are 0..20, then icol = 21.  That's
		   because in the body of the last trip through this loop, 
		   icol is counting the element that *would* be read if 
		   the read was successful - but instead we hit parens instead
		   of another number.  That's why we need --icol.  */

                  /* At end of row, check number of parens */ 
		 fstatus = fscanf(fp, "%s", &parens);

		  /* Note distinction here between highest array indices 
			nx, etc. and number of array elements n_x, etc.
		     Array indices go 0..nx (etc.), so number of elements
		     are nx + 1 (etc.).  See TR-91-1 p. 31. */

		  /* One ")" means end of row */
		 if (strcmp(parens, ")") == 0) { 
		    row_size = icol; /* number of elements in row */
		    nx = icol - 1;   /* so 0..nx is number of elements in row*/
		    }

                 /* Two parens "))" means end of plane */		 
		 else if (strcmp(parens, "))") == 0) { 
		    ny = irow;
                    end_plane = TRUE; 
	 	    }

		 /* Three parens ")))" means end of array */
		 else if (strcmp(parens, ")))") == 0) { 
		    nz = iplane;
		    end_array = TRUE; 
	 	    }

		} /* end "for irow" loop, reading a plane */
               } /* end for "for iplane" loop, reading array */
             
printf("     Grid values reads %d planes, %d rows, %d cols\n", 
		 nz + 1, ny + 1, nx + 1);

	} /* end "GRID" */
                    
      } /* end do-while find_next_key... body */
      while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));

/*****   DEBUG - Write out the rows in the linked list to the screen ********
	    tmp_p = rows_p; 
	    while (tmp_p != NULL) {
		row_p = tmp_p -> set_element_p;
		printf("In row buffer: row[0] = %.3f, row[%d] = %.3f\n",
       			*row_p, nx, *(row_p + nx));
		tmp_p = tmp_p -> next_p;
		}
*****************************************************************************/

	  /*
	   * THIS IS THE STEP WHERE WE ACCOUNT FOR DIFFERENT INDEXING
	   * CONVENTIONS IN PRISM AND RTPT -- Jon Jacky, 14-Dec-1993
	   * 
	   * Here the columns in the *input file* become planes in
	   * the *internal array*.
	   * 
	   * In the following code, iplane, irow, icol, nx, ny, nz all
	   * refer to arrangement in *input file*.
	   *
	   * We distinguish these from aplane, arow, acol, nax, nay, naz
	   * in *internal array*  We have nx = naz   ny = nay  nz = nax
	   * Size of array plane is (nax + 1)*(nay + 1).  And,
	   *
	   * array[icol, irow, iplane] = input[iplane, irow, icol]
	   *   
	   */

	    /* Allocate array of just the right size */
	    array_p = (small_float *) 
		malloc((nx + 1)*(ny + 1)*(nz + 1) * sizeof(small_float));
            if (array_p == NULL) return RTPT_ST_OUTOFMEM; 
					/* A big chunk, so check failure */

	    /* Copy the linked list of array elements into one array.
	 	Remember list of rows is in reverse order; so count
		planes, rows, down; columns are in ascending order. */
	    tmp_p = rows_p; 
	    row_p = tmp_p -> set_element_p;

	    for (iplane = nz; iplane >= 0; iplane--) {
	      for (irow = ny; irow >= 0; irow-- ) {
		for (icol = 0; icol <= nx; icol++) {
		    *(array_p + icol*(nz+1)*(ny+1) + irow*(nz+1) + iplane)
			= *(row_p + icol);
		} /* end for icol */

		tmp_p = tmp_p -> next_p; /* point at next row buffer */
	        if (tmp_p != NULL) row_p = tmp_p -> set_element_p;

	       } /* end for irow */
	     } /* end for iplane */

	     grid_values_p -> values = array_p;

 
	/* Free up temp storage used by GRID_VALUES */
        /* printf("     About to free row buffers\n"); */

	while (rows_p != NULL) {
		tmp_p = rows_p;
		rows_p = rows_p -> next_p;
		free(tmp_p -> set_element_p);
		free(tmp_p);
		}

   } /* end GRID_VALUES */

   /* Do all the image classes in one case brach - they have almost all
	the same slots, and the other slots don't conflict or overlap */
   else if (rtpt_class(current_class, RTPT_IMAGE)
	|| rtpt_class(current_class, RTPT_IMAGE_2D)
	|| rtpt_class(current_class, RTPT_IMAGE_3D)) {

   printf("    Entering get_object branch for %s\n", current_class);

       if rtpt_class(current_class, RTPT_IMAGE) { 
      	obj_p -> set_element_p = 
		(rtpt_image_t *) malloc(sizeof(rtpt_image_t));
	image_p = obj_p -> set_element_p;
	}
       else if rtpt_class(current_class, RTPT_IMAGE_2D) { 
      	obj_p -> set_element_p = 
		(rtpt_image_2d_t *) malloc(sizeof(rtpt_image_2d_t));
	image_2d_p = obj_p -> set_element_p;
	image_2d_p -> obj_id.type = RTPT_IMAGE_2D;
	image_2d_p -> thickness = 1.0; /* 1 cm. slice - default */

	image_p = &(image_2d_p -> image);

        /* Initialize 2d image orientation for transverse */
	image_2d_p -> x_orient[0] = 1.0;
	image_2d_p -> x_orient[1] = 0.0;
	image_2d_p -> x_orient[2] = 0.0;
	image_2d_p -> x_orient[3] = 1.0;
	image_2d_p -> y_orient[0] = 0.0;
	image_2d_p -> y_orient[1] = -1.0;
	image_2d_p -> y_orient[2] = 0.0;
	image_2d_p -> y_orient[3] = 1.0;

	image_2d_p -> pix_per_cm = 10.0; /* Unrealistically small */

	}
       else if rtpt_class(current_class, RTPT_IMAGE_3D) { 
      	obj_p -> set_element_p = 
		(rtpt_image_3d_t *) malloc(sizeof(rtpt_image_3d_t));
	image_3d_p = obj_p -> set_element_p;
	image_3d_p -> obj_id.type = RTPT_IMAGE_3D;
	image_p = &(image_3d_p -> image);
	}

      /* Initialize slots in Image */
      image_p -> obj_id.type = RTPT_IMAGE;
      image_p -> pixtype = RTPT_PIXTYPE_MEDIUM_UINT; 
			/* All Prism pixels are 16 bit unsigned ... */
			/* ...what does that cast to in VAX/VMS ?   */
      image_p -> range_low = 0; /* Not stored in Prism files; always 0 */
      image_p -> range_high = 4095; /* A good default for CT */
      image_p -> type = RTPT_UNKNOWN_E; /* unless otherwise noted */

      /* Initialize all the strings */
      slen = MAXLINE; 			/* Safer - was strlen(no_name) + 1; */
      image_p -> id = (rtpt_string_t) malloc(slen);
      strcpy(image_p -> id, no_name); /* This seems safest */
      image_p -> descrip = (rtpt_string_t) malloc(slen);
      strcpy(image_p -> descrip, no_name); /* This seems safest */
      image_p -> date = (rtpt_string_t) malloc(slen);
      strcpy(image_p -> date, no_name); /* This seems safest */
      image_p -> time = (rtpt_string_t) malloc(slen);
      strcpy(image_p -> time, no_name); /* This seems safest */
      image_p -> scanner = (rtpt_string_t) malloc(slen);
      strcpy(image_p -> scanner, no_name); /* This seems safest */
      image_p -> units = (rtpt_string_t) malloc(slen);
      strcpy(image_p -> units, no_name); /* This seems safest */
      image_p -> filename = (rtpt_string_t) malloc(slen);
      strcpy(image_p -> filename, no_name); /* This seems safest */
      image_p -> hosp_name = (rtpt_string_t) malloc(slen);
      strcpy(image_p -> hosp_name, no_name); /* This seems safest */

      /* Initialize the geometry */
      grid_geom_p = &(image_p -> grid);
      grid_geom_p -> obj_id.type = RTPT_GRID_GEOM;
      slen = MAXLINE; 			/* Safer - was strlen(no_name) + 1; */
      grid_geom_p -> name = (rtpt_string_t) malloc(slen);
      strcpy(grid_geom_p -> name, no_name); /* This seems safest */

      /* Now initialize transform to reasonable defaults, so we'll see
	 something even if scale factors not found in input file.

	 Prism coord system x,y,z are always parallel to patient system so 
	 off-diagonal elements are always 0.  However, image origin in Prism
	 is back upper left corner, not front lower left corner, so sign of 
	 both y and z are negative in order to transform from image to patient
	 coordinates.

	 Scale factors are in units of cm per pixel (or voxel or sample) */

      grid_geom_p -> x_size = 40.96; /* Default 512 pix * 0.08 cm/pix */
      grid_geom_p -> y_size = 40.96;
      grid_geom_p -> z_size = 30.0;   /* Default 30 slice * 1.0 cm/slice */
      grid_geom_p -> n_x = PRISM_DIM; /* All Prism images are same size */
      grid_geom_p -> n_y = PRISM_DIM; /* PRISM_DIM x PRISM_DIM 		*/
      grid_geom_p -> n_z = 1;   /* This stays 1 for 2D images */

      for (i = 0; i <= 3; i++) {
	for (j = 0; j <= 3; j++) {
	   grid_geom_p -> trans.transform[i][j] = 0.0;
	}
      }
      for (i = 0; i <= 3; i++) {
	   grid_geom_p -> trans.transform[i][i] = 1.0;
      }

      grid_geom_p -> trans.transform[0][0] = 0.08; /* x scale 12.5 pix/cm */
      grid_geom_p -> trans.transform[1][1] = -0.08; /* y scale 12.5 pix/cm */
      grid_geom_p -> trans.transform[2][2] = -1.0; /* z scale - 1 cm spacing */

      do {
	fstatus = find_next_key(fp, current_label, TRUE);
	if (fstatus == EOF) {
	   return RTPT_ST_FAIL; /* Reached EOF while scanning inside object */
	   }

   printf("     find_next_key just encountered %s\n", current_label);

	/* Read in all the strings */

	/* ID is an integer (without "" around it) in Prism, 
		but a string in RTPT */
	if (strcmp(current_label, "ID") == 0) {
		fstatus = fscanf(fp, "%s", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		image_p -> id = (rtpt_string_t) malloc(slen);
		strcpy(image_p -> id, temp_s);
		} 

	if (strcmp(current_label, "DESCRIPTION") == 0) {
		fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		image_p -> descrip = (rtpt_string_t) malloc(slen);
		strcpy(image_p -> descrip, temp_s);
		} 

	if (strcmp(current_label, "ACQ-DATE") == 0) {
		fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		image_p -> date = (rtpt_string_t) malloc(slen);
		strcpy(image_p -> date, temp_s);
		} 

	if (strcmp(current_label, "ACQ-TIME") == 0) {
		fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		image_p -> time = (rtpt_string_t) malloc(slen);
		strcpy(image_p -> time, temp_s);
		} 

	if (strcmp(current_label, "SCANNER-TYPE") == 0) {
		fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		image_p -> scanner = (rtpt_string_t) malloc(slen);
		strcpy(image_p -> scanner, temp_s);
		} 

	if (strcmp(current_label, "HOSP-NAME") == 0) {
		fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		image_p -> hosp_name = (rtpt_string_t) malloc(slen);
		strcpy(image_p -> hosp_name, temp_s);
		} 

	if (strcmp(current_label, "UNITS") == 0) {
		fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
		/* Skip any number of blanks and quotes, 
		   then read in all the characters up to the next quotes */

		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		if (strcmp(temp_s, "H - 1024") == 0) {
		   slen = strlen(hounsfield) + 1;
		   image_p -> units = (rtpt_string_t) malloc(slen);
		   strcpy(image_p -> units, hounsfield); /* seems safest */
		   } else {
		   image_p -> units = (rtpt_string_t) malloc(slen);
		   strcpy(image_p -> units, temp_s);
		   } 
		}

     	if (strcmp(current_label, "IMG-TYPE") == 0) {
		fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		if (strcmp(temp_s, "X-ray CT") == 0) {
		   image_p -> type = RTPT_IMTYPE_CT; 
		   } else {
		   image_p -> type = RTPT_UNKNOWN_E; /* more kinds later? */
		   } 
		}

     	if (strcmp(current_label, "RANGE") == 0) {
		fstatus = fscanf(fp," %d", &(image_p -> range_high));
		} /* range_low remains at 0 */

	/* Read in the geometry - explicitly cast values to large_float; jmu */
     	if (strcmp(current_label, "ORIGIN") == 0) {
                float tmp_0, tmp_1, tmp_2;

		fstatus = fscanf(fp," #(%f %f %f", &tmp_0, &tmp_1, &tmp_2);
		grid_geom_p -> trans.transform[0][3] = (large_float) tmp_0;
		grid_geom_p -> trans.transform[1][3] = (large_float) tmp_1;
		grid_geom_p -> trans.transform[2][3] = (large_float) tmp_2;
		}

	if (strcmp(current_label, "SIZE") == 0) {
		fstatus = fscanf(fp," (%f %f %f)", &(grid_geom_p -> x_size), 
			&(grid_geom_p -> y_size), &(grid_geom_p -> z_size));
		}

	/* This occurs only in Image 2D */
	if (strcmp(current_label, "THICKNESS") == 0) {
		fstatus = fscanf(fp, "%f", &(image_2d_p -> thickness));
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		grid_geom_p -> z_size = image_2d_p -> thickness;
		} 

	/* These occur only in Image 2D */

     	if (strcmp(current_label, "X-ORIENT") == 0) {
		fstatus = fscanf(fp," #(%f %f %f %f", 
		&(image_2d_p -> x_orient[0]),
		&(image_2d_p -> x_orient[1]),
		&(image_2d_p -> x_orient[2]),
		&(image_2d_p -> x_orient[3]));
		}

     	if (strcmp(current_label, "Y-ORIENT") == 0) {
		fstatus = fscanf(fp," #(%f %f %f %f", 
		&(image_2d_p -> y_orient[0]),
		&(image_2d_p -> y_orient[1]),
		&(image_2d_p -> y_orient[2]),
		&(image_2d_p -> y_orient[3]));
		}

 	if (strcmp(current_label, "PIX-PER-CM") == 0) {
		fstatus = fscanf(fp, "%f", &(image_2d_p -> pix_per_cm));
		} 

 	if (strcmp(current_label, "PIXELS") == 0) {

		/* read filename, skip inital blanks, parens, quotes */
		fstatus = fscanf(fp, "%*[ (\"]%[^\"]", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		image_p -> filename = (rtpt_string_t) malloc(slen);
		strcpy(image_p -> filename, temp_s);


		} 

	/* This occurs only in Image 3D */
	if (strcmp(current_label, "VOXELS") == 0) {

		/* read filename, skip inital blanks, parens, quotes */
		fstatus = fscanf(fp, "%*[ (\"]%[^\"]", temp_s);

/* printf("      fscanf just read |%s|, status = %d\n", temp_s, fstatus); */

		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		image_p -> filename = (rtpt_string_t) malloc(slen);
		strcpy(image_p -> filename, temp_s);

		/* read n of planes only - in Prism n_x, n_y must be PRISM_DIM 
		   Be sure to skip over quotes and spaces */

                /* Read value in to temp variable and explicitly cast to 
                   type medium_uint  jmu */
    
                { int temp;

  		  fstatus = fscanf(fp, "%*[\" ]%d", &temp);
                  grid_geom_p -> n_z = (medium_uint) temp;
                }

/* printf("      fscanf just read n_z = %d, status = %d\n", 
					grid_geom_p -> n_z, fstatus); */

		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */

		} 

      } /* end do-while body */
      while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));

      /* Calculate image array origin and scale factors.
	 Note sign reversal in y only - image system y coordinate is 
	 opposite direction from patient y direction - x and z are same */

      printf("     calculate image transform matrix\n");
      grid_geom_p -> trans.transform[0][0] =                   /* x scale */
		grid_geom_p -> x_size / (small_float) grid_geom_p -> n_x;
      grid_geom_p -> trans.transform[1][1] =                   /* y scale */
		-(grid_geom_p -> y_size / (small_float) grid_geom_p -> n_y);
      grid_geom_p -> trans.transform[2][2] =                   /* z scale */
		grid_geom_p -> z_size / (small_float) grid_geom_p -> n_z;

      /* Look for binary image file */
      if (!(imf = fopen(image_p->filename, "r"))) {
	    fprintf(stderr, "     can't open binary image file %s\n", 
		    image_p->filename);
      } else {
	  fclose(imf);
	  if rtpt_class(current_class, RTPT_IMAGE_2D) { 
	      printf("     allocate memory for 2d image array\n");
	      image_2d_p -> pixels = 
		  (medium_uint *) 
		      malloc(grid_geom_p->n_x * grid_geom_p->n_y * 
			     sizeof(medium_uint));
              if ((image_2d_p -> pixels) == NULL) return RTPT_ST_OUTOFMEM;
              printf("     read 2d binary image file %s\n", image_p->filename);
              read_bin_array_2(image_p->filename, grid_geom_p->n_x, 
			       grid_geom_p->n_y, image_2d_p->pixels);
          }
          if rtpt_class(current_class, RTPT_IMAGE_3D) { 
	      printf("     allocate memory for 3d image array\n");
	      image_3d_p->voxels = 
		  (medium_uint *) malloc 
		      (grid_geom_p->n_x * grid_geom_p->n_y 
		       * grid_geom_p->n_z * sizeof(medium_uint));
              if ((image_3d_p->voxels) == NULL) return RTPT_ST_OUTOFMEM;
              printf("     read 3d binary image file %s\n", 
		     image_p->filename);
              read_bin_array_3(image_p->filename, grid_geom_p->n_x, 
			       grid_geom_p->n_y, grid_geom_p->n_z, 
			       image_3d_p->voxels);
          } /* end if Image 3D */
        } /* else if image file could be opened */
	printf("     about to exit image branch\n", image_p -> filename);
      } /* end RTPT_IMAGE, RTPT_IMAGE_2D, RTPT_IMAGE_3D */

   /* Do all the beam classes in one case brach - they have almost all
	the same slots.  The wrinkle is, RTPT and Prism organization aren't
	the same.  In RTPT, BEAM is the base class and S_BEAM etc. are
	derived classes.  In Prism, there is just one BEAM class; each 
	BEAM contains one instance of COLLIMATOR, of which there are 
	several different classes.  We don't know which RTPT class we're
	working with until we reach the COLLIMATOR slot in the Prism object. 

So, we have a special case here because the RTPT base class all of its derived
classes are  labelled in the Prism file by the *same* keyword.   They can only
be distinguished by their contents.  This procedure therefore picks
up any possible candidate, and later discards those that don't match.

*/

   else if (rtpt_class(current_class, RTPT_BEAM)
 	|| rtpt_class(current_class, RTPT_S_BEAM)
	|| rtpt_class(current_class, RTPT_C_BEAM)
	|| rtpt_class(current_class, RTPT_VJ_BEAM)
	|| rtpt_class(current_class, RTPT_M_BEAM)) {

   printf("    Entering get_object branch for %s\n", current_class);

      /* First, allocate the base class part.  We'll copy its contents into 
	the returned data structure when we find out what kind of collimator 
	we've got. */
	temp_beam_p = (rtpt_beam_t *) malloc(sizeof(rtpt_beam_t));
	
      /* Initialize slots in Beam. First, the ID */
      temp_beam_p -> obj_id.type = RTPT_BEAM;

      /* Next, all the strings */
      slen = MAXLINE; 			/* Safer - was strlen(no_name) + 1; */
      temp_beam_p -> name = (rtpt_string_t) malloc(slen);
      strcpy(temp_beam_p -> name, no_name); /* This seems safest */
      temp_beam_p -> delivery = (rtpt_string_t) malloc(slen);
      strcpy(temp_beam_p -> delivery, no_name); /* This seems safest */
      temp_beam_p -> wedge = (rtpt_string_t) malloc(slen);
      strcpy(temp_beam_p -> wedge, no_name); /* This seems safest */

      /* Hidden - for Prism use only */
      temp_beam_p -> display_color = (rtpt_string_t) malloc(slen);
      strcpy(temp_beam_p -> display_color, "SLIK:RED"); 

      /* Next, all the numbers */
      temp_beam_p -> units = 100.0;		/* This is the Prism default */
      temp_beam_p -> lateral = 0.0;
      temp_beam_p -> longit = 0.0;
      temp_beam_p -> height = 0.0;
      temp_beam_p -> c_angle = 0.0;
      temp_beam_p -> g_angle = 0.0;
      temp_beam_p -> coll_angle = 0.0;
      temp_beam_p -> orientation = 0.0;

      /* Hidden - for Prism use only */
      for (i = 0; i < 3; i++) temp_beam_p -> table_position[i] = 0.0;
      temp_beam_p -> table_position[3] = 1.0;
      temp_beam_p -> arc_size = 0.0;
      temp_beam_p -> n_treatments = 1;

      /* Finally, the pointer */
      temp_beam_p -> blocks_p = alloc_set();

      /* Now scan through the file and read the data */
      do {
	fstatus = find_next_key(fp, current_label, TRUE);
	if (fstatus == EOF) {
	   return RTPT_ST_FAIL; /* Reached EOF while scanning inside object */
	   }

   printf("     find_next_key just encountered %s\n", current_label);

	if (strcmp(current_label, "NAME") == 0) {
	   fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
	   if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	   slen = strlen(temp_s) + 1;
	   temp_beam_p -> name = (rtpt_string_t) malloc(slen);
	   strcpy(temp_beam_p -> name, temp_s);
	   } 

	/* Beam delivery system is now a string (with "" around it) in Prism, 
		just as in RTPT --- it's no longer a symbol */
	if (strcmp(current_label, "MACHINE") == 0) {
		fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		temp_beam_p -> delivery = (rtpt_string_t) malloc(slen);
		strcpy(temp_beam_p -> delivery, temp_s);
		} 

     	if (strcmp(current_label, "MONITOR-UNITS") == 0) {
		fstatus = fscanf(fp,"%f", &(temp_beam_p -> units));
		} 

     	if (strcmp(current_label, "COUCH-LATERAL") == 0) {
		fstatus = fscanf(fp,"%f", &(temp_beam_p -> lateral));
		} 

     	if (strcmp(current_label, "COUCH-LONGITUDINAL") == 0) {
		fstatus = fscanf(fp,"%f", &(temp_beam_p -> longit));
		} 

     	if (strcmp(current_label, "COUCH-HEIGHT") == 0) {
		fstatus = fscanf(fp,"%f", &(temp_beam_p -> height));
		} 

     	if (strcmp(current_label, "COUCH-ANGLE") == 0) {
		fstatus = fscanf(fp,"%f", &(temp_beam_p -> c_angle));
		} 

     	if (strcmp(current_label, "GANTRY-ANGLE") == 0) {
		fstatus = fscanf(fp,"%f", &(temp_beam_p -> g_angle));
		} 

     	if (strcmp(current_label, "COLLIMATOR-ANGLE") == 0) {
		fstatus = fscanf(fp,"%f", &(temp_beam_p -> coll_angle));
		} 

	/* Here are the "hidden" fields that might be used by Prism */
	if (strcmp(current_label, "DISPLAY-COLOR") == 0) {
		fstatus = fscanf(fp, "%s", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		slen = strlen(temp_s) + 1;
		temp_beam_p -> display_color = (rtpt_string_t) malloc(slen);
		strcpy(temp_beam_p -> display_color, temp_s);
		} 

     	if (strcmp(current_label, "ARC-SIZE") == 0) {
		fstatus = fscanf(fp,"%f", &(temp_beam_p -> arc_size));
		} 

        /* 
          We read n_treatments into a temporary variable and explicitly 
          cast to a small_uint, which is the type of n_treatments.  jmu
        */

        if (strcmp(current_label, "N-TREATMENTS") == 0) {
                int temp;

		fstatus = fscanf(fp,"%d", &temp);
                temp_beam_p -> n_treatments = (small_uint) temp;
		}  

     	if (strcmp(current_label, "TABLE-POSITION") == 0) {
		fstatus = fscanf(fp," #(%f %f %f", 
			&(temp_beam_p -> table_position[0]),
			&(temp_beam_p -> table_position[1]),
			&(temp_beam_p -> table_position[2]));
		}

	/* Blocks can be in any kind of beam - they are contained objects.
	   This code base on handling of set of CONTOURS in VOLUME */
     	if (strcmp(current_label, "BLOCKS") == 0) {

	    /* Allocate root node for this set of objects */
	    temp_beam_p -> blocks_p = 
		(rtpt_set_t *) 	malloc(sizeof(rtpt_set_t));
            temp_beam_p -> blocks_p -> obj_id.type = RTPT_SET;
            temp_beam_p -> blocks_p -> next_p = NULL;
	   temp_beam_p -> blocks_p -> set_element_p = NULL;

	   /* Indirect recursive call to get the constituent blocks */
           gstatus = get_all_objects(fp, RTPT_BLOCK, &contained_objects, 
			&tail, TRUE, &num_blocks);
	   if (gstatus != RTPT_ST_OK) return gstatus; /* get_all_... failed */
	   printf("get_all_objects returned %d blocks in BEAM\n",
			num_blocks);
           /* There might not be any blocks */
           if (num_blocks > 0) {
	       tail -> next_p = NULL; 
	       temp_beam_p -> blocks_p -> next_p = contained_objects;
	   }
           else temp_beam_p -> blocks_p = NULL;
        }

        /*  Prism Wedges are objects contained in beams, much like collims.
	    However in RTPT they are just slots in beam object */
     	if (strcmp(current_label, "WEDGE") == 0) {
	    /* Now loop just as within get_object */
	    do {
		fstatus = find_next_key(fp, current_label, TRUE);
                if (fstatus == EOF) {
                    return RTPT_ST_FAIL; /* Reached EOF */
	        }
                printf("       find_next_key just encountered %s\n",
                       current_label);
                
                /* Wedge ID is an integer (without "" around it) in Prism, 
		   but a string in RTPT */
	        if (strcmp(current_label, "ID") == 0) {
                    fstatus = fscanf(fp, "%s", temp_s);
		    if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		    slen = strlen(temp_s) + 1;
		    temp_beam_p -> wedge = (rtpt_string_t) malloc(slen);
		    strcpy(temp_beam_p -> wedge, temp_s);
		} 
     	        if (strcmp(current_label, "ROTATION") == 0) {
		    fstatus = fscanf(fp,"%f", &(temp_beam_p -> orientation));
		} 

             } /* end do-while body for WEDGE  */
             while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));
             /* Remember current_label now holds :END - we don't want to fall 
		out of whole get_object loop, so */
             strcpy(current_label, no_name);
	} /* end if WEDGE ... */

	/* Here comes the hard part ... */
     	if (strcmp(current_label, "COLLIMATOR") == 0) {

	/* Here's where we learn which derived class of RTPT beam
	   we have, so we can finally create the returned data structure.

	   Or, if we are looking for a particular derived class (a particular
	   kind of collimator) and this beam isn't an example of that,
	   we must discard this object.

	   In the Prism file, the collimator is a single embedded object
	   represented as in this sample: 

		  ...
		  PRISM::ARC-SIZE  0.0
		  PRISM::COLLIMATOR  
		    PRISM::SYMMETRIC-JAW-COLL
		      PRISM::X  12.00
		      PRISM::Y  11.90
		    :END
		  PRISM::COLLIMATOR-ANGLE  0.0
		  ...

	   Rather than defining RTPT-style classes analogous to the 
	   Prism collimator classes and then calling our get_object,
	   seems easier just to hard-code it all in-line here. */

	/* We know the collimator class has to appear first */

	fstatus = find_next_key(fp, current_label, TRUE);
	if (fstatus == EOF) {
	   return RTPT_ST_FAIL; /* Reached EOF while scanning inside object */
	   }

   printf("       find_next_key just encountered %s\n", current_label);


	if (strcmp(current_label, "SYMMETRIC-JAW-COLL") == 0) {
	this_class = RTPT_S_BEAM;
	s_beam_p = (rtpt_s_beam_t *) malloc(sizeof(rtpt_s_beam_t));
	s_beam_p -> obj_id.type = RTPT_S_BEAM;
	s_beam_p -> coll_x = 10.0;
	s_beam_p -> coll_y = 10.0;
	beam_p = &(s_beam_p -> beam); 
	}

	else if (strcmp(current_label, "COMBINATION-COLL") == 0) {
	this_class = RTPT_C_BEAM;
	c_beam_p = (rtpt_c_beam_t *) malloc(sizeof(rtpt_c_beam_t));
	c_beam_p -> obj_id.type = RTPT_C_BEAM;
	c_beam_p -> coll_sup = 5.0;
	c_beam_p -> coll_inf = 5.0;
	c_beam_p -> coll_width = 10.0;
	beam_p = &(c_beam_p -> beam); 
	}

	else if (strcmp(current_label, "VARIABLE-JAW-COLL") == 0) {
	this_class = RTPT_VJ_BEAM;
	vj_beam_p = (rtpt_vj_beam_t *) malloc(sizeof(rtpt_vj_beam_t));
	vj_beam_p -> obj_id.type = RTPT_VJ_BEAM;
	vj_beam_p -> coll_supx = 5.0;
	vj_beam_p -> coll_infx = 5.0;
	vj_beam_p -> coll_supy = 5.0;
	vj_beam_p -> coll_infy = 5.0;
	beam_p = &(vj_beam_p -> beam); 
	}

	else if (strcmp(current_label, "MULTILEAF-COLL") == 0) {
	this_class = RTPT_M_BEAM;
	m_beam_p = (rtpt_m_beam_t *) malloc(sizeof(rtpt_m_beam_t));
	m_beam_p -> obj_id.type = RTPT_M_BEAM;
        m_beam_p -> nsegs = 0;
	for (ileaf = 0; ileaf <= RTPT_MAXN_LEAFPAIRS; ileaf++) {
		m_beam_p -> leaf_sups[ileaf] = 0.0;
		m_beam_p -> leaf_infs[ileaf] = 0.0;
		} /* end for ileaf - this one isn't 10 x 10 */
	beam_p = &(m_beam_p -> beam); 
	}

 	/* Now loop just as within get_object */
        do {
	   fstatus = find_next_key(fp, current_label, TRUE);
	   if (fstatus == EOF) {
	      return RTPT_ST_FAIL; /* Reached EOF while scanning in object */
	      }

   printf("       find_next_key just encountered %s\n",
	  current_label);

	   /* This is in S_BEAM only */
     	   if (strcmp(current_label, "Y") == 0) {
		fstatus = fscanf(fp,"%f", &(s_beam_p -> coll_y));
		} 

	   /* These are in VJ_BEAM only */
     	   if (strcmp(current_label, "X-SUP") == 0) {
		fstatus = fscanf(fp,"%f", &(vj_beam_p -> coll_supx));
		} 
     	   if (strcmp(current_label, "X-INF") == 0) {
		fstatus = fscanf(fp,"%f", &(vj_beam_p -> coll_infx));
		} 

	   /* This is in S_BEAM and C_BEAM */
     	   if (strcmp(current_label, "X") == 0) {
		fstatus = fscanf(fp,"%f", &coll_x);
		} 

	   /* These are in C_BEAM and VJ_BEAM */
     	   if (strcmp(current_label, "Y-SUP") == 0) {
		fstatus = fscanf(fp,"%f", &coll_supy);
		} 
     	   if (strcmp(current_label, "Y-INF") == 0) {
		fstatus = fscanf(fp,"%f", &coll_infy);
		} 

           /* This is in M_BEAM only */
           if  (strcmp(current_label, "VERTICES") == 0) {
		fstatus = fscanf(fp, "%1s", ch); /* read first nonwhite char */
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */

		if (strcmp(ch,"(") == 0) { /* start of list of coords */
		    fstatus = 2; /* Needed to init. for loop */
		    for (iv = 0; (fstatus == 2) && (iv < MAX_VERTICES); iv++) {
			fstatus = fscanf(fp," (%f %f)", 
					 &(vbuf[iv].x), &(vbuf[iv].y));
			/* printf("%d (%.3f %.3f) \n", 
			   iv, vbuf[iv].x, vbuf[iv].y); */
		    }
		    nsegs = --iv; 
		    /* had to go one too far */
		    printf("   %d vertices read in\n", nsegs);
		} /* end if "(" at start of list of coords found */
		else nsegs = 0;
	    } /* end if VERTICES */

         } /* end do-while body for collimator object */
         while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));

	 /* Now we've collected all there is for the collimator */
         if rtpt_class(this_class, RTPT_S_BEAM) {
		s_beam_p -> coll_x = coll_x;
		}

         else if rtpt_class(this_class, RTPT_C_BEAM) {
		c_beam_p -> coll_width = coll_x;
		c_beam_p -> coll_inf = coll_infy;
		c_beam_p -> coll_sup = coll_supy;
		}

	else if rtpt_class(this_class, RTPT_VJ_BEAM) {
		vj_beam_p -> coll_infy = coll_infy;
		vj_beam_p -> coll_supy = coll_supy;
		}

        else if rtpt_class(this_class, RTPT_M_BEAM) {
	        m_beam_p -> nsegs = nsegs;
		for (iv = 0; iv < nsegs; iv++) {
                    m_beam_p -> seg[iv].x = vbuf[iv].x;
		    m_beam_p -> seg[iv].y = vbuf[iv].y;
		    } 
	        }

	/* Remember current_label now holds :END - we don't want to fall 
	   out of whole get_object loop, so */

	strcpy(current_label, no_name);

	} /* end if COLLIMATOR ... */

      } /* end do-while body for beams */
      while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));

      /* Now that everything has been collected from the collimator and
	 the beam, if the collimator type matches the requested type,
	 assemble the returned structure.  */

      /* Here's where we decide to return or discard this candidate */
      if (rtpt_class(current_class, RTPT_BEAM)
 	|| rtpt_class(current_class, this_class)) {

	 /* This seems awkward but I couldn't think of an alternative */
	 beam_p -> obj_id.type =  temp_beam_p -> obj_id.type;
	 beam_p -> name =  temp_beam_p -> name;
	 beam_p -> delivery =  temp_beam_p -> delivery;
	 beam_p -> units =  temp_beam_p -> units;
	 beam_p -> lateral =  temp_beam_p -> lateral;
	 beam_p -> longit =  temp_beam_p -> longit;
	 beam_p -> height =  temp_beam_p -> height;
	 beam_p -> c_angle =  temp_beam_p -> c_angle;
	 beam_p -> g_angle =  temp_beam_p -> g_angle;
	 beam_p -> coll_angle =  temp_beam_p -> coll_angle;
	 beam_p -> wedge =  temp_beam_p -> wedge;
	 beam_p -> orientation =  temp_beam_p -> orientation;
	 beam_p -> blocks_p =  temp_beam_p -> blocks_p;

	 /* Hidden stuff for Prism */
	 beam_p -> display_color =  temp_beam_p -> display_color;
	 for (i = 0; i < 4; i++) beam_p -> table_position[i] 
				   = temp_beam_p -> table_position[i];
	 beam_p -> arc_size = temp_beam_p -> arc_size;
	 beam_p -> n_treatments =  temp_beam_p -> n_treatments;

         if rtpt_class(this_class, RTPT_S_BEAM) {
	      	obj_p -> set_element_p = s_beam_p;
		} 
         if rtpt_class(this_class, RTPT_C_BEAM) {
	      	obj_p -> set_element_p = c_beam_p;
		} 
         if rtpt_class(this_class, RTPT_VJ_BEAM) {
	      	obj_p -> set_element_p = vj_beam_p;
		} 
         if rtpt_class(this_class, RTPT_M_BEAM) {
	      	obj_p -> set_element_p = m_beam_p;
		} 
	 } 
	else obj_p -> set_element_p = NULL; 
		/* Collimator type doesn't match what we're seeking */

        /***
	We thought this might be necessary, but it's not.  Even in Prism,
	MU refers to total MU in whole course of treatment, just like in RTPT
        beam_p -> units = (beam_p -> units)*n_treats;
        ***/

      } /* end RTPT_BEAM etc. */

   /* Do all the beam delivery classes in one case brach - 
	similar to beam - A single Prism class corresponds to multiple 
	RTPT classes, depending on the value of one of the Prism slots.

	Handle much the same way as beam */

   else if (rtpt_class(current_class, RTPT_BEAM_DELIV)
 	|| rtpt_class(current_class, RTPT_S_BEAM_DELIV)
	|| rtpt_class(current_class, RTPT_C_BEAM_DELIV)
	|| rtpt_class(current_class, RTPT_VJ_BEAM_DELIV)
	|| rtpt_class(current_class, RTPT_M_BEAM_DELIV)) {

   printf("    Entering get_object branch for %s\n", current_class);

      /* First, allocate the base class part and init its slots */
      temp_beam_deliv_p = (rtpt_beam_delivery_t *) 
					malloc(sizeof(rtpt_beam_delivery_t));
      temp_beam_deliv_p -> obj_id.type = RTPT_BEAM_DELIV;
      slen = MAXLINE; 			/* Safer - was strlen(no_name) + 1; */
      temp_beam_deliv_p -> unit_name = (rtpt_string_t) malloc(slen);
      strcpy(temp_beam_deliv_p -> unit_name, no_name); /* seems safest */
      temp_beam_deliv_p -> mfgr_model = (rtpt_string_t) malloc(slen);
      strcpy(temp_beam_deliv_p -> mfgr_model, no_name); /* seems safest */
      temp_beam_deliv_p -> modality = RTPT_BEAM_PHOTON;
      temp_beam_deliv_p -> energy = 6.0; /* No particular reason... */
      temp_beam_deliv_p -> source_size = 0.3;
      temp_beam_deliv_p -> source_axis = 100.0;
      temp_beam_deliv_p -> wedges_p = alloc_set();

/*jmu noted prolem here when slen was strlen(n_name) + 1, not MAXLINE */
      collim_type = (rtpt_string_t) malloc(slen);
      strcpy(collim_type, no_name); /* seems safest - slen is MAXLINE here */

/*** jmu's initial fix
        collim_type = (rtpt_string_t) malloc(MAXLINE);
        strcpy(collim_type, no_name); 
***/
	
      /* Now scan through the file and read the data */
      do {
	fstatus = find_next_key(fp, current_label, TRUE);
	if (fstatus == EOF) {
	   return RTPT_ST_FAIL; /* Reached EOF while scanning inside object */
	   }

   printf("     find_next_key just encountered %s\n", current_label);

	/* Machine name has quotes around it */
	if (strcmp(current_label, "NAME") == 0) {
	   fstatus = fscanf(fp, "%*[ \"]%[^\"]", temp_s);
	   if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
	   slen = strlen(temp_s) + 1;
	   temp_beam_deliv_p -> unit_name = (rtpt_string_t) malloc(slen);
	   strcpy(temp_beam_deliv_p -> unit_name, temp_s);
	   } 

	/* Particle type doesn't have quotes around it */
	if (strcmp(current_label, "PARTICLE") == 0) {
		fstatus = fscanf(fp, "%s", temp_s);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */
		if (strcmp(temp_s, "PHOTONS") == 0) {
			temp_beam_deliv_p -> modality = RTPT_BEAM_PHOTON;
			} 
		else if (strcmp(temp_s, "ELECTRONS") == 0) {
			temp_beam_deliv_p -> modality = RTPT_BEAM_ELECTRON;
			} 
		else if (strcmp(temp_s, "NEUTRONS") == 0) {
			temp_beam_deliv_p -> modality = RTPT_BEAM_NEUTRON;
			} 
		else if (strcmp(temp_s, "PROTONS") == 0) {
			temp_beam_deliv_p -> modality = RTPT_BEAM_PROTON;
			} 
			else temp_beam_deliv_p -> modality = RTPT_UNKNOWN_E;
		} 

     	if (strcmp(current_label, "ENERGY") == 0) {
		fstatus = fscanf(fp,"%f", &(temp_beam_deliv_p -> energy));
		} 

     	if (strcmp(current_label, "PENUMBRA") == 0) {
	   fstatus = fscanf(fp,"%f", &(temp_beam_deliv_p -> source_size));
	   } 

     	if (strcmp(current_label, "CAL-DISTANCE") == 0) {
	   fstatus = fscanf(fp,"%f", &(temp_beam_deliv_p -> source_axis));
	   } 

	/** NOTE NOTE collim_type must have space pre-allocated
			at this point to hold largest possible string here */
     	if (strcmp(current_label, "COLLIMATOR") == 0) {
		fstatus = fscanf(fp, "%s", collim_type);
		if (fstatus != 1) return RTPT_ST_FAIL; /* bad input file */

		/* Here are the possibilities */

		if (strcmp(collim_type, "SYMMETRIC-JAW-COLL") == 0) {
			this_class = RTPT_S_BEAM_DELIV;
			s_beam_deliv_p = (rtpt_s_beam_delivery_t *) 
					malloc(sizeof(rtpt_s_beam_delivery_t));
			s_beam_deliv_p -> obj_id.type = RTPT_S_BEAM_DELIV;
			s_beam_deliv_p -> coll_x_lim = 40.0;
			s_beam_deliv_p -> coll_y_lim = 40.0;
			beam_deliv_p = &(s_beam_deliv_p -> beam_deliv); 
			}

		if (strcmp(collim_type, "COMBINATION-COLL") == 0) {
			this_class = RTPT_C_BEAM_DELIV;
			c_beam_deliv_p = (rtpt_c_beam_delivery_t *) 
					malloc(sizeof(rtpt_c_beam_delivery_t));
			c_beam_deliv_p -> obj_id.type = RTPT_C_BEAM_DELIV;
			c_beam_deliv_p -> direction = RTPT_X;
			c_beam_deliv_p -> coll_retraction = 20.0;
			c_beam_deliv_p -> coll_extension = 10.0;
			c_beam_deliv_p -> coll_limit = 40.0;
			beam_deliv_p = &(c_beam_deliv_p -> beam_deliv); 
			}

		if (strcmp(collim_type, "VARIABLE-JAW-COLL") == 0) {
			this_class = RTPT_VJ_BEAM_DELIV;
			vj_beam_deliv_p = (rtpt_vj_beam_delivery_t *) 
					malloc(sizeof(rtpt_vj_beam_delivery_t));
			vj_beam_deliv_p -> obj_id.type = RTPT_VJ_BEAM_DELIV;
			vj_beam_deliv_p -> coll_retraction = 20.0;
			vj_beam_deliv_p -> coll_extension = 10.0;
			beam_deliv_p = &(vj_beam_deliv_p -> beam_deliv); 
			}

		if (strcmp(collim_type, "MULTILEAF-COLL") == 0) {
			this_class = RTPT_M_BEAM_DELIV;
			m_beam_deliv_p = (rtpt_m_beam_delivery_t *) 
					malloc(sizeof(rtpt_m_beam_delivery_t));
			m_beam_deliv_p -> obj_id.type = RTPT_M_BEAM_DELIV;
			m_beam_deliv_p -> direction = RTPT_X;
			m_beam_deliv_p -> num_leaf = 0; /* safe! */
			m_beam_deliv_p -> retraction = 20.0;
			m_beam_deliv_p -> extension = 10.0;
			m_beam_deliv_p -> thickness = 1.0;
			m_beam_deliv_p -> num_positions = 0; /* safe! */
			beam_deliv_p = &(m_beam_deliv_p -> beam_deliv); 
			}

		} /* if collimator */

      } /* end do-while body for beam delivery system */
      while ((fstatus != EOF) && (strcmp(current_label, ":END") != 0));

      /* Now that everything has been collected from the collimator and
	 the beam delivery system , if the collimator type matches the 
	 requested type, assemble the returned structure.  */

      if (rtpt_class(current_class, RTPT_BEAM_DELIV)
 	|| rtpt_class(current_class, this_class)) {

	 /* This seems awkward but I couldn't think of an alternative */
	 beam_deliv_p -> obj_id.type =  temp_beam_deliv_p -> obj_id.type;
         beam_deliv_p -> unit_name = temp_beam_deliv_p -> unit_name;
         beam_deliv_p -> mfgr_model = temp_beam_deliv_p -> mfgr_model;
         beam_deliv_p -> modality = temp_beam_deliv_p -> modality;
         beam_deliv_p -> energy = temp_beam_deliv_p -> energy;
         beam_deliv_p -> source_size = temp_beam_deliv_p -> source_size;
         beam_deliv_p -> source_axis = temp_beam_deliv_p -> source_axis;
         beam_deliv_p -> wedges_p = temp_beam_deliv_p -> wedges_p;

         if rtpt_class(this_class, RTPT_S_BEAM_DELIV) {
	      	obj_p -> set_element_p = s_beam_deliv_p;
		} 
         if rtpt_class(this_class, RTPT_C_BEAM_DELIV) {
	      	obj_p -> set_element_p = c_beam_deliv_p;
		} 
         if rtpt_class(this_class, RTPT_VJ_BEAM_DELIV) {
	      	obj_p -> set_element_p = vj_beam_deliv_p;
		} 
         if rtpt_class(this_class, RTPT_M_BEAM_DELIV) {
	      	obj_p -> set_element_p = m_beam_deliv_p;
		} 
	 } 
	else obj_p -> set_element_p = NULL; 
		/* Collimator type doesn't match what we're seeking */

      } /* end RTPT_BEAM_DELIV  etc. */

     /* etc... add other classes here */

   /* Default.  Returning NULL element should cause no trouble */
   else {
      obj_p -> set_element_p = NULL; /* default - should cause no trouble */
      }

   return RTPT_ST_OK;
} /* end get_object */

/****************************************************************************

get_all_objects.   Gets all objects of a given class, from the current 
position of the file pointer to end of file, or to end of enclosing object.
Called from the main Fetch All function, also called by get_object to get
nested objects, e.g. the contours within a solid.

Input params:

	fp: file pointer 
	current_class: class of objects to get
        object_list: pointer to pointer to list of objects that was found.
        last_object: pointer to pointer to last object in list.  
			Needed to insert this list into a list. 
	stop_flag: Determines whether only within an object (= TRUE)
			or all the way to EOF (= FALSE)
	n_objects: pointer to an integer reporting the number of objects 
			found.

This function returns an integer status value, used to convey success or
various failures.

Note that current is a pointer to a pointer to a set element (which then points
to the list of objects). 

Call this function with stop_flag set to false to scan for all objects to the
end of the dataset, as in the main Fetch All function; call it with stop_flag
true to scan for objects nested within an object, as in the get_object
function. 

Here is the pseudocode for get_all_objects:

   When we enter get_all_objects, either we are just at the beginning of the
   file (if at top level) or have just read the keyword for an object where we
   are about the read the contained objects.

	Do
		find_next_keyword
		(with stop flag set true to search to eof, or stop flag false
		 to search only within this object)

		If find_next_keyword indicated eof or end of object (depending
		on stop flag) 
			Then (do nothing - fall out of bottom of loop )

			instance_class = lookup_class(keyword, current_class)

			if fetch_class not RTPT_ABSENT then

				Then get_object( instance_class ... )

				If get_object fails then return immediately

				Insert new object at head of list 

	While not eof or end of object (depending on stop flag)

	Return success
			
*****************************************************************************/

int get_all_objects(FILE *fp, rtpt_string_t current_class, 
			rtpt_set_t **object_list, rtpt_set_t **last_object,
			int stop_flag, int *n_objects)

{
   int fstatus, gstatus, first;
   char current_key[MAXLINE]; 
   rtpt_set_t *obj_p; 
   rtpt_string_t instance_class;
   rtpt_id_t *id_p;

   *n_objects = 0;
   first = TRUE;

   printf(" Entering get_all_objects seeking %s\n", current_class); 
   
   /* do find next keyword while not end of file or end of enclosing obj. */
   do {

   /* Scan through file for next keyword or eof */
   fstatus = find_next_key(fp, current_key, stop_flag);

   if ( (!stop_flag  && (fstatus == EOF)) || 
	  (stop_flag && (strcmp(current_key, ":END") == 0)) ) {
       /* printf("Returned from find_next_key: status %d, EOF or :END\n",
	      fstatus); */
   }
   else {
       /* printf("Returned from find_next_key: status %d, keyword |%s|\n", 
		fstatus, current_key); */

      instance_class = lookup_class(current_key, current_class);

     /* printf("Returned from lookup_class: keyword |%s|, instance class %s\n", 
		current_key, instance_class); */

      /* If current_key is a sought-after keyword then ... else keep scanning */
      if (strcmp(instance_class, RTPT_ABSENT) != 0) {

	/* printf(" get_all_objects matched current key %s, current class %s, got instance class %s\n",
			current_key, current_class, instance_class); */

         /* Allocate new object instance and fill with data read from file. */
         gstatus = get_object(fp, instance_class, &obj_p); 
	   /* must pass in address of current_obj because of call-by-val */

	 if (gstatus != RTPT_ST_OK) return gstatus; /* get_object failed */

	 /* get_object succeeded. Insert new object at head */ 
	 obj_p -> next_p = *object_list;
	 *object_list = obj_p;
	 (*n_objects)++;
	 if (first) {*last_object = obj_p; first = FALSE;} /* Mark tail */

	 printf(" get_all_objects collected object number %d of class %s\n",
			*n_objects, instance_class);

	 id_p = (rtpt_id_t *) (*object_list)->set_element_p;
	 
	 printf(" head object on list is of type %s\n", id_p->type);
	 /* printf(" tail is of type %s\n", 
			(*last_object) -> obj_id.type); */

         } /* end if keyword matched current class.  No else needed here */

    }/* end else not EOF or not :END returned by find_next_key */

   } /* end do-while not EOF or not :END body */
   while ( (!stop_flag  && (fstatus != EOF)) || 
	   (stop_flag && (strcmp(current_key, ":END") != 0)) );
   
   return RTPT_ST_OK; /* If we got this far, success */	   
} /* end get_all_objects */

/****************************************************************************

The Fetch All function.  Fetches items from a sequential text file where 
each object and each attribute are indicated by keywords.

Here's the pseudocode for Fetch All (in C, fou_fetchall).

	Try to open data set file

	If open fails, then return immediately

	For each class in list

		Reset data set file

		get_all_objects	in current class, return list of those objects
		(Set get_all_objects' stop flag to false, search to eof)

		If get_all_objects returns failure status, return immediately

		Insert list of new objects in front of list

	end for each class

	Close data set file 

	Return success

*****************************************************************************/

/* Fetch All */
enum rtpt_status_e fou_fetchall(        /* output: status */
    rtpt_string_t      data_id,         /* input: data set identifer */
    rtpt_set_t       * classes_p,       /* input: classes */
    rtpt_set_t       * objects_p        /* output: objects */
    )

{
 rtpt_id_t *class_name_p;	
 rtpt_string_t current_class;
 rtpt_set_t *class_p, *object_list, *last_object; 
 int n_objects, fstatus, gstatus;
 FILE *fp; 
 char current_key[MAXLINE]; /* char *current_key crashes */

 /* Stay out of trouble!   Initialize rtpt_set_t indicated by objects_p. 
    Our current interp. of C binding does not require caller to do this. */
 objects_p -> obj_id.type = RTPT_SET;
 objects_p -> next_p = NULL;
 objects_p -> set_element_p = NULL;

 /* For now, data set name is VMS logical name for input file.
 Try to open data set.  If open fails, then exit.   
 Code for opening file copied from K&R 2nd ed p. 162. */

 if ((fp = fopen(data_id, "r")) == NULL) {
  printf("fou_fetchall: Can't open %s\n", data_id);
  return RTPT_ST_FAIL; /* Can't open input data set */
  } else {

  /* else ... */
  printf("Opened data set %s\n", data_id);

  /* For each class named in classes_p.  Walk list as in K&R 2nd ed p. 145 */
  last_object = NULL;
  object_list = NULL;
  n_objects = 0;
  for (class_p = classes_p; class_p != NULL; class_p = class_p -> next_p) {

   /* Find class name in two steps. */
   class_name_p = class_p -> set_element_p; 
   current_class = class_name_p -> type; /* same as (*class_name_p).type */ 

   /* While experimenting, print out each class name as it is found. */
   printf("Begin seeking instances of class %s\n", current_class);
  
   /* Reset data set file to beginning */
   rewind(fp);

   gstatus = get_all_objects(fp, current_class, &object_list, &last_object,
				FALSE, &n_objects);

   if (gstatus != RTPT_ST_OK) {
      return gstatus; /* get_object failed */

      } else {
   
      /* get_all_objects succeeded. Insert new list at front of existing list */
      printf("get_all_objects found %d objects of class %s\n", 
		n_objects, current_class);
      if (n_objects > 0) { 
	last_object -> next_p = objects_p -> next_p;
        objects_p -> next_p = object_list;
        }
      } /* end else get_object succeeded */


  } /* end for iterating over class names */

 fclose(fp);
 } /* end else data set file opened... */

 /* We're back out of all those nested loops */
 return RTPT_ST_OK; /* If we got this far, success! */
}                                                                            

