/* {{{ xrtp.h -- Interface for Scanner and RTPT system in Rad. Oncology.  */

/*************************************************************************
*
* Author:       Kevin Hinshaw
* Created:      95Jul17
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
extern LVAL  xrtp02_Save_Contour_Fn();
extern LVAL  xrtp04_Save_Volume_Fn();
extern LVAL  xrtp06_Fetch_Image_Filenames_Fn();
extern LVAL  xrtp11_Fetch_Segmentation_Data_Fn();

#ifndef EXTERNED_CLASSPOINT2D
extern LVAL k_class_point2d;   /* Keyword "CLASS-POINT2D" */
#define EXTERNED_CLASSPOINT2D
#endif

#ifndef EXTERNED_NUMRADIALS
extern LVAL k_numradials;   /* Keyword ":NUM-RADIALS" */
#define EXTERNED_NUMRADIALS
#endif

#ifndef EXTERNED_SET
extern LVAL k_set;   /* Keyword ":SET" */
#define EXTERNED_SET
#endif

#ifndef EXTERNED_BESTX
extern LVAL k_bestx;   /* Keyword ":BEST-X" */
#define EXTERNED_BESTX
#endif

#ifndef EXTERNED_BESTY
extern LVAL k_besty;   /* Keyword ":BEST-Y" */
#define EXTERNED_BESTY
#endif

#ifndef EXTERNED_CONVERTPOINTFROMCCS
extern LVAL k_convertpointfromccs;   /* Keyword ":CONVERT-POINT-FROM-CCS" */
#define EXTERNED_CONVERTPOINTFROMCCS
#endif

#ifndef EXTERNED_X
extern LVAL k_x;   /* Keyword ":X" */
#define EXTERNED_X
#endif

#ifndef EXTERNED_Y
extern LVAL k_y;   /* Keyword ":Y" */
#define EXTERNED_Y
#endif

#ifndef EXTERNED_CONTOUR
extern LVAL k_contour;   /* Keyword ":CONTOUR" */
#define EXTERNED_CONTOUR
#endif

#ifndef EXTERNED_DATA_ID
extern LVAL k_contour;   /* Keyword ":DATA-ID" */
#define EXTERNED_DATA_ID
#endif

#ifndef EXTERNED_NAME
extern LVAL k_name;   /* Keyword ":NAME" */
#define EXTERNED_NAME
#endif

#ifndef EXTERNED_CONTOURLIST
extern LVAL k_contourlist;   /* Keyword ":CONTOUR-LIST" */
#define EXTERNED_CONTOURLIST
#endif

#ifndef EXTERNED_Z
extern LVAL k_z;   /* Keyword ":Z" */
#define EXTERNED_Z
#endif

#ifndef EXTERNED_IMAGE_FILENAME
extern LVAL k_imagefilename;   /* Keyword ":IMAGE-FILENAME" */
#define EXTERNED_IMAGE_FILENAME
#endif

#ifndef EXTERNED_STRUCTURE
extern LVAL k_structure;   /* Keyword ":STRUCTURE" */
#define EXTERNED_STRUCTURE
#endif

#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR( "XRTP-SAVE-CONTOUR",            xrtp02_Save_Contour_Fn)
DEFINE_SUBR( "XRTP-SAVE-VOLUME",             xrtp04_Save_Volume_Fn)
DEFINE_SUBR( "XRTP-FETCH-IMAGE-FILENAMES",   xrtp06_Fetch_Image_Filenames_Fn)
DEFINE_SUBR( "XRTP-FETCH-SEGMENTATION-DATA", xrtp11_Fetch_Segmentation_Data_Fn)
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS


#ifndef DEFINED_CLASSPOINT2D
LVAL k_class_point2d;   /* Keyword "CLASS-POINT2D" */
#define DEFINED_CLASSPOINT2D
#endif

#ifndef DEFINED_NUMRADIALS
LVAL k_numradials;   /* Keyword ":NUM-RADIALS" */
#define DEFINED_NUMRADIALS
#endif

#ifndef DEFINED_SET
LVAL k_set;   /* Keyword ":SET" */
#define DEFINED_SET
#endif

#ifndef DEFINED_BESTX
LVAL k_bestx;   /* Keyword ":BEST-X" */
#define DEFINED_BESTX
#endif

#ifndef DEFINED_BESTY
LVAL k_besty;   /* Keyword ":BEST-Y" */
#define DEFINED_BESTY
#endif

#ifndef DEFINED_CONVERTPOINTFROMCCS
LVAL k_convertpointfromccs;   /* Keyword ":CONVERT-POINT-FROM-CCS" */
#define DEFINED_CONVERTPOINTFROMCCS
#endif

#ifndef DEFINED_X
LVAL k_x;   /* Keyword ":X" */
#define DEFINED_X
#endif

#ifndef DEFINED_Y
LVAL k_y;   /* Keyword ":Y" */
#define DEFINED_Y
#endif

#ifndef DEFINED_CONTOUR
LVAL k_contour;   /* Keyword ":CONTOUR" */
#define DEFINED_CONTOUR
#endif

#ifndef DEFINED_DATA_ID
LVAL k_data_id;   /* Keyword ":DATA-ID" */
#define DEFINED_DATA_ID
#endif

#ifndef DEFINED_NAME
LVAL k_name;   /* Keyword ":NAME" */
#define DEFINED_NAME
#endif

#ifndef DEFINED_CONTOURLIST
LVAL k_contourlist;   /* Keyword ":CONTOUR-LIST" */
#define DEFINED_CONTOURLIST
#endif

#ifndef DEFINED_Z
LVAL k_z;   /* Keyword ":Z" */
#define DEFINED_Z
#endif

#ifndef DEFINED_IMAGE_FILENAME
LVAL k_imagefilename;   /* Keyword ":IMAGE-FILENAME" */
#define DEFINED_IMAGE_FILENAME
#endif

#ifndef DEFINED_STRUCTURE
LVAL k_structure;   /* Keyword ":STRUCTURE" */
#define DEFINED_STRUCTURE
#endif

#endif

#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_CLASSPOINT2D
    k_class_point2d = xlenter("CLASS-POINT2D");
#define CREATED_CLASSPOINT2D
#endif

#ifndef CREATED_NUMRADIALS
    k_numradials = xlenter(":NUM-RADIALS");
#define CREATED_NUMRADIALS
#endif

#ifndef CREATED_SET
    k_set = xlenter(":SET");
#define CREATED_SET
#endif

#ifndef CREATED_BESTX
    k_bestx = xlenter(":BEST-X");
#define CREATED_BESTX
#endif

#ifndef CREATED_BESTY
    k_besty = xlenter(":BEST-Y");
#define CREATED_BESTY
#endif

#ifndef CREATED_CONVERTPOINTFROMCCS
    k_convertpointfromccs = xlenter(":CONVERT-POINT-FROM-CCS");
#define CREATED_CONVERTPOINTFROMCCS
#endif

#ifndef CREATED_X
    k_x = xlenter(":X");
#define CREATED_X
#endif

#ifndef CREATED_Y
    k_y = xlenter(":Y");
#define CREATED_Y
#endif

#ifndef CREATED_CONTOUR
    k_contour = xlenter(":CONTOUR");
#define CREATED_CONTOUR
#endif

#ifndef CREATED_DATA_ID
    k_data_id = xlenter(":DATA-ID");
#define CREATED_DATA_ID
#endif

#ifndef CREATED_NAME
    k_name = xlenter(":NAME");
#define CREATED_NAME
#endif

#ifndef CREATED_CONTOURLIST
    k_contourlist = xlenter(":CONTOUR-LIST");
#define CREATED_CONTOURLIST
#endif

#ifndef CREATED_Z
    k_z = xlenter(":Z");
#define CREATED_Z
#endif

#ifndef CREATED_IMAGE_FILENAME
    k_imagefilename = xlenter(":IMAGE-FILENAME");
#define CREATED_IMAGE_FILENAME
#endif

#ifndef CREATED_STRUCTURE
    k_structure = xlenter(":STRUCTURE");
#define CREATED_STRUCTURE
#endif

#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
#endif


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
