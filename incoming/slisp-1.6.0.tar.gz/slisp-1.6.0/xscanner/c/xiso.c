/* {{{ xiso.c -- isosurface routines                    	     CrT*/

/*************************************************************************
*
* Author:       Kevin Hinshaw
* Created:      96Aug16
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 96Aug16 kph  Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

/*
#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/csry.h"
*/
#include "implicit.h"
#include "../../xg.3d/c/cf2v.h"
#include <math.h>
/* #include "ciso.h" */

extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();
extern LVAL xgrl3c_Get_Array();
extern LVAL xgrl01_Get_A_XGRL();
extern LVAL xgrl31_Get_Array_With_Fill_Pointer();
extern LVAL xlin21_extractLineFromVolume();

extern char *polygonize();

extern LVAL k_new;
extern LVAL k_setarray;
extern LVAL k_min;
extern LVAL k_max;
extern LVAL lv_xgrl;
extern LVAL lv_xf2v;
extern LVAL lv_xflv;
extern LVAL lv_x32v;
extern LVAL true; /*xlglob.c*/

/* all the keywords I define here (some may exist elsewhere) */
extern LVAL k_seeds;
extern LVAL k_threshold;
extern LVAL k_intensity;
extern LVAL k_original_intensity;
extern LVAL k_voxels;
extern LVAL k_pointx;
extern LVAL k_pointy;
extern LVAL k_pointz;
extern LVAL k_point_normalx;
extern LVAL k_point_normaly;
extern LVAL k_point_normalz;
extern LVAL k_facet0;
extern LVAL k_facet1;
extern LVAL k_facet2;
extern LVAL k_setf_fill_pointer;
extern LVAL k_point_relation;
extern LVAL k_facet_relation;
extern LVAL k_interpolate;
extern LVAL k_reuse_if_available;
extern LVAL k_resolution;
extern LVAL k_use_tetrahedrons;
extern LVAL k_array_dimensions;

/* function prototypes */
void computeThresholds(LVAL, XISO_SEEDS);
LVAL computeIsosurface(XISO_DATASET *);
int  triangleHandler(int, int, int, VERTICES);
double trilinear_volume(double, double, double, XISO_DATASET *);
double thresh (double, double, double, XISO_DATASET *);

/* global vars */
LVAL     XISO_LV_FACETS;  /* facet relation for isosurface */

/* }}} */

/* {{{ --- Public fns ---						*/

/* }}} */
/* {{{ isaseed                                                          */

/* Return 1 if the specified point is a seed point. */

unsigned char isaseed(int x, int y, int z, XISO_DATASET d) { 

  int  i;

  for (i = 0; i < d.num_seeds; i++) {
    if ((x == d.xseed[i]) &&
	(y == d.yseed[i]) &&
	(z == d.zseed[i]))
      return 1;
  }
  return 0;
}

/* }}} */
/* {{{ extract_seeds                                                    */

/* Convert seed points from list format to 3 coordinate arrays and put
 * them into the dataset.  Return 1 if everything was fine, 0 if there
 * were no seeds, and error if no dataset was specified.
 */

int extract_seeds(LVAL lv_seeds, XISO_DATASET *d) {

  /* no dataset specified */
  if (!d) {
    xlerror("extract_seeds: no dataset specified");
  }
  
  /* no seeds -- use a default one at the center of the dataset */
  else if (!lv_seeds) {

    int        toProt = 1;
    xlstkcheck(toProt);
    xlprotect(lv_seeds);

    d->num_seeds = 1;
    d->xseed = (int *) calloc(d->num_seeds, sizeof(int));
    d->yseed = (int *) calloc(d->num_seeds, sizeof(int));
    d->zseed = (int *) calloc(d->num_seeds, sizeof(int));
    d->xseed[0] = d->xsize / 2;
    d->yseed[0] = d->ysize / 2;
    d->zseed[0] = d->zsize / 2;

    xlpopn(toProt);
    return 0;
  }

  /* got dataset and seeds -- do the conversion */
  else {

    LVAL  lv_arg;   /* temp */
    LVAL  lv_num;   /* temp num */
    LVAL  lv_seed;  /* entry in seed list */
    int   i;

    int        toProt = 4;
    xlstkcheck(toProt);
    xlprotect(lv_seeds);
    xlsave(lv_arg);
    xlsave(lv_num);
    xlsave(lv_seed);

    d->num_seeds = xiso_length(lv_seeds);
    d->xseed = (int *) calloc(d->num_seeds, sizeof(int));
    d->yseed = (int *) calloc(d->num_seeds, sizeof(int));
    d->zseed = (int *) calloc(d->num_seeds, sizeof(int));
    if (!(d->xseed && d->yseed && d->zseed))
      xlerror("XISO-COMPUTE-ISOSURFACE: couldn't allocate array");
    lv_arg = lv_seeds;
    for (i = 0; i < d->num_seeds; i++) {
      lv_seed = car(lv_arg);
      
      /* check for bad seeds */
      if (!((listp(lv_seed)) || 
	    (xiso_length(lv_seed) == 3)))
	xlerror("Bad XISO-COMPUTE-ISOSURFACE seed", lv_seed);
      
      /* copy seed's coords to arrays */
      lv_num = car(lv_seed);
      if      (  fixp(lv_num)) { d->xseed[i] = getfixnum(lv_num); }
      else    { xlerror("Bad XISO-COMPUTE-ISOSURFACE seed", lv_seed); }
      lv_num = car(cdr(lv_seed));
      if      (  fixp(lv_num)) { d->yseed[i] = getfixnum(lv_num); }
      else    { xlerror("Bad XISO-COMPUTE-ISOSURFACE seed", lv_seed); }
      lv_num = car(cdr(cdr(lv_seed)));
      if      (  fixp(lv_num)) { d->zseed[i] = getfixnum(lv_num); }
      else    { xlerror("Bad XISO-COMPUTE-ISOSURFACE seed", lv_seed); }
      
      /* advance to the next seed */
      lv_arg = cdr(lv_arg);
    }
    
    xlpopn(toProt);
    return 1;
  }
}

/* }}} */
/* {{{ xiso_length       	         	                	*/

/* compute length of a list */

int xiso_length(LVAL lv_list) {

  LVAL  lv_arg;
  int   n;

  if (listp(lv_list)) {
    lv_arg = lv_list;
    for (n = 0; consp(lv_arg); n++)
      lv_arg = cdr(lv_arg);
  }
  else {
    xlerror("xiso_length: bad argument type",lv_list);
  }
  return n;
}

/* }}} */
/* {{{ Compute_Thresholds_Fn	                                	*/

/* Lisp name:  XISO-COMPUTE-THRESHOLDS
 *
 * Function to compute threshold values for a volume of voxels, given
 * a list of seed point boundaries.  Each entry in the list should
 * look like ((xmin ymin zmin) (x y z) (xmax ymax zmax)).  These range
 * defined by these bounds will be searched to find an appropriate
 * threshold for each seed point.
 *
 * Seed coordinates should be in voxel space: integers in [0,size-1]^3.
 * 
 */

LVAL Compute_Thresholds_Fn() {

  LVAL             lv_voxels;         /* 3D voxel GRL */
  LVAL             lv_seeds;          /* seed point coordinates */
  LVAL             lv_seed;           /* single seed point */
  LVAL             lv_intensity;      /* voxel intensities */
  LVAL             lv_threshold;      /* computed threshold values */
  LVAL             lv_shape;          /* dimensions of voxel GRL */
  LVAL             lv_arg;            /* dummy lval */
  LVAL             lv_num;            /* temp number */
  LVAL             lv_min;            /* seed's min bounds */
  LVAL             lv_mid;            /* seed coordinates  */
  LVAL             lv_max;            /* seed's max bounds */
  XISO_SEEDS       seeds;             /* seed arrays */
  int              i;                 /* loop index */


  int        toProt = 11;
  xlstkcheck(toProt);
  xlsave(lv_voxels);
  xlsave(lv_seeds);
  xlsave(lv_seed);
  xlsave(lv_intensity);
  xlsave(lv_threshold);
  xlsave(lv_shape);
  xlsave(lv_arg);
  xlsave(lv_num);
  xlsave(lv_min);
  xlsave(lv_mid);
  xlsave(lv_max);

  /* read the arguments */
  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();

    if        (key == k_voxels) {  /* :VOXELS */
      lv_voxels = xgrl01_Get_A_XGRL();
    }
    else if   (key == k_seeds) {   /* :SEEDS */
      lv_seeds = xlgalist();
    }
    else {
      xlerror("XISO-COMPUTE-THRESHOLDS: bad keyword", key);
    }
  }

  /* make sure we got both arrays */
  if (!lv_voxels) xlfail("XISO-COMPUTE-THRESHOLDS: missing :VOXELS keyword");
  if (!lv_seeds)  xlfail("XISO-COMPUTE-THRESHOLDS: missing :SEEDS keyword");

  /* create coordinate arrays to store seed bounds */
  seeds.count = xiso_length(lv_seeds);
  seeds.xmin  = (int *) calloc(seeds.count, sizeof(int));
  seeds.ymin  = (int *) calloc(seeds.count, sizeof(int));
  seeds.zmin  = (int *) calloc(seeds.count, sizeof(int));
  seeds.x     = (int *) calloc(seeds.count, sizeof(int));
  seeds.y     = (int *) calloc(seeds.count, sizeof(int));
  seeds.z     = (int *) calloc(seeds.count, sizeof(int));
  seeds.xmax  = (int *) calloc(seeds.count, sizeof(int));
  seeds.ymax  = (int *) calloc(seeds.count, sizeof(int));
  seeds.zmax  = (int *) calloc(seeds.count, sizeof(int));
  if (!(seeds.xmin && seeds.ymin && seeds.zmin &&
	seeds.x    && seeds.y    && seeds.z    &&
	seeds.xmax && seeds.ymax && seeds.zmax))
    xlerror("XISO-COMPUTE-THRESHOLDS: couldn't allocate array");

  /* convert the seeds list into coordinate arrays */
  lv_arg = lv_seeds;
  for (i = 0; i < seeds.count; i++) {
    lv_seed = car(lv_arg);

    /* check for bad seeds */
    if (!((listp(lv_seed)) || 
	  (xiso_length(lv_seed) == 3)))
      xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_seed);
    
    /* copy seed's min coords to arrays */
    lv_min = car(lv_seed);
    lv_num = car(lv_min);
    if      (  fixp(lv_num)) { seeds.xmin[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_min); }
    lv_num = car(cdr(lv_min));
    if      (  fixp(lv_num)) { seeds.ymin[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_min); }
    lv_num = car(cdr(cdr(lv_min)));
    if      (  fixp(lv_num)) { seeds.zmin[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_min); }

    /* copy seed's coords to arrays */
    lv_mid = car(cdr(lv_seed));
    lv_num = car(lv_mid);
    if      (  fixp(lv_num)) { seeds.x[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_mid); }
    lv_num = car(cdr(lv_mid));
    if      (  fixp(lv_num)) { seeds.y[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_mid); }
    lv_num = car(cdr(cdr(lv_mid)));
    if      (  fixp(lv_num)) { seeds.z[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_mid); }

    /* copy seed's max coords to arrays */
    lv_max = car(cdr(cdr(lv_seed)));
    lv_num = car(lv_max);
    if      (  fixp(lv_num)) { seeds.xmax[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_max); }
    lv_num = car(cdr(lv_max));
    if      (  fixp(lv_num)) { seeds.ymax[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_max); }
    lv_num = car(cdr(cdr(lv_max)));
    if      (  fixp(lv_num)) { seeds.zmax[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_max); }

    /* advance to the next seed */
    lv_arg = cdr(lv_arg);
  }

  /* create the threshold array */
  /* (should we check to see if one already exists?) */
  lv_shape = xsendmsg0( lv_voxels, k_array_dimensions);
  lv_threshold = xsendmsg1(lv_xf2v, k_new, lv_shape);

  /* insert the threshold array in the voxel GRL (might want to delay this) */
  xsendmsg2( lv_voxels, k_setarray, k_threshold, lv_threshold );

  /* do the real work */
  computeThresholds(lv_voxels, seeds);

  /* free up temp arrays */
  free(seeds.xmin);
  free(seeds.ymin);
  free(seeds.zmin);
  free(seeds.x);
  free(seeds.y);
  free(seeds.z);
  free(seeds.xmax);
  free(seeds.ymax);
  free(seeds.zmax);

  xlpopn(toProt);
  return lv_threshold;
}

/* }}} */
/* {{{ computeThresholds                                                */

/*
 * Given the coordinates for some number of seed points, compute a
 * volume of interpolated isosurface threshold values.
 *
 * Input:
 *   lv_voxels     3D dataset
 *   seeds         arrays with seed point coordinates and range bounds
 *
 * Output:
 *   lv_threshold  3D volume of intensity thresholds
 *                 (this will be an array in lv_voxels)
 *
 * The x/y/z-offset values are used as a shortcut for incrementally
 * computing the distance from the next voxel to the seeds by using
 * the current voxel's distances.  This technique is derived from the
 * fact that consecutive squares of integers can be generated through
 * repeated addition of consecutive odd integers.  (This technique
 * assumes that distances are measured in voxel units and are, as a
 * result, integers.)
 *   
 */
 
void computeThresholds(LVAL lv_voxels, XISO_SEEDS seeds)
{
  /* 1D arrays */
  int             *xoff;        /* current x-offset value for each seed */
  int             *yoff;        /* current y-offset value for each seed */
  int             *zoff;        /* current z-offset value for each seed */
  int             *dist;        /* current squared distance to each seed */
  int             *zbasedist;   /* dist from start of current plane to seeds */
  int             *ybasedist;   /* dist from start of current row to seeds */
  CSRY_UNSIGNED16 *seed_thresholds; /* thresholds for seed points */

  /* other vars */
  LVAL            lv_num;            /* temp number */
  LVAL            lv_line;           /* pixel line taken from dataset */
  LVAL            lv_intensity;      /* dataset's intensity values */
  LVAL            lv_threshold;      /* dataset's threshold values */
  LVAL            lv_line_intensity; /* pixel line intensity array */
  CSRY_UNSIGNED16 *intensity;        
  CSRY_UNSIGNED16 *threshold;        
  CSRY_UNSIGNED16 *line_intensity;        
  CSRY_UNSIGNED16 min, max;          /* line sample intensity extremes */
  int             i, x, y, z;        /* loop indices */
  float           total_weight;      /* accumulated weighting factors */
  float           total_threshold;   /* accumulated weighted intensities */
  float           weight;            /* intensity weighting value */
  int             offset;            /* 1D offset into voxel array */
  int             num_voxels;        /* voxels in intensity array */
  int             xsize,ysize,zsize; /* voxel array dimensions */
  int             range_max = 4095;  /* max allowable 12-bit intensity */
  unsigned char   DEBUG = 1;         /* flag for debug comments */

  int        toProt = 6;
  xlstkcheck(toProt);
  xlprotect(lv_voxels);
  xlsave(lv_num);
  xlsave(lv_line);
  xlsave(lv_intensity);
  xlsave(lv_threshold);
  xlsave(lv_line_intensity);

  /* pull out the threshold and intensity arrays from the dataset.  If
   * intensity has been rotated, then we want the :original-intensity
   * array.  
   */
  lv_intensity = xgrl3c_Get_Array( lv_voxels, k_original_intensity, NIL, TRUE );
  if (!lv_intensity) {
    lv_intensity = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
  }
  if (!xf2vp(  lv_intensity )) {
    xlerror(":INTENSITY array is missing", lv_voxels);
  }
  lv_threshold = xgrl3c_Get_Array( lv_voxels, k_threshold, NIL, TRUE );
  if (!xf2vp(  lv_threshold )) {
    xlerror(":THRESHOLD array is missing", lv_voxels);
  }

  /* grab the actual arrays we want to work with */
  intensity = (CSRY_UNSIGNED16 *) (csry_base( lv_intensity ));
  threshold = (CSRY_UNSIGNED16 *) (csry_base( lv_threshold ));

  /* create 1D arrays */
  if (DEBUG) printf("Creating arrays...\n");
  xoff      = (int *) calloc(seeds.count, sizeof(int));
  yoff      = (int *) calloc(seeds.count, sizeof(int));
  zoff      = (int *) calloc(seeds.count, sizeof(int));
  dist      = (int *) calloc(seeds.count, sizeof(int));
  ybasedist = (int *) calloc(seeds.count, sizeof(int));
  zbasedist = (int *) calloc(seeds.count, sizeof(int));
  seed_thresholds = (CSRY_UNSIGNED16 *) 
    calloc(seeds.count, sizeof(CSRY_UNSIGNED16));

  if (!(xoff && yoff && zoff && dist && 
	ybasedist && zbasedist && seed_thresholds))
    xlerror("Unable to allocate memory");

  /* zero out entries in the threshold array */
  xvol95_Get_X_Y_Z_Dimensions( &xsize, &ysize, &zsize, lv_voxels );
  num_voxels = xsize * ysize * zsize;
  for (i = 0; i < num_voxels; i++) {
    threshold[i] = 0;
  }

  /* initialize at seeds */
  if (DEBUG) printf("Initializing seed points...\n");
  for (i = 0; i < seeds.count; i++) {
    x = seeds.x[i];
    y = seeds.y[i];
    z = seeds.z[i];
/*    offset = z + zsize * ( y + ysize * x ); */  /* 96Nov20 -- uh-oh... */
    offset = x + xsize * ( y + ysize * z );

    /* To avoid allocating a huge array of flags, I'm going to be
     * tricky and initialize the threshold value for each seed to be 1
     * plus its index.  In the main loop, I'll check this flag to
     * differentiate seeds and non-seeds, and used this stored value
     * to retrieve the right value from seed_thresholds.
     */
    threshold[offset] = i+1;

    /* compute seed's threshold by looking at region around it and */
    /* taking the midpoint of the min and max intensities */
    lv_line = 
      xlin21_extractLineFromVolume(lv_voxels, 
				   (double) seeds.xmin[i],
				   (double) seeds.ymin[i],
				   (double) seeds.zmin[i],
				   (double) seeds.xmax[i],
				   (double) seeds.ymax[i],
				   (double) seeds.zmax[i],
				   0.0, 0.0, 0.0,
				   (double) xsize,
				   (double) ysize, 
				   (double) zsize);

    /* grab line's intensity array */
    lv_line_intensity = xgrl3c_Get_Array( lv_line, k_intensity, NIL, TRUE );
    if (!xf2vp(  lv_line_intensity )) {
      xlerror(":INTENSITY array is missing", lv_line);
    }
    line_intensity = (CSRY_UNSIGNED16 *) (csry_base( lv_line_intensity ));

    /* pick the threshold halfway between min and max.  Note that by */
    /* using the built-in min/max functions, the returned answers will */
    /* look like floats in the range [0,1].  So we need to return them */
    /* to the integer range [0,4095] before working with them. */
    lv_num = xsendmsg0(lv_line_intensity, k_min);
    min = rint(getflonum(lv_num) * range_max);
    lv_num = xsendmsg0(lv_line_intensity, k_max);
    max = rint(getflonum(lv_num) * range_max);
    seed_thresholds[i] = (CSRY_UNSIGNED16) rint((min + max) / 2.0);

    if (DEBUG) {
      printf("seed %d (offset=%d): min=%hd, max=%hd, mid=%hd, actual=%hd\n",
	     i, offset, min, max, seed_thresholds[i], intensity[offset]);
    }

    /* sound the alarm if the seed point isn't at the line's center  */
    /* (check two points near center to handle lines of even length) */
    if (DEBUG) {
      csry_rec*  h   = (csry_rec*) gobjimmbase( lv_line_intensity );
      int        len = h->dim[0];
      int        mid = (int) ceil(len / 2.0);
      if ((intensity[offset] != line_intensity[mid-1]) &&
	  (intensity[offset] != line_intensity[mid]))
	  {
	printf("\nWARNING:  Possible seed point mismatch!\n"); 
	printf("\n");
      }
    }

    /* compute offsets and distance squared between seed and starting voxel */
    xoff[i] = -2 * x - 1;
    yoff[i] = -2 * y - 1;
    zoff[i] = -2 * z - 1;
    dist[i] =  x*x + y*y + z*z;
    ybasedist[i] = dist[i];
    zbasedist[i] = dist[i];
  }

  /* compute thresholds for all the voxels */
  if (DEBUG) printf("Computing thresholds...\n");
  offset = 0;
  for (z = 0; z < zsize; z++) {
    if (DEBUG) printf("Slice %d...\n", z);
    for (y = 0; y < ysize; y++) {
      for (x = 0; x < xsize; x++) {

	/* if this is a seed, just grab its precomputed threshold */
	if (threshold[offset] > 0) {
	  threshold[offset] = seed_thresholds[ threshold[offset] - 1 ];
	}

	/* otherwise compute the weighted threshold */
	else {

	  /* clear out accumulators */
	  total_threshold = 0;
	  total_weight    = 0;

	  /* compute sum of weighted intensities */
	  for (i = 0; i < seeds.count; i++) {
	    weight = 1.0 / dist[i];
	    total_threshold += weight * seed_thresholds[i];
	    total_weight += weight;
	  }

	  /* normalize weighted intensity */
	  threshold[offset] = total_threshold / total_weight;
/*
	  printf("(%3d,%3d,%3d):  %5.3f / %5.3f = %3d  (%d)\n", 
		 x, y, z, 
		 total_threshold, total_weight, 
		 threshold[offset], offset);
*/
	}  /* end else */

	/* move to next voxel and compute distances to seeds */
	offset++;
	for (i = 0; i < seeds.count; i++) {
	  xoff[i] += 2;
	  dist[i] += xoff[i];
	}	
      }  /* end x loop */

      /* compute offsets/distances for next voxel in y-direction */
      for (i = 0; i < seeds.count; i++) {
	yoff[i] += 2;
	xoff[i] = -2 * seeds.x[i] - 1;
	dist[i] = ybasedist[i] + yoff[i];
	ybasedist[i] = dist[i];          /* set row's new base dist */
      }

    } /* end y loop */
      
    /* compute offsets/distances for next voxel in z-direction */
    for (i = 0; i < seeds.count; i++) {
      zoff[i] += 2;
      yoff[i] = -2 * seeds.y[i] - 1;
      xoff[i] = -2 * seeds.x[i] - 1;
      dist[i] = zbasedist[i] + zoff[i];
      ybasedist[i] = dist[i];           /* set row's new base dist   */
      zbasedist[i] = dist[i];           /* set plane's new base dist */
    }

  } /* end x loop */


  /* print in a decent form */
/*
  i = 0;
  printf("\n\nTHRESHOLDS\n");
  printf("(seed points are starred)\n");
  for (z = 0; z < zsize; z++) {
    printf("Plane %d:\n", x);
    for (y = 0; y < ysize; y++) {
      for (x = 0; x < xsize; x++) {
	printf("%3d", threshold[i]);
	if (isaseed(x, y, z, d))
	  printf("*"); 
	else
	  printf(" ");
	i++;
      }
      printf("\n");
    }
    printf("\n");
  }
*/
  /* free all the arrays we allocated */
  free(xoff);
  free(yoff);
  free(zoff);
  free(dist);
  free(ybasedist);
  free(zbasedist);
  free(seed_thresholds);

  xlpopn(toProt);

}

/* }}} */
/* {{{ Compute_Isosurface_Fn	         	                	*/

/* Lisp name:  XISO-COMPUTE-ISOSURFACE
 *
 * Function to compute an isosurface for a volume of voxels, given a
 * set of seed points.  This uses Jules Bloomenthal's implicit surface
 * code from Graphics Gems IV. 
 */

/* NOTE:  This duplicates most of the code in Compute_Thresholds_Fn. */
/* It would be a good idea to factor out the shared portions.        */

LVAL Compute_Isosurface_Fn() {

  LVAL             lv_voxels;          /* 3D voxel GRL */
  LVAL             lv_seeds;           /* seed point coordinates */
  LVAL             lv_intensity;       /* voxel intensities */
  LVAL             lv_threshold;       /* global threshold */
  LVAL             lv_threshold_array; /* computed threshold values */
  LVAL             lv_isosurface;      /* computed isosurface (GRL?) */
  LVAL             lv_shape;           /* dimensions of voxel GRL */
  LVAL             lv_mode;            /* mode for isosurface */
  XISO_DATASET     d;                  /* dataset structure */
  int              i;                  /* loop index */


  int        toProt = 8;
  xlstkcheck(toProt);
  xlsave(lv_voxels);
  xlsave(lv_seeds);
  xlsave(lv_intensity);
  xlsave(lv_threshold);
  xlsave(lv_threshold_array);
  xlsave(lv_isosurface);
  xlsave(lv_shape);
  xlsave(lv_mode);

  /* set some default values */
  d.resolution = XISO_RESOLUTION;
  d.mode = TET;

  /* read the arguments */
  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();

    if        (key == k_voxels) {      /* :VOXELS */
      lv_voxels = xgrl01_Get_A_XGRL();
    }
    else if   (key == k_seeds) {       /* :SEEDS */
      lv_seeds = xlgalist();
    }
    else if   (key == k_threshold) {   /* :THRESHOLD */
      lv_threshold = xlgetarg();
    }
    else if   (key == k_resolution) {  /* :RESOLUTION */
      d.resolution = (double) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    }
    else if   (key == k_use_tetrahedrons) {  /* :USE-TETRAHEDRONS */
      lv_mode = xlgetarg();
      if      (null(lv_mode))    { d.mode = NOTET; }
      else if (lv_mode == true)  { d.mode = TET; }
      else { xlerror("XISO-COMPUTE-ISOSURFACE: bad value", lv_mode); }
    }
    else {
      xlerror("XISO-COMPUTE-ISOSURFACE: bad keyword", key);
    }
  }

printf("mode: %s\n", ((d.mode == TET) ? "tetrahedrons" : "cubes"));

  /* make sure we got voxels */
  if (!lv_voxels) xlerror("XISO-COMPUTE-ISOSURFACE: missing :VOXELS parameter");

  /* pull out the intensity array */
  lv_intensity = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
  if (!xf2vp(  lv_intensity )) {
    xlerror(":INTENSITY array is missing", lv_voxels);
  }
  xvol95_Get_X_Y_Z_Dimensions( &(d.xsize), &(d.ysize), &(d.zsize), lv_voxels );

  /* grab the actual array we want to work with */
  d.intensity = (CSRY_UNSIGNED16 *) (csry_base( lv_intensity ));

  /* convert the seeds list into three coordinate arrays */
  extract_seeds(lv_seeds, &d);


  /*** parse the :THRESHOLD argument ***/

  /* NOTE:  for the single threshold cases, we shouldn't throw away */
  /* the threshold array if it exists.  Maybe add a flag to indicate */
  /* which approach should be used? */

  /* CASE 1a:  single threshold (integer) */
  if (fixp(lv_threshold)) {    
printf("got an integer threshold\n");
    d.threshold = (double) getfixnum(lv_threshold);
    d.threshold_array = NULL;
  }
  /* CASE 1b:  single threshold (float) */
  else if (floatp(lv_threshold)) {    
printf("got a float threshold\n");
    d.threshold = (double) getflonum(lv_threshold); 
    d.threshold_array = NULL;
  }
  /* CASE 2:  interpolated thresholds */
  else if (symbolp(lv_threshold)) {    
    
    /* bad :THRESHOLD keyword */
    if ((lv_threshold != k_interpolate) &&
	(lv_threshold != k_reuse_if_available)) {
      xlerror("XISO-COMPUTE-ISOSURFACE: bad :THRESHOLD keyword", lv_threshold); 
    }

printf("got a threshold keyword\n");

    /* try to grab the current array of interpolated thresholds */
    lv_threshold_array = xgrl3c_Get_Array( lv_voxels, k_threshold, NIL, TRUE );

    /* regenerate thresholds if (1) we don't have any yet, or */
    /* (2) the caller didn't ask to reuse the old ones.       */
    if ((!xf2vp( lv_threshold_array )) ||
	(lv_threshold == k_interpolate)) {

printf("creating thresholds\n");

      /* make sure we have seed points */
      if (!lv_seeds) 
	xlerror("XISO-COMPUTE-ISOSURFACE:", 
	        "interpolation requires a :SEEDS parameter");

      /* if needed, create the threshold array and add it to the voxel GRL */
      if (!xf2vp( lv_threshold_array )) {
	lv_shape     = cons(cvfixnum(d.zsize), NIL);
	lv_shape     = cons(cvfixnum(d.ysize), lv_shape);
	lv_shape     = cons(cvfixnum(d.xsize), lv_shape);
	lv_threshold_array = xsendmsg1( lv_xf2v, k_new, lv_shape );
	xsendmsg2( lv_voxels, k_setarray, k_threshold, lv_threshold_array );
      }

      /* grab the actual array we want to work with */
      d.threshold_array = (CSRY_UNSIGNED16 *) (csry_base(lv_threshold_array));
      d.threshold = 0;

      /* compute thresholds from the seeds */
      /*  computeThresholds(d); */
    }
    /* otherwise, just grab the existing array */
    else {
printf("REUSING thresholds\n");
      d.threshold_array = (CSRY_UNSIGNED16 *) (csry_base(lv_threshold_array));
      d.threshold = 0;
    }      
  } /* end else if symbolp */

  /* CASE 3:  illegal :THRESHOLD value */
  else { 
    xlerror("XISO-COMPUTE-ISOSURFACE: bad :THRESHOLD value", lv_threshold); 
  }


  /* do the real work */
  lv_isosurface = computeIsosurface(&d);

  /* free up temp arrays */
/*
  free(d.xseed);
  free(d.yseed);
  free(d.zseed);
*/

  xlpopn(toProt);
  return lv_isosurface;
}

/* }}} */
/* {{{ computeIsosurface                                                */

/*
 * Given the coordinates for some number of seed points and
 * corresponding thresholds, compute a tiled surface.
 *
 * Input:
 *   d               3D dataset (see def. of XISO_DATASET for fields)
 *
 * Output:
 *   lv_isosurface   thinglist for the resulting surface
 */
 
LVAL computeIsosurface(XISO_DATASET *d) {

  LVAL    lv_pointx;             /* coordinate arrays (as LVALs) */
  LVAL    lv_pointy;
  LVAL    lv_pointz;
  LVAL    lv_normalx;            /* point normal arrays (as LVALs) */
  LVAL    lv_normaly;
  LVAL    lv_normalz;
  LVAL    lv_facet0;             /* facet arrays (as LVALs) */
  LVAL    lv_facet1;
  LVAL    lv_facet2;
  LVAL    lv_isosurface;         /* surface thinglist */
  LVAL    lv_points;             /* point relation GRL */
  LVAL    lv_facets;             /* facet relation GRL */
  LVAL    lv_shape;              /* array dimensions */
  float   *pointx;               /* coordinate arrays */
  float   *pointy;
  float   *pointz;
  float   *normalx;              /* point normal arrays */
  float   *normaly;
  float   *normalz;
  char    *err;                  /* error string */
/*  char    *polygonize();         /* the implicit surface creator */
  VERTEX  v;                     /* temp variable */
  int     i;                     /* loop index */
  int     facet_count = 100;     /* starting guess at number of facets */
  double  max_range;             /* max number of cubes to search? */

  int        toProt = 13;
  xlstkcheck(toProt);
  xlsave(lv_pointx);
  xlsave(lv_pointy);
  xlsave(lv_pointz);
  xlsave(lv_normalx);
  xlsave(lv_normaly);
  xlsave(lv_normalz);
  xlsave(lv_facet0);
  xlsave(lv_facet1);
  xlsave(lv_facet2);
  xlsave(lv_isosurface);
  xlsave(lv_points);
  xlsave(lv_facets);
  xlsave(lv_shape);

  /* create the facet relation for the surface (this gets stored in a
   * globar var so that triangleHandler can get to it)
   */
  lv_shape  = cvfixnum(facet_count);
  lv_facets = xsendmsg1( lv_xgrl, k_new, lv_shape );
  XISO_LV_FACETS = lv_facets;

  /* create the facet arrays and add them to the point relation */
  lv_facet0 = xsendmsg1( lv_x32v, k_new, lv_shape );
  lv_facet1 = xsendmsg1( lv_x32v, k_new, lv_shape );
  lv_facet2 = xsendmsg1( lv_x32v, k_new, lv_shape );
  xsendmsg2( lv_facets, k_setarray, k_facet0, lv_facet0 );
  xsendmsg2( lv_facets, k_setarray, k_facet1, lv_facet1 );
  xsendmsg2( lv_facets, k_setarray, k_facet2, lv_facet2 );

  /* reset the fill pointer (new facets will be pushed in) */
  xsendmsg1( lv_facets, k_setf_fill_pointer, NULL );

  /* restrict surface search to the size of the cube (roughly) */
  max_range = XISO_MAX3(d->xsize, d->ysize, d->zsize) /
              (double) d->resolution;

  /* generate the polygons */
printf("finding isosurface...\n");
  if (err = 
      polygonize(thresh,                 /* surface function */
		 d->resolution,          /* width of partitioning cube */
		 max_range,              /* max. range of cubes from first */
		 (double)(d->xseed[0]),  /* starting point coords */
		 (double)(d->yseed[0]),
		 (double)(d->zseed[0]),
		 triangleHandler,        /* function called per triangle */
		 d->mode,                /* mode */
		 d))                     /* dataset */
    {
      xlerror(err);
    }

  /* create the point relation for the surface */
  lv_shape  = cvfixnum(XISO_VERTICES.count);
  lv_points = xsendmsg1( lv_xgrl, k_new, lv_shape );

  /* create the coordinate and normals arrays and */
  /* add them to the point relation */
  lv_pointx  = xsendmsg1( lv_xflv, k_new, lv_shape );
  lv_pointy  = xsendmsg1( lv_xflv, k_new, lv_shape );
  lv_pointz  = xsendmsg1( lv_xflv, k_new, lv_shape );
  lv_normalx = xsendmsg1( lv_xflv, k_new, lv_shape );
  lv_normaly = xsendmsg1( lv_xflv, k_new, lv_shape );
  lv_normalz = xsendmsg1( lv_xflv, k_new, lv_shape );
  xsendmsg2( lv_points, k_setarray, k_pointx, lv_pointx );
  xsendmsg2( lv_points, k_setarray, k_pointy, lv_pointy );
  xsendmsg2( lv_points, k_setarray, k_pointz, lv_pointz );
  xsendmsg2( lv_points, k_setarray, k_point_normalx, lv_normalx );
  xsendmsg2( lv_points, k_setarray, k_point_normaly, lv_normaly );
  xsendmsg2( lv_points, k_setarray, k_point_normalz, lv_normalz );

  /* grab the actual arrays we want to work with */
  pointx  = (float *) (csry_base( lv_pointx ));
  pointy  = (float *) (csry_base( lv_pointy ));
  pointz  = (float *) (csry_base( lv_pointz ));
  normalx = (float *) (csry_base( lv_normalx ));
  normaly = (float *) (csry_base( lv_normaly ));
  normalz = (float *) (csry_base( lv_normalz ));

  /* add vertex coordinates and normals to the surface GRL */
  for (i = 0; i < XISO_VERTICES.count; i++) {
    v = XISO_VERTICES.ptr[i];
    pointx[i]  = v.position.x;
    pointy[i]  = v.position.y;
    pointz[i]  = v.position.z;
    normalx[i] = v.normal.x;
    normaly[i] = v.normal.y;
    normalz[i] = v.normal.z;

/*
    fprintf(stdout, "%f  %f      %f\t%f	 %f  %f\n",
	    v.position.x, v.position.y,	 v.position.z,
	    v.normal.x,	  v.normal.y,	 v.normal.z);
*/
    }
  
  /* construct a thinglist for the isosurface */
  lv_isosurface = cons(lv_facets,         NIL);
  lv_isosurface = cons(k_facet_relation,  lv_isosurface);
  lv_isosurface = cons(lv_points,         lv_isosurface);
  lv_isosurface = cons(k_point_relation,  lv_isosurface);

  xlpopn(toProt);
  return lv_isosurface;
}

/* }}} */
/* {{{ triangleHandler                                                  */

/* Function that tells the polygonize routine what to do with each
 * triangle.  We'll add each one to a global GRL for the surface.
 */

int  triangleHandler (i1, i2, i3, vertices)
     int  i1, i2, i3;
     VERTICES vertices;
{

  csry_rec* h = xsry9c_Find_Immediate_Base(XISO_LV_FACETS);
  LVAL lv_facet0;
  LVAL lv_facet1;
  LVAL lv_facet2;
  LVAL lv_data;


  int        toProt = 4;
  xlstkcheck(toProt);
  xlsave(lv_facet0);
  xlsave(lv_facet1);
  xlsave(lv_facet2);
  xlsave(lv_data);

  /* debugging stuff */
  if ((i1 == i2) || (i1 == i3) || (i2 == i3)) {
    int index = 1 + h->dim[1];   /* get fill pointer */
    printf("BAD FACET: %d = (%d %d %d)\n", index, i1, i2, i3);
  }

  /* create LVAL versions of the indices */
  lv_facet0 = cvfixnum(i1);
  lv_facet1 = cvfixnum(i2);
  lv_facet2 = cvfixnum(i3);

  /* update global vertex list */
  XISO_VERTICES = vertices;

  /* build a keyword/argument list for the new facet */
  lv_data = cons(lv_facet2, NIL);
  lv_data = cons(k_facet2,  lv_data);
  lv_data = cons(lv_facet1, lv_data);
  lv_data = cons(k_facet1,  lv_data);
  lv_data = cons(lv_facet0, lv_data);
  lv_data = cons(k_facet0,  lv_data);
  
  /* add the triangle to GRL */
  /* (send grl vector-push-extend '(:facet-0 i1 :facet-1 i2 :facet-2 i3)) */
  xgrlZ0_Vector_Push_Extend(XISO_LV_FACETS, lv_data, h);

  /* print for testing purposes */
/*  printf("%d  %d  %d\n", i1, i2, i3); */

  xlpopn(toProt);
  return 1;
}

/* }}} */
/* {{{ trilinear_volume                                                 */

/* volume: return intensity at (x,y,z) in a volume dataset.  */
/* assumption:  coords in the range [0,d->xsize),[0,d->ysize),[0,d->zsize) */
double trilinear_volume (x, y, z, d)
     double x, y, z;
     XISO_DATASET *d;
{
  /* return 0 if the point is outside the volume */
  if ((x < 0) || (x >= d->xsize) ||
      (y < 0) || (y >= d->ysize) ||
      (z < 0) || (z >= d->zsize)) {
    return 0;
  }
  /* otherwise get voxel value by trilinear interpolation */
  else {
    /* compute boundary coordinates */
    int   x_lo = (int) floor(x);
    int   y_lo = (int) floor(y);
    int   z_lo = (int) floor(z);
    int   x_hi = x_lo + 1;
    int   y_hi = y_lo + 1;
    int   z_hi = z_lo + 1;

    /* compute weighting factors */
    double  x_w0 = x_hi - x;
    double  x_w1 = x    - x_lo;
    double  y_w0 = y_hi - y;
    double  y_w1 = y    - y_lo;
    double  z_w0 = z_hi - z;
    double  z_w1 = z    - z_lo;

    /* get 8 corners */
    /* (could speed up by just checking bounds once) */
    double   v_000 = (double) XISO_GET_VOXEL(d, x_lo, y_lo, z_lo);
    double   v_001 = (double) XISO_GET_VOXEL(d, x_lo, y_lo, z_hi);
    double   v_010 = (double) XISO_GET_VOXEL(d, x_lo, y_hi, z_lo);
    double   v_011 = (double) XISO_GET_VOXEL(d, x_lo, y_hi, z_hi);
    double   v_100 = (double) XISO_GET_VOXEL(d, x_hi, y_lo, z_lo);
    double   v_101 = (double) XISO_GET_VOXEL(d, x_hi, y_lo, z_hi);
    double   v_110 = (double) XISO_GET_VOXEL(d, x_hi, y_hi, z_lo);
    double   v_111 = (double) XISO_GET_VOXEL(d, x_hi, y_hi, z_hi);

    /* interpolate along x */
    double   v_x00 = (x_w0 * v_000) + (x_w1 * v_100);
    double   v_x01 = (x_w0 * v_001) + (x_w1 * v_101);
    double   v_x10 = (x_w0 * v_010) + (x_w1 * v_110);
    double   v_x11 = (x_w0 * v_011) + (x_w1 * v_111);

    /* interpolate along y */
    double   v_xy0 = (y_w0 * v_x00) + (y_w1 * v_x10);
    double   v_xy1 = (y_w0 * v_x01) + (y_w1 * v_x11);

    /* interpolate along z */
    double   v_xyz = (z_w0 * v_xy0) + (z_w1 * v_xy1);

    return v_xyz;
  }
}

/* }}} */
/* {{{ thresh                                                           */

/* thresh: threshold a volume data set -- return negative if below,
   positive if above, and 0 at the threshold */
double thresh (x, y, z, d)
double x, y, z;
XISO_DATASET *d;
{
  /* convert unsigned 12-bit int to range [0,1), then threshold */

  double  val = trilinear_volume(x, y, z, d);
  double  result;

  /* use interpolated values if they're available */
  if (d->threshold_array) {
    int offset = (int) (floor(z) +
			d->zsize * (floor(y) +
				    d->ysize * floor(x)));
    result = (val / (double)(XISO_MAX_INTENSITY)) - 
             d->threshold_array[offset];
  }

  /* otherwise use the single threshold */
  else {
    result = d->threshold - (val / (double)(XISO_MAX_INTENSITY));
  }

  return result;
}

/* }}} */

/* {{{ temporary main function (for testing purposes) */

/* this trick will leave out the main function for now */
#if 0

#ifndef CSRY_UNSIGNED16
#define CSRY_UNSIGNED16 unsigned short
#endif

#include <math.h>
#include <stdio.h>

#define SEEDS 6
#define XSIZE 4
#define YSIZE 4
#define ZSIZE 4
#define NUM_VOXELS ((XSIZE) * (YSIZE) * (ZSIZE))

void main() {

  CSRY_UNSIGNED16 intensity[NUM_VOXELS];  /* voxel intensities */
  CSRY_UNSIGNED16 threshold[NUM_VOXELS];  /* computed thresholds */
  int             xseed[SEEDS];           /* coords of seed points */
  int             yseed[SEEDS];
  int             zseed[SEEDS];
  int             i, x, y, z;
     
  /* seed the random number generator */
  srand(time(NULL));

  /* fill intensity array with random integers in [0,29] */
  for (i = 0; i < NUM_VOXELS; i++) {
    intensity[i] = rand() % 30;
  }
     
  /* pick random seed points */
  printf("SEEDS:\n");
  for (i = 0; i < SEEDS; i++) {
    xseed[i] = rand() % XSIZE;
    yseed[i] = rand() % YSIZE;
    zseed[i] = rand() % ZSIZE;
    printf("(%d,%d,%d)\n", xseed[i], yseed[i], zseed[i]);
  }

  /* compute thresholds */
  computeThresholds(SEEDS, 
		    xseed, yseed, zseed,
		    XSIZE, YSIZE, ZSIZE,
		    intensity, threshold);
}

#endif

/* }}} */

/* {{{ --- Obsolete Functions ---                                       */
/* }}} */
/* {{{ oldComputeThresholds                                             */

/* Old version of the main function for computing thresholds.
 * (Before XISO_DATASET datatype was scrapped.)
 *
 * Given the coordinates for some number of seed points, compute a
 * volume of interpolated isosurface threshold values.
 *
 * Input:
 *   d            3D dataset (see def. of XISO_DATASET for fields)
 *
 * Output:
 *   d.threshold  3D volume of intensity thresholds
 *
 * The x/y/z-offset values are used as a shortcut for incrementally
 * computing the distance from the next voxel to the seeds by using
 * the current voxel's distances.  This technique is derived from the
 * fact that consecutive squares of integers can be generated through
 * repeated addition of consecutive odd integers.  (This technique
 * assumes that distances are measured in voxel units and are, as a
 * result, integers.)
 *   
 */
 
void oldComputeThresholds(XISO_DATASET d)
{
  /* 1D arrays */
  int             *xoff;        /* current x-offset value for each seed */
  int             *yoff;        /* current y-offset value for each seed */
  int             *zoff;        /* current z-offset value for each seed */
  int             *dist;        /* current distance to each seed */
  int             *xbasedist;   /* dist from start of current plane to seeds */
  int             *ybasedist;   /* dist from start of current row to seeds */
  CSRY_UNSIGNED16 *seeds;       /* intensities for seed points */

  /* other vars */
  int             i, x, y, z;       /* loop indices */
  float           total_weight;     /* accumulated weighting factors */
  float           total_threshold;  /* accumulated weighted intensities */
  float           weight;           /* intensity weighting value */
  int             offset;           /* 1D offset into voxel array */
  int             num_voxels;       /* voxels in intensity array */
  unsigned char   DEBUG = 1;        /* flag for debug comments */


  /* create 1D arrays */
  if (DEBUG) printf("Creating arrays...\n");
  xoff      = (int *) calloc(d.num_seeds, sizeof(int));
  yoff      = (int *) calloc(d.num_seeds, sizeof(int));
  zoff      = (int *) calloc(d.num_seeds, sizeof(int));
  dist      = (int *) calloc(d.num_seeds, sizeof(int));
  ybasedist = (int *) calloc(d.num_seeds, sizeof(int));
  xbasedist = (int *) calloc(d.num_seeds, sizeof(int));
  seeds     = (CSRY_UNSIGNED16 *) calloc(d.num_seeds, sizeof(CSRY_UNSIGNED16));

  if (!(xoff && yoff && zoff && dist && ybasedist && xbasedist && seeds))
    xlerror("Unable to allocate memory");

  /* zero out entries in the threshold array */
  num_voxels = d.xsize * d.ysize * d.zsize;
  for (i = 0; i < num_voxels; i++) {
    d.threshold_array[i] = 0;
  }

  /* initialize at seeds */
  if (DEBUG) printf("Initializing seed points...\n");
  for (i = 0; i < d.num_seeds; i++) {
    x = d.xseed[i];
    y = d.yseed[i];
    z = d.zseed[i];
    offset = z + d.zsize * ( y + d.ysize * x );

    /* To avoid allocating a huge array of flags, I'm going to be
     * tricky and initialize the threshold value for each seed to be 1.
     * In the main loop, I'll check this flag to differentiate seeds
     * and non-seeds.
     */
    d.threshold_array[offset] = 1;
    seeds[i] = d.intensity[offset];

    /* compute offsets and distance between this seed and starting voxel */
    xoff[i] = -2 * x - 1;
    yoff[i] = -2 * y - 1;
    zoff[i] = -2 * z - 1;
    dist[i] =  x*x + y*y + z*z;
    ybasedist[i] = dist[i];
    xbasedist[i] = dist[i];
  }

  /* compute thresholds for all the voxels */
  if (DEBUG) printf("Computing thresholds...\n");
  offset = 0;
  for (x = 0; x < d.xsize; x++) {
    if (DEBUG) printf("Plane %d...\n", x);
    for (y = 0; y < d.ysize; y++) {
      for (z = 0; z < d.zsize; z++) {

	/* if this is a seed, just grab its intensity value */
	if (d.threshold_array[offset]) {
	  d.threshold_array[offset] = d.intensity[offset];
	}

	/* otherwise compute the weighted threshold */
	else {

	  /* clear out accumulators */
	  total_threshold = 0;
	  total_weight    = 0;

	  /* compute sum of weighted intensities */
	  for (i = 0; i < d.num_seeds; i++) {
	    weight = 1.0 / dist[i];
	    total_threshold += weight * seeds[i];
	    total_weight += weight;
	  }

	  /* normalize weighted intensity */
	  d.threshold_array[offset] = total_threshold / total_weight;
/*
	  printf("(%3d,%3d,%3d):  %5.3f / %5.3f = %3d  (%d)\n", 
		 x, y, z, 
		 total_threshold, total_weight, 
		 d.threshold_array[offset], offset);
*/
	}  /* end else */

	/* move to next voxel and compute distances to seeds */
	offset++;
	for (i = 0; i < d.num_seeds; i++) {
	  zoff[i] += 2;
	  dist[i] += zoff[i];
	}	
      }  /* end z loop */

      /* compute offsets/distances for next voxel in y-direction */
      for (i = 0; i < d.num_seeds; i++) {
	yoff[i] += 2;
	zoff[i] = -2 * d.zseed[i] - 1;
	dist[i] = ybasedist[i] + yoff[i];
	ybasedist[i] = dist[i];          /* set row's new base dist */
      }

    } /* end y loop */
      
    /* compute offsets/distances for next voxel in x-direction */
    for (i = 0; i < d.num_seeds; i++) {
      xoff[i] += 2;
      yoff[i] = -2 * d.yseed[i] - 1;
      zoff[i] = -2 * d.zseed[i] - 1;
      dist[i] = xbasedist[i] + xoff[i];
      ybasedist[i] = dist[i];           /* set row's new base dist   */
      xbasedist[i] = dist[i];           /* set plane's new base dist */
    }

  } /* end x loop */


  /* print in a decent form */
/*
  i = 0;
  printf("\n\nTHRESHOLDS\n");
  printf("(seed points are starred)\n");
  for (x = 0; x < d.xsize; x++) {
    printf("Plane %d:\n", x);
    for (y = 0; y < d.ysize; y++) {
      for (z = 0; z < d.zsize; z++) {
	printf("%3d", d.threshold_array[i]);
	if (isaseed(x, y, z, d))
	  printf("*"); 
	else
	  printf(" ");
	i++;
      }
      printf("\n");
    }
    printf("\n");
  }
*/
  /* free all the arrays we allocated */
  free(xoff);
  free(yoff);
  free(zoff);
  free(dist);
  free(ybasedist);
  free(xbasedist);
  free(seeds);
}

/* }}} */
/* {{{ Old_Compute_Thresholds_Fn	      	                	*/

/* Lisp name:  XISO-COMPUTE-THRESHOLDS
 *
 * The original version of the function to compute threshold values
 * for a volume of voxels, given a list of seed points coordinates 
 * (x y z).  The thresholds at the seed points were simply the
 * intensity values.
 */

LVAL Old_Compute_Thresholds_Fn() {

  LVAL             lv_voxels;         /* 3D voxel GRL */
  LVAL             lv_seeds;          /* seed point coordinates */
  LVAL             lv_seed;           /* single seed point */
  LVAL             lv_intensity;      /* voxel intensities */
  LVAL             lv_threshold;      /* computed threshold values */
  LVAL             lv_shape;          /* dimensions of voxel GRL */
  LVAL             lv_arg;            /* dummy lval */
  LVAL             lv_num;            /* temp number */
  XISO_DATASET     d;                 /* dataset structure */
  int              i;                 /* loop index */


  int        toProt = 8;
  xlstkcheck(toProt);
  xlsave(lv_voxels);
  xlsave(lv_seeds);
  xlsave(lv_seed);
  xlsave(lv_intensity);
  xlsave(lv_threshold);
  xlsave(lv_shape);
  xlsave(lv_arg);
  xlsave(lv_num);

  /* read the arguments */
  while ( moreargs() ) {
    
    LVAL key = xlgasymbol();

    if        (key == k_voxels) {  /* :VOXELS */
      lv_voxels = xgrl01_Get_A_XGRL();
    }
    else if   (key == k_seeds) {   /* :SEEDS */
      lv_seeds = xlgalist();
    }
    else {
      xlerror("XISO-COMPUTE-THRESHOLDS: bad keyword", key);
    }
  }

  /* make sure we got both arrays */
  if (!lv_voxels) xlfail("XISO-COMPUTE-THRESHOLDS: missing :VOXELS keyword");
  if (!lv_seeds)  xlfail("XISO-COMPUTE-THRESHOLDS: missing :SEEDS keyword");

  /* pull out the intensity array */
  lv_intensity = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
  if (!xf2vp(  lv_intensity )) {
    xlerror(":INTENSITY array is missing", lv_voxels);
  }
  xvol95_Get_X_Y_Z_Dimensions( &d.xsize, &d.ysize, &d.zsize, lv_voxels );

  /* convert the seeds list into three coordinate arrays */
  d.num_seeds = xiso_length(lv_seeds);
  d.xseed = (int *) calloc(d.num_seeds, sizeof(int));
  d.yseed = (int *) calloc(d.num_seeds, sizeof(int));
  d.zseed = (int *) calloc(d.num_seeds, sizeof(int));
  if (!(d.xseed && d.yseed && d.zseed))
    xlerror("XISO-COMPUTE-THRESHOLDS: couldn't allocate array");
  lv_arg = lv_seeds;
  for (i = 0; i < d.num_seeds; i++) {
    lv_seed = car(lv_arg);

    /* check for bad seeds */
    if (!((listp(lv_seed)) || 
	  (xiso_length(lv_seed) == 3)))
      xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_seed);
    
    /* copy seed's coords to arrays */
    lv_num = car(lv_seed);
    if      (  fixp(lv_num)) { d.xseed[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_seed); }
    lv_num = car(cdr(lv_seed));
    if      (  fixp(lv_num)) { d.yseed[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_seed); }
    lv_num = car(cdr(cdr(lv_seed)));
    if      (  fixp(lv_num)) { d.zseed[i] = getfixnum(lv_num); }
    else    { xlerror("Bad XISO-COMPUTE-THRESHOLDS seed", lv_seed); }

    /* advance to the next seed */
    lv_arg = cdr(lv_arg);
  }

  /* create the threshold array */
  /* (should we check to see if one already exists?) */
  lv_shape     = cons(cvfixnum(d.zsize), NIL);
  lv_shape     = cons(cvfixnum(d.ysize), lv_shape);
  lv_shape     = cons(cvfixnum(d.xsize), lv_shape);
  lv_threshold = xsendmsg1( lv_xf2v, k_new, lv_shape );

  /* insert the threshold array in the voxel GRL (might want to delay this) */
  xsendmsg2( lv_voxels, k_setarray, k_threshold, lv_threshold );

  /* grab the actual arrays we want to work with */
  d.intensity       = (CSRY_UNSIGNED16 *) (csry_base( lv_intensity ));
  d.threshold_array = (CSRY_UNSIGNED16 *) (csry_base( lv_threshold ));

  /* do the real work */
  oldComputeThresholds(d);

  /* free up temp arrays */
  free(d.xseed);
  free(d.yseed);
  free(d.zseed);

  xlpopn(toProt);
  return lv_threshold;
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */

