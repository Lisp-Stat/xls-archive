/*----------------------------------------------------------------------------

fou_driver.c 

This version calls Fetch All with Image, Dose Grid and Dose Values, also Point
and Volume.  It should fetch Solid as well, since it is a derived classes of
Volume.  It should also fetch both Image 2D and Image 3D, since these are both
derived classes of Image.

Test driver program for FETCH ALL and STORE ALL.

Developed for the UW/Seattle environment: Prism treatment planning system and
VAX/VMS platform.  

Actually this program is written in portable C, and only depends on the
Foundation, so it could be compiled and used anywhere that can provide C
implemetations of FETCH ALL and STORE ALL. 

This program does take advantage of one feature of the VMS C implementation to
select the input data set (see below) so it may behave differently in non-VMS
environments in some circumstances.

This program invokes FETCH ALL once.  If FETCH ALL fails, the program exits.
Otherwise, for each object that was fetched the program writes a line to stdout
telling the class of the object (but nothing else). The program then invokes
STORE ALL on everything that was fetched and exits.

This program also writes some messages to standard output as it goes.

In this version, the set of classes that FETCH ALL fetches is *hard-coded* 
into the program, as the elements of the array variable named class_names. You
have to edit this source file to change the classes.

This version reads from only a single input data set.   The name of the data
set is *hard-coded* into the program source as the string value of the
#define'd symbol IN_DATASET. In this version the value is the string
"input". In the VMS world this is actually quite flexible; if there is no file
named INPUT. in the current default directory, then the VMS
C environent interprets "input" as a logical name.  That means the input
file can be anything you wish; you simply define the logical name before
running this program, for example by typing a DCL command as follows:

	$ define input dua0:[rtpt]sample-patient.dat

This program writes only a single output data set. The name of the data set is
*hard-coded* into the program source as the string value of the #define'd
symbol OUT_DATASET.  In this version the value is the string "output". In
the UW/Seattle environment the data set name is the name of the output file.  
So, if you wish to display the output on your terminal screen instead of
sending it to a file, you can type the command:

	$ define output SYS$OUTPUT

The optional interpretation of "input" and "output" as VMS logical names 
are the only VMS-dependent behaviors of the program.  

----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 Revision History:

 Date             Pgmr                 Comments
 =============================================================================

7/30/91		J. Jacky		Begun as fetchall_driver.c
8/ 1/91		J. Jacky		First compile/run w/stub Fetch All
8/ 6/91		J. Jacky		Input param classes is a linked list
8/ 7/91		J. Jacky		Print linked list of objects returned
8/ 7/91		J. Jacky		New fou_driver.c based on 
					fetchall_driver.c.
8/ 8/91		J. Jacky		Add Point to list of classes to fetch
8/ 9/91		J. Jacky		Add #define's IN_DATASET, OUT_DATASET
8/13/91		J. Jacky		Comment out some printf's
8/13/91		J. Jacky		Fetch only classes Point, Volume, and
					 Solid, but not Contour --- they
					 will be fetched anyway as parts of
					 Volume and Solid
3/17/92		J. Jacky		New prototypes for Fetch All, Store All
					 consistent with TR-92-1 - no returned
					 structures, just return status value.
					 Also, params are not rtpt_set_t
					 structs but pointers to rtpt_set_t,
					 so classes param becomes classes_p
3/20/92         J. Jacky                Extract alloc_set fcn to fou_util.c
26-Mar-1992  J. Jacky  Modify so it fetches only POINT and VOLUME, not SOLID
 2-Apr-1992  J. Jacky  Fetch Grid Geometry and Grid Values as well
17-Apr-1992  J. Jacky  Add images
22-Jun-1992  J. Jacky  Extract list_objects to fou_util.c  
		       Rename simply fou_driver not fou_driver_images etc.
 7-Dec-1992  J. Unger  Add external declaration for alloc_set, which is 
                       defined in fou_utils.c, and is used twice below in
                       the main routine.
23-Dec-1992  J. Jacky/J. Unger make class list maximally inclusive.
31-Dec-1992  J. Jacky  Remove BLOCK from class list - we don't want it at
			top level, it will be collected from inside beams.
-----------------------------------------------------------------------------*/

#include <stdio.h>      /* Needed here because it defines NULL */

#include "rtpt.h"

extern rtpt_set_t *alloc_set();   /* fwd decl; def'ed in fou_utils.c (jmu) */

/***************************************************************************
	Main 
*****************************************************************************/

main()

{

/*******************************************************/
/* Symbolic constants - Note "#" must be in column 1!  */
/*******************************************************/

#define	IN_DATASET	"input"

#define OUT_DATASET	"output"

 /****************/ 
 /* Declarations */
 /****************/

 int i;

 /* Fetch All return status */
 enum rtpt_status_e fetchall_ret_status;

 /* Fetch All input parameters */
 rtpt_string_t data_id; 
 rtpt_set_t *classes_p; /* ptr to first element in linked list of classes */
 rtpt_set_t *class_p;   /* temp for traversing that list */
 rtpt_id_t class_name, *class_name_p;  /* also used to construct the list */
 rtpt_set_t *objects_p; /* ptr to first element in list of fetched objects */

/* array of class names for Fetch All input parameter - edit this 
    section to look for other classes */

#define N_CLASS_NAMES 7

rtpt_string_t class_names[N_CLASS_NAMES] =
{RTPT_POINT,RTPT_VOLUME,RTPT_GRID_GEOM,RTPT_GRID_VALUES,RTPT_IMAGE,RTPT_BEAM,
 RTPT_BEAM_DELIV};

 /*******************/
 /* Executable code */
 /*******************/


 /* Initialize input parameters to Fetch All. */
 data_id = IN_DATASET; 

 /* Build singly linked list as in Grogono, PROGRAMMING IN PASCAL, revised
   ed., 1980, p. 227 - 229. Syntax after K&R, 2nd ed., pps. 140 - 143 */
 classes_p = NULL;

 /* Loop thru array per K&R 2nd ed. p61. */ 
 for (i = 0; i < N_CLASS_NAMES; i++) { 

   /* allocate the new element */
   class_p = alloc_set();
   class_p -> set_element_p = (rtpt_id_t *) malloc(sizeof(rtpt_id_t));
   class_name_p = class_p -> set_element_p; /* two-step maneuver is required*/
   class_name_p -> type = class_names[i]; /* by the compiler */

   /* Insert new element at front of list */
   class_p -> next_p = classes_p;
   classes_p = class_p;

   /* printf("Just created new link, class name is |%s|\n", 
	class_name_p -> type); */

   } /* end iterating over class names */

 /* Debug */
 printf("Display linked list of class names\n");
 for (class_p = classes_p; class_p != NULL; class_p = class_p -> next_p) {
   class_name_p = class_p -> set_element_p; /* two-step maneuver is required*/
   printf(" Class name in this link is %s\n", 
	class_name_p -> type);
    }

 /* Call Fetch All */
 /* "caller must allocate the first node of the set to be filled in by Fetch"
     - Tracton and Yan, 9-Mar-1992 */
 objects_p = alloc_set();   
 fetchall_ret_status = fou_fetchall(data_id, classes_p, objects_p);

 /* Print status returned by Fetch All */
 printf("Fetch All returned status: %d\n", fetchall_ret_status);
	/* would be nice to print out #define'd value of status somehow */

 if ((fetchall_ret_status) == RTPT_ST_OK) {

   /* Print objects in linked list returned by Fetch All */
   printf("\n");
   printf("List of top-level objects returned by fou_fetchall\n");
   list_objects(objects_p);
   printf("\n");

   /* Call Store All and print returned status */
   data_id = OUT_DATASET;
   printf("Store All returned status: %d\n", 
		fou_storeall(data_id, objects_p));

   } /* end if Fetch All didn't fail */

}
