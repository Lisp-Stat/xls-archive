/* {{{ raw2rgb.c -- Conversion of raw mri datasets to sgi .rgb format.	     CrT*/
/*********************************************************************************
*
* File:         raw2rgb.c
* Description:  An incredibly quick-and-dirty hack to convert raw MRI scans
*               in the stalfos.engr.washington.edu /ciso image archive
*	        to .TIFF format. Will probably break on next scan, dunno what
*	        the space of raw fileformats they use looks like.
* Author:       Jeff Prothero
* Created:      93Sep16
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */
/* {{{ header stuff							*/

#include <stdio.h>

/* Size of matrix (256x256): */
#define RAW_IMAGE_ROWS (256)
#define RAW_IMAGE_COLS (256)
#define RAW_IMAGE_BITS_IN (16)
#define RAW_IMAGE_BITS_OUT (8)

#define RAW_IMAGE_PIXELS (RAW_IMAGE_ROWS * RAW_IMAGE_COLS)
short short_buf[ RAW_IMAGE_PIXELS ];
char   char_buf[ RAW_IMAGE_PIXELS ];
int       remap[          0x10000 ];

typedef	unsigned char U_char;
typedef	unsigned short U_short;
typedef	unsigned long U_long;

#define	howmany(x, y)	(((x)+((y)-1))/(y))
#define	streq(a,b)	(strcmp(a,b) == 0)

int     minval = 0;
int     maxval = 255;

/* }}} */
/* {{{ main -- 								*/

main(argc, argv)
int  argc;
char      *argv[];
{
    U_char *buf;
    int row, linebytes;

    argc--, argv++;
    if (!argc)   usage();
    for (; argc > 2 && argv[0][0] == '-'; argc--, argv++) {
	if (streq(argv[0], "-min")) {
	    argc--, argv++;
	    minval = atoi(argv[0]);
	    continue;
	}
	if (streq(argv[0], "-max")) {
	    argc--, argv++;
	    maxval = atoi(argv[0]);
	    continue;
	}
	usage();
    }
    remap_fill();
    while (argc--) convert_file(*argv++);
}

/* }}} */
/* {{{ map_to_8_bits -- 						*/

map_to_8_bits(d,s,i)
char*         d;
unsigned short* s;
int               i;
{   while (i --> 0)   *d++ = remap[ *s++ ];
}

/* }}} */
/* {{{ getrow -- 							*/

getRow( r, g, b, row )
short  *r,*g,*b;
int              row;
{
    int  bas = row *  RAW_IMAGE_COLS;
    int  col;
    for (col =0;   col <  RAW_IMAGE_COLS;   ++col) {
	r[col] = g[col] = b[col] = char_buf[ bas+col ];
    }
}

/* }}} */
/* {{{ convert_file -- 							*/

#include "image.h"

short sbuf[8192];
short rbuf[8192];
short gbuf[8192];
short bbuf[8192];

convert_file(filename)
char        *filename;
{
    U_char *buf;
    int row, linebytes;
    FILE *in;
    char outfilename[256];

    in = fopen(filename, "r");
    if (in == NULL) {
	fprintf(stderr, "%s: Can not open.\n", filename);
	exit(-1);
    }
    if (fread(short_buf, sizeof(short), RAW_IMAGE_PIXELS, in) != RAW_IMAGE_PIXELS){
	fprintf(stderr, "%s: Can't read %d shorts from it.\n", filename);
	exit(-2);
    }
    fclose(in);
    map_to_8_bits( char_buf, short_buf, RAW_IMAGE_PIXELS );

    {   IMAGE *oimage;
	int y, xsize, ysize, zsize;

	/* Construct filename with .rgb file extention: */
	strcpy(outfilename,filename);
	strcpy(&outfilename[strlen(outfilename)-3],"rgb");

	xsize = RAW_IMAGE_ROWS;
	xsize = RAW_IMAGE_COLS;

	oimage = iopen(outfilename,"w",RLE(1),3,xsize,ysize,3);
	for(y=0; y<ysize; y++) {
	    getRow(rbuf,gbuf,bbuf,RAW_IMAGE_ROWS-y);
	    putrow(oimage,rbuf,y,0);
	    putrow(oimage,gbuf,y,1);
	    putrow(oimage,bbuf,y,2);
	}
	iclose(oimage);
    }
}

/* }}} */
/* {{{ remap_fill -- Fill array mapping input to output values		*/

remap_fill() {
    float w = 255.0 / (float)(maxval - minval);
    int   i;
    for   (i = 0;        i < minval ;   ++i)   remap[i] =   0;
    for   (i = maxval;   i < 0x10000;   ++i)   remap[i] = 255;
    for   (i = minval;   i < maxval ;   ++i) {
        remap[i] = (int)( ((float)(i-minval))   *   w);
    }
}

/* }}} */
/* {{{ usage -- 							*/

usage() {
    fprintf(stderr, "usage: raw2rgb [options] infile ...\n");
    fprintf(stderr, "where options are:\n");
    fprintf(stderr," -min 12\t\ttake 12 as darkest interesting input pixel value\n");
    fprintf(stderr," -max 1024\t\ttake 1024 as brightest interesting input pixel value\n");
    fprintf(stderr," (values from min to max will linearly map to 0-255 on output)\n");
    fprintf(stderr, "\n");
    exit(-1);
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
