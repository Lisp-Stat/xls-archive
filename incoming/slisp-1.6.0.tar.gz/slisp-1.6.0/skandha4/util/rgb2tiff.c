/* {{{ rgb2tiff.c -- Conversion of SGI .rgb datasets to .tiff format.	     CrT*/
/*********************************************************************************
*
* File:         rgb2tiff.c
* Description:  An quick-and-dirty hack to SGI .rgb files to .TIFF format.
* Author:       Jeff Prothero
* Created:      93Sep16
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/*
 * This program was created from the libtiff 2.4 ras2tiff.c utility, which
 * carried the following copyright:
 *
 * Copyright (c) 1988, 1989, 1990, 1991 Sam Leffler
 * Copyright (c) 1991 Silicon Graphics, Inc.
 *
 * Permission to use, copy, modify, distribute, and sell this software and 
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names of
 * Sam Leffler and Silicon Graphics may not be used in any advertising or
 * publicity relating to the software without the specific, prior written
 * permission of Sam Leffler and Silicon Graphics.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL SAM LEFFLER OR SILICON GRAPHICS BE LIABLE FOR
 * ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF 
 * LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE 
 * OF THIS SOFTWARE.
 */

/* }}} */

/* {{{ history								*/

/*
 * 93May28 jsp: Folded, remap[] instead of 8-bit truncation.
 * 92May22 jsp: Created, from libtiff2.4 ras2tiff.c.
 */

/* }}} */
/* {{{ header stuff							*/

#include <stdio.h>
#include "/usr/exports/local/people/jsp/iv/include/tiffio.h"

/* Size of matrix (256x256): */
#define RAW_IMAGE_ROWS (256)
#define RAW_IMAGE_COLS (256)
#define RAW_IMAGE_BITS_IN (16)
#define RAW_IMAGE_BITS_OUT (8)

#define RAW_IMAGE_PIXELS (RAW_IMAGE_ROWS * RAW_IMAGE_COLS)
short short_buf[ RAW_IMAGE_PIXELS ];
char   char_buf[ RAW_IMAGE_PIXELS ];
int       remap[          0x10000 ];

typedef	unsigned char U_char;
typedef	unsigned short U_short;
typedef	unsigned long U_long;

#define	howmany(x, y)	(((x)+((y)-1))/(y))
#define	streq(a,b)	(strcmp(a,b) == 0)

U_short	config = PLANARCONFIG_CONTIG;
U_short	compression = COMPRESSION_NONE;
U_long	rowsperstrip = (U_long) -1;

int     minval = 0;
int     maxval = 255;

/* }}} */

/* {{{ --- fns ---							*/
/* }}} */
/* {{{ convert_file -- 							*/

#include "image.h"
#include "/usr/exports/local/people/jsp/iv/include/tiffio.h"

#define RAW_IMAGE_BITS_IN (16)
#define RAW_IMAGE_BITS_OUT (8)

#define MAXIWIDTH	8192

short rbuf[ MAXIWIDTH ];
short gbuf[ MAXIWIDTH ];
short bbuf[ MAXIWIDTH ];

unsigned char  cbuf[ MAXIWIDTH ];

convert_file(filename)
char        *filename;
{
    U_char *buf;
    int row, linebytes;
    TIFF *out;
    FILE *in;
    char outfilename[256];

    int xsize;
    int ysize;
    int zsize;

    IMAGE *image;

    image = iopen(filename,"r");
    if(!image) {
	fprintf(stderr,"rgb2tiff: can't open input file %s\n",filename);
	exit(1);
    }

    xsize = image->xsize;
    ysize = image->ysize;
    zsize = image->zsize;


    /* Construct filename with .tiff file extention: */
    strcpy(outfilename,filename);
    strcpy(&outfilename[strlen(outfilename)-3],"tiff");

    out = TIFFOpen(outfilename, "w");
    if (out == NULL)   exit(-4);
    TIFFSetField(out, TIFFTAG_IMAGEWIDTH , (U_long) xsize );
    TIFFSetField(out, TIFFTAG_IMAGELENGTH, (U_long) ysize );
    TIFFSetField(out, TIFFTAG_ORIENTATION, ORIENTATION_TOPLEFT);
    TIFFSetField(out, TIFFTAG_SAMPLESPERPIXEL, RAW_IMAGE_BITS_OUT > 8 ? 3 : 1);
    TIFFSetField(out, TIFFTAG_BITSPERSAMPLE,   RAW_IMAGE_BITS_OUT > 1 ? 8 : 1);
    TIFFSetField(out, TIFFTAG_PLANARCONFIG, config);

    /* XXX this is bogus... */
    TIFFSetField(out, TIFFTAG_PHOTOMETRIC, RAW_IMAGE_BITS_OUT == 24 ?
	PHOTOMETRIC_RGB : PHOTOMETRIC_MINISBLACK
    );
    if (compression == (U_short)-1)   compression = COMPRESSION_LZW;
    TIFFSetField(out, TIFFTAG_COMPRESSION, compression);

    linebytes = ((RAW_IMAGE_BITS_OUT * xsize +15) >> 3) & ~1;
    if (TIFFScanlineSize(out) > linebytes) {
	buf = (U_char *)malloc(linebytes);
    } else {
	buf = (U_char *)malloc(TIFFScanlineSize(out));
    }
    if (rowsperstrip != (U_long)-1) {
	rowsperstrip = (8*1024)/linebytes;
    }
    TIFFSetField(out, TIFFTAG_ROWSPERSTRIP, rowsperstrip == 0 ? 1L : rowsperstrip);

    for (row = 0;   row < ysize;   ++row) {

	if(zsize<3) {
	    getrow(image,gbuf,(ysize-1)-row,0);
	} else {
	    getrow(image,rbuf,(ysize-1)-row,0);
	    getrow(image,gbuf,(ysize-1)-row,1);
	    getrow(image,bbuf,(ysize-1)-row,2);
        }

	/* BUGGO. Taking only green for now. Ok for MRI grayscale images. */
	{   int k;
	    for (k = 0; k < xsize; ++k) cbuf[k] = gbuf[k];
	}

	if (TIFFWriteScanline(
	        out,
	        cbuf,
	        row,
	        0
	    ) < 0
	) {
	    break;
    }   }
    (void) TIFFClose(out);
}

/* }}} */

/* {{{ main -- 								*/

main(argc, argv)
int  argc;
char      *argv[];
{
    U_char *buf;
    int row, linebytes;
    TIFF *out;
    FILE *in;

    argc--, argv++;
    if (!argc)   usage();
    for (; argc > 2 && argv[0][0] == '-'; argc--, argv++) {
	if (streq(argv[0], "-none")) {
	    compression = COMPRESSION_NONE;
	    continue;
	}
	if (streq(argv[0], "-packbits")) {
	    compression = COMPRESSION_PACKBITS;
	    continue;
	}
	if (streq(argv[0], "-lzw")) {
	    compression = COMPRESSION_LZW;
	    continue;
	}
	if (streq(argv[0], "-rowsperstrip")) {
	    argc--, argv++;
	    rowsperstrip = atoi(argv[0]);
	    continue;
	}
	usage();
    }
    while (argc--) convert_file(*argv++);
}

/* }}} */
/* {{{ usage -- 							*/

usage() {
    fprintf(stderr, "usage: rgb2tiff [options] infile ...\n");
    fprintf(stderr, "where options are:\n");
    fprintf(stderr," -lzw\t\tcompress output with Lempel-Ziv & Welch encoding\n");
    fprintf(stderr," -packbits\tcompress output with packbits encoding\n");
    fprintf(stderr," -none\t\tuse no compression algorithm on output\n");
    fprintf(stderr, "\n");
    fprintf(stderr," -rowsperstrip #\tmake each strip have no more than # rows\n");
    exit(-1);
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
