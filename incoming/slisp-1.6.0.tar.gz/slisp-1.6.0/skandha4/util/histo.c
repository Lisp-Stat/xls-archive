/* {{{ histo.c -- voxel histogramming of raw mri datasets.		     CrT*/
/*************************************************************************
*
* File:         histo.c
* Description:  An incredibly quick-and-dirty hack to get some idea of the
*               pixel-value distribution in the stalfos.engr.washington.edu
*               /ciso image archive MRI scans of my brain (among others :)
* Author:       Jeff Prothero
* Created:      92May21
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */
/* {{{ history								*/

/* 
 * 93May28 jsp: Folded, generalized.
 * 92May21 jsp: Created.
*/

/* }}} */
/* {{{ header stuff							*/

#include <stdio.h>

/* Size of matrix (256x256): */
#define COUNT (0x10000)
#define HISTO_SIZE (0x10000)
#define HISTO_MASK (0x0FFFF)

/* }}} */

/* {{{ --- fns ---							*/
/* }}} */
/* {{{ maxFn -- find max value in buffer 'a'				*/

maxFn(a)
short*a;
{   short m = 0;
    int   i = COUNT;
    while (i -- > 0) {
        if (*a > m)   m = *a;
        ++a;
    }
    return m;
}

/* }}} */
/* {{{ minFn -- find min value in buffer 'a'				*/

minFn(a)
short*a;
{   int   m = 0x10000;
    int   i = COUNT;
    while (i -- > 0) {
        if (*a < m)   m = *a;
        ++a;
    }
    return m;
}

/* }}} */
/* {{{ histoFn -- accumulate value histogram of 'a' in 'histo'		*/

histoFn(a,histo)
short*a;
int*      histo;
{   int   m = 0x10000;
    int   i = COUNT;
    while (i -- > 0) {
        ++histo[ *a & HISTO_MASK ];
        ++a;
    }
    return m;
}

/* }}} */
/* {{{ histoInit -- Zero 'histo' array					*/

histoInit(histo)
int*      histo;
{   int   i = HISTO_SIZE;
    while (i -- > 0)   *histo++ = 0;
}

/* }}} */
/* {{{ histoPrint -- Asciiprint contents of 'histo' array		*/

histoPrint(histo,sections)
int*       histo,sections;
{   int   i;
    int lim = HISTO_SIZE;
    int sum = 0;
    float w = 1.0 / (((float)COUNT)*sections);
    int mask;
    while (lim > 0   &&   !histo[lim-1])   --lim;
    if (lim >   128)   mask =   3;
    if (lim >   256)   mask =   7;
    if (lim >   512)   mask =  15;
    if (lim >  1024)   mask =  31;
    if (lim >  2048)   mask =  63;
    if (lim >  4096)   mask = 127;
    if (lim >  8192)   mask = 255;
    if (lim > 16384)   mask = 511;
    printf("INTENSITY:   VOXELS   %% OF TOTAL   CUMULATIVE %% OF TOTAL\n");
    printf("----------   ------   ----------   ---------------------\n");
    for (i = 0;   i < lim;   ++i) {
        float  local = ((float)histo[i]) * w;
        float global = ((float)     sum) * w;
	sum += histo[i];
	if (!(i&mask)) {
	    printf("     %4d:   %6d   %10g   %g\n",i,histo[i],local,global);
	}
    }
}

/* }}} */
/* {{{ histo_file -- Read file, compute min/max/histo for it.		*/

histo_file( filename, pmin, pmax, histo )
char*       filename;
int                  *pmin,*pmax,*histo;
{   FILE*fd;
    short a[ COUNT ];
    int minVal, maxVal;
    int level;
    fd = fopen( filename, "r" );
    if (fd == NULL)   exit(2);
    if (fread(a,2,0x10000,fd) != 0x10000) exit(3);
    fclose(fd);
    *pmin = minFn(a);
    *pmax = maxFn(a);
    histoFn(a,histo);
}

/* }}} */
/* {{{ main -- Histogram a fileset.					*/

main(argC,argV)
int  argC;
char**    argV;
{
#ifdef OLD
    int minVal, maxVal;
    int level;
    int filMin, filMax;
    int histo[ HISTO_SIZE ];
    char filename[128];
    int first,last;
    char* format;
    if (argC != 4)   usage();
    first  = atoi(argV[1]);
    last   = atoi(argV[2]);
    format =      argV[3];
    filMin = 0x10000;
    filMax = 0x00000;
    histoInit(histo);
    ++last;
    
    for (level = first;  level < last;   ++level) {
        sprintf(filename, format,level);
	histo_file( filename, &minVal, &maxVal, histo );
	printf(
	    "file %-20s   level %3d     min d=%d x=%x   max d=%5d x=%3x\n",
	    filename,
	    level,
	    minVal,minVal,
	    maxVal,maxVal
	);
	if (filMin > minVal)   filMin = minVal;
	if (filMax < maxVal)   filMax = maxVal;
    }        
#else
    int minVal, maxVal;
    int level;
    int filMin, filMax;
    int histo[ HISTO_SIZE ];
    int i;

    filMin = 0x10000;
    filMax = 0x00000;
    histoInit(histo);
    
    for (i = 1;  i < argC;   ++i) {
	histo_file( argV[i], &minVal, &maxVal, histo );
	printf(
	    "file %-20s   level %3d     min d=%d x=%x   max d=%5d x=%3x\n",
	    argV[i],
	    level,
	    minVal,minVal,
	    maxVal,maxVal
	);
	if (filMin > minVal)   filMin = minVal;
	if (filMax < maxVal)   filMax = maxVal;
    }        
#endif
    printf(
	"Overall   min d=%d x=%x   max d=%d x=%x\n",
	filMin,filMin,
	filMax,filMax
    );
    histoPrint(histo,argC-1);
}

/* }}} */
/* {{{ usage -- Print commandline protocol and exit.			*/

usage() {
#ifdef OLD
    printf("usage: histo 1 127 jsp%%d.mrb\n");
    printf("where: 1:   first file to read.\n");
    printf("where: 127: last  file to read.\n");
    printf("where: jsp%%d.mrb: format string to product filenames.\n");
#else
    printf("usage: histo filenames\n");
#endif
    exit(1);
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
