/******************************************************************/
/* slc.c */


#include "slisp.h"
#include <stdio.h>

#ifdef DEMO

#define BUF_SIZ 4000

/* Example main program that uses the functions in slisp.h	*/
/* to implement a read-eval-print loop to the terminal. sl_Init	*/
/* and sl_Eval_Str are the two routines from slisp.h.		*/
main()
{
    char inbuf[ BUF_SIZ ];
    sl_Init();
    for (;;) {
	int   got_err;
	char* result;
	printf("> ");
	fgets( inbuf, BUF_SIZ, stdin );
	sl_Eval_Str( &got_err, &result, inbuf );
	printf(result);
    }
}

#else

/* Simple selftest of slisp.c functionality: */

static tests_done = 0;
static bugs_found = 0;

strip_nl( dst, src )
char     *dst,*src;
{
    int    c;
    while (c = *src++)    if (c != '\n')   *dst++ = c;
    *dst = '\0';
}

should_be_true( bool, got_err, result, input, expected_result )
int             bool, got_err;
char                          *result,*input,*expected_result;
{
    ++tests_done;
    if (got_err) {
        printf("***** Error during evaluation of '%s'\n", input );
	++bugs_found;
    } else if (!bool || strcmp( result, expected_result )) {
	char r[ 4096 ];
	char e[ 4096 ];
	strip_nl( r,          result );
	strip_nl( e, expected_result );
        printf("***** Error: %s gave %s, expected %s\n", input, r, e );
	++bugs_found;
    }
}

should_fail( bool, what )
int          bool;
char*              what;
{
    ++tests_done;
    if (!bool) {
        printf("***** Error: Didn't fail when trying to %s\n", what );
	++bugs_found;
    }
}

main()
{
    int   b;
    int   e;
    char* i;
    char* o;

    sl_Init();
    
    sl_Eval_Str(    &e,&o, i="(+ 3 4)" );
    should_be_true(1,e, o, i, "7\n");

    sl_Eval_Str(    &e,&o, i="(* 3 4)" );
    b = sl_Int(&e)==12;
    should_be_true( b, e, o, i, "12\n" );

    i ="(+ 3 4)";
    b = 7==sl_Int_Eval_Str(&e,&o,i);
    should_be_true( b, e,o,i, "7\n" );
    sl_Float(&e);
    should_fail(e,"fetch int as float");
    sl_String(&e);
    should_fail(e,"fetch int as string");

    i = "(* 0.5 7.0)";
    b = 3.5==sl_Float_Eval_Str(&e,&o,i);
    should_be_true( b, e,o,i,"3.5\n" );

    sl_Int(&e);
    should_fail(e,"fetch float as int");
    sl_String(&e);
    should_fail(e,"fetch float as string");

    i = "(strcat \"a\" \"bc\")";
    b = !strcmp( "abc", sl_Str_Eval_Str(&e,&o,i) );
    should_be_true( b, e,o,i,"\"abc\"\n" );
    sl_Int(&e);
    should_fail(e,"fetch string as int");
    sl_Float(&e);
    should_fail(e,"fetch string as float");

    printf("%d tests done, %d bugs found\n", tests_done, bugs_found );
}

#endif
