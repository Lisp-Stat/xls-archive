/* {{{ xpvd.c -- Hybrid-class code for lst (sublist) objects.		*/
/*******************************************************************************
*
* Author:       Jeff Prothero
* Created:      93Feb02
* Language:     C
* Package:      N/A
*
* Copyright (c) 1994, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************

/* }}} */

/* {{{ --- history ---							*/

/* 93Feb02 jsp: Created.

/* }}} */
/* {{{ --- quotables ---						*/

/************************************************************************/
/* "No, I'm not interested in developing a powerful brain.  All I'm     */
/* after is just a mediocre brain, something like the president of      */
/* American Telephone and Telegraph Company." Alan Turing, 1943.        */
/************************************************************************/

/************************************************************************/
/* Fundamental Theorem of America:  Any question of fact or policy can  */
/* be settled to everyone's satisfaction, given sufficient ammo.        */
/************************************************************************/

/* }}} */
/* {{{ --- header stuff ---						*/

  

#include "../../xcore/c/xlisp.h"

/* I suspect some of these aren't needed any more: */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <strings.h>
#include <device.h>
#include <fcntl.h>
#include <termio.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#define ERR (-1)
#define loop for(;;)

static char* xpvd25_Command();


/* fd for serial port we communicate with Panasonic on: */
static xpvd00_Port = FALSE;

/* }}} */

/* {{{ xpvd05_Init_Port -- Initialize Panasonic serial port.		*/

static char* xpvd05_Init_Port( devName )
char *                         devName; /* /dev/ttyd2 or /dev/ttyd3 */
{
    extern LVAL true;
    int fd;
    struct termio   trmStruct;

    /* Open serial port to recorder: */
    fd = open( devName, O_RDWR );
    if (fd < 0) {

        return "Couldn't open serial port";
    }

    /******************************************************/
    /* Suppress all handling possible -- in particular,   */
    /* line blocking, because protocol is single 	  */
    /* char both directions, with no returns or newlines. */
    /******************************************************/

    /* Read (part of) the current line status: */
    if (ioctl(fd,TCGETA,&trmStruct)==ERR){
        close( fd );
        return "Couldn't ioctl(TCGETA) serial port";
    }

    /* Turn off all the knobs we can reach: */
    trmStruct.c_iflag &= ~( IUCLC  | IXON  | IXOFF                  );
    trmStruct.c_oflag &= ~( OPOST  | OLCUC | ONLCR | OCRNL | OFILL  );
    trmStruct.c_lflag &= ~( ICANON | ECHO  | ECHOE | ECHOK | ECHONL );

    trmStruct.c_cc[ VMIN  ] = 0;
    trmStruct.c_cc[ VTIME ] = 1;

    /* Transmit new state back to Unix: */
    if (ioctl(fd,TCSETA,&trmStruct)==ERR){
        close( fd );
        return "Couldn't ioctl(TCSETA) serial port";
    }
    xpvd00_Port = fd;
    return NULL;
}
LVAL xpvd06_Init_Port_Fn() {
    
    char* result;
    LVAL  lv_dev = xlgastring();
    char*    dev = (char*)getstring( lv_dev );
    xllastarg();
    result = xpvd05_Init_Port( dev );
    if (result)   return cvstring( result );
    else          return NIL;
}

/* }}} */
/* {{{ xpvd10_Send_Command -- Send 'str' to Panasonic.			*/

static xpvd10_Send_Command( str )
char *                 str;
{
    char     stx         = 0x02;
    char     etx         = 0x03;

    /* Send the command: */
    write( xpvd00_Port, &stx, 1 );
    write( xpvd00_Port,  str, strlen( str ) );
    write( xpvd00_Port, &etx, 1 );
}
LVAL xpvd11_Send_Command_Fn() {
    
    char* result;
    LVAL  lv_str = xlgastring();
    char*    str = (char*)getstring( lv_str );
    xllastarg();
    xpvd10_Send_Command( str );
    return NIL;
}

/* }}} */
/* {{{ xpvd15_Flush_Input -- Eat all pending input on serial line.	*/

xpvd15_Flush_Input() {

    loop {
        char c;
        int charsRead = read( xpvd00_Port, &c, 1 );
        if (!charsRead)   break;
    }
}
LVAL xpvd16_Flush_Input_Fn() {
    xllastarg();
    xpvd15_Flush_Input();
    return NIL;
}

/* }}} */
/* {{{ xpvd20_Wait -- Wait for given Panasonic char.			*/

static char* xpvd20_Wait( c, time_out )
int                       c, time_out;
{
    char* errMsg = NULL;
    if (!xpvd00_Port)   return errMsg;
    loop {
        char ack;
        int charsRead = read( xpvd00_Port, &ack, 1 );
        if (charsRead == 0   &&   !--time_out) {
            return "No Panasonic Response!";
        }
        if (charsRead == 1) {
            /****************************************************************/
            /* Panasonic has two handshake responses:                       */
            /* It sends an ascii ACK when it has RECEIVED  the command, and */
            /* it sends an ascii ETX when it has PERFORMED them command.    */
            /* (Actually, it sends lots more stuff, which we ignore.)       */
            /* We usually wait for command completion:                      */
            /****************************************************************/
            if (ack == 0x21) { errMsg = "NAK recieved"; break; }
            if (ack == c)    {                          break; }
        }
        if (charsRead > 1)   return "charsRead > 1 ?!@#";
    }
    return errMsg;
}
LVAL xpvd21_Wait_Fn() {
    
    char* result;
    int      timeout = 400;
    int      c       = 0x3;
    if (moreargs()) {
        LVAL  lv_char    = xlgafixnum();
        c                = getfixnum( lv_char    );
    }
    if (moreargs()) {
        LVAL  lv_timeout = xlgafixnum();
        timeout          = getfixnum( lv_timeout );
    }
    xllastarg();
    result = xpvd20_Wait( c, timeout );
    if (result)   return cvstring( result );
    else          return NIL;
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
