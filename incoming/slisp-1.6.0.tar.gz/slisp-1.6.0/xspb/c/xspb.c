/************************************************************************/
/*                          	xspb.c					*/
/* Spaceball support.							*/
/************************************************************************/

/**************************************************************************
*
* File:         xspb.c
* Description:  Source code for xspb.c spaceball objects.
* Author:       Jerry Prothero
* Created:      92Mar30
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, Human Interface Technology Lab (by Jerry Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of Human Interface Technology
* Lab and Jerry Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  Human Interface Technology Lab and 
* Jerry Prothero make no representations about the suitability of this 
* software for any purpose. It is provided "as is" without express or 
* implied warranty.
* 
* HUMAN INTERFACE TECHNOLOGY LAB AND JERRY PROTHERO DISCLAIM ALL WARRANTIES 
* WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL HUMAN INTERFACE TECHNOLOGY
* LAB NOR JERRY PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to 
* prothero@hitl.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
****************************************************************************/

/************************************************************************/
/*                              contents                                */
/*									*/
/*.xspb20_Init_Msg                                                      */
/*.xspb30_Wrapup_Msg                                                    */
/*.xspb40_Get_Matrix            Convert spaceball data to matrix.       */
/*.xspb60_KeyPressed            Handle keypad events.                   */
/*.xspb70_Translation           Store translation.                      */
/*.xspb80_Rotation              Store rotation.                         */
/*		(generated via "grep '/\*\.' xspb.c")			*/
/************************************************************************/

/************************************************************************/
/*                          history   				        */
/*									*/
/* 92Mar30 jdp  Created.						*/
/************************************************************************/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gl.h>
#include "/usr/include/gl/spaceball.h"
#include <device.h>
#include <sys/types.h>
#include <malloc.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <device.h>
#include <math.h>

#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#define  Sb_ENVIRONMENT_INCLUDES
#include "sblibry.h"

extern LVAL lv_xspb;

extern LVAL s_stdout;
extern LVAL xsendmsg0();
extern LVAL xsendmsg2(); 
#define xspbp(o) (getclass(o) == lv_xspb)
#include <math.h>
#include "../../xg.3d/c/geo.h"
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/csry.h"
#include "xspb.h"

int xspb60_KeyPressed();
int xspb70_Translation();
int xspb80_Rotation();

SbMatrixType mat;
SbReal tran_vec[ 3 ];
SbReal rot_vec[  3 ];
int tran_on   = TRUE;
int rot_on    = TRUE;

/************************************************************************/
/*.xspb20_Init_Msg                                                      */
/************************************************************************/ 
xspb20_Init_Msg() { 

    char * tty_line = "/dev/ttyd1";

    if (!sbexists()) {
	printf( "\nNo spaceball, spaceball initialization failing." );
	return;
    }

    if (SbOpen( tty_line ) < 0) {
	printf( "\nCouldn't open Spaceball on line %s", tty_line );
	exit( 1 );
    }
    if (SbReset(TRUE) == -1) {
	printf(
	    "\nSpaceball didn't respond on %s, but continuing anyway",
	    tty_line
	);
    }

    /* Turn on translations and rotations: */
    SbSetBallMode( "SSV" );

    /* What to do on spaceball events: */
    SbFunctions.pressed   = xspb60_KeyPressed;
    SbFunctions.translate = xspb70_Translation;
    SbFunctions.rotate    = xspb80_Rotation;
}

/************************************************************************/
/*.xspb30_Wrapup_Msg                                                    */
/************************************************************************/
LVAL xspb30_Wrapup_Msg()
/*-
  Code executed when Skandha closes up shop.
-*/
{
    SbClose();
    return (LVAL)NULL;
}

/************************************************************************/
/*.xspb40_Get_Matrix            Convert spaceball data to matrix.       */
/************************************************************************/
xspb40_Get_Matrix( m, sbscale )
ctfm_rec *         m;
float		      sbscale;
/*-
  Convert spaceball data to matrix.
-*/
{
    int i, j;
    Matrix sbtmp;
    Matrix sbmat;

    if (!sbexists)   xlfail( "No spaceball" );

    /* Set up to get spaceball data: */
    SbWaitForPacket( 100 );
    SbCheckSpaceball();
    SbRequestBallData();

#if UNNEEDED_SPACEBALL_IS_LEFT_HANDED_COORDS
    /* Reflect various quantities to match our coord system: */
    tran_vec[2] *= -1.0;	/* Z translation.	*/
    rot_vec[ 0] *= -1.0;     	/* X rotation.		*/
    rot_vec[ 1] *= -1.0;     	/* Y rotation.		*/
#endif

    /* Scale the compoents: */
    for (i = 0;   i < 3;   i++)   tran_vec[i] *= sbscale;
    for (i = 0;   i < 3;   i++)   rot_vec[ i] *= sbscale;

    /* Build a rotate + tranlate matrix from spaceball vector: */
    rotarbaxis(sbscale, rot_vec[0], rot_vec[1], rot_vec[2], sbtmp);	
    sbtmp[3][0] = tran_vec[0];	/* X translation. */
    sbtmp[3][1] = tran_vec[1];	/* Y translation. */
    sbtmp[3][2] = tran_vec[2];	/* Z translation. */

    /* Translate from portable (double) to sgi-specific (float) matrix: */
    {   int i, j;
        for (    i = 4;   i --> 0;   ) {
            for (j = 4;   j --> 0;   ) {
		sbmat[i][j] = m->m.m[i][j];
    }   }   }

    /* Postmult spaceball location (sbmat) by above update matrix (sbtmp): */
    pushmatrix();
    loadmatrix(sbtmp);
    multmatrix(sbmat);	/* Use GL to do post-multiply         */
    getmatrix( sbmat);	/* ... there's probably a better way! */
    popmatrix();

    /* Translate from sgi-specific (float) to portable (double) matrix: */
    {   int i, j;
        for (    i = 4;   i --> 0;   ) {
            for (j = 4;   j --> 0;   ) {
		m->m.m[i][j] = sbmat[i][j];
    }   }   }
}

/************************************************************************/
/*.xspb60_KeyPressed            Handle keypad events.                   */
/************************************************************************/
xspb60_KeyPressed( keys ) 
SbUint16 	   keys;
{
    SbBeep( "cE" );
    if (keys & 1) {
	tran_on = !tran_on;
	printf( 
	    "\nfunction key #1 pressed:  translation changed to %s",
	    tran_on ? "TRUE" : "FALSE"
        );
	SbSetBallMode( tran_on ? "S" : "N" );
    }
    if (keys & 2) {
	rot_on = !rot_on;
	printf( 
	    "\nfunction key #2 pressed:  rotation changed to %s",
	    rot_on ? "TRUE" : "FALSE"
        );
	SbSetBallMode( rot_on ? "XS" : "XN" );
    }
    if (keys & 4) {
	printf( "\nfunction key #3 pressed" );
    }
    if (keys & 8) {
	printf( "\nfunction key #4 pressed" );
    }
    if (keys & 0x10) {
	printf( "\nfunction key #5 pressed" );
    }
    if (keys & 0x20) {
	printf( "\nfunction key #6 pressed" );
    }
    if (keys & 0x40) {
	printf( "\nfunction key #7 pressed" );
    }
    if (keys & 0x80) {
	printf( "\nfunction key #8 pressed:  reset spaceball" );
	SbRezero();
    }
    if (keys & 0x100) {
	printf( "\npick button pressed" );
    }
}

/************************************************************************/
/*.xspb70_Translation           Store translation.                      */
/************************************************************************/
xspb70_Translation( period, vec ) 
SbUint16 	    period;
SbReal 			    vec[3];
{
    memcpy( tran_vec, vec, sizeof(tran_vec) );
}

/************************************************************************/
/*.xspb80_Rotation              Store rotation.                         */
/************************************************************************/
xspb80_Rotation( period, vec ) 
SbUint16 	 period;
SbReal 			 vec[3];
{
    memcpy( rot_vec, vec, sizeof(rot_vec));
}



