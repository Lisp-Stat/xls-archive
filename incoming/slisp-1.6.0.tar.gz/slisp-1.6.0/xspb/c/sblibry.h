/*
 * sblibry.h
 *
 * Spaceball Library Include File
 *
 * Version: L4.05
 * Release Date:	       29 August  1989
 * Latest modification:        13 May	  1989
 *
 * Written by John Hilton, Spatial Systems Inc, May 1988
 *
 * Copyright (C) 1988 Spatial Systems Inc. All Rights Reserved.
 * Spaceball is a registered trademark of Spatial Systems Inc.
 *
 * Refer to the Spaceball Application Developer's Reference (Document
 * Number D1005) for more information on the following code.
 *
 * RESTRICTIONS
 *
 * The following code is licensed for use and distribution provided the
 * code is used exclusively in conjunction with a Spaceball.  No portion
 * may be used for other purposes without prior written permission from
 * Spatial Systems Inc.  This notice must accompany any full or partial
 * copies.
 *
 * PURPOSE
 *
 * This file provides the definitions and declarations required to
 * use the Spaceball Library and should be included in each program
 * utilizing the library.
 */

#ifndef Sb_SBLIBRY_H	    /* have we been here before? */
#define Sb_SBLIBRY_H

#include    "sbcustom.h"    /* platform configuration definitions */


#if !Sb_CHECK_ARGS

#define     Sb_ARGS1( a1 )
#define     Sb_ARGS2( a1, a2 )
#define     Sb_ARGS3( a1, a2, a3 )
#define     Sb_ARGS4( a1, a2, a3, a4 )

#else

#define     Sb_ARGS1( a1 )		   a1
#define     Sb_ARGS2( a1, a2 )		   a1, a2
#define     Sb_ARGS3( a1, a2, a3 )	   a1, a2, a3
#define     Sb_ARGS4( a1, a2, a3, a4 )	   a1, a2, a3, a4

#endif

/*============================== TYPEDEFS ===================================*/

typedef char
  SbBoolean;
typedef unsigned char
  SbUchar;
typedef short
  SbInt16;
typedef unsigned short
  SbUint16;
typedef SbReal
  SbMatrixType[ Sb_ROWS ][ Sb_COLUMNS ];
typedef struct {
    int
	(*absolute)  ( Sb_ARGS1( SbMatrixType		  )),
	(*ballatrest)( Sb_ARGS1( void			  )),
	(*ballmode)  ( Sb_ARGS1( char * 		  )),
	(*beeper)    ( Sb_ARGS1( char * 		  )),
	(*delta)     ( Sb_ARGS1( SbMatrixType		  )),
	(*echo)      ( Sb_ARGS1( char * 		  )),
	(*error)     ( Sb_ARGS1( char * 		  )),
	(*invalid)   ( Sb_ARGS2( char *, int		  )),
	(*irotate)   ( Sb_ARGS2( SbUint16, SbInt16 [ 3 ]  )),
	(*itranslate)( Sb_ARGS2( SbUint16, SbInt16 [ 3 ]  )),
	(*other)     ( Sb_ARGS2( char *, int		  )),
	(*pressed)   ( Sb_ARGS1( SbUint16		  )),
	(*released)  ( Sb_ARGS1( SbUint16		  )),
	(*reset)     ( Sb_ARGS1( char * 		  )),
	(*rotate)    ( Sb_ARGS2( SbUint16, SbReal [ 3 ]   )),
	(*translate) ( Sb_ARGS2( SbUint16, SbReal [ 3 ]   ));
}
  SbFunctionsType;

/*========================== CONSTANT DEFINITIONS ===========================*/

#ifndef FALSE
#define     FALSE			0
#endif
#ifndef TRUE
#define     TRUE			1
#endif

#define     Sb_MAXPACKET		100	/* maximum number of characters
						 * allowed in a single packet
						 */
#define     Sb_NUM_SETTINGS		11
#define     Sb_SETTINGS_LENGTH		20

/*============================ MACRO DEFINITIONS ============================*/

#define     SbBeep( s ) \
    (SbPutChar( 'B' ), SbPutStr( s ), SbPutChar( '\r' ))
#define     SbPollBall()		SbRequestBallData()   /* early name */
#define     SbRequestBallData() \
    (SbPutStr( "d\r" ), SbBallDataPending = TRUE)
#define     SbPollBeeper()		SbRequestBeeperData() /* early name */
#define     SbRequestBeeperData()	SbPutStr( "b\r" )
#define     SbRezero()			SbPutStr( "Z\r" )
#define     SbSendSync()		SbPutStr( "%sync\r" )
#define     SbSetUserGetPacket( f )	(SbUserGetPacket = (f))

/* All Spaceball specific variables are contained within a structure
 * but are referenced in programs by the following names.
 */

#define     SbInBuffer			Sb->InBuffer
#define     SbOutBuffer 		Sb->OutBuffer
#define     SbSettings			Sb->Settings
#define     SbNullRegion		Sb->NullRegion
#define     SbRS232Mode 		Sb->RS232Mode
#define     SbOutBitBuffer		Sb->OutBitBuffer
#define     SbBallMode			Sb->BallMode
#define     SbRotationMode		Sb->RotationMode
#define     SbTranslationMode		Sb->TranslationMode
#define     SbInIndex			Sb->InIndex
#define     SbOutIndex			Sb->OutIndex
#define     SbBallDataLength		Sb->BallDataLength
#define     SbNumchars			Sb->Numchars
#define     SbVersionMajor		Sb->VersionMajor
#define     SbVersionMinor		Sb->VersionMinor
#define     SbOutBitShift		Sb->OutBitShift
#define     SbUserGetPacket		Sb->UserGetPacket
#define     SbFirstTime 		Sb->FirstTime
#define     SbBallAtRest		Sb->BallAtRest
#define     SbBallDataHasPeriod 	Sb->BallDataHasPeriod
#define     SbOverflowed		Sb->Overflowed
#define     SbWatchingReset		Sb->WatchingReset
#define     SbPacking			Sb->Packing
#define     SbBallDataPending		Sb->BallDataPending
#define     SbBallModePending		Sb->BallModePending
#define     SbKeys			Sb->Keys
#define     SbTranslationFeel		Sb->TranslationFeel
#define     SbRotationFeel		Sb->RotationFeel
#define     SbPulse			Sb->Pulse
#define     SbZero			Sb->Zero
#define     SbAveragePeriod		Sb->AveragePeriod
#define     SbSpinRate			Sb->SpinRate
#define     SbTranslationFreedom	Sb->TranslationFreedom
#define     SbRotationFreedom		Sb->RotationFreedom
#define     SbXYZScalings		Sb->XYZScalings
#define     SbAbsolute			Sb->Absolute
#define     SbOrientation		Sb->Orientation
#define     SbFunctions 		Sb->Functions
#define     SbEnvironment		Sb->Environment

/*========================== GLOBAL VARIABLES ===============================*/
#ifndef vms
#define     EXTERN			extern
#else
#define     EXTERN			globalref
#endif

#ifdef Sb_DEBUG
EXTERN int Sb_debug;
#endif

EXTERN SbMatrixType
  SbIdentityMatrix;

/* The following structure is used to allow efficient code generation for a
 * single Spaceball yet provide the flexibility to use the library with
 * several Spaceball's through pointer lookup.
 */

EXTERN struct SbArrayStruct {

    char
      InBuffer[ Sb_MAXPACKET ],
      OutBuffer[ Sb_MAXPACKET ],
      Settings[ Sb_NUM_SETTINGS ][ Sb_SETTINGS_LENGTH ],
      NullRegion,
      RS232Mode[ 3 ],
      OutBitBuffer,
      BallMode[ 6 ],
      RotationMode[ 4 ],
      TranslationMode[ 4 ];

    int
      InIndex,
      OutIndex,
      BallDataLength,
      Numchars,
      VersionMajor,
      VersionMinor,
      OutBitShift,
      (*UserGetPacket)( Sb_ARGS1( char * ));
			/* allow user to intercept packets */

    SbBoolean
      FirstTime,
      BallAtRest,
      BallDataHasPeriod,
      Overflowed,
      WatchingReset,
      Packing,
      BallDataPending,
      BallModePending;

    SbUint16
      Keys,		/* current state of keys */
      TranslationFeel,
      RotationFeel,
      Pulse[ 2 ],
      Zero[ 6 ],
      AveragePeriod;

    SbReal
      SpinRate, 	  /* rate of spin */
      TranslationFreedom[ 3 ],
      RotationFreedom[ 3 ],
      XYZScalings[ 3 ];

    SbMatrixType
      Absolute,
      Orientation;

    SbFunctionsType
      Functions;

    SbEnvironmentType
      Environment;	/* contains machine environment specific information */
}
#if Sb_NUMBER_OF_SPACEBALLS == 1
  Sb[ 1 ];	    /* Sb-><variable name> is a run time absolute address */
#else
  SbArray[ Sb_NUMBER_OF_SPACEBALLS ],
  *Sb = SbArray;    /* Sb-><variable name> is a run time pointer dereference */
#define     SbCurrentSpaceball		(Sb - SbArray)
#endif

/*========================== GLOBAL FUNCTIONS ===============================*/

extern SbInt16
  SbMilliseconds(	   Sb_ARGS1( void				));

extern int
  SbOpen(		   Sb_ARGS1( char *				)),
  SbClose(		   Sb_ARGS1( void				)),
  SbInput(		   Sb_ARGS3( char *, int, SbInt16		)),
  SbOutput(		   Sb_ARGS2( char *, int			)),

  SbCheckSpaceball(	   Sb_ARGS1( void				)),
  SbConvertMatrix(	   Sb_ARGS2( SbUint16, SbMatrixType		)),
  SbGetPacket(		   Sb_ARGS1( char *				)),
  SbMatricize(		   Sb_ARGS3( SbReal, SbReal[ 3 ], SbMatrixType	)),
  SbMatrix3x3Multiply(	   Sb_ARGS3( SbMatrixType, SbMatrixType,
				     SbMatrixType			)),
  SbNullFunction(							 ),
  SbPacketReady(	   Sb_ARGS1( void				)),
  SbPackVector( 	   Sb_ARGS2( SbReal[ 3 ], SbInt16[ 3 ]		)),
  SbPackMatrix( 	   Sb_ARGS2( SbMatrixType, SbInt16[ 3 ] 	)),
  SbProcessEcho(	   Sb_ARGS1( char *				)),
  SbProcessError(	   Sb_ARGS1( char *				)),
  SbProcessInvalid(	   Sb_ARGS2( char *, int			)),
  SbProcessIRotate(	   Sb_ARGS2( SbUint16, SbInt16 [ 3 ]		)),
  SbProcessITranslate(	   Sb_ARGS2( SbUint16, SbInt16 [ 3 ]		)),
  SbProcessOther(	   Sb_ARGS2( char *, int			)),
  SbProcessPacket(	   Sb_ARGS2( char *, int			)),
  SbProcessReset(	   Sb_ARGS1( char *				)),
  SbPutBytes(		   Sb_ARGS2( char *, int			)),
  SbPutChar(		   Sb_ARGS1( char				)),
  SbPutStr(		   Sb_ARGS1( char *				)),
  SbPutWords(		   Sb_ARGS2( SbUint16 *, int			)),
  SbRequestSettings(	   Sb_ARGS1( void				)),
  SbReset(		   Sb_ARGS1( int				)),
  SbRotateAbout(	   Sb_ARGS3( SbReal, SbReal[ 3 ], SbMatrixType	)),
  SbSetAbsolute(	   Sb_ARGS1( SbMatrixType			)),
  SbSetBallMode(	   Sb_ARGS1( char *				)),
  SbSetRS232Mode(	   Sb_ARGS1( char *				)),
#if Sb_NUMBER_OF_SPACEBALLS > 1
  SbSetCurrentSpaceball(   Sb_ARGS1( int				)),
#endif
  SbSetNullRegion(	   Sb_ARGS1( char				)),
  SbSetOrientation(	   Sb_ARGS1( SbMatrixType			)),
  SbSetPulse(		   Sb_ARGS1( SbUint16 [ 2 ]			)),
  SbSetRotationFeel(	   Sb_ARGS1( char				)),
  SbSetRotationFreedom(    Sb_ARGS1( SbReal [ 3 ]			)),
  SbSetRotationMode(	   Sb_ARGS1( char [ 3 ] 			)),
  SbSetSpinRate(	   Sb_ARGS1( SbReal				)),
  SbSetTranslationFeel(    Sb_ARGS1( char				)),
  SbSetTranslationFreedom( Sb_ARGS1( SbReal [ 3 ]			)),
  SbSetTranslationMode(    Sb_ARGS1( char [ 3 ] 			)),
  SbSetXYZScalings(	   Sb_ARGS1( SbReal [ 3 ]			)),
  SbSetZero(		   Sb_ARGS1( SbUint16[ 6 ]			)),
  SbSynchronize(	   Sb_ARGS1( void				)),
  SbUnpackMatrix(	   Sb_ARGS2( char [ 6 ], SbMatrixType		)),
  SbUnpackVector(	   Sb_ARGS2( char [ 6 ], SbReal [ 3 ]		)),
  SbWaitForPacket(	   Sb_ARGS1( SbInt16				)),
  SbWaitForSync(	   Sb_ARGS1( SbInt16				)),
  SbWatchForReset(	   Sb_ARGS1( SbInt16				));

#endif	/* Sb_SBLIBRY_H */
