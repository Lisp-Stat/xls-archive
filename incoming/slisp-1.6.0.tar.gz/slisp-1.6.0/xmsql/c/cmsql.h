/* cmsql.h   */

#include <msql.h>
#define DB_MAX_LOGINS 50
#define MAX_SERVER_NAME 20
#define MAX_FORMATTED_STRING 1000
extern void msqlinit();
extern LVAL dbaddlogin();
extern LVAL cdbopen();
extern LVAL cdbclose();
extern LVAL cdbsetdb();
extern LVAL dbremovelogin();
extern LVAL sqlcmd();
/* extern int error_handler(); */
extern LVAL err_return();
extern LVAL ok_return();

struct {
  int mark;
  char server[MAX_SERVER_NAME];
  int db;    /* socket fd */
  char dbname[MAX_SERVER_NAME];
}  dblogins[DB_MAX_LOGINS];

