/* cmsql.c  */

#include "../../xcore/c/xlisp.h"
#include "cmsql.h"
#define MAXCOLCOUNT	50
#define MAXCOLSIZE	2048
#define min(a,b)	((a) > (b) ? (b) : (a))
extern LVAL true;

int currentloginslot;

/* Forward declarations */
/* int error_handler();
   int message_handler(); */

void msqlinit()
/* Initialize msql db library (and install error handler?) */
{
  int i;
  /* Initialize arrays of db-logins */
  for (i=0; i<DB_MAX_LOGINS; i++) {
    dblogins[i].mark=0;
    dblogins[i].db=-1;
    dblogins[i].dbname[0] = '\0';
  }
  
}

LVAL cdbsetdb(loginslot, dbnm)
int loginslot;
char *dbnm;
{
  if (loginslot < 0 || loginslot >= DB_MAX_LOGINS) {
    /* invalid slot number */
    xlfail("xmsql: invalid login slot number");
  }

  if (dblogins[loginslot].mark == 0) {
    /* unregistered slot number */
    xlfail("xmsql: unregistered login slot number");
  }

  if (dblogins[loginslot].db != -1) {
    /* this slot already connected to server... */
    if (msqlSelectDB(dblogins[loginslot].db,dbnm) == -1) {
      /* switch unsuccessful */
      char out[1024];
      sprintf(out,"xmsql: can't switch to database: %s",dbnm);
      xlfail(out);
    }
  }

  /* record the new name in the login slot record */
  sprintf(dblogins[loginslot].dbname,dbnm);
  return(true);
}

LVAL dbaddlogin(server, username,pwd)
char *server, *username,*pwd;
{
  /* no user or passwd for msql, so discard that crap */
  
  /* Determine if there are login record slots available. If so fill the
     next available one with the arguments and return the slot number */
  int i;
  for (i=0; i < DB_MAX_LOGINS; i++) {
    if (!dblogins[i].mark) 
      break;
  }
  if (i == DB_MAX_LOGINS)
    xlfail("xmsql: Not enough login slots, DB-REMOVE-LOGIN one first");
  
  dblogins[i].mark = 1;
  strcpy(dblogins[i].server,server);
  
  /* Return the slot number */
  return(cvfixnum(i));
}

LVAL dbremovelogin(loginslot)
int loginslot;
{
  /* Free up login slot given by loginslot */
  if ( loginslot >= 0 && loginslot < DB_MAX_LOGINS) {
    dblogins[loginslot].mark = 0;
    return(true);
  }
  else
    xlfail("xmsql: Slot number out of bounds");
}

LVAL cdbopen(loginslot)
int loginslot;
/* Open database connection to server specified in loginslot */
{
  char *dbnm;
  int dbsock;
  /* Check to be sure loginslot is within bounds */
  if ( loginslot < 0 || loginslot >= DB_MAX_LOGINS) 
    xlfail("xmsql: Slot number out of bounds");
  /* Check to be sure a valid login record is at loginslot */
  if (!dblogins[loginslot].mark)
    xlfail("xmsql: Invalid login record at loginslot");
  /* Try to open connection to database. */
  
  dbsock = msqlConnect(dblogins[loginslot].server);
  
  if (dbsock == -1)
    xlfail("xmsql: Unable to connect to database server");
  dblogins[loginslot].db = dbsock;

  /* check to see if there is a dbname */
  /* if so, use it, else use "default" */
  if (dblogins[loginslot].dbname[0]) {
    dbnm=dblogins[loginslot].dbname;
  } else {
    dbnm="default";
  }

  if (msqlSelectDB(dbsock,dbnm) == -1) {
    /* can't switch to that database */
    char msg[1024];

    /* close db socket */
    msqlClose(dbsock);
    dbsock = -1;

    sprintf(msg,"xmsql: can't connect to datbase: %s",dbnm);
    xlfail(msg);
  }

  return(true);
}
     
LVAL cdbclose(loginslot)
int loginslot;
/* Close database connection to server specified in loginslot */
{
  /* Check to be sure loginslot is within bounds */
  if ( loginslot < 0 || loginslot >= DB_MAX_LOGINS) 
    xlfail("xmsql: Slot number out of bounds");
  /* Check to be sure a valid login record is at loginslot */
  if (!dblogins[loginslot].mark)
    xlfail("xmsql: Invalid login record at loginslot");
  
  /* Close connection to database. */
  msqlClose(dblogins[loginslot].db);
  
  dblogins[loginslot].db =-1;
  return(true);
}
     


LVAL sqlcmd(loginslot, cmd)
int loginslot;
char *cmd;
{
    /* Execute cmd for given loginslot record */
    int i,r,numRows;
    LVAL result_list, rec_list, next, tail, tail_record, cell;
    char bufarray[MAXCOLCOUNT][MAXCOLSIZE], EORbuf[10];
    int dbsock;
    m_result *result;
    int keepopen=0;
    int nlvals=6;
    xlstkcheck(nlvals);
    xlsave(result_list);
    xlsave(rec_list);
    xlsave(next);
    xlsave(tail);
    xlsave(tail_record);
    xlsave(cell);
    /* Check to be sure loginslot is within bounds */
    if ( loginslot < 0 || loginslot >= DB_MAX_LOGINS) 
	xlfail("xmsql: Slot number out of bounds");
    /* Check to be sure a valid login record is at loginslot */
    if (!dblogins[loginslot].mark)
	xlfail("xmsql: Invalid login record at loginslot");
    /* Keep globalvariable currentloginslot so error handler can close
     connection if it is called */
    currentloginslot = loginslot;
    /* If cdbopen has previously been called (by DB-OPEN) then a valid
    socket should exist in the login record. If so this socket should
    be kept open at the end of this routine */
    dbsock = dblogins[loginslot].db;
    if (dbsock != -1) 
	keepopen = 1;
    else {
	cdbopen(loginslot);
	dbsock = dblogins[loginslot].db;
	}
    /* Execute command */ 
    numRows = msqlQuery(dbsock,cmd);   /* if returns -1, error */
    if (numRows == -1) {
      char msg[1024];
      sprintf(msg,"xmsql: msql server: %s",msqlErrMsg);
      xlfail(msg);
    }

    /* save results */
    result = msqlStoreResult();

    if (result) {  /* we actually have results */
      /* Construct a list of lists to save results, each field is a string, each
	 row is a list, and the returned table is a list of lists */
      result_list=NIL;
      tail_record=result_list;
      
      /* For each row */
      for (r=0;r<msqlNumRows(result);r++) {
	m_row curr_row;
	curr_row = msqlFetchRow(result);
	
	/* build a list of strings for this row;
	   see XLIST in xllist.c */
	rec_list = NIL;
	
	for (i=0; i<min(msqlNumFields(result),MAXCOLCOUNT); i++)  {
	  if (curr_row[i]) {
	    cell=cvstring(curr_row[i]);
	  } else {
	    cell=NIL;
	  }
	  next = consa(cell);
	  if (rec_list) rplacd(tail, next);
	  else rec_list = next;
	  tail = next;
	}
	
	/* then put the row list into a list of rows */
	next = consa( rec_list );
	if (result_list) rplacd(tail_record,next);
	else result_list = next;
	tail_record = next;
      }

      /* free msql result buffer */
      msqlFreeResult(result);
    }

    xlpopn(nlvals);
      
    /* Close connection depending on keepopen, and return constructed list */
    if (!keepopen) cdbclose(loginslot);
    return(result_list);
}
