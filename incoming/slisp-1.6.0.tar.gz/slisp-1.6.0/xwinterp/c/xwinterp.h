/* -*-C-*-
********************************************************************************
*
* File:         xwinterp.h
* RCS:          $Header: /usr/local/master/slisp/xwinterp/c/xwinterp.h,v 1.1.1.1 1998/06/20 03:55:46 ben Exp $
* Description:  winterp support
* Author:       Niels Mayer (Collected into this file by Jeff Prothero)
* Created:      90Nov17
* Modified:     
* Language:     C
* Package:      N/A
* Status:       X11r4 contrib tape release
*
* WINTERP 1.0 Copyright 1989 Hewlett-Packard Company (by Niels Mayer).
* XLISP version 2.1, Copyright (c) 1989, by David Betz.
*
* Permission to use, copy, modify, distribute, and sell this software and its
* documentation for any purpose is hereby granted without fee, provided that
* the above copyright notice appear in all copies and that both that
* copyright notice and this permission notice appear in supporting
* documentation, and that the name of Hewlett-Packard and David Betz not be
* used in advertising or publicity pertaining to distribution of the software
* without specific, written prior permission.  Hewlett-Packard and David Betz
* make no representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
*
* HEWLETT-PACKARD AND DAVID BETZ DISCLAIM ALL WARRANTIES WITH REGARD TO THIS
* SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
* IN NO EVENT SHALL HEWLETT-PACKARD NOR DAVID BETZ BE LIABLE FOR ANY SPECIAL,
* INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
* LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
* OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* See ./winterp/COPYRIGHT for information on contacting the authors.
* 
* Please send modifications, improvements and bugfixes to mayer@hplabs.hp.com
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_F
#endif



#ifdef MODULE_XLINIT_C_XLINIT
#endif



#ifdef MODULE_XLISP_C_WRAPUP
#endif





#ifdef MODULE_XLISP_H_GLOBALS

#define NEED_TO_REPLACE_BREAKLOOP

#undef NNODES
#undef AFMT
#undef OFFTYPE
#define NNODES		2000
#define AFMT		"%lx"
#define OFFTYPE		long

/* NOTE: WINTERP breaks save/restore functionality
   because I haven't implemented a way to make
   Xtoolkit/Motif objects (WIDGETOBJs, PIXMAPs, PIXELs,
   CALLBACKOBJs, TIMEOUTOBJs, EVHANDLEROBJs) persist across
   invocations. Currently all the code in xlimage.c just
   assumes that all pointers are xlisp pointers and
   doesn't try to handle pointers to objects created
   outside of xlisp. Implementing save/restore for
   WINTERP is doable, but is not high on my priority
   list right now. Note that WINTERP doesn't break
   save/restore for standard xlisp objects. However, since
   it doesn't work correctly I've disabled it for now. */
#undef SAVERESTORE 


#undef objectp
#ifndef PROVIDE_GOBJECT
#define objectp(x)	((x) && ((ntype(x) == OBJECT) || \
                                 (ntype(x) == XLTYPE_WIDGETOBJ)))
#else
#define objectp(x)	((x) && ((ntype(x) == OBJECT) || \
                                 (ntype(x) == GOBJECT)|| \
                                 (ntype(x) == XLTYPE_WIDGETOBJ)))
#endif


#define xtresource_p(x)  ((x) && (ntype(x) == XLTYPE_XT_RESOURCE))
#define pixel_p(x)       ((x) && (ntype(x) == XLTYPE_Pixel))
#define pixmap_p(x)      ((x) && (ntype(x) == XLTYPE_Pixmap))
#define ximage_p(x)      ((x) && (ntype(x) == XLTYPE_XImage))
#define callbackobj_p(x) ((x) && (ntype(x) == XLTYPE_CALLBACKOBJ))
#define timeoutobj_p(x)  ((x) && (ntype(x) == XLTYPE_TIMEOUTOBJ))
#define widgetobj_p(x)   ((x) && (ntype(x) == XLTYPE_WIDGETOBJ))
#define xmstring_p(x)	 ((x) && (ntype(x) == XLTYPE_XmString))
#define xevent_p(x)      ((x) && (ntype(x) == XLTYPE_XEvent))
#define xtaccelerators_p(x) ((x) && (ntype(x) == XLTYPE_XtAccelerators))
#define xttranslations_p(x) ((x) && (ntype(x) == XLTYPE_XtTranslations))
#define evhandlerobj_p(x)   ((x) && (ntype(x) == XLTYPE_EVHANDLEROBJ))

#define xlga_timeoutobj()  (testarg(typearg(timeoutobj_p)))
#define xlga_callbackobj() (testarg(typearg(callbackobj_p)))
#define xlga_ximage()      (testarg(typearg(ximage_p)))
#define xlga_widgetobj()   (testarg(typearg(widgetobj_p)))
#define xlga_xevent()	   (testarg(typearg(xevent_p)))
#define xlga_xttranslations() (testarg(typearg(xttranslations_p)))
#define xlga_xtaccelerators() (testarg(typearg(xtaccelerators_p)))
#define xlga_evhandlerobj()   (testarg(typearg(evhandlerobj_p)))
#define xlga_xmstring()     (testarg(typearg(xmstring_p)))
#endif





#ifdef MODULE_XLISP_H_GLOBALS



/* XLTYPE_XT_RESOURCE access macros */
#define get_xtresource(x)          ((x)->n_xtresource)

#ifndef Pixel
#define Pixel unsigned long	/* from <X11/Intrinsic.h> */
#endif

/* XLTYPE_Pixel access macros */
#define get_pixel(x)               ((x)->n_pixel)

#ifndef Pixmap
#define Pixmap unsigned long	/* from <X11/X.h> */
#endif

/* XLTYPE_Pixmap access macros */
#define get_pixmap(x)              ((x)->n_pixmap)

#ifndef XImage
#define XImage struct _XImage
#endif

/* XLTYPE_XImage access macros */
#define get_ximage(x)              ((x)->n_ximage)

#ifndef XmString
#define XmString char *		/* from <Xm/Xm.h> */
#endif

/* XLTYPE_XmString access macros */
#define get_xmstring(x)		   ((x)->n_xmstring)

#ifndef XEvent
#define XEvent union _XEvent	/* from <X11/Xlib.h> */
#endif

/* XLTYPE_XEvent access macros */
#define get_xevent(x)	   ((x)->n_xevent)

#ifndef Window
#define Window unsigned long
#endif

/* XLTYPE_Window access macros */
#define get_window(x)		   ((x)->n_window)

/* XLTYPE_PIXMAP_REFOBJ access macros */
#define get_pixref_pixmap(x)       ((x)->n_vdata[0])
#define set_pixref_pixmap(x,v)     ((x)->n_vdata[0] = (v))
#define get_pixref_widget(x)       ((x)->n_vdata[1])
#define set_pixref_widget(x,v)     ((x)->n_vdata[1] = (v))
#define get_pixref_resname(x)      ((x)->n_vdata[2])
#define set_pixref_resname(x,v)    ((x)->n_vdata[2] = (v))
#define PIXMAP_REFOBJ_SIZE 3

/* XLTYPE_CALLBACKOBJ access macros */
#define get_callback_widget(x)     ((x)->n_vdata[0])
#define set_callback_widget(x,v)   ((x)->n_vdata[0] = (v))
#define get_callback_name(x)       ((char *) getfixnum((x)->n_vdata[1]))
#define set_callback_name(x,v)     ((x)->n_vdata[1] = cvfixnum((FIXTYPE) (v))) /* note that (v) is of type char* */
#define get_callback_proc(x)       ((XtCallbackProc) getfixnum((x)->n_vdata[2]))
#define set_callback_proc(x,v)     ((x)->n_vdata[2] = cvfixnum((FIXTYPE) (v))) /* note that (v) is of type XtCallbackProc */
#define get_callback_closure(x)    ((x)->n_vdata[3])
#define set_callback_closure(x,v)  ((x)->n_vdata[3] = (v))
#define CALLBACKOBJ_SIZE 4

/* XLTYPE_TIMEOUTOBJ access macros */
#define get_timeout_closure(x)     ((x)->n_vdata[0])
#define set_timeout_closure(x,v)   ((x)->n_vdata[0] = (v))
#define get_timeout_id(x)          ((XtIntervalId) getfixnum((x)->n_vdata[1]))
#define set_timeout_id(x,v)        ((x)->n_vdata[1] = cvfixnum((FIXTYPE) (v))) /* note that (v) is of type XtIntervalId */
#define TIMEOUTOBJ_SIZE 2

/* XLTYPE_EVHANDLEROBJ access macros */
#define get_evhandler_widget(x)    ((x)->n_vdata[0])
#define set_evhandler_widget(x,v)  ((x)->n_vdata[0] = (v))
#define get_evhandler_mask(x)      ((long) getfixnum((x)->n_vdata[1]))
#define set_evhandler_mask(x,v)    ((x)->n_vdata[1] = cvfixnum((FIXTYPE) (v))) /* note that (v) is of type long */
#define get_evhandler_options(x)   ((long) getfixnum((x)->n_vdata[2]))
#define set_evhandler_options(x,v) ((x)->n_vdata[2] = cvfixnum((FIXTYPE) (v))) /* note that (v) is of type long */
#define get_evhandler_closure(x)   ((x)->n_vdata[3])
#define set_evhandler_closure(x,v) ((x)->n_vdata[3] = (v))
#define EVHANDLEROBJ_SIZE 4

/* XLTYPE_WIDGETOBJ access macros -- note that all OBJECT operations work
   on this type too. The main difference between this type and OBJECT
   (both of which are implemented as vectors) is that a WIDGETOBJ holds
   a single instance variable which is an immediate pointer to a WidgetID
   (as opposed to having the slot holding a pointer to an FIXNUM representing
   the WidgetID.) This slot may not be marked since it is
   not a LVAL node. Thus, special code exists in xldmem.c to prevent
   such a problem. The reason for going through all this is that we
   need to do a special operation on the widgetID when a WIDGETOBJ gets
   garbage collected (see sweep()). If the widgetID were another node,
   then the object would be considered "free" and may not hold a valid
   widgetID. Yes, this is a hack. Also, having a separate type for WIDGETOBJs
   makes some operations on WIDGETOBJs more efficient... see w_classes.c */
/* #define getclass(x)	  ((x)->n_vdata[0]) --> this macro valid for both this and OBJECT */
#define get_widgetobj_widgetID(x)   (Widget) ((x)->n_vdata[1])
#define set_widgetobj_widgetID(x,v) ((x)->n_vdata[1] = (LVAL) (v))
#define WIDGETOBJ_SIZE 1	/* this val represents the number of instance variables
				   in the object. newobject() will actually create a vector
				   of size WIDGETOBJ_SIZE+1 so as to hold the ivar and the
				   class pointer. */

#ifndef XtAccelerators
#define XtAccelerators struct _TranslationData* /* from <X11/Intrinsic.h> */
#endif

/* XLTYPE_XtAccelerators access macros */
#define get_xtaccelerators(x)         ((x)->n_xtaccelerators)

#ifndef XtTranslations
#define XtTranslations struct _TranslationData*	/* from <X11/Intrinsic.h */
#endif

/* XLTYPE_XtTranslations access macros */
#define get_xttranslations(x)	      ((x)->n_xttranslations)



/* XLTYPE_XT_RESOURCE node */
#define n_xtresource           n_info.n_xresource.xr_resource

/* XLTYPE_Pixel node */
#define n_pixel                n_info.n_xpixel.xp_pixel

/* XLTYPE_Pixmap node */
#define n_pixmap               n_info.n_xpixmap.xp_pixmap

/* XLTYPE_XImage node */
#define n_ximage               n_info.n_xximage.xx_ximage

/* XLTYPE_XmString node */
#define n_xmstring	       n_info.n_xxmstring.xx_xmstring

/* XLTYPE_XEvent node */
#define n_xevent	       n_info.n_xxevent.xx_xevent

/* XLTYPE_Window node */
#define n_window	       n_info.n_xwindow.xw_window

/* XLTYPE_XtAccelerators node */
#define n_xtaccelerators       n_info.n_xxtaccelerators.xx_xtaccelerators

/* XLTYPE_XtTranslations node */
#define n_xttranslations       n_info.n_xxttranslations.xx_xttranslations


extern LVAL cv_xtresource();	/* convert a pointer to struct _Resource_Instance */
extern LVAL cv_pixel();		/* convert a X11 Pixel to XLTYPE_Pixel */
extern LVAL cv_pixmap();	/* create a XLTYPE_Pixmap */
extern LVAL cv_ximage();	/* create a XLTYPE_XImage */
extern LVAL cv_xmstring();	/* create a XLTYPE_XmString */
extern LVAL cv_xevent();	/* create a XLTYPE_XEvent */
extern LVAL cv_window();	/* create a XLTYPE_Window */
extern LVAL cv_xtaccelerators();/* create a XLTYPE_XtAccelerators */
extern LVAL cv_xttranslations();/* create a XLTYPE_XtTranslations */
extern LVAL new_pixrefobj();	/* create a XLTYPE_PIXMAP_REFOBJ */
extern LVAL new_timeoutobj();	/* create a XLTYPE_TIMEOUTOBJ */
extern LVAL new_callbackobj();	/* create a XLTYPE_CALLBACKOBJ */
extern LVAL new_evhandlerobj();	/* create a XLTYPE_EVHANDLEROBJ */

#endif



#ifdef MODULE_XLDMEM_H_NINFO
      struct xresource {	/* XLTYPE_XTRESOURCE node */
	struct _Resource_Instance *xr_resource;
      } n_xresource;
      struct xpixel {		/* XLTYPE_Pixel node */
	Pixel xp_pixel;
      } n_xpixel;
      struct xpixmap {		/* XLTYPE_Pixmap node */
	Pixmap xp_pixmap;
      } n_xpixmap;
      struct xximage {		/* XLTYPE_XImage node */
	XImage *xx_ximage;
      } n_xximage;
      struct xxmstring {	/* XLTYPE_XmString node */
	XmString xx_xmstring;
      } n_xxmstring;
      struct xxevent {		/* XLTYPE_XEvent node */
	XEvent *xx_xevent;
      } n_xxevent;
      struct xwindow {		/* XLTYPE_Window node */
	Window xw_window;
      } n_xwindow;
      struct xxtaccelerators {
	XtAccelerators xx_xtaccelerators; /* XLTYPE_XtAccelerators node */
      } n_xxtaccelerators;
      struct xxttranslations {
	XtTranslations xx_xttranslations; /* XLTYPE_XtTranslations node */
      } n_xxttranslations;
#endif




#ifdef MODULE_XLDBUG_C_BREAKLOOP_REPLACEMENT
/*
 * This version of breakloop() works with server in winterp.c. It allows you
 * to be in the breakloop while X Events and Xlisp server requests to be
 * processed.
 */
#include <X11/Intrinsic.h>
LOCAL int breakloop(hdr,cmsg,emsg,arg,cflag)
     char *hdr,*cmsg,*emsg; LVAL arg; int cflag;
{
  extern int read_eval_print_just_called; /* from winterp.c */
  extern int lisp_reader_hit_eof; /* from winterp.c */
  extern XtAppContext app_context; /* from winterp.c */
  LVAL expr,val;
  CONTEXT cntxt;
  int type;
  XEvent event;

  xlerrprint(hdr,cmsg,emsg,arg); /* print the error message */

  /* flush the input buffer --  needed if using (read)/(read-line) from stdin */
  xlflush();

  if (getvalue(s_tracenable)) {	/* do the back trace */
    val = getvalue(s_tlimit);
    xlbaktrace(fixp(val) ? (int)getfixnum(val) : -1);
  }
  xlsave1(expr);		/* protect some pointers */
  ++xldebug;			/* increment the debug level */

  read_eval_print_just_called = TRUE; /* special initial cond */
  lisp_reader_hit_eof = FALSE;

  /* debug command processing loop -- note similarity to loop winterp.c:main() */
  xlbegin(&cntxt,CF_BRKLEVEL|CF_CLEANUP|CF_CONTINUE,true);
  for (type = 0; type == 0; ) {
    /* 
     * We need to setup a new error return only after each time that an XLISP 
     * evaluation occurs. Therefore, we check for read_eval_print_just_called 
     * (which is set by Read_Eval_Print()) and then clear it once the setjmp() 
     * has been done. This avoids setting up an error return for each X event
     * being processed in this loop. 
     */
    if (read_eval_print_just_called) { /* set in winterp.c:Read_Eval_Print callback */
      read_eval_print_just_called = FALSE;
      if (lisp_reader_hit_eof) {	/* set in winterp.c:Read_Eval_Print callback */
	type = CF_CLEANUP;
	break;
      }
      if (type = setjmp(cntxt.c_jmpbuf)) /* setup the continue trap */
	switch (type) {
	case CF_CLEANUP:
	  continue;
	case CF_BRKLEVEL:
	  type = 0;
	  break;
	case CF_CONTINUE:
	  if (cflag) {
	    dbgputstr("[ continue from break loop ]\n");
	    continue;
	  }
	  else 
	    xlabort("this error can't be continued");
	}
      sprintf(buf, "XLisp-Breakloop-Level-%d> ", xldebug); /* print a "prompt" */
      dbgputstr(buf);
      fflush(stdout); fflush(stderr); /* otherwise output won't happen while blocked in XtAppNextEvent() */
    }

    /*
     * XtAppNextEvent() waits for Xevents, and while it is waiting, it will
     * process inputs added via AtAppAddInput() or XtAppAddWorkProc(). Lisp 
     * server input will cause Read_Eval_Print() to get called, and that
     * procedure sets the globals lisp_reader_hit_eof and 
     * read_eval_print_just_called. Read_Eval_Print() sends a bogus 
     * XAnyEvent (event.type == 0) so as to force XtAppNextEvent() to return; 
     * otherwise it would only return if a lisp evaluation caused X events 
     * to be generated, which means that XLISP error returns for non-X 
     * evaluations wouldn't get set up properly.
     *
     * XtDispatchEvent() will dispatch the actions from the events gathered
     * by XtAppNextEvent(). Note that XtAppNextEvent() ignores the aforementioned
     * bogus events: "if (event->type == 0) return;"
     */
    XtAppNextEvent(app_context, &event);
    XtDispatchEvent(&event);
  }
  xlend(&cntxt);

  --xldebug;			/* decrement the debug level */
  xlpop();			/* restore the stack */
  if (type == CF_CLEANUP)	/* check for aborting to the previous level */
    xlbrklevel();
}
#endif





#ifdef MODULE_XLDMEM_C_GLOBALS

extern LVAL v_savedobjs;
extern void Wxms_Garbage_Collect_XmString(); /* w_XmString.c */
extern void Wpm_Decr_Refcount_Or_Free_Pixmap();	/* w_pixmap.c */
extern void Wcls_Garbage_Collect_WIDGETOBJ(); /* w_classes.c */

/* cv_xtresource - convert a xtresource instance to an XLTYPE_XT_RESOURCE node */
LVAL cv_xtresource(res)
     struct _Resource_Instance *res;
{
  LVAL val;
  val = newnode(XLTYPE_XT_RESOURCE);
  val->n_xtresource = res;
  return (val);
}

/* cv_pixel - convert a Pixel to an XLTYPE_Pixel node */
LVAL cv_pixel(pixel)
     Pixel pixel;
{
  LVAL val;
  val = newnode(XLTYPE_Pixel);
  val->n_pixel = pixel;
  return (val);
}

/* cv_pixmap - allocate and initialize a new XLTYPE_Pixmap node */
LVAL cv_pixmap(pixmap)
     Pixmap pixmap;
{
  LVAL val;
  val = newnode(XLTYPE_Pixmap);
  val->n_pixmap = pixmap;
  return (val);
}

/* cv_ximage -- allocate and initialize a new XLTYPE_XImage node */
LVAL cv_ximage(ximage)
     XImage *ximage;
{
  LVAL val;
  val = newnode(XLTYPE_XImage);
  val->n_ximage = ximage;
  return (val);
}

/* cv_xmstring -- allocate and initialize a new XLTYPE_XmString node */
LVAL cv_xmstring(xmstr)
     XmString xmstr;
{
  LVAL val;
  val = newnode(XLTYPE_XmString);
  val->n_xmstring = xmstr;
  return (val);
}

/* cv_xevent_ptr -- allocate and initialize a new XLTYPE_XEvent node */
LVAL cv_xevent(xevp)
     XEvent *xevp;
{
  LVAL val;
  val = newnode(XLTYPE_XEvent);
  val->n_xevent = xevp;
  return (val);
}

/* cv_window -- allocate and initialize a new XLTYPE_Window node */
LVAL cv_window(win)
     Window win;
{
  LVAL val;
  val = newnode(XLTYPE_Window);
  val->n_window = win;
  return (val);
}

/* cv_xtaccelerators -- allocate and initialize a new XLTYPE_XtAccelerators node */
LVAL cv_xtaccelerators(axl)
     XtAccelerators axl;
{
  LVAL val;
  val = newnode(XLTYPE_XtAccelerators);
  val->n_xtaccelerators = axl;
  return (val);
}

/* cv_xttranslations -- allocate and initialize a new XLTYPE_XtTranslations node */
LVAL cv_xttranslations(txl)
     XtTranslations txl;
{
  LVAL val;
  val = newnode(XLTYPE_XtTranslations);
  val->n_xttranslations = txl;
  return (val);
}

/* new_pixrefobj() -- allocate and initialize a new XLTYPE_PIXMAP_REFOBJ */
LVAL new_pixrefobj()
{
  LVAL val;
  val = newvector(PIXMAP_REFOBJ_SIZE);
  val->n_type = XLTYPE_PIXMAP_REFOBJ;
  return (val);
}

/* new_callbackobj() -- allocate and initialize a new XLTYPE_CALLBACKOBJ */
LVAL new_callbackobj()
{
  LVAL val;
  val = newvector(CALLBACKOBJ_SIZE);
  val->n_type = XLTYPE_CALLBACKOBJ;
  return (val);
}

/* new_timeoutobj() -- allocate and initialize a new XLTYPE_TIMEOUTOBJ */
LVAL new_timeoutobj()
{
  LVAL val;
  val = newvector(TIMEOUTOBJ_SIZE);
  val->n_type = XLTYPE_TIMEOUTOBJ;
  return (val);
}

/* new_evhandlerobj() -- allocate and initialize a new XLTYPE_EVHANDLEROBJ */
LVAL new_evhandlerobj()
{
  LVAL val;
  val = newvector(EVHANDLEROBJ_SIZE);
  val->n_type = XLTYPE_EVHANDLEROBJ;
  return (val);
}
#endif


#ifdef MODULE_XLDMEM_C_GC
    /* mark the callback-obj's, timeout-obj's, etc that are "referenced"
       inside Motif/Xtoolkit implementation. */
    if (v_savedobjs)
        mark(v_savedobjs);
#endif


#ifdef MODULE_XLDMEM_C_MARK
case XLTYPE_WIDGETOBJ:
  /* 
   * An XLTYPE_WIDGETOBJ is just like a OBJECT node with slot 0
   * being the class, and the other slots being instance
   * variables. class WIDGET_CLASS defines a special instance
   * variable at slot 1 holding the WidgetID. Since that slot
   * isn't an LVAL, it should not be mark()'d. Any additional
   * slots means that the WIDGETOBJ was subclassed and new
   * instance variables were added in the subclass which need to
   * be marked.
   */
  if (tmp = getelement(this, 0))
    mark(tmp);
  /* HACK: skip element 1 since it's special, start at 2 */
  for (i = 2, n = getsize(this) - 2; --n >= 0; ++i)
    if ((tmp = getelement(this,i)))
      mark(tmp);
  break;
case XLTYPE_TIMEOUTOBJ:
case XLTYPE_CALLBACKOBJ:
case XLTYPE_PIXMAP_REFOBJ:
case XLTYPE_EVHANDLEROBJ:
goto vector;
#endif



#ifdef MODULE_XLDMEM_C_SWEEP
case XLTYPE_XmString:
	Wxms_Garbage_Collect_XmString(p);
	break;
case XLTYPE_Pixmap:
        /* Tell Motif that the X11 Pixmap is no longer ref'd: */
	Wpm_Decr_Refcount_Or_Free_Pixmap(p);
	break;
case XLTYPE_WIDGETOBJ:
	/* During initialization (:isnew method), we stored
	   a pointer to WIDGETOBJ in the XmNuserData
	   resource. We must clear this since it will be
	   invalid after the WIDGETOBJ is garbage colected */
	Wcls_Garbage_Collect_WIDGETOBJ(p);
		/* fall through to "VECTOR" case */
case XLTYPE_TIMEOUTOBJ:
case XLTYPE_CALLBACKOBJ:
case XLTYPE_PIXMAP_REFOBJ:
case XLTYPE_EVHANDLEROBJ:
goto vector;
#endif



#ifdef MODULE_XLDMEM_C_XLMINIT
    v_savedobjs = NIL;
#endif



#ifdef MODULE_XLGLOB_C_GLOBALS
/* additional type names for winterp*/
LVAL a_XtAccelerators=NIL, a_XtTranslations=NIL, a_XtCallbackList=NIL,
  a_XEvent=NIL, a_Window=NIL, a_Pixel=NIL, a_Pixmap=NIL, a_XImage=NIL,
  a_XmString=NIL, a_XmFontList=NIL, a_caddr_t=NIL, a_XT_RESOURCE=NIL,
  a_CALLBACKOBJ=NIL, a_TIMEOUTOBJ=NIL, a_PIXMAP_REFOBJ=NIL, a_WIDGETOBJ=NIL,
  a_EVHANDLEROBJ=NIL;

/* A vector that is marked so that winterp objects referenced inside MOTIF
   or Xtoolkit code don't get garbage collected (see w_savedobjs.c) */
LVAL v_savedobjs=NIL;
#endif



#ifdef MODULE_XLIMAGE_C_XLISAVE
case XLTYPE_TIMEOUTOBJ:
case XLTYPE_CALLBACKOBJ:
case XLTYPE_EVHANDLEROBJ:
case XLTYPE_PIXMAP_REFOBJ:
case XLTYPE_WIDGETOBJ:
goto vector;
#endif


#ifdef MODULE_XLIMAGE_C_XLIRESTORE
case XLTYPE_TIMEOUTOBJ:
case XLTYPE_CALLBACKOBJ:
case XLTYPE_PIXMAP_REFOBJ:
case XLTYPE_WIDGETOBJ:
case XLTYPE_EVHANDLEROBJ:
goto vector;
#endif



#ifdef MODULE_XLIMAGE_C_FREEIMAGE
case XLTYPE_TIMEOUTOBJ:
case XLTYPE_CALLBACKOBJ:
case XLTYPE_PIXMAP_REFOBJ:
case XLTYPE_WIDGETOBJ:
case XLTYPE_EVHANDLEROBJ:
goto vector;
#endif



#ifdef MODULE_XLINIT_C_GLOBALS
extern LVAL a_XtAccelerators, a_XtTranslations, a_XtCallbackList, a_XEvent,
  a_Window, a_Pixel, a_Pixmap, a_XImage, a_XmString, a_XmFontList,
  a_caddr_t, a_XT_RESOURCE, a_CALLBACKOBJ, a_TIMEOUTOBJ, a_PIXMAP_REFOBJ,
  a_WIDGETOBJ, a_EVHANDLEROBJ;
#endif



#ifdef MODULE_XLINIT_C_XLSYMBOLS
    a_XtAccelerators = xlenter("XT_ACCELERATORS");
    a_XtTranslations = xlenter("XT_TRANSLATIONS");
    a_XtCallbackList = xlenter("XT_CALLBACKLIST");
    a_XEvent = xlenter("XEVENT");
    a_Window = xlenter("WINDOW");
    a_Pixel = xlenter("PIXEL");
    a_Pixmap = xlenter("PIXMAP");
    a_XImage = xlenter("XIMAGE");
    a_XmString = xlenter("XM_STRING");
    a_XmFontList = xlenter("XM_FONT_LIST");
    a_caddr_t = xlenter("CADDR_T");
    a_XT_RESOURCE = xlenter("XT_RESOURCE");
    a_CALLBACKOBJ = xlenter("CALLBACK_OBJ");
    a_TIMEOUTOBJ = xlenter("TIMEOUT_OBJ");
    a_PIXMAP_REFOBJ = xlenter("PIXMAP_REFOBJ");
    a_WIDGETOBJ = xlenter("WIDGET_OBJ");
    a_EVHANDLEROBJ = xlenter("EVHANDLER_OBJ");
#endif

#ifdef MODULE_XLPRIN_C_GLOBALS
extern LVAL Wres_Get_Symbol();	/* w_resources.c */
#endif

#ifdef MODULE_XLPRIN_C_XLPRINT
    case XLTYPE_XtAccelerators:
	    putatm(fptr, "XtAccelerators", vptr);
	    break;
    case XLTYPE_XtTranslations:
	    putatm(fptr, "XtTranslations", vptr);
	    break;
    case XLTYPE_XEvent:
	    putatm(fptr, "XEvent", vptr);
	    break;
    case XLTYPE_Window:
	    putatm(fptr, "Window", vptr);
	    break;
    case XLTYPE_Pixel:
	    putatm(fptr, "Pixel", vptr);
	    break;
    case XLTYPE_Pixmap:
	    putatm(fptr, "Pixmap", vptr);
	    break;
    case XLTYPE_XImage:
	    putatm(fptr, "XImage", vptr);
	    break;
    case XLTYPE_XmString:
	    putatm(fptr, "XmString", vptr);
	    break;
    case XLTYPE_XT_RESOURCE:
	    putsymbol(fptr,
		      getstring(getpname(Wres_Get_Symbol(vptr))),
		      flag);
	    break;
    case XLTYPE_CALLBACKOBJ:
	    putatm(fptr, "CALLBACK-OBJ", vptr);
	    break;
    case XLTYPE_TIMEOUTOBJ:
	    putatm(fptr, "TIMEOUT-OBJ", vptr);
	    break;
    case XLTYPE_PIXMAP_REFOBJ:
	    putatm(fptr, "PIXMAP-REFOBJ", vptr);
	    break;
    case XLTYPE_WIDGETOBJ:
	    Wcls_Print_WIDGETOBJ(fptr, vptr); /* from w_classes.c */
	    break;
     case XLTYPE_EVHANDLEROBJ:
	    putatm(fptr, "EVHANDLER-OBJ", vptr);
	    break;
#endif



#ifdef MODULE_XLSYS_C_GLOBALS
extern LVAL a_XtAccelerators, a_XtTranslations, a_XtCallbackList, a_XEvent,
  a_Window, a_Pixel, a_Pixmap, a_XImage, a_XmString, a_XmFontList,
  a_caddr_t, a_XT_RESOURCE, a_CALLBACKOBJ, a_TIMEOUTOBJ, a_PIXMAP_REFOBJ,
  a_WIDGETOBJ, a_EVHANDLEROBJ;
#endif



#ifdef MODULE_XLSYS_C_XTYPE
    case XLTYPE_XtAccelerators: return (a_XtAccelerators);
    case XLTYPE_XtTranslations: return (a_XtTranslations);
    case XLTYPE_XtCallbackList: return (a_XtCallbackList);
    case XLTYPE_XEvent:		return (a_XEvent);
    case XLTYPE_Window:         return (a_Window);
    case XLTYPE_Pixel:          return (a_Pixel);
    case XLTYPE_Pixmap:         return (a_Pixmap);
    case XLTYPE_XImage:         return (a_XImage);
    case XLTYPE_XmString:	return (a_XmString);
    case XLTYPE_XmFontList:     return (a_XmFontList);
    case XLTYPE_caddr_t:        return (a_caddr_t);
    case XLTYPE_XT_RESOURCE:    return (a_XT_RESOURCE);
    case XLTYPE_CALLBACKOBJ:    return (a_CALLBACKOBJ);
    case XLTYPE_TIMEOUTOBJ:     return (a_TIMEOUTOBJ);
    case XLTYPE_PIXMAP_REFOBJ:  return (a_PIXMAP_REFOBJ);
    case XLTYPE_WIDGETOBJ:      return (a_WIDGETOBJ);
    case XLTYPE_EVHANDLEROBJ:   return (a_EVHANDLEROBJ);
#endif
