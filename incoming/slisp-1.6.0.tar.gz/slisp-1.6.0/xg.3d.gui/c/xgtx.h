/* {{{ xgtx.h -- text-input (GeT teXt) objects.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jul27
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xgtx;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xgtx00_Is_New();
extern LVAL xgtx08_Copy_Msg();
extern LVAL xgtx03_Show_Msg();
extern LVAL xgtx40_Get_Msg();
extern LVAL xgtx42_Put_Msg();
extern LVAL xgtx52_AppendChar_Msg();
extern LVAL xgtx55_DeleteChar_Msg();
extern LVAL xgtx58_ClearString_Msg();
extern LVAL xgtx65_Downclick_Fn();
extern LVAL xgtx67_Upclick_Fn();
extern LVAL xgtx69_Drag_Fn();
extern LVAL xgtx79_Insert_Msg();
extern LVAL xgtx91_ProplistLength_Msg();
extern LVAL xgtx95_ProplistNth_Msg();

#ifndef EXTERNED_STRING
extern LVAL k_string;/* Keyword ":string" */
#define EXTERNED_STRING
#endif

#ifndef EXTERNED_STRINGASFLOAT
extern LVAL k_stringasfloat;/* Keyword ":string-as-float" */
#define EXTERNED_STRINGASFLOAT
#endif

#ifndef EXTERNED_STRINGFONT
extern LVAL k_stringfont;/* Keyword ":string-font" */
#define EXTERNED_STRINGFONT
#endif

#ifndef EXTERNED_STRINGHEIGHT
extern LVAL k_stringheight;/* Keyword ":string-height" */
#define EXTERNED_STRINGHEIGHT
#endif

#ifndef EXTERNED_STRINGDEPTH
extern LVAL k_stringdepth;/* Keyword ":string-depth" */
#define EXTERNED_STRINGDEPTH
#endif

#ifndef EXTERNED_S_XG3DGUIXGTXDOWNCLICKFN
extern LVAL s_xg3dguixgtxdownclickfn;/* Symbol "xg.3d.gui-xgtx-downclick-fn" */
#define EXTERNED_S_XG3DGUIXGTXDOWNCLICKFN
#endif

#ifndef EXTERNED_S_XG3DGUIXGTXDRAGFN
extern LVAL s_xg3dguixgtxdragfn;/* Symbol "xg.3d.gui-xgtx-drag-fn" */
#define EXTERNED_S_XG3DGUIXGTXDRAGFN
#endif

#ifndef EXTERNED_S_XG3DGUIXGTXUPCLICKFN
extern LVAL s_xg3dguixgtxupclickfn;/* Symbol "xg.3d.gui-xgtx-upclick-fn" */
#define EXTERNED_S_XG3DGUIXGTXUPCLICKFN
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,			xgtx00_Is_New			)
DEFINE_SUBR(	NULL,			xgtx08_Copy_Msg			)
DEFINE_SUBR(	NULL,			xgtx03_Show_Msg			)
DEFINE_SUBR(	NULL,			xgtx40_Get_Msg			)
DEFINE_SUBR(	NULL,			xgtx42_Put_Msg			)
DEFINE_SUBR(    NULL,			xgtx52_AppendChar_Msg		)
DEFINE_SUBR(	NULL,			xgtx55_DeleteChar_Msg		)
DEFINE_SUBR(	NULL,			xgtx58_ClearString_Msg		)
DEFINE_SUBR(	"XG.3D.GUI-XGTX-DOWNCLICK-FN",xgtx65_Downclick_Fn		)
DEFINE_SUBR(	"XG.3D.GUI-XGTX-UPCLICK-FN",	xgtx67_Upclick_Fn		)
DEFINE_SUBR(	"XG.3D.GUI-XGTX-DRAG-FN",	xgtx69_Drag_Fn			)
DEFINE_SUBR(	NULL,			xgtx79_Insert_Msg		)
DEFINE_SUBR(	NULL,			xgtx91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,			xgtx95_ProplistNth_Msg		)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLINIT
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xgtx;
LOCAL struct xgtx_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xgtx_table[] = {
    {	":ISNEW",		xgtx00_Is_New			},
    {	":COPY",		xgtx08_Copy_Msg			},
    {	":SHOW",		xgtx03_Show_Msg			},
    {	":GET", 		xgtx40_Get_Msg			},
    {	":SET", 		xgtx42_Put_Msg			},
    {	":APPEND-CHAR",		xgtx52_AppendChar_Msg		},
    {	":DELETE-CHAR",		xgtx55_DeleteChar_Msg		},
    {	":CLEAR-STRING",	xgtx58_ClearString_Msg		},
    {	":INSERT",		xgtx79_Insert_Msg		},
    {	":PROPERTY-LIST-LENGTH",xgtx91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xgtx95_ProplistNth_Msg		},

    {	NULL,			NULL				}
};

#ifndef DEFINED_STRING
LVAL k_string;/* Keyword ":string" */
#define DEFINED_STRING
#endif

#ifndef DEFINED_STRINGASFLOAT
LVAL k_stringasfloat;/* Keyword ":string-as-float" */
#define DEFINED_STRINGASFLOAT
#endif

#ifndef DEFINED_STRINGFONT
LVAL k_stringfont;/* Keyword ":string-font" */
#define DEFINED_STRINGFONT
#endif

#ifndef DEFINED_STRINGHEIGHT
LVAL k_stringheight;/* Keyword ":string-height" */
#define DEFINED_STRINGHEIGHT
#endif

#ifndef DEFINED_STRINGDEPTH
LVAL k_stringdepth;/* Keyword ":string-depth" */
#define DEFINED_STRINGDEPTH
#endif

#ifndef DEFINED_S_XG3DGUIXGTXUPCLICKFN
LVAL s_xg3dguixgtxupclickfn;/* Symbol "xg.3d.gui-xgtx-upclick-fn" */
#define DEFINED_S_XG3DGUIXGTXUPCLICKFN
#endif

#ifndef DEFINED_S_XG3DGUIXGTXDRAGFN
LVAL s_xg3dguixgtxdragfn;/* Symbol "xg.3d.gui-xgtx-drag-fn" */
#define DEFINED_S_XG3DGUIXGTXDRAGFN
#endif

#ifndef DEFINED_S_XG3DGUIXGTXDOWNCLICKFN
LVAL s_xg3dguixgtxdownclickfn;/* Symbol "xg.3d.gui-xgtx-downclick-fn" */
#define DEFINED_S_XG3DGUIXGTXDOWNCLICKFN
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_STRING
    k_string = xlenter(":STRING");
#define CREATED_STRING
#endif

#ifndef CREATED_STRINGASFLOAT
    k_stringasfloat = xlenter(":STRING-AS-FLOAT");
#define CREATED_STRINGASFLOAT
#endif

#ifndef CREATED_STRINGFONT
    k_stringfont = xlenter(":STRING-FONT");
#define CREATED_STRINGFONT
#endif

#ifndef CREATED_STRINGHEIGHT
    k_stringheight = xlenter(":STRING-HEIGHT");
#define CREATED_STRINGHEIGHT
#endif

#ifndef CREATED_STRINGDEPTH
    k_stringdepth = xlenter(":STRING-DEPTH");
#define CREATED_STRINGDEPTH
#endif

#ifndef CREATED_S_XG3DGUIXGTXUPCLICKFN
    s_xg3dguixgtxupclickfn = xlenter("XG.3D.GUI-XGTX-UPCLICK-FN");
#define CREATED_S_XG3DGUIXGTXUPCLICKFN
#endif

#ifndef CREATED_S_XG3DGUIXGTXDRAGFN
    s_xg3dguixgtxdragfn = xlenter("XG.3D.GUI-XGTX-DRAG-FN");
#define CREATED_S_XG3DGUIXGTXDRAGFN
#endif

#ifndef CREATED_S_XG3DGUIXGTXDOWNCLICKFN
    s_xg3dguixgtxdownclickfn = xlenter("XG.3D.GUI-XGTX-DOWNCLICK-FN");
#define CREATED_S_XG3DGUIXGTXDOWNCLICKFN
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xgtx = xgbj58_Create_Class("CLASS-STRING-READER",lv_x03d);
    xgbj57_Add_Instance_Variable( lv_xgtx,"BODY-THING");
    xgbj57_Add_Instance_Variable( lv_xgtx,"FIELD-THING");
    xgbj57_Add_Instance_Variable( lv_xgtx,"TEXT-THING");
    xgbj56_Enter_Messages(        lv_xgtx,  xgtx_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
