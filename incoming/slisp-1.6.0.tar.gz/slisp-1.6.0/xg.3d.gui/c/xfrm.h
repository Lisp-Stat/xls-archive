/* {{{ xfrm.h -- viewFRaMe objects.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jul28
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xfrm;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xfrm00_Is_New();
extern LVAL xfrm08_Copy_Msg();
extern LVAL xfrm03_Show_Msg();
extern LVAL xfrm40_Get_Msg();
extern LVAL xfrm42_Put_Msg();
extern LVAL xfrm65_Downclick_Fn();
extern LVAL xfrm67_Upclick_Fn();
extern LVAL xfrm69_Drag_Fn();
extern LVAL xfrm79_Insert_Msg();
extern LVAL xfrm91_ProplistLength_Msg();
extern LVAL xfrm95_ProplistNth_Msg();

#ifndef EXTERNED_STATE
extern LVAL k_state;/* Keyword ":state" */
#define EXTERNED_STATE
#endif

#ifndef EXTERNED_RUN
extern LVAL k_run;/* Keyword ":run" */
#define EXTERNED_RUN
#endif

#ifndef EXTERNED_STOP
extern LVAL k_stop;/* Keyword ":stop" */
#define EXTERNED_STOP
#endif

#ifndef EXTERNED_SIZE
extern LVAL k_size;/* Keyword ":size" */
#define EXTERNED_SIZE
#endif

#ifndef EXTERNED_BIG
extern LVAL k_big;/* Keyword ":big" */
#define EXTERNED_BIG
#endif

#ifndef EXTERNED_NORMAL
extern LVAL k_normal;/* Keyword ":normal" */
#define EXTERNED_NORMAL
#endif

#ifndef EXTERNED_CLOSED
extern LVAL k_closed;/* Keyword ":closed" */
#define EXTERNED_CLOSED
#endif

#ifndef EXTERNED_S_XG3DGUIXFRMDOWNCLICKFN
extern LVAL s_xg3dguixfrmdownclickfn;/* Symbol "xg.3d.gui-xfrm-downclick-fn" */
#define EXTERNED_S_XG3DGUIXFRMDOWNCLICKFN
#endif

#ifndef EXTERNED_S_XG3DGUIXFRMDRAGFN
extern LVAL s_xg3dguixfrmdragfn;/* Symbol "xg.3d.gui-xfrm-drag-fn" */
#define EXTERNED_S_XG3DGUIXFRMDRAGFN
#endif

#ifndef EXTERNED_S_XG3DGUIXFRMUPCLICKFN
extern LVAL s_xg3dguixfrmupclickfn;/* Symbol "xg.3d.gui-xfrm-upclick-fn" */
#define EXTERNED_S_XG3DGUIXFRMUPCLICKFN
#endif

#ifndef EXTERNED_S_VIEWPORTCAMERA
extern LVAL s_viewportcamera;/* Symbol "viewport-camera" */
#define EXTERNED_S_VIEWPORTCAMERA
#endif

#ifndef EXTERNED_VIEWPORTCAMERA
extern LVAL k_viewportcamera;/* Keyword ":viewport-camera" */
#define EXTERNED_VIEWPORTCAMERA
#endif

#ifndef EXTERNED_S_VIEWFRAMECAMERA
extern LVAL s_viewframecamera;/* Symbol "viewframe-camera" */
#define EXTERNED_S_VIEWFRAMECAMERA
#endif

#ifndef EXTERNED_VIEWFRAMECAMERA
extern LVAL k_viewframecamera;/* Keyword ":viewframe-camera" */
#define EXTERNED_VIEWFRAMECAMERA
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,			xfrm00_Is_New			)
DEFINE_SUBR(	NULL,			xfrm08_Copy_Msg			)
DEFINE_SUBR(	NULL,			xfrm03_Show_Msg			)
DEFINE_SUBR(	NULL,			xfrm40_Get_Msg			)
DEFINE_SUBR(	NULL,			xfrm42_Put_Msg			)
DEFINE_SUBR(	"XG.3D.GUI-XFRM-DOWNCLICK-FN",xfrm65_Downclick_Fn		)
DEFINE_SUBR(	"XG.3D.GUI-XFRM-UPCLICK-FN",	xfrm67_Upclick_Fn		)
DEFINE_SUBR(	"XG.3D.GUI-XFRM-DRAG-FN",	xfrm69_Drag_Fn			)
DEFINE_SUBR(	NULL,			xfrm79_Insert_Msg		)
DEFINE_SUBR(	NULL,			xfrm91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,			xfrm95_ProplistNth_Msg		)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLINIT
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xfrm;
LOCAL struct xfrm_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xfrm_table[] = {
    {	":ISNEW",		xfrm00_Is_New			},
    {	":COPY",		xfrm08_Copy_Msg			},
    {	":SHOW",		xfrm03_Show_Msg			},
    {	":GET", 		xfrm40_Get_Msg			},
    {	":SET", 		xfrm42_Put_Msg			},
    {	":INSERT",		xfrm79_Insert_Msg		},
    {	":PROPERTY-LIST-LENGTH",xfrm91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xfrm95_ProplistNth_Msg		},

    {	NULL,			NULL				}
};

#ifndef DEFINED_STATE
LVAL k_state;/* Keyword ":state" */
#define DEFINED_STATE
#endif

#ifndef DEFINED_RUN
LVAL k_run;/* Keyword ":run" */
#define DEFINED_RUN
#endif

#ifndef DEFINED_STOP
LVAL k_stop;/* Keyword ":stop" */
#define DEFINED_STOP
#endif

#ifndef DEFINED_SIZE
LVAL k_size;/* Keyword ":size" */
#define DEFINED_SIZE
#endif

#ifndef DEFINED_BIG
LVAL k_big;/* Keyword ":big" */
#define DEFINED_BIG
#endif

#ifndef DEFINED_NORMAL
LVAL k_normal;/* Keyword ":normal" */
#define DEFINED_NORMAL
#endif

#ifndef DEFINED_CLOSED
LVAL k_closed;/* Keyword ":closed" */
#define DEFINED_CLOSED
#endif
#ifndef DEFINED_S_XG3DGUIXFRMUPCLICKFN
LVAL s_xg3dguixfrmupclickfn;/* Symbol "xg.3d.gui-xfrm-upclick-fn" */
#define DEFINED_S_XG3DGUIXFRMUPCLICKFN
#endif

#ifndef DEFINED_S_XG3DGUIXFRMDRAGFN
LVAL s_xg3dguixfrmdragfn;/* Symbol "xg.3d.gui-xfrm-drag-fn" */
#define DEFINED_S_XG3DGUIXFRMDRAGFN
#endif

#ifndef DEFINED_S_XG3DGUIXFRMDOWNCLICKFN
LVAL s_xg3dguixfrmdownclickfn;/* Symbol "xg.3d.gui-xfrm-downclick-fn" */
#define DEFINED_S_XG3DGUIXFRMDOWNCLICKFN
#endif

#ifndef DEFINED_S_VIEWPORTCAMERA
LVAL s_viewportcamera;/* Symbol "viewport-camera" */
#define DEFINED_S_VIEWPORTCAMERA
#endif

#ifndef DEFINED_VIEWPORTCAMERA
LVAL k_viewportcamera;/* Keyword ":viewport-camera" */
#define DEFINED_VIEWPORTCAMERA
#endif

#ifndef DEFINED_S_VIEWFRAMECAMERA
LVAL s_viewframecamera;/* Symbol "viewframe-camera" */
#define DEFINED_S_VIEWFRAMECAMERA
#endif

#ifndef DEFINED_VIEWFRAMECAMERA
LVAL k_viewframecamera;/* Keyword ":viewframe-camera" */
#define DEFINED_VIEWFRAMECAMERA
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_STATE
    k_state = xlenter(":STATE");
#define CREATED_STATE
#endif

#ifndef CREATED_RUN
    k_run = xlenter(":RUN");
#define CREATED_RUN
#endif

#ifndef CREATED_STOP
    k_stop = xlenter(":STOP");
#define CREATED_STOP
#endif

#ifndef CREATED_SIZE
    k_size = xlenter(":SIZE");
#define CREATED_SIZE
#endif

#ifndef CREATED_BIG
    k_big = xlenter(":BIG");
#define CREATED_BIG
#endif

#ifndef CREATED_NORMAL
    k_normal = xlenter(":NORMAL");
#define CREATED_NORMAL
#endif

#ifndef CREATED_CLOSED
    k_closed = xlenter(":CLOSED");
#define CREATED_CLOSED
#endif

#ifndef CREATED_S_XG3DGUIXFRMUPCLICKFN
    s_xg3dguixfrmupclickfn = xlenter("XG.3D.GUI-XFRM-UPCLICK-FN");
#define CREATED_S_XG3DGUIXFRMUPCLICKFN
#endif

#ifndef CREATED_S_XG3DGUIXFRMDRAGFN
    s_xg3dguixfrmdragfn = xlenter("XG.3D.GUI-XFRM-DRAG-FN");
#define CREATED_S_XG3DGUIXFRMDRAGFN
#endif

#ifndef CREATED_S_XG3DGUIXFRMDOWNCLICKFN
    s_xg3dguixfrmdownclickfn = xlenter("XG.3D.GUI-XFRM-DOWNCLICK-FN");
#define CREATED_S_XG3DGUIXFRMDOWNCLICKFN
#endif

#ifndef CREATED_S_VIEWPORTCAMERA
    s_viewportcamera = xlenter("VIEWPORT-CAMERA");
#define CREATED_S_VIEWPORTCAMERA
#endif

#ifndef CREATED_VIEWPORTCAMERA
    k_viewportcamera = xlenter(":VIEWPORT-CAMERA");
#define CREATED_VIEWPORTCAMERA
#endif

#ifndef CREATED_S_VIEWFRAMECAMERA
    s_viewframecamera = xlenter("VIEWFRAME-CAMERA");
#define CREATED_S_VIEWFRAMECAMERA
#endif

#ifndef CREATED_VIEWFRAMECAMERA
    k_viewframecamera = xlenter(":VIEWFRAME-CAMERA");
#define CREATED_VIEWFRAMECAMERA
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xfrm = xgbj58_Create_Class("CLASS-TITLEBAR",lv_x03d);
    xgbj57_Add_Instance_Variable( lv_xfrm,"BODY-THING");
    xgbj57_Add_Instance_Variable( lv_xfrm,"FIELD-THING");
    xgbj57_Add_Instance_Variable( lv_xfrm,"TEXT-THING");
    xgbj57_Add_Instance_Variable( lv_xfrm,"VIEWPORT-CAMERA");
    xgbj57_Add_Instance_Variable( lv_xfrm,"VIEWFRAME-CAMERA");
    xgbj56_Enter_Messages(        lv_xfrm,  xfrm_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
