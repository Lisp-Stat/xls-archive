/* {{{ xchc.h -- menu (CHoiCe) objects.				     CrT*/
/*************************************************************************
*
* File:         xchc.h
* Description:  Hybrid-class header for menu (CHoiCe) objects.
* Author:       Jeff Prothero
* Created:      92Jul26
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xchc;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xchc00_Is_New();
extern LVAL xchc08_Copy_Msg();
extern LVAL xchc03_Show_Msg();
extern LVAL xchc40_Get_Msg();
extern LVAL xchc42_Put_Msg();
extern LVAL xchc65_Downclick_Fn();
extern LVAL xchc67_Upclick_Fn();
extern LVAL xchc69_Drag_Fn();
extern LVAL xchc79_Insert_Msg();
extern LVAL xchc91_ProplistLength_Msg();
extern LVAL xchc95_ProplistNth_Msg();

#ifndef EXTERNED_CHOSENSTRING
extern LVAL k_chosenstring;/* Keyword ":chosen-string" */
#define EXTERNED_CHOSENSTRING
#endif

#ifndef EXTERNED_CHOICE
extern LVAL k_choice;/* Keyword ":choice" */
#define EXTERNED_CHOICE
#endif

#ifndef EXTERNED_CHOICES
extern LVAL k_choices;/* Keyword ":choices" */
#define EXTERNED_CHOICES
#endif

#ifndef EXTERNED_S_CHOICES
extern LVAL s_choices;/* Symbol "choices" */
#define EXTERNED_S_CHOICES
#endif

#ifndef EXTERNED_CHOICEFONT
extern LVAL k_choicefont;/* Keyword ":choice-font" */
#define EXTERNED_CHOICEFONT
#endif

#ifndef EXTERNED_CHOICEHEIGHT
extern LVAL k_choiceheight;/* Keyword ":choice-height" */
#define EXTERNED_CHOICEHEIGHT
#endif

#ifndef EXTERNED_UPDOWNHEIGHT
extern LVAL k_updownheight;/* Keyword ":updown-height" */
#define EXTERNED_UPDOWNHEIGHT
#endif

#ifndef EXTERNED_CHOICEDEPTH
extern LVAL k_choicedepth;/* Keyword ":choice-depth" */
#define EXTERNED_CHOICEDEPTH
#endif

#ifndef EXTERNED_UPDOWNDEPTH
extern LVAL k_updowndepth;/* Keyword ":updown-depth" */
#define EXTERNED_UPDOWNDEPTH
#endif

#ifndef EXTERNED_MAXVISIBLECHOICES
extern LVAL k_maxvisiblechoices;/* Keyword ":max-visible-choices" */
#define EXTERNED_MAXVISIBLECHOICES
#endif

#ifndef EXTERNED_S_XG3DGUIXCHCDOWNCLICKFN
extern LVAL s_xg3dguixchcdownclickfn;/* Symbol "xg.3d.gui-xchc-downclick-fn" */
#define EXTERNED_S_XG3DGUIXCHCDOWNCLICKFN
#endif

#ifndef EXTERNED_S_XG3DGUIXCHCDRAGFN
extern LVAL s_xg3dguixchcdragfn;/* Symbol "xg.3d.gui-xchc-drag-fn" */
#define EXTERNED_S_XG3DGUIXCHCDRAGFN
#endif

#ifndef EXTERNED_S_XG3DGUIXCHCUPCLICKFN
extern LVAL s_xg3dguixchcupclickfn;/* Symbol "xg.3d.gui-xchc-upclick-fn" */
#define EXTERNED_S_XG3DGUIXCHCUPCLICKFN
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,			xchc00_Is_New			)
DEFINE_SUBR(	NULL,			xchc08_Copy_Msg			)
DEFINE_SUBR(	NULL,			xchc03_Show_Msg			)
DEFINE_SUBR(	NULL,			xchc40_Get_Msg			)
DEFINE_SUBR(	NULL,			xchc42_Put_Msg			)
DEFINE_SUBR(	"XG.3D.GUI-XCHC-DOWNCLICK-FN",xchc65_Downclick_Fn		)
DEFINE_SUBR(	"XG.3D.GUI-XCHC-UPCLICK-FN",	xchc67_Upclick_Fn		)
DEFINE_SUBR(	"XG.3D.GUI-XCHC-DRAG-FN",	xchc69_Drag_Fn			)
DEFINE_SUBR(	NULL,			xchc79_Insert_Msg		)
DEFINE_SUBR(	NULL,			xchc91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,			xchc95_ProplistNth_Msg		)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLINIT
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xchc;
LOCAL struct xchc_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xchc_table[] = {
    {	":ISNEW",		xchc00_Is_New			},
    {	":COPY",		xchc08_Copy_Msg			},
    {	":SHOW",		xchc03_Show_Msg			},
    {	":GET", 		xchc40_Get_Msg			},
    {	":SET", 		xchc42_Put_Msg			},
    {	":INSERT",		xchc79_Insert_Msg		},
    {	":PROPERTY-LIST-LENGTH",xchc91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xchc95_ProplistNth_Msg		},

    {	NULL,			NULL				}
};

#ifndef DEFINED_CHOSENSTRING
LVAL k_chosenstring;/* Keyword ":chosen-string" */
#define DEFINED_CHOSENSTRING
#endif

#ifndef DEFINED_CHOICE
LVAL k_choice;/* Keyword ":choice" */
#define DEFINED_CHOICE
#endif

#ifndef DEFINED_CHOICES
LVAL k_choices;/* Keyword ":choices" */
#define DEFINED_CHOICES
#endif

#ifndef DEFINED_S_CHOICES
LVAL s_choices;/* Symbol "choices" */
#define DEFINED_S_CHOICES
#endif

#ifndef DEFINED_CHOICEFONT
LVAL k_choicefont;/* Keyword ":choice-font" */
#define DEFINED_CHOICEFONT
#endif

#ifndef DEFINED_CHOICEHEIGHT
LVAL k_choiceheight;/* Keyword ":choice-height" */
#define DEFINED_CHOICEHEIGHT
#endif

#ifndef DEFINED_UPDOWNHEIGHT
LVAL k_updownheight;/* Keyword ":updown-height" */
#define DEFINED_CHOICEHEIGHT
#endif

#ifndef DEFINED_CHOICEDEPTH
LVAL k_choicedepth;/* Keyword ":choice-depth" */
#define DEFINED_CHOICEDEPTH
#endif

#ifndef DEFINED_UPDOWNDEPTH
LVAL k_updowndepth;/* Keyword ":updown-depth" */
#define DEFINED_CHOICEDEPTH
#endif

#ifndef DEFINED_MAXVISIBLECHOICES
LVAL k_maxvisiblechoices;/* Keyword ":max-visible-choices" */
#define DEFINED_MAXVISIBLECHOICES
#endif

#ifndef DEFINED_S_XG3DGUIXCHCUPCLICKFN
LVAL s_xg3dguixchcupclickfn;/* Symbol "xg.3d.gui-xchc-upclick-fn" */
#define DEFINED_S_XG3DGUIXCHCUPCLICKFN
#endif

#ifndef DEFINED_S_XG3DGUIXCHCDRAGFN
LVAL s_xg3dguixchcdragfn;/* Symbol "xg.3d.gui-xchc-drag-fn" */
#define DEFINED_S_XG3DGUIXCHCDRAGFN
#endif

#ifndef DEFINED_S_XG3DGUIXCHCDOWNCLICKFN
LVAL s_xg3dguixchcdownclickfn;/* Symbol "xg.3d.gui-xchc-downclick-fn" */
#define DEFINED_S_XG3DGUIXCHCDOWNCLICKFN
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_CHOSENSTRING
    k_chosenstring = xlenter(":CHOSEN-STRING");
#define CREATED_CHOSENSTRING
#endif

#ifndef CREATED_CHOICE
    k_choice = xlenter(":CHOICE");
#define CREATED_CHOICE
#endif

#ifndef CREATED_CHOICES
    k_choices = xlenter(":CHOICES");
#define CREATED_CHOICES
#endif

#ifndef CREATED_S_CHOICES
    s_choices = xlenter("CHOICES");
#define CREATED_S_CHOICES
#endif

#ifndef CREATED_CHOICEFONT
    k_choicefont = xlenter(":CHOICE-FONT");
#define CREATED_CHOICEFONT
#endif

#ifndef CREATED_CHOICEHEIGHT
    k_choiceheight = xlenter(":CHOICE-HEIGHT");
#define CREATED_CHOICEHEIGHT
#endif

#ifndef CREATED_UPDOWNHEIGHT
    k_updownheight = xlenter(":UPDOWN-HEIGHT");
#define CREATED_UPDOWNHEIGHT
#endif

#ifndef CREATED_CHOICEDEPTH
    k_choicedepth = xlenter(":CHOICE-DEPTH");
#define CREATED_CHOICEDEPTH
#endif

#ifndef CREATED_UPDOWNDEPTH
    k_updowndepth = xlenter(":UPDOWN-DEPTH");
#define CREATED_UPDOWNDEPTH
#endif

#ifndef CREATED_MAXVISIBLECHOICES
    k_maxvisiblechoices = xlenter(":MAX-VISIBLE-CHOICES");
#define CREATED_MAXVISIBLECHOICES
#endif

#ifndef CREATED_S_XG3DGUIXCHCUPCLICKFN
    s_xg3dguixchcupclickfn = xlenter("XG.3D.GUI-XCHC-UPCLICK-FN");
#define CREATED_S_XG3DGUIXCHCUPCLICKFN
#endif

#ifndef CREATED_S_XG3DGUIXCHCDRAGFN
    s_xg3dguixchcdragfn = xlenter("XG.3D.GUI-XCHC-DRAG-FN");
#define CREATED_S_XG3DGUIXCHCDRAGFN
#endif

#ifndef CREATED_S_XG3DGUIXCHCDOWNCLICKFN
    s_xg3dguixchcdownclickfn = xlenter("XG.3D.GUI-XCHC-DOWNCLICK-FN");
#define CREATED_S_XG3DGUIXCHCDOWNCLICKFN
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xchc = xgbj58_Create_Class("CLASS-MENU",lv_x03d);
    xgbj57_Add_Instance_Variable( lv_xchc,"BODY-THING");
    xgbj57_Add_Instance_Variable( lv_xchc,"FIELD-THING");
    xgbj57_Add_Instance_Variable( lv_xchc,"TEXT-THING");
    xgbj57_Add_Instance_Variable( lv_xchc,"CHOICES");
    xgbj56_Enter_Messages(        lv_xchc,  xchc_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
