/* {{{ xchc.h -- menu (CHoiCe) objects.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jul26
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Jul26 jsp: Created.  Operational.					*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/cshp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xchc;
extern LVAL k_choice;
extern LVAL k_choicedepth;
extern LVAL k_choicefont;
extern LVAL k_choiceheight;
extern LVAL k_choices;
extern LVAL k_chosenstring;
extern LVAL k_frustumdepth;
extern LVAL k_horizontalmargin;
extern LVAL k_initializefromfile;
extern LVAL k_label;
extern LVAL k_labeldepth;
extern LVAL k_labelfont;
extern LVAL k_labelheight;
extern LVAL k_maxvisiblechoices;
extern LVAL k_updowndepth;
extern LVAL k_updownheight;
extern LVAL k_verticalmargin;
extern LVAL s_choices;
extern LVAL k_bodything;
extern LVAL k_center;
extern LVAL k_changehook;
extern LVAL k_downclickhook;
extern LVAL k_draghook;
extern LVAL k_fieldthing;
extern LVAL k_scale;
extern LVAL k_scalex;
extern LVAL k_scaley;
extern LVAL k_scalez;
extern LVAL k_textthing;
extern LVAL k_upclickhook;
extern LVAL k_widget;
extern LVAL k_x;
extern LVAL k_y;
extern LVAL k_z;
extern LVAL s_bodything;
extern LVAL s_bodything;
extern LVAL s_xg3dguicurrentwidget;
extern LVAL s_fieldthing;
extern LVAL s_textthing;
extern LVAL s_xg3dguixchcdownclickfn;
extern LVAL s_xg3dguixchcdragfn;
extern LVAL s_xg3dguixchcupclickfn;



extern LVAL s_stdout;
extern LVAL xsendmsg0();
extern LVAL xsendmsg0();
LVAL  xchc41_Put();
LVAL  xchc71_Do_Hook_Fn();
LVAL  xchc78_Insert();

#include <math.h>
#include <string.h>
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/cthl.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/clgt.h"
#include "../../xg.3d/c/ccmr.h"
#include "../../xg.3d.fileio/c/cfil.h"
#include "cchc.h"

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xchc00_Is_New -- Initialize a new xchc instance.			*/

/* Following are in fractions of the total width of widget: */
#define VERTICAL_MARGIN     0.01
#define HORIZONTAL_MARGIN   0.01

#define CHOICE_HEIGHT       0.08
#define UPDOWN_HEIGHT       0.08
#define LABEL_HEIGHT        0.08

#define FRUSTUM_DEPTH       0.02
#define CHOICE_DEPTH        0.01
#define UPDOWN_DEPTH        0.01
#define LABEL_DEPTH         0.01

cchc_rec xchc_defaults = {
    C03D_xCHC,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */
    CCHC_STYLE_1,		/* menu_style.			*/

    1,				/* choice_font			*/
    0,				/* choice			*/
    0,				/* choice_count			*/
    0,				/* first_visible_choice		*/
    40,				/* max_visible_choices		*/
    1,				/* label_font			*/
    0,				/* omit_updown			*/
    0,				/* omit_choices			*/
    0,				/* omit_label			*/
    0,				/* omit_body			*/
    0,				/* in_changehook		*/
    ~13,			/* spare_1			*/
    ~13,			/* spare_2			*/

    VERTICAL_MARGIN,		/* vertical_margin		*/
    HORIZONTAL_MARGIN,		/* horizontal_margin		*/

    CHOICE_HEIGHT,		/* choice_height		*/
    UPDOWN_HEIGHT,		/* updown_height		*/
    LABEL_HEIGHT,		/* label_height			*/

    CHOICE_DEPTH,		/* choice_depth			*/
    UPDOWN_DEPTH,		/* updown_depth			*/
    LABEL_DEPTH,		/* label_depth			*/

    FRUSTUM_DEPTH,		/* frustum_depth		*/

    0.0,			/* frustum_height		*/

    0.0,			/* text_spot_x			*/
    0.0,			/* text_spot_y			*/
    1.0,			/* text_scale_x			*/
    1.0,			/* text_scale_y			*/

    {0.1, 0.1, 0.0},		/* down_min			*/
    {0.2, 0.2, 0.2},		/* down_max			*/
    {0.3, 0.3, 0.0},		/* choice_min			*/
    {0.4, 0.4, 0.2},		/* choice_max			*/
    {0.5, 0.5, 0.0},		/* up_min			*/
    {0.6, 0.6, 0.2},		/* up_max			*/
    {0.7, 0.7, 0.0},		/* label_min			*/
    {0.8, 0.8, 0.2},		/* label_max			*/

   -314155.0,			/* fspare_1			*/
    "\0nameless)\0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
};


LVAL xchc00_Is_New()
/*-
    Initialize a new xchc instance.
-*/
{
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    cchc_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xchcp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( cchc_rec ) );

    /* Initialize menu record to reasonable default values: */
    r	= (cchc_rec*) gobjimmbase( lv );
   *r   = xchc_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    xchc41_Put( lv );

    return lv;
}

/* }}} */
/* {{{ xchc01_Get_A_XCHC -- Get arg, must be of class xchc.		*/

LOCAL LVAL xchc01_Get_A_XCHC()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XCHC has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xchc.  Similarly,          */
    /* nobody but nobody has any business resizing a xchc,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xchcp(m_as_lval) ||
        getgobjimmbytes(m_as_lval) != sizeof(cchc_rec)
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xchc03_Show_Msg -- Show the contents of a cchc.			*/

LVAL xchc03_Show_Msg()
{
    LVAL lv,fptr;

    /* get self and the file pointer */
    lv   = xchc01_Get_A_XCHC();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(lv,fptr);
    xgbj52_Show_Lval_Vector(lv,fptr);

    /* Print the chc record: */
    {   cchc_rec * r = (cchc_rec*) gobjimmbase( lv );
	/* Suppose I should write this someday... (buggo) */
    }

    /* return the gobject */
    return lv;
}

/* }}} */
/* {{{ xchc08_Copy_Msg -- Build copy of given CCHC.			*/

LVAL xchc09_Copy( m_as_lval )
LVAL		  m_as_lval;
{
    /* Create a new gobject to hold result: */
    cchc_rec*mh = (cchc_rec*) gobjimmbase( m_as_lval );
    cchc_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xchc,k_new);
    xlpop();
    nh = (cchc_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}
LVAL xchc08_Copy_Msg()
{   LVAL m_as_lval;
    LVAL x_as_lval = xchc01_Get_A_XCHC();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xchc09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xchc28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xchc28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {   char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xchc29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xchc01_Get_A_XCHC();
    LVAL n_as_lval = xchc01_Get_A_XCHC();
    xllastarg();
    return xchc28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xchc40_Get_Msg -- Get keyword properties.                        */

LVAL xchc39_Get( lv_xchc )
LVAL             lv_xchc;
{
    extern LVAL true;/*xlglob.c*/
    cchc_rec* r = (cchc_rec*) gobjimmbase( lv_xchc );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if        (key == k_choice) {

	result = cvfixnum( r->choice );

    } else if (key == k_label) {

        result = cvstring( r->label );

    } else if (key == k_chosenstring) {

	LVAL lv_choices = xthl90_GetObjectVariable(lv_xchc,s_choices);
	LVAL lv_choice	= xthl95_nth( lv_choices, r->choice, NIL, FALSE);
        result = lv_choice;

    } else if (key == k_labelfont) {

        result = cvfixnum( r->label_font );

    } else if (key == k_choicefont) {

        result = cvfixnum( r->choice_font );

    } else if (key == k_verticalmargin) {
	result = cvflonum( r->vertical_margin );
    } else if (key == k_horizontalmargin) {
	result = cvflonum( r->horizontal_margin );

    } else if (key == k_choiceheight) {
	result = cvflonum( r->choice_height );
    } else if (key == k_updownheight) {
	result = cvflonum( r->updown_height );
    } else if (key == k_labelheight) {
	result = cvflonum( r->label_height );

    } else if (key == k_frustumdepth) {
	result = cvflonum( r->frustum_depth );
    } else if (key == k_choicedepth) {
	result = cvflonum( r->choice_depth );
    } else if (key == k_updowndepth) {
	result = cvflonum( r->updown_depth );
    } else if (key == k_labeldepth) {
	result = cvflonum( r->label_depth );

    } else if (key == k_maxvisiblechoices) {
	result = cvflonum( r->max_visible_choices );

    } else if (key == k_choices) {
	/* I'd be happier copying the whole thing so users  */
	/* can't mess with list without us knowing. But I'm */
	/* too lazy to do that right now...		    */
	result = xthl90_GetObjectVariable(lv_xchc,s_choices);

    } else {

	/* If this isn't a property we know, do a generic get property: */
        result = xthl8a_GetObjectProp( lv_xchc, key, default_val, got_default );
    }
    return result;
}
LVAL xchc40_Get_Msg()
{
    return xchc39_Get( xchc01_Get_A_XCHC() );
}

/* }}} */
/* {{{ xchc42_Put_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Put, update XCHC_PROPS and xchc94_ProplistNth. */
#define XCHC_PROPS (14)

/* A little macro to make this fn a little neater: */
#define XCHC_REDO(x) {		\
    x;				\
    rebuild = TRUE;		\
}

LVAL xchc41_Put( lv_xchc )
LVAL             lv_xchc;
{
    cchc_rec* r = (cchc_rec*) gobjimmbase( lv_xchc );
    extern LVAL true;/*xlglob.c*/
    int  rebuild    = FALSE;
    int  setchoice  = FALSE;
    int  setchoices = FALSE;
    int  choice;
    LVAL lv_choices;

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xchcz7_Read_Xchc_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_xchc,
		getfile(xlgetfile()),
		xchcz7_Read_Xchc_From_File,NULL
	    );

        } else if (key == k_choice) {

	    choice    = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    setchoice = TRUE;

        } else if (key == k_choices) {

	    lv_choices = xlgalist();
	    setchoices = TRUE;
	    rebuild    = TRUE;

        } else if (key == k_label) {

	    LVAL lv_string = xlgastring();
	    strncpy(r->label,(const char*)getstring(lv_string),CCHC_MAX_LABEL);
	    r->label[ CCHC_MAX_LABEL -1 ] = '\0';
	    rebuild	   = TRUE;

        } else if (key == k_labelfont) {

	    float ffont;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&ffont,xlgetarg())) {
		int font = (int) ffont;
		if (font <  0)   font =  0;
		if (font > 11)   font = 11;
		r->label_font = font;
		rebuild	  = TRUE;
	    }

        } else if (key == k_maxvisiblechoices) {

	    float fmax;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&fmax,xlgetarg())) {
		int max_v = (int) fmax;
		if (max_v <   2)   max_v =   2;
		if (max_v > 200)   max_v = 200;/* *shrug* :) */
		r->max_visible_choices = max_v;
		rebuild	  = TRUE;
	    }

        } else if (key == k_choicefont) {

	    float ffont;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&ffont,xlgetarg())) {
		int font = (int) ffont;
		if (font <  0)   font =  0;
		if (font > 11)   font = 11;
		r->choice_font = font;
		rebuild       = TRUE;
	    }

        } else if (key == k_verticalmargin) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f!=r->vertical_margin
            ) {
                XCHC_REDO( r->vertical_margin   = f );
	    }
        } else if (key == k_horizontalmargin) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f<0.45                                         &&
                f!=r->horizontal_margin
            ) {
                XCHC_REDO( r->horizontal_margin = f );
            }
        } else if (key == k_choiceheight) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>=0.0				               &&
                f!=r->choice_height
            ) {
                XCHC_REDO( r->choice_height     = f );
	    }
        } else if (key == k_updownheight) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>=0.0                                         &&
                f!=r->updown_height
            ) {
                XCHC_REDO( r->updown_height     = f );
	    }
        } else if (key == k_labelheight) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>=0.0                                         &&
                f!=r-> label_height
            ) {
                XCHC_REDO( r->label_height      = f );
            }
        } else if (key == k_frustumdepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f<0.3                                          &&
                f!=r->frustum_depth
            ) {
                XCHC_REDO( r->frustum_depth     = f );
	    }
        } else if (key == k_choicedepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f<0.3                                          &&
                f!=r->choice_depth
            ) {
                XCHC_REDO( r->choice_depth      = f );
	    }
        } else if (key == k_updowndepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f<0.3                                          &&
                f!=r->updown_depth
            ) {
                XCHC_REDO( r->updown_depth      = f );
	    }
        } else if (key == k_labeldepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f<0.3                                          &&
                f!=r->label_depth
            ) {
                XCHC_REDO( r->label_depth       = f );
            }
	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_xchc, key, xlgetarg() );
        }
    }

    /* We delay this stuff to end to make result order-invariant: */
    if (setchoice) {
        xchc61_Set_Choice(      lv_xchc,    choice );
    }
    if (setchoices) xchc59_Set_Choices(     lv_xchc, lv_choices );
    if (rebuild)    xchc75_RebuildGeometry( lv_xchc );

    return lv_xchc;
}
#undef XCHC_REDO
LVAL xchc42_Put_Msg()
{   /* Read keyword properties for a menu object. */
    LVAL   lv_xchc = xchc01_Get_A_XCHC();
    LVAL   result  = xchc41_Put( lv_xchc );
    return result;
}

/* }}} */
/* {{{ xchc59_Set_Choices	Main fn to set choices list.		*/

int xchc58_Count_Choices( lv_full_list, lv_list, count )
LVAL			  lv_full_list, lv_list;
int						 count;
{   /* We do a little validation on the list too: */
    if (null(lv_list))   return count;
    /* List should be a list of strings, or else a list */
    /* of lists headed by strings.  The latter allows	*/
    /* the user to associate values with menu strings.	*/
    if (!consp(lv_list)
    || (   !stringp(car(lv_list)) &&
	   !(consp(car(lv_list)) && (stringp(car(car(lv_list)))))
       )
    ) {
	xlerror("Invalid :CHOICES",lv_full_list);
    }
    return xchc58_Count_Choices(
	lv_full_list,
	cdr(lv_list),
	count+1
    );
}
xchc59_Set_Choices( lv_xchc, lv_new_choicelist )
LVAL	            lv_xchc, lv_new_choicelist;
{   cchc_rec*   r = (cchc_rec*) gobjimmbase(  lv_xchc );
    r->choice_count = xchc58_Count_Choices(
	lv_new_choicelist,
	lv_new_choicelist,
	0
    );
    if (r->choice > 0   &&
	r->choice > r->choice_count -1
    ) {
	r->choice = r->choice_count -1;
    }
    if (r->max_visible_choices > r->choice_count) {
	r->max_visible_choices = r->choice_count;
    }
    xthl91_SetObjectVariable(lv_xchc,s_choices,lv_new_choicelist);
    xchc71_Do_Hook_Fn( lv_xchc, k_changehook );
    xchc77_ReinsertVaryingPartOfMenu( lv_xchc );
}

/* }}} */
/* {{{ xchc61_Set_Choice	Main fn to set choice, call hooks.	*/

xchc61_Set_Choice( lv_xchc, new_choice )
LVAL	           lv_xchc;
int			    new_choice;
{   cchc_rec*   r = (cchc_rec*) gobjimmbase(  lv_xchc );
    if (new_choice > r->choice_count-1)   new_choice = r->choice_count-1;
    if (new_choice < 0)   new_choice = 0;

    /* Unlike sliders, we don't require the new value  */
    /* to be different from the old value in order for */
    /* the hook to fire -- folks often keep tapping on */
    /* a single menu entry, wanting incremental stuff: */
    r->choice	= new_choice;

    xchc71_Do_Hook_Fn( lv_xchc, k_changehook );

    /* Update our appearance: */
    xchc77_ReinsertVaryingPartOfMenu( lv_xchc );
}

/* }}} */
/* {{{ xchc63_Click		Main fn to handle upclick/downclick/drag*/

LVAL xchc63_Click( lv_hook )
LVAL		   lv_hook; /* k_upclickhook/k_draghook/k_downclickhook */
{   /*********************************************/
    /* We've been called as a hook fn, need to   */
    /* update our appearance etc to track mouse. */
    /*********************************************/
    extern LVAL k_selectedthing;
    extern LVAL k_get;

    /* We've been called with no arguments: */
    int  csux0	  = (
	xcmrC3_RunningWidgets ||
	xlfail("CLASS-MENU Hookfn not called via :RUN-WIDGETS")
    );

    /* But we need some arguments! */
    LVAL lv_thing = xcmrC2_RunWidgets_Rec.lv_selected_thing;
    LVAL lv_xchc  = xthl74_GetProp( &lv_thing, k_widget, NIL,/*got_default:*/FALSE);
    int  csux1 	  = (
	xchcp(lv_xchc) ||
	xlerror("Not CLASS-MENU instance:",lv_xchc)
    );
    cchc_rec*   r = (cchc_rec*) gobjimmbase(  lv_xchc );
    int         f = xcmrC2_RunWidgets_Rec.selected_facet;
    xllastarg();
    r->in_changehook	= FALSE;/* Guard against it getting stuck ON */

    if (lv_hook != k_downclickhook) {
        return xchc71_Do_Hook_Fn( lv_xchc, lv_hook );
    }

    if (f >= r->max_visible_choices) {
	int delta = r->max_visible_choices -1;
	if (f == r->max_visible_choices) {
	    /* "Up": */
	    if (r->first_visible_choice) {
		r->first_visible_choice -= delta;
		if (r->first_visible_choice < 0) {
		    r->first_visible_choice = 0;
		}
		xchc77_ReinsertVaryingPartOfMenu( lv_xchc );
	    }	    
	} else {
	    /* "Down": */
	    if (r->first_visible_choice+r->max_visible_choices < r->choice_count) {
		r->first_visible_choice += delta;
		xchc77_ReinsertVaryingPartOfMenu( lv_xchc );
	    }	    
	}
	return NIL;
    }

    if (r->first_visible_choice + f   <   r->choice_count) {
        xchc61_Set_Choice( lv_xchc, r->first_visible_choice + f );
    }
    return xchc71_Do_Hook_Fn( lv_xchc, lv_hook );
}

/* }}} */
/* {{{ xchc65_Downclick_Fn -- Function to implement menu downclick.	*/

LVAL xchc69_Drag_Fn();
LVAL xchc65_Downclick_Fn()
{
    return xchc63_Click( k_downclickhook );
}

/* }}} */
/* {{{ xchc67_Upclick_Fn -- Function to implement menu upclick.		*/

LVAL xchc67_Upclick_Fn()
{
    return xchc63_Click( k_upclickhook );
}

/* }}} */
/* {{{ xchc69_Drag_Fn -- Function to implement menu drag.		*/

LVAL xchc69_Drag_Fn()
{
    return xchc63_Click( k_draghook );
}

/* }}} */
/* {{{ xchc71_Do_Hook_Fn -- Call user-supplied hook fns.		*/

LVAL xchc70_Do_Hook_Fn( lv_xchc, lv_hookfns )
LVAL			lv_xchc;
LVAL				 lv_hookfns;
{
    LVAL     lv_old_current_widget = getvalue( s_xg3dguicurrentwidget );
    xlprot1( lv_old_current_widget );
    setvalue( s_xg3dguicurrentwidget, lv_xchc );

    xthlF5_Call_HookFns( lv_hookfns );

    setvalue( s_xg3dguicurrentwidget, lv_old_current_widget );
    xlpop();
    return NIL;
}
LVAL xchc71_Do_Hook_Fn( lv_xchc, lv_hook )
LVAL			lv_xchc;
LVAL				 lv_hook; /* k_changehook/k_downclickhook/...*/
{   cchc_rec* r	    = (cchc_rec*) gobjimmbase(  lv_xchc );
    LVAL lv_hookfns = xthl8a_GetObjectProp( lv_xchc, lv_hook, NIL,TRUE );
    if (null(lv_hookfns)) {
        return NIL;
    }
    if (lv_hook != k_changehook)   return xchc70_Do_Hook_Fn( lv_xchc, lv_hookfns );

    /* A little dodge so changehooks can modify our	*/
    /* value without slipping into infinite recursion:	*/
    if (r->in_changehook)   return NIL;
    r    ->in_changehook	= TRUE;
    /* Bad news if we get an error and leave this flag	*/
    /* set... as a partial fix, we clear it various	*/
    /* places.						*/
    xchc70_Do_Hook_Fn( lv_xchc, lv_hookfns );
    r    ->in_changehook	= FALSE;
    return NIL;
}

/* }}} */
/* {{{ xchc75_RebuildGeometry -- Rebuild our shape to new specs.	*/

xchc75_RebuildGeometry( lv_xchc )
LVAL			lv_xchc;
{
    /********************************************************************/
    /* Compute our current origin and scale factors by looking at our	*/
    /* bounding box, after which xchc78_Insert will do the rest of our	*/
    /* work.								*/
    /*									*/
    /* We use this somewhat roundabout technique (deduction from our	*/
    /* bounding box) so as to attempt to work correctly even if the	*/
    /* app hacker rescales or moves us without telling us.  Ideally,	*/
    /* we'd also work if s/he rotated us.  Someday :).			*/
    /********************************************************************/
    cchc_rec* r			= (cchc_rec*) gobjimmbase(  lv_xchc );
    float     old_frustum_width = 1.0;	/* By definition -- width units.*/
    float     old_frustum_height= r->frustum_height;
    float     old_frustum_depth	= r->frustum_depth;
    LVAL      lv_body		= xthl90_GetObjectVariable( lv_xchc, s_bodything );


    if (!null(lv_body)) {      /* May get called before we're inserted! */
	geo_point bbmin;
	geo_point bbmax;
        int       csux0	  = xchc76_RecomputeLayout(   lv_xchc );
	int       csux1   = xthlL2_ObjectspaceBoundingBoxOfThing( &bbmin, &bbmax, lv_body );

	float     x0      = (bbmax.x + bbmin.x) * 0.5;
	float     y0      = (bbmax.y + bbmin.y) * 0.5;
	float     z0      = (bbmax.z + bbmin.z) * 0.5;

	float     scalex  = (bbmax.x - bbmin.x)  / old_frustum_width ;
	float     scaley  = (bbmax.y - bbmin.y)  / old_frustum_height;
	float     scalez  = (bbmax.z - bbmin.z)  / old_frustum_depth ;

	xchc78_Insert(
	    lv_xchc,
	    x0, y0, z0,
	    scalex, scaley, scalez
	);
    }
}

/* }}} */
/* {{{ xchc76_RecomputeLayout						*/

xchc76_RecomputeLayout( lv_xchc )
LVAL			lv_xchc;
{
    float slot_depth;
    cchc_rec* r        = (cchc_rec*) gobjimmbase(  lv_xchc );
    LVAL      lv_body  = xthl90_GetObjectVariable( lv_xchc, s_bodything   );

    /* If body is null, assume someone is sending us */
    /* reshape messages before inserting us:         */
    if (null( lv_body   ))  return;

    /* Remember which parts we are missing: */
    r->omit_choices	= (r->choice_height == 0.0);
    r->omit_updown	= (r->choice_count <= r->max_visible_choices);
    r->omit_label	= (r-> label_height == 0.0 || !r->label[0]);

    /* Worry about nonsensical user layouts: */
    if (!r->omit_choices && r->frustum_depth < r->choice_depth) {
        r->frustum_depth  = r->choice_depth;
    }
    if (!r->omit_updown  && r->frustum_depth < r->updown_depth) {
        r->frustum_depth = r->updown_depth;
    }
    if (!r->omit_label  && r->frustum_depth < r-> label_depth) {
	r->frustum_depth = r-> label_depth;
    }
    for (;;) {
	/* All user input is in fractions of total width, */
	/* so width better not sum to more than 1.0 here: */
	float width;
        slot_depth = 0.0;
	if (!r->omit_choices  &&   r->choice_depth > slot_depth)   slot_depth = r->choice_depth;
	if (!r->omit_updown   &&   r->updown_depth > slot_depth)   slot_depth = r->updown_depth;
	if (!r->omit_label    &&   r-> label_depth > slot_depth)   slot_depth = r-> label_depth;
	width = (
	    2.0 * r->horizontal_margin +
	    2.0 *    slot_depth        +
	    2.0 * r->frustum_depth
	);

	if (width <= 1.0)   break;

	/* Shrink-to-fit: */
	r->vertical_margin	*= 0.99;
	r->horizontal_margin	*= 0.99;
	r->frustum_depth	*= 0.99;
	r->choice_depth		*= 0.99;
	r->updown_depth		*= 0.99;
	r->label_depth		*= 0.99;
    }

    /* Figure total height of widget, relative to width: */
    r                          ->frustum_height  = (
	2.0 * r->frustum_depth + r->vertical_margin
    );
    if (!r->omit_choices)     r->frustum_height += (
	2.0 * r->choice_depth  + r->vertical_margin +  r->choice_height * r->max_visible_choices
    );
    if (!r->omit_updown)      r->frustum_height += 2.0 * (
	2.0 * r->updown_depth  + r->vertical_margin +  r->updown_height
    );
    if (!r->omit_label)	      r->frustum_height += (
	2.0 * r->label_depth   + r->vertical_margin +  r->label_height
    );

    /* Figure parametric coordinates of various parts of menu.   */
    /* p_* are parameterized in bounding_box==1.0 units, x,y &z.   */
    {   float pvm  = r->  vertical_margin / r->frustum_height;	/* "Parametric Vertical   Margin"*/
        float phm  = r->horizontal_margin / 1.0;		/* "Parametric Horizontal Margin"*/
        float pvfd = r->frustum_depth     / r->frustum_height;
        float phfd = r->frustum_depth     / 1.0;

	float p_choice_depth  = r->choice_depth / r->frustum_depth;
	float p_updown_depth  = r->updown_depth / r->frustum_depth;
	float p__label_depth  = r-> label_depth / r->frustum_depth;

	float p_choice_spot_x = 0.5;
	float p_updown_spot_x = 0.5;
	float p__label_spot_x = 0.5;

	float p_choice_spot_y = 0.0;
	float p_up_____spot_y = 0.0;
	float p_down___spot_y = 0.0;
	float p__label_spot_y = 0.0;

	float p_choice_size_x = 1.0 - 2.0*(phfd+phm);
	float p__label_size_x = 1.0 - 2.0*(phfd+phm);
/*	float p_updown_size_x = 1.0 - 2.0*(phfd+phm); */
	float p_updown_size_x = 0.3 * p_choice_size_x;

	float mx              = r->max_visible_choices;
	float mx2             = mx * 0.5;
	float p_choice_size_y = (
			     (mx*r->choice_height + 2.0*r->choice_depth)/r->frustum_height
        );
	float p_updown_size_y = (r->updown_height + 2.0*r->updown_depth)/r->frustum_height;
	float p__label_size_y = (r-> label_height + 2.0*r-> label_depth)/r->frustum_height;

	float p_loc	      = pvfd + pvm;

	if (!r->omit_updown) {
	    p_down___spot_y   =p_loc+(0.5*r->updown_height +    r->updown_depth)/r->frustum_height;
	    p_loc	     +=  pvm+(    r->updown_height +2.0*r->updown_depth)/r->frustum_height;
	}

	if (!r->omit_choices) {
	    p_choice_spot_y   =p_loc+(mx2*r->choice_height +    r->choice_depth)/r->frustum_height;
	    p_loc	     +=  pvm+(mx *r->choice_height +2.0*r->choice_depth)/r->frustum_height;
	}
	if (!r->omit_updown) {
	    p_up_____spot_y   =p_loc+(0.5*r->updown_height +    r->updown_depth)/r->frustum_height;
	    p_loc	     +=  pvm+(    r->updown_height +2.0*r->updown_depth)/r->frustum_height;
	}
	if (!r->omit_label) {
	    p__label_spot_y   =p_loc+(0.5*r-> label_height  +   r-> label_depth)/r->frustum_height;
	}

	r->choice_min.x = p_choice_spot_x   -   0.5 * p_choice_size_x;
	r->choice_min.y = p_choice_spot_y   -   0.5 * p_choice_size_y;
	r->choice_min.z = 0.0;

	r->choice_max.x = p_choice_spot_x   +   0.5 * p_choice_size_x;
	r->choice_max.y = p_choice_spot_y   +   0.5 * p_choice_size_y;
	r->choice_max.z = r->choice_depth / r->frustum_depth;



	r->up_min.x     = p_updown_spot_x   -   0.5 * p_updown_size_x;
	r->up_min.y     = p_up_____spot_y   -   0.5 * p_updown_size_y;
	r->up_min.z     = 0.0;

	r->up_max.x	= p_updown_spot_x   +   0.5 * p_updown_size_x;
	r->up_max.y	= p_up_____spot_y   +   0.5 * p_updown_size_y;
	r->up_max.z	= r->updown_depth / r->frustum_depth;



	r->down_min.x   = p_updown_spot_x   -   0.5 * p_updown_size_x;
	r->down_min.y   = p_down___spot_y   -   0.5 * p_updown_size_y;
	r->down_min.z   = 0.0;

	r->down_max.x	= p_updown_spot_x   +   0.5 * p_updown_size_x;
	r->down_max.y	= p_down___spot_y   +   0.5 * p_updown_size_y;
	r->down_max.z	= r->updown_depth / r->frustum_depth;



	r-> label_min.x = p__label_spot_x   -   0.5 * p__label_size_x;
	r-> label_min.y = p__label_spot_y   -   0.5 * p__label_size_y;
	r-> label_min.z = 0.0;

	r-> label_max.x = p__label_spot_x   +   0.5 * p__label_size_x;
	r-> label_max.y = p__label_spot_y   +   0.5 * p__label_size_y;
	r-> label_max.z =  r->label_depth / r->frustum_depth;
    }
}

/* }}} */
/* {{{ xchc79_Insert_Msg -- ThingList to display us as lines & polys.	*/

xchc77_ReinsertVaryingPartOfMenu( lv_xchc )
LVAL				    lv_xchc;
{   /* Actually, we insert the varying part the first time around */
    /* too, as well as re-inserting it at need, of course ...     */

    extern LVAL s_bodything;
    extern LVAL s_fieldthing;
    extern LVAL s_textthing;
    extern LVAL k_left;

    LVAL        lv_body    = xthl90_GetObjectVariable( lv_xchc, s_bodything   );
    LVAL        lv_text    = xthl90_GetObjectVariable( lv_xchc, s_textthing   );

    cchc_rec*   r     = (cchc_rec*) gobjimmbase(  lv_xchc );

    float       f;
    char        buf[ CCHC_MAX_LABEL * 2 ];

    geo_point bbmin;
    geo_point bbmax;

    float     old_frustum_width = 1.0;	/* By definition -- width units.*/
    float     old_frustum_height= r->frustum_height;

    float     scalex;
    float     scaley;

    /* Worry about being called before :INSERT is done: */
    if (null( lv_body   ) ||
	null( lv_text   )
    ) {
	return;
    }

    /* Clear out any old stuff in */
    /* our hershey text thing:    */
    xthlJ1_EmptyThing( lv_text   );

    xthlL2_ObjectspaceBoundingBoxOfThing( &bbmin, &bbmax, lv_body );

    scalex  = (bbmax.x - bbmin.x)  / old_frustum_width ;
    scaley  = (bbmax.y - bbmin.y)  / old_frustum_height;

    /* "Up" */
    if (!r->omit_updown   &&   r->first_visible_choice) {
	geo_point p_min;	/* Parametric min of label bounding box */
	geo_point p_max;	/* Parametric max of label bounding box */
	geo_point r_min;	/* Real       min of label bounding box */
	geo_point r_max;	/* Real       max of label bounding box */
	float     scale;
	p_min	 = r->up_min;
	p_max	 = r->up_max;
	p_min.x += r->updown_depth;
	p_max.x -= r->updown_depth;

	/* Convert parametric to object-space coords: */
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	scale    = r_max.y - r_min.y;

	/* Insert hershey text for "Up" box: */
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= "Up";
	    a.font_num	= r->choice_font;
	    a.x		= (r_min.x + r_max.x) * 0.5;	/* x   location	*/
	    a.y		= (r_min.y + r_max.y) * 0.5;	/* y   location	*/
	    a.z		= (r_min.z	    )	   ;	/* z   location	*/
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_center;
	    xshpE0_Insert_Hershey_String( &a );
	}
    }

    /* "Down" */
    if (!r->omit_updown &&
	r->first_visible_choice + r->max_visible_choices   <   r->choice_count
    ) {
	geo_point p_min;	/* Parametric min of label bounding box */
	geo_point p_max;	/* Parametric max of label bounding box */
	geo_point r_min;	/* Real       min of label bounding box */
	geo_point r_max;	/* Real       max of label bounding box */
	float     scale;
	p_min	 = r->down_min;
	p_max	 = r->down_max;
	p_min.x += r->updown_depth;
	p_max.x -= r->updown_depth;

	/* Convert parametric to object-space coords: */
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	scale    = r_max.y - r_min.y;

	/* Insert hershey text for "Down" box: */
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= "Down";
	    a.font_num	= r->choice_font;
	    a.x		= (r_min.x + r_max.x) * 0.5;	/* x   location	*/
	    a.y		= (r_min.y + r_max.y) * 0.5;	/* y   location	*/
	    a.z		= (r_min.z	    )	   ;	/* z   location	*/
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_center;
	    xshpE0_Insert_Hershey_String( &a );
	}
    }

    /* Title: */
    if (!r->omit_label) {
	geo_point p_min;	/* Parametric min of label bounding box */
	geo_point p_max;	/* Parametric max of label bounding box */
	geo_point r_min;	/* Real       min of label bounding box */
	geo_point r_max;	/* Real       max of label bounding box */
	float     scale;
	p_min	 = r->label_min;
	p_max	 = r->label_max;
	p_min.x += r->label_depth;
	p_max.x -= r->label_depth;

	/* Convert parametric to object-space coords: */
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	scale    = r_max.y - r_min.y;

	/* Insert hershey text for label: */
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= r->label;
	    a.font_num	= r->label_font;
	    a.x		= (r_min.x + r_max.x) * 0.5;	/* x   location	*/
	    a.y		= (r_min.y + r_max.y) * 0.5;	/* y   location	*/
	    a.z		= (r_min.z	    )	   ;	/* z   location	*/
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_center;
	    xshpE0_Insert_Hershey_String( &a );
	}
    }

    /* Choices: */
    if (!r->omit_choices) {
	LVAL lv_choices = xthl90_GetObjectVariable( lv_xchc, s_choices );
	int i;
	for (i = r->max_visible_choices;   i --> 0;  ) {
	    geo_point p_min;	/* Parametric min of label bounding box */
	    geo_point p_max;	/* Parametric max of label bounding box */
	    geo_point r_min;	/* Real       min of label bounding box */
	    geo_point r_max;	/* Real       max of label bounding box */
	    float     scale;
	    LVAL   lv_choice;
	    char*     choice;
	    int       n = (r->max_visible_choices-(i+1)) + r->first_visible_choice;
	    float     h = r->frustum_height;
	    if (n >= r->choice_count)   continue;
	    lv_choice	= xthl95_nth( lv_choices, n, NIL, FALSE);
	    /* Allow both list of strings and list of lists headed */
	    /* by strings (so user can associate values with menu  */
	    /* entries):					   */
	    if (consp(lv_choice))   lv_choice = car( lv_choice );
	    if (!stringp(lv_choice)) xlerror("Need str",lv_choice);
	    choice	= (char*)getstring(lv_choice);
	    p_min	= r->choice_min;
	    p_max	= r->choice_max;
	    p_min.x    += r->choice_depth;
	    p_max.x    -= r->choice_depth;
	    p_min.y    += (r->choice_depth + i*r->choice_height) / h;
	    p_max.y     = p_min.y + r->choice_height / h;

	    /* Convert parametric to object-space coords: */
	    libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	    libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	    scale    = (r_max.y - r_min.y);

	    /* Insert hershey text for choice: */
	    {   struct xshp06_Args_Rec   a  ;
		xshp07_Init_Shape_Args( &a );
		a.lv_thing  = lv_text;
		a.text	    = choice;
		a.font_num  = r->choice_font;
		a.x	    = (r_min.x + r_max.x) * 0.5; /* x location */
		a.y	    = (r_min.y + r_max.y) * 0.5; /* y location */
		a.z	    = (r_min.z		)      ; /* z location */
		a.got_p	= TRUE;
		a.update_cursor	= FALSE;
		a.margin	= 0.0;
		a.got_margin= FALSE;
		a.vspacing  = 1.0;
		a.got_vspacing  = FALSE;
		a.scalex    = scale*scalex;
		a.scaley    = scale*scaley;
		a.scalez    = 1.0;
		a.lv_justify= k_center;
		xshpE0_Insert_Hershey_String( &a );
	    }
    }   }
}

#define LVALS_TO_PROTECT (5)
LVAL xchc78_Insert(
    lv_xchc,
    x0, y0, z0,
    scalex, scaley, scalez
)
LVAL  lv_xchc;
float x0, y0, z0;
float scalex, scaley, scalez;
{
    extern LVAL k_pickas;
    extern LVAL k_invisible;
    extern LVAL k_downclickhook;
    extern LVAL k_draghook;
    extern LVAL k_upclickhook;

    extern LVAL s_bodything;
    extern LVAL s_fieldthing;
    extern LVAL s_textthing;

    extern LVAL s_xg3dguixchcdownclickfn;
    extern LVAL s_xg3dguixchcdragfn;
    extern LVAL s_xg3dguixchcupclickfn;

    LVAL  lv_body, lv_field, lv_text;

    LVAL lv_thingList;

    cchc_rec* r = (cchc_rec*) gobjimmbase( lv_xchc );

    geo_point bbmin;
    geo_point bbmax;

    xlstkcheck(LVALS_TO_PROTECT);
    xlprotect( lv_xchc		);
    xlsave(    lv_body		);
    xlsave(    lv_field		);
    xlsave(    lv_text		);

    xlsave(    lv_thingList	);

    /* Fetch our three things from internal variables: */
    lv_body  = xthl90_GetObjectVariable( lv_xchc, s_bodything   );
    lv_field = xthl90_GetObjectVariable( lv_xchc, s_fieldthing  );
    lv_text  = xthl90_GetObjectVariable( lv_xchc, s_textthing   );

    /* If any of the above are null, assume someone is sending us */
    /* reshape messages before inserting us, and just return:     */
    if (null( lv_body   ) ||
	null( lv_field  ) ||
	null( lv_text   )
    ) {
	return;
    }

    /* Clear them out to make room for new shape: */
    xthlJ1_EmptyThing( lv_body   );
    xthlJ1_EmptyThing( lv_field  );

    xchc76_RecomputeLayout( lv_xchc );


    /* Insert our body frustum: */
    {   struct xshp06_Args_Rec a;
	xshp07_Init_Shape_Args( &a );
	a.x = x0;
	a.y = y0;
	a.z = z0;
	a.scalex = 1.0;
	a.scaley = r->frustum_height;
	a.scalez = 10.0*r->frustum_depth;
	a.lv_thing = lv_body;
	xshp22_Insert_Box_Or_Frustum( &a, 0 /* doBox */ );
    }

    /* Figure bounding box of body, so our parametric coords apply: */
    xthlL2_ObjectspaceBoundingBoxOfThing( &bbmin, &bbmax, lv_body );

    /* Insert a hole in body for choices: */
    if (!r->omit_choices) {
	geo_point p_min, p_max;
	geo_point r_min, r_max;
	float  h = r->frustum_height;
	int  i;
	p_min	= r->choice_min;
	p_max	= r->choice_max;
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (r_max.x + r_min.x) * 0.5;
	    a.y = (r_max.y + r_min.y) * 0.5;
	    a.z = (r_max.z + r_min.z) * 0.5;
	    a.scalex = (r_max.x - r_min.x)      ;
	    a.scaley = (r_max.y - r_min.y)      ;
	    a.scalez = (r_max.z - r_min.z) *10.0;
	    a.omit_bottom = TRUE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}

	/* Insert our field rectangles: */
	for (i = r->max_visible_choices;   i --> 0;  ) {
	    p_min	= r->choice_min;
	    p_max	= r->choice_max;
	    p_min.x    += r->choice_depth;
	    p_max.x    -= r->choice_depth;
	    p_min.y    += (r->choice_depth + i*r->choice_height) / h;
	    p_max.y     = p_min.y + r->choice_height / h;
	    libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	    libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	    /* Insert a field rectangle: */
	    {   struct xshp06_Args_Rec a;
		xshp07_Init_Shape_Args( &a );
		a.x0 = r_min.x;	a.y0 = r_min.y;	a.z0 = r_max.z;
		a.x1 = r_max.x;	a.y1 = r_min.y;	a.z1 = r_max.z;
		a.x2 = r_max.x;	a.y2 = r_max.y;	a.z2 = r_max.z;
		a.x3 = r_min.x;	a.y3 = r_max.y;	a.z3 = r_max.z;
		a.n  = 4;
		a.lv_thing = lv_field;
		xshp12_Insert_Facet( &a );
	    }
    }   }

    /* Insert a hole in body for "Up": */
    if (!r->omit_updown) {
	geo_point slot_min;
	geo_point slot_max;
	float     d;
	libP2_InterpolatePointInBox( &slot_min, &r->up_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &slot_max, &r->up_max, &bbmin, &bbmax );

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (slot_max.x + slot_min.x) * 0.5;
	    a.y = (slot_max.y + slot_min.y) * 0.5;
	    a.z = (slot_max.z + slot_min.z) * 0.5;
	    a.scalex = (slot_max.x - slot_min.x)      ;
	    a.scaley = (slot_max.y - slot_min.y)      ;
	    a.scalez = (slot_max.z - slot_min.z) *10.0;
	    a.omit_bottom = TRUE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}

	/* Insert our field rectangle: */
	d   = slot_max.z - slot_min.z;			/* Depth	*/
	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x0 = slot_min.x+d; a.y0 = slot_min.y+d; a.z0 = slot_max.z;
	    a.x1 = slot_max.x-d; a.y1 = slot_min.y+d; a.z1 = slot_max.z;
	    a.x2 = slot_max.x-d; a.y2 = slot_max.y-d; a.z2 = slot_max.z;
	    a.x3 = slot_min.x+d; a.y3 = slot_max.y-d; a.z3 = slot_max.z;
	    a.n  = 4;
	    a.lv_thing = lv_field;
	    xshp12_Insert_Facet( &a );
	}
    }

    /* Insert a hole in body for "Down": */
    if (!r->omit_updown) {
	geo_point slot_min;
	geo_point slot_max;
	float     d;
	libP2_InterpolatePointInBox( &slot_min, &r->down_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &slot_max, &r->down_max, &bbmin, &bbmax );

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (slot_max.x + slot_min.x) * 0.5;
	    a.y = (slot_max.y + slot_min.y) * 0.5;
	    a.z = (slot_max.z + slot_min.z) * 0.5;
	    a.scalex = (slot_max.x - slot_min.x)      ;
	    a.scaley = (slot_max.y - slot_min.y)      ;
	    a.scalez = (slot_max.z - slot_min.z) *10.0;
	    a.omit_bottom = TRUE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}

	/* Insert our field rectangle: */
	d   = slot_max.z - slot_min.z;			/* Depth	*/
	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x0 = slot_min.x+d; a.y0 = slot_min.y+d; a.z0 = slot_max.z;
	    a.x1 = slot_max.x-d; a.y1 = slot_min.y+d; a.z1 = slot_max.z;
	    a.x2 = slot_max.x-d; a.y2 = slot_max.y-d; a.z2 = slot_max.z;
	    a.x3 = slot_min.x+d; a.y3 = slot_max.y-d; a.z3 = slot_max.z;
	    a.n  = 4;
	    a.lv_thing = lv_field;
	    xshp12_Insert_Facet( &a );
	}
    }

    /* Insert a hole in body for label: */
    if (!r->omit_label) {
	geo_point slot_min;
	geo_point slot_max;
	libP2_InterpolatePointInBox( &slot_min, &r-> label_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &slot_max, &r-> label_max, &bbmin, &bbmax );

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (slot_max.x + slot_min.x) * 0.5;
	    a.y = (slot_max.y + slot_min.y) * 0.5;
	    a.z = (slot_max.z + slot_min.z) * 0.5;
	    a.scalex = (slot_max.x - slot_min.x)      ;
	    a.scaley = (slot_max.y - slot_min.y)      ;
	    a.scalez = (slot_max.z - slot_min.z) *10.0;
	    a.omit_bottom = FALSE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}
    }

    /* Insert hershey text: */
    xchc77_ReinsertVaryingPartOfMenu( lv_xchc );

    /* Do rescaling if user-requested: */
    if (scalex != 1.0  ||
        scaley != 1.0  ||
        scalez != 1.0
    ) {
	geo_matrix m;
	geo_point  origin;
	geo_point  scale;
	origin.x = x0;
	origin.y = y0;
	origin.z = z0;
	scale.x  = scalex;
	scale.y  = scaley;
	scale.z  = scalez;
        ctfm16_Scale( &m, &origin, &scale );

	xthlK1_TransformThing(lv_body,   &m, /*skip-points:*/0, /*skip-facets:*/0 );
	xthlK1_TransformThing(lv_field,  &m, /*skip-points:*/0, /*skip-facets:*/0 );
	xthlK1_TransformThing(lv_text,   &m, /*skip-points:*/0, /*skip-facets:*/0 );
    }

    /* Thread our things together to make a thinglist: */
    lv_thingList = cons( lv_body,   lv_thingList );
    lv_thingList = cons( lv_field,  lv_thingList );
    lv_thingList = cons( lv_text,   lv_thingList );

    xlpopn(LVALS_TO_PROTECT);
    return lv_thingList;
}
#undef LVALS_TO_PROTECT

LVAL xchc79_Insert_Msg()
{
    LVAL lv_xchc	= xchc01_Get_A_XCHC();

    LVAL lv_body	= NIL;
    LVAL lv_field	= NIL;
    LVAL lv_text	= NIL;

    float x0		= 0.0;
    float y0		= 0.0;
    float z0		= 0.0;

    float scalex	= 1.0;	int got_scalex	= FALSE;
    float scaley	= 1.0;	int got_scaley	= FALSE;
    float scalez	= 1.0;	int got_scalez	= FALSE;

    cchc_rec* r = (cchc_rec*) gobjimmbase( lv_xchc );

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_bodything) {

	    lv_body	= xlgacons();

	} else if (key == k_fieldthing) {

	    lv_field	= xlgacons();

	} else if (key == k_textthing) {

	    lv_text	= xlgacons();

        } else if (key == k_x) {
	    x0		= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
        } else if (key == k_y) {
	    y0		= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
        } else if (key == k_z) {
	    z0		= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

        } else if (key == k_scale) {
	    float scale	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    if (!got_scalex) scalex = scale;
	    if (!got_scaley) scaley = scale;
	    if (!got_scalez) scalez = scale;

        } else if (key == k_scalex) {
	    scalex	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    got_scalex	= TRUE;
        } else if (key == k_scaley) {
	    scaley	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    got_scaley	= TRUE;
        } else if (key == k_scalez) {
	    scalez	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    got_scalez	= TRUE;

	} else {

	    xlerror("Bad :INSERT keyword",key);
        }
    }

    /* Probably should default these to something someday: */
    if (null(lv_body  )) xlfail(":INSERT: no :BODY-THING"  );
    if (null(lv_field )) xlfail(":INSERT: no :FIELD-THING" );
    if (null(lv_text  )) xlfail(":INSERT: no :TEXT-THING"  );

    /* Save our four things in internal variables: */
    xthl91_SetObjectVariable( lv_xchc, s_bodything  , lv_body   );
    xthl91_SetObjectVariable( lv_xchc, s_fieldthing , lv_field  );
    xthl91_SetObjectVariable( lv_xchc, s_textthing  , lv_text   );

    /* Set field hook functions: */
    xthl82_SetProp(&lv_field,k_widget       ,lv_xchc				);
    xthl82_SetProp(&lv_field,k_downclickhook,getfunction(s_xg3dguixchcdownclickfn) );
    xthl82_SetProp(&lv_field,k_draghook     ,getfunction(s_xg3dguixchcdragfn     ) );
    xthl82_SetProp(&lv_field,k_upclickhook  ,getfunction(s_xg3dguixchcupclickfn  ) );

    return xchc78_Insert(
	lv_xchc,
	x0, y0, z0,
	scalex, scaley, scalez
    );
}

/* }}} */
/* {{{ xchc91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xchc90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XCHC_PROPS + x03d89_PropListLength( *pPropList ) );
}
LVAL xchc91_ProplistLength_Msg()
{
    return xchc90_ProplistLength( xchc01_Get_A_XCHC() );
}

/* }}} */
/* {{{ xchc95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xchc94_ProplistNth( lv_g )
LVAL                     lv_g;
{
    LVAL*pPropList  = x03d73_pPropList( lv_g );
    LVAL lv_n       = xlgafixnum();
    int  n          = getfixnum(lv_n);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case  0: return k_choice;
    case  1: return k_label;
    case  2: return k_labelfont;
    case  3: return k_choicefont;
    case  4: return k_verticalmargin;
    case  5: return k_horizontalmargin;
    case  6: return k_choiceheight;
    case  7: return k_updownheight;
    case  8: return k_labelheight;
    case  9: return k_frustumdepth;
    case 10: return k_choicedepth;
    case 11: return k_updowndepth;
    case 12: return k_labeldepth;
    case 13: return k_maxvisiblechoices;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XCHC_PROPS,
	    lv_n,
	    default_val,
	    got_default
	);
    }
}
LVAL xchc95_ProplistNth_Msg()
{
    return xchc94_ProplistNth( xchc01_Get_A_XCHC() );
}

/* }}} */
/* {{{ xchcz7_Read_Xchc_From_File                                       */

xchcz7_Read_Xchc_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   cchc_rec* h;
    char*     p;
    if (version != CCHC_REC_VERSION) {
	xlerror("xchcz7: unsupported version",cvfixnum(version));
    }
    h = (cchc_rec*) gobjimmbase( lv );

    p = (char*) &h->CCHC_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CCHC_INT32_COUNT,  magic, fp );

    p = (char*) &h->CCHC_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CCHC_FLOAT_COUNT,  magic, fp );

    p = (char*) &h->CCHC_FIRST_BYTE;
    p = cfil52_Read_Bytes_From_File(   p, CCHC_BYTE_COUNT ,  magic, fp );
}

/* }}} */
/* {{{ xchcwo_Write_Xchc_To_Graphics_File                               */

xchcwo_Write_Xchc_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   cchc_rec* h = (cchc_rec*) gobjimmbase( lv );
	char*     p;

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CCHC_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CCHC_FIRST_INT32, CCHC_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CCHC_FIRST_FLOAT, CCHC_FLOAT_COUNT, fdob);
	cfil45_Write_Bytes_To_File( &h->CCHC_FIRST_BYTE , CCHC_BYTE_COUNT , fdob);
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

