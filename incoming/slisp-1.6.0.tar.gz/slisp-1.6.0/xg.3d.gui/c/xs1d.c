/* {{{ xs1d.c -- Sliders, 1-Dimensional.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jun29
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Jun29 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/cshp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xs1d;
extern LVAL k_enforcemaxx;
extern LVAL k_enforceminx;
extern LVAL k_frustumdepth;
extern LVAL k_horizontalmargin;
extern LVAL k_label;
extern LVAL k_labelfont;
extern LVAL k_labelheight;
extern LVAL k_lastdeltax;
extern LVAL k_limitfont;
extern LVAL k_limitsheight;
extern LVAL k_maxx;
extern LVAL k_minx;
extern LVAL k_neutralx;
extern LVAL k_sliderdepth;
extern LVAL k_sliderheight;
extern LVAL k_verticalmargin;
extern LVAL k_x;
extern LVAL k_bodything;
extern LVAL k_changehook;
extern LVAL k_downclickhook;
extern LVAL k_draghook;
extern LVAL k_fieldthing;
extern LVAL k_initializefromfile;
extern LVAL k_labeldepth;
extern LVAL k_limitsdepth;
extern LVAL k_right;
extern LVAL k_sliderlength;
extern LVAL k_sliderthing;
extern LVAL k_textthing;
extern LVAL k_upclickhook;
extern LVAL k_widget;
extern LVAL k_y;
extern LVAL s_bodything;
extern LVAL s_xg3dguicurrentwidget;
extern LVAL k_z;
extern LVAL k_scale;
extern LVAL k_scalex;
extern LVAL k_scaley;
extern LVAL k_scalez;
extern LVAL s_sliderthing;
extern LVAL s_fieldthing;
extern LVAL s_textthing;
extern LVAL k_pickas;
extern LVAL k_invisible;
extern LVAL s_xg3dguixs1ddownclickfn;
extern LVAL s_xg3dguixs1ddragfn;
extern LVAL s_xg3dguixs1dupclickfn;
extern LVAL k_srcloc;

extern LVAL s_stdout;
extern LVAL xsendmsg0();
extern LVAL xsendmsg0();
LVAL  xs1d41_Put();
LVAL  xs1d71_Do_Hook_Fn();
LVAL  xs1d78_Insert();

#include <math.h>
#include <string.h>
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/cthl.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/clgt.h"
#include "../../xg.3d/c/ccmr.h"
#include "../../xg.3d.fileio/c/cfil.h"
#include "cs1d.h"

cs1d_rec* xs1d9c_Find_Immediate_Base();

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xs1d00_Is_New -- Initialize a new xs1d instance.			*/

/* Following are in fractions of the total width of widget: */
#define VERTICAL_MARGIN     0.01
#define HORIZONTAL_MARGIN   0.01

#define SLIDER_HEIGHT       0.04
#define LIMITS_HEIGHT       0.04
#define LABEL_HEIGHT        0.04

#define FRUSTUM_DEPTH       0.02
#define SLIDER_DEPTH        0.01
#define LIMITS_DEPTH        0.01
#define LABEL_DEPTH         0.01

#define SLIDER_LENGTH	    0.025
#define SLIDER_LENGTH_MIN   0.001
#define SLIDER_LENGTH_MAX   0.999

cs1d_rec xs1d_defaults = {
    C03D_xS1D,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */
    CS1D_STYLE_1,		/* slider_style.		*/
    TRUE,			/* enforce_min_x		*/
    TRUE,			/* enforce_max_x		*/
    1,				/* limit_font			*/
    1,				/* label_font			*/
    FALSE,			/* omit_slider			*/
    FALSE,			/* omit_limits			*/
    FALSE,			/* omit_label			*/
    FALSE,			/* omit_body			*/
    FALSE,			/* in_changehook		*/
    ~13,			/* spare_1			*/
    ~13,			/* spare_2			*/

    0.0,			/* min_x			*/
    0.5,			/* x				*/
    0.5,			/* neutral_x			*/
    1.0,			/* max_x			*/
    0.0,			/* last_delta_x			*/

    VERTICAL_MARGIN	,	/* vertical_margin              */
    HORIZONTAL_MARGIN	,	/* horizontal_margin   	       	*/

    SLIDER_HEIGHT	,	/* slider_height                */
    LIMITS_HEIGHT	,	/* limits_height                */
    LABEL_HEIGHT	,	/* label_height	               	*/

    SLIDER_DEPTH	,	/* slider_depth	               	*/
    LIMITS_DEPTH	,	/* limits_depth	               	*/
    LABEL_DEPTH		,	/* label_depth	                */

    SLIDER_LENGTH	,	/* slider_length		*/
    FRUSTUM_DEPTH	,	/* frustum_depth                */

    0.0			,	/* frustum_height		*/

    0.0,			/* text_spot_x			*/
    0.0,			/* text_spot_y			*/
    1.0,			/* text_scale_x			*/
    1.0,			/* text_scale_y			*/

    {0.1,0.1,0.0},		/* slider_min			*/
    {0.2,0.2,0.2},		/* slider_max			*/

    {0.3,0.3,0.0},		/* limits_min			*/
    {0.4,0.4,0.2},		/* limits_max			*/

    {0.5,0.5,0.0},		/*  label_min			*/
    {0.6,0.6,0.2},		/*  label_max			*/

   -314155.0,			/* fspare_1			*/
    "(nameless)\0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
};

LVAL xs1d00_Is_New()
/*-
    Initialize a new xs1d instance.
-*/
{
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    cs1d_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xs1dp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( cs1d_rec ) );

    /* Initialize slider record to reasonable default values: */
    r	= (cs1d_rec*) gobjimmbase( lv );
   *r   = xs1d_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    xs1d41_Put( lv );

    return lv;
}

/* }}} */
/* {{{ xs1d01_Get_A_XS1D -- Get arg, must be of class xs1d.			*/

LOCAL LVAL xs1d01_Get_A_XS1D()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XS1D has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xs1d.  Similarly,          */
    /* nobody but nobody has any business resizing a xs1d,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xs1dp(m_as_lval) ||
        getgobjimmbytes(m_as_lval) != sizeof(cs1d_rec)
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xs1d03_Show_Msg -- Show the contents of a cs1d.			*/

LVAL xs1d03_Show_Msg()
{
    LVAL lv,fptr;

    /* get self and the file pointer */
    lv   = xs1d01_Get_A_XS1D();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(lv,fptr);
    xgbj52_Show_Lval_Vector(lv,fptr);

    /* Print the s1d record: */
    {   cs1d_rec * r = xs1d9c_Find_Immediate_Base( lv );
	libE5_xlprint_int(   "style"		,  r->slider_style , fptr );
	libE5_xlprint_int(   "enforce-min-x"	,  r->enforce_min_x, fptr );
	libE5_xlprint_int(   "enforce-max-x"	,  r->enforce_max_x, fptr );
	libE6_xlprint_float( "min-x"		,  r->min_x	   , fptr );
	libE6_xlprint_float( "x"		,  r->x		   , fptr );
	libE6_xlprint_float( "max-x"		,  r->max_x	   , fptr );
	libE6_xlprint_float( "neutral-x"	,  r->neutral_x	   , fptr );
	/* Should print 'label' sometime :) (buggo) */
    }

    /* return the gobject */
    return lv;
}

/* }}} */
/* {{{ xs1d08_Copy_Msg -- Build copy of given CS1D.				*/

LVAL xs1d09_Copy( m_as_lval )
LVAL		  m_as_lval;
{
    /* Create a new gobject to hold result: */
    cs1d_rec*mh = xs1d9c_Find_Immediate_Base( m_as_lval );
    cs1d_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xs1d,k_new);
    xlpop();
    nh = (cs1d_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}
LVAL xs1d08_Copy_Msg()
{
    LVAL m_as_lval;
    LVAL x_as_lval = xs1d01_Get_A_XS1D();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xs1d09_Copy(x_as_lval);
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xs1d28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT
LVAL xs1d28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {   char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xs1d29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xs1d01_Get_A_XS1D();
    LVAL n_as_lval = xs1d01_Get_A_XS1D();
    xllastarg();
    return xs1d28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xs1d40_Get_Msg -- Get keyword properties.                            */

LVAL xs1d39_Get( lv_xs1d )
LVAL             lv_xs1d;
{
    extern LVAL true;/*xlglob.c*/
    cs1d_rec* r = xs1d9c_Find_Immediate_Base( lv_xs1d );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if        (key == k_minx) {

	result = cvflonum( r->min_x );

    } else if (key == k_maxx) {

	result = cvflonum( r->max_x );

    } else if (key == k_x) {

	result = cvflonum( r->x );

    } else if (key == k_neutralx) {

	result = cvflonum( r->neutral_x );

    } else if (key == k_lastdeltax) {

	result = cvflonum( r->last_delta_x );

    } else if (key == k_enforceminx) {

        result = r->enforce_min_x ? true : NIL;

    } else if (key == k_enforcemaxx) {

        result = r->enforce_max_x ? true : NIL;

    } else if (key == k_label) {

        result = cvstring( r->label );

    } else if (key == k_labelfont) {

        result = cvfixnum( r->label_font );

    } else if (key == k_limitfont) {

        result = cvfixnum( r->limit_font );

    } else if (key == k_verticalmargin) {
	result = cvflonum( r->vertical_margin );
    } else if (key == k_horizontalmargin) {
	result = cvflonum( r->horizontal_margin );

    } else if (key == k_sliderheight) {
	result = cvflonum( r->slider_height );
    } else if (key == k_limitsheight) {
	result = cvflonum( r->limits_height );
    } else if (key == k_labelheight) {
	result = cvflonum( r->label_height );

    } else if (key == k_frustumdepth) {
	result = cvflonum( r->frustum_depth );
    } else if (key == k_sliderdepth) {
	result = cvflonum( r->slider_depth );
    } else if (key == k_limitsdepth) {
	result = cvflonum( r->limits_depth );
    } else if (key == k_labeldepth) {
	result = cvflonum( r->label_depth );

    } else if (key == k_sliderlength) {
	result = cvflonum( r->slider_length );

    } else {

	/* If this isn't a property we know, do a generic get property: */
        result = xthl8a_GetObjectProp( lv_xs1d, key, default_val, got_default );
    }
    return result;
}
LVAL xs1d40_Get_Msg()
{
    return xs1d39_Get( xs1d01_Get_A_XS1D() );
}

/* }}} */
/* {{{ xs1d42_Put_Msg -- Write keyword properties.                          */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Put, update XS1D_PROPS and xs1d94_ProplistNth. */
#define XS1D_PROPS (19)

/* A little macro to make this fn a little neater: */
#define XS1D_REDO(x) {		\
    x;				\
    rebuild = TRUE;		\
}

LVAL xs1d41_Put( lv_xs1d )
LVAL             lv_xs1d;
{
    cs1d_rec* r = xs1d9c_Find_Immediate_Base( lv_xs1d );
    extern LVAL true;/*xlglob.c*/
    int rebuild = FALSE;

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xs1dz7_Read_Xs1d_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_xs1d,
		getfile(xlgetfile()),
		xs1dz7_Read_Xs1d_From_File,NULL
	    );

	} else if (key == k_minx) {

	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())) {
		r->min_x = f;
		rebuild  = TRUE;
	    }

        } else if (key == k_maxx) {

	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())) {
		r->max_x = f;
		rebuild  = TRUE;
	    }

        } else if (key == k_x) {

	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())) {
		xs1d61_Set_X( lv_xs1d, f );
	    }

        } else if (key == k_neutralx) {

	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())) {
		r->neutral_x = f;
	    }

        } else if (key == k_enforceminx) {

	    r->enforce_min_x = !null( xlgetarg() );

        } else if (key == k_enforcemaxx) {

	    r->enforce_max_x = !null( xlgetarg() );

        } else if (key == k_label) {

	    LVAL lv_string = xlgastring();
	    strncpy(r->label,(char*)getstring(lv_string),CS1D_MAX_LABEL);
	    r->label[ CS1D_MAX_LABEL -1 ] = '\0';
	    rebuild	   = TRUE;

        } else if (key == k_labelfont) {

	    float ffont;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&ffont,xlgetarg())) {
		int font = ffont;
		if (font <  0)   font =  0;
		if (font > 11)   font = 11;
		r->label_font = font;
		rebuild	  = TRUE;
	    }

        } else if (key == k_limitfont) {

	    float ffont;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&ffont,xlgetarg())) {
		int font = ffont;
		if (font <  0)   font =  0;
		if (font > 11)   font = 11;
		r->limit_font = font;
		rebuild       = TRUE;
	    }

        } else if (key == k_verticalmargin) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
		f>0.0                                          &&
                f!=r->vertical_margin
	    ) {
		XS1D_REDO( r->vertical_margin   = f );
	    }
        } else if (key == k_horizontalmargin) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
		f>0.0                                          &&
                f<0.45                                         &&
		f!=r->horizontal_margin
            ) {
                XS1D_REDO( r->horizontal_margin = f );
	    }
        } else if (key == k_sliderheight) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>=0.0                                         &&
                f!=r->slider_height
            ) {
                XS1D_REDO( r->slider_height     = f );
            }
        } else if (key == k_limitsheight) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>=0.0                                         &&
                f!=r->limits_height
            ) {
                XS1D_REDO( r->limits_height     = f );
            }
        } else if (key == k_labelheight) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>=0.0                                         &&
                f!=r-> label_height
            ) {
                XS1D_REDO( r->label_height      = f );
            }

        } else if (key == k_frustumdepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f<0.3                                          &&
                f!=r->frustum_depth
            ) {
                XS1D_REDO( r->frustum_depth     = f );
            }
        } else if (key == k_sliderdepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f<0.3                                          &&
                f!=r->slider_depth
            ) {
                XS1D_REDO( r->slider_depth      = f );
            }
        } else if (key == k_limitsdepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f<0.3                                          &&
                f!=r->limits_depth
            ) {
                XS1D_REDO( r->limits_depth      = f );
            }
        } else if (key == k_labeldepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
	        f>0.0                                          &&
                f<0.3                                          &&
                f!=r->label_depth
            ) {
                XS1D_REDO( r->label_depth       = f );
            }

        } else if (key == k_sliderlength) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())) {
		if (f < SLIDER_LENGTH_MIN) f = SLIDER_LENGTH_MIN;
		if (f > SLIDER_LENGTH_MAX) f = SLIDER_LENGTH_MAX;
		if (f != r->slider_length) {
                    XS1D_REDO( r->slider_length 	   = f );
	    }   }
	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_xs1d, key, xlgetarg() );
        }
    }
    if (r->min_x >= r->max_x)   r->min_x = r->max_x - SLIDER_LENGTH_MIN;
    if (r->x     <  r->min_x)   xs1d61_Set_X( lv_xs1d, r->min_x );
    if (r->x     >  r->max_x)   xs1d61_Set_X( lv_xs1d, r->max_x );

    if (rebuild)   xs1d75_RebuildGeometry( lv_xs1d );

    return lv_xs1d;
}
#undef XS1D_REDO
LVAL xs1d42_Put_Msg()
{   /* Read keyword properties for a slider object. */
    LVAL   lv_xs1d = xs1d01_Get_A_XS1D();
    LVAL   result  = xs1d41_Put( lv_xs1d );
    return result;
}

/* }}} */
/* {{{ xs1d61_Set_X		Main fn to set X, call hooks.			*/

xs1d61_Set_X( lv_xs1d, new_x_value )
LVAL	      lv_xs1d;
float		       new_x_value;
{   cs1d_rec*   r = xs1d9c_Find_Immediate_Base(  lv_xs1d );
    if (r->x	       != new_x_value) {
	r->last_delta_x	= new_x_value - r->x;
        r->x  		= new_x_value;

	xs1d71_Do_Hook_Fn( lv_xs1d, k_changehook );

        /* Update our appearance: */
        xs1d77_ReinsertVaryingPartOfSlider( lv_xs1d );
    }
}

/* }}} */
/* {{{ xs1d63_Click		Main fn to handle upclick/downclick/drag	*/

LVAL xs1d63_Click( lv_hook )
LVAL		   lv_hook; /* k_upclickhook/k_draghook/k_downclickhook */
{   /*********************************************/
    /* We've been called as a hook fn, need to   */
    /* update our appearance etc to track mouse. */
    /*********************************************/
    extern LVAL k_selectedthing;
    extern LVAL k_get;

    /* We've been called with no arguments: */
    int  csux0	  = (
	xcmrC3_RunningWidgets ||
	xlfail("CLASS-SLIDER Hookfn not called via :RUN-WIDGETS")
    );

    /* But we need some arguments! */
    LVAL lv_thing = xcmrC2_RunWidgets_Rec.lv_selected_thing;
    LVAL lv_xs1d  = xthl74_GetProp( &lv_thing, k_widget, NIL,/*got_default:*/FALSE);
    int  csux1 	  = (
	xs1dp(lv_xs1d) ||
	xlerror("Not CLASS-SLIDER instance:",lv_xs1d)
    );
    cs1d_rec*   r = xs1d9c_Find_Immediate_Base(  lv_xs1d );
    float       f = xcmrC2_RunWidgets_Rec.selected_parametric_facet_location.x;
    xllastarg();
    r->in_changehook	= FALSE;/* Guard against it getting stuck ON */

    /******************************************************/
    /* f, the spot the user clicked on, arrives in 0->1.  */
    /* First need to curtate this value to the physically */
    /* accessable slider range and then scale that to the */
    /* logical range currently assigned to the slider.	  */
    /******************************************************/
    f		  = ((f - 0.5)   /   (1.0 - r->slider_length))     +     0.5;
    if (f < 0.0) f= 0.0;
    if (f > 1.0) f= 1.0;
    f		  = f * (r->max_x - r->min_x)   +   r->min_x;

    xs1d61_Set_X( lv_xs1d, f );

    return xs1d71_Do_Hook_Fn( lv_xs1d, lv_hook );
}

/* }}} */
/* {{{ xs1d65_Downclick_Fn -- Function to implement slider downclick.	*/

LVAL xs1d69_Drag_Fn();
LVAL xs1d65_Downclick_Fn()
{   return xs1d63_Click( k_downclickhook );
}

/* }}} */
/* {{{ xs1d67_Upclick_Fn -- Function to implement slider upclick.		*/

LVAL xs1d67_Upclick_Fn()
{   return xs1d63_Click( k_upclickhook );
}

/* }}} */
/* {{{ xs1d69_Drag_Fn -- Function to implement slider drag.			*/

LVAL xs1d69_Drag_Fn()
{   return xs1d63_Click( k_draghook );
}

/* }}} */
/* {{{ xs1d71_Do_Hook_Fn -- Call user-supplied hook fns.			*/

LVAL xs1d70_Do_Hook_Fn( lv_xs1d, lv_hookfns )
LVAL			lv_xs1d;
LVAL				 lv_hookfns;
{
    LVAL     lv_old_current_widget = getvalue( s_xg3dguicurrentwidget );
    xlprot1( lv_old_current_widget );
    setvalue( s_xg3dguicurrentwidget, lv_xs1d );

    xthlF5_Call_HookFns( lv_hookfns );

    setvalue( s_xg3dguicurrentwidget, lv_old_current_widget );
    xlpop();
    return NIL;
}
LVAL xs1d71_Do_Hook_Fn( lv_xs1d, lv_hook )
LVAL			lv_xs1d;
LVAL				 lv_hook; /* k_changehook/k_downclickhook/...*/
{   cs1d_rec* r	    = xs1d9c_Find_Immediate_Base( lv_xs1d );
    LVAL lv_hookfns = xthl8a_GetObjectProp( lv_xs1d, lv_hook, NIL,TRUE );
    if (null(lv_hookfns))   return NIL;
    if (lv_hook != k_changehook)   return xs1d70_Do_Hook_Fn( lv_xs1d, lv_hookfns );

    /* A little dodge so changehooks can modify our	*/
    /* value without slipping into infinite recursion:	*/
    if (r->in_changehook)   return NIL;
    r    ->in_changehook	= TRUE;
    /* Bad news if we get an error and leave this flag	*/
    /* set... as a partial fix, we clear it various	*/
    /* places.						*/
    xs1d70_Do_Hook_Fn( lv_xs1d, lv_hookfns );
    r    ->in_changehook	= FALSE;
    return NIL;
}

/* }}} */
/* {{{ xs1d75_RebuildGeometry -- Rebuild our shape to new specs.		*/

xs1d75_RebuildGeometry( lv_xs1d )
LVAL			lv_xs1d;
{
    /********************************************************************/
    /* Compute our current origin and scale factors by looking at our	*/
    /* bounding box, after which xs1d78_Insert will do the rest of our	*/
    /* work.								*/
    /*									*/
    /* We use this somewhat roundabout technique (deduction from our	*/
    /* bounding box) so as to attempt to work correctly even if the	*/
    /* app hacker rescales or moves us without telling us.  Ideally,	*/
    /* we'd also work if s/he rotated us.  Someday :).			*/
    /********************************************************************/
    cs1d_rec* r			= xs1d9c_Find_Immediate_Base( lv_xs1d );
    float     old_frustum_width = 1.0;	/* By definition -- width units.*/	
    float     old_frustum_height= r->frustum_height;
    float     old_frustum_depth	= r->frustum_depth;
    LVAL      lv_body		= xthl90_GetObjectVariable( lv_xs1d, s_bodything );


    if (!null(lv_body)) {      /* May get called before we're inserted! */
	geo_point bbmin;
	geo_point bbmax;
        int       csux0	  = xs1d76_RecomputeLayout(   lv_xs1d );
	int       csux1   = xthlL2_ObjectspaceBoundingBoxOfThing( &bbmin, &bbmax, lv_body );

	float     x0      = (bbmax.x + bbmin.x) * 0.5;
	float     y0      = (bbmax.y + bbmin.y) * 0.5;
	float     z0      = (bbmax.z + bbmin.z) * 0.5;

	float     scalex  = (bbmax.x - bbmin.x)  / old_frustum_width ;
	float     scaley  = (bbmax.y - bbmin.y)  / old_frustum_height;
	float     scalez  = (bbmax.z - bbmin.z)  / old_frustum_depth ;

	xs1d78_Insert(
	    lv_xs1d,
	    x0, y0, z0,
	    scalex, scaley, scalez
	);
    }
}

/* }}} */
/* {{{ xs1d76_RecomputeLayout						*/

xs1d76_RecomputeLayout( lv_xs1d )
LVAL			lv_xs1d;
{
    float slot_depth;
    cs1d_rec* r        = xs1d9c_Find_Immediate_Base( lv_xs1d );
    LVAL      lv_body  = xthl90_GetObjectVariable(   lv_xs1d, s_bodything   );

    /* If body is null, assume someone is sending us */
    /* reshape messages before inserting us:         */
    if (null( lv_body   ))  return;

    /* Remember which parts we are missing: */
    r->omit_slider = (r->slider_height == 0.0);
    r->omit_limits = (r->limits_height == 0.0);
    r->omit_label  = (r-> label_height == 0.0);

    /* Worry about nonsensical user layouts: */
    if (!r->omit_slider && r->frustum_depth < r->slider_depth) {
        r->frustum_depth = r->slider_depth;
    }
    if (!r->omit_limits && r->frustum_depth < r->limits_depth) {
        r->frustum_depth = r->limits_depth;
    }
    if (!r->omit_label  && r->frustum_depth < r-> label_depth) {
	r->frustum_depth = r-> label_depth;
    }
    if (!r->omit_slider && r->slider_height < 3.0 * r->slider_depth) {
	r->slider_height = 3.0*r->slider_depth;
    }
    for (;;) {
	/* All user input is in fractions of total width, */
	/* so width better not sum to more than 1.0 here: */
	float width;
	float     min_slider_width   = (
	    2.0 * r->slider_depth
	    + 0.0001	/* Allow *some* surface area :) */
	);
        if (r->omit_slider)   min_slider_width = 0.0;
        slot_depth = 0.0;
	if (!r->omit_slider   &&   r->slider_depth > slot_depth)   slot_depth = r->slider_depth;
	if (!r->omit_limits   &&   r->limits_depth > slot_depth)   slot_depth = r->limits_depth;
	if (!r->omit_label    &&   r-> label_depth > slot_depth)   slot_depth = r-> label_depth;
	width = (
	    2.0 * r->horizontal_margin +
	    2.0 *    slot_depth        +
	    2.0 * r->frustum_depth     +
	    min_slider_width
	);

	if (width <= 1.0)   break;

	/* Shrink-to-fit: */
	r->vertical_margin	*= 0.99;
	r->horizontal_margin	*= 0.99;
	r->frustum_depth	*= 0.99;
	r->slider_depth		*= 0.99;
	r->limits_depth		*= 0.99;
	r->label_depth		*= 0.99;
    }

    /* Figure total height of widget, relative to width: */
    r                          ->frustum_height  = (
	2.0 * r->frustum_depth + r->vertical_margin
    );
    if (!r->omit_slider)      r->frustum_height += (
	2.0 * r->slider_depth  + r->vertical_margin +  r->slider_height
    );
    if (!r->omit_limits)      r->frustum_height += (
	2.0 * r->limits_depth  + r->vertical_margin +  r->limits_height
    );
    if (!r->omit_label)	      r->frustum_height += (
	2.0 * r->label_depth   + r->vertical_margin +  r->label_height
    );

    /* Figure parametric coordinates of various parts of slider.   */
    /* p_* are parameterized in bounding_box==1.0 units, x,y &z.   */
    {   float pvm  = r->  vertical_margin / r->frustum_height;	/* "Parametric Vertical   Margin"*/
        float phm  = r->horizontal_margin / 1.0;		/* "Parametric Horizontal Margin"*/
        float pvfd = r->frustum_depth     / r->frustum_height;
        float phfd = r->frustum_depth     / 1.0;

	float p_slider_depth  = r->slider_depth / r->frustum_depth;
	float p_limits_depth  = r->limits_depth / r->frustum_depth;
	float p__label_depth  = r-> label_depth / r->frustum_depth;

	float p_slider_spot_x = 0.5;
	float p_limits_spot_x = 0.5;
	float p__label_spot_x = 0.5;

	float p_slider_spot_y = 0.0;
	float p_limits_spot_y = 0.0;
	float p__label_spot_y = 0.0;

	float p_slider_size_x = 1.0 - 2.0*(phfd+phm);
	float p_limits_size_x = 1.0 - 2.0*(phfd+phm);
	float p__label_size_x = 1.0 - 2.0*(phfd+phm);

	float p_slider_size_y = (r->slider_height + 2.0*r->slider_depth)/r->frustum_height;
	float p_limits_size_y = (r->limits_height + 2.0*r->limits_depth)/r->frustum_height;
	float p__label_size_y = (r-> label_height + 2.0*r-> label_depth)/r->frustum_height;

	float p_loc	      = pvfd + pvm;

	if (!r->omit_slider) {
	    p_slider_spot_y   =p_loc+(0.5*r->slider_height +    r->slider_depth)/r->frustum_height;
	    p_loc	     +=  pvm+(    r->slider_height +2.0*r->slider_depth)/r->frustum_height;
	}
	if (!r->omit_limits) {
	    p_limits_spot_y   =p_loc+(0.5*r->limits_height +    r->limits_depth)/r->frustum_height;
	    p_loc	     +=  pvm+(    r->limits_height +2.0*r->limits_depth)/r->frustum_height;
	}
	if (!r->omit_label) {
	    p__label_spot_y   =p_loc+(0.5*r-> label_height  +   r-> label_depth)/r->frustum_height;
	}

	r->slider_min.x = p_slider_spot_x   -   0.5 * p_slider_size_x;
	r->slider_min.y = p_slider_spot_y   -   0.5 * p_slider_size_y;
	r->slider_min.z = 0.0;

	r->slider_max.x = p_slider_spot_x   +   0.5 * p_slider_size_x;
	r->slider_max.y = p_slider_spot_y   +   0.5 * p_slider_size_y;
	r->slider_max.z = r->slider_depth / r->frustum_depth;


	r->limits_min.x = p_limits_spot_x   -   0.5 * p_limits_size_x;
	r->limits_min.y = p_limits_spot_y   -   0.5 * p_limits_size_y;
	r->limits_min.z = 0.0;

	r->limits_max.x = p_limits_spot_x   +   0.5 * p_limits_size_x;
	r->limits_max.y = p_limits_spot_y   +   0.5 * p_limits_size_y;
	r->limits_max.z = r->limits_depth / r->frustum_depth;


	r-> label_min.x = p__label_spot_x   -   0.5 * p__label_size_x;
	r-> label_min.y = p__label_spot_y   -   0.5 * p__label_size_y;
	r-> label_min.z = 0.0;

	r-> label_max.x = p__label_spot_x   +   0.5 * p__label_size_x;
	r-> label_max.y = p__label_spot_y   +   0.5 * p__label_size_y;
	r-> label_max.z =  r->label_depth / r->frustum_depth;
    }
}

/* }}} */
/* {{{ xs1d79_Insert_Msg -- ThingList to display us as lines & polys.	*/

xs1d77_ReinsertVaryingPartOfSlider( lv_xs1d )
LVAL				    lv_xs1d;
{   /* Actually, we insert the varying part the first time around */
    /* too, as well as re-inserting it at need, of course ...     */

    extern LVAL s_bodything;
    extern LVAL s_sliderthing;
    extern LVAL s_fieldthing;
    extern LVAL s_textthing;
    extern LVAL k_left;

    LVAL        lv_body    = xthl90_GetObjectVariable( lv_xs1d, s_bodything   );
    LVAL        lv_text    = xthl90_GetObjectVariable( lv_xs1d, s_textthing   );
    LVAL        lv_slider  = xthl90_GetObjectVariable( lv_xs1d, s_sliderthing );

    cs1d_rec*   r     = xs1d9c_Find_Immediate_Base( lv_xs1d );

    float       f;
    char        buf[ CS1D_MAX_LABEL * 2 ];

    geo_point bbmin;
    geo_point bbmax;

    float     old_frustum_width = 1.0;	/* By definition -- width units.*/	
    float     old_frustum_height= r->frustum_height;

    float     scalex;
    float     scaley;

    /* Worry about being called before :INSERT is done: */
    if (null( lv_body   ) ||
	null( lv_slider ) ||
	null( lv_text   )
    ) {
	return;
    }

    /* Clear out any old stuff in our  */
    /* slider and hershey text things: */
    xthlJ1_EmptyThing( lv_text   );
    xthlJ1_EmptyThing( lv_slider );

    xthlL2_ObjectspaceBoundingBoxOfThing( &bbmin, &bbmax, lv_body );

    scalex  = (bbmax.x - bbmin.x)  / old_frustum_width ;
    scaley  = (bbmax.y - bbmin.y)  / old_frustum_height;

    /* Insert our slider frustum: */
    if (!r->omit_slider) {

	/* Figure slider position and shape parametrically: */
	geo_point p_min;	/* Parametric min of slider bounding box */
	geo_point p_max;	/* Parametric max of slider bounding box */
	geo_point r_min;	/* Real       min of slider bounding box */
	geo_point r_max;	/* Real       max of slider bounding box */
	float     f;
	float     p_range;
	float     p_rang2;

	p_min.x = r->slider_min.x   +   r->slider_depth;
	p_min.y = r->slider_min.y   +   r->slider_depth/r->frustum_height;
	p_min.z = r->slider_min.z;

	p_max.x = 1.0 - p_min.x;
	p_max.y = r->slider_max.y   -   r->slider_depth/r->frustum_height;
	p_max.z = r->slider_max.z;

	/* What is the parametric range of motion allowed slider? */
	p_range = (p_max.x - p_min.x) - 2.0*r->slider_depth;

	/* Subtract %age of range which slider is supposed to occupy: */
	p_rang2 = p_range * (1.0 - r->slider_length);

	/* Where do we want to be positioned within that range? */
	f  = r->max_x - r->min_x;
        if (f != 0.0)   f = (r->x - r->min_x) / f;

	/* Position slider: */
	p_min.x += f * p_rang2;
	p_max.x  = (
	    p_min.x 			 +
	    p_range * r->slider_length   +
	    2.0 * r->slider_depth
	);

	/* Convert parametric to object-space coords: */
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	/* Actually insert our slider: */
	{   float x0     = (r_max.x + r_min.x) * 0.5;
	    float y0     = (r_max.y + r_min.y) * 0.5;
	    float z0     = (r_max.z + r_min.z) * 0.5;

	    float scalex = (r_max.x - r_min.x)      ;
	    float scaley = (r_max.y - r_min.y)      ;
	    float scalez = (r_max.z - r_min.z)      ;

	    /* Insert our body frustum: */
	    {   struct xshp06_Args_Rec a;
		xshp07_Init_Shape_Args( &a );
		a.x = x0;
		a.y = y0;
		a.z = z0;
		a.scalex = scalex;
		a.scaley = scaley;
		a.scalez = scalez*10.0;
		/* 10.0 above cancels xshp22's internal 0.1 */
		a.lv_thing = lv_slider;
		xshp22_Insert_Box_Or_Frustum( &a, 0 /* doBox */ );
	    }
	}
    }

    if (!r->omit_limits) {
	geo_point p_min;	/* Parametric min of label bounding box */
	geo_point p_max;	/* Parametric max of label bounding box */
	geo_point r_min;	/* Real       min of label bounding box */
	geo_point r_max;	/* Real       max of label bounding box */
	float     scale;
	p_min	 = r->limits_min;
	p_max	 = r->limits_max;
	p_min.x += r->limits_depth;
	p_max.x -= r->limits_depth;
	
	/* Convert parametric to object-space coords: */
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	scale    = r_max.y - r_min.y;

	/* Insert hershey text for lower limit: */
	sprintf(buf,"%g",r->min_x);
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= buf;
	    a.font_num  = r->limit_font;
	    a.x	    = (r_min.x          )      ; /* x location */
	    a.y	    = (r_min.y + r_max.y) * 0.5; /* y location */
	    a.z	    = (r_min.z		)      ; /* z location */
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_left;
	    xshpE0_Insert_Hershey_String( &a );
	}

	/* Insert hershey text for upper limit: */
	sprintf(buf,"%g",r->max_x);
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= buf;
	    a.font_num  = r->limit_font;
	    a.x	    = (r_max.x          )      ; /* x location */
	    a.y	    = (r_min.y + r_max.y) * 0.5; /* y location */
	    a.z	    = (r_min.z		)      ; /* z location */
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_right;
	    xshpE0_Insert_Hershey_String( &a );
	}
    }
    if (!r->omit_label) {
	geo_point p_min;	/* Parametric min of label bounding box */
	geo_point p_max;	/* Parametric max of label bounding box */
	geo_point r_min;	/* Real       min of label bounding box */
	geo_point r_max;	/* Real       max of label bounding box */
	float     scale;
	p_min	 = r->label_min;
	p_max	 = r->label_max;
	p_min.x += r->label_depth;
	p_max.x -= r->label_depth;
	
	/* Convert parametric to object-space coords: */
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	scale    = r_max.y - r_min.y;

	/* Insert hershey text for label: */
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= r->label;
	    a.font_num  = r->label_font;
	    a.x	    = (r_min.x          )      ; /* x location */
	    a.y	    = (r_min.y + r_max.y) * 0.5; /* y location */
	    a.z	    = (r_min.z		)      ; /* z location */
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_left;
	    xshpE0_Insert_Hershey_String( &a );
	}

	/* Insert hershey text for value: */
	sprintf(buf,"%g",r->x);
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= buf;
	    a.font_num  = r->limit_font;
	    a.x	    = (r_max.x          )      ; /* x location */
	    a.y	    = (r_min.y + r_max.y) * 0.5; /* y location */
	    a.z	    = (r_min.z		)      ; /* z location */
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_right;
	    xshpE0_Insert_Hershey_String( &a );
	}
    }
}

#define LVALS_TO_PROTECT (6)
LVAL xs1d78_Insert(
    lv_xs1d,
    x0, y0, z0,
    scalex, scaley, scalez
)
LVAL  lv_xs1d;
float x0, y0, z0;
float scalex, scaley, scalez;
{
    extern LVAL k_pickas;
    extern LVAL k_invisible;
    extern LVAL k_downclickhook;
    extern LVAL k_draghook;
    extern LVAL k_upclickhook;

    extern LVAL s_bodything;
    extern LVAL s_sliderthing;
    extern LVAL s_fieldthing;
    extern LVAL s_textthing;

    extern LVAL s_xg3dguixs1ddownclickfn;
    extern LVAL s_xg3dguixs1ddragfn;
    extern LVAL s_xg3dguixs1dupclickfn;

    LVAL  lv_body, lv_field, lv_text, lv_slider;

    LVAL lv_thingList;

    cs1d_rec* r = xs1d9c_Find_Immediate_Base( lv_xs1d );

    geo_point bbmin;
    geo_point bbmax;

    xlstkcheck(LVALS_TO_PROTECT);
    xlprotect( lv_xs1d		);
    xlsave(    lv_body		);
    xlsave(    lv_field		);
    xlsave(    lv_text		);
    xlsave(    lv_slider	);

    xlsave(    lv_thingList	);

    /* Fetch our four things from internal variables: */
    lv_body  = xthl90_GetObjectVariable( lv_xs1d, s_bodything   );
    lv_slider= xthl90_GetObjectVariable( lv_xs1d, s_sliderthing );
    lv_field = xthl90_GetObjectVariable( lv_xs1d, s_fieldthing  );
    lv_text  = xthl90_GetObjectVariable( lv_xs1d, s_textthing   );

    /* If any of the above are null, assume someone is sending us */
    /* reshape messages before inserting us, and just return:     */
    if (null( lv_body   ) ||
	null( lv_field  ) ||
	null( lv_text   ) ||
	null( lv_slider )
    ) {
	return;
    }

    /* Clear them out to make room for new shape: */
    xthlJ1_EmptyThing( lv_body   );
    xthlJ1_EmptyThing( lv_field  );

    xs1d76_RecomputeLayout( lv_xs1d );


    /* Insert our body frustum: */
    {   struct xshp06_Args_Rec a;
	xshp07_Init_Shape_Args( &a );
	a.x = x0;
	a.y = y0;
	a.z = z0;
	a.scalex = 1.0;
	a.scaley = r->frustum_height;
	a.scalez = 10.0*r->frustum_depth;
	a.lv_thing = lv_body;
	xshp22_Insert_Box_Or_Frustum( &a, 0 /* doBox */ );
    }

    /* Figure bounding box of body, so our parametric coords apply: */
    xthlL2_ObjectspaceBoundingBoxOfThing( &bbmin, &bbmax, lv_body );

    /* Insert a hole in body for slider: */
    if (!r->omit_slider) {
	geo_point slot_min;
	geo_point slot_max;
	float     d;
	libP2_InterpolatePointInBox( &slot_min, &r->slider_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &slot_max, &r->slider_max, &bbmin, &bbmax );

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (slot_max.x + slot_min.x) * 0.5;
	    a.y = (slot_max.y + slot_min.y) * 0.5;
	    a.z = (slot_max.z + slot_min.z) * 0.5;
	    a.scalex = (slot_max.x - slot_min.x)      ;
	    a.scaley = (slot_max.y - slot_min.y)      ;
	    a.scalez = (slot_max.z - slot_min.z) *10.0;
	    a.omit_bottom = TRUE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}

	/* Insert our field rectangle: */
	d   = slot_max.z - slot_min.z;			/* Depth	*/
	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x0 = slot_min.x+d; a.y0 = slot_min.y+d; a.z0 = slot_max.z;
	    a.x1 = slot_max.x-d; a.y1 = slot_min.y+d; a.z1 = slot_max.z;
	    a.x2 = slot_max.x-d; a.y2 = slot_max.y-d; a.z2 = slot_max.z;
	    a.x3 = slot_min.x+d; a.y3 = slot_max.y-d; a.z3 = slot_max.z;
	    a.n  = 4;
	    a.lv_thing = lv_field;
	    xshp12_Insert_Facet( &a );
	}
    }

    /* Insert a hole in body for limits: */
    if (!r->omit_limits) {
	geo_point slot_min;
	geo_point slot_max;
	libP2_InterpolatePointInBox( &slot_min, &r->limits_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &slot_max, &r->limits_max, &bbmin, &bbmax );

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (slot_max.x + slot_min.x) * 0.5;
	    a.y = (slot_max.y + slot_min.y) * 0.5;
	    a.z = (slot_max.z + slot_min.z) * 0.5;
	    a.scalex = (slot_max.x - slot_min.x)      ;
	    a.scaley = (slot_max.y - slot_min.y)      ;
	    a.scalez = (slot_max.z - slot_min.z) *10.0;
	    a.omit_bottom = FALSE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}
    }

    /* Insert a hole in body for label: */
    if (!r->omit_label) {
	geo_point slot_min;
	geo_point slot_max;
	libP2_InterpolatePointInBox( &slot_min, &r-> label_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &slot_max, &r-> label_max, &bbmin, &bbmax );

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (slot_max.x + slot_min.x) * 0.5;
	    a.y = (slot_max.y + slot_min.y) * 0.5;
	    a.z = (slot_max.z + slot_min.z) * 0.5;
	    a.scalex = (slot_max.x - slot_min.x)      ;
	    a.scaley = (slot_max.y - slot_min.y)      ;
	    a.scalez = (slot_max.z - slot_min.z) *10.0;
	    a.omit_bottom = FALSE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}
    }

    /* Insert slider and hershey text: */
    xs1d77_ReinsertVaryingPartOfSlider( lv_xs1d );

    /* Do rescaling if user-requested: */
    if (scalex != 1.0  ||
        scaley != 1.0  ||
        scalez != 1.0
    ) {
	geo_matrix m;
	geo_point  origin;
	geo_point  scale;
	origin.x = x0;
	origin.y = y0;
	origin.z = z0;
	scale.x  = scalex;
	scale.y  = scaley;
	scale.z  = scalez;
        ctfm16_Scale( &m, &origin, &scale );

	xthlK1_TransformThing( lv_body,   &m, /*skip-points:*/0, /*skip-facets:*/0 );
	xthlK1_TransformThing( lv_field,  &m, /*skip-points:*/0, /*skip-facets:*/0 );
	xthlK1_TransformThing( lv_slider, &m, /*skip-points:*/0, /*skip-facets:*/0 );
	xthlK1_TransformThing( lv_text,   &m, /*skip-points:*/0, /*skip-facets:*/0 );
    }

    /* Thread our things together to make a thinglist: */
    lv_thingList = cons( lv_body,   lv_thingList );
    lv_thingList = cons( lv_slider, lv_thingList );
    lv_thingList = cons( lv_field,  lv_thingList );
    lv_thingList = cons( lv_text,   lv_thingList );

    xlpopn(LVALS_TO_PROTECT);
    return lv_thingList;
}
#undef LVALS_TO_PROTECT

LVAL xs1d79_Insert_Msg()
{
    LVAL lv_xs1d	= xs1d01_Get_A_XS1D();

    LVAL lv_body	= NIL;
    LVAL lv_field	= NIL;
    LVAL lv_text	= NIL;
    LVAL lv_slider	= NIL;

    float x0		= 0.0;
    float y0		= 0.0;
    float z0		= 0.0;

    float scalex	= 1.0;	int got_scalex	= FALSE;
    float scaley	= 1.0;	int got_scaley	= FALSE;
    float scalez	= 1.0;	int got_scalez	= FALSE;

    cs1d_rec* r = xs1d9c_Find_Immediate_Base( lv_xs1d );

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_bodything) {

	    lv_body	= xlgacons();

	} else if (key == k_fieldthing) {

	    lv_field	= xlgacons();

	} else if (key == k_textthing) {

	    lv_text	= xlgacons();

	} else if (key == k_sliderthing) {

	    lv_slider	= xlgacons();

        } else if (key == k_x) {
	    x0		= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
        } else if (key == k_y) {
	    y0		= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
        } else if (key == k_z) {
	    z0		= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

        } else if (key == k_scale) {
	    float scale	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    if (!got_scalex) scalex = scale;
	    if (!got_scaley) scaley = scale;
	    if (!got_scalez) scalez = scale;

        } else if (key == k_scalex) {
	    scalex	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    got_scalex	= TRUE;
        } else if (key == k_scaley) {
	    scaley	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    got_scaley	= TRUE;
        } else if (key == k_scalez) {
	    scalez	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    got_scalez	= TRUE;

	} else {

	    xlerror("Bad :INSERT keyword",key);
        }
    }

    /* Probably should default these to something someday: */
    if (null(lv_body  )) xlfail(":INSERT: no :BODY-THING"  );
    if (null(lv_field )) xlfail(":INSERT: no :FIELD-THING" );
    if (null(lv_text  )) xlfail(":INSERT: no :TEXT-THING"  );
    if (null(lv_slider)) xlfail(":INSERT: no :SLIDER-THING");

    /* Save our four things in internal variables: */
    xthl91_SetObjectVariable( lv_xs1d, s_bodything  , lv_body   );
    xthl91_SetObjectVariable( lv_xs1d, s_sliderthing, lv_slider );
    xthl91_SetObjectVariable( lv_xs1d, s_fieldthing , lv_field  );
    xthl91_SetObjectVariable( lv_xs1d, s_textthing  , lv_text   );

    /* Set slider to be pick-invisible: */
    xthl82_SetProp( &lv_slider,/*key*/k_pickas,/*val*/k_invisible );

    /* Set field hook functions: */
    xthl82_SetProp(&lv_field,k_widget       ,lv_xs1d				);
    xthl82_SetProp(&lv_field,k_downclickhook,getfunction(s_xg3dguixs1ddownclickfn) );
    xthl82_SetProp(&lv_field,k_draghook     ,getfunction(s_xg3dguixs1ddragfn     ) );
    xthl82_SetProp(&lv_field,k_upclickhook  ,getfunction(s_xg3dguixs1dupclickfn  ) );

    return xs1d78_Insert(
	lv_xs1d,
	x0, y0, z0,
	scalex, scaley, scalez
    );
}

/* }}} */
/* {{{ xs1d91_ProplistLength_Msg -- Return length of propertylist.          */

LVAL xs1d90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XS1D_PROPS + x03d89_PropListLength( *pPropList ) );
}
LVAL xs1d91_ProplistLength_Msg()
{
    return xs1d90_ProplistLength( xs1d01_Get_A_XS1D() );
}

/* }}} */
/* {{{ xs1d95_ProplistNth_Msg -- Return Nth prop from propertylist.         */

LVAL xs1d94_ProplistNth( lv_g )
LVAL                     lv_g;
{
    LVAL*pPropList  = x03d73_pPropList( lv_g );
    LVAL lv_n       = xlgafixnum();
    int  n          = getfixnum(lv_n);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case  0:    return k_minx;
    case  1:    return k_maxx;
    case  2:    return k_x;
    case  3:    return k_neutralx;
    case  4:    return k_enforceminx;
    case  5:    return k_enforcemaxx;
    case  6:    return k_label;
    case  7:    return k_verticalmargin;
    case  8:    return k_horizontalmargin;
    case  9:    return k_sliderheight;
    case 10:    return k_limitsheight;
    case 11:    return k_labelheight;
    case 12:    return k_frustumdepth;
    case 13:    return k_sliderdepth;
    case 14:    return k_limitsdepth;
    case 15:    return k_labeldepth;
    case 16:    return k_sliderlength;
    case 17:    return k_labelfont;
    case 18:    return k_limitfont;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XS1D_PROPS,
	    lv_n,
	    default_val,
	    got_default
	);
    }
}
LVAL xs1d95_ProplistNth_Msg()
{
    return xs1d94_ProplistNth( xs1d01_Get_A_XS1D() );
}

/* }}} */
/* {{{ xs1d9c_Find_Immediate_Base                                           */

cs1d_rec* xs1d9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    cs1d_rec*s1d = (cs1d_rec*) gobjimmbase( lv );
    return s1d;
}

/* }}} */
/* {{{ xs1dz7_Read_Xs1d_From_File                                           */

xs1dz7_Read_Xs1d_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   cs1d_rec* h;
    char*     p;
    if (version != CS1D_REC_VERSION) {
	xlerror("xs1dz7: unsupported version",cvfixnum(version));
    }
    h = (cs1d_rec*) gobjimmbase( lv );

    p = (char*) &h->CS1D_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CS1D_INT32_COUNT,  magic, fp );

    p = (char*) &h->CS1D_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CS1D_FLOAT_COUNT,  magic, fp );

    p = (char*) &h->CS1D_FIRST_BYTE;
    p = cfil52_Read_Bytes_From_File(   p, CS1D_BYTE_COUNT ,  magic, fp );
}

/* }}} */
/* {{{ xs1dwo_Write_Xs1d_To_Graphics_File                                   */

xs1dwo_Write_Xs1d_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   cs1d_rec* h = (cs1d_rec*) gobjimmbase( lv );
	char*     p;

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CS1D_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CS1D_FIRST_INT32, CS1D_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CS1D_FIRST_FLOAT, CS1D_FLOAT_COUNT, fdob);
	cfil45_Write_Bytes_To_File( &h->CS1D_FIRST_BYTE , CS1D_BYTE_COUNT , fdob);
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

