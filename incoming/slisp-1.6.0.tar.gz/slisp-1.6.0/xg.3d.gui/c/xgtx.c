/* {{{ xgtx.c -- text-input (GeT teXt) objects.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jul27
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Jul27 jsp: Created.  Operational.					*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/cshp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xgtx;
extern LVAL k_frustumdepth;
extern LVAL k_horizontalmargin;
extern LVAL k_initializefromfile;
extern LVAL k_label;
extern LVAL k_labeldepth;
extern LVAL k_labelfont;
extern LVAL k_labelheight;
extern LVAL k_string;
extern LVAL k_stringasfloat;
extern LVAL k_stringdepth;
extern LVAL k_stringfont;
extern LVAL k_stringheight;
extern LVAL k_verticalmargin;
extern LVAL k_bodything;
extern LVAL k_changehook;
extern LVAL k_downclickhook;
extern LVAL k_draghook;
extern LVAL k_fieldthing;
extern LVAL k_scale;
extern LVAL k_scalex;
extern LVAL k_scaley;
extern LVAL k_scalez;
extern LVAL k_textthing;
extern LVAL k_upclickhook;
extern LVAL k_widget;
extern LVAL k_x;
extern LVAL k_y;
extern LVAL k_z;
extern LVAL s_bodything;
extern LVAL s_fieldthing;
extern LVAL s_textthing;
extern LVAL s_xg3dguicurrentwidget;
extern LVAL s_xg3dguixgtxdownclickfn;
extern LVAL s_xg3dguixgtxdragfn;
extern LVAL s_xg3dguixgtxupclickfn;

extern LVAL s_stdout;
extern LVAL xsendmsg0();
extern LVAL xsendmsg0();
LVAL  xgtx41_Put();
LVAL  xgtx71_Do_Hook_Fn();
LVAL  xgtx78_Insert();

#include <math.h>
#include <string.h>
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/cthl.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/clgt.h"
#include "../../xg.3d/c/ccmr.h"
#include "../../xg.3d.fileio/c/cfil.h"
#include "cgtx.h"

cgtx_rec* xgtx9c_Find_Immediate_Base();


/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xgtx00_Is_New -- Initialize a new xgtx instance.			*/

/* Following are in fractions of the total width of widget: */
#define VERTICAL_MARGIN     0.01
#define HORIZONTAL_MARGIN   0.01

#define STRING_HEIGHT       0.04
#define LABEL_HEIGHT        0.04

#define FRUSTUM_DEPTH       0.02
#define STRING_DEPTH        0.01
#define LABEL_DEPTH         0.01

cgtx_rec xgtx_defaults = {
    C03D_xGTX,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */
    CGTX_STYLE_1,		/* menu_style.			*/

    1,				/* string_font			*/
    1,				/* label_font			*/
    0,				/* omit_old_str			*/
    0,				/* omit_label			*/
    0,				/* omit_body			*/
    0,				/* in_changehook		*/
    ~13,			/* spare_1			*/
    ~13,			/* spare_2			*/

    VERTICAL_MARGIN,		/* vertical_margin		*/
    HORIZONTAL_MARGIN,		/* horizontal_margin		*/

    STRING_HEIGHT,		/* string_height		*/
    LABEL_HEIGHT,		/* label_height			*/

    STRING_DEPTH,		/* string_depth			*/
    LABEL_DEPTH,		/* label_depth			*/

    FRUSTUM_DEPTH,		/* frustum_depth		*/

    0.0,			/* frustum_height		*/

    0.0,			/* text_spot_x			*/
    0.0,			/* text_spot_y			*/
    1.0,			/* text_scale_x			*/
    1.0,			/* text_scale_y			*/

    {0.1, 0.1, 0.0},		/* oldstr_min			*/
    {0.2, 0.2, 0.2},		/* oldstr_max			*/
    {0.3, 0.3, 0.0},		/* newstr_min			*/
    {0.4, 0.4, 0.2},		/* newstr_max			*/
    {0.7, 0.7, 0.0},		/* label_min			*/
    {0.8, 0.8, 0.2},		/* label_max			*/

   -314155.0,			/* fspare_1			*/
    "(nameless)\0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "(something)\0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "(something)\0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
};


LVAL xgtx00_Is_New()
/*-
    Initialize a new xgtx instance.
-*/
{
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    cgtx_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xgtxp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( cgtx_rec ) );

    /* Initialize menu record to reasonable default values: */
    r	= (cgtx_rec*) gobjimmbase( lv );
   *r   = xgtx_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    xgtx41_Put( lv );

    return lv;
}


/* }}} */
/* {{{ xgtx01_Get_A_XGTX -- Get arg, must be of class xgtx.			*/

LOCAL LVAL xgtx01_Get_A_XGTX()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XGTX has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xgtx.  Similarly,          */
    /* nobody but nobody has any business resizing a xgtx,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xgtxp(m_as_lval) ||
        getgobjimmbytes(m_as_lval) != sizeof(cgtx_rec)
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}


/* }}} */
/* {{{ xgtx03_Show_Msg -- Show the contents of a cgtx.			*/

LVAL xgtx03_Show_Msg()
{
    LVAL lv,fptr;

    /* get self and the file pointer */
    lv   = xgtx01_Get_A_XGTX();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(lv,fptr);
    xgbj52_Show_Lval_Vector(lv,fptr);

    /* Print the gtx record: */
    {   cgtx_rec * r = xgtx9c_Find_Immediate_Base( lv );
	/* Suppose I should write this someday... (buggo) */
    }

    /* return the gobject */
    return lv;
}

/* }}} */
/* {{{ xgtx08_Copy_Msg -- Build copy of given CGTX.				*/

LVAL xgtx09_Copy( m_as_lval )
LVAL		  m_as_lval;
{
    /* Create a new gobject to hold result: */
    cgtx_rec*mh = xgtx9c_Find_Immediate_Base( m_as_lval );
    cgtx_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xgtx,k_new);
    xlpop();
    nh = (cgtx_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}
LVAL xgtx08_Copy_Msg()
{
    LVAL m_as_lval;
    LVAL x_as_lval = xgtx01_Get_A_XGTX();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xgtx09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xgtx28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xgtx28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {   char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xgtx29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xgtx01_Get_A_XGTX();
    LVAL n_as_lval = xgtx01_Get_A_XGTX();
    xllastarg();
    return xgtx28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xgtx40_Get_Msg -- Get keyword properties.                            */

LVAL xgtx39_Get( lv_xgtx )
LVAL             lv_xgtx;
{
    extern LVAL true;/*xlglob.c*/
    cgtx_rec* r = xgtx9c_Find_Immediate_Base( lv_xgtx );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if        (key == k_string) {

	result = cvstring( r->new_string );

    } else if (key == k_stringasfloat) {

	float f;
        sscanf(r->new_string,"%g",&f);
	result = cvflonum( f );

    } else if (key == k_label) {

        result = cvstring( r->label );

    } else if (key == k_labelfont) {

        result = cvfixnum( r->label_font );

    } else if (key == k_stringfont) {

        result = cvfixnum( r->string_font );

    } else if (key == k_verticalmargin) {
	result = cvflonum( r->vertical_margin );
    } else if (key == k_horizontalmargin) {
	result = cvflonum( r->horizontal_margin );

    } else if (key == k_stringheight) {
	result = cvflonum( r->string_height );
    } else if (key == k_labelheight) {
	result = cvflonum( r->label_height );

    } else if (key == k_frustumdepth) {
	result = cvflonum( r->frustum_depth );
    } else if (key == k_stringdepth) {
	result = cvflonum( r->string_depth );
    } else if (key == k_labeldepth) {
	result = cvflonum( r->label_depth );

    } else {

	/* If this isn't a property we know, do a generic get property: */
        result = xthl8a_GetObjectProp( lv_xgtx, key, default_val, got_default );
    }
    return result;
}
LVAL xgtx40_Get_Msg()
{
    return xgtx39_Get( xgtx01_Get_A_XGTX() );
}

/* }}} */
/* {{{ xgtx42_Put_Msg -- Write keyword properties.                          */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Put, update XGTX_PROPS and xgtx94_ProplistNth. */
#define XGTX_PROPS (11)

/* A little macro to make this fn a little neater: */
#define XGTX_REDO(x) {		\
    x;				\
    rebuild = TRUE;		\
}

LVAL xgtx41_Put( lv_xgtx )
LVAL             lv_xgtx;
{
    cgtx_rec* r = xgtx9c_Find_Immediate_Base( lv_xgtx );
    extern LVAL true;/*xlglob.c*/
    int  rebuild    = FALSE;

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xgtxz7_Read_Xgtx_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_xgtx,
		getfile(xlgetfile()),
		xgtxz7_Read_Xgtx_From_File,NULL
	    );

        } else if (key == k_label) {

	    LVAL lv_string = xlgastring();
	    strncpy(r->label,(char*)getstring(lv_string),CGTX_MAX_LABEL);
	    r->label[ CGTX_MAX_LABEL -1 ] = '\0';
	    rebuild	   = TRUE;

        } else if (key == k_string) {

	    LVAL lv_string = xlgastring();
	    char*   string = (char*)getstring(lv_string);
	    strncpy( r->old_string, string, CGTX_MAX_LABEL );
	    r->old_string[ CGTX_MAX_LABEL -1 ] = '\0';
	    strncpy( r->new_string, string, CGTX_MAX_LABEL );
	    r->new_string[ CGTX_MAX_LABEL -1 ] = '\0';
	    rebuild	   = TRUE;

        } else if (key == k_stringasfloat) {

	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())) {
		sprintf(r->old_string,"%g",f);
		sprintf(r->new_string,"%g",f);
	    }

        } else if (key == k_labelfont) {

	    float ffont;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&ffont,xlgetarg())) {
		int font = (int) ffont;
		if (font <  0)   font =  0;
		if (font > 11)   font = 11;
		r->label_font = font;
		rebuild	  = TRUE;
	    }
        } else if (key == k_stringfont) {

	    float ffont;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&ffont,xlgetarg())) {
		int font = (int) ffont;
		if (font <  0)   font =  0;
		if (font > 11)   font = 11;
		r->string_font = font;
		rebuild	   = TRUE;
	    }
        } else if (key == k_verticalmargin) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
		f>0.0                                          &&
                f!=r->vertical_margin
	    ) {
		XGTX_REDO( r->vertical_margin   = f );
	    }
        } else if (key == k_horizontalmargin) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
		f>0.0                                          &&
                f<0.45                                         &&
                f!=r->horizontal_margin
            ) {
	        XGTX_REDO( r->horizontal_margin = f );
	    }
        } else if (key == k_stringheight) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
		f>=0.0                                         &&
                f!=r->string_height
            ) {
                XGTX_REDO( r->string_height     = f );
	    }
        } else if (key == k_labelheight) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
		f>=0.0                                         &&
                f!=r-> label_height
	    ) {
		XGTX_REDO( r->label_height      = f );
	    }
        } else if (key == k_frustumdepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
		f>0.0                                          &&
	        f<0.3                                          &&
		f!=r->frustum_depth
	    ) {
		XGTX_REDO( r->frustum_depth     = f );
	    }
        } else if (key == k_stringdepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
		f>0.0                                          &&
		f<0.3                                          &&
	        f!=r->string_depth
	    ) {
		XGTX_REDO( r->string_depth      = f );
	    }
        } else if (key == k_labeldepth) {
	    float f;
	    if (lib30_Maybe_Get_Fix_Or_Flo_Num(&f,xlgetarg())  &&
		f>0.0                                          &&
                f<0.3                                          &&
                f!=r->label_depth
	    ) {
                XGTX_REDO( r->label_depth       = f );
            }
	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_xgtx, key, xlgetarg() );
        }
    }

    /* We delay this stuff to end to make result order-invariant: */
    if (rebuild)    xgtx75_RebuildGeometry( lv_xgtx );

    return lv_xgtx;
}
#undef XGTX_REDO
LVAL xgtx42_Put_Msg()
{   /* Read keyword properties for a menu object. */
    LVAL   lv_xgtx = xgtx01_Get_A_XGTX();
    LVAL   result  = xgtx41_Put( lv_xgtx );
    return result;
}

/* }}} */
/* {{{ xgtx52_AppendChar_Msg -- Append a char to edited string.		*/

LVAL xgtx51_AppendChar( lv_xgtx, c )
LVAL			lv_xgtx;
int				 c;
{   cgtx_rec*   r       = xgtx9c_Find_Immediate_Base(  lv_xgtx );
    int         len     = strlen( r->new_string );
    if (len < CGTX_MAX_LABEL-1) {
	r->new_string[len  ] = c   ;
	r->new_string[len+1] = '\0';
	xgtx77_ReinsertVaryingPartOfStringReader( lv_xgtx );
    }
    return NIL;
}
LVAL xgtx52_AppendChar_Msg()
{   LVAL   lv_xgtx = xgtx01_Get_A_XGTX();
    LVAL   lv_char = xlgachar();
    xllastarg();
    return xgtx51_AppendChar( lv_xgtx, getchcode(lv_char) );
}

/* }}} */
/* {{{ xgtx55_DeleteChar_Msg -- Strip trailing char from edited string.	*/

LVAL xgtx54_DeleteChar( lv_xgtx )
LVAL			lv_xgtx;
{   cgtx_rec*   r       = xgtx9c_Find_Immediate_Base(  lv_xgtx );
    int         len     = strlen( r->new_string );
    if (len) {
	r->new_string[len-1] = '\0';
	xgtx77_ReinsertVaryingPartOfStringReader( lv_xgtx );
    }
    return NIL;
}
LVAL xgtx55_DeleteChar_Msg()
{   LVAL        lv_xgtx = xgtx01_Get_A_XGTX();
    xllastarg();
    return xgtx54_DeleteChar( lv_xgtx );
}

/* }}} */
/* {{{ xgtx58_ClearString_Msg -- Erase edited string.			*/

LVAL xgtx57_ClearString( lv_xgtx )
LVAL			 lv_xgtx;
{   cgtx_rec*   r       = xgtx9c_Find_Immediate_Base(  lv_xgtx );
    int         len     = strlen( r->new_string );
    if (len) {
	r->new_string[0] = '\0';
	xgtx77_ReinsertVaryingPartOfStringReader( lv_xgtx );
    }
    return NIL;
}
LVAL xgtx58_ClearString_Msg()
{   LVAL        lv_xgtx = xgtx01_Get_A_XGTX();
    xllastarg();
    return xgtx57_ClearString( lv_xgtx );
}

/* }}} */
/* {{{ xgtx63_Click --	Main fn to handle upclick/downclick/drag	*/

LVAL xgtx63_Click( lv_hook )
LVAL		   lv_hook; /* k_upclickhook/k_draghook/k_downclickhook */
{   /*********************************************/
    /* We've been called as a hook fn, need to   */
    /* update our appearance etc to track mouse. */
    /*********************************************/
    extern LVAL k_selectedthing;
    extern LVAL k_get;

    /* We've been called with no arguments: */
    int  csux0	  = (
	xcmrC3_RunningWidgets ||
	xlfail("CLASS-STRING-READER Hookfn not called via :RUN-WIDGETS")
    );

    /* But we need some arguments! */
    LVAL lv_thing = xcmrC2_RunWidgets_Rec.lv_selected_thing;
    LVAL lv_xgtx  = xthl74_GetProp( &lv_thing, k_widget, NIL,/*got_default:*/FALSE);
    int  csux1 	  = (
	xgtxp(lv_xgtx) ||
	xlerror("Not CLASS-STRING-READER instance:",lv_xgtx)
    );
    cgtx_rec*   r = xgtx9c_Find_Immediate_Base(  lv_xgtx );
    int         f = xcmrC2_RunWidgets_Rec.selected_facet;
    xllastarg();
    r->in_changehook	= FALSE;/* Guard against it getting stuck ON */

    /* This is where you'd think we'd do something :) */

    return xgtx71_Do_Hook_Fn( lv_xgtx, lv_hook );
}

/* }}} */
/* {{{ xgtx65_Downclick_Fn -- Function to implement menu downclick.	*/

LVAL xgtx69_Drag_Fn();
LVAL xgtx65_Downclick_Fn()
{   return xgtx63_Click( k_downclickhook );
}

/* }}} */
/* {{{ xgtx67_Upclick_Fn -- Function to implement menu upclick.		*/

LVAL xgtx67_Upclick_Fn()
{   return xgtx63_Click( k_upclickhook );
}

/* }}} */
/* {{{ xgtx69_Drag_Fn -- Function to implement menu drag.		*/

LVAL xgtx69_Drag_Fn()
{   return xgtx63_Click( k_draghook );
}

/* }}} */
/* {{{ xgtx71_Do_Hook_Fn -- Call user-supplied hook fns.		*/

LVAL xgtx70_Do_Hook_Fn( lv_xgtx, lv_hookfns )
LVAL			lv_xgtx;
LVAL				 lv_hookfns;
{
    LVAL     lv_old_current_widget = getvalue( s_xg3dguicurrentwidget );
    xlprot1( lv_old_current_widget );
    setvalue( s_xg3dguicurrentwidget, lv_xgtx );

    xthlF5_Call_HookFns( lv_hookfns );

    setvalue( s_xg3dguicurrentwidget, lv_old_current_widget );
    xlpop();
    return NIL;
}
LVAL xgtx71_Do_Hook_Fn( lv_xgtx, lv_hook )
LVAL			lv_xgtx;
LVAL				 lv_hook; /* k_changehook/k_downclickhook/...*/
{   cgtx_rec* r	    = xgtx9c_Find_Immediate_Base( lv_xgtx );
    LVAL lv_hookfns = xthl8a_GetObjectProp( lv_xgtx, lv_hook, NIL,TRUE );
    if (null(lv_hookfns))   return NIL;
    if (lv_hook != k_changehook)   return xgtx70_Do_Hook_Fn( lv_xgtx, lv_hookfns );

    /* A little dodge so changehooks can modify our	*/
    /* value without slipping into infinite recursion:	*/
    if (r->in_changehook)   return NIL;
    r    ->in_changehook	= TRUE;
    /* Bad news if we get an error and leave this flag	*/
    /* set... as a partial fix, we clear it various	*/
    /* places.						*/
    xgtx70_Do_Hook_Fn( lv_xgtx, lv_hookfns );
    r    ->in_changehook	= FALSE;
    return NIL;
}

/* }}} */
/* {{{ xgtx75_RebuildGeometry -- Rebuild our shape to new specs.	*/

xgtx75_RebuildGeometry( lv_xgtx )
LVAL			lv_xgtx;
{
    /********************************************************************/
    /* Compute our current origin and scale factors by looking at our	*/
    /* bounding box, after which xgtx78_Insert will do the rest of our	*/
    /* work.								*/
    /*									*/
    /* We use this somewhat roundabout technique (deduction from our	*/
    /* bounding box) so as to attempt to work correctly even if the	*/
    /* app hacker rescales or moves us without telling us.  Ideally,	*/
    /* we'd also work if s/he rotated us.  Someday :).			*/
    /********************************************************************/
    cgtx_rec* r			= xgtx9c_Find_Immediate_Base(  lv_xgtx );
    float     old_frustum_width = 1.0;	/* By definition -- width units.*/
    float     old_frustum_height= r->frustum_height;
    float     old_frustum_depth	= r->frustum_depth;
    LVAL      lv_body		= xthl90_GetObjectVariable( lv_xgtx, s_bodything );


    if (!null(lv_body)) {      /* May get called before we're inserted! */
	geo_point bbmin;
	geo_point bbmax;
        int       csux0	  = xgtx76_RecomputeLayout(   lv_xgtx );
	int       csux1   = xthlL2_ObjectspaceBoundingBoxOfThing( &bbmin, &bbmax, lv_body );

	float     x0      = (bbmax.x + bbmin.x) * 0.5;
	float     y0      = (bbmax.y + bbmin.y) * 0.5;
	float     z0      = (bbmax.z + bbmin.z) * 0.5;

	float     scalex  = (bbmax.x - bbmin.x)  / old_frustum_width ;
	float     scaley  = (bbmax.y - bbmin.y)  / old_frustum_height;
	float     scalez  = (bbmax.z - bbmin.z)  / old_frustum_depth ;

	xgtx78_Insert(
	    lv_xgtx,
	    x0, y0, z0,
	    scalex, scaley, scalez
	);
    }
}

/* }}} */
/* {{{ xgtx76_RecomputeLayout						*/

xgtx76_RecomputeLayout( lv_xgtx )
LVAL			lv_xgtx;
{
    float slot_depth;
    cgtx_rec* r        = xgtx9c_Find_Immediate_Base( lv_xgtx );
    LVAL      lv_body  = xthl90_GetObjectVariable(   lv_xgtx, s_bodything   );

    /* If body is null, assume someone is sending us */
    /* reshape messages before inserting us:         */
    if (null( lv_body   ))  return;

    /* Remember which parts we are missing: */
    r->omit_old_str	= !strlen( r->old_string );
    r->omit_label	= (r-> label_height == 0.0);

    /* Worry about nonsensical user layouts: */
    if (!r->omit_old_str && r->frustum_depth < r->string_depth) {
        r->frustum_depth  = r->string_depth;
    }
    if (!r->omit_label  && r->frustum_depth < r-> label_depth) {
	r->frustum_depth = r-> label_depth;
    }
    for (;;) {
	/* All user input is in fractions of total width, */
	/* so width better not sum to more than 1.0 here: */
	float width;
        slot_depth = 0.0;
	/* Yes, it's currently redundant: */
	if (!r->omit_old_str  &&   r->string_depth > slot_depth)  slot_depth = r->string_depth;
	if (                       r->string_depth > slot_depth)  slot_depth = r->string_depth;
	if (!r->omit_label    &&   r-> label_depth > slot_depth)  slot_depth = r-> label_depth;
	width = (
	    2.0 * r->horizontal_margin +
	    2.0 *    slot_depth        +
	    2.0 * r->frustum_depth
	);

	if (width <= 1.0)   break;

	/* Shrink-to-fit: */
	r->vertical_margin	*= 0.99;
	r->horizontal_margin	*= 0.99;
	r->frustum_depth	*= 0.99;
	r->string_depth		*= 0.99;
	r->label_depth		*= 0.99;
    }

    /* Figure total height of widget, relative to width: */
    r                          ->frustum_height  = (
	2.0 * r->frustum_depth + r->vertical_margin
    );
    if (!r->omit_old_str)      r->frustum_height += (
	2.0 * r->string_depth  + r->vertical_margin +  r->string_height
    );
    if (TRUE            )      r->frustum_height += (
	2.0 * r->string_depth  + r->vertical_margin +  r->string_height
    );
    if (!r->omit_label)	      r->frustum_height += (
	2.0 * r->label_depth   + r->vertical_margin +  r->label_height
    );

    /* Figure parametric coordinates of various parts of menu.   */
    /* p_* are parameterized in bounding_box==1.0 units, x,y &z.   */
    {   float h		      = r->frustum_height;

	/* "Parametric Vertical Margin": */
        float pvm  = r->  vertical_margin / h;

	/* "Parametric Horizontal Margin": */
        float phm  = r->horizontal_margin / 1.0;


        float pvfd = r->frustum_depth     / h;
        float phfd = r->frustum_depth     / 1.0;

	float p_string_depth  = r->string_depth / r->frustum_depth;
	float p__label_depth  = r-> label_depth / r->frustum_depth;

	float p_string_spot_x = 0.5;
	float p__label_spot_x = 0.5;

	float p_newstr_spot_y = 0.0;
	float p_oldstr_spot_y = 0.0;
	float p__label_spot_y = 0.0;

	float p_string_size_x = 1.0 - 2.0*(phfd+phm);
	float p__label_size_x = 1.0 - 2.0*(phfd+phm);

	float p_string_size_y = (r->string_height + 2.0*r->string_depth)/h;
	float p__label_size_y = (r-> label_height + 2.0*r-> label_depth)/h;

	float p_loc	      = pvfd + pvm;

	if (TRUE            ) {
	    p_newstr_spot_y   =p_loc+(0.5*r->string_height +    r->string_depth)/h;
	    p_loc	     +=  pvm+(    r->string_height +2.0*r->string_depth)/h;
	}

	if (!r->omit_old_str) {
	    p_oldstr_spot_y   =p_loc+(0.5*r->string_height +    r->string_depth)/h;
	    p_loc	     +=  pvm+(    r->string_height +2.0*r->string_depth)/h;
	}
	if (!r->omit_label) {
	    p__label_spot_y   =p_loc+(0.5*r-> label_height +    r-> label_depth)/h;
	}

	r->newstr_min.x = p_string_spot_x   -   0.5 * p_string_size_x;
	r->newstr_min.y = p_newstr_spot_y   -   0.5 * p_string_size_y;
	r->newstr_min.z = 0.0;

	r->newstr_max.x = p_string_spot_x   +   0.5 * p_string_size_x;
	r->newstr_max.y = p_newstr_spot_y   +   0.5 * p_string_size_y;
	r->newstr_max.z = r->string_depth / r->frustum_depth;



	r->oldstr_min.x = p_string_spot_x   -   0.5 * p_string_size_x;
	r->oldstr_min.y = p_oldstr_spot_y   -   0.5 * p_string_size_y;
	r->oldstr_min.z = 0.0;

	r->oldstr_max.x	= p_string_spot_x   +   0.5 * p_string_size_x;
	r->oldstr_max.y	= p_oldstr_spot_y   +   0.5 * p_string_size_y;
	r->oldstr_max.z	= r->string_depth / r->frustum_depth;



	r-> label_min.x = p__label_spot_x   -   0.5 * p__label_size_x;
	r-> label_min.y = p__label_spot_y   -   0.5 * p__label_size_y;
	r-> label_min.z = 0.0;

	r-> label_max.x = p__label_spot_x   +   0.5 * p__label_size_x;
	r-> label_max.y = p__label_spot_y   +   0.5 * p__label_size_y;
	r-> label_max.z =  r->label_depth / r->frustum_depth;
    }
}

/* }}} */
/* {{{ xgtx79_Insert_Msg -- ThingList to display us as lines & polys.	*/

xgtx77_ReinsertVaryingPartOfStringReader( lv_xgtx )
LVAL				          lv_xgtx;
{   /* Actually, we insert the varying part the first time around */
    /* too, as well as re-inserting it at need, of course ...     */

    extern LVAL s_bodything;
    extern LVAL s_fieldthing;
    extern LVAL s_textthing;
    extern LVAL k_left;

    LVAL        lv_body    = xthl90_GetObjectVariable( lv_xgtx, s_bodything   );
    LVAL        lv_text    = xthl90_GetObjectVariable( lv_xgtx, s_textthing   );

    cgtx_rec*   r     = xgtx9c_Find_Immediate_Base(  lv_xgtx );

    float       f;
    char        buf[ CGTX_MAX_LABEL * 2 ];

    geo_point bbmin;
    geo_point bbmax;

    float     old_frustum_width = 1.0;	/* By definition -- width units.*/
    float     old_frustum_height= r->frustum_height;

    float     scalex;
    float     scaley;

    /* Worry about being called before :INSERT is done: */
    if (null( lv_body   ) ||
	null( lv_text   )
    ) {
	return;
    }

    /* Clear out any old stuff in */
    /* our hershey text thing:    */
    xthlJ1_EmptyThing( lv_text   );

    xthlL2_ObjectspaceBoundingBoxOfThing( &bbmin, &bbmax, lv_body );

    scalex  = (bbmax.x - bbmin.x)  / old_frustum_width ;
    scaley  = (bbmax.y - bbmin.y)  / old_frustum_height;

    /* New string: */
    if (TRUE) {
	geo_point p_min;	/* Parametric min of label bounding box */
	geo_point p_max;	/* Parametric max of label bounding box */
	geo_point r_min;	/* Real       min of label bounding box */
	geo_point r_max;	/* Real       max of label bounding box */
	float     scale;
        char	  buf[ 2 * CGTX_MAX_LABEL ];
	p_min	 = r->newstr_min;
	p_max	 = r->newstr_max;
	p_min.x += r->string_depth;
	p_max.x -= r->string_depth;

	/* Convert parametric to object-space coords: */
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	scale    = r_max.y - r_min.y;

	/* Insert hershey text for string being entered: */
	sprintf(buf, "now: %s|", r->new_string);
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= buf;
	    a.font_num  = r->string_font;
	    a.x	    = (r_min.x          )      ; /* x location */
	    a.y	    = (r_min.y + r_max.y) * 0.5; /* y location */
	    a.z	    = (r_min.z		)      ; /* z location */
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_left;
	    xshpE0_Insert_Hershey_String( &a );
	}
    }

    /* Old string: */
    if (!r->omit_old_str) {
	geo_point p_min;	/* Parametric min of label bounding box */
	geo_point p_max;	/* Parametric max of label bounding box */
	geo_point r_min;	/* Real       min of label bounding box */
	geo_point r_max;	/* Real       max of label bounding box */
	float     scale;
        char	  buf[ 2 * CGTX_MAX_LABEL ];
	p_min	 = r->oldstr_min;
	p_max	 = r->oldstr_max;
	p_min.x += r->string_depth;
	p_max.x -= r->string_depth;

	/* Convert parametric to object-space coords: */
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	scale    = r_max.y - r_min.y;

	/* Insert hershey text for original value of string: */
	sprintf(buf, "was: %s", r->old_string);
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= buf;
	    a.font_num  = r->string_font;
	    a.x	    = (r_min.x          )      ; /* x location */
	    a.y	    = (r_min.y + r_max.y) * 0.5; /* y location */
	    a.z	    = (r_min.z		)      ; /* z location */
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_left;
	    xshpE0_Insert_Hershey_String( &a );
	}
    }

    /* Title: */
    if (!r->omit_label) {
	geo_point p_min;	/* Parametric min of label bounding box */
	geo_point p_max;	/* Parametric max of label bounding box */
	geo_point r_min;	/* Real       min of label bounding box */
	geo_point r_max;	/* Real       max of label bounding box */
	float     scale;
        char	  buf[ 2 * CGTX_MAX_LABEL ];
	p_min	 = r->label_min;
	p_max	 = r->label_max;
	p_min.x += r->label_depth;
	p_max.x -= r->label_depth;

	/* Convert parametric to object-space coords: */
	libP2_InterpolatePointInBox( &r_min, &p_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &r_max, &p_max, &bbmin, &bbmax );

	scale    = r_max.y - r_min.y;

	/* Insert hershey text for label: */
	sprintf(buf, "'%s'", r->label);
	{   struct xshp06_Args_Rec   a  ;
	    xshp07_Init_Shape_Args( &a );
	    a.lv_thing  = lv_text;
	    a.text	= buf;
	    a.font_num  = r->label_font;
	    a.x	    = (r_min.x          )      ; /* x location */
	    a.y	    = (r_min.y + r_max.y) * 0.5; /* y location */
	    a.z	    = (r_min.z		)      ; /* z location */
	    a.got_p	= TRUE;
	    a.update_cursor	= FALSE;
	    a.margin	= 0.0;
	    a.got_margin= FALSE;
	    a.vspacing  = 1.0;
	    a.got_vspacing  = FALSE;
	    a.scalex    = scale*scalex;
	    a.scaley    = scale*scaley;
	    a.scalez    = 1.0;
	    a.lv_justify= k_left;
	    xshpE0_Insert_Hershey_String( &a );
	}
    }
}

#define LVALS_TO_PROTECT (5)
LVAL xgtx78_Insert(
    lv_xgtx,
    x0, y0, z0,
    scalex, scaley, scalez
)
LVAL  lv_xgtx;
float x0, y0, z0;
float scalex, scaley, scalez;
{
    extern LVAL k_pickas;
    extern LVAL k_invisible;
    extern LVAL k_downclickhook;
    extern LVAL k_draghook;
    extern LVAL k_upclickhook;

    extern LVAL s_bodything;
    extern LVAL s_fieldthing;
    extern LVAL s_textthing;

    extern LVAL s_xg3dguixgtxdownclickfn;
    extern LVAL s_xg3dguixgtxdragfn;
    extern LVAL s_xg3dguixgtxupclickfn;

    LVAL  lv_body, lv_field, lv_text;

    LVAL lv_thingList;

    cgtx_rec* r = xgtx9c_Find_Immediate_Base( lv_xgtx );

    geo_point bbmin;
    geo_point bbmax;

    xlstkcheck(LVALS_TO_PROTECT);
    xlprotect( lv_xgtx		);
    xlsave(    lv_body		);
    xlsave(    lv_field		);
    xlsave(    lv_text		);

    xlsave(    lv_thingList	);

    /* Fetch our three things from internal variables: */
    lv_body  = xthl90_GetObjectVariable( lv_xgtx, s_bodything   );
    lv_field = xthl90_GetObjectVariable( lv_xgtx, s_fieldthing  );
    lv_text  = xthl90_GetObjectVariable( lv_xgtx, s_textthing   );

    /* If any of the above are null, assume someone is sending us */
    /* reshape messages before inserting us, and just return:     */
    if (null( lv_body   ) ||
	null( lv_field  ) ||
	null( lv_text   )
    ) {
	return;
    }

    /* Clear them out to make room for new shape: */
    xthlJ1_EmptyThing( lv_body   );
    xthlJ1_EmptyThing( lv_field  );

    xgtx76_RecomputeLayout( lv_xgtx );

    /* Insert our body frustum: */
    {   struct xshp06_Args_Rec a;
	xshp07_Init_Shape_Args( &a );
	a.x = x0;
	a.y = y0;
	a.z = z0;
	a.scalex = 1.0;
	a.scaley = r->frustum_height;
	a.scalez = 10.0*r->frustum_depth;
	/* 10.0 above cancels xshp22's internal 0.1 */
	a.lv_thing = lv_body;
	xshp22_Insert_Box_Or_Frustum( &a, 0 /* doBox */ );
    }

    /* Figure bounding box of body, so our parametric coords apply: */
    xthlL2_ObjectspaceBoundingBoxOfThing( &bbmin, &bbmax, lv_body );

    /* Insert a hole in body for new string: */
    if (TRUE) {
	geo_point slot_min;
	geo_point slot_max;

	libP2_InterpolatePointInBox(&slot_min, &r->newstr_min, &bbmin, &bbmax);
	libP2_InterpolatePointInBox(&slot_max, &r->newstr_max, &bbmin, &bbmax);

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (slot_max.x + slot_min.x) * 0.5;
	    a.y = (slot_max.y + slot_min.y) * 0.5;
	    a.z = (slot_max.z + slot_min.z) * 0.5;
	    a.scalex = (slot_max.x - slot_min.x)      ;
	    a.scaley = (slot_max.y - slot_min.y)      ;
	    a.scalez = (slot_max.z - slot_min.z) *10.0;
	    a.omit_bottom = FALSE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}
    }

    /* Insert a hole in body for original string: */
    if (!r->omit_old_str) {
	geo_point slot_min;
	geo_point slot_max;
	libP2_InterpolatePointInBox( &slot_min, &r->oldstr_min, &bbmin, &bbmax );
	libP2_InterpolatePointInBox( &slot_max, &r->oldstr_max, &bbmin, &bbmax );

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (slot_max.x + slot_min.x) * 0.5;
	    a.y = (slot_max.y + slot_min.y) * 0.5;
	    a.z = (slot_max.z + slot_min.z) * 0.5;
	    a.got_p  = TRUE;
	    a.scalex = (slot_max.x - slot_min.x)      ;
	    a.scaley = (slot_max.y - slot_min.y)      ;
	    a.scalez = (slot_max.z - slot_min.z) *10.0;
	    a.omit_bottom = FALSE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}
    }

    /* Insert a hole in body for label: */
    if (!r->omit_label) {
	geo_point slot_min;
	geo_point slot_max;
	libP2_InterpolatePointInBox( &slot_min, &r->label_min, &bbmin, &bbmax);
	libP2_InterpolatePointInBox( &slot_max, &r->label_max, &bbmin, &bbmax);

	{   struct xshp06_Args_Rec a;
	    xshp07_Init_Shape_Args( &a );
	    a.x = (slot_max.x + slot_min.x) * 0.5;
	    a.y = (slot_max.y + slot_min.y) * 0.5;
	    a.z = (slot_max.z + slot_min.z) * 0.5;
	    a.scalex = (slot_max.x - slot_min.x)      ;
	    a.scaley = (slot_max.y - slot_min.y)      ;
	    a.scalez = (slot_max.z - slot_min.z) *10.0;
	    a.omit_bottom = FALSE;
	    a.lv_thing = lv_body;
	    xshp29_Insert_Box_Or_Frustum_Hole( &a, 0 /* doBox */ );
	}
    }

    /* Insert hershey text: */
    xgtx77_ReinsertVaryingPartOfStringReader( lv_xgtx );

    /* Do rescaling if user-requested: */
    if (scalex != 1.0  ||
        scaley != 1.0  ||
        scalez != 1.0
    ) {
	geo_matrix m;
	geo_point  origin;
	geo_point  scale;
	origin.x = x0;
	origin.y = y0;
	origin.z = z0;
	scale.x  = scalex;
	scale.y  = scaley;
	scale.z  = scalez;
        ctfm16_Scale( &m, &origin, &scale );

	xthlK1_TransformThing(lv_body,   &m, /*skip-points:*/0, /*skip-facets:*/0 );
	xthlK1_TransformThing(lv_field,  &m, /*skip-points:*/0, /*skip-facets:*/0 );
	xthlK1_TransformThing(lv_text,   &m, /*skip-points:*/0, /*skip-facets:*/0 );
    }

    /* Thread our things together to make a thinglist: */
    lv_thingList = cons( lv_body,   lv_thingList );
    lv_thingList = cons( lv_field,  lv_thingList );
    lv_thingList = cons( lv_text,   lv_thingList );

    xlpopn(LVALS_TO_PROTECT);
    return lv_thingList;
}
#undef LVALS_TO_PROTECT

LVAL xgtx79_Insert_Msg()
{
    LVAL lv_xgtx	= xgtx01_Get_A_XGTX();

    LVAL lv_body	= NIL;
    LVAL lv_field	= NIL;
    LVAL lv_text	= NIL;

    float x0		= 0.0;
    float y0		= 0.0;
    float z0		= 0.0;

    float scalex	= 1.0;	int got_scalex	= FALSE;
    float scaley	= 1.0;	int got_scaley	= FALSE;
    float scalez	= 1.0;	int got_scalez	= FALSE;

    cgtx_rec* r = xgtx9c_Find_Immediate_Base( lv_xgtx );

    while (moreargs()) {
        LVAL key = xlgasymbol();
	LVAL arg;

        if        (key == k_bodything) {

	    lv_body	= xlgacons();

	} else if (key == k_fieldthing) {

	    lv_field	= xlgacons();

	} else if (key == k_textthing) {

	    lv_text	= xlgacons();

        } else if (key == k_x) {
	    x0		= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
        } else if (key == k_y) {
	    y0		= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
        } else if (key == k_z) {
	    z0		= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

        } else if (key == k_scale) {
	    float scale	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    if (!got_scalex) scalex = scale;
	    if (!got_scaley) scaley = scale;
	    if (!got_scalez) scalez = scale;

        } else if (key == k_scalex) {
	    scalex	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    got_scalex	= TRUE;
        } else if (key == k_scaley) {
	    scaley	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    got_scaley	= TRUE;
        } else if (key == k_scalez) {
	    scalez	= xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	    got_scalez	= TRUE;

	} else {

	    xlerror("Bad :INSERT keyword",key);
        }
    }

    /* Probably should default these to something someday: */
    if (null(lv_body  )) xlfail(":INSERT: no :BODY-THING"  );
    if (null(lv_field )) xlfail(":INSERT: no :FIELD-THING" );
    if (null(lv_text  )) xlfail(":INSERT: no :TEXT-THING"  );

    /* Save our four things in internal variables: */
    xthl91_SetObjectVariable( lv_xgtx, s_bodything  , lv_body   );
    xthl91_SetObjectVariable( lv_xgtx, s_fieldthing , lv_field  );
    xthl91_SetObjectVariable( lv_xgtx, s_textthing  , lv_text   );

    /* Set field hook functions: */
    xthl82_SetProp(&lv_field,k_widget       ,lv_xgtx				);
    xthl82_SetProp(&lv_field,k_downclickhook,getfunction(s_xg3dguixgtxdownclickfn) );
    xthl82_SetProp(&lv_field,k_draghook     ,getfunction(s_xg3dguixgtxdragfn     ) );
    xthl82_SetProp(&lv_field,k_upclickhook  ,getfunction(s_xg3dguixgtxupclickfn  ) );

    return xgtx78_Insert(
	lv_xgtx,
	x0, y0, z0,
	scalex, scaley, scalez
    );
}

/* }}} */
/* {{{ xgtx91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xgtx90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XGTX_PROPS + x03d89_PropListLength( *pPropList ) );
}
LVAL xgtx91_ProplistLength_Msg()
{
    return xgtx90_ProplistLength( xgtx01_Get_A_XGTX() );
}

/* }}} */
/* {{{ xgtx95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xgtx94_ProplistNth( lv_g )
LVAL                     lv_g;
{
    LVAL*pPropList  = x03d73_pPropList( lv_g );
    LVAL lv_n       = xlgafixnum();
    int  n          = getfixnum(lv_n);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    switch (n) {
    case  0: return k_label;
    case  1: return k_string;
    case  2: return k_labelfont;
    case  3: return k_stringfont;
    case  4: return k_verticalmargin;
    case  5: return k_horizontalmargin;
    case  6: return k_stringheight;
    case  7: return k_labelheight;
    case  8: return k_frustumdepth;
    case  9: return k_stringdepth;
    case 10: return k_labeldepth;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XGTX_PROPS,
	    lv_n,
	    default_val,
	    got_default
	);
    }
}
LVAL xgtx95_ProplistNth_Msg()
{
    return xgtx94_ProplistNth( xgtx01_Get_A_XGTX() );
}

/* }}} */
/* {{{ xgtx9c_Find_Immediate_Base                                           */

cgtx_rec* xgtx9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    cgtx_rec*gtx = (cgtx_rec*) gobjimmbase( lv );
    return gtx;
}

/* }}} */
/* {{{ xgtxz7_Read_Xgtx_From_File                                           */

xgtxz7_Read_Xgtx_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   cgtx_rec* h;
    char*     p;
    if (version != CGTX_REC_VERSION) {
	xlerror("xgtxz7: unsupported version",cvfixnum(version));
    }
    h = (cgtx_rec*) gobjimmbase( lv );

    p = (char*) &h->CGTX_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CGTX_INT32_COUNT,  magic, fp );

    p = (char*) &h->CGTX_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CGTX_FLOAT_COUNT,  magic, fp );

    p = (char*) &h->CGTX_FIRST_BYTE;
    p = cfil52_Read_Bytes_From_File(   p, CGTX_BYTE_COUNT ,  magic, fp );
}


/* }}} */
/* {{{ xgtxwo_Write_Xgtx_To_Graphics_File                                   */

xgtxwo_Write_Xgtx_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   cgtx_rec* h = (cgtx_rec*) gobjimmbase( lv );
	char*     p;

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CGTX_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CGTX_FIRST_INT32, CGTX_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CGTX_FIRST_FLOAT, CGTX_FLOAT_COUNT, fdob);
	cfil45_Write_Bytes_To_File( &h->CGTX_FIRST_BYTE , CGTX_BYTE_COUNT , fdob);
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
