/* {{{ xs1d.h -- Sliders, 1-Dimensional.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jun29
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xs1d;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xs1d00_Is_New();
extern LVAL xs1d08_Copy_Msg();
extern LVAL xs1d03_Show_Msg();
extern LVAL xs1d40_Get_Msg();
extern LVAL xs1d42_Put_Msg();
extern LVAL xs1d65_Downclick_Fn();
extern LVAL xs1d67_Upclick_Fn();
extern LVAL xs1d69_Drag_Fn();
extern LVAL xs1d79_Insert_Msg();
extern LVAL xs1d91_ProplistLength_Msg();
extern LVAL xs1d95_ProplistNth_Msg();

#ifndef EXTERNED_SHOW
extern LVAL k_show;/* Keyword ":show" */
#define EXTERNED_SHOW
#endif

#ifndef EXTERNED_LABELFONT
extern LVAL k_labelfont;/* Keyword ":label-font" */
#define EXTERNED_LABELFONT
#endif

#ifndef EXTERNED_LIMITFONT
extern LVAL k_limitfont;/* Keyword ":limit-font" */
#define EXTERNED_LIMITFONT
#endif

#ifndef EXTERNED_MINX
extern LVAL k_minx;/* Keyword ":min-x" */
#define EXTERNED_MINX
#endif

#ifndef EXTERNED_MAXX
extern LVAL k_maxx;/* Keyword ":max-x" */
#define EXTERNED_MINX
#endif

#ifndef EXTERNED_X
extern LVAL k_x;/* Keyword ":x" */
#define EXTERNED_X
#endif

#ifndef EXTERNED_NEUTRALX
extern LVAL k_neutralx;/* Keyword ":neutral-x" */
#define EXTERNED_NEUTRALX
#endif

#ifndef EXTERNED_LASTDELTAX
extern LVAL k_lastdeltax;/* Keyword ":last-delta-x" */
#define EXTERNED_LASTDELTAX
#endif

#ifndef EXTERNED_ENFORCEMINX
extern LVAL k_enforceminx;/* Keyword ":enforce-min-x" */
#define EXTERNED_ENFORCEMINX
#endif

#ifndef EXTERNED_ENFORCEMAXX
extern LVAL k_enforcemaxx;/* Keyword ":enforce-max-x" */
#define EXTERNED_ENFORCEMAXX
#endif

#ifndef EXTERNED_LABEL
extern LVAL k_label;/* Keyword ":label" */
#define EXTERNED_LABEL
#endif

#ifndef EXTERNED_BODYTHING
extern LVAL k_bodything;/* Keyword ":body-thing" */
#define EXTERNED_BODYTHING
#endif

#ifndef EXTERNED_FIELDTHING
extern LVAL k_fieldthing;/* Keyword ":field-thing" */
#define EXTERNED_FIELDTHING
#endif

#ifndef EXTERNED_TEXTTHING
extern LVAL k_textthing;/* Keyword ":text-thing" */
#define EXTERNED_TEXTTHING
#endif

#ifndef EXTERNED_SLIDERTHING
extern LVAL k_sliderthing;/* Keyword ":slider-thing" */
#define EXTERNED_SLIDERTHING
#endif

#ifndef EXTERNED_S_XG3DGUICURRENTWIDGET
extern LVAL s_xg3dguicurrentwidget;/* Symbol "xg.3d.gui-current-widget" */
#define EXTERNED_S_XG3DGUICURRENTWIDGET
#endif

#ifndef EXTERNED_S_XG3DGUIXS1DDOWNCLICKFN
extern LVAL s_xg3dguixs1ddownclickfn;/* Symbol "xg.3d.gui-xs1d-downclick-fn" */
#define EXTERNED_S_XG3DGUIXS1DDOWNCLICKFN
#endif

#ifndef EXTERNED_S_XG3DGUIXS1DDRAGFN
extern LVAL s_xg3dguixs1ddragfn;/* Symbol "xg.3d.gui-xs1d-drag-fn" */
#define EXTERNED_S_XG3DGUIXS1DDRAGFN
#endif

#ifndef EXTERNED_S_XG3DGUIXS1DUPCLICKFN
extern LVAL s_xg3dguixs1dupclickfn;/* Symbol "xg.3d.gui-xs1d-upclick-fn" */
#define EXTERNED_S_XG3DGUIXS1DUPCLICKFN
#endif

#ifndef EXTERNED_S_BODYTHING
extern LVAL s_bodything;/* Symbol "body-thing" */
#define EXTERNED_S_BODYTHING
#endif

#ifndef EXTERNED_S_FIELDTHING
extern LVAL s_fieldthing;/* Symbol "field-thing" */
#define EXTERNED_S_FIELDTHING
#endif

#ifndef EXTERNED_S_SLIDERTHING
extern LVAL s_sliderthing;/* Symbol "slider-thing" */
#define EXTERNED_S_SLIDERTHING
#endif

#ifndef EXTERNED_S_TEXTTHING
extern LVAL s_textthing;/* Symbol "text-thing" */
#define EXTERNED_S_TEXTTHING
#endif

#ifndef EXTERNED_VERTICALMARGIN
extern LVAL k_verticalmargin;/* Keyword ":vertical-margin" */
#define EXTERNED_VERTICALMARGIN
#endif

#ifndef EXTERNED_HORIZONTALMARGIN
extern LVAL k_horizontalmargin;/* Keyword ":horizontal-margin" */
#define EXTERNED_HORIZONTALMARGIN
#endif

#ifndef EXTERNED_FRUSTUMDEPTH
extern LVAL k_frustumdepth;/* Keyword ":frustum-depth" */
#define EXTERNED_FRUSTUMDEPTH
#endif

#ifndef EXTERNED_SLIDERDEPTH
extern LVAL k_sliderdepth;/* Keyword ":slider-depth" */
#define EXTERNED_SLIDERDEPTH
#endif

#ifndef EXTERNED_LIMITSDEPTH
extern LVAL k_limitsdepth;/* Keyword ":limits-depth" */
#define EXTERNED_LIMITSDEPTH
#endif

#ifndef EXTERNED_LABELDEPTH
extern LVAL k_labeldepth;/* Keyword ":label-depth" */
#define EXTERNED_LABELDEPTH
#endif

#ifndef EXTERNED_SLIDERHEIGHT
extern LVAL k_sliderheight;/* Keyword ":slider-height" */
#define EXTERNED_SLIDERHEIGHT
#endif

#ifndef EXTERNED_LIMITSHEIGHT
extern LVAL k_limitsheight;/* Keyword ":limits-height" */
#define EXTERNED_LIMITSHEIGHT
#endif

#ifndef EXTERNED_LABELHEIGHT
extern LVAL k_labelheight;/* Keyword ":label-height" */
#define EXTERNED_LABELHEIGHT
#endif

#ifndef EXTERNED_SLIDERLENGTH
extern LVAL k_sliderlength;/* Keyword ":slider-length" */
#define EXTERNED_SLIDERLENGTH
#endif

#ifndef EXTERNED_CHANGEHOOK
extern LVAL k_changehook;/* Keyword ":change-hook" */
#define EXTERNED_CHANGEHOOK
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,			xs1d00_Is_New			)
DEFINE_SUBR(	NULL,			xs1d08_Copy_Msg			)
DEFINE_SUBR(	NULL,			xs1d03_Show_Msg			)
DEFINE_SUBR(	NULL,			xs1d40_Get_Msg			)
DEFINE_SUBR(	NULL,			xs1d42_Put_Msg			)
DEFINE_SUBR(	"XG.3D.GUI-XS1D-DOWNCLICK-FN",xs1d65_Downclick_Fn		)
DEFINE_SUBR(	"XG.3D.GUI-XS1D-UPCLICK-FN",	xs1d67_Upclick_Fn		)
DEFINE_SUBR(	"XG.3D.GUI-XS1D-DRAG-FN",	xs1d69_Drag_Fn			)
DEFINE_SUBR(	NULL,			xs1d79_Insert_Msg		)
DEFINE_SUBR(	NULL,			xs1d91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,			xs1d95_ProplistNth_Msg		)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLINIT
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xs1d;
LOCAL struct xs1d_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xs1d_table[] = {
    {	":ISNEW",		xs1d00_Is_New			},
    {	":COPY",		xs1d08_Copy_Msg			},
    {	":SHOW",		xs1d03_Show_Msg			},
    {	":GET", 		xs1d40_Get_Msg			},
    {	":SET", 		xs1d42_Put_Msg			},
    {	":INSERT",		xs1d79_Insert_Msg		},
    {	":PROPERTY-LIST-LENGTH",xs1d91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xs1d95_ProplistNth_Msg		},

    {	NULL,			NULL				}
};

#ifndef DEFINED_SHOW
LVAL k_show;/* Keyword ":show" */
#define DEFINED_SHOW
#endif

#ifndef DEFINED_LABELFONT
LVAL k_labelfont;/* Keyword ":label-font" */
#define DEFINED_LABELFONT
#endif

#ifndef DEFINED_LIMITFONT
LVAL k_limitfont;/* Keyword ":limit-font" */
#define DEFINED_LIMITFONT
#endif

#ifndef DEFINED_MINX
LVAL k_minx;/* Keyword ":min-x" */
#define DEFINED_MINX
#endif

#ifndef DEFINED_MAXX
LVAL k_maxx;/* Keyword ":max-x" */
#define DEFINED_MAXX
#endif

#ifndef DEFINED_X
LVAL k_x;/* Keyword ":x" */
#define DEFINED_X
#endif

#ifndef DEFINED_NEUTRALX
LVAL k_neutralx;/* Keyword ":neutral-x" */
#define DEFINED_NEUTRALX
#endif

#ifndef DEFINED_LASTDELTAX
LVAL k_lastdeltax;/* Keyword ":last-delta-x" */
#define DEFINED_LASTDELTAX
#endif

#ifndef DEFINED_ENFORCEMINX
LVAL k_enforceminx;/* Keyword ":enforce-min-x" */
#define DEFINED_ENFORCEMINX
#endif

#ifndef DEFINED_ENFORCEMAXX
LVAL k_enforcemaxx;/* Keyword ":enforce-max-x" */
#define DEFINED_ENFORCEMAXX
#endif

#ifndef DEFINED_LABEL
LVAL k_label;/* Keyword ":label" */
#define DEFINED_LABEL
#endif

#ifndef DEFINED_BODYTHING
LVAL k_bodything;/* Keyword ":body-thing" */
#define DEFINED_BODYTHING
#endif

#ifndef DEFINED_FIELDTHING
LVAL k_fieldthing;/* Keyword ":field-thing" */
#define DEFINED_FIELDTHING
#endif

#ifndef DEFINED_TEXTTHING
LVAL k_textthing;/* Keyword ":text-thing" */
#define DEFINED_TEXTTHING
#endif

#ifndef DEFINED_SLIDERTHING
LVAL k_sliderthing;/* Keyword ":slider-thing" */
#define DEFINED_SLIDERTHING
#endif

#ifndef DEFINED_S_XG3DGUIXS1DUPCLICKFN
LVAL s_xg3dguixs1dupclickfn;/* Symbol "xg.3d.gui-xs1d-upclick-fn" */
#define DEFINED_S_XG3DGUIXS1DUPCLICKFN
#endif

#ifndef DEFINED_S_XG3DGUIXS1DDRAGFN
LVAL s_xg3dguixs1ddragfn;/* Symbol "xg.3d.gui-xs1d-drag-fn" */
#define DEFINED_S_XG3DGUIXS1DDRAGFN
#endif

#ifndef DEFINED_S_XG3DGUIXS1DDOWNCLICKFN
LVAL s_xg3dguixs1ddownclickfn;/* Symbol "xg.3d.gui-xs1d-downclick-fn" */
#define DEFINED_S_XG3DGUIXS1DDOWNCLICKFN
#endif

#ifndef DEFINED_S_XG3DGUICURRENTWIDGET
LVAL s_xg3dguicurrentwidget;/* Symbol "xg.3d.gui-current-widget" */
#define DEFINED_S_XG3DGUICURRENTWIDGET
#endif

#ifndef DEFINED_S_BODYTHING
LVAL s_bodything;/* Symbol "body-thing" */
#define DEFINED_S_BODYTHING
#endif

#ifndef DEFINED_S_SLIDERTHING
LVAL s_sliderthing;/* Symbol "slider-thing" */
#define DEFINED_S_SLIDERTHING
#endif

#ifndef DEFINED_S_FIELDTHING
LVAL s_fieldthing;/* Symbol "field-thing" */
#define DEFINED_S_FIELDTHING
#endif

#ifndef DEFINED_S_TEXTTHING
LVAL s_textthing;/* Symbol "text-thing" */
#define DEFINED_S_TEXTTHING
#endif

#ifndef DEFINED_VERTICALMARGIN
LVAL k_verticalmargin;/* Keyword ":vertical-margin" */
#define DEFINED_VERTICALMARGIN
#endif

#ifndef DEFINED_HORIZONTALMARGIN
LVAL k_horizontalmargin;/* Keyword ":horizontal-margin" */
#define DEFINED_HORIZONTALMARGIN
#endif

#ifndef DEFINED_FRUSTUMDEPTH
LVAL k_frustumdepth;/* Keyword ":frustum-depth" */
#define DEFINED_FRUSTUMDEPTH
#endif

#ifndef DEFINED_SLIDERDEPTH
LVAL k_sliderdepth;/* Keyword ":slider-depth" */
#define DEFINED_SLIDERDEPTH
#endif

#ifndef DEFINED_LIMITSDEPTH
LVAL k_limitsdepth;/* Keyword ":limits-depth" */
#define DEFINED_LIMITSDEPTH
#endif

#ifndef DEFINED_LABELDEPTH
LVAL k_labeldepth;/* Keyword ":label-depth" */
#define DEFINED_LABELDEPTH
#endif

#ifndef DEFINED_SLIDERHEIGHT
LVAL k_sliderheight;/* Keyword ":slider-height" */
#define DEFINED_SLIDERHEIGHT
#endif

#ifndef DEFINED_LIMITSHEIGHT
LVAL k_limitsheight;/* Keyword ":limits-height" */
#define DEFINED_LIMITSHEIGHT
#endif

#ifndef DEFINED_LABELHEIGHT
LVAL k_labelheight;/* Keyword ":label-height" */
#define DEFINED_LABELHEIGHT
#endif

#ifndef DEFINED_SLIDERLENGTH
LVAL k_sliderlength;/* Keyword ":slider-length" */
#define DEFINED_SLIDERLENGTH
#endif

#ifndef DEFINED_CHANGEHOOK
LVAL k_changehook;/* Keyword ":change-hook" */
#define DEFINED_CHANGEHOOK
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_SHOW
    k_show = xlenter(":SHOW");
#define CREATED_SHOW
#endif

#ifndef CREATED_LABELFONT
    k_labelfont = xlenter(":LABEL-FONT");
#define CREATED_LABELFONT
#endif

#ifndef CREATED_LIMITFONT
    k_limitfont = xlenter(":LIMIT-FONT");
#define CREATED_LIMITFONT
#endif

#ifndef CREATED_MINX
    k_minx = xlenter(":MIN-X");
#define CREATED_MINX
#endif

#ifndef CREATED_MAXX
    k_maxx = xlenter(":MAX-X");
#define CREATED_MAXX
#endif

#ifndef CREATED_X
    k_x = xlenter(":X");
#define CREATED_X
#endif

#ifndef CREATED_NEUTRALX
    k_neutralx = xlenter(":NEUTRAL-X");
#define CREATED_NEUTRALX
#endif

#ifndef CREATED_LASTDELTAX
    k_lastdeltax = xlenter(":LAST-DELTA-X");
#define CREATED_LASTDELTAX
#endif

#ifndef CREATED_ENFORCEMINX
    k_enforceminx = xlenter(":ENFORCE-MIN-X");
#define CREATED_ENFORCEMINX
#endif

#ifndef CREATED_ENFORCEMAXX
    k_enforcemaxx = xlenter(":ENFORCE-MAX-X");
#define CREATED_ENFORCEMAXX
#endif

#ifndef CREATED_LABEL
    k_label = xlenter(":LABEL");
#define CREATED_LABEL
#endif

#ifndef CREATED_BODYTHING
    k_bodything = xlenter(":BODY-THING");
#define CREATED_BODYTHING
#endif

#ifndef CREATED_FIELDTHING
    k_fieldthing = xlenter(":FIELD-THING");
#define CREATED_FIELDTHING
#endif

#ifndef CREATED_TEXTTHING
    k_textthing = xlenter(":TEXT-THING");
#define CREATED_TEXTTHING
#endif

#ifndef CREATED_SLIDERTHING
    k_sliderthing = xlenter(":SLIDER-THING");
#define CREATED_SLIDERTHING
#endif

#ifndef CREATED_S_XG3DGUIXS1DUPCLICKFN
    s_xg3dguixs1dupclickfn = xlenter("XG.3D.GUI-XS1D-UPCLICK-FN");
#define CREATED_S_XG3DGUIXS1DUPCLICKFN
#endif

#ifndef CREATED_S_XG3DGUIXS1DDRAGFN
    s_xg3dguixs1ddragfn = xlenter("XG.3D.GUI-XS1D-DRAG-FN");
#define CREATED_S_XG3DGUIXS1DDRAGFN
#endif

#ifndef CREATED_S_XG3DGUIXS1DDOWNCLICKFN
    s_xg3dguixs1ddownclickfn = xlenter("XG.3D.GUI-XS1D-DOWNCLICK-FN");
#define CREATED_S_XG3DGUIXS1DDOWNCLICKFN
#endif

#ifndef CREATED_S_XG3DGUICURRENTWIDGET
    s_xg3dguicurrentwidget = xlenter("XG.3D.GUI-CURRENT-WIDGET");
#define CREATED_S_XG3DGUICURRENTWIDGET
#endif

#ifndef CREATED_S_BODYTHING
    s_bodything = xlenter("BODY-THING");
#define CREATED_S_BODYTHING
#endif

#ifndef CREATED_S_SLIDERTHING
    s_sliderthing = xlenter("SLIDER-THING");
#define CREATED_S_SLIDERTHING
#endif

#ifndef CREATED_S_FIELDTHING
    s_fieldthing = xlenter("FIELD-THING");
#define CREATED_S_FIELDTHING
#endif

#ifndef CREATED_S_TEXTTHING
    s_textthing = xlenter("TEXT-THING");
#define CREATED_S_TEXTTHING
#endif

#ifndef CREATED_VERTICALMARGIN
    k_verticalmargin = xlenter(":VERTICAL-MARGIN");
#define CREATED_VERTICALMARGIN
#endif

#ifndef CREATED_HORIZONTALMARGIN
    k_horizontalmargin = xlenter(":HORIZONTAL-MARGIN");
#define CREATED_HORIZONTALMARGIN
#endif

#ifndef CREATED_FRUSTUMDEPTH
    k_frustumdepth = xlenter(":FRUSTUM-DEPTH");
#define CREATED_FRUSTUMDEPTH
#endif

#ifndef CREATED_SLIDERDEPTH
    k_sliderdepth = xlenter(":SLIDER-DEPTH");
#define CREATED_SLIDERDEPTH
#endif

#ifndef CREATED_LIMITSDEPTH
    k_limitsdepth = xlenter(":LIMITS-DEPTH");
#define CREATED_LIMITSDEPTH
#endif

#ifndef CREATED_LABELDEPTH
    k_labeldepth = xlenter(":LABEL-DEPTH");
#define CREATED_LABELDEPTH
#endif

#ifndef CREATED_SLIDERHEIGHT
    k_sliderheight = xlenter(":SLIDER-HEIGHT");
#define CREATED_SLIDERHEIGHT
#endif

#ifndef CREATED_LIMITSHEIGHT
    k_limitsheight = xlenter(":LIMITS-HEIGHT");
#define CREATED_LIMITSHEIGHT
#endif

#ifndef CREATED_LABELHEIGHT
    k_labelheight = xlenter(":LABEL-HEIGHT");
#define CREATED_LABELHEIGHT
#endif

#ifndef CREATED_SLIDERLENGTH
    k_sliderlength = xlenter(":SLIDER-LENGTH");
#define CREATED_SLIDERLENGTH
#endif

#ifndef CREATED_CHANGEHOOK
    k_changehook = xlenter(":CHANGE-HOOK");
#define CREATED_CHANGEHOOK
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xs1d = xgbj58_Create_Class("CLASS-SLIDER",lv_x03d);
    xgbj57_Add_Instance_Variable( lv_xs1d,"BODY-THING");
    xgbj57_Add_Instance_Variable( lv_xs1d,"FIELD-THING");
    xgbj57_Add_Instance_Variable( lv_xs1d,"SLIDER-THING");
    xgbj57_Add_Instance_Variable( lv_xs1d,"TEXT-THING");
    xgbj56_Enter_Messages(        lv_xs1d,  xs1d_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
