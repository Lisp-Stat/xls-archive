/* {{{ xgui.h -- Graphical User Interface.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jun27
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/*extern LVAL xgui08_Resize_Image_Msg();*/

/*#ifndef EXTERNED_FROM*/
/*extern LVAL k_from;   /* Keyword ":FROM" */
/*#define EXTERNED_FROM*/
/*#endif*/

#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
/*DEFINE_SUBR(	NULL,				xgui08_Resize_Image_Msg		)*/
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS


/*#ifndef DEFINED_BLURFACTOR*/
/*LVAL k_blurfactor;   /* Keyword ":blur-factor" */
/*#define DEFINED_BLURFACTOR*/
/*#endif*/

#ifdef SOON
LOCAL struct xgui_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xgui_xu8v_table[] = {
    {	":RESIZE-IMAGE",	xgui08_Resize_Image_Msg        	},

    {	NULL,			NULL	                	}
};
#endif
#endif

#ifdef MODULE_XLOBJ_C_OBSYMBOLS

/*#ifndef CREATED_BLURFACTOR*/
/*    k_blurfactor = xlenter(":BLUR-FACTOR");
#define CREATED_BLURFACTOR
#endif*/

#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
/*    xgbj56_Enter_Messages( lv_xu8v,  xgui_xu8v_table );*/
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
