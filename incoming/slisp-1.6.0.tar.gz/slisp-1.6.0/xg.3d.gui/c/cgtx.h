/* {{{ cgtx.h -- text-input (GeT teXt) objects.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jul27
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
********************************************************************************
*/

#ifndef INCLUDED_CGTX_H
#define INCLUDED_CGTX_H

/* }}} */

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#include "../../xg.3d/c/c03d.h"
#include "../../xg.3d/c/geo.h"

#define CGTX_REC_VERSION (28)

#define CGTX_MAX_LABEL   (64)

/* Currently supported different visual styles for menus: */
#define CGTX_STYLE_1 (1)


/* A struct type that holds everything we need to know about a menu.    */
/* WARNING:  xgtx.c depends on the below order to initialize correctly. */
/* See xgtx00_Is_New.     						*/ 
struct cgtx_struct {
    int           k_class; /* k_class should always be first in record. */
    c03d_fileInfo fileInfo;/* Always 2nd in record.  Save-file.         */

#define CGTX_FIRST_INT32 menu_style
#define CGTX_INT32_COUNT 9
    int		  menu_style;
    int		  string_font;
    int		  label_font;
    int		  omit_old_str;
    int		  omit_label;
    int		  omit_body;	/* Unimplemented.			*/
    int		  in_changehook;/* TRUE iff calling changehook fn.	*/
    int		  spare_1;
    int		  spare_2;

#define CGTX_FIRST_FLOAT vertical_margin
#define CGTX_FLOAT_COUNT 31

    /* Numbers the user uses to specify layout: */
    float vertical_margin;	/* As fraction of width, before scaling.*/
    float horizontal_margin;	/* As fraction of width, before scaling.*/

    float string_height;	/* As fraction of width, before scaling.*/
    float label_height;		/* As fraction of width, before scaling.*/

    float string_depth;		/* As fraction of width, before scaling.*/
    float label_depth;		/* As fraction of width, before scaling.*/

    float frustum_depth;	/* As fraction of width, before scaling.*/



    /* Internal layout numbers derived from above: */

    float 	frustum_height;		/* As fraction of width, before scaling.*/

    float	text_spot_x;		/* Offset relative to the */	
    float	text_spot_y;		/* hole the text is in.	  */
    float	text_scale_x;
    float	text_scale_y;

    geo_point	oldstr_min, oldstr_max;/* Parametric 0->1 in coords of bounding box. */
    geo_point	newstr_min, newstr_max;/* Parametric 0->1 in coords of bounding box. */
    geo_point	label_min , label_max ;/* Parametric 0->1 in coords of bounding box. */

    float	fspare_1;

#define CGTX_FIRST_BYTE  label[0]
#define CGTX_BYTE_COUNT  (3 * CGTX_MAX_LABEL)
    char	  label[      CGTX_MAX_LABEL ];
    char	  old_string[ CGTX_MAX_LABEL ];
    char	  new_string[ CGTX_MAX_LABEL ];
};
typedef struct cgtx_struct  cgtx_rec;

extern LVAL xgtx70_Do_Hook_Fn();

#define xgtxp(o) (gobjectp(o) && ((((cgtx_rec*)(gobjimmbase(o)))->k_class) == C03D_xGTX))

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
#endif
/* }}} */
