/* {{{ xavs.c -- AVS: Code to interface to AVS system.			*/

/* This file is formatted for use with folding.el for emacs, sort	*/
/* of an outline-mode for programmers, ftp-able from elisp archives	*/
/* such as tut.cis.ohio-state.edu (128.146.8.52).  If you don't use	*/
/* folding-mode and/or emacs, you may want to prepare a table of	*/
/* contents for this file by doing "grep '{{{' thisfile.c".		*/

/* -*-C-*-                                                                  CrT
*******************************************************************************
*
* Author:       Jeff Prothero
* Created:      94Feb24
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
* See slisp/SLISPCOPYING for distribution information
*******************************************************************************
*/

/************************************************************************/
/*                              history                                 */
/*									*/
/* 94Feb24 jsp: Created.						*/
/************************************************************************/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/cthl.h"
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/cf6v.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

/* }}} */

/* {{{ Header stuff							*/

#include <string.h>
#include <ctype.h>

#include "cavs.h"

/* xavs_geometry is our communication channel with avs: */
Xavs_List xavs_geometry;

/* }}} */
/* {{{ xavs_Init -- Start-of-world initialization.			*/

xavs_Init() {

    static done_init = FALSE;
    if  (done_init)   return;
    else done_init   = TRUE ;
}   

/* }}} */
/* {{{ xavs13_Avs_To_Thinglist -- Convert AVS geometry to thinglist	*/

LVAL xavs13_Avs_To_Thinglist_Fn( )
{
    xlfail("xavs-avs-to-thinglist unimplemented");
}

/* }}} */
/* {{{ xavs15_Initialize_GEOMpolyh --					*/

xavs15_Initialize_GEOMpolyh( g )
GEOMpolyh *                  g ;
{
    /* Set our various pointers to NIL: */
    g->verts  .l = NULL;
    g->normals.l = NULL;
    g->colors .l = NULL;
    g->uvs    .l = NULL;
    g->vdata  .l = NULL;
    g->pdata  .l = NULL;
    g->vtrans .l = NULL;

    /* Set official sizes to empty too, not sure */
    /* what avs looks at, so be thorough:        */
    g->verts  .alloced_size = 0;
    g->normals.alloced_size = 0;
    g->colors .alloced_size = 0;
    g->uvs    .alloced_size = 0;
    g->vdata  .alloced_size = 0;
    g->pdata  .alloced_size = 0;
    g->vtrans .alloced_size = 0;

    g->verts  .n            = 0;
    g->normals.n            = 0;
    g->colors .n            = 0;
    g->uvs    .n            = 0;
    g->vdata  .n            = 0;
    g->pdata  .n            = 0;
    g->vtrans .n            = 0;
}

/* }}} */

/* {{{ xavs23_Thinglist_To_Avs_Fn -- Convert thinglist to AVS geometry.	*/

xavs21_Thinglist_To_Avs( dummy, r, cell )
int                      dummy;
gt_tri_rec                     *r;
LVAL                               cell;
{
    /* We really should pass through empty pointsets */
    /* properly one of these days, but this is easy: */
    if (!r->pLen || !r->fLen)   return;
    {

	/* Allocate GEOMpolyh record, and a list cell */
	/* to string it onto any pre-existing ones:   */
	Xavs_List  c = (Xavs_List)  malloc( sizeof( Xavs_A_List ) );
	GEOMpolyh* g = (GEOMpolyh*) malloc( sizeof( GEOMpolyh   ) );
	if (!g || !c) {
	    fputs("xavs21_Thinglist_To_Avs.1: out of ram!\n", stderr);
	    exit(1);
	}

	/* Initialize both, prepend new GEOMpoly to xavs_geometry list: */
	xavs15_Initialize_GEOMpolyh( g );
	c->g           = g;
	c->next        = xavs_geometry;
	xavs_geometry  = c;

	/* Copy thing into GEOMpolyh: */

	/* Allocate and fill in the vertices array: */
	g->verts.n	      = r->pLen;
	g->verts.alloced_size = 3 * sizeof(float) * r->pLen;
	g->verts.l	      = (float*) malloc( g->verts.alloced_size );
	if (!g->verts.l) {
	    fputs("xavs21_Thinglist_To_Avs.2: out of ram!\n",stderr);
	    exit(1);
	}
	{   float* p = g->verts.l;
	    int  i;
	    for (i = 0;   i < r->pLen;   ++i) {
		p[0] = r->x ? r->x[ i ] : 0.0;
		p[1] = r->y ? r->y[ i ] : 0.0;
		p[2] = r->z ? r->z[ i ] : 0.0;
		p += 3;
	}   }

	/* Allocate and fill in the polygon array: */
	{   /* How many vertices/polygon? */
	    int card = 4;
	    if (!r->got_rectangles)   --card;
	    if (!r->got_triangles )   --card;
	    if (!r->got_segments  )   --card;
	    if (!r->got_points    )   --card;

	    g->ptlist.nps = r->fLen;	/* Total number of polygons. */
	    g->ptlist.nvs = r->fLen*card;	/* Total number of vertices. */

	    g->ptlist.alloced_size = (card+1) * sizeof(int) * r->fLen +1;
	    g->ptlist.l	       = (int*) malloc( g->ptlist.alloced_size );
	    if (!g->ptlist.l) {
		fputs("xavs21_Thinglist_To_Avs.3: out of ram!\n",stderr);
		exit(1);
	    }
	    {   int* p = g->ptlist.l;
		int  i;
		switch (card) {

		case 1:
		    for (i = 0;   i < r->fLen;   ++i) {
			*p++ = card       ;
			*p++ = r->f0[i] +1;
		    }
		    break;

		case 2:
		    for (i = 0;   i < r->fLen;   ++i) {
			*p++ = card       ;
			*p++ = r->f0[i] +1;
			*p++ = r->f1[i] +1;
		    }
		    break;

		case 3:
		    for (i = 0;   i < r->fLen;   ++i) {
			*p++ = card       ;
			*p++ = r->f0[i] +1;	/* Note order reversal. */
			*p++ = r->f2[i] +1;
			*p++ = r->f1[i] +1;
		    }
		    break;

		case 4:
		    for (i = 0;   i < r->fLen;   ++i) {
			*p++ = card       ;
			*p++ = r->f0[i] +1;
			*p++ = r->f3[i] +1;	/* Note order reversal. */
			*p++ = r->f2[i] +1;
			*p++ = r->f1[i] +1;
		    }
		    break;

		default:
		    fprintf(stderr,
			"xavs21_Thinglist_To_Avs.3: card d=%d?!\n",
			card
		    );
		    exit(1);
		}
		/* AVS specifies zero termination for list: */
		p[0] = 0;
    }	}   }
}
xavs22_Thinglist_To_Avs( things )
LVAL			 things;
{
    gt_tri_rec            r;
    xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
/* buggo, we don't recycle memory from last list yet. */
    xavs_geometry  = NULL;
    xthlB0_Process_Thing_List( things, &r, xavs21_Thinglist_To_Avs, 0 );
}

LVAL xavs23_Thinglist_To_Avs_Fn()
{
    LVAL thinglist = xlgacons();
    xllastarg();
    xavs22_Thinglist_To_Avs( thinglist );
    return NIL;
}

/* }}} */
/* {{{ xavs33_Avs_Print_Fn -- Debug fn to print out avs list.		*/

/* This is strictly a throwaway debug hack. */

xavs31_Avs_Print( g )
GEOMpolyh*        g;
{
    puts("\nxavs32_Avs_Print debug printout of one GEOMpolyh:\n");
    printf("g->verts.alloced_size d=%d\n", g->verts.alloced_size);
    printf("g->verts.n            d=%d\n", g->verts.n);
    printf("g->verts.l            x=%x\n", g->verts.l);
    putchar('\n');

    printf("g->ptlist.nps d=%d\n", g->ptlist.nps);
    printf("g->ptlist.nvs d=%d\n", g->ptlist.nvs);
    printf("g->ptlist.alloced_size d=%d\n", g->ptlist.alloced_size);
    printf("g->ptlist.l            x=%x\n", g->ptlist.l);

    {   int*    p = g->ptlist.l;
	while (*p) {
	    int j;
	    int card = *p++;
	    printf("\n%d-gon:\n",card);
	    for (j = 0;   j < card;   ++j) {	    
		int    x = *p++;
		float* q = &g->verts.l[ (x-1) *3 ];
		printf("%d: %g %g %g\n",x-1,q[0],q[1],q[2]);
    }	}   }
}

xavs32_Avs_Print()
{
    Xavs_List p;
    for (p = xavs_geometry;   p;   p = p->next) {
	xavs31_Avs_Print( p->g );
    }
}

LVAL xavs33_Avs_Print_Fn()
{
    xllastarg();
    xavs32_Avs_Print();
    return NIL;
}

/* }}} */
/* {{{ xavs48_VoxelRelation_To_Avs_Fn -- Convert to AVS geometry.	*/

xavs46_PerArray(
    int* dum,
    LVAL lv_key,
    LVAL lv_val
) {
    /* If it's a 16-bit array: */
    if (xf6vp( lv_val )) {

        /* Get name of array: */
	char* name = "(bad name!)";
	if (stringp(lv_key)) name =   (char*)getstring( lv_key );
	if (symbolp(lv_key)) name = 1+(char*)getstring( getpname(lv_key) );

	/* Get dimensions of array: */
	{   csry_rec* h = (csry_rec*) gobjimmbase( lv_val );
	    /* Ignore arrays which aren't 3-D: */
	    if (h->rank == 3) {
		int z_dim = h->dim[0];
		int y_dim = h->dim[1];
		int x_dim = h->dim[2];

printf("Found a %dx%dx%d array '%s' (%x)\n",x_dim,y_dim,z_dim,name,lv_val);
	}   }
    }
    return FALSE;
}
xavs47_Voxels_To_Avs( lv_vox )
LVAL		      lv_vox;
{
    /* Over all arrays in relation: */
    xgrl14_Map_ArrayList( lv_vox, xavs46_PerArray, NULL );
}

LVAL xavs48_Voxels_To_Avs_Fn()
{
    LVAL lv_vox = xgrl01_Get_A_XGRL();
    xllastarg();
    xavs47_Voxels_To_Avs( lv_vox );
    return NIL;
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/


/* }}} */

