/* The following AVS geometry definitions are extracted from      */
/* AVS header files and no doubt carry restrictive proprietary    */
/* copyrights, patent-pending warnings, and/or unpublification    */
/* notices.  This file is intended only for Biostructure internal */
/* development and should likely be replaced by #includes of the  */
/* actual appropriate AVS header files. 94Feb24jsp.		  */

typedef struct _GEOMvert_list {
   int  alloced_size;
   int  n;
   float *l;
} GEOMvert_list, GEOMscalar_list; /* These are the same. but treated differently*/

typedef struct _GEOMint_list {
   int  alloced_size;
   int  n;
   int *l;
} GEOMint_list;

typedef struct _GEOMchar_list {
   int  alloced_size;
   int  n;
   char **l;
} GEOMchar_list;

typedef struct _GEOMplist_list {
   int  alloced_size;
   int  nps, nvs;       /* Number of polygons and number of vert indicies */
   int *l;              /* Compacted array of both (zero terminated) */
} GEOMp_list;

typedef struct _GEOMsphere {
   GEOMvert_list verts;
   GEOMscalar_list radii;
   GEOMvert_list colors;
   GEOMvert_list normals; /* Perhaps useful later on for point clouds?*/
   GEOMint_list vdata;
   GEOMscalar_list vtrans;
} GEOMsphere;

typedef struct _GEOMmesh {
   int          m,n;    /* Data is same for lines or polytriangles */
   GEOMvert_list verts;
   GEOMvert_list normals;
   GEOMvert_list colors;
   GEOMscalar_list uvs;
   GEOMint_list vdata;
   GEOMint_list pdata;
   GEOMscalar_list vtrans;
} GEOMmesh;


typedef struct _GEOMpolytri {
   int npts;               /* Number of polytris */
   GEOMvert_list *ptverts; /* Polytriangle data */
   GEOMvert_list *ptcolors;
   GEOMvert_list *ptnormals;
   GEOMscalar_list *ptuvs;
   int npls;               /* Number of polylines */
   GEOMvert_list *plverts; /* Polyline data */
   GEOMvert_list *plcolors;
   GEOMvert_list dlverts; /* Disjoint line data */
   GEOMvert_list dlcolors;

   /* User defined data for polytris, polylines, disjoint lines */
   GEOMint_list *ptvdata;
   GEOMint_list *ptpdata;
   GEOMint_list *plvdata;
   GEOMint_list *plpdata;
   GEOMint_list dlvdata;
   GEOMint_list dlpdata;
   GEOMscalar_list *ptvtrans;
} GEOMpolytri;

typedef struct _GEOMlabel {
   int lflags;
   GEOMchar_list labels;        /* Character strings themselves */
   GEOMvert_list verts;         /* Locations of label strings */
   GEOMvert_list offsets;       /* Offsets of label strings from point */
   GEOMvert_list colors;        /* Color of string */
   GEOMscalar_list heights;
   GEOMint_list vflags;
} GEOMlabel;

typedef struct _GEOMpolyh {
   GEOMvert_list verts;
   GEOMvert_list normals;
   GEOMvert_list colors;
   GEOMscalar_list uvs;
   GEOMp_list   ptlist;
   GEOMint_list vdata;
   GEOMint_list pdata;
   GEOMscalar_list vtrans;
} GEOMpolyh;

typedef struct _GEOMval {
   int  type;
   int  size; /* Number of bytes of extra data following this struct */
   union {
      int       i;
      float     f;
      unsigned  long c;
      int       data[1];
   } d;
} GEOMval;

typedef struct _GEOMobj {
   int  type; /* Object type */
   int  data; /* Vertex data that this object has (normals and vertices) */
   float extent[6];
   int   has_extent;
   char  *name, *filename;
   char  *groupname;
   GEOMval *vals;       /* Pointer to a list of name/value pairs */
   int  nvals;
   union {      /* An objects internal bits */
      GEOMmesh m;
      GEOMpolyh ph;
      GEOMpolytri pt;
      GEOMsphere sp;
      GEOMlabel la;
   } d;
   int  refcnt;
} GEOMobj;


typedef struct _GEOMedit {
  int type;
  char *data;
  char *name;
  int size; /* If it is a generic value, this is valid */
  struct _GEOMedit *next;
} GEOMedit;

typedef struct _GEOMedit_list {
   GEOMedit *l;
} *GEOMedit_list;





#define PH(A)   ((A)->d.ph)
#define PT(A)   ((A)->d.pt)
#define MSH(A)  ((A)->d.m)
#define SP(A)   ((A)->d.sp)
#define LA(A)   ((A)->d.la)

/*** structures for receiving picking information from the geometry viewer  ***/


typedef struct _upstream_geom {
   int flags;           /* Button state, and selection mode */
   char current_obj[256];/* Object whose selection mode set (coords are in
                            the coordinate system of this object but vertices
                            are defined for "picked obj" */
   float mscoord[3];    /* Modelling space coordinates  */
   float wscoord[3];    /* World space coordinates      */
   float sscoord[3];    /* Screen space coordinates     */
   float objxform[4][4]; /* Object's coordinate matrix */
   float worldxform[4][4]; /* From modelling space to world space */
   float viewxform[4][4]; /* From world space to screen space */

   int x, y;            /* Button x, y               */
   int width, height;   /* window width,height       */
   int camera_index;    /* Index of the view selection was made */

   char picked_obj[256]; /* Name of object whose vertex was picked */
   float vertex[3];     /* nearest vertex to selection */
   int vdata;           /* per-vertex data -- user specified */
   int odata;           /* per-object (line,poly,sphere) data */
} upstream_geom;

typedef struct _upstream_transform {
   int flags;           /* Button state              */
   float msxform[4][4]; /* Modelling space transform */
   char object_name[256]; /* Current object          */
   int camera_index;    /* View transformation is in */
   int button;          /* Button pressed            */
   int x, y;            /* Button x, y               */
   int width, height;   /* window width,height       */
} upstream_transform;

struct Xavs_List_Rec {
    GEOMpolyh           *   g   ;
    struct Xavs_List_Rec*   next;
};
typedef struct Xavs_List_Rec Xavs_A_List;
typedef struct Xavs_List_Rec * Xavs_List;

#define AVS_TYPE_BYTE		0  /*_F77_s: ATBYTE */
#define AVS_TYPE_INTEGER	1  /*_F77_s: ATINT  */
#define AVS_TYPE_REAL		2  /*_F77_s: ATREAL */
#define AVS_TYPE_DOUBLE		3  /*_F77_s: ATDUBL */
#define AVS_TYPE_SHORT		4  /*_F77_s: ATSHRT */

/* Stuff added 94Aug09 to support passing fields: */
typedef struct {
   int ndim;			/* Number of dimensions in the field */
   int nspace;			/* Number of physical coordinates per point */
   int veclen;			/* number of components at each point */
   int type;			/* data type (see below for values) */
   int size;			/* size of each element */
   int single_block;		/* internal, 1 if field is a single malloc */
				/* 2 if using shared memory */
   int uniform;			/* UNIFORM, RECTILINEAR, or IRREGULAR */
   int flags;                   /* internal, data validity flags */
   int *dimensions;		/* dimension along each axis, len is ndim */
   float *points;		/* real-world coords for non-uniform fields */
   short *data;			/* the field itself as chars */
   float *min_extent;		/* range of the data, len is nspace */
   float *max_extent;		/* range of the data, len is nspace */
   char  *labels;		/* labels for each component */
   short *minimum;   		/* minimum data values for each component */
   short *maximum;   		/* maximum data values for each component */
   int shm_key;			/* shared memory key */
   int shm_id;			/* shared memory identifier */
   char *shm_base;		/* shared memory base address */
   char  *units;		/* units for each component */
   int shm_size;		/* shared memory segment size */
   int mesh_id;			/* unique id for the "points" information */
   int refcnt;			/* how many "allocations" of this field */
} AVSfield_short;
