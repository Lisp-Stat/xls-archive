/* {{{ xavs.c -- AVS: Skandha4 interface to AVS system.			*/

/* This file is formatted for use with folding.el for emacs, sort	*/
/* of an outline-mode for programmers, ftp-able from elisp archives	*/
/* such as tut.cis.ohio-state.edu (128.146.8.52).  If you don't use	*/
/* folding-mode and/or emacs, you may want to prepare a table of	*/
/* contents for this file by doing "grep '{{{' thisfile.c".		*/

/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xavs.h
* Description:  AVS: Skandha4 interface to AVS.
* Author:       Jeff Prothero
* Created:      94Feb24
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
* See slisp/SLISPCOPYING for distribution information

********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLINIT_C_GLOBALS
extern void xavs_Init();			/*jfb*/
#endif

#ifdef MODULE_XLINIT_C_XLINIT
/* code to be executed on startup  */
xavs_Init();					/*jfb*/
#endif

#ifdef MODULE_XLDMEM_H_GLOBALS
extern LVAL xavs13_Avs_To_Thinglist_Fn();
extern LVAL xavs23_Thinglist_To_Avs_Fn();
extern LVAL xavs33_Avs_Print_Fn();
extern LVAL xavs48_Voxels_To_Avs_Fn();
#endif



#ifdef MODULE_XLOBJ_C_GLOBALS

#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	"XAVS-AVS->THINGLIST",	xavs13_Avs_To_Thinglist_Fn	)
DEFINE_SUBR(	"XAVS-THINGLIST->AVS",	xavs23_Thinglist_To_Avs_Fn	)
DEFINE_SUBR(	"XAVS-AVS-PRINT",	xavs33_Avs_Print_Fn		)
DEFINE_SUBR(	"XAVS-VOXELS->AVS",	xavs48_Voxels_To_Avs_Fn		)
#endif


#ifdef MODULE_XLOBJ_C_OBSYMBOLS
#endif



/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/


/* }}} */
