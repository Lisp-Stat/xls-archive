/* {{{ xetc.c -- ET Cetera: Fns etc that didn't fit elsewhere.		*/

/* This file is formatted for use with folding.el for emacs, sort	*/
/* of an outline-mode for programmers, ftp-able from elisp archives	*/
/* such as tut.cis.ohio-state.edu (128.146.8.52).  If you don't use	*/
/* folding-mode and/or emacs, you may want to prepare a table of	*/
/* contents for this file by doing "grep '{{{' thisfile.c".		*/

/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xetc.h
* Description:  ET Cetera ... some fns etc that didn't fit nicely elsewhere.
* Author:       Jeff Prothero
* Created:      92Jan22
* Modified:     Jim Brinkley (jfb)   
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
* See slisp/SLISPCOPYING for distribution information

********************************************************************************
*/

/* }}} */

#ifdef MODULE_XLINIT_C_GLOBALS
extern void xetc_Init();			/*jfb*/
#endif

#ifdef MODULE_XLINIT_C_XLINIT
/* code to be executed on startup  */
xetc_Init();					/*jfb*/
#endif

#ifdef MODULE_XLDMEM_H_GLOBALS
extern LVAL xetc03_Load_Library_Fn();
extern LVAL xetc11_Time_Fn();
extern LVAL xosenvget(); /* from Niels Mayer's unixstuff.c */
extern LVAL xetc_copying();
extern LVAL xetc_set_server_delimiters();

/* Expand small fixnum range to include screen coords: */
/* Standard 2.1 values were: */
/*#define SFIXMIN		(-128)*/
/*#define SFIXMAX		255   */
/*#define SFIXSIZE		384   */
#undef SFIXMIN
#undef SFIXMAX
#undef SFIXSIZE
#define SFIXMIN	      (-128)
#define SFIXMAX	       2047
#define SFIXSIZE       2176

#ifndef EXTERNED_S_STAR_ERRMSG_STAR
extern LVAL s_star_errmsg_star;/* Symbol "*errmsg*" */
#define EXTERNED_S_STAR_ERRMSG_STAR
#endif


#endif

#ifdef MODULE_XLISP_C_MAIN
    /* Export argc, argv for drivers looking for -term=iris4d and such: */
    {   extern int    xlArgC;
        extern char** xlArgV;
	xlArgC = argc;
	xlArgV = argv;
    }
#endif



#ifdef MODULE_XLOBJ_C_GLOBALS

#ifndef DEFINED_S_STAR_ERRMSG_STAR
LVAL s_star_errmsg_star;
#define DEFINED_S_STAR_ERRMSG_STAR
#endif

#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	"LOAD-LIBRARY",	xetc03_Load_Library_Fn	)
DEFINE_SUBR(	"XETC-TIME",	xetc11_Time_Fn		)
DEFINE_SUBR(	"XETC-GETENV",	xosenvget		)
DEFINE_SUBR(	"COPYING",	xetc_copying		)
DEFINE_SUBR(	"XETC-SET-SERVER-DELIMITERS", xetc_set_server_delimiters)
#endif


#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_S_STAR_ERRMSG_STAR
    s_star_errmsg_star = xlenter("*ERRMSG*");
    setvalue(s_star_errmsg_star,NIL);
#define CREATED_S_STAR_ERRMSG_STAR
#endif
#endif



/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/


/* }}} */
