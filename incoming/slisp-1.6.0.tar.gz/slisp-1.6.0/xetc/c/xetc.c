/* {{{ xetc.c -- ET Cetera: Fns etc that didn't fit elsewhere.		*/

/* This file is formatted for use with folding.el for emacs, sort	*/
/* of an outline-mode for programmers, ftp-able from elisp archives	*/
/* such as tut.cis.ohio-state.edu (128.146.8.52).  If you don't use	*/
/* folding-mode and/or emacs, you may want to prepare a table of	*/
/* contents for this file by doing "grep '{{{' thisfile.c".		*/

/* -*-C-*-                                                                   CrT
********************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jan22
* Modified:     Jim Brinkley (jfb)   
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
* See slisp/SLISPCOPYING for distribution information
********************************************************************************
*/

/************************************************************************/
/*                              history                                 */
/*									*/
/* Mon Nov 29 18:16:02 PST 1993 jfb Added global variable *XLPATH*	*/
/*    which is initially set to XLPATH, then searched by 		*/
/*    (load-library), thereby allowing the search path to be changed    */
/*    at the lisp level							*/
/* 92Jan22 jsp: Created.						*/
/************************************************************************/

#include "../../xcore/c/xlisp.h"

/* }}} */

/* {{{ Header stuff							*/

#include <string.h>
#include <ctype.h>
#include "netseval.h"

/* Dave Betz' getenv macro conflicts with the unix fn we need so: */
#undef getenv

#ifndef loop
#define loop for(;;)
#endif

/* Maximum supported length for XLPATH: */
#define XETC01_PATH_MAX (8192)

char** xlArgV;
int    xlArgC;

/* Server  delimiters					 */  /* jfb*/
int server_end=SN_DEFAULT_END;
int server_data=SN_DEFAULT_DATA;
extern LVAL true;


/* }}} */
/* {{{ xetc_Init -- Start-of-world initialization.			*/

xetc_Init() {

    /********************************************************************/
    /* Initialize xetc at xlisp startup. Primary purpose is to set the  */
    /* global variable *xlpath* from the environment  variable XLPATH.  */
    /* This variable is used by load-library to search for a file to    */
    /* load, and can  be reset from lisp to a new search path           */
    /* Added to xetc by jfb Mon Nov 29 14:47:03 PST 1993	        */
    LVAL pathlist, next, tail, s_xlpath, cell;
    char *path;
    char buf[XETC01_PATH_MAX];
    char *getenv(), *colon;
    int span, nlvals=5;

    static done_init = FALSE;
    if  (done_init)   return;
    else done_init   = TRUE ;

    xlstkcheck(nlvals);
    xlsave(pathlist);
    xlsave(next);
    xlsave(tail);
    xlsave(s_xlpath);
    xlsave(cell);
    /* Enter the global variable *xlpath* into symbol table */
    s_xlpath=xlenter("*XLPATH*");
    setvalue(s_xlpath, NIL);
    /* Get the environment variable XLPATH and return if nil*/
    path = getenv("XLPATH"); 
    if (!path) {
	xlpopn(nlvals);
	return;
    }

    /* Copy path to buffer so it can be trashed */
    if (strlen(path) >= XETC01_PATH_MAX) {
	xlfail("XLPATH exceeds XETC01_PATH_MAX!");
    }
    strcpy(buf, path);
    path     = buf;

    /* Build pathlist */
    pathlist = NIL;
    loop {
        colon = strchr(path, ':');
	span  = (colon==NULL) ? strlen(path) : colon-path;
	path[span]  = '\0';
	cell=cvstring(path);
	next=consa(cell);

	if (pathlist!=NIL) rplacd(tail,next);
	else pathlist = next;

	tail=next;

	if (colon == NULL) break;

	path = colon+1;
    }

    /* Set pathlist to be value of global variable *xlpath*, restore stack */
    setvalue(s_xlpath, pathlist);
    xlpopn(nlvals);
}   

/* }}} */
/* {{{ xetc00_Find_Xlpath_Library -- Locate dir holding file.		*/

char* xetc00_Find_Xlpath_Library(name, fname )
char                            *name,*fname;
{
    /********************************************************************/
    /* Here we search all the directories defined by the value of the   */
    /* variable *XLPATH*, which is initially set by xetcinit to be the  */
    /* value of the environment variable XLPATH, but which can be reset */
    /* from lisp							*/
    /* Each path in the list is prepended to name, and if the file is   */
    /* found the fullpath fname is returned. If no matching file is     */
    /* found the original name is returned.				*/
    /* Modified from the original code of jsp by jfb			*/
    /* 									*/
    /********************************************************************/
    LVAL s_xlpath, nextpath;
    int nlvals=2;
    xetc_Init();	/* We were getting called before xetc_Init() ran. */
    xlstkcheck(nlvals);
    xlsave(s_xlpath);
    xlsave(nextpath);

    /* If *xlpath* is not set a list, just return filename: */
    s_xlpath= getvalue(xlenter("*XLPATH*"));
    if (!consp(s_xlpath)) {
	xlpopn(nlvals);
	return name;
    }

    /* Loop over paths in xlpath: */
    for (nextpath = s_xlpath;   consp(nextpath);   nextpath=cdr(nextpath)) {
	int   new_filename = TRUE;
	FILE* fp;
	char* namep;
        LVAL         lv_fname = car(nextpath);
	if (!stringp(lv_fname))   continue;

	strcpy( fname, (char*)getstring(lv_fname) );
	strcat( fname, "/"  );    namep = fname + strlen(fname);
	strcat( fname, name );

	/* An artifact of PROVIDE is that it uses symbol names, */
	/* which xlisp has mapped to upper case. The least ugly */
	/* solution on unix seems to be to check for lowercase  */
	/* if we don't find uppercase:				*/
	while (new_filename) {

	    /* See if file exists: */
	    FILE* osaopen();
	    if ((fp = osaopen(fname,"r")) != NULL) {
	        osclose(fp);
		xlpopn(nlvals);
	        return fname;
	    }

	    new_filename = FALSE;

	    /* Think about forcing 'name' to lowercase: */
	    for ( ;   *namep;   ++namep) {
	        if (isupper( *namep )) {
		    *namep       = tolower( *namep );
		    new_filename = TRUE;
	    }	}

	    /* Think about appending ".lsp" to 'name': */
	    if (!new_filename   &&
		strcmp( fname + strlen(fname)-4,  ".lsp" )
	    ) {
	        strcat( fname, ".lsp" );
		new_filename = TRUE;
	    }
	}
    }
    xlpopn(nlvals);
    return name;
}

/* }}} */
/* {{{ xetc01_Load_Library -- Load a library from dir in XLPATH.	*/

LVAL xetc01_Load_Library( name, vflag, pflag, fn )
char*			  name;
int				vflag, pflag;
LVAL					    (*fn)();
{
    extern LVAL true;
    char *path;
    char *getenv();
    char fname[ XETC01_PATH_MAX ];

    /* The references to '/' are unix-specific, of course.  One would */
    /* have to hack a bit to make this portable to dos, vms etc.      */
    /* jfb Replaced getenv XLPATH with global var *xlpath* set in xetcinit */
    if (name[0] != '/') {     
	/* Expand name to full pathname if found */
	/* in XLPATH, stored in fname[]:  */
        name = (char*)xetc00_Find_Xlpath_Library(name, fname );   
    }
    /* load the file */
    return ((*fn)(name,vflag,pflag)!=NIL ? true : NIL);
}

LVAL xetc02_Load_Library( name, vflag, pflag )
char*		 	  name;
int				vflag, pflag;
{
    extern int  xlload();
    return xetc01_Load_Library( name, vflag, pflag, xlload );
}

LVAL xetc03_Load_Library_Fn()
/*-
    Load a lisp library file from a directory in XLPATH.
-*/
{
    /* This fn is line-for-line the same as xlsys.c:xload(),    */
    /* except for 'xlload' being changed to xetc01_Load_Library */
    /* in the very last line.					*/

    extern LVAL true;
    extern LVAL k_verbose;   /* Keyword ":verbose" */
    extern LVAL k_print;     /* Keyword ":print"   */
    extern LVAL xlgetfname();
    char *name;
    int vflag,pflag;
    LVAL arg;

    /* get the file name */
    name = (char*)getstring(xlgetfname());

    /* get the :verbose flag */
    if (xlgetkeyarg(k_verbose,&arg)) 	vflag = (arg != NIL);
    else				vflag = TRUE;

    /* get the :print flag */
    if (xlgetkeyarg(k_print,&arg)) 	pflag = (arg != NIL);
    else				pflag = FALSE;

    /* load the file */
    return xetc02_Load_Library(name,vflag,pflag);
}

/* }}} */
/* {{{ xetc11_Time_Fn -- Return time in secs since Jan 1 1970 GMT.	*/

#include <sys/types.h>

time_t xetc10_Time()
{
    time_t t = time(NULL);
    return t;
}

LVAL xetc11_Time_Fn()
{
    xllastarg();
    return cvfixnum( xetc10_Time() );
}

/* }}} */

/* {{{ xetc_copying -- Print copyright information			*/
LVAL xetc_copying()
{
    xllastarg();
    stdputstr("Copyright (c) 1994 Digital Anatomist Program\n");
    stdputstr("University of Washington, Seattle USA\n");
    stdputstr("Based on XLISP version 2.1, Copyright (c) 1989\n");
    stdputstr("by David Betz\n");
    stdputstr("If you have the source code, see slisp/SLISPCOPYING\n");
    stdputstr("for more details\n");
    return(true);
}
/* }}} */

/* {{{ xetc_set_server_delimiters-- Set server data and end		*/
LVAL xetc_set_server_delimiters()
{
    LVAL lchar;
    lchar = xlgafixnum();
    server_data = getfixnum(lchar);
    lchar = xlgafixnum();
    server_end = getfixnum(lchar);
    return(true);
}

/* }}} */
/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/


/* }}} */

