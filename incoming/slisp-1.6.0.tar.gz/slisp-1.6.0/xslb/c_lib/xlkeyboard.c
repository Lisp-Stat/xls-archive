/* xlkeyboard.c

   Fran Taylor, HITL, Seattle

   non-blocking stream I/O for Xlisp */

#include <termios.h>
#include <sys/types.h>
#include <sys/time.h>

#include "xlisp.h"

#define BSIZ 1

extern LVAL true;

static long stdin_lflag, stdin_iflag, stdin_cflag;

LVAL xlnoecho();
LVAL xlecho();
LVAL xllisten();
LVAL xlnoecho();
LVAL xlread_char_no_hang();
LVAL xlclear_input();

void asynch_install_prims()
{
  DEFINE_SUBR("ECHO-OFF", xlnoecho);
  DEFINE_SUBR("ECHO-ON", xlecho);
  DEFINE_SUBR("LISTEN", xllisten);
  DEFINE_SUBR("READ-CHAR-NO-HANG", xlread_char_no_hang);
  DEFINE_SUBR("CLEAR-INPUT", xlclear_input);
}

/* turn off echo and canonical input processing */

static int noecho(fd)
int fd;
{
  struct termios t;
  int i;

  if (tcgetattr(fd, &t) < 0)
    return -1;

  /* turn off XON/XOFF processing, CR-NL translation, 
     input character signals, echo, input processing */

  t.c_iflag &= ~(IXON | ICRNL);
  t.c_lflag &= ~(ISIG | ICANON | ECHO);

  /* set VMIN and VTIME */

  t.c_cc[VMIN] = 0;
  t.c_cc[VTIME] = 0;

  /* store the termios structure */

  if (tcsetattr(fd, TCSANOW, &t) < 0)
  {
    perror("tcsetattr");
    return -1;
  }
  return 0;
}

static int yesecho(fd)
int fd;
{
  struct termios t;

  if (tcgetattr(fd, &t) < 0)
    return -1;

  /* turn on XON/XOFF processing, CR-NL translation, 
     input character signals, echo, input processing */

  t.c_iflag |= IXON | ICRNL;
  t.c_lflag |= ISIG | ICANON | ECHO;

  /* set VEOF and VEOL */
  
  t.c_cc[VEOF] = CEOF;
  t.c_cc[VEOL] = '\0';

  /* store the termios structure */

  if (tcsetattr(fd, TCSANOW, &t) < 0)
    return -1;
  return 0;
}

/* we use select here, which is not POSIX compliant, but there's
   really no other way to do it! */

static input_waiting(fd)
int fd;
{
  fd_set fdset;
  struct timeval tm;
  int n;

  FD_ZERO(&fdset);
  FD_SET(fd, &fdset);
  tm.tv_sec = tm.tv_usec = 0;

  n = select(FD_SETSIZE, &fdset, NULL, NULL, &tm);

  if ((n == -1) || (n == 0))
    return 0;  
  return 1;
}

LVAL xlnoecho()
{
  int fd;

  if (moreargs())
    fd = fileno(getfile(xlgastream()));
  else
    fd = fileno(stdin);
  xllastarg();

  if (noecho(fd) == -1)
    return NIL;
  return true;
}

/* turn on echo and canonical input processing */

LVAL xlecho()
{
  int fd;

  if (moreargs())
    fd = fileno(getfile(xlgastream()));
  else
    fd = fileno(stdin);
  xllastarg();

  if (yesecho(fd) == -1)
    return NIL;
  return true;
}

LVAL xllisten()
{
  LVAL avail;
  int fd, n;
  char buf;

  if (moreargs())
    fd = fileno(getfile(xlgastream()));
  else
    fd = fileno(stdin);
  xllastarg();
    
  if (input_waiting(fd))
    return true;  
  return NIL;
}

LVAL xlread_char_no_hang()
{
  char buf;
  int fd, n;

  if (moreargs())
    fd = fileno(getfile(xlgastream()));
  else
    fd = fileno(stdin);
  xllastarg();
   
  if ((n = read(fd, &buf, 1)) > 0)
  {
    n = buf;
    return cvchar(n);
  }
  else
    return NIL;
}

LVAL xlclear_input()
{
  int fd;

  if (moreargs())
    fd = fileno(getfile(xlgastream()));
  else
    fd = fileno(stdin);
  xllastarg();

  tcflush(fd, TCIFLUSH);
  return NIL;
}
