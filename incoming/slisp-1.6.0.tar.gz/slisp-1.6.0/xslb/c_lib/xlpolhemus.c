/* xlpolhemus.c

   by Fran Taylor, at the HITLab, Seattle

   Copyright (C) 1992  Human Interface Technology Lab, Seattle

   Xlisp interface to Polhemus

   This code by default does NO error checking, for speed,
   If you want full error checking, compile with -DDEBUG */

/* PROACTIVE additions by Andrew MacDonald */

#include <stdio.h>
#include <math.h>

#include "xlisp.h"
#include "xlsensor.h"
#include "seriallib.h"

extern char *sys_errlist[];

#define TIMEOUT 2 /* be a sport */

/* private flags */

#define ORIGIN 1

#define BSIZ 132

#define pol_int_value(buf, n) ((short) ((buf)[(n)] | ((buf)[(n)+1] << 8)))

#define pol_disp_value(buf, n) (((float) pol_int_value(buf, n)) * \
				0.000050245)

#define pol_quat_value(buf, n) (((float) pol_int_value(buf, n)) / 32767.0)

void polhemus_init(void);
int polhemus_open(char *port, int speed, char *config);
LVAL polhemus_put(int fd, int n);
LVAL polhemus_get();
LVAL polhemus_data_descriptor();
LVAL polhemus_read();
int polhemus_close();

static void get_polhemus(int fd, unsigned char *buf);
#ifdef PROACTIVE
static void prime_polhemus(int fd);
static void flush_polhemus(int fd, unsigned char *buf);
#endif
static void get_point(unsigned char *buf, float *x, float *y, float *z);
static void get_quaternion(unsigned char *buf, float *qw, float *qx, float *qy, float *qz);

sensor_object polhemus =
{
  "Polhemus", polhemus_init, polhemus_open, polhemus_get, polhemus_put, 
  polhemus_data_descriptor, polhemus_read, polhemus_close, NIL, NULL};

static void get_polhemus(fd, buf)
int fd;
unsigned char *buf;
{
  int n;

  serial_vmin(fd, 17);
  if (serial_write(fd, "P", 1) < 0)
      xlstr_error("Polhemus Data Read Command Write Error: ");
  if ((n = serial_timeout_read(fd, buf, 17, TIMEOUT)) != 17)
      xlnstr_error("Polhemus Data Read Error (%d of 17 bytes read): ", n);

#ifdef DEBUG
  if ((buf[1] != '1') || (buf[2] != ' '))
    xlerror("Garbled Data From Polhemus", s_unbound);
#endif
}

#ifdef PROACTIVE
static void prime_polhemus(fd)
int fd;
{
  serial_vmin(fd, 17);
  if (serial_write(fd, "P", 1) < 0)
      xlstr_error("Polhemus Data Read Command (Priming) Write Error: ");
}

static void flush_polhemus(fd,buf)
int fd;
unsigned char *buf;
{
  int n;

  if ((n = serial_timeout_read(fd, buf, 17, TIMEOUT)) != 17)
      xlnstr_error("Polhemus Data Read Error (%d of 17 bytes read): ", n);

#ifdef DEBUG
  if ((buf[1] != '1') || (buf[2] != ' '))
    xlerror("Garbled Data From Polhemus", s_unbound);
#endif
}
#endif /* PROACTIVE */

static void get_point(buf, x, y, z)
unsigned char *buf;
float *x, *y, *z;
{
  *x = pol_disp_value(buf, 3);
  *y = pol_disp_value(buf, 5);
  *z = pol_disp_value(buf, 7);
}

static void get_quaternion(buf, qw, qx, qy, qz)
unsigned char *buf;
float *qw, *qx, *qy, *qz;
{
  *qw = pol_quat_value(buf, 9);
  *qx = pol_quat_value(buf, 11);
  *qy = pol_quat_value(buf, 13);
  *qz = pol_quat_value(buf, 15);
}

void polhemus_init()
{
  LVAL r, s;
  xlstkcheck(3);
  xlsave(r);
  xlsave(s);
  xlsave(polhemus.speed_list);

  polhemus.speed_list = xlenter("POLHEMUS-SPEED-LIST");
  setvalue(polhemus.speed_list, r = cons_fixnum(300));
  rplacd(r, s = cons_fixnum(1200));
  rplacd(s, r = cons_fixnum(2400));
  rplacd(r, s = cons_fixnum(4800));
  rplacd(s, r = cons_fixnum(9600));
  rplacd(r, s = cons_fixnum(19200));
  polhemus.symbol = xlenter("POLHEMUS");

  xlpopn(3);
}

int polhemus_open(port, speed, config)
char *port;
int speed;
char *config;
{
  int fd, n;
  unsigned char buf[BSIZ];
  LVAL lst, s, t;
  FILE *f;

  /* open the port and initialize the device */

  if ((fd = serial_open(port, speed, 8, 1, TIMEOUT)) < 0)
    xlstr_error("Polhemus Port Open Error: ");

  if (serial_write(fd, "fUO2,11\r", 8) != 8)
    xlstr_error("Polhemus Initialize Command Write Error: ");

  /* safe sex with lisp */

  xlstkcheck(4);
  xlsave(t);
  xlsave(s);
  xlsave(s_instances[fd].parameter_list);
  xlsave(s_instances[fd].available_results);

  /* the parameter list */

  s_instances[fd].parameter_list = xlenter("POLHEMUS-PARAMETER-LIST");
  setvalue(s_instances[fd].parameter_list, s = consa(s_hemisphere));
  rplacd(s, t = consa(s_boresight));
  rplacd(t, s = consa(s_unboresight));
  rplacd(s, t = consa(s_origin));
  rplacd(t, s = consa(s_reset_origin));
  
  /* the output specifier list */

  s_instances[fd].available_results = xlenter("POLHEMUS-OUTPUT-LIST");
  setvalue(s_instances[fd].available_results, s = consa(type_point));
  rplacd(s, t = consa(type_quaternion));
  rplacd(t, s = consa(type_pt_quaternion));
  rplacd(s, t = consa(type_matrix));

  /* take it off after you're done */

  xlpopn(4);
  return fd;  
}

LVAL polhemus_put(fd, n)
int fd;
int n;
{
  int x, y, z;
  unsigned char buf[80];
  LVAL param, val;
  int i;

  xlstkcheck(2);
  xlsave(param);
  xlsave(val);

#ifdef PROACTIVE
  /* get rid of stale data, emptying the serial line so get_polhemus
     will work for origining and boresighting */
  flush_polhemus(fd,buf);
#endif

  i = obj[n].val_index;
  if ((param = xlgasymbol()) == s_hemisphere)
  {
    if ((val = xlgasymbol()) == hemisphere_forward)
    {
      x = 1;
      y = z = 0;
    }
    else if (val == hemisphere_aft)
    {
      x = -1;
      y = z = 0;
    }
    else if (val == hemisphere_upper)
    {
      x = y = 0;
      z = 1;
    }
    else if (val == hemisphere_lower)
    {
      x = y = 0;
      z = -1;
    }
    else if (val == hemisphere_left)
    {
      x = z = 0;
      y = -1;
    }
    else if (val == hemisphere_right)
    {
      x = z = 0;
      y = 1;
    }
    else
      xlerror("Illegal hemisphere", val);

    /* write the hemisphere command to the Polhemus */

    sprintf(buf, "H1,%d,%d,%d\r", x, y, z);
    if (serial_write(fd, buf, strlen(buf)) != strlen(buf))
      xlstr_error("Polhemus Hemisphere Command Write Error: ");
    obj[n].hemisphere = val;
  }

  else if (param == s_boresight)
  {
    if (moreargs())
    {
      LVAL q;
      xlsave1(q);
      q = xlgavector();
      xllastarg();
      pull_quaternion(q, &(s_instances[fd].Qw[i]), &(s_instances[fd].Qx[i]),
		      &(s_instances[fd].Qy[i]), &(s_instances[fd].Qz[i]));
      xlpop();
    }
    else
    {
      unsigned char buf[BSIZ];

      get_polhemus(fd, buf);
      get_quaternion(buf, &(s_instances[fd].Qw[i]), &(s_instances[fd].Qx[i]),
		     &(s_instances[fd].Qy[i]), &(s_instances[fd].Qz[i]));
    }
    s_instances[fd].boresight_flags |= (1 << i);
  }

  else if (param == s_unboresight)
  {
    s_instances[fd].boresight_flags &= ~(1 << i);
    s_instances[fd].Qw[i] = s_instances[fd].Qx[i] = 0.0;
    s_instances[fd].Qy[i] = s_instances[fd].Qz[i] = 0.0;
  }
  else if (param == s_origin)
  {
    if (moreargs())
    {
      LVAL p;
      xlsave1(p);
      p = xlgavector();
      xllastarg();
      pull_point(p, &(s_instances[fd].x[i]), &(s_instances[fd].y[i]), 
		 &(s_instances[fd].z[i]));
      xlpop();
    }
    else
    {
      unsigned char buf[BSIZ];
      get_polhemus(fd, buf);
      get_point(buf, &(s_instances[fd].x[i]), &(s_instances[fd].y[i]), 
		&(s_instances[fd].z[i]));
    }
    s_instances[fd].origin_flags |= (1 << i);
  }
  else if (param == s_reset_origin)
  {
    xllastarg();
    s_instances[fd].x[i] = s_instances[fd].y[i] = s_instances[fd].z[i] = 0.0;
    s_instances[fd].origin_flags &= ~(1 << i);
  }
  else
    xlerror("Illegal parameter", param);
  xlpopn(2);

#ifdef PROACTIVE
  /* reprime buffer */
  prime_polhemus(fd);
#endif

  return true;
}

LVAL polhemus_get(n)
int n;
{
  int fd;
  LVAL arg2;

  if (n > FD_SETSIZE)
  {
    /* this is a data output descriptor */

    n -= FD_SETSIZE;
    fd = obj[n].fd;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_hemisphere)
      return obj[n].hemisphere;
    else if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else
      xlerror("Illegal symbol for data output descriptor", arg2);
  }
  else
  {
   /* this is a file descriptor */
    
    fd = n;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else if (arg2 == type_list)
      return s_instances[fd].available_results;
    else if (arg2 == s_no_sensors)
      return cvfixnum(1);
    else
      xlerror("Illegal symbol for file descriptor", arg2);
  }
  return true;
}

LVAL polhemus_data_descriptor(fd)
int fd;
{
  LVAL type;
  int ind, n;

  type = xlgasymbol();
  if (memberx(type, xleval(s_instances[fd].available_results)) == FALSE)
    xlerror("Illegal output type requested", type);

  if (moreargs())
    ind = getfixnum(xlgafixnum());
  else
    ind = 1;
  xllastarg();

  if (ind != 1)
    xlerror("Illegal index", cvfixnum(ind));

  /* pick out a data descriptor slot */
  
  if ((n = find_empty_obj()) == -1)
    xlerror("Out of data descriptors", s_unbound);
  
  /* add this item to the list of things that we ask the device for */

  obj[n].fd = fd;
  obj[n].read = (s_instances[fd].obj)->read;
  obj[n].value_type = type;
  obj[n].val_index = ind;
  obj[n].hemisphere = hemisphere_forward;

#ifdef PROACTIVE
  /* ask for data, so that it will be around when we read */
  prime_polhemus(fd);
#endif

  return cvfixnum(n + FD_SETSIZE);
}

/* this function should be all-out speed optimized! */

LVAL polhemus_read(n, where)
int n;
LVAL where;
{
  unsigned char buf[20];
  int fd;
  LVAL value_type;
  float x, y, z, qw, qx, qy, qz;

  value_type = obj[n].value_type;
  fd = obj[n].fd;
    
#ifndef PROACTIVE
  get_polhemus(fd, buf);
#else
  /* get data from last request and request some more */
  flush_polhemus(fd, buf);
  prime_polhemus(fd);
#endif

  if ((value_type == type_point) || (value_type == type_pt_quaternion) ||
      (value_type == type_matrix))
  {
    int i;
    i = obj[n].val_index;
    get_point(buf, &x, &y, &z);
    if (s_instances[fd].origin_flags & (1 << i))
      concatenate_translations(&x, &y, &z, x, y, z, 
			       -s_instances[fd].x[i], 
			       -s_instances[fd].y[i], 
			       -s_instances[fd].z[i]);
  }
  if ((value_type == type_quaternion) || (value_type == type_pt_quaternion) ||
      (value_type == type_matrix))
  {
    int i;
    i = obj[n].val_index;
    get_quaternion(buf, &qw, &qx, &qy, &qz);
    if (s_instances[fd].boresight_flags & (1 << i))
      concatenate_quaternions(&qw, &qx, &qy, &qz, qw, qx, qy, qz,
			      -s_instances[fd].Qw[i], s_instances[fd].Qx[i], 
			      s_instances[fd].Qy[i], s_instances[fd].Qz[i]);
  }

  if (value_type == type_point)
    stuff_point(where, x, y, z);
  else if (value_type == type_quaternion)
    stuff_quaternion(where, qw, qx, qy, qz);
  else if (value_type == type_pt_quaternion)
    stuff_pt_quaternion(where, qw, qx, qy, qz, x, y, z);
  else if (value_type == type_matrix)
    stuff_matrix(where, qw, qx, qy, qz, x, y, z);
  else
    xlerror("Illegal result type specified", value_type);

  return where;
}

int polhemus_close(fd)
{
  s_instances[fd].obj = NULL;
  s_instances[fd].device = NIL;
  s_instances[fd].parameter_list = NIL;
  s_instances[fd].available_results = NIL;
  return close(fd);
}

