/* xlknobs.c

   by Fran Taylor, at the HITLab, Seattle

   Copyright (C) 1992  Human Interface Technology Lab, Seattle

   Xlisp interface to Spectragraphics knob box

   This code by default does NO error checking, for speed,
   If you want full error checking, compile with -DDEBUG */

#include <stdio.h>
#include <math.h>

#include "xlisp.h"
#include "xlsensor.h"
#include "seriallib.h"

extern char *sys_errlist[];

#define TIMEOUT 2 /* be a sport */

#define BSIZ 132

#define knob_int_value(buf, n) ((short) ((buf)[(n)] | ((buf)[(n)+1] << 8)))

#define knob_value(buf, n) (((float) pol_int_value(buf, n)) * \
				0.000050245)

int knobs_open();
void knobs_init();
int knobs_open();
LVAL knobs_get();
LVAL knobs_put();
LVAL knobs_data_descriptor();
LVAL knobs_read();
int knobs_close();

sensor_object knobs =
{
  "Knobs", knobs_init, knobs_open, knobs_get, knobs_put, 
  knobs_data_descriptor, knobs_read, knobs_close, NIL, NULL};

#ifdef DEBUG
static knobsp(k)
LVAL k;
{
  int i;
#ifdef HAVE_GETSZ
  if (!vectorp(k) || (getsz(k) != 8))
    return 0;
#endif
  for(i = 0; i < 8; i++)
    if (!floatp(getelement(k, i)))
      return 0;
  return 1;
}
#endif

void knobs_init()
{
  LVAL r, s;
  char buf[80];

  knobs.speed_list = cons_fixnum(300);
  rplacd(knobs.speed_list, s = cons_fixnum(1200));
  rplacd(s, r = cons_fixnum(2400));
  rplacd(r, s = cons_fixnum(4800));
  rplacd(s, r = cons_fixnum(9600));
  rplacd(r, s = cons_fixnum(19200));
  knobs.symbol = xlenter("KNOBS");

}

int knobs_open(port, speed, config)
char *port;
int speed;
char *config;
{
  int fd, n;
  char buf[BSIZ];
  LVAL lst, s, t;
  FILE *f;

  /* open the port */

  if ((fd = serial_open(port, speed, 8, 1, TIMEOUT)) < 0)
    xlstr_error("Knobs Port Open Error: ");

  /* initialize the device */

  if (serial_write(fd, "fUO2,11\r", 8) != 8)
    xlstr_error("Knobs Initialize Command Write Error: ");
  
  /* the parameter list */

  s_instances[fd].parameter_list = NIL;
  
  /* the initial values */

  for(n = 0; n < 8; n++)
    s_instances[fd].knobval[n] = 0;

  /* the output specifier list */

  s_instances[fd].available_results = consa(type_point);
  rplacd(s_instances[fd].available_results, t = consa(type_quaternion));
  rplacd(t, s = consa(type_pt_quaternion));
  rplacd(s, t = consa(type_matrix));
  rplacd(t, s = consa(type_knobs));

  return fd;  
}

LVAL knobs_put(fd, n, param, val)
int fd;
LVAL param, val;
{
  int x, y, z;
  char buf[80];

  if (param == s_boresight)
  {
    /* if value is non-nil, set boresight to current orientation
       if value is nil, reset to default orientation */

    if (val != NIL)
    {
      /* set boresight */

    }
    else
    {
      /* reset boresight */

    }
    return val;
  }
  else
    xlerror("Illegal parameter", param);
}

LVAL knobs_get(n)
int n;
{
  int fd;
  LVAL arg2;

  if (n > FD_SETSIZE)
  {
    /* this is a data output descriptor */

    n -= FD_SETSIZE;
    fd = obj[n].fd;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    xlerror("Illegal symbol for data output descriptor", arg2);
  }
  else
  {
   /* this is a file descriptor */
    
    fd = n;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else if (arg2 == type_list)
      return s_instances[fd].available_results;
    else
      xlerror("Illegal symbol for file descriptor", arg2);
  }
  return true;
}

LVAL knobs_data_descriptor(fd)
int fd;
{
  LVAL type;
  int ind, n;

  type = xlgasymbol();
  if (memberx(type, s_instances[fd].available_results) == FALSE)
    xlerror("Illegal output type requested", type);

  if (moreargs())
    ind = getfixnum(xlgafixnum());
  else
    ind = 1;
  xllastarg();

  if (ind != 1)
    xlerror("Illegal index", cvfixnum(ind));

  /* pick out a data descriptor slot */
  
  if ((n = find_empty_obj()) == -1)
    xlerror("Out of data descriptors", s_unbound);
  
  /* add this item to the list of things that we ask the device for */

  obj[n].fd = fd;
  obj[n].read = (s_instances[fd].obj)->read;
  obj[n].value_type = type;
  obj[n].val_index = 1;
  return cvfixnum(n + FD_SETSIZE);
}

/* this function should be all-out speed optimized! */

LVAL knobs_read(n, where)
int n;
LVAL where;
{
  unsigned char buf[20];
  int fd, done;
  LVAL value_type;

  value_type = obj[fd].value_type;

  /****** read the data from the port ******/

  serial_vmin(fd, 17);


  /* keep going until there's no data left in the port */

  for(done = 0; !done; )
  {
    if ((n = serial_read(fd, buf, 17)) != 17)
      xlnstr_error("Knobs Data Read Error (%d of 17 bytes read): ", n);

#ifdef DEBUG
    if ((buf[0] != '0') || (buf[1] != '1') || (buf[2] != ' '))
      xlerror("Garbled Data From Knob Box", s_unbound);
#endif

    /* format of data retuned: */

    /* update the appropriate knob value */

  }
  
  /***** user wants points *****/

  if (value_type == type_point)
  { 
    float xxx = 0.0;

#ifdef DEBUG
    if (!triplep(where))
      xlerror("Destination must be triple", where);
#endif
    
    v_float(where, 0) = xxx;
    v_float(where, 1) = xxx;
    v_float(where, 2) = xxx;
    return where;
  }

  /****** user wants quaternions ******/

  else if (value_type == type_quaternion)
  {
    LVAL qv;
    float xxx = 0.0;

#ifdef DEBUG
    if (!quaternionp(where))
      xlerror("Destination must be quaternion", where);
#endif

    qv = getelement(where, 1);
    v_float(where, 0) = xxx;
    v_float(qv, 0) =    xxx;
    v_float(qv, 1) =    xxx;
    v_float(qv, 2) =    xxx;
    return where;
  }

  /****** user wants points and quaternions ******/

  else if (value_type == type_pt_quaternion)
  {
    LVAL pt, q, qv;
    float xxx = 0.0;

#ifdef DEBUG
    if (!pt_quatp(where))
      xlerror("Destination must be point-quaternion pair", where);
#endif

    pt = getelement(where, 0);
    q = getelement(where, 1);
    qv = getelement(q, 1);

    v_float(pt, 0) = xxx;
    v_float(pt, 1) = xxx;
    v_float(pt, 2) = xxx;
    
    v_float(q, 0) =  xxx;
    v_float(qv, 0) = xxx;
    v_float(qv, 1) = xxx;
    v_float(qv, 2) = xxx;

    return where;
  }

  /****** user wants matrix ******/

  else if (value_type == type_matrix)
  {
    float xxx = 0.0;

#ifdef DEBUG
    if (!matrixp(where))
      xlerror("Destination must be matrix", where);
#endif

    m_float(where, 0, 0) = 1.0;
    m_float(where, 0, 1) = 0.0;
    m_float(where, 0, 2) = 0.0;
    m_float(where, 0, 3) = 0.0;

    m_float(where, 1, 0) = 0.0;
    m_float(where, 1, 1) = 1.0;
    m_float(where, 1, 2) = 0.0;
    m_float(where, 1, 3) = 0.0;

    m_float(where, 2, 0) = 0.0;
    m_float(where, 2, 1) = 0.0;
    m_float(where, 2, 2) = 1.0;
    m_float(where, 2, 3) = 0.0;
  
    m_float(where, 3, 0) = 0.0;
    m_float(where, 3, 1) = 0.0;
    m_float(where, 3, 2) = 0.0;
    m_float(where, 3, 3) = 1.0;
    return where;
  }

  /***** user wants knob values ******/

  else if (value_type == type_knobs)
  {
    float xxx = 0.0;

#ifdef DEBUG
    if (!knobsp(where))
      xlerror("Destination must be knobs vector", where);
#endif

    v_float(where, 0) = xxx;
    v_float(where, 1) = xxx;
    v_float(where, 2) = xxx;
    v_float(where, 3) = xxx;
    v_float(where, 4) = xxx;
    v_float(where, 5) = xxx;
    v_float(where, 6) = xxx;
    v_float(where, 7) = xxx;
    return where;
  }
  else
    xlerror("Illegal result type specified", value_type);
}

int knobs_close(fd)
{
  s_instances[fd].obj = NULL;
  s_instances[fd].device = NIL;
  s_instances[fd].parameter_list = NIL;
  s_instances[fd].available_results = NIL;
  return close(fd);
}

