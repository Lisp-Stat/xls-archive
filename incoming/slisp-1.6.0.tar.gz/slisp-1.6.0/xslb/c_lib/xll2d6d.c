/* xll2d6d.c

   by Fran Taylor, at the HITLab, Seattle
   
   Copyright (C) 1992  Human Interface Technology Lab, Seattle
   
   Xlisp interface to Logitech 2D/6D mouse
   
   This code by default does NO error checking, for speed,
   If you want full error checking, compile with -DDEBUG */

#include <stdio.h>
#include <math.h>

#include "xlisp.h"
#include "xlsensor.h"
#include "seriallib.h"

extern char *sys_errlist[];

/* our private flags */

#define BORESIGHT 1
#define ORIGIN 2

#define TIMEOUT 2 /* be a sport */

#define BSIZ 132

/* to make the notation neater in l2d6d_read, below */

#define aw obj[n].Qw
#define ax obj[n].Qx
#define ay obj[n].Qy
#define az obj[n].Qz

int l2d6d_open();
void l2d6d_init();
int l2d6d_open();
LVAL l2d6d_get();
LVAL l2d6d_put();
LVAL l2d6d_data_descriptor();
LVAL l2d6d_read();
int l2d6d_close();

sensor_object l2d6d =
{
  "L2d6d", l2d6d_init, l2d6d_open, l2d6d_get, l2d6d_put, 
  l2d6d_data_descriptor, l2d6d_read, l2d6d_close, NIL, NULL};


static float l_disp_value(buf, n)
     char *buf;
     int n;
{
  int i;
  
  i = (((unsigned) buf[n]) << 14) | (((unsigned) buf[n+1]) << 7) |
    ((unsigned) buf[n+2]);
  
  if (i & (1 << 20))
    i |= 0xfff00000;
  
  return (((float) i) / 39370.07874);
}

static float l_quat_value(buf, n)
     char *buf;
     int n;
{
  int i;
  
  i = (((unsigned) buf[n]) << 7) | (((unsigned) buf[n+1]));
  
  if (i & (1 << 13))
    i |= 0xffffe000;
  
  return (((float) i) / 8192.0);
}

static void get_buffer(fd, buf)
int fd;
char *buf;
{
  int n;

  serial_vmin(fd, 18);
  if (serial_write(fd, "*d", 2) < 0)
    xlstr_error("Logitech 2D/6D Write Error: ");
  if ((n = serial_timeout_read(fd, buf, 18, TIMEOUT)) < 0)
    xlnstr_error("Logitech 2D/6D Read Error (read %d bytes of 18)",n);
      
#ifdef DEBUG
  if (!(buf[0] & 0x80))
    xlerror("Logitech 2D/6D Data Garbled", s_unbound);
  for(n = 1; n < 18; n++)
    if (buf[n] & 0x80)
      xlerror("Logitech 2D/6D Data Garbled", s_unbound);
#endif
}

static void get_point(buf, x, y, z)
char *buf;
float *x, *y, *z;
{
  *x = l_disp_value(buf, 1);
  *y = l_disp_value(buf, 4);
  *z = l_disp_value(buf, 7);
}

static void get_quaternion(buf, qw, qx, qy, qz)
char *buf;
float *qw, *qx, *qy, *qz;
{
  *qw = l_quat_value(buf, 10);
  *qx = l_quat_value(buf, 12);
  *qy = l_quat_value(buf, 14);
  *qz = l_quat_value(buf, 16);
}

static void stuff_buttons(where, buf)
LVAL where;
char *buf;
{
  int i;

#ifdef DEBUG
  if (!vectorp(where))
    xlerror("Destination must be vector", where);
#ifdef HAVE_GETSZ
  if (getsz(where) < 4)
    xlerror("Destination vector too small", where);
#endif
#endif

  for(i = 0; i < 4; i++)
    setelement(where, i, cvfixnum((buf[0] >> i) & 0x01));
}

void l2d6d_init()
{
  LVAL r, s;
  char buf[80];
  
  l2d6d.speed_list = NIL;
  l2d6d.symbol = xlenter("L2D6D");
}

int l2d6d_open(port, speed, config)
     char *port;
     int speed;
     char *config;
{
  int fd, n;
  char buf[BSIZ];
  LVAL lst, s, t;
  FILE *f;
  
  if (!port)
    xlerror("Logitech 2D/6D Open: port must be specified", s_unbound);
  
  /* open the port */
  
  if ((fd = serial_open(port, 19200, 8, 1, TIMEOUT)) < 0)
    xlstr_error("Logitech 2D/6D Port Open Error: ");    
  
  /* initialize the device */
  
  serial_write(fd, "*Q*H", 4);
  
  /* the parameter list */
  
  s_instances[fd].parameter_list = NIL;
  
  /* the output specifier list */
  
  s_instances[fd].available_results = consa(type_point);
  rplacd(s_instances[fd].available_results, t = consa(type_quaternion));
  rplacd(t, s = consa(type_pt_quaternion));
  rplacd(s, t = consa(type_matrix));
  rplacd(t, s = consa(type_buttons));
  
  return fd;  
}

LVAL l2d6d_put(fd, n)
int fd, n;
{
  int s;
  LVAL arg2;
  LVAL param, val;

  param = xlgasymbol();
  if (param == s_boresight)
  {
    if (moreargs())
    {
      LVAL q, qv;
      q = xlgavector();
#ifdef DEBUG
      if (!quaternionp(q))
	xlerror("Boresight argument must be quaternion", q);
#endif
      xllastarg();
      qv = getelement(q, 1);
      obj[n].Qw = -v_float(q, 0);
      obj[n].Qx = v_float(qv, 0);
      obj[n].Qy = v_float(qv, 1);
      obj[n].Qz = v_float(qv, 2);
    }
    else
    {
      char buf[BSIZ];
      
      /* boresight this sensor to its present orientation */
      
      get_buffer(fd, buf);
      obj[n].Qw = -l_quat_value(buf, 10);
      obj[n].Qx = l_quat_value(buf, 12);
      obj[n].Qy = l_quat_value(buf, 14);
      obj[n].Qz = l_quat_value(buf, 16);      
    }
    obj[n].flags |= BORESIGHT;
    return true;      
  }
  else if (arg2 == s_unboresight)
  {
    /* turn off the boresight on this sensor */
      
    obj[n].flags &= ~BORESIGHT;
    return true;
  }
  else if (arg2 == s_origin)
  {
    if (moreargs())
    {
      LVAL p;
      p = xlgavector();
#ifdef DEBUG
      if (!triplep(p))
	xlerror("Origin argument must be point", p);
#endif
      xllastarg();
      obj[n].x = v_float(p, 0);
      obj[n].y = v_float(p, 1);
      obj[n].z = v_float(p, 2);
    }
    else
    {
      char buf[BSIZ];

      /* set the origin of the device to its current location */

      get_buffer(fd, buf);

      obj[n].x = l_disp_value(buf, 1);
      obj[n].y = l_disp_value(buf, 4);
      obj[n].z = l_disp_value(buf, 7);
    }
    obj[n].flags |= ORIGIN;
    return true;
  }
  else if (arg2 == s_reset_origin)
  {
    obj[n].flags &= ORIGIN;
    return true;
  }
  else
    xlerror("Illegal request", arg2);
}

LVAL l2d6d_get(n)
     int n;
{
  int fd;
  LVAL arg2;
  
  if (n > FD_SETSIZE)
  {
    /* this is a data output descriptor */
    
    n -= FD_SETSIZE;
    fd = obj[n].fd;
    arg2 = xlgasymbol();
    xllastarg();
    xlerror("Illegal symbol for data output descriptor", arg2);
  }
  else
  {
    /* this is a file descriptor */
    
    fd = n;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == type_list)
      return s_instances[fd].available_results;
    else if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else if (arg2 == s_no_sensors)
      return cvfixnum(1);
    xlerror("Illegal symbol for file descriptor", arg2);
  }
  return true;
}

LVAL l2d6d_data_descriptor(fd)
     int fd;
{
  LVAL type;
  int ind, n;
  
  type = xlgasymbol();
  if (memberx(type, s_instances[fd].available_results) == FALSE)
    xlerror("Illegal output type requested", type);
  
  if (moreargs())
    ind = getfixnum(xlgafixnum());
  else
    ind = 1;
  xllastarg();
  
  if (ind != 1)
    xlerror("Illegal index", s_unbound);
  
  /* pick out a data descriptor slot */
  
  if ((n = find_empty_obj()) == -1)
    xlerror("Out of data descriptors", s_unbound);
  
  /* add this item to the list of things that we ask the device for */

  obj[n].fd = fd;
  obj[n].read = (s_instances[fd].obj)->read;
  obj[n].value_type = type;
  obj[n].val_index = ind;
  obj[n].flags = 0;
  return cvfixnum(n + FD_SETSIZE);
}

/* this function should be all-out speed optimized! */

LVAL l2d6d_read(n, where)
int n;
LVAL where;

{
  unsigned char buf[20];
  int fd;
  LVAL value_type;
  float qw, qx, qy, qz, x, y, z;

  value_type = obj[n].value_type;
  fd = obj[n].fd;

  get_buffer(fd, buf);

  if ((value_type == type_point) || (value_type == type_pt_quaternion) ||
      (value_type == type_matrix))
  {
    get_point(buf, &x, &y, &z);
    if (obj[n].flags & ORIGIN)
      concatenate_translations(&x, &y, &z, x, y, z, 
			       obj[n].x, obj[n].y, obj[n].z);
  }

  if ((value_type == type_quaternion) || (value_type == type_pt_quaternion) ||
      (value_type == type_matrix))
  {
    get_quaternion(buf, &qw, &qx, &qy, &qz);
    if (obj[n].flags & BORESIGHT)
      concatenate_quaternions(&qw, &qx, &qy, &qz, qw, qx, qy, qz,
			      obj[n].Qw, obj[n].Qx, obj[n].Qy, obj[n].Qz);
  }

  if (value_type == type_point)
    stuff_point(where, x, y, z);
  else if (value_type == type_quaternion)
    stuff_quaternion(where, qw, qx, qy, qz);
  else if (value_type == type_pt_quaternion)
    stuff_pt_quaternion(where, qw, qx, qy, qz, x, y, z);
  else if (value_type == type_matrix)
    stuff_matrix(where, qw, qx, qy, qz, x, y, z);
  else if (value_type == type_buttons)
    stuff_buttons(where, buf);
  else
    xlerror("illegal result type specified", value_type);

  return true;
}

int l2d6d_close(fd)
{
  s_instances[fd].obj = NULL;
  s_instances[fd].device = NIL;
  s_instances[fd].parameter_list = NIL;
  s_instances[fd].available_results = NIL;
  return close(fd);
}

