/* xlfastrak.c

   by Fran Taylor, at the HITLab, Seattle

   Copyright (C) 1992  Human Interface Technology Lab, Seattle

   Xlisp interface to Polhemus Fastrak 

   This code by default does NO error checking, for speed,
   If you want full error checking, compile with -DDEBUG */

/* PROACTIVE additions by Andrew MacDonald */

#include <stdio.h>

#include "xlisp.h"
#include "xlsensor.h"
#include "seriallib.h"

extern char *sys_errlist[];

#define TIMEOUT 2 /* be a sport */

#define BSIZ 132
#define DATALEN 17

#define TOTAL_DATA 31 * 4

#define pol_int_value(buf, n) ((short) ((buf)[(n)] | ((buf)[(n)+1] << 8)))

#ifdef RADIANS
#define pol_angle_value(buf, n) (((float) pol_int_value(buf, n)) /  \
  				  (256.0 * 180.0 * M_1_PI))
#else
#define pol_angle_value(buf, n) (((float) pol_int_value(buf, n)) / (256.0))
#endif

#define pol_disp_value(buf, n) (((float) pol_int_value(buf, n)) / 25600.0)

#define pol_quat_value(buf, n) (((float) pol_int_value(buf, n)) / 32768.0)

static void get_fastrak(int fd, char *buf, int len);
#ifdef PROACTIVE
static void prime_fastrak(int fd, int len);
static void flush_fastrak(int fd, char *buf, int len);
#endif
static void get_point(char *buf, int n, float *x, float *y, float *z);
static void get_quaternion(char *buf, int n, float *qw, float *qx,
			   float *qy, float *qz);
void fastrak_init(void);
int fastrak_open(char *port, int speed, char *config);
LVAL fastrak_put(int fd, int n);
LVAL fastrak_get(int n);
LVAL fastrak_data_descriptor(int fd);
LVAL fastrak_read(int n, LVAL where);
int fastrak_close(int fd);

typedef struct pol_float
{
  union
  {
    float f;
    unsigned long l;
  } u;
} pol_float;

sensor_object fastrak =
{
  "Fastrak", fastrak_init, fastrak_open, fastrak_get, fastrak_put, 
  fastrak_data_descriptor, fastrak_read, fastrak_close, NIL, NULL
};

static void get_fastrak(fd, buf, len)
int fd;
char *buf;
int len;
{
  int n;

  if (serial_vmin(fd, len) < 0)
    xlstr_error("Fastrak vmin error: ");

  if (serial_write(fd, "P", 1) < 0)
    xlstr_error("Fastrak Read Data Command Write Error: ");

  if ((n = serial_timeout_read(fd, buf, len, TIMEOUT)) != len)
    xln2str_error("Fastrak Data Read Error (%d of %d bytes read): ", n, len);

#ifdef DEBUG
    if ((buf[0] != '0') || (buf[2] != ' '))
      xlerror("Garbled data from Fastrak", s_unbound);
#endif
}

#ifdef PROACTIVE
static void prime_fastrak(fd, len)
int fd;
int len;
{
  if (serial_vmin(fd, len) < 0)
    xlstr_error("Fastrak vmin error: ");

  if (serial_write(fd, "P", 1) < 0)
    xlstr_error("Fastrak Read Data Command Write Error: ");
}

static void flush_fastrak(fd, buf, len)
int fd;
char *buf;
int len;
{
  int n;

  if ((n = serial_timeout_read(fd, buf, len, TIMEOUT)) != len)
    xln2str_error("Fastrak Data Read Error (%d of %d bytes read): ", n, len);

#ifdef DEBUG
    if ((buf[0] != '0') || (buf[2] != ' '))
      xlerror("Garbled data from Fastrak", s_unbound);
#endif
}
#endif /* PROACTIVE */

/* convert polhemus floats to native floats */

static float get_float(buf, n)
unsigned char *buf;
int n;
{
  pol_float x;

#ifdef BIG_ENDIAN
  x.u.l = (((unsigned long) buf[n+3]) << 24) |
          (((unsigned long) buf[n+2]) << 16) |
          (((unsigned long) buf[n+1]) <<  8) |
          (((unsigned long) buf[n  ]));
#else
  x.u.l = (((unsigned long) buf[n  ]) << 24) |
          (((unsigned long) buf[n+1]) << 16) |
	  (((unsigned long) buf[n+2]) <<  8) |
	  (((unsigned long) buf[n+3]));
#endif

  return x.u.f;
}

static void get_point(buf, n, x, y, z)
char *buf;
int n;
float *x, *y, *z;
{
  int p = (n - 1) * 31 + 3;

  /* be sure to convert to meters */
  *x = get_float(buf, p) * 2.54 / 100.0 ;
  *y = get_float(buf, p + 4) * 2.54 / 100.0 ;
  *z = get_float(buf, p + 8) * 2.54 / 100.0 ;
}

static void get_quaternion(buf, n, qw, qx, qy, qz)
char *buf;
int n;
float *qw, *qx, *qy, *qz;
{
  int p = (n - 1) * 31 + 3;
  *qw = get_float(buf, p + 12);
  *qx = get_float(buf, p + 16);
  *qy = get_float(buf, p + 20);
  *qz = get_float(buf, p + 24);
}

void fastrak_init()
{
  LVAL r, s;

  xlstkcheck(3);
  xlsave(r);
  xlsave(s);
  xlsave(fastrak.speed_list);

  fastrak.speed_list = xlenter("FASTRAK-SPEED-LIST");
  setvalue(fastrak.speed_list, r = cons_fixnum(300));
  rplacd(r, s = cons_fixnum(1200));
  rplacd(s, r = cons_fixnum(2400));
  rplacd(r, s = cons_fixnum(4800));
  rplacd(s, r = cons_fixnum(9600));
  rplacd(r, s = cons_fixnum(19200));
  rplacd(s, r = cons_fixnum(38400));
  rplacd(r, s = cons_fixnum(57600));
  rplacd(s, r = cons_fixnum(115200));

  fastrak.symbol = xlenter("FASTRAK");
  xlpopn(3);
}

/* the Fastrak MUST be opened at 9600 bps, but we can crank it up! */

int fastrak_open(port, speed, config)
char *port;
int speed;
char *config;
{
  int fd, n, i;
  char buf[BSIZ];
  unsigned char ch;
  LVAL lst, s, t;
  FILE *f;

  if ((fd = serial_open(port, 9600, 8, 2, TIMEOUT)) < 0)
    xlstr_error("Fastrak Port Open Error: ");

  /* zap everything back to default values */

  buf[0] = 'W';
  buf[1] = '\0';
  if (serial_write(fd, buf, 1) != 1)
    xlstr_error("Fastrak Initialize Command Write Error: ");

  sleep(2);

  buf[0] = '\013'; /* ^K */
  buf[1] = '\0';

  if (serial_write(fd, buf, 1) != 1)
    xlstr_error("Fastrak Initialize Command Write Error: ");

  sleep(2);

  /* if speed is non-zero, change to the specified speed */

  if (speed && (speed != 9600))
  {
    sprintf(buf, "o%d,N,8\r", speed / 100);

#ifdef SHOW_OUTPUTS
    printf("Sending: \"%s\"\n", buf);
#endif

    if (serial_write(fd, buf, strlen(buf)) != strlen(buf))
      xlstr_error("Fastrak Speed Change Command Write Error: ");

    if (serial_config(fd, speed, 8, 1) < 0)
      xlnstr_error("Fastrak Port Speed Change Error (%d bps): ", speed);
    sleep(1); /* wait for everybody to get adjusted */
  }

  /* open and transfer the configuration file, substituting
     carriage returns for newlines */

  if (config && config[0])
  {
    if ((f = fopen(config, "r")) == NULL)
      xlstr_error("Fastrak: Can't open Configuration File: ");
  
    for(; fgets(buf, BSIZ, f); )
    {
#ifdef SHOW_OUTPUTS
      printf("Sending: \"%s\"\n", buf);
#endif

      buf[strlen(buf) - 1] = '\r';
      if (serial_write(fd, buf, strlen(buf)) < 0)
	xlstr_error("Fastrak Configuration File Write Error: ");
    }
    close(f);
  }

  s_instances[fd].attached = 0x1e;

  /* tell it we want binary data */

  buf[0] = 'f';

  if (serial_write(fd, buf, 1) < 0)
    xlstr_error("Fastrak Binary Output Command Write Error: ");

  /* tell it what kind of data we want */

  strcpy(buf, "O1,2,11\rO2,2,11\rO3,2,11\rO4,2,11\r");
  if (serial_write(fd, buf, strlen(buf)) < 0)
	xlstr_error("Fastrak Output Format Command Write Error: ");

  /* protect thyself */

  xlstkcheck(4);
  xlsave(t);
  xlsave(s);
  xlsave(s_instances[fd].parameter_list);
  xlsave(s_instances[fd].available_results);

  /* the parameter list */
  
  s_instances[fd].parameter_list = xlenter("FASTRAK-PARAMETER-LIST");
  setvalue(s_instances[fd].parameter_list, s = consa(s_hemisphere));
  rplacd(s, t = consa(s_boresight));
  rplacd(t, s = consa(s_unboresight));
  rplacd(s, t = consa(s_origin));
  rplacd(t, s = consa(s_reset_origin));

  /* the output specifier list */

  s_instances[fd].available_results = xlenter("FASTRAK-OUTPUT-LIST");
  setvalue(s_instances[fd].available_results, s = consa(type_point));
  rplacd(s, t = consa(type_quaternion));
  rplacd(t, s = consa(type_pt_quaternion));
  rplacd(s, t = consa(type_matrix));

  xlpopn(4);

  s_instances[fd].initialized = 0;
  s_instances[fd].enabled = 0;
  s_instances[fd].read = 0xff;
  s_instances[fd].origin_flags = 0;
  s_instances[fd].boresight_flags = 0;
  return fd;  
}

LVAL fastrak_put(fd, n)
int fd;
int n;
{
  int x, y, z;
  char buf[80];
  LVAL param, val;
  int i;
#ifdef PROACTIVE
  int idx;
#endif

  xlstkcheck(2);
  xlsave(param);
  xlsave(val);
  
  i = obj[n].val_index;
  
  if ((param = xlgasymbol()) == s_hemisphere)
  {
    if ((val = xlgasymbol()) == hemisphere_forward)
    {
      x = 1;
      y = z = 0;
    }
    else if (val == hemisphere_aft)
    {
      x = -1;
      y = z = 0;
    }
    else if (val == hemisphere_upper)
    {
      x = y = 0;
      z = 1;
    }
    else if (val == hemisphere_lower)
    {
      x = y = 0;
      z = -1;
    }
    else if (val == hemisphere_left)
    {
      x = z = 0;
      y = -1;
    }
    else if (val == hemisphere_right)
    {
      x = z = 0;
      y = 1;
    }
    else
      xlerror("Illegal hemisphere", val);

    /* write the hemisphere command to the Fastrak */

#ifdef PROACTIVE
    if( i != 0)
    {
#endif
      sprintf(buf, "H%d,%d,%d,%d,%d\r", i, x, y, z);
      if (serial_write(fd, buf, strlen(buf)) < 0)
	xlstr_error("Fastrak Hemisphere Command Write Error: ");
      obj[n].hemisphere = val;
#ifdef PROACTIVE
    }
    else
    {
      flush_fastrak(fd, s_instances[fd].buf, TOTAL_DATA);
      for( idx = 1; idx < 5; idx++)
      {
        sprintf(buf, "H%d,%d,%d,%d,%d\r", idx, x, y, z);
	if (serial_write(fd, buf, strlen(buf)) < 0)
	  xlstr_error("Fastrak Hemisphere Command Write Error: ");
      }
      obj[n].hemisphere = val;
      prime_fastrak(fd, TOTAL_DATA);
    }    
#endif /* PROACTIVE */
  }

  else if (param == s_boresight)
  {
    if (moreargs())
    {
      LVAL q;
      xlsave1(q);
      q = xlgavector();
      xllastarg();
#ifdef PROACTIVE
      if(i != 0)
#endif
	pull_quaternion(q, &(s_instances[fd].Qw[i]), &(s_instances[fd].Qx[i]),
			&(s_instances[fd].Qy[i]), &(s_instances[fd].Qz[i]));
#ifdef PROACTIVE
      else
	for( idx = 1; idx < 5; idx++)
	  pull_quaternion(getelement(q, idx - 1),
			  &(s_instances[fd].Qw[idx]), &(s_instances[fd].Qx[idx]),
			  &(s_instances[fd].Qy[idx]), &(s_instances[fd].Qz[idx]));
#endif /* PROACTIVE */

      xlpop();
    }
    else
    {
      char buf[BSIZ];

#ifdef PROACTIVE
      if( i != 0)
      {
#endif
        get_fastrak(fd, buf, TOTAL_DATA);
	get_quaternion(buf, i, &(s_instances[fd].Qw[i]), 
		       &(s_instances[fd].Qx[i]),
		       &(s_instances[fd].Qy[i]), &(s_instances[fd].Qz[i]));
#ifdef PROACTIVE
      }
      else
      {
        flush_fastrak(fd, buf, TOTAL_DATA);
        get_fastrak(fd, buf, TOTAL_DATA);
	for( idx = 1; idx < 5; idx++)
	    get_quaternion(buf, idx,
			   &(s_instances[fd].Qw[idx]), &(s_instances[fd].Qx[idx]),
			   &(s_instances[fd].Qy[idx]), &(s_instances[fd].Qz[idx]));
	prime_fastrak(fd, TOTAL_DATA);
      }
#endif /* PROACTIVE */
    }

#ifdef PROACTIVE
    if( i != 0)
#endif
      s_instances[fd].boresight_flags |= (1 << i);
#ifdef PROACTIVE
    else
      s_instances[fd].boresight_flags |= 0x1e;
#endif
  }

  else if (param == s_unboresight)
  {
#ifdef PROACTIVE
    if( i != 0)
    {
#endif
      s_instances[fd].boresight_flags &= ~(1 << i);
      s_instances[fd].Qw[i] = s_instances[fd].Qx[i] = 0.0;
      s_instances[fd].Qy[i] = s_instances[fd].Qz[i] = 0.0;
#ifdef PROACTIVE
    }
    else
    {
      s_instances[fd].boresight_flags &= ~0x1e;
      for( idx = 1; idx < 5; idx++)
	s_instances[fd].Qw[idx] = s_instances[fd].Qx[idx] =
	    s_instances[fd].Qy[idx] = s_instances[fd].Qz[idx] = 0.0;
    }
#endif /* PROACTIVE */
  }
  else if (param == s_origin)
  {
    if (moreargs())
    {
      LVAL p;
      xlsave1(p);
      p = xlgavector();
      xllastarg();
#ifdef PROACTIVE
      if(i != 0)
#endif
      if(i != 0)
	pull_point(p, &(s_instances[fd].x[i]), &(s_instances[fd].y[i]), 
		   &(s_instances[fd].z[i]));
#ifdef PROACTIVE
      else
	for( idx = 1; idx < 5; idx++)
	  pull_point(getelement(p, idx-1),
		     &(s_instances[fd].x[idx]), &(s_instances[fd].y[idx]), 
		     &(s_instances[fd].z[idx]));
#endif /* PROACTIVE */

      xlpop();
    }
    else
    {
      char buf[BSIZ];

#ifdef PROACTIVE
      if( i != 0)
      {
#endif
        get_fastrak(fd, buf, TOTAL_DATA);
	get_point(buf, i, &(s_instances[fd].x[i]), &(s_instances[fd].y[i]), 
		  &(s_instances[fd].z[i]));
#ifdef PROACTIVE
      }
      else
      {
        flush_fastrak(fd, buf, TOTAL_DATA);
        get_fastrak(fd, buf, TOTAL_DATA);
	for( idx = 1; idx < 5; idx++)
	    get_point(buf, idx, &(s_instances[fd].x[idx]), &(s_instances[fd].y[idx]), 
		      &(s_instances[fd].z[i]));
	prime_fastrak(fd, TOTAL_DATA);
      }
#endif /* PROACTIVE */
    }

#ifdef PROACTIVE
    if( i != 0)
#endif
      s_instances[fd].origin_flags |= (1 << i);
#ifdef PROACTIVE
    else
      s_instances[fd].origin_flags |= 0x1e;
#endif
  }
  else if (param == s_reset_origin)
  {
    xllastarg();

#ifdef PROACTIVE
    if( i != 0)
    {
#endif
      s_instances[fd].origin_flags &= ~(1 << i);
      s_instances[fd].x[i] = s_instances[fd].y[i] = s_instances[fd].z[i] = 0.0;
#ifdef PROACTIVE
    }
    else
    {
      s_instances[fd].origin_flags &= ~0x1e;
      for( idx = 1; idx < 5; idx++)
	s_instances[fd].x[idx] = s_instances[fd].y[idx] = s_instances[fd].z[idx] = 0.0;
    }
#endif /* PROACTIVE */
  }
  else
    xlerror("Illegal parameter", param);
  xlpopn(2);
  return true;
}

LVAL fastrak_get(n)
int n;
{
  int fd;
  LVAL arg2;

  if (n > FD_SETSIZE)
  {
    /* this is a data output descriptor */

    n -= FD_SETSIZE;
    fd = obj[n].fd;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_hemisphere)
      return obj[n].hemisphere;
    else if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else
      xlerror("Illegal symbol for data output descriptor", arg2);
  }
  else
  {
   /* this is a file descriptor */
    
    fd = n;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else if (arg2 == type_list)
      return s_instances[fd].available_results;
    else if (arg2 == s_no_sensors)
      return cvfixnum(4);
    else
      xlerror("Illegal symbol for file descriptor", arg2);
  }
}

LVAL fastrak_data_descriptor(fd)
int fd;
{
  LVAL type;
  int ind, n, i;
  char buf[80];

  type = xlgasymbol();
  if (memberx(type, xleval(xlenter("FASTRAK-OUTPUT-LIST"))) == FALSE)
    xlerror("Illegal output type requested", type);

  if (moreargs())
    ind = getfixnum(xlgafixnum());
  else
    ind = 1;
  xllastarg();

#ifdef PROACTIVE
  if ((ind < 0) || (ind > 4))
#else
  if ((ind <= 0) || (ind > 4))
#endif
    xlerror("Illegal type index", cvfixnum(ind));

  /* pick out a data descriptor slot */
  
  if ((n = find_empty_obj()) == -1)
    xlerror("Out of data descriptors", s_unbound);
  
  /* add this item to the list of things that we ask the device for */

  obj[n].fd = fd;
  obj[n].read = (s_instances[fd].obj)->read;
  obj[n].value_type = type;
  obj[n].val_index = ind;
  obj[n].hemisphere = hemisphere_forward;

#ifdef PROACTIVE
  /* if ind == 0, then we are to prime before reading */
  if( ind == 0)
    prime_fastrak( fd, TOTAL_DATA);
#endif

  return cvfixnum(n + FD_SETSIZE);
}

/* this function should be all-out speed optimized! */

LVAL fastrak_read(n, where)
int n;
LVAL where;
{
  int i, fd;
#ifdef PROACTIVE
  int idx;
#endif
  LVAL value_type;
  float qw, qx, qy, qz;
  float x, y, z;
  
  fd = obj[n].fd;
  value_type = obj[n].value_type;
  i = obj[n].val_index;

#ifdef PROACTIVE
  if( i != 0)
  {
#endif
    /* if this data has been requested before,
       it's time to read in more data */

    if (s_instances[fd].read & (1 << i))
    {
      get_fastrak(fd, s_instances[fd].buf, TOTAL_DATA);
      s_instances[fd].read = 1 << i;
    }
    else
      s_instances[fd].read |= 1 << i;
    
    if ((value_type == type_point) || (value_type == type_pt_quaternion) ||
	(value_type == type_matrix))
    {
      get_point(s_instances[fd].buf, i, &x, &y, &z);
      if (s_instances[fd].origin_flags & (1 << i))
	  concatenate_translations(&x, &y, &z, x, y, z, 
				   -s_instances[fd].x[i], 
				   -s_instances[fd].y[i], 
				   -s_instances[fd].z[i]);
    }
    if ((value_type == type_quaternion) || (value_type == type_pt_quaternion) ||
	(value_type == type_matrix))
    {
      get_quaternion(s_instances[fd].buf, i, &qw, &qx, &qy, &qz);
      if (s_instances[fd].boresight_flags & (1 << i))
	  concatenate_quaternions(&qw, &qx, &qy, &qz, qw, qx, qy, qz,
				  -s_instances[fd].Qw[i], s_instances[fd].Qx[i], 
				  s_instances[fd].Qy[i], s_instances[fd].Qz[i]);
    }
    if (value_type == type_point)
	stuff_point(where, x, y, z);
    else if (value_type == type_quaternion)
	stuff_quaternion(where, qw, qx, qy, qz);
    else if (value_type == type_pt_quaternion)
	stuff_pt_quaternion(where, qw, qx, qy, qz, x, y, z);
    else if (value_type == type_matrix)
	stuff_matrix(where, qw, qx, qy, qz, x, y, z);
    else
	xlerror("Illegal result type specified", value_type);
#ifdef PROACTIVE
  }
  else
  {
    /* data should already be here -- get it, and ask for more */
    flush_fastrak(fd, s_instances[fd].buf, TOTAL_DATA);
    prime_fastrak(fd, TOTAL_DATA);

    for( idx = 1; idx < 5; idx++)
    {
      if ((value_type == type_point) || (value_type == type_pt_quaternion) ||
	  (value_type == type_matrix))
      {
        get_point(s_instances[fd].buf, idx, &x, &y, &z);
	if (s_instances[fd].origin_flags & (1 << idx))
	    concatenate_translations(&x, &y, &z, x, y, z, 
				     -s_instances[fd].x[idx], 
				     -s_instances[fd].y[idx], 
				     -s_instances[fd].z[idx]);
      }

      if ((value_type == type_quaternion) || (value_type == type_pt_quaternion) ||
	  (value_type == type_matrix))
      {
        get_quaternion(s_instances[fd].buf, idx, &qw, &qx, &qy, &qz);
	if (s_instances[fd].boresight_flags & (1 << idx))
	    concatenate_quaternions(&qw, &qx, &qy, &qz, qw, qx, qy, qz,
				    -s_instances[fd].Qw[idx], s_instances[fd].Qx[idx], 
				    s_instances[fd].Qy[idx], s_instances[fd].Qz[idx]);
      }

      /* optimize for reading point-quaternions; we seem to do that most often */
      if (value_type == type_pt_quaternion)
	 stuff_pt_quaternion(getelement(where, idx - 1), qw, qx, qy, qz, x, y, z);
      else if (value_type == type_point)
	stuff_point(getelement(where, idx - 1), x, y, z);
      else if (value_type == type_quaternion)
	stuff_quaternion(getelement(where, idx - 1), qw, qx, qy, qz);
      else if (value_type == type_matrix)
	stuff_matrix(getelement(where, idx - 1), qw, qx, qy, qz, x, y, z);
      else
	xlerror("Illegal result type specified", value_type);
    }
  }
#endif /* PROACTIVE */
  return where;
}

int fastrak_close(fd)
int fd;
{
  s_instances[fd].obj = NULL;
  s_instances[fd].device = NIL;
  s_instances[fd].parameter_list = NIL;
  s_instances[fd].available_results = NIL;
  return close(fd);
}
