/* error_check.c

   by Fran Taylor, at the HITLab, Seattle

   Copyright (C) 1992  Human Interface Technology Lab, Seattle

   Error checking functions for Xlisp functions written in C */

#include <math.h>

#include "xlisp.h"

#define m_float(m, j, i) getflonum(getelement(m, (i * 4) + j))
#define v_float(v, n) getflonum(getelement(v, n))

#define EPSILON 0.01

int triplep(v)
LVAL v;
{
  int i;
#ifdef HAVE_GETSZ
  if (!vectorp(v) || (getsz(v) != 3))
    return 0;
#endif
  for(i = 0; i < 3; i++)
    if (!floatp(getelement(v, i)))
      return 0;
  return 1;
}

int quaternionp(v)
LVAL v;
{
  LVAL p;
  int i;

#ifdef HAVE_GETSZ
  if (!vectorp(v) || (getsz(v) != 2) || !floatp(getelement(v, 0)))
    return 0;
  if (!vectorp(p = getelement(v, 1)) || (getsz(p) != 3))
    return 0;
#endif
  for(i = 0; i < 3; i++)
    if (!floatp(getelement(p, i)))
      return 0;
  return 1;
}

int pt_quatp(x)
LVAL x;
{
#ifdef HAVE_GETSZ
  if (!vectorp(x) || (getsz(x) != 2) || !triplep(getelement(x, 0)) ||
      !quaternionp(getelement(x, 1)))
    return 0;
#endif
  return 1;
}

int pt_eulerp(x)
LVAL x;
{
#ifdef HAVE_GETSZ
  if (!vectorp(x) || (getsz(x) != 2) || !triplep(getelement(x, 0)) ||
      !triplep(getelement(x, 1)))
    return 0;
#endif
  return 1;
}

int matrixp(m)
LVAL m;
{
  int i;

#ifdef HAVE_GETSZ
  if (!vectorp(m) || (getsz(m) != 16))
    return 0;
#endif
  for(i = 0; i < 16; i++)
    if (!floatp(getelement(m, i)))
      return 0;
  return 1;
}

int unitvectorp(v)
LVAL v;
{
  int i;
  float sum = 0.0;

  if (!triplep(v))
    return 0;
  for(i = 0; i < 3; i++)
    sum += v_float(v, i);
  if (fabs(sum - 1.0) > EPSILON)
    return 0;
  return 1;
}

int orthonormalp(m)
LVAL m;
{
  int i, j;
  float sum;

  if (!matrixp(m))
    return 0;

  /* check to make sure the rotation columns are unit vectors */

  for(i = 0; i < 3; i++)
  {
    sum = 0.0;

    for(j = 0; j < 3; j++)
      sum += m_float(m, i, j) * m_float(m, i, j);
    if (fabs(sum - 1.0) > EPSILON)
      return 0;
  }
  
  /* check the dot products of the rotation column vectors are 0 */
  
  if ((fabs((m_float(m, 0, 0) * m_float(m, 1, 0)) +
	    (m_float(m, 0, 1) * m_float(m, 1, 1)) +
	    (m_float(m, 0, 2) * m_float(m, 1, 2))) > EPSILON) ||
      (fabs((m_float(m, 0, 0) * m_float(m, 2, 0)) +
	    (m_float(m, 0, 1) * m_float(m, 2, 1)) +
	    (m_float(m, 0, 2) * m_float(m, 2, 2))) > EPSILON) ||
      (fabs((m_float(m, 2, 0) * m_float(m, 1, 0)) +
	    (m_float(m, 2, 1) * m_float(m, 1, 1)) +
	    (m_float(m, 2, 2) * m_float(m, 1, 2))) > EPSILON) ||
      
      /* make sure the right column is 0, and the bottom right entry is 1 */

      (fabs(m_float(m, 3, 0)) > EPSILON) ||
      (fabs(m_float(m, 3, 1)) > EPSILON) ||
      (fabs(m_float(m, 3, 2)) > EPSILON) ||
      (fabs(m_float(m, 3, 3) - 1.0) > EPSILON))
    return 0;
  return 1;
}

int flexp(f)
LVAL f;
{
  int i;
#ifdef HAVE_GETSZ
  if (!vectorp(f) || (getsz(f) != 10))
    return 0;
#endif
  for(i = 0; i < 10; i++)
    if (!fixp(getelement(f, i)))
      return 0;
  return 1;
}


   
