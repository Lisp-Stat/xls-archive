/* xldataglove.c

   by Fran Taylor, at the HITLab, Seattle

   Copyright (C) 1992  Human Interface Technology Lab, Seattle

   Xlisp interface to Dataglove

   This code by default does NO error checking, for speed,
   If you want full error checking, compile with -DDEBUG

   This code is painful because we can only get Euler angles from
   the Polhemus inside the Dataglove, thanks to VPL brain death. */

#include <stdio.h>
#include <math.h>

#include "xlisp.h"
#include "xlsensor.h"
#include "seriallib.h"

extern char *sys_errlist[];

#define TIMEOUT 2 /* be a sport */

#define BSIZ 132

#define pol_int_value(buf, n) ((short) ((buf)[(n)] | ((buf)[(n)+1] << 8)))

#define pol_angle_value(buf, n) ((float) pol_int_value(buf, n) / 8192.0)

#define pol_disp_value(buf, n) (((float) pol_int_value(buf, n)) * \
				0.000050245)

#define pol_raw_value( n) ((int) (n * 19902.5))

#define dataglove_volts(n) ((float) ((unsigned char) buf[n]) * (5.0 / 256.0))

char dataglove_get_polhemus[] = {0x24, 0x43, 0x02};
char dataglove_get_flex[] = {0x24, 0x43, 0x01};
char dataglove_get_user[] = {0x24, 0x46};

/* records returned from Dataglove:

   polhemus record: (0x24, 0x42, 0x02)

   0 = 0x24;
   1 = 0x42;
   2 = 0x02;
   3 = length (0x0c)
   4, 5 = X
   6, 7 = Y
   8, 9 = Z
   10, 11 = Rx
   12, 13 = Ry
   14, 15 = Rz 
   
   Dataglove record: (0x24, 0x42, 0x01)

   0 = 0x24;
   1 = 0x42;
   2 = 0x01;
   3 = length (0x0a)
   4 = inner thumb 
   5 = outer thumb
   6 = inner index
   7 = outer index
   8 = inner middle
   9 = outer middle
   10 = inner ring
   11 = outer ring
   12 = inner pinkie
   13 = outer pinkie

   User port record: (0x24, 0x46)

   0 = 0x24;
   1 = 0x46;
   2 = digital inputs
   3 = volts 1
   4 = volts 2
   5 = volts 3
*/

void dataglove_init(void);
int dataglove_open(char *port, int speed, char *config);
LVAL dataglove_put(int fd, int n);
LVAL dataglove_get(int n);
LVAL dataglove_data_descriptor(int fd);
LVAL dataglove_read(int n, LVAL where);
int dataglove_close(int fd);

static int polhemus_write(int fd, char *str, int len);

static void get_polhemus(int fd, unsigned char *buf);
static void get_user_port(int fd, unsigned char *buf);
static void get_flex(int fd, unsigned char *buf);

#ifdef SPEEDY
static void prime_polhemus(int fd);
static void prime_user_port(int fd);
static void prime_flex(int fd);

static void flush_polhemus(int fd, unsigned char *buf);
static void flush_user_port(int fd, unsigned char *buf);
static void flush_flex(int fd, unsigned char *buf);
#endif

static void get_quaternion(unsigned char *buf, float *qw, float *qx, float *qy, float *qz);
static void get_point(unsigned char *buf, float *x, float *y, float *z);
static void stuff_buttons(LVAL where, unsigned char *buf);
static void stuff_volts(LVAL where, unsigned char *buf);
static void stuff_flex(LVAL where, unsigned char *buf);
static int dataglove_get_calibration(int fd, unsigned char *buf, int n);

sensor_object dataglove =
{
  "Dataglove", dataglove_init, dataglove_open, dataglove_get, dataglove_put, 
  dataglove_data_descriptor, dataglove_read, dataglove_close, NIL, NULL};

static int polhemus_write(fd, str, len)
int fd;
char *str;
int len;
{
  char buf[3];
  buf[0] = 0x24;
  buf[1] = 0x51;
  buf[2] = len;
  serial_write(fd, buf, 3);
  return (serial_write(fd, str, len));
}

static void get_polhemus(fd, buf)
int fd;
unsigned char *buf;
{
  int n;
  serial_vmin(fd, 16);
  if (serial_write(fd, dataglove_get_polhemus, 3) < 0)
    xlstr_error("Dataglove Position Command Write Error: ");
  if ((n = serial_timeout_read(fd, buf, 16, TIMEOUT)) != 16)
    xlnstr_error("Dataglove Polhemus Read Error (%d of 16 bytes read): ", n);

#ifdef DEBUG
  if ((buf[0] != 0x24) || (buf[1] != 0x43) || (buf[2] != 0x02) ||
      (buf[3] != 0x0c))
    xlerror("Bad data from Dataglove", s_unbound);
#endif
}

#ifdef SPEEDY
static void prime_polhemus(fd)
int fd;
{
  serial_vmin(fd, 16);
  if (serial_write(fd, dataglove_get_polhemus, 3) < 0)
    xlstr_error("Dataglove Position Command Write Error: ");
}

static void flush_polhemus(fd, buf)
int fd;
unsigned char *buf;
{
  int n;
  if ((n = serial_timeout_read(fd, buf, 16, TIMEOUT)) != 16)
    xlnstr_error("Dataglove Polhemus Read Error (%d of 16 bytes read): ", n);

#ifdef DEBUG
  if ((buf[0] != 0x24) || (buf[1] != 0x43) || (buf[2] != 0x02) ||
      (buf[3] != 0x0c))
    xlerror("Bad data from Dataglove", s_unbound);
#endif
}
#endif /* SPEEDY */

static void get_quaternion(buf, qw, qx, qy, qz)
unsigned char *buf;
float *qw, *qx, *qy, *qz;
{
  euler_to_quaternion(qw, qx, qy, qz, pol_angle_value(buf, 10),
		      pol_angle_value(buf, 12), pol_angle_value(buf, 14));
}

static void get_user_port(fd, buf)
int fd;
unsigned char *buf;
{
  int n;
  serial_vmin(fd, 6);
  if (serial_write(fd, dataglove_get_user, 2) < 0)
    xlstr_error("Dataglove User Port Command Write Error: ");
  if ((n = serial_timeout_read(fd, buf, 6, TIMEOUT)) != 6)
    xlnstr_error("Dataglove User Port Read Error (read %d bytes of 6): ", n);

#ifdef DEBUG
  if ((buf[0] != 0x24) || (buf[1] != 0x46))
    xlerror("Dataglove User Port Read: Garbled Data", s_unbound);
#endif
}

#ifdef SPEEDY
static void prime_user_port(fd)
int fd;
{
  serial_vmin(fd, 6);
  if (serial_write(fd, dataglove_get_user, 2) < 0)
    xlstr_error("Dataglove User Port Command Write Error: ");
}

static void flush_user_port(fd, buf)
int fd;
unsigned char *buf;
{
  int n;
  if ((n = serial_timeout_read(fd, buf, 6, TIMEOUT)) != 6)
    xlnstr_error("Dataglove User Port Read Error (read %d bytes of 6): ", n);

#ifdef DEBUG
  if ((buf[0] != 0x24) || (buf[1] != 0x46))
    xlerror("Dataglove User Port Read: Garbled Data", s_unbound);
#endif
}
#endif /* SPEEDY */

static void get_flex(fd, buf)
int fd;
unsigned char *buf;
{
  int n;
  serial_vmin(fd, 14);
  if (serial_write(fd, dataglove_get_flex, 3) < 0)
    xlstr_error("Dataglove Read Flex Write Error: ");
  if ((n = serial_timeout_read(fd, buf, 14, TIMEOUT)) != 14)
    xlnstr_error(
	   "Dataglove Position Command Read Error (%d of 16 bytes read): ", n);

#ifdef DEBUG
  if ((buf[0] != 0x24) || (buf[1] != 0x43) || (buf[2] != 0x01) ||
      (buf[3] != 0x0a))
    xlerror("Bad data from Dataglove", s_unbound);
#endif
}

#ifdef SPEEDY
static void prime_flex(fd)
int fd;
{
  serial_vmin(fd, 14);
  if (serial_write(fd, dataglove_get_flex, 3) < 0)
    xlstr_error("Dataglove Read Flex Write Error: ");
}

static void flush_flex(fd, buf)
int fd;
unsigned char *buf;
{
  int n;
  if ((n = serial_timeout_read(fd, buf, 14, TIMEOUT)) != 14)
    xlnstr_error(
	   "Dataglove Position Command Read Error (%d of 16 bytes read): ", n);

#ifdef DEBUG
  if ((buf[0] != 0x24) || (buf[1] != 0x43) || (buf[2] != 0x01) ||
      (buf[3] != 0x0a))
    xlerror("Bad data from Dataglove", s_unbound);
#endif
}
#endif /* SPEEDY */

static void get_point(buf, x, y, z)
unsigned char *buf;
float *x, *y, *z;
{
  *x = pol_disp_value(buf, 4);
  *y = pol_disp_value(buf, 6);
  *z = pol_disp_value(buf, 8);
}

static void stuff_buttons(where, buf)
LVAL where;
unsigned char *buf;
{
  int i;
#ifdef DEBUG
  if (!vectorp(where))
    xlerror("Destination must be vector", where);
  if (getsz(where) < 4)
    xlerror("Destination vector too small", where);
#endif

  for(i = 0; i < 4; i++)
    setelement(where, i, cvfixnum(((~buf[2]) >> i) & 0x01));
}

static void stuff_volts(where, buf)
LVAL where;
unsigned char *buf;
{
#ifdef DEBUG
    if (!triplep(where))
      xlerror("Destination must be triple", where);
#endif
    v_float(where, 0) = dataglove_volts(buf[3]);
    v_float(where, 1) = dataglove_volts(buf[4]);
    v_float(where, 2) = dataglove_volts(buf[5]);
}

static void stuff_flex(where, buf)
LVAL where;
unsigned char *buf;
{
  int i;
#ifdef DEBUG
    if (!flexp(where))
      xlerror("Destination must be flex", where);
#endif
    for(i = 0; i < 10; i++)
      setelement(where, i, cvfixnum((unsigned char) buf[i + 4]));
}

void dataglove_init()
{
  LVAL r, s;
  xlstkcheck(3);
  xlsave(r);
  xlsave(s);
  xlsave(dataglove.speed_list);

  dataglove.speed_list = xlenter("DATAGLOVE-SPEED-LIST");
  setvalue(dataglove.speed_list, r = cons_fixnum(300));
  rplacd(r, s = cons_fixnum(1200));
  rplacd(s, r = cons_fixnum(2400));
  rplacd(r, s = cons_fixnum(4800));
  rplacd(s, r = cons_fixnum(9600));
  rplacd(r, s = cons_fixnum(19200));
  rplacd(s, r = cons_fixnum(38400));
  dataglove.symbol = xlenter("DATAGLOVE");
  xlpopn(3);
}

int dataglove_open(port, speed, config)
char *port;
int speed;
char *config;
{
  int fd, n;
  unsigned char buf[BSIZ];
  LVAL s, t;
  FILE *f;
  
  /* open the serial port */

  if ((fd = serial_open(port, speed, 8, 1, TIMEOUT)) < 0)
    xlstr_error("Dataglove Port Open Error: ");

  /* initialize the Dataglove */

  buf[0] = 0x24;
  buf[1] = 0x4a;
  if (serial_write(fd, buf, 2) < 0)
    xlstr_error("Dataglove Initialize Command Write Error: ");

#ifdef ULTRIX
  /* the decs are sooOOO fast that we have to put this delay in.
     We don't need it on the other reads: I haven't a clue why.
     -awm */
  for( n = 0; n < 250000; n++);
#endif

  if ((n = serial_timeout_read(fd, buf, 5, TIMEOUT)) != 5)
    xlnstr_error("Dataglove Initialize Read Error: ", n);

  /* always protect yourself... */

  xlstkcheck(4);
  xlsave(t);
  xlsave(s);
  xlsave(s_instances[fd].parameter_list);
  xlsave(s_instances[fd].available_results);

  /* the parameter list */

  s_instances[fd].parameter_list = xlenter("DATAGLOVE-PARAMETER-LIST");
  setvalue(s_instances[fd].parameter_list,  s = consa(s_hemisphere));
  rplacd(s, t = consa(s_boresight));
  rplacd(t, s = consa(s_unboresight));
  rplacd(s, t = consa(s_origin));
  rplacd(t, s = consa(s_reset_origin));
  
  /* the output specifier list */

  s_instances[fd].available_results = xlenter("DATAGLOVE-OUTPUT-LIST");
  setvalue(s_instances[fd].available_results, s = consa(type_point));
  rplacd(s, t = consa(type_quaternion));
  rplacd(t, s = consa(type_pt_quaternion));
  rplacd(s, t = consa(type_matrix));
  rplacd(t, s = consa(type_flex));
  rplacd(s, t = consa(type_buttons));
  rplacd(t, s = consa(type_volts));

  xlpopn(4);
  return fd;  
}

LVAL dataglove_put(fd, n)
int fd;
int n;
{
  int x, y, z;
  unsigned char buf[80];
  LVAL param, val;
  int i;
  
  xlstkcheck(2);
  xlsave(param);
  xlsave(val);

  i = obj[n].val_index;
  if ((param = xlgasymbol()) == s_hemisphere)
  {
    if ((val = xlgasymbol()) == hemisphere_forward)
    {
      x = 1;
      y = z = 0;
    }
    else if (val == hemisphere_aft)
    {
      x = -1;
      y = z = 0;
    }
    else if (val == hemisphere_upper)
    {
      x = y = 0;
      z = 1;
    }
    else if (val == hemisphere_lower)
    {
      x = y = 0;
      z = -1;
    }
    else if (val == hemisphere_left)
    {
      x = z = 0;
      y = -1;
    }
    else if (val == hemisphere_right)
    {
      x = z = 0;
      y = 1;
    }
    else
      xlerror("Illegal hemisphere", val);

    /* write the hemisphere command to the Dataglove */

#if 0
    sprintf(buf, "H%d,%d,%d,%d,%d\r", n, x, y, z);
    if (polhemus_write(fd, buf, strlen(buf)) != strlen(buf))
      xlstr_error("Dataglove Hemisphere Write Error: ");
    obj[n].hemisphere = val;
#endif
  }
  else if (param == s_boresight)
  {
    if (moreargs())
    {
      LVAL q;
      xlsave1(q);
      q = xlgavector();
      xllastarg();
      pull_quaternion(q, &(s_instances[fd].Qw[i]), &(s_instances[fd].Qx[i]),
		      &(s_instances[fd].Qy[i]), &(s_instances[fd].Qz[i]));
      xlpop();
    }
    else
    {
      unsigned char buf[BSIZ];

      get_polhemus(fd, buf);
      get_quaternion(buf, &(s_instances[fd].Qw[i]), &(s_instances[fd].Qx[i]),
		     &(s_instances[fd].Qy[i]), &(s_instances[fd].Qz[i]));
    }
    s_instances[fd].boresight_flags |= (1 << i);
  }
  else if (param == s_unboresight)
  {
    xllastarg();
    s_instances[fd].Qw[i] = s_instances[fd].Qx[i] = 0.0;
    s_instances[fd].Qy[i] = s_instances[fd].Qz[i] = 0.0;
    s_instances[fd].boresight_flags &= ~(1 << i);
  }
  else if (param == s_origin)
  {
    if (moreargs())
    {
      LVAL p;
      p = xlgavector();
      xllastarg();
      pull_point(p, &(s_instances[fd].x[i]), &(s_instances[fd].y[i]), 
		 &(s_instances[fd].z[i]));
    }
    else
    {
      unsigned char buf[BSIZ];

      get_polhemus(fd, buf);
      get_point(buf, &(s_instances[fd].x[i]), &(s_instances[fd].y[i]),
		&(s_instances[fd].z[i]));
    }
    s_instances[fd].origin_flags |= (1 << i);
  }
  else if (param == s_reset_origin)
  {
    xllastarg();
    s_instances[fd].x[i] = s_instances[fd].y[i] = s_instances[fd].z[i] = 0.0;
    s_instances[fd].origin_flags &= ~(1 << i);
  }
  else
    xlerror("Illegal parameter", param);
  xlpopn(2);
  return true;
}

LVAL dataglove_get(n)
int n;
{
  int fd;
  LVAL arg2;

  if (n >= FD_SETSIZE)
  {
    /* this is a data output descriptor */

    n -= FD_SETSIZE;
    fd = obj[n].fd;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_hemisphere)
      return obj[n].hemisphere;
    else if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else
      xlerror("Illegal symbol for data output descriptor", arg2);
  }
  else
  {
   /* this is a file descriptor */
    
    fd = n;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else if (arg2 == type_list)
      return s_instances[fd].available_results;
    else if (arg2 == s_no_sensors)
      return cvfixnum(1);
    else if (arg2 == calibrate)
    {
      unsigned char buf[2593];
      int i, j;
      if (dataglove_get_calibration(fd, buf, 5) < 0)
	return NIL;
      if (serial_write(fd, buf, 2593) < 0)
	xlstr_error("Dataglove Calibration Table Write Error: ");
    }
    else
      xlerror("Illegal symbol for file descriptor", arg2);
  }
  return true;
}

LVAL dataglove_data_descriptor(fd)
int fd;
{
  LVAL type;
  int ind, n;

  type = xlgasymbol();
  if (memberx(type, xleval(s_instances[fd].available_results)) == FALSE)
    xlerror("Illegal output type requested", type);

  if (moreargs())
    ind = getfixnum(xlgafixnum());
  else
    ind = 1;
  xllastarg();

  if (ind != 1)
    xlerror("Illegal index", cvfixnum(ind));

  /* pick out a data descriptor slot */
  
  if ((n = find_empty_obj()) == -1)
    xlerror("Out of data descriptors", s_unbound);
  
  /* add this item to the list of things that we ask the device for */

  obj[n].fd = fd;
  obj[n].read = (s_instances[fd].obj)->read;
  obj[n].value_type = type;
  obj[n].val_index = ind;
  obj[n].hemisphere = hemisphere_forward;
  obj[n].flags = 0;
  return cvfixnum(n + FD_SETSIZE);
}

LVAL dataglove_read(n, where)
int n;
LVAL where;
{
  unsigned char buf[BSIZ];
  int i, fd;
  char ind;
  float qw, qx, qy, qz, x, y, z;
  LVAL value_type;

  value_type = obj[n].value_type;
  fd = obj[n].fd;
  i = obj[n].val_index;

  /* read the data from the port, and turn it into
     "our kind of data" */

  if ((value_type == type_buttons) || (value_type == type_volts))
    get_user_port(fd, buf);

  if ((value_type == type_point) || (value_type == type_quaternion) ||
      (value_type == type_pt_quaternion) || (value_type == type_matrix))
    get_polhemus(fd, buf);

  if (value_type == type_flex)
    get_flex(fd, buf);

  /* if there's an origin or offset in effect, do it */

  if ((value_type == type_quaternion) || (value_type == type_pt_quaternion) ||
      (value_type == type_matrix))
  {

    get_quaternion(buf, &qw, &qx, &qy, &qz);
    if (s_instances[fd].boresight_flags & (1 << i))
      concatenate_quaternions(&qw, &qx, &qy, &qz, 
			      -s_instances[fd].Qw[i], s_instances[fd].Qx[i], 
			      s_instances[fd].Qy[i], s_instances[fd].Qz[i],
			      qw, qx, qy, qz);
  }

  if ((value_type == type_point) || (value_type == type_pt_quaternion) ||
      (value_type == type_matrix))
  {
    get_point(buf, &x, &y, &z);
    if (s_instances[fd].origin_flags & (1 << i))
      concatenate_translations(&x, &y, &z, x, y, z, 
			       -s_instances[fd].x[i], -s_instances[fd].y[i],
			       -s_instances[fd].z[i]);
  }

  /* stuff the result structure */

  if (value_type == type_point)
    stuff_point(where, x, y, z);
  else if (value_type == type_quaternion)
    stuff_quaternion(where, qw, qx, qy, qz);
  else if (value_type == type_pt_quaternion)
    stuff_pt_quaternion(where, qw, qx, qy, qz, x, y, z);
  else if (value_type == type_matrix)
    stuff_matrix(where, qw, qx, qy, qz, x, y, z);
  else if (value_type == type_buttons)
    stuff_buttons(where, buf);
  else if (value_type == type_volts)
    stuff_volts(where, buf);
  else if (value_type == type_flex)
    stuff_flex(where, buf);
  else
    xlerror("Illegal result type specified", value_type);
  return where;
}

int dataglove_close(fd)
int fd;
{
  s_instances[fd].obj = NULL;
  s_instances[fd].device = NIL;
  s_instances[fd].parameter_list = NIL;
  s_instances[fd].available_results = NIL;
  return close(fd);
}

/* calibrates the Dataglove

   blocks for n seconds, during which time the user
   should make the standard set of gestures to calibrate the 
   Dataglove.  fills in the buffer given with the calibration record */

static int dataglove_get_calibration(fd, buf, n)
int fd;
unsigned char *buf;
int n;
{
  int i, j;
  float sc;
  unsigned char flexmin[10], flexmax[10];
  long t;
  unsigned char b[20];

  /* initialize the min and max table */

  for(i = 0; i < 10; i++)
  {
    flexmin[i] = 255;
    flexmax[i] = 0;
  }

  /* tell the dataglove to send raw angles */

  b[0] = 0x24;
  b[1] = 0x57;
  if (serial_write(fd, b, 2) < 0)
    xlstr_error("Dataglove Calibrate: Raw Angle Command Write Error: ");

  /* read the dataglove for a while */

  for(t = serial_msecs(); (serial_msecs() - t) <= (n * 1000);)
  {
    serial_vmin(fd, 14);
    if (serial_write(fd, dataglove_get_flex, 3) < 0)
      xlstr_error("Dataglove Calibrate: Read Raw Angle Command Write Error: ");
    if ((n = serial_timeout_read(fd, b, 14, TIMEOUT)) != 14)
      xlnstr_error(
	 "Dataglove Calibrate Raw Angle Read Error (read %d bytes of 6): ", n);
      
    for(i = 0; i < 10; i++)
    {
      if (b[i+4] > flexmax[i])
	flexmax[i] = b[i+4];
      if (b[i+4] < flexmin[i])
	flexmin[i] = b[i+4];
    }
  }

  /* done reading raw flex; reset to calibrated angles */

  b[0] = 0x24;
  b[1] = 0x52;
  if (serial_write(fd, b, 2) < 0)
      xlstr_error("Dataglove Reset Calibrated Angle Command Write Error: ");
    

  /* generate the calibration table */

  buf[0] = 0x24;
  buf[1] = 0x56;
  buf[2] = 0xff;

  for(i = 0; i < 10; i++)
  {
    /* the header for each flex joint */

    buf[(259*i) + 3] = 0x24;
    buf[(259*i) + 4] = 0x50;
    buf[(259*i) + 5] = 0x81 + i;

    /* fill the bottom of the lookup table with zeros */

    for(j = 0; j < flexmin[i]; j++)
	buf[(259*i) + 6 + j] = 0;

    /* the active area of the lookup table */
    
    sc = (100.0 / (flexmax[i] - flexmin[i]));
    for( ; j <= flexmax[i]; j++)
 	buf[(259*i) + 6 + j] = (j - flexmin[i]) * sc;

    /* the top of the lookup table gets 100's */

    for( ; j < 256; j++)
      buf[(259*i) + 6 + j] = 100;
  }

  return 0;
}
