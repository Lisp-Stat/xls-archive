/* xlmatrix.c

   Fran Taylor, HITL, Seattle */

#include <stdio.h>
#include <math.h>

#include "xlisp.h"

#define m_float(m, i, j) getflonum(getelement(m, (i * 4) + j))

/* this is a C interface to matrix multiply of XLisp matrices */

/* this routine keeps the result separate so that you can do:
   cmatmul(x, x, n) */
   
void cmatmul(r, a, b)
LVAL r, a, b;
{
  float m[4][4];
  int i, j, k;
  
  for(i = 0; i < 4; i++)
    for(j = 0; j < 4; j++)
      for(m[i][j] = 0.0, k = 0; k < 4; k++)
	m[i][j] += m_float(a, i, k) * m_float(b, k, j);
  for(i = 0; i < 4; i++)
    for(j = 0; j < 4; j++)
      m_float(r, i, j) = m[i][j];
}

LVAL matmul()
{
  LVAL r, a, b;
  int i;
  r = xlgavector();
  a = xlgavector();
  b = xlgavector();

#ifdef DEBUG
#ifdef HAVE_GETSZ
  if ((getsz(a) != 16) || (getsz(b) != 16) || (getsz(r) != 16)
    return NIL;
#endif
  for(i = 0; i < 16; i++)
    if (!floatp(getelement(r, i)) || !floatp(getelement(a, i)) ||
	!floatp(getelement(b, i)))
      return NIL;
#endif

  cmatmul(r, a, b);
  return r;
}
