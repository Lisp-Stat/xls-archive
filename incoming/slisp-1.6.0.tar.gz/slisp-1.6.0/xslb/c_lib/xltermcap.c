/* xltermcap.c

   Fran Taylor, HITL, Seattle */

#include "xlisp.h"
#undef getenv

#include <stdio.h>

extern char *getenv();

extern LVAL true;
extern LVAL s_unbound;

static char bp[1024]; /* termcap entry */
static char mv[1024], cl[1024], ce[1024]; /* termcap strings */

static terminit = 0;

LVAL cgoto();
LVAL cleos();
LVAL cleol();
LVAL xlsleep();

#ifdef JDP_REDEFINED_FOR_SKANDHA_INTERFACE
void termcap_install_prims()
{
  char *ptr;
  char **h;
  char str[256];

  /* initialize termcap */

  if (tgetent(bp, getenv("TERM")) == 1)
  {
    terminit = 1;

    bzero(cl, 1024);
    ptr = cl;
    h = &ptr;
    tgetstr("cd", h);
    ptr = mv;
    tgetstr("cm", h);
    ptr = ce;
    tgetstr("ce", h);
  }

  /* stuff in our prims */

  DEFINE_SUBR("TERMCAP-MOVE-CURSOR", cgoto);
  DEFINE_SUBR("TERMCAP-CLEAR-EOS", cleos);
  DEFINE_SUBR("TERMCAP-CLEAR-EOL", cleol);
  DEFINE_SUBR("SLEEP", xlsleep);
}
#else
void termcap_init()
{
  char *ptr;
  char **h;
  char str[256];

  /* initialize termcap */

  if (tgetent(bp, getenv("TERM")) == 1)
  {
    terminit = 1;

    bzero(cl, 1024);
    ptr = cl;
    h = &ptr;
    tgetstr("cd", h);
    ptr = mv;
    tgetstr("cm", h);
    ptr = ce;
    tgetstr("ce", h);
  }
}
#endif

static int pc(c)
char c;
{
  putchar(c);
}

LVAL xlsleep()
{
  int n = 1;

  if (moreargs())
    n = getfixnum(xlgafixnum());
  xllastarg();
  sleep(n);
  return true;
}

LVAL cgoto()
{
  int x, y;

  if (!terminit)
    return NIL;
  x = getfixnum(xlgafixnum());
  y = getfixnum(xlgafixnum());
  xllastarg();
  tputs(tgoto(mv, x, y), 1, pc);
  return true;
}

LVAL cleos()
{
  if (!terminit)
    return NIL;
  
  xllastarg();
  tputs(cl, 1, pc);
  return true;
}

LVAL cleol()
{
  if (!terminit)
    return NIL;
  xllastarg();
  tputs(ce, 1, pc);
  return true;
}

