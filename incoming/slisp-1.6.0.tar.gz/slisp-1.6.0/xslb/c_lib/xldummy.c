/* xldummy.c

   by Fran Taylor, at the HITLab, Seattle

   Copyright (C) 1992  Human Interface Technology Lab, Seattle

   Xlisp interface to Dummy

   This code by default does NO error checking, for speed,
   If you want full error checking, compile with -DDEBUG */

#include <stdio.h>
#include <math.h>

#include "xlisp.h"
#include "xlsensor.h"
#include "seriallib.h"

int dummy_open();
void dummy_init();
int dummy_open();
LVAL dummy_get();
LVAL dummy_put();
LVAL dummy_data_descriptor();
LVAL dummy_read();
int dummy_close();

sensor_object dummy =
{
  "Dummy", dummy_init, dummy_open, dummy_get, dummy_put, 
  dummy_data_descriptor, dummy_read, dummy_close, NIL, NULL};

void dummy_init()
{
  LVAL r, s;
  char buf[80];

  dummy.speed_list = NIL;
  dummy.symbol = xlenter("DUMMY");
}

int dummy_open(port, speed, config)
char *port;
int speed;
char *config;
{
  int fd, n;
  LVAL lst, s, t;

  /* have to get an fd from somewhere! */

  fd = dup(fileno(stdin));

  /* the output specifier list */

  s_instances[fd].available_results = consa(type_point);
  rplacd(s_instances[fd].available_results, t = consa(type_quaternion));
  rplacd(t, s = consa(type_pt_quaternion));
  rplacd(s, t = consa(type_matrix));

  return fd;  
}

LVAL dummy_put(fd, n, param, val)
int fd;
LVAL param, val;
{
  xlerror("Illegal parameter", param);
}

LVAL dummy_get(n)
int n;
{
  int fd;
  LVAL arg2;

  if (n > FD_SETSIZE)
  {
    /* this is a data output descriptor */

    n -= FD_SETSIZE;
    fd = obj[n].fd;
    arg2 = xlgasymbol();
    xllastarg();
    xlerror("Illegal symbol for data output descriptor", arg2);
  }
  else
  {
   /* this is a file descriptor */
    
    fd = n;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_parameters)
      return NIL;
    else if (arg2 == type_list)
      return s_instances[fd].available_results;
    else if (arg2 == s_no_sensors)
      return cvfixnum(1);
    else
      xlerror("Illegal symbol for file descriptor", arg2);
  }
  return true;
}

LVAL dummy_data_descriptor(fd)
int fd;
{
  LVAL type;
  int ind, n;

  type = xlgasymbol();
  if (memberx(type, s_instances[fd].available_results) == FALSE)
    xlerror("Illegal output type requested", type);

  if (moreargs())
    ind = getfixnum(xlgafixnum());
  else
    ind = 1;
  xllastarg();

  if (ind != 1)
    xlerror("Illegal index", cvfixnum(ind));

  /* pick out a data descriptor slot */
  
  if ((n = find_empty_obj()) == -1)
    xlerror("Out of data descriptors", s_unbound);
  
  /* add this item to the list of things that we ask the device for */

  obj[n].fd = fd;
  obj[n].read = (s_instances[fd].obj)->read;
  obj[n].value_type = type;
  obj[n].val_index = ind;
  return cvfixnum(n + FD_SETSIZE);
}

/* this function should be all-out speed optimized! */

LVAL dummy_read(fd, value_type, value_index, where)
int fd;
LVAL value_type;
int value_index;
LVAL where;
{
  unsigned char buf[20];
  int n;

  /***** user wants points *****/

  if (value_type == type_point)
  {
#ifdef DEBUG
    if (!triplep(where))
      xlerror("Destination must be triple", where);
#endif
    
    v_float(where, 0) = 0.0;
    v_float(where, 1) = 0.0;
    v_float(where, 2) = 0.0;
    return where;
  }

  /****** user wants quaternions ******/

  else if (value_type == type_quaternion)
  {
    LVAL qv;

#ifdef DEBUG
    if (!quaternionp(where))
      xlerror("Destination must be quaternion", where);
#endif

    qv = getelement(where, 1);
    v_float(where, 0) = 0.0;
    v_float(qv, 0) =    0.0;
    v_float(qv, 1) =    0.0;
    v_float(qv, 2) =    0.0;
    return where;
  }

  /****** user wants points and quaternions ******/

  else if (value_type == type_pt_quaternion)
  {
    LVAL pt, q, qv;

#ifdef DEBUG
    if (!pt_quatp(where))
      xlerror("Destination must be point-quaternion pair", where);
#endif

    pt = getelement(where, 0);
    q = getelement(where, 1);
    qv = getelement(q, 1);

    v_float(pt, 0) = 0.0;
    v_float(pt, 1) = 0.0;
    v_float(pt, 2) = 0.0;
    
    v_float(q, 0) =  0.0;
    v_float(qv, 0) = 1.0;
    v_float(qv, 1) = 0.0;
    v_float(qv, 2) = 0.0;

    return where;
  }

  /****** user wants matrix ******/

  else if (value_type == type_matrix)
  {
#ifdef DEBUG
    if (!matrixp(where))
      xlerror("Destination must be matrix", where);
#endif

    m_float(where, 0, 0) = 1.0;
    m_float(where, 0, 1) = 0.0;
    m_float(where, 0, 2) = 0.0;
    m_float(where, 0, 3) = 0.0;

    m_float(where, 1, 0) = 0.0;
    m_float(where, 1, 1) = 1.0;
    m_float(where, 1, 2) = 0.0;
    m_float(where, 1, 3) = 0.0;

    m_float(where, 2, 0) = 0.0;
    m_float(where, 2, 1) = 0.0;
    m_float(where, 2, 2) = 1.0;
    m_float(where, 2, 3) = 0.0;
  
    m_float(where, 3, 0) = 0.0;
    m_float(where, 3, 1) = 0.0;
    m_float(where, 3, 2) = 0.0;
    m_float(where, 3, 3) = 1.0;
    return where;
  }
  else
    xlerror("Illegal result type specified", value_type);
}

int dummy_close(fd)
{
  s_instances[fd].obj = NULL;
  s_instances[fd].device = NIL;
  s_instances[fd].parameter_list = NIL;
  s_instances[fd].available_results = NIL;
  return close(fd);
}

