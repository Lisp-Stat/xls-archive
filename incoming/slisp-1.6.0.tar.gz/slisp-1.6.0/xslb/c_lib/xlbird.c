/* xlbird.c

   by Fran Taylor, at the HITLab, Seattle

   Copyright (C) 1992  Human Interface Technology Lab, Seattle

   Xlisp interface to Bird

   This code by default does NO error checking, for speed,
   If you want full error checking, compile with -DDEBUG */

#include <stdio.h>
#include <math.h>

#include "xlisp.h"
#include "xlsensor.h"
#include "seriallib.h"

extern char *sys_errlist[];

/* our private flags */

#define ORIGIN 1
#define BORESIGHT 2

#define TIMEOUT 2 /* be a sport */

#define BSIZ 132

#define bird_int_value(buf, n) ((short) ((buf)[(n)] | ((buf)[(n)+1] << 8)))

#define bird_angle_value(buf, n) (((float) bird_int_value(buf, n)) * \
				  (M_PI / 32768.0))

#define bird_disp_value(buf, n) (((float) bird_int_value(buf, n)) * \
				 (72.0 / 32768.0))
				 
int bird_open();
void bird_init();
int bird_open();
LVAL bird_get();
LVAL bird_put();
LVAL bird_data_descriptor();
LVAL bird_read();
int bird_close();

sensor_object bird =
{
  "Bird", bird_init, bird_open, bird_get, bird_put, 
  bird_data_descriptor, bird_read, bird_close, NIL, NULL};

static void get_bird(fd, buf)
int fd;
char *buf;
{
  int n;

  if (serial_write(fd, "B", 1) < 0)
    xlstr_error("Bird Read Data Command Write Error: ");
  if ((n = serial_timeout_read(fd, buf, 12, TIMEOUT)) != 12)
    xlnstr_error("Bird Data Read Error (read %d bytes of 12): ", n);

#ifdef DEBUG
  if (!(buf[0] & 0x80))
    xlerror("Bird Read Data Garbled", s_unbound);
  for(n = 1; n < 12; n++)
    if (buf[n] & 0x80)
      xlerror("Bird read Data Garbled", s_unbound);
#endif
}

static void get_quaternion(buf, qw, qx, qy, qz)
char *buf;
float *qw, *qx, *qy, *qz;
{
  euler_to_quaternion(qw, qx, qy, qz, bird_angle_value(buf, 10),
		      bird_angle_value(buf, 8), bird_angle_value(buf, 6));
}

static void get_point(buf, x, y, z)
char *buf;
float *x, *y, *z;
{
  *x = bird_disp_value(buf, 0);
  *y = bird_disp_value(buf, 2);
  *z = bird_disp_value(buf, 4);
}

void bird_init()
{
  LVAL r, s;
  char buf[80];

  bird.speed_list = cons_fixnum(300);
  rplacd(bird.speed_list, s = cons_fixnum(1200));
  rplacd(s, r = cons_fixnum(2400));
  rplacd(r, s = cons_fixnum(4800));
  rplacd(s, r = cons_fixnum(9600));
  rplacd(r, s = cons_fixnum(19200));
  bird.symbol = xlenter("BIRD");

}

int bird_open(port, speed, config)
char *port;
int speed;
char *config;
{
  int fd, n;
  char ch;
  char buf[BSIZ];
  LVAL lst, s, t;
  FILE *f;

  if (!port)
    xlerror("Bird Open: port must be specified", s_unbound);
  if (!speed)
    xlerror("Bird Open: speed must be specified", s_unbound);
  
  /* open the port */

  if ((fd = serial_open(port, speed, 8, 1, TIMEOUT)) < 0)
    xlstr_error("Bird Port Open Error: ");

  /* transmit the autobaud character */

  if (serial_write(fd, " ", 1) != 1)
    xlstr_error("Bird Transmit Autobaud Character Error: ");
  sleep(1);

  /* get the software rev no from the Bird */
  
  serial_vmin(fd, 2);

  buf[0] = 'O';
  buf[1] = 0x01;
  if (serial_write(fd, buf, 2) < 0)
    xlstr_error("Bird Examine Rev. No. Write Error: ");

  if ((n = serial_timeout_read(fd, buf, 2, TIMEOUT)) != 2)
    xlnstr_error("Bird Examine rev. No. Read Error (%d bytes of 2 read): ", n);
  
  /* download the configuration file if one is specified */

  if (config && config[0])
  {
    if ((f = fopen(config, "r")) == NULL)
    {
      serial_close(fd);
      return -1;
    }
  
    /* transmit the configuration file
       read ASCII numbers, one per line, and transmit
       as binary bytes to the Bird */

    for(; fgets(buf, BSIZ, f); )
    {
      ch = (unsigned char) atoi(buf);
      if (serial_write(fd, ch, 1) < 0)
	xlstr_error("Bird Configuration File Write Error: ");
    }
    close(f);
  }

  /* initialize the device - point/angle output, far range */
  
  buf[0] = 'P';
  buf[1] = 0x03;
  buf[2] = 0x01;
  buf[3] = 0x00;
  buf[4] = 'Y';
  if (serial_write(fd, buf, 5) != 5)
    xlstr_error("Bird Position/Angle Command Write Error: ");
  
  serial_vmin(fd, 12);

  /* the parameter list */

  s_instances[fd].parameter_list = xlenter("BIRD-PARAMETER-LIST");
  setvalue(s_instances[fd].parameter_list, consa(s_hemisphere));
  
  /* the output specifier list */

  s_instances[fd].available_results = consa(type_point);
  rplacd(s_instances[fd].available_results, t = consa(type_quaternion));
  rplacd(t, s = consa(type_pt_quaternion));
  rplacd(s, t = consa(type_matrix));

  return fd;  
}

LVAL bird_put(fd, n)
int fd, n;
{
  LVAL param, val;
  int x, y, z;
  char buf[80];

  param = xlgasymbol();
  if (param == s_hemisphere)
  {
    if (!memberx(val, sensor_hemisphere_list))
      xlerror("Illegal hemisphere", val);
	
    buf[0] = 'L';

    if ((val == hemisphere_forward) || (val == hemisphere_aft))
      buf[1] = 0x00;
    else if (val == hemisphere_left)
      buf[1] = 0x0c;
    else
      buf[1] = 0x06;

    if  ((val == hemisphere_aft) || (val == hemisphere_upper) ||
	 (val == hemisphere_left))
      buf[2] = 0x01;
    else
      buf[2] = 0x00;

    /* write the hemisphere command to the Bird */

    if (serial_write(fd, buf, 3) != 3)
      xlerror("Communications error", s_unbound);
    obj[n].hemisphere = val;
    return val;
  }
  else if (param == s_boresight)
  {
    if (moreargs())
    {
      LVAL q, qv;
      q = xlgavector();
#ifdef DEBUG
      if (!quaternionp(q))
	xlerror("Boresight argument must be quaternion");
#endif
	xllastarg();
	qv = getelement(q, 1);
	obj[n].Qw = -v_float(q, 0);
	obj[n].Qx = v_float(qv, 0);
	obj[n].Qy = v_float(qv, 1);
	obj[n].Qz = v_float(qv, 2);
    }
    else
    {
      char buf[BSIZ];
      get_bird(fd, buf);
      get_quaternion(buf, &(obj[n].Qw), &(obj[n].Qx),
		     &(obj[n].Qy), &(obj[n].Qz));
      obj[n].Qw = -obj[n].Qw;
    }
    obj[n].flags |= BORESIGHT;
    return true;
  }
  else if (param == s_unboresight)
  {
    xllastarg();
    obj[fd].flags &= ~BORESIGHT;
    return true;
  }
  else if (param == s_origin)
  {
    if (moreargs())
    {
      LVAL p;
      p = xlgavector();
#ifdef DEBUG
      if (!triplep(p))
	xlerror("Origin argument must be point", p);
#endif
      xllastarg();
      obj[n].x = v_float(p, 0);
      obj[n].y = v_float(p, 1);
      obj[n].z = v_float(p, 2);
    }
    else
    {
      char buf[BSIZ];
      get_bird(fd, buf);

      obj[n].x = bird_disp_value(buf, 0); /* bird X */
      obj[n].y = bird_disp_value(buf, 2); /* bird Y */
      obj[n].z = bird_disp_value(buf, 4); /* bird Z */
    }
    obj[n].flags |= ORIGIN;
    return true;
  }
  else if (param == s_reset_origin)
  {
    obj[fd].flags &= ~ORIGIN;
    return true;
  }
  else
    xlerror("Illegal parameter", param);
}

LVAL bird_get(n)
int n;
{
  int fd;
  LVAL arg2;

  if (n > FD_SETSIZE)
  {
    /* this is a data output descriptor */

    n -= FD_SETSIZE;
    fd = obj[n].fd;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_hemisphere)
      return obj[n].hemisphere;
    else if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else
      xlerror("Illegal symbol for data output descriptor", arg2);
  }
  else
  {
   /* this is a file descriptor */
    
    fd = n;
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_parameters)
      return s_instances[fd].parameter_list;
    else if (arg2 == type_list)
     return s_instances[fd].available_results;
    else if (arg2 == s_no_sensors)
      return cvfixnum(1);
    else
      xlerror("Illegal symbol for file descriptor", arg2);
  }
  return true;
}

LVAL bird_data_descriptor(fd)
int fd;
{
  LVAL type;
  int ind, n;

  type = xlgasymbol();
  if (memberx(type, s_instances[fd].available_results) == FALSE)
    xlerror("Illegal output type requested", type);

  if (moreargs())
    ind = getfixnum(xlgafixnum());
  else
    ind = 1;
  xllastarg();

  if (ind != 1)
    xlerror("Illegal index", cvfixnum(ind));

  /* pick out a data descriptor slot */
  
  if ((n = find_empty_obj()) == -1)
    xlerror("Out of data descriptors", s_unbound);
  
  /* add this item to the list of things that we ask the device for */

  obj[n].fd = fd;
  obj[n].read = (s_instances[fd].obj)->read;
  obj[n].value_type = type;
  obj[n].val_index = ind;
  obj[n].hemisphere = hemisphere_forward;
  obj[n].flags = 0;
  return cvfixnum(n + FD_SETSIZE);
}

/* this function should be all-out speed optimized! */

LVAL bird_read(n, where)
int n;
LVAL where;
{
  unsigned char buf[20];
  int fd;
  float x, y, z, qw, qx, qy, qz;
  LVAL value_type;

  value_type = obj[n].value_type;
  fd = obj[n].fd;

  get_bird(fd, buf);

  if ((value_type == type_quaternion) || (value_type == type_pt_quaternion) ||
      (value_type == type_matrix))
    {
      get_quaternion(buf, &qw, &qx, &qy, &qz);
      if (obj[n].flags & BORESIGHT)
	concatenate_quaternions(&qw, &qx, &qy, &qz, 
				obj[n].Qw, obj[n].Qx, obj[n].Qy, obj[n].Qz,
				qw, qx, qy, qz);
    }
  
  if ((value_type == type_pt_quaternion) || (value_type == type_matrix) ||
      (value_type == type_point))
  {
    get_point(buf, &x, &y, &z);
    if (obj[n].flags & ORIGIN)
      concatenate_translations(&x, &y, &z, x, y, z,
			       obj[n].x, obj[n].y, obj[n].z);
  }

  if (value_type == type_point)
    stuff_point(where, x, y, z);
  else if (value_type == type_quaternion)
    stuff_quaternion(where, qw, qx, qy, qz);
  else if (value_type == type_pt_quaternion)
    stuff_pt_quaternion(where, qw, qx, qy, qz, x, y, z);
  else if (value_type == type_matrix)
    stuff_matrix(where, qw, qx, qy, qz, x, y, z);
  else
    xlerror("Illegal result type specified", value_type);
  return where;
}

int bird_close(fd)
{
  s_instances[fd].obj = NULL;
  s_instances[fd].device = NIL;
  s_instances[fd].parameter_list = NIL;
  s_instances[fd].available_results = NIL;
  return close(fd);
}

