/* For Skandha4 interface, moved the below to ../c/xslb.[c|h] */

/* xlsensor.c

   by Fran Taylor, at the HITLab, Seattle

   Copyright (C) 1992  Human Interface Technology Lab, Seattle

   Xlisp interface to SensorLib

   NOTE: there are two different kinds of fixnums returned by sensorlib
   one is a file descriptor, and the other is a data output descriptor.

   Since the maximum possible file descriptor value is FD_SETSIZE - 1, if
   we add FD_SETSIZE to the data output descriptors, then we can easily
   tell the difference between them */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <math.h>
/* this should be in <errno.h>! */

extern char *sys_errlist[];

#include "xlisp.h"
#include "xlsensor.h"

#define device_name_max_length 80
#define device_port_max_length 80
#define total_data_objects 256
#define max_no_devices 20

/* here are the valid output objects:

   matrix (a 4 x 4) (actually a vector of length 16, because Xlisp
   ony supports vectors)

   6d (x, y, z, Rx, Ry, Rz) (a vector of length 6)(don't use these; 
   they're grody)
  
   pq (x, y, z, qw, qx, qy, qz) (a point and a unit quaternion)

   flexes (variable length, depending on the sensor.  Datagloves
   return 10 values; Powergloves return 8)

   buttons (a bit field, with bit 0 set for the first button, etc)

   knobs (a vector, with an entry for each knob)

   analog inputs (value returned is in volts)

   MIDI channel (haven't figured this one out yet!) */

/* global data */

static sensor_object *find_device_record_from_symbol();

/* these are our variable keys for sensor-open */

LVAL k_speed, k_port, k_device, k_config;

/* the list of available devices */

LVAL device_symbol_list;

/* the list of available types */

LVAL type_list, type_matrix, type_point, type_euler_angles, type_quaternion,
  type_pt_quaternion, type_pt_euler, type_flex, type_buttons,
  type_knobs, type_volts, type_composite;

/* hemispheres */

LVAL sensor_hemisphere_list, hemisphere_forward, hemisphere_aft,
  hemisphere_upper, hemisphere_lower, hemisphere_left, hemisphere_right;

/* miscellaneous symbols */

LVAL s_parameters, s_hemisphere, s_speed_list, calibrate, s_boresight;
LVAL s_unboresight, s_no_sensors, s_origin, s_reset_origin;

/* one of these for each type of device */

sensor_object *device_list[max_no_devices];

/* one of these for each physical device, indexed by file descriptor */

sensor_instance s_instances[FD_SETSIZE];

/* one of these for each data item, indexed by data descriptor */

data_object obj[total_data_objects];

static num_devices = 0;

#if JDP_MOVED_TO_XSLB_C_H
void sensor_install_prims()
{
  DEFINE_SUBR("SENSOR-INIT", sensor_init);
  DEFINE_SUBR("SENSOR-GET", sensor_get);
  DEFINE_SUBR("SENSOR-OPEN", sensor_open);
  DEFINE_SUBR("SENSOR-PUT", sensor_put);
  DEFINE_SUBR("SENSOR-DATA-DESCRIPTOR", sensor_data_descriptor);
  DEFINE_SUBR("SENSOR-CLOSE-DATA-DESCRIPTOR", sensor_close_data_descriptor);
  DEFINE_SUBR("SENSOR-READ", sensor_read);
  DEFINE_SUBR("SENSOR-CLOSE", sensor_close);
}
#endif

/* this is also in xleval.c, but it's declared static there */
/* and we hack it to do eq instead of equal, so comparing fixnums works. */

int memberx(x,list)
LVAL x,list;
{
    for (; consp(list); list = cdr(list))
      if (eql(x, car(list)))
	return 1;
    return 0;
}

/* this must be called at initialization */

LVAL sensor_init()
{
  int i;
  LVAL s, t;
  sensor_object **d;

  xllastarg();

  /* don't do it twice! */

  if (num_devices)
    return true;

  /* make a list of the devices */

  for(i = 0; i < max_no_devices; i++)
    device_list[i] = NULL;

  add_device(fastrak);
  add_device(dataglove);
  add_device(polhemus);
  add_device(l2d6d);
  add_device(bird);
  add_device(knobs);
  add_device(dummy);

  /* initialize the drivers */

  for(d = device_list; *d; d++)
    ((**d).init)();

  /* make a list of the devices */

  device_symbol_list = xlenter("SENSOR-DEVICE-LIST");
  setvalue(device_symbol_list, s = consa(fastrak.symbol));
  rplacd(s, t = consa(dataglove.symbol));
  rplacd(t, s = consa(polhemus.symbol));
  rplacd(s, t = consa(l2d6d.symbol));
  rplacd(t, s = consa(bird.symbol));
  rplacd(s, t = consa(knobs.symbol));
  rplacd(t, s = consa(dummy.symbol));

  /* these are the hemispheres */

  sensor_hemisphere_list = xlenter("SENSOR-HEMISPHERE-LIST");
  setvalue(sensor_hemisphere_list,
	   s = consa(hemisphere_forward = xlenter("FORWARD")));
  rplacd(s, t = consa(hemisphere_aft = xlenter("AFT")));
  rplacd(t, s = consa(hemisphere_upper = xlenter("UPPER")));
  rplacd(s, t = consa(hemisphere_lower = xlenter("LOWER")));
  rplacd(t, s = consa(hemisphere_left = xlenter("LEFT")));
  rplacd(s, t = consa(hemisphere_right = xlenter("RIGHT")));
	 
  /* these are the keys for sensor-open */

  k_speed = xlenter(":SPEED");
  k_port = xlenter(":PORT");
  k_device = xlenter(":DEVICE");
  k_config = xlenter(":CONFIG");

  /* add miscellaneous symbols */

  s_parameters = xlenter("PARAMETERS");
  s_hemisphere = xlenter("HEMISPHERE");
  s_speed_list = xlenter("SPEED-LIST");
  calibrate = xlenter("CALIBRATE");
  s_boresight = xlenter("SET-BORESIGHT");
  s_unboresight = xlenter ("RESET-BORESIGHT");
  s_no_sensors = xlenter("NUM-SENSORS");
  s_origin = xlenter("ORIGIN");
  s_reset_origin = xlenter("RESET-ORIGIN");

  /* these are the type specifiers for sensor-data-descriptor */

  type_list = xlenter("OUTPUT-TYPE-LIST");
  setvalue(type_list, s = consa(type_matrix = xlenter("MATRIX")));
  rplacd(s, t = consa(type_point = xlenter("POINT")));
  rplacd(t, s = consa(type_euler_angles = xlenter("EULER-ANGLES")));
  rplacd(s, t = consa(type_quaternion = xlenter("QUATERNION")));
  rplacd(t, s = consa(type_pt_quaternion = xlenter("PT-QUATERNION")));
  rplacd(s, t = consa(type_pt_euler = xlenter("PT-EULER")));
  rplacd(t, s = consa(type_flex = xlenter("FINGER-FLEX")));
  rplacd(s, t = consa(type_buttons = xlenter("BUTTONS")));
  rplacd(t, s = consa(type_knobs = xlenter("KNOBS")));
  rplacd(s, t = consa(type_volts = xlenter("VOLTS")));
  rplacd(t, s = consa(type_composite = xlenter("COMPOSITE")));
    
  /* initialize the static data */

  for(i = 0; i < FD_SETSIZE; i++)
    s_instances[i].device = NIL;

  for(i = 0; i < total_data_objects; i++)
    obj[i].fd = -1;

  return device_symbol_list;
}

/* the general function to return state information */

LVAL sensor_get()
{
  LVAL arg1, arg2, arg3;
  sensor_object *s;
  int n, fd;

  if (num_devices == 0)
    xlerror("Sensors not initialized; call sensor-init", s_unbound);

  arg1 = xlgetarg();

  /* if it's a symbol, he's asking about the generic device */

  if (symbolp(arg1))
  {
    if ((s = find_device_record_from_symbol(arg1)) == NULL)
      xlerror("Illegal device symbol", arg1);
    arg2 = xlgasymbol();
    xllastarg();
    if (arg2 == s_speed_list)
      return s->speed_list;
    else
      xlerror("Illegal request for device symbol", arg2);
  }

  /* if it's a fixnum, let the driver handle it */

  else if (fixp(arg1))
  {
    n = getfixnum(arg1);

    if (n >= FD_SETSIZE)
      fd = obj[n - FD_SETSIZE].fd;
    else
      fd = n;
    return (s_instances[fd].obj)->get(n);
  }
  else
    xlerror("First argument must specify a device", arg1);
}

LVAL sensor_open()
{
  LVAL dev, arg, s_port, s_speed, s_device, speed_list;
  char *port, *config;
  sensor_object *s;
  int found, fd, device, speed;

  if (num_devices == 0)
    xlerror("Sensors not initialized; call sensor-init", s_unbound);

  /* get and check the device symbol */
  
  dev = NIL;
  xlgetkeyarg(k_device, &dev);
  
  if (!symbolp(dev))
    xlerror("Device parameter must be symbol", dev);

  if ((s = find_device_record_from_symbol(dev)) == NULL)
    xlerror("Illegal device symbol", dev);

  /* get the port string */

  arg = NIL;
  xlgetkeyarg(k_port, &arg);
  if (arg != NIL)
    port = (char *) getstring(arg);
  else
    port = NULL;

  /* get the speed */

  arg = NIL;
  xlgetkeyarg(k_speed, &arg);
  if (fixp(arg))
  {
    speed_list = xleval(s->speed_list);
    if (memberx(arg, speed_list))
      speed = getfixnum(arg);
    else
      xlerror("Illegal speed for device", arg);
  }
  else
    speed = 19200;

  /* get the configuration file string */

  arg = NIL;
  xlgetkeyarg(k_config, &arg);
  if (stringp(arg))
    config = (char *) getstring(arg);
  else
    config = NULL;

  /* open the device */

  if ((fd = (s->open)(port, speed, config)) == -1)
    xlerror(sys_errlist[errno], s_unbound);

  s_instances[fd].obj = s;
  s_instances[fd].device = dev;
  
  /* return the file descriptor */

  return cvfixnum(fd);
}

LVAL sensor_put()
{
  LVAL arg, sym, val;
  int n, fd;

  if (num_devices == 0)
    xlerror("Sensors not initialized; call sensor-init", s_unbound);

  arg = xlgetarg();
  if (fixp(arg))
  {
    if ((n = getfixnum(arg)) >= FD_SETSIZE)
    {
      /* it's a data value descriptor */

      n -= FD_SETSIZE;
      fd = obj[n].fd;

      /* call the device's put method */

      return ((s_instances[fd].obj)->put)(fd, n);
    }
    else
      xlerror("File descriptor not allowed here", arg);
  }
  else
    xlerror("Illegal argument", arg);
}

LVAL sensor_data_descriptor()
{
  int fd;

  if (num_devices == 0)
    xlerror("Sensors not initialized; call sensor-init", s_unbound);

  /* first arg must be a valid file descriptor */

  fd = getfixnum(xlgafixnum());
  if ((fd < 0) || (fd > FD_SETSIZE) || (s_instances[fd].device == NIL))
    xlerror("Invalid File Descriptor", cvfixnum(fd));

  return ((s_instances[fd].obj)->data_descriptor)(fd);
}

/* this function should be speed-optimized! */

LVAL sensor_read()
{
  int data_descriptor;
  LVAL data_buffer;

  if (num_devices == 0)
    xlerror("Sensors not initialized; call sensor-init", s_unbound);

  /* get the two arguments: the data descriptor, and the place to
     stuff the results */

  data_descriptor = getfixnum(xlgafixnum()) - FD_SETSIZE;
  data_buffer = xlgetarg();
  xllastarg();

  /* call the read routine for the device, passing the values associated
     with the data descriptor, and the results object */
  
  return (obj[data_descriptor].read)(data_descriptor, data_buffer);
}

  /* tell the system that we're all done with the data stream */

LVAL sensor_close_data_descriptor()
{
  int data_item;

  if (num_devices == 0)
    xlerror("Sensors not initialized; call sensor-init", s_unbound);

  data_item = getfixnum(xlgafixnum());
  xllastarg();
  if ((data_item < 0) || (data_item > total_data_objects) ||
      (obj[data_item].fd == -1))
    xlerror("Invalid File Descriptor", cvfixnum(data_item));
  obj[data_item].fd = -1;
}

/* close off comunications with the device */

LVAL sensor_close()
{
  int fd;

  if (num_devices == 0)
    xlerror("Sensors not initialized; call sensor-init", s_unbound);

  fd = getfixnum(xlgafixnum());
  xllastarg();
  if ((fd < 0) || (fd > FD_SETSIZE) || (s_instances[fd].device == NIL))
    xlerror("Invalid File Descriptor", cvfixnum(fd));
  s_instances[fd].device = NIL;
}

static int item_already_there(obj, fd, item_type, item_index)
data_object *obj;
int fd;
LVAL item_type;
int item_index;
{
  int i;
  for(i = 0; i < total_data_objects; i++)
    if ((obj[i].fd == fd) &&
	(obj[i].value_type == item_type) &&
	(obj[i].val_index == item_index))
      return i;
  return -1;
}

int find_empty_obj()
{
  int i;
  for(i = 0; i < total_data_objects; i++)
    if (obj[i].fd == -1)
      return i;
  return -1;
}

static sensor_object *find_device_record_from_symbol(sym)
LVAL sym;
{
  sensor_object **obj;
  int i;

  for(obj = device_list, i = 0; i < num_devices; obj++, i++)
    if (sym == (**obj).symbol)
      return *obj;
  return NULL;  
}

void stuff_point(LVAL where, float x, float y, float z)
{
  v_float(where, 0) = x;
  v_float(where, 1) = y;
  v_float(where, 2) = z;
}

void stuff_quaternion(LVAL where, float qw, float qx, float qy, float qz)
{
  LVAL qv;

#ifdef DEBUG
  if (!quaternionp(where))
    xlerror("Destination must be quaternion", where);
#endif

  qv = getelement(where, 1);
  v_float(where, 0) = qw;
  v_float(qv, 0) = qx;
  v_float(qv, 1) = qy;
  v_float(qv, 2) = qz;
}

void stuff_pt_quaternion(LVAL where, float qw, float qx, float qy, float qz,
			 float x, float y, float z)
{
  LVAL pt, q, qv;

#ifdef DEBUG
    if (!pt_quatp(where))
      xlerror("Destination must be point-quaternion pair", where);
#endif

  pt = getelement(where, 0);
  q = getelement(where, 1);
  qv = getelement(q, 1);

  v_float(pt, 0) = x;
  v_float(pt, 1) = y;
  v_float(pt, 2) = z;
    
  v_float(q, 0)  = qw;
  v_float(qv, 0) = qx;
  v_float(qv, 1) = qy;
  v_float(qv, 2) = qz;
}

void stuff_matrix(LVAL where, float qw, float qx, float qy, float qz,
		  float x, float y, float z)
{
    float x2, y2, z2, wx2, wy2, wz2, xx2, xy2, xz2, yy2, yz2, zz2;

#ifdef DEBUG
    if (!matrixp(where))
      xlerror("Destination must be matrix", where);
#endif

    x2 = qx + qx;
    y2 = qy + qy;
    z2 = qz + qz;
    wx2 = qw * x2;
    wy2 = qw * y2;
    wz2 = qw * z2;
    xx2 = qx * x2;
    xy2 = qx * y2;
    xz2 = qx * z2;
    yy2 = qy * y2;
    yz2 = qy * z2;
    zz2 = qz * z2;

    m_float(where, 0, 0) = 1.0 - yy2 - zz2;
    m_float(where, 0, 1) = xy2 + wz2;
    m_float(where, 0, 2) = xz2 - wy2;
    m_float(where, 0, 3) = 0.0;

    m_float(where, 1, 0) = xy2 - wz2;
    m_float(where, 1, 1) = 1.0 - xx2 - zz2;
    m_float(where, 1, 2) = yz2 + wx2;
    m_float(where, 1, 3) = 0.0;

    m_float(where, 2, 0) = xz2 + wy2;
    m_float(where, 2, 1) = yz2 - wx2;
    m_float(where, 2, 2) = 1.0 - xx2 - yy2;
    m_float(where, 2, 3) = 0.0;

    m_float(where, 3, 0) = x;
    m_float(where, 3, 1) = y;
    m_float(where, 3, 2) = z;
    m_float(where, 3, 3) = 1.0;
}

void pull_point(LVAL where, float *x, float *y, float *z)
{
#ifdef DEBUG
  if (!triplep(where))
    xlerror("Invalid point argument", where);
#endif
  *x = v_float(where, 0);
  *y = v_float(where, 1);
  *z = v_float(where, 2);
}

void pull_quaternion(LVAL where, float *w, float *x, float *y, float *z)
{
  LVAL qv;
#ifdef DEBUG
  if (!quaternionp(where))
    xlerror("Invalid quaternion argument", where);
#endif
  qv = getelement(where, 1);
  *w = v_float(where, 0);
  *x = v_float(qv, 0);
  *y = v_float(qv, 1);
  *z = v_float(qv, 2);
}

void concatenate_quaternions(float *rw, float *rx, float *ry, float *rz, 
			     float aw, float ax, float ay, float az, 
			     float bw, float bx, float by, float bz)
{
  *rw = (aw * bw) - (ax * bx) - (ay * by) - (az * bz);
  *rx = (aw * bx) + (bw * ax) + (ay * bz) - (az * by);
  *ry = (aw * by) + (bw * ay) - (ax * bz) + (az * bx);
  *rz = (aw * bz) + (bw * az) + (ax * by) - (ay * bx);
}

void concatenate_translations(float *rx, float *ry, float *rz,
			      float ax, float ay, float az,
			      float bx, float by, float bz)
{
  *rx = ax + bx;
  *ry = ay + by;
  *rz = az + bz;
}

void euler_to_quaternion(float *qw, float *qx, float *qy, float *qz,
			 float rx, float ry, float rz)
{
  float sx, cx, sy, cy, sz, cz, cxcy, sxcy, cxsy, sxsy;

  rx /= 2.0;
  ry /= 2.0;
  rz /= 2.0;

  sx = sin(rx);
  cx = cos(rx);
  sy = sin(ry);
  cy = cos(ry);
  sz = sin(rz);
  cz = cos(rz);

  cxcy = cx * cy;
  sxcy = sx * cy;
  cxsy = cx * sy;
  sxsy = sx * sy;    

  *qw = (cxcy * cz) + (sxsy * sz);
  *qx = (sxcy * cz) - (cxsy * sz);
  *qy = (cxsy * cz) + (sxcy * sz);
  *qz = (cxcy * sz) - (sxsy * cz);  
}

/* this is needed to handle the way the dataglove picks its euler angles */
void ypr_to_quaternion(float *qw, float *qx, float *qy, float *qz,
		       float rx, float ry, float rz)
{
  float sx, cx, sy, cy, sz, cz, cxcy, sxcy, cxsy, sxsy;

  rx /= 2.0;
  ry /= 2.0;
  rz /= 2.0;

  sx = sin(rx);
  cx = cos(rx);
  sy = sin(ry);
  cy = cos(ry);
  sz = sin(rz);
  cz = cos(rz);

  cxcy = cx * cy;
  sxcy = sx * cy;
  cxsy = cx * sy;
  sxsy = sx * sy;    

  *qw = (cxcy * cz) + (sxsy * sz);
  *qx = -(cxsy * cz) - (sxcy * sz);
  *qy = (cxcy * sz) - (sxsy * cz);  
  *qz = -(sxcy * cz) + (cxsy * sz);
}
