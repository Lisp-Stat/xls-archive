/* xlsensor.h

   by Fran Taylor, at the HITLab, Seattle

   Copyright (C) 1992  Human Interface Technology Lab, Seattle

   Xlisp interface to SensorLib */

#ifndef _XLSENSORH_
#define _XLSENSORH_

/* these should be in xlisp.h */

extern LVAL s_unbound;
extern LVAL true;

/* max no of sensors per device */

#define MAX_SENSORS 5

/* macros to print xlisp error messages */

static errstr[256];

#define str_error(s) (strcpy(errstr, s), strcat(errstr, sys_errlist[errno]))
#define nstr_error(str, n) str_error((sprintf(errstr, str, n), errstr))
#define n2str_error(str, n1, n2) str_error((sprintf(errstr, str, n1, n2), \
					    errstr))

#define xlstr_error(str) xlerror(str_error(str), s_unbound);
#define xlnstr_error(str, n) xlerror(nstr_error(str, n), s_unbound)
#define xln2str_error(str, n1, n2) xlerror(n2str_error(str, n1, n2), s_unbound)

/* macro to add a device to the list */

#define add_device(device) { extern sensor_object device; \
device_list[num_devices++] = &device; }

#define v_float(v, n) getflonum(getelement(v, n))
#define m_float(m, i, j) getflonum(getelement(m, (j * 4) + i))
#define v_fixnum(v, n) cvfixnum(getelement(v, n))

#define cm2in( cm) (cm * 0.393701)
#define in2cm( in) (in * 2.54)

#define cons_fixnum(n) consa(cvfixnum(n))

/* one of these of each type of sensor */

typedef struct sensor_object
{
  char *name;
  void (*init)();
  int (*open)();
  LVAL (*get)(), (*put)(), (*data_descriptor)();
  LVAL (*read)();
  int (*close)();
  LVAL symbol, speed_list;
} sensor_object;

/* one of these for each opened sensor device */

typedef struct sensor_instance
{
  sensor_object *obj;
  LVAL device;
  LVAL parameter_list, available_results;
  int attached, enabled, read, initialized, rcvlen;
  char buf[128];
  long knobval[8];
  unsigned boresight_flags, origin_flags;
  float Qw[MAX_SENSORS], Qx[MAX_SENSORS], Qy[MAX_SENSORS], Qz[MAX_SENSORS];
  float x[MAX_SENSORS], y[MAX_SENSORS], z[MAX_SENSORS];
} sensor_instance;

/* one of these for each data output desired */

typedef struct data_object
{
  int fd;
  LVAL (*read)();
  LVAL value_type;
  int val_index;
  LVAL hemisphere;
  unsigned flags;
  int no_buttons, no_sensors;
  float Qw, Qx, Qy, Qz, x, y, z;
} data_object;

extern LVAL k_speed, k_port, k_device, k_config;
extern LVAL device_symbol_list;
extern LVAL type_list, type_matrix, type_point, type_euler_angles,
  type_quaternion, type_pt_quaternion, type_pt_euler, type_flex,
  type_buttons, type_knobs, type_volts;
extern LVAL sensor_hemisphere_list, hemisphere_forward, hemisphere_aft,
  hemisphere_upper, hemisphere_lower, hemisphere_left, hemisphere_right;
extern LVAL s_parameters, s_hemisphere, s_speed_list, calibrate,
  s_boresight, s_unboresight, s_no_sensors, s_origin, s_reset_origin,
  s_no_buttons;

extern sensor_object *device_list[];

extern sensor_instance s_instances[];

extern data_object obj[];

/* function prototypes */

extern LVAL sensor_init(void);
extern LVAL sensor_get(void);
extern LVAL sensor_open(void);
extern LVAL sensor_put(void);
extern LVAL sensor_data_descriptor(void);
extern LVAL sensor_close_data_descriptor(void);
extern LVAL sensor_read(void);
extern LVAL sensor_close(void);

static int item_already_there(data_object *obj, int fd, 
			      LVAL item_type, int item_index);

int find_empty_obj(void);

static sensor_object *find_device_record_frome_symbol(LVAL sym);

void stuff_point(LVAL where, float x, float y, float z);

void stuff_pt_quaternion(LVAL where, float qw, float qx, float qy, float qz,
			 float x, float y, float z);

void stuff_matrix(LVAL where, float qw, float qx, float qy, float qz,
		  float x, float y, float z);

void pull_point(LVAL where, float *x, float *y, float *z);

void pull_quaternion(LVAL where, float *w, float *x, float *y, float *z);

void concatenate_quaternions(float *rw, float *rx, float *ry, float *rz, 
			     float aw, float ax, float ay, float az, 
			     float bw, float bx, float by, float bz);

void concatenate_translations(float *rx, float *ry, float *rz, 
			      float ax, float ay, float az,
			      float bx, float by, float bz);

void sensor_install_prims(void);

void euler_to_quaternion(float *qw, float *qx, float *qy, float *qz, 
			 float rx, float ry, float rz);

int memberx(LVAL x, LVAL list);

#endif
