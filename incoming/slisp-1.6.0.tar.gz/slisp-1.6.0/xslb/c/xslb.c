/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xslb.c (XSensorLiB.c)
* Description:  Skandha4 interface to HITL sensorLib functions.
* Author:       Jerry Prothero
* Created:      92Jul28
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, Human Interface Technology Laboratory (by Jerry Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* HUMAN INTERFACE TECHNOLOGY LABORATORY AND JERRY PROTHERO DISCLAIM ALL 
* WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS.  IN NO EVENT SHALL HUMAN INTERFACE TECHNOLOGY
* LABORATORY NOR JERRY PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR 
* CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF 
* USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/************************************************************************/
/*                              contents                                */
/*									*/
/*									*/
/*		(generated via "grep '/\*\.' xSensorLib.c")		*/
/************************************************************************/

/************************************************************************/
/*                          history   				        */
/************************************************************************/
/*
 * 92Jul28 jdp	Created.  A simple Skandha4 xlisp wrapper for HITL's 
 *              SensorLib functions.  
 */



#include "../../xcore/c/xlisp.h"

extern LVAL xsendmsg0(); 
extern LVAL sensor_get();
extern LVAL sensor_open();
extern LVAL sensor_put();
extern LVAL sensor_data_descriptor();
extern LVAL sensor_close_data_descriptor();
extern LVAL sensor_read();
extern LVAL sensor_close();

#include <math.h>
#undef getenv
#include <stdlib.h>
/*#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"*/


/*************************************************************************/
/* The below are stubs, which call the functions in the HITL sensor lib: */
/*************************************************************************/



/************************************************************************/
/*.     xslb10_Sensor_Init                                              */ 
/************************************************************************/ 
xslb10_Sensor_Init() { 
    sensor_init();
    termcap_init();
}

/************************************************************************/
/*.     xslb20_Sensor_Get                                               */ 
/************************************************************************/ 
LVAL xslb20_Sensor_Get() { 
    return sensor_get();
}

/************************************************************************/
/*.     xslb30_Sensor_Open                                              */ 
/************************************************************************/ 
LVAL xslb30_Sensor_Open() { 
    return sensor_open();
}

/************************************************************************/
/*.     xslb40_Sensor_Put                                               */ 
/************************************************************************/ 
LVAL xslb40_Sensor_Put() { 
    return sensor_put();
}

/************************************************************************/
/*.     xslb50_Sensor_Data_Descriptor                                   */ 
/************************************************************************/ 
LVAL xslb50_Sensor_Data_Descriptor() { 
    return sensor_data_descriptor();
}

/************************************************************************/
/*.     xslb60_Sensor_Close_Data_Descriptor                             */ 
/************************************************************************/ 
LVAL xslb60_Sensor_Close_Data_Descriptor() { 
    return sensor_close_data_descriptor();
}

/************************************************************************/
/*.     xslb70_Sensor_Read		                                */ 
/************************************************************************/ 
LVAL xslb70_Sensor_Read() {
    return sensor_read();
}

/************************************************************************/
/*.     xslb80_Sensor_Close		                                */ 
/************************************************************************/ 
LVAL xslb80_Sensor_Close() {
    return sensor_close();
}

/* The below are some termcap fns. */

/************************************************************************/
/*.     xslb90_Cgoto			                                */ 
/************************************************************************/ 
LVAL xslb90_Cgoto() {
    return cgoto();
}

/************************************************************************/
/*.     xslba0_Cleos			                                */ 
/************************************************************************/ 
LVAL xslba0_Cleos() {
    return cleos();
}

/************************************************************************/
/*.     xslbb0_Cleol			                                */ 
/************************************************************************/ 
LVAL xslbb0_Cleol() {
    return cleol();
}

/************************************************************************/
/*.     xslbc0_Xlsleep			                                */ 
/************************************************************************/ 
LVAL xslbc0_Xlsleep() {
    return xlsleep();
}


