/* -*-C-*-                                                                   
********************************************************************************
*
* File:         xslb.h (XSensorLiB.h)
* Description:  Skandha4 interface to HITL sensorLib functions.  Adapted
*		    from HITL VEOS interface code written by Fran Taylor.
* Author:       Jerry Prothero
* Created:      92Jul28
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, Human Interface Technology Laboratory (by Jerry Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 1, or (at your option)
*   any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* HUMAN INTERFACE TECHNOLOGY LABORATORY AND JERRY PROTHERO DISCLAIM ALL 
* WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS.  IN NO EVENT SHALL HUMAN INTERFACE TECHNOLOGY
* LABORATORY NOR JERRY PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR 
* CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF 
* USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifdef MODULE_XLINIT_C_XLINIT
/* Code to be executed on program start-up: */
xslb10_Sensor_Init();
#endif

#ifdef MODULE_XLDMEM_H_GLOBALS
extern LVAL xslb20_Sensor_Get();
extern LVAL xslb30_Sensor_Open();
extern LVAL xslb40_Sensor_Put();
extern LVAL xslb50_Sensor_Data_Descriptor();
extern LVAL xslb60_Sensor_Close_Data_Descriptor();
extern LVAL xslb70_Sensor_Read();
extern LVAL xslb80_Sensor_Close();
extern LVAL xslb90_Cgoto();
extern LVAL xslba0_Cleos();
extern LVAL xslbb0_Cleol();
extern LVAL xslbc0_Xlsleep();
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR("SENSOR-GET", xslb20_Sensor_Get)
DEFINE_SUBR("SENSOR-OPEN", xslb30_Sensor_Open)
DEFINE_SUBR("SENSOR-PUT", xslb40_Sensor_Put)
DEFINE_SUBR("SENSOR-DATA-DESCRIPTOR", xslb50_Sensor_Data_Descriptor)
DEFINE_SUBR("SENSOR-CLOSE-DATA-DESCRIPTOR",xslb60_Sensor_Close_Data_Descriptor)
DEFINE_SUBR("SENSOR-READ", xslb70_Sensor_Read)
DEFINE_SUBR("SENSOR-CLOSE", xslb80_Sensor_Close)
DEFINE_SUBR("TERMCAP-MOVE-CURSOR", xslb90_Cgoto)
DEFINE_SUBR("TERMCAP-CLEAR-EOS", xslba0_Cleos)
DEFINE_SUBR("TERMCAP-CLEAR-EOL", xslbb0_Cleol)
DEFINE_SUBR("SLEEP", xslbc0_Xlsleep)
#endif























