/* {{{ xshp.h -- Insert varous simple shapes into graphic relations. CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jul02
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

/* {{{ MODULE_XLDMEM_H_GLOBALS						*/

#ifdef MODULE_XLDMEM_H_GLOBALS
extern LVAL xshp14_Insert_Facet_Fn();
extern LVAL xshp25_Insert_Frustum_Fn();
extern LVAL xshp30_Insert_Frustum_Hole_Fn();
extern LVAL xshp32_Insert_Box_Fn();
extern LVAL xshp39_Insert_Ball_Fn();
extern LVAL xshp44_Insert_Grid_Fn();
extern LVAL xshp54_Insert_Rod_Fn();

extern LVAL xshpE1_Insert_Hershey_String_Fn();
extern LVAL xshpE3_Insert_Hershey_Symbol_Fn();

#ifndef EXTERNED_X0
extern LVAL k_x0;   /* Keyword ":x0" */
#define EXTERNED_X0
#endif

#ifndef EXTERNED_Y0
extern LVAL k_y0;   /* Keyword ":y0" */
#define EXTERNED_Y0
#endif

#ifndef EXTERNED_Z0
extern LVAL k_z0;   /* Keyword ":z0" */
#define EXTERNED_Z0
#endif

#ifndef EXTERNED_X1
extern LVAL k_x1;   /* Keyword ":x1" */
#define EXTERNED_X1
#endif

#ifndef EXTERNED_Y1
extern LVAL k_y1;   /* Keyword ":y1" */
#define EXTERNED_Y1
#endif

#ifndef EXTERNED_Z1
extern LVAL k_z1;   /* Keyword ":z1" */
#define EXTERNED_Z1
#endif

#ifndef EXTERNED_X2
extern LVAL k_x2;   /* Keyword ":x2" */
#define EXTERNED_X2
#endif

#ifndef EXTERNED_Y2
extern LVAL k_y2;   /* Keyword ":y2" */
#define EXTERNED_Y2
#endif

#ifndef EXTERNED_Z2
extern LVAL k_z2;   /* Keyword ":z2" */
#define EXTERNED_Z2
#endif

#ifndef EXTERNED_X3
extern LVAL k_x3;   /* Keyword ":x3" */
#define EXTERNED_X3
#endif

#ifndef EXTERNED_Y3
extern LVAL k_y3;   /* Keyword ":y3" */
#define EXTERNED_Y3
#endif

#ifndef EXTERNED_Z3
extern LVAL k_z3;   /* Keyword ":z3" */
#define EXTERNED_Z3
#endif

#ifndef EXTERNED_THING
extern LVAL k_thing;   /* Keyword ":THING" */
#define EXTERNED_THING
#endif

#ifndef EXTERNED_UPDATECURSOR
extern LVAL k_updatecursor;   /* Keyword ":UPDATE-CURSOR" */
#define EXTERNED_UPDATECURSOR
#endif

#ifndef EXTERNED_X
extern LVAL k_x;   /* Keyword ":X" */
#define EXTERNED_X
#endif

#ifndef EXTERNED_Y
extern LVAL k_y;   /* Keyword ":Y" */
#define EXTERNED_Y
#endif

#ifndef EXTERNED_Z
extern LVAL k_z;   /* Keyword ":Z" */
#define EXTERNED_Z
#endif

#ifndef EXTERNED_WANTHOLES
extern LVAL k_wantholes;   /* Keyword ":WANT-HOLES" */
#define EXTERNED_WANTHOLES
#endif

#ifndef EXTERNED_TRANSFORM
extern LVAL k_transform;   /* Keyword ":TRANSFORM" */
#define EXTERNED_TRANSFORM
#endif

#ifndef EXTERNED_RED
extern LVAL k_red;   /* Keyword ":RED" */
#define EXTERNED_RED
#endif

#ifndef EXTERNED_GREEN
extern LVAL k_green;   /* Keyword ":GREEN" */
#define EXTERNED_GREEN
#endif

#ifndef EXTERNED_BLUE
extern LVAL k_blue;   /* Keyword ":BLUE" */
#define EXTERNED_BLUE
#endif

#ifndef EXTERNED_REDB
extern LVAL k_redb;   /* Keyword ":RED-B" */
#define EXTERNED_REDB
#endif

#ifndef EXTERNED_GREENB
extern LVAL k_greenb;   /* Keyword ":GREEN-B" */
#define EXTERNED_GREENB
#endif

#ifndef EXTERNED_BLUEB
extern LVAL k_blueb;   /* Keyword ":BLUE-B" */
#define EXTERNED_BLUEB
#endif

#ifndef EXTERNED_UPOINTS
extern LVAL k_Upoints;   /* Keyword ":U-POINTS" */
#define EXTERNED_UPOINTS
#endif

#ifndef EXTERNED_VPOINTS
extern LVAL k_vpoints;   /* Keyword ":V-POINTS" */
#define EXTERNED_VPOINTS
#endif

#ifndef EXTERNED_TEXT
extern LVAL k_text;   /* Keyword ":TEXT" */
#define EXTERNED_TEXT
#endif

#ifndef EXTERNED_FONT
extern LVAL k_font;   /* Keyword ":FONT" */
#define EXTERNED_FONT
#endif

#ifndef EXTERNED_LEFTMARGIN
extern LVAL k_leftmargin;   /* Keyword ":LEFT-MARGIN" */
#define EXTERNED_LEFTMARGIN
#endif

#ifndef EXTERNED_JUSTIFY
extern LVAL k_justify;   /* Keyword ":JUSTIFY" */
#define EXTERNED_JUSTIFY
#endif

#ifndef EXTERNED_LEFT
extern LVAL k_left;   /* Keyword ":LEFT" */
#define EXTERNED_LEFT
#endif

#ifndef EXTERNED_CENTER
extern LVAL k_center;   /* Keyword ":CENTER" */
#define EXTERNED_CENTER
#endif

#ifndef EXTERNED_RIGHT
extern LVAL k_right;   /* Keyword ":RIGHT" */
#define EXTERNED_RIGHT
#endif

#ifndef EXTERNED_LEFT
extern LVAL k_left;   /* Keyword ":LEFT" */
#define EXTERNED_LEFT
#endif

#ifndef EXTERNED_RADIUS
extern LVAL k_radius;   /* Keyword ":RADIUS" */
#define EXTERNED_RADIUS
#endif

#ifndef EXTERNED_RADIUSB
extern LVAL k_radiusb;  /* Keyword ":RADIUS-B" */
#define EXTERNED_RADIUSB
#endif

#ifndef EXTERNED_SCALE
extern LVAL k_scale;   /* Keyword ":SCALE" */
#define EXTERNED_SCALE
#endif

#ifndef EXTERNED_SCALEX
extern LVAL k_scalex;   /* Keyword ":SCALE-X" */
#define EXTERNED_SCALEX
#endif

#ifndef EXTERNED_SCALEY
extern LVAL k_scaley;   /* Keyword ":SCALE-Y" */
#define EXTERNED_SCALEY
#endif

#ifndef EXTERNED_SCALEZ
extern LVAL k_scalez;   /* Keyword ":SCALE-Z" */
#define EXTERNED_SCALEZ
#endif

#ifndef EXTERNED_CURSORX
extern LVAL k_cursorx;   /* Keyword ":CURSOR-X" */
#define EXTERNED_CURSORX
#endif

#ifndef EXTERNED_CURSORY
extern LVAL k_cursory;   /* Keyword ":CURSOR-Y" */
#define EXTERNED_CURSORY
#endif

#ifndef EXTERNED_CURSORZ
extern LVAL k_cursorz;   /* Keyword ":CURSOR-Z" */
#define EXTERNED_CURSORZ
#endif

#ifndef EXTERNED_VERTICALSPACING
extern LVAL k_verticalspacing;   /* Keyword ":VERTICAL-SPACING" */
#define EXTERNED_VERTICALSPACING
#endif

#ifndef EXTERNED_SYMBOL
extern LVAL k_symbol;   /* Keyword ":SYMBOL" */
#define EXTERNED_SYMBOL
#endif

#ifndef EXTERNED_OMITBOTTOM
extern LVAL k_omitbottom;   /* Keyword ":OMIT-BOTTOM" */
#define EXTERNED_OMITBOTTOM
#endif

#endif
/* }}} */
/* {{{ MODULE_XLFTAB_C_FUNTAB_S						*/

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR( "XG.3D-INSERT-FACET",	   xshp14_Insert_Facet_Fn	   )
DEFINE_SUBR( "XG.3D-INSERT-FRUSTUM",	   xshp25_Insert_Frustum_Fn	   )
DEFINE_SUBR( "XG.3D-INSERT-FRUSTUM-HOLE",  xshp30_Insert_Frustum_Hole_Fn   )
DEFINE_SUBR( "XG.3D-INSERT-BOX",	   xshp32_Insert_Box_Fn	           )
DEFINE_SUBR( "XG.3D-INSERT-BALL",	   xshp39_Insert_Ball_Fn	   )
DEFINE_SUBR( "XG.3D-INSERT-GRID",	   xshp44_Insert_Grid_Fn           )
DEFINE_SUBR( "XG.3D-INSERT-ROD",	   xshp54_Insert_Rod_Fn	           )
DEFINE_SUBR( "XG.3D-INSERT-HERSHEY-STRING",xshpE1_Insert_Hershey_String_Fn )
DEFINE_SUBR( "XG.3D-INSERT-HERSHEY-SYMBOL",xshpE3_Insert_Hershey_Symbol_Fn )

#endif

/* }}} */
/* {{{ MODULE_XLOBJ_C_GLOBALS						*/

#ifdef MODULE_XLOBJ_C_GLOBALS

#ifdef MAYBE_SOMEDAY
LOCAL struct xshp_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xshp_xgrl_table[] = {

    {	":INSERT-HERSHEY-STRING",	xshpE1_String_Msg	},
    {	":INSERT-HERSHEY-SYMBOL",	xshpE3_Symbol_Msg	},

    {	NULL,			NULL				}
};
#endif

#ifndef DEFINED_X0
LVAL k_x0;   /* Keyword ":x0" */
#define DEFINED_X0
#endif

#ifndef DEFINED_Y0
LVAL k_y0;   /* Keyword ":y0" */
#define DEFINED_Y0
#endif

#ifndef DEFINED_Z0
LVAL k_z0;   /* Keyword ":z0" */
#define DEFINED_Z0
#endif

#ifndef DEFINED_X1
LVAL k_x1;   /* Keyword ":x1" */
#define DEFINED_X1
#endif

#ifndef DEFINED_Y1
LVAL k_y1;   /* Keyword ":y1" */
#define DEFINED_Y1
#endif

#ifndef DEFINED_Z1
LVAL k_z1;   /* Keyword ":z1" */
#define DEFINED_Z1
#endif

#ifndef DEFINED_X2
LVAL k_x2;   /* Keyword ":x2" */
#define DEFINED_X2
#endif

#ifndef DEFINED_Y2
LVAL k_y2;   /* Keyword ":y2" */
#define DEFINED_Y2
#endif

#ifndef DEFINED_Z2
LVAL k_z2;   /* Keyword ":z2" */
#define DEFINED_Z2
#endif

#ifndef DEFINED_X3
LVAL k_x3;   /* Keyword ":x3" */
#define DEFINED_X3
#endif

#ifndef DEFINED_Y3
LVAL k_y3;   /* Keyword ":y3" */
#define DEFINED_Y3
#endif

#ifndef DEFINED_Z3
LVAL k_z3;   /* Keyword ":z3" */
#define DEFINED_Z3
#endif

#ifndef DEFINED_THING
LVAL k_thing;   /* Keyword ":thing" */
#define DEFINED_THING
#endif

#ifndef DEFINED_UPDATECURSOR
LVAL k_updatecursor;   /* Keyword ":update-cursor" */
#define DEFINED_UPDATECURSOR
#endif

#ifndef DEFINED_X
LVAL k_x;   /* Keyword ":x" */
#define DEFINED_X
#endif

#ifndef DEFINED_Y
LVAL k_y;   /* Keyword ":y" */
#define DEFINED_Y
#endif

#ifndef DEFINED_Z
LVAL k_z;   /* Keyword ":z" */
#define DEFINED_Z
#endif

#ifndef DEFINED_WANTHOLES
LVAL k_wantholes;   /* Keyword ":want-holes" */
#define DEFINED_WANTHOLES
#endif

#ifndef DEFINED_TRANSFORM
LVAL k_transform;   /* Keyword ":transform" */
#define DEFINED_TRANSFORM
#endif

#ifndef DEFINED_RED
LVAL k_red;   /* Keyword ":red" */
#define DEFINED_RED
#endif

#ifndef DEFINED_GREEN
LVAL k_green;   /* Keyword ":green" */
#define DEFINED_GREEN
#endif

#ifndef DEFINED_BLUE
LVAL k_blue;   /* Keyword ":blue" */
#define DEFINED_BLUE
#endif

#ifndef DEFINED_REDB
LVAL k_redb;   /* Keyword ":red-b" */
#define DEFINED_REDB
#endif

#ifndef DEFINED_GREENB
LVAL k_greenb;   /* Keyword ":green-b" */
#define DEFINED_GREENB
#endif

#ifndef DEFINED_BLUEB
LVAL k_blueb;   /* Keyword ":blue-b" */
#define DEFINED_BLUEB
#endif

#ifndef DEFINED_UPOINTS
LVAL k_upoints;   /* Keyword ":u-points" */
#define DEFINED_UPOINTS
#endif

#ifndef DEFINED_VPOINTS
LVAL k_vpoints;   /* Keyword ":v-points" */
#define DEFINED_VPOINTS
#endif

#ifndef DEFINED_TEXT
LVAL k_text;   /* Keyword ":text" */
#define DEFINED_TEXT
#endif

#ifndef DEFINED_FONT
LVAL k_font;   /* Keyword ":font" */
#define DEFINED_FONT
#endif

#ifndef DEFINED_LEFTMARGIN
LVAL k_leftmargin;   /* Keyword ":left-margin" */
#define DEFINED_LEFTMARGIN
#endif

#ifndef DEFINED_JUSTIFY
LVAL k_justify;   /* Keyword ":justify" */
#define DEFINED_JUSTIFY
#endif

#ifndef DEFINED_LEFT
LVAL k_left;   /* Keyword ":left" */
#define DEFINED_LEFT
#endif

#ifndef DEFINED_CENTER
LVAL k_center;   /* Keyword ":center" */
#define DEFINED_CENTER
#endif

#ifndef DEFINED_RIGHT
LVAL k_right;   /* Keyword ":right" */
#define DEFINED_RIGHT
#endif

#ifndef DEFINED_RADIUS
LVAL k_radius;   /* Keyword ":radius" */
#define DEFINED_RADIUS
#endif

#ifndef DEFINED_RADIUSB
LVAL k_radiusb;   /* Keyword ":radius-b" */
#define DEFINED_RADIUSB
#endif

#ifndef DEFINED_SCALE
LVAL k_scale;   /* Keyword ":scale" */
#define DEFINED_SCALE
#endif

#ifndef DEFINED_SCALEX
LVAL k_scalex;   /* Keyword ":scale-x" */
#define DEFINED_SCALEX
#endif

#ifndef DEFINED_SCALEY
LVAL k_scaley;   /* Keyword ":scale-y" */
#define DEFINED_SCALEY
#endif

#ifndef DEFINED_SCALEZ
LVAL k_scalez;   /* Keyword ":scale-z" */
#define DEFINED_SCALEZ
#endif

#ifndef DEFINED_CURSORX
LVAL k_cursorx;   /* Keyword ":cursor-x" */
#define DEFINED_CURSORX
#endif

#ifndef DEFINED_CURSORY
LVAL k_cursory;   /* Keyword ":cursor-y" */
#define DEFINED_CURSORY
#endif

#ifndef DEFINED_CURSORZ
LVAL k_cursorz;   /* Keyword ":cursor-z" */
#define DEFINED_CURSORZ
#endif

#ifndef DEFINED_VERTICALSPACING
LVAL k_verticalspacing;   /* Keyword ":vertical-spacing" */
#define DEFINED_VERTICALSPACING
#endif

#ifndef DEFINED_SYMBOL
LVAL k_symbol;   /* Keyword ":symbol" */
#define DEFINED_SYMBOL
#endif

#ifndef DEFINED_OMITBOTTOM
LVAL k_omitbottom;   /* Keyword ":omit-bottom" */
#define DEFINED_OMITBOTTOM
#endif

#endif

/* }}} */
/* {{{ MODULE_XLOBJ_C_OBJSYMBOLS					*/

#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_X0
    k_x0 = xlenter(":X0");
#define CREATED_X0
#endif

#ifndef CREATED_Y0
    k_y0 = xlenter(":Y0");
#define CREATED_Y0
#endif

#ifndef CREATED_Z0
    k_z0 = xlenter(":Z0");
#define CREATED_Z0
#endif

#ifndef CREATED_X1
    k_x1 = xlenter(":X1");
#define CREATED_X1
#endif

#ifndef CREATED_Y1
    k_y1 = xlenter(":Y1");
#define CREATED_Y1
#endif

#ifndef CREATED_Z1
    k_z1 = xlenter(":Z1");
#define CREATED_Z1
#endif

#ifndef CREATED_X2
    k_x2 = xlenter(":X2");
#define CREATED_X2
#endif

#ifndef CREATED_Y2
    k_y2 = xlenter(":Y2");
#define CREATED_Y2
#endif

#ifndef CREATED_Z2
    k_z2 = xlenter(":Z2");
#define CREATED_Z2
#endif

#ifndef CREATED_X3
    k_x3 = xlenter(":X3");
#define CREATED_X3
#endif

#ifndef CREATED_Y3
    k_y3 = xlenter(":Y3");
#define CREATED_Y3
#endif

#ifndef CREATED_Z3
    k_z3 = xlenter(":Z3");
#define CREATED_Z3
#endif

#ifndef CREATED_THING
    k_thing = xlenter(":THING");
#define CREATED_THING
#endif

#ifndef CREATED_UPDATECURSOR
    k_updatecursor = xlenter(":UPDATE-CURSOR");
#define CREATED_UPDATECURSOR
#endif

#ifndef CREATED_X
    k_x = xlenter(":X");
#define CREATED_X
#endif

#ifndef CREATED_Y
    k_y = xlenter(":Y");
#define CREATED_Y
#endif

#ifndef CREATED_Z
    k_z = xlenter(":Z");
#define CREATED_Z
#endif

#ifndef CREATED_WANTHOLES
    k_wantholes = xlenter(":WANT-HOLES");
#define CREATED_WANTHOLES
#endif

#ifndef CREATED_TRANSFORM
    k_transform = xlenter(":TRANSFORM");
#define CREATED_TRANSFORM
#endif

#ifndef CREATED_RED
    k_red = xlenter(":RED");
#define CREATED_RED
#endif

#ifndef CREATED_GREEN
    k_green = xlenter(":GREEN");
#define CREATED_GREEN
#endif

#ifndef CREATED_BLUE
    k_blue = xlenter(":BLUE");
#define CREATED_BLUE
#endif

#ifndef CREATED_REDB
    k_redb = xlenter(":RED-B");
#define CREATED_REDB
#endif

#ifndef CREATED_GREENB
    k_greenb = xlenter(":GREEN-B");
#define CREATED_GREENB
#endif

#ifndef CREATED_BLUEB
    k_blueb = xlenter(":BLUE-B");
#define CREATED_BLUEB
#endif

#ifndef CREATED_UPOINTS
    k_upoints = xlenter(":U-POINTS");
#define CREATED_UPOINTS
#endif

#ifndef CREATED_VPOINTS
    k_vpoints = xlenter(":V-POINTS");
#define CREATED_VPOINTS
#endif

#ifndef CREATED_TEXT
    k_text = xlenter(":TEXT");
#define CREATED_TEXT
#endif

#ifndef CREATED_FONT
    k_font = xlenter(":FONT");
#define CREATED_FONT
#endif

#ifndef CREATED_LEFTMARGIN
    k_leftmargin = xlenter(":LEFT-MARGIN");
#define CREATED_LEFTMARGIN
#endif

#ifndef CREATED_JUSTIFY
    k_justify = xlenter(":JUSTIFY");
#define CREATED_JUSTIFY
#endif

#ifndef CREATED_LEFT
    k_left = xlenter(":LEFT");
#define CREATED_LEFT
#endif

#ifndef CREATED_CENTER
    k_center = xlenter(":CENTER");
#define CREATED_CENTER
#endif

#ifndef CREATED_RIGHT
    k_right = xlenter(":RIGHT");
#define CREATED_RIGHT
#endif

#ifndef CREATED_RADIUS
    k_radius = xlenter(":RADIUS");
#define CREATED_RADIUS
#endif

#ifndef CREATED_RADIUSB
    k_radiusb = xlenter(":RADIUS-B");
#define CREATED_RADIUSB
#endif

#ifndef CREATED_SCALE
    k_scale = xlenter(":SCALE");
#define CREATED_SCALE
#endif

#ifndef CREATED_SCALEX
    k_scalex = xlenter(":SCALE-X");
#define CREATED_SCALEX
#endif

#ifndef CREATED_SCALEY
    k_scaley = xlenter(":SCALE-Y");
#define CREATED_SCALEY
#endif

#ifndef CREATED_SCALEZ
    k_scalez = xlenter(":SCALE-Z");
#define CREATED_SCALEZ
#endif

#ifndef CREATED_CURSORX
    k_cursorx = xlenter(":CURSOR-X");
#define CREATED_CURSORX
#endif

#ifndef CREATED_CURSORY
    k_cursory = xlenter(":CURSOR-Y");
#define CREATED_CURSORY
#endif

#ifndef CREATED_CURSORZ
    k_cursorz = xlenter(":CURSOR-Z");
#define CREATED_CURSORZ
#endif

#ifndef CREATED_VERTICALSPACING
    k_verticalspacing = xlenter(":VERTICAL-SPACING");
#define CREATED_VERTICALSPACING
#endif

#ifndef CREATED_SYMBOL
    k_symbol = xlenter(":SYMBOL");
#define CREATED_SYMBOL
#endif

#ifndef CREATED_OMITBOTTOM
    k_omitbottom = xlenter(":OMIT-BOTTOM");
#define CREATED_OMITBOTTOM
#endif

#endif

/* }}} */
/* {{{ MODULE_XLOBJ_C_XLOINIT						*/

#ifdef MODULE_XLOBJ_C_XLOINIT
#ifdef MAYBE_SOMEDAY
    xgbj56_Enter_Messages(        lv_xgrl, xshp_xgrl_table  );
#endif
#endif

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
