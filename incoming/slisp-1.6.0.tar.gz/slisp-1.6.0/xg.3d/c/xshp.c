/* {{{ xshp.c -- Insert various simple shapes into graphic relations.CrT*/

/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jul02
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 98Oct21 kph: Set v-points=2 for rods (nothing else works yet)        */
/* 96Aug20 jsp: Added ":update-cursor" kwd to xshp08_Parse_Shape_Args()	*/
/* 96Aug16 jsp: Fixed: Sphere facet count was wrong for segment case.	*/
/* 96Mar08 jsp: Fixed: rdx insert didn't aplly facet or point colors.	*/
/* 96Mar08 jsp: Fixed: box insert had facet normals wrong, often.	*/
/* 96Mar08 jsp: Fixed: box insert didn't apply facet color.		*/
/* 96Mar08 jsp: Fixed: grid insert started polygons at 0, not pbase.	*/
/* 95Jul12 jsp: :TRANSFORM support -- finally!				*/
/* 94Apr25 jsp: Rods, cleanup, texture coords, neighbors.		*/
/* 92Jul02 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

  
#include "../../xcore/c/xlisp.h"

#include <math.h>

#include "geo.h"
#include "c03d.h"
#include "csry.h"
#include "clgt.h"
#include "cshp.h"
#include "cthl.h"
#include "ctfm.h"

extern LVAL k_facet0;
extern LVAL k_facet1;
extern LVAL k_facet2;
extern LVAL k_facet3;
extern LVAL k_facetnormalx;
extern LVAL k_facetnormaly;
extern LVAL k_facetnormalz;
extern LVAL k_facetrelation;
extern LVAL k_omitbottom;
extern LVAL k_pointrelation;
extern LVAL k_pointx;
extern LVAL k_pointy;
extern LVAL k_pointz;
extern LVAL k_radius;
extern LVAL k_radiusb;
extern LVAL k_scale;
extern LVAL k_scalex;
extern LVAL k_scaley;
extern LVAL k_scalez;
extern LVAL k_thing;
extern LVAL k_updatecursor;
extern LVAL k_x;
extern LVAL k_y;
extern LVAL k_z;
extern LVAL k_x0;
extern LVAL k_y0;
extern LVAL k_z0;
extern LVAL k_x1;
extern LVAL k_y1;
extern LVAL k_z1;
extern LVAL k_x2;
extern LVAL k_y2;
extern LVAL k_z2;
extern LVAL k_x3;
extern LVAL k_y3;
extern LVAL k_z3;
extern LVAL k_blue;
extern LVAL k_blueb;
extern LVAL k_green;
extern LVAL k_greenb;
extern LVAL k_left;
extern LVAL k_upoints;
extern LVAL k_vpoints;
extern LVAL k_red;
extern LVAL k_redb;
extern LVAL k_wantholes;
extern LVAL k_center;
extern LVAL k_cursorx;
extern LVAL k_cursory;
extern LVAL k_cursorz;
extern LVAL k_font;
extern LVAL k_justify;
extern LVAL k_leftmargin;
extern LVAL k_right;
extern LVAL k_symbol;
extern LVAL k_text;
extern LVAL k_transform;
extern LVAL k_verticalspacing;

/* }}} */

/* {{{ --- Public fns ---						*/

/* }}} */
/* {{{ xshp07_Init_Shape_Args						*/

void xshp07_Init_Shape_Args( a )
struct xshp06_Args_Rec      *a;
{
    /* We use a fn mostly because NIL isn't a constant,  */
    /* and in particular can't be counted on to be NULL: */

    a->lv_thing    = NIL;
    a->lv_xtfm     = NIL;
    a->n           = 0;
    a->want_holes  = FALSE;
    a->omit_bottom = FALSE;
    a->u_points    = 4;   a->got_u_points = FALSE;
    a->v_points    = 4;   a->got_v_points = FALSE;
    a->font_num    = 1;
    a->update_cursor = TRUE;
    a->symbol      = -1;
    a->text        = NULL;
    a->lv_justify  = k_left;

    a->vspacing = 0.0; a->got_vspacing = FALSE;
    a->margin   = 0.0; a->got_margin   = FALSE;
    a->radius   = 1.0; a->got_radius   = FALSE;
    a->radius_b = 1.0; a->got_radius_b = FALSE;

    a->x = a->y = a->z = 0.0;   a->got_p = FALSE;

    a->x0 = 0.0; a->y0 = 0.0; a->z0 = 0.0;   a->got_0 = FALSE;
    a->x1 = 1.0; a->y1 = 0.0; a->z1 = 0.0;   a->got_1 = FALSE;
    a->x2 = 1.0; a->y2 = 1.0; a->z2 = 0.0;   a->got_2 = FALSE;
    a->x3 = 0.0; a->y3 = 1.0; a->z3 = 0.0;   a->got_3 = FALSE;

    a->red   = 255;   a->got_rgb   = FALSE;
    a->grn   = 255;
    a->blu   =   0;

    a->red_b =   0;   a->got_rgb_b = FALSE;
    a->grn_b =   0;
    a->blu_b = 255;

    a->scale  = 1.0;   a->got_scale = FALSE;
    a->scalex = 1.0;   a->got_scalex= FALSE;
    a->scaley = 1.0;   a->got_scaley= FALSE;
    a->scalez = 1.0;   a->got_scalez= FALSE;
}

/* }}} */
/* {{{ xshp08_Parse_Shape_Args						*/

void
xshp08_Parse_Shape_Args( a )
struct xshp06_Args_Rec  *a;
{
    xshp07_Init_Shape_Args( a );
    while (moreargs()) {

        LVAL       key = xlgasymbol();
        if        (key == k_thing) {

	    a->lv_thing = xlgacons();

        } else if (key == k_updatecursor) {

	    a->update_cursor = !null(xlgetarg());

        } else if (key == k_transform) {

	    a->lv_xtfm  = xtfm01_Get_A_XTFM();

        } else if (key == k_wantholes) {
	    a->want_holes = !null(xlgetarg());

        } else if (key == k_omitbottom) {
	    a->omit_bottom = !null(xlgetarg());

        } else if (key == k_x) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->x	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_p    = TRUE;
	    }
        } else if (key == k_y) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->y	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_p    = TRUE;
	    }
        } else if (key == k_z) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->z	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_p    = TRUE;
	    }
        } else if (key == k_x0) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->x0 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_0 = TRUE;
	    }

        } else if (key == k_y0) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->y0 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_0 = TRUE;
	    }

        } else if (key == k_z0) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->z0 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_0 = TRUE;
	    }

        } else if (key == k_x1) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->x1 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_1 = TRUE;
	    }

        } else if (key == k_y1) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->y1 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_1 = TRUE;
	    }

        } else if (key == k_z1) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->z1 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_1 = TRUE;
	    }

        } else if (key == k_x2) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->x2 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_2 = TRUE;
	    }

        } else if (key == k_y2) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->y2 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_2 = TRUE;
	    }

        } else if (key == k_z2) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->z2 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_2 = TRUE;
	    }

        } else if (key == k_x3) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->x3 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_3 = TRUE;
	    }

        } else if (key == k_y3) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->y3 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_3 = TRUE;
	    }

        } else if (key == k_z3) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->z3 = xgbj00_Get_Fix_Or_Flo_Num( arg );
		a->got_3 = TRUE;
	    }

        } else if (key == k_scale) {

	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->scale = xgbj00_Get_Fix_Or_Flo_Num(arg);
		if (!a->got_scalex) a->scalex = a->scale;
		if (!a->got_scaley) a->scaley = a->scale;
		if (!a->got_scalez) a->scalez = a->scale;
	    }

        } else if (key == k_scalex) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->scalex	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_scalex	= TRUE;
	    }
        } else if (key == k_scaley) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->scaley	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_scaley	= TRUE;
	    }
        } else if (key == k_scalez) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->scalez	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_scalez	= TRUE;
	    }

        } else if (key == k_red) {
	    a->red = xshp30_GetColor();
        } else if (key == k_green) {
	    a->grn = xshp30_GetColor();
        } else if (key == k_blue) {
	    a->blu = xshp30_GetColor();

        } else if (key == k_redb) {
	    a->red_b       = xshp30_GetColor();
	    a->got_rgb_b   = TRUE;
        } else if (key == k_greenb) {
	    a->grn_b       = xshp30_GetColor();
	    a->got_rgb_b   = TRUE;
        } else if (key == k_blueb) {
	    a->blu_b       = xshp30_GetColor();
	    a->got_rgb_b   = TRUE;

        } else if (key == k_upoints) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->u_points = (int) xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_u_points = TRUE;
	    }

        } else if (key == k_vpoints) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->v_points = (int) xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_v_points = TRUE;
	    }

        } else if (key == k_radius) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->radius	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_radius = TRUE;
	    }

        } else if (key == k_radiusb) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->radius_b	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_radius_b = TRUE;
	    }

        } else if (key == k_text) {

	    {   LVAL lv_text= xlgastring();
	        a->text	= (char *) getstring( lv_text );
	    }

        } else if (key == k_font) {

	    {    LVAL lv_fontNum  = xlgafixnum();
	         a->font_num	= getfixnum( lv_fontNum );
	     }

        } else if (key == k_symbol) {

	    {   LVAL lv_symbol = xlgafixnum();
	        a->symbol	= getfixnum( lv_symbol );
	    }

        } else if (key == k_verticalspacing) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->vspacing	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_vspacing= TRUE;
	    }

        } else if (key == k_leftmargin) {
	    LVAL arg = xlgetarg();
	    if (arg != NIL) {
		a->margin	= xgbj00_Get_Fix_Or_Flo_Num(arg);
		a->got_margin	= TRUE;
	    }

        } else if (key == k_justify) {
	    {   LVAL lv	= xlgasymbol();
		if (lv == k_left   ||
		    lv == k_center ||
		    lv == k_right
		) {
		    a->lv_justify = lv;
		} else {
		    xlerror("Bad :JUSTIFY val",lv);
		}
	    }
        } else {

            xlerror( "Unexpected keyword", key );
    }   }

    if (null(a->lv_thing)) xlfail("No :THING");

    /* Figure out how many corners on polygon: */
    if (a->n == 0   &&   a->got_0)   ++a->n;
    if (a->n == 1   &&   a->got_1)   ++a->n;
    if (a->n == 2   &&   a->got_2)   ++a->n;
    if (a->n == 3   &&   a->got_3)   ++a->n;

    if (!a->got_rgb_b) {
	a->red_b = 255-a->red;
	a->grn_b = 255-a->grn;
	a->blu_b = 255-a->blu;
    }
}

/* }}} */
/* {{{ xshp14_Insert_Facet_Fn						*/

void xshp12_Insert_Facet(
    struct xshp06_Args_Rec*  a
) {
    int  pbase = 0;
    int  fbase = 0;

    int  pnts = a->n;
    int  fcts = 1;

    LVAL lv_pointGrl = NIL;
    LVAL lv_facetGrl = NIL;

    gt_tri_rec r;
    if (!a->n)   return;
    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, a->lv_thing );

    /* Find our relations: */
    if (r.got_points) {
	lv_pointGrl   = xthlA2_Get_Point_Relation_From_Thing( a->lv_thing );
    } else {
	return;
    }
    if (r.got_segments) {
	lv_facetGrl   = xthlA4_Get_Facet_Relation_From_Thing( a->lv_thing );
    } else {
	fcts = 0;
    }

    if (r.got_points)   pbase = xthlEf_Resize_Grl( lv_pointGrl, pnts );
    if (r.got_segments) fbase = xthlEf_Resize_Grl( lv_facetGrl, fcts );

    /* Reload r, because resizing may have moved (realloc()ed) stuff in ram: */
    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, a->lv_thing );

    /* Enter our points into pointgrl: */
    {   int b = pbase;
	if (a->n > 0) { r.x[b] = a->x0; r.y[b] = a->y0;  r.z[b] = a->z0; ++b; }
	if (a->n > 1) { r.x[b] = a->x1; r.y[b] = a->y1;  r.z[b] = a->z1; ++b; }
	if (a->n > 2) { r.x[b] = a->x2; r.y[b] = a->y2;  r.z[b] = a->z2; ++b; }
	if (a->n > 3) { r.x[b] = a->x3; r.y[b] = a->y3;  r.z[b] = a->z3; ++b; }
    }

    /* Enter our point texture coords: */
    if (r.got_point_textures) {
	int b = pbase;
	if (a->n > 0) { r.ptu[b] = 0.0; r.ptv[b] = 0.0; ++b; }
	if (a->n > 1) { r.ptu[b] = 1.0; r.ptv[b] = 0.0; ++b; }
	if (a->n > 2) { r.ptu[b] = 1.0; r.ptv[b] = 1.0; ++b; }
	if (a->n > 3) { r.ptu[b] = 0.0; r.ptv[b] = 1.0; ++b; }
    }

    /* Enter our facet into facetgrl: */
    if (r.got_segments) {
	int f = fbase;
	if (a->n > 0 && r.f0)   r.f0[f] = pbase+0;
	if (a->n > 1 && r.f1)   r.f1[f] = pbase+1;
	if (a->n > 2 && r.f2)   r.f2[f] = pbase+2;
	if (a->n > 3 && r.f3)   r.f3[f] = pbase+3;
    }

    /* Enter our facet texture coords: */
    if (r.got_facet_textures) {
	int f = fbase;
	if (a->n > 0) { r.ftu0[f] = 0.0; r.ftv0[f] = 0.0; }
	if (a->n > 1) { r.ftu1[f] = 1.0; r.ftv1[f] = 0.0; }
	if (a->n > 2) { r.ftu2[f] = 1.0; r.ftv2[f] = 1.0; }
	if (a->n > 3) { r.ftu3[f] = 0.0; r.ftv2[f] = 1.0; }
    }



    if (a->n < 3) {

	if (r.got_segments && r.got_facet_normals) {
	    int f = fbase;
	    /* Enter our facet normal: */
	    r.fnx[f] = 0.0;
	    r.fny[f] = 0.0;
	    r.fnz[f] = 1.0;
	}
	if (r.got_point_normals) {
	    int b = pbase;
	    /* Enter our point normals: */
	    int i = a->n;
	    while (i --> 0) {
		r.pnx[b] = 0.0;
		r.fny[b] = 0.0;
		r.fnz[b] = 1.0;
		++b;
	}   }

    } else /* a->n > 2 */ {

	if (r.got_facet_normals || r.got_point_normals) {
	    /* Compute our facet normal: */
	    geo_point f_0;
	    geo_point f_1;
	    geo_point f_2;
	    f_0.x = a->x0;	f_0.y = a->y0;	f_0.z = a->z0;
	    f_1.x = a->x1;	f_1.y = a->y1;	f_1.z = a->z1;
	    f_2.x = a->x2;	f_2.y = a->y2;	f_2.z = a->z2;
	    lib11_Vector_Subtract(      &f_1, &f_1, &f_0 );
	    lib11_Vector_Subtract(      &f_2, &f_2, &f_0 );
	    lib00_Vector_Cross_Product( &f_0, &f_2, &f_1 );
	    lib08_Vector_Normalize(     &f_0	     );

	    if (r.got_segments && r.got_facet_normals) {
		int f = fbase;
		/* Enter our facet normal: */
		r.fnx[f] = f_0.x;
		r.fny[f] = f_0.y;
		r.fnz[f] = f_0.z;
	    }
	    if (r.got_point_normals) {
		int b = pbase;
		/* Enter our point normals: */
		int i = a->n;
		while (i --> 0) {
		    r.pnx[b] = f_0.x;
		    r.pny[b] = f_0.y;
		    r.pnz[b] = f_0.z;
		    ++b;
    }	}   }	}

    /* Transform points if requested: */
    if (a->lv_xtfm != NIL) {
	xthlK1_TransformThing(
	    a->lv_thing,
	    xtfm9b_Find_Matrix( a->lv_xtfm ),
	    pbase,
	    fbase
	);
    }
}

LVAL xshp14_Insert_Facet_Fn()
{
    struct xshp06_Args_Rec     a  ;
    xshp08_Parse_Shape_Args(  &a );
    xshp12_Insert_Facet(      &a );
    return a.lv_thing;
}

/* }}} */
/* {{{ xshp22_Insert_Box_Or_Frustum					*/

LVAL xshp22_Insert_Box_Or_Frustum(
    struct xshp06_Args_Rec*  a,
    int                      doBox
) {
    /* Compute number of points and facets we'll need: */
    int  pnts  = 8;
    int  squares = doBox ? 6 : 5;
    int  fcts;

    /* Allocate required # of points and facets, remembering old number: */
    int pbase = 0;
    int fbase = 0;

    LVAL lv_pointGrl;
    LVAL lv_facetGrl;

    gt_tri_rec r;
    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, a->lv_thing );

    /* Find our relations: */
    if (r.got_points) {
	lv_pointGrl   = xthlA2_Get_Point_Relation_From_Thing( a->lv_thing );
    } else {
	return NIL;
    }
    if (r.got_segments) {
	lv_facetGrl   = xthlA4_Get_Facet_Relation_From_Thing( a->lv_thing );
    }
    if      (r.got_rectangles)   fcts =   squares;
    else if (r.got_triangles)    fcts = 2*squares;
    else if (r.got_segments)     fcts = 12;
    else                         fcts = 0;

    /* Allocate required #s of points and facets, remembering old number: */
    if (r.got_points)   pbase = xthlEf_Resize_Grl( lv_pointGrl, pnts );
    if (r.got_segments) fbase = xthlEf_Resize_Grl( lv_facetGrl, fcts );

    /* Reload r, because resizing may have moved (realloc()ed) stuff in ram: */
    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, a->lv_thing );


    /* Compute geometry: */
    {
        float w    = doBox ? 1.0 : 0.1;

        float xmin = -0.5*  a->scalex + a->x;
	float xmax =  0.5*  a->scalex + a->x;

        float ymin = -0.5*  a->scaley + a->y;
	float ymax =  0.5*  a->scaley + a->y;

        float zmin = -0.5*w*a->scalez + a->z;
	float zmax =  0.5*w*a->scalez + a->z;

	FLOTYPE Xmin, Xmax;
	FLOTYPE Ymin, Ymax;
	FLOTYPE thickness;

	int     b;
	int     f;

	if (xmin > xmax) {FLOTYPE f = xmin; xmin = xmax; xmax = f; }
	if (ymin > ymax) {FLOTYPE f = ymin; ymin = ymax; ymax = f; }
	if (zmin > zmax) {FLOTYPE f = zmin; zmin = zmax; zmax = f; }

	/* Figure x-y corners of near face from those of far face,	*/
	/* by constructing a 45 degree bevel:			*/
	thickness	= zmax - zmin;
	Xmin	= doBox   ?   xmin   :   xmin + thickness;
	Xmax	= doBox   ?   xmax   :   xmax - thickness;
	Ymin	= doBox   ?   ymin   :   ymin + thickness;
	Ymax	= doBox   ?   ymax   :   ymax - thickness;


        /* Deposit the new points,           */
        /* counterclockwise from lower-left, */
        /* front then back:                  */
	b = pbase;
        r.x[b] = Xmin;   r.y[b] = Ymin;   r.z[b] = zmin;   ++b;
        r.x[b] = Xmax;   r.y[b] = Ymin;   r.z[b] = zmin;   ++b;
        r.x[b] = Xmax;   r.y[b] = Ymax;   r.z[b] = zmin;   ++b;
        r.x[b] = Xmin;   r.y[b] = Ymax;   r.z[b] = zmin;   ++b;

        r.x[b] = xmin;   r.y[b] = ymin;   r.z[b] = zmax;   ++b;
        r.x[b] = xmax;   r.y[b] = ymin;   r.z[b] = zmax;   ++b;
        r.x[b] = xmax;   r.y[b] = ymax;   r.z[b] = zmax;   ++b;
        r.x[b] = xmin;   r.y[b] = ymax;   r.z[b] = zmax;   ++b;

	/* Enter our texture coords: */
	if (r.got_point_textures) {
	    int b = pbase;
	    r.ptu[b] = 0.25; r.ptv[b] = 0.25; ++b;
	    r.ptu[b] = 0.75; r.ptv[b] = 0.25; ++b;
	    r.ptu[b] = 0.75; r.ptv[b] = 0.75; ++b;
	    r.ptu[b] = 0.25; r.ptv[b] = 0.75; ++b;

	    r.ptu[b] = 0.00; r.ptv[b] = 0.00; ++b;
	    r.ptu[b] = 1.00; r.ptv[b] = 0.00; ++b;
	    r.ptu[b] = 1.00; r.ptv[b] = 1.00; ++b;
	    r.ptu[b] = 0.00; r.ptv[b] = 1.00; ++b;
	}



	if (r.got_point_normals) {
	    /* From laziness, I'm doing always the box case here: */
	    float ir3 = 0.57735;
	    b = pbase;
	    r.pnx[b] = -ir3;   r.pny[b] = -ir3;   r.pnz[b] = -ir3;   ++b;
	    r.pnx[b] =  ir3;   r.pny[b] = -ir3;   r.pnz[b] = -ir3;   ++b;
	    r.pnx[b] =  ir3;   r.pny[b] =  ir3;   r.pnz[b] = -ir3;   ++b;
	    r.pnx[b] = -ir3;   r.pny[b] =  ir3;   r.pnz[b] = -ir3;   ++b;

	    r.pnx[b] = -ir3;   r.pny[b] = -ir3;   r.pnz[b] =  ir3;   ++b;
	    r.pnx[b] =  ir3;   r.pny[b] = -ir3;   r.pnz[b] =  ir3;   ++b;
	    r.pnx[b] =  ir3;   r.pny[b] =  ir3;   r.pnz[b] =  ir3;   ++b;
	    r.pnx[b] = -ir3;   r.pny[b] =  ir3;   r.pnz[b] =  ir3;   ++b;
        }

	/* Deposit the new facets, near then counterclockwise from bottom: */
	b = pbase;
	if (r.got_rectangles) {

	    f = fbase;
	    {
		r.f0[f]=b+0; r.f1[f]=b+1; r.f2[f]=b+2; r.f3[f]=b+3; ++f;
		r.f0[f]=b+0; r.f1[f]=b+4; r.f2[f]=b+5; r.f3[f]=b+1; ++f;
		r.f0[f]=b+1; r.f1[f]=b+5; r.f2[f]=b+6; r.f3[f]=b+2; ++f;
		r.f0[f]=b+2; r.f1[f]=b+6; r.f2[f]=b+7; r.f3[f]=b+3; ++f;
		r.f0[f]=b+3; r.f1[f]=b+7; r.f2[f]=b+4; r.f3[f]=b+0; ++f;
	    }
	    if (doBox) {
		r.f0[f]=b+7; r.f1[f]=b+6; r.f2[f]=b+5; r.f3[f]=b+4; ++f;
	    }

	    /* Enter our texture coords: */
	    if (r.got_facet_textures) {
		int f = doBox ? fbase+6 : fbase+5;
		while (f --> fbase) {
		    r.ftu0[f] = 0.0; r.ftv0[f] = 0.0;
		    r.ftu1[f] = 1.0; r.ftv1[f] = 0.0;
		    r.ftu2[f] = 1.0; r.ftv2[f] = 1.0;
		    r.ftu3[f] = 0.0; r.ftv3[f] = 1.0;
	    }   }

	    if (r.got_facet_normals) {
		if (!doBox) {
		    /* Deposit the facet normals, same order as facets: */
		    float ir2 = doBox ? 1.0 : (0.707107);
		    float IR2 = doBox ? 0.0 : (0.707107);
		    f = fbase;
		    r.fnx[f]= 0.0; r.fny[f]= 0.0; r.fnz[f]= -1.0;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]=-ir2; r.fnz[f]= -IR2;   ++f;
		    r.fnx[f]= ir2; r.fny[f]= 0.0; r.fnz[f]= -IR2;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]= ir2; r.fnz[f]= -IR2;   ++f;
		    r.fnx[f]=-ir2; r.fny[f]= 0.0; r.fnz[f]= -IR2;   ++f;
		} else {
		    f = fbase;
		    r.fnx[f]= 0.0; r.fny[f]= 0.0; r.fnz[f]= -1.0;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]=-1.0; r.fnz[f]=  0.0;   ++f;
		    r.fnx[f]= 1.0; r.fny[f]= 0.0; r.fnz[f]=  0.0;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]= 1.0; r.fnz[f]=  0.0;   ++f;
		    r.fnx[f]=-1.0; r.fny[f]= 0.0; r.fnz[f]=  0.0;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]= 0.0; r.fnz[f]=  0.0;   ++f;
		}
	    }

	    if (r.got_facet_colors) {
		f = fbase;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
	    }
	    if (r.got_facet_colors && doBox) {
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
	    }

	} else if (r.got_triangles) {
	    f = fbase;
	    {
		r.f0[f]=b+0; r.f1[f]=b+1; r.f2[f]=b+2; ++f;
		r.f0[f]=b+0; r.f1[f]=b+2; r.f2[f]=b+3; ++f;

		r.f0[f]=b+0; r.f1[f]=b+4; r.f2[f]=b+5; ++f;
		r.f0[f]=b+0; r.f1[f]=b+5; r.f2[f]=b+1; ++f;

		r.f0[f]=b+1; r.f1[f]=b+5; r.f2[f]=b+6; ++f;
		r.f0[f]=b+1; r.f1[f]=b+6; r.f2[f]=b+2; ++f;

		r.f0[f]=b+2; r.f1[f]=b+6; r.f2[f]=b+7; ++f;
		r.f0[f]=b+2; r.f1[f]=b+7; r.f2[f]=b+3; ++f;

		r.f0[f]=b+3; r.f1[f]=b+7; r.f2[f]=b+4; ++f;
		r.f0[f]=b+3; r.f1[f]=b+4; r.f2[f]=b+0; ++f;
	    }
	    if (doBox) {
		r.f0[f]=b+7; r.f1[f]=b+6; r.f2[f]=b+5; ++f;
		r.f0[f]=b+7; r.f1[f]=b+5; r.f2[f]=b+4; ++f;
	    }

	    /* Enter our texture coords: */
	    if (r.got_facet_textures) {
		int f = doBox ? fbase+12 : fbase+10;

		while (f --> fbase) {

		    r.ftu0[f] = 0.0; r.ftv0[f] = 0.0;
		    r.ftu1[f] = 1.0; r.ftv1[f] = 1.0;
		    r.ftu2[f] = 0.0; r.ftv2[f] = 1.0;

		    --f;

		    r.ftu0[f] = 0.0; r.ftv0[f] = 0.0;
		    r.ftu1[f] = 1.0; r.ftv1[f] = 0.0;
		    r.ftu2[f] = 1.0; r.ftv2[f] = 1.0;
	    }   }

	    if (r.got_facet_normals) {
		if (!doBox) {
		    /* Deposit the facet normals, same order as facets: */
		    float ir2 = doBox ? 1.0 : (0.707107);
		    float IR2 = doBox ? 0.0 : (0.707107);
		    f = fbase;
		    r.fnx[f]= 0.0; r.fny[f]= 0.0; r.fnz[f]= -1.0;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]= 0.0; r.fnz[f]= -1.0;   ++f;

		    r.fnx[f]= 0.0; r.fny[f]=-ir2; r.fnz[f]= -IR2;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]=-ir2; r.fnz[f]= -IR2;   ++f;

		    r.fnx[f]= ir2; r.fny[f]= 0.0; r.fnz[f]= -IR2;   ++f;
		    r.fnx[f]= ir2; r.fny[f]= 0.0; r.fnz[f]= -IR2;   ++f;

		    r.fnx[f]= 0.0; r.fny[f]= ir2; r.fnz[f]= -IR2;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]= ir2; r.fnz[f]= -IR2;   ++f;

		    r.fnx[f]=-ir2; r.fny[f]= 0.0; r.fnz[f]= -IR2;   ++f;
		    r.fnx[f]=-ir2; r.fny[f]= 0.0; r.fnz[f]= -IR2;   ++f;
		} else {
		    f = fbase;
		    r.fnx[f]= 0.0; r.fny[f]= 0.0; r.fnz[f]= -1.0;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]= 0.0; r.fnz[f]= -1.0;   ++f;

		    r.fnx[f]= 0.0; r.fny[f]=-1.0; r.fnz[f]=  0.0;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]=-1.0; r.fnz[f]=  0.0;   ++f;

		    r.fnx[f]= 1.0; r.fny[f]= 0.0; r.fnz[f]=  0.0;   ++f;
		    r.fnx[f]= 1.0; r.fny[f]= 0.0; r.fnz[f]=  0.0;   ++f;

		    r.fnx[f]= 0.0; r.fny[f]= 1.0; r.fnz[f]=  0.0;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]= 1.0; r.fnz[f]=  0.0;   ++f;

		    r.fnx[f]=-1.0; r.fny[f]= 0.0; r.fnz[f]=  0.0;   ++f;
		    r.fnx[f]=-1.0; r.fny[f]= 0.0; r.fnz[f]=  0.0;   ++f;

		    r.fnx[f]= 0.0; r.fny[f]= 0.0; r.fnz[f]=  1.0;   ++f;
		    r.fnx[f]= 0.0; r.fny[f]= 0.0; r.fnz[f]=  1.0;   ++f;
		}
	    }

	    if (r.got_facet_colors) {
		f = fbase;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
	    }
	    if (r.got_facet_colors && doBox) {
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
	    }

	} else if (r.got_segments) {
	    f = fbase;

	    /* Front face: */
	    r.f0[f]=b+0; r.f1[f]=b+1; ++f; /* bottom */
	    r.f0[f]=b+1; r.f1[f]=b+2; ++f; /* right  */
	    r.f0[f]=b+2; r.f1[f]=b+3; ++f; /* top    */
	    r.f0[f]=b+3; r.f1[f]=b+0; ++f; /* left   */

	    /* Back face: */
	    r.f0[f]=b+4; r.f1[f]=b+5; ++f; /* bottom */
	    r.f0[f]=b+5; r.f1[f]=b+6; ++f; /* right  */
	    r.f0[f]=b+6; r.f1[f]=b+7; ++f; /* top    */
	    r.f0[f]=b+7; r.f1[f]=b+4; ++f; /* left   */

	    /* Front-to-back edges: */
	    r.f0[f]=b+0; r.f1[f]=b+4; ++f; /* botleft */
	    r.f0[f]=b+1; r.f1[f]=b+5; ++f; /* botroit */
	    r.f0[f]=b+2; r.f1[f]=b+6; ++f; /* toproit */
	    r.f0[f]=b+3; r.f1[f]=b+7; ++f; /* topleft */

	    if (r.got_facet_normals) {
		/* From laziness, I'm doing always the box case here: */
		float ir2 = (0.707107);
		f = fbase;
		r.fnx[f]= 0.0; r.fny[f]=-ir2; r.fnz[f]= -ir2;   ++f;
		r.fnx[f]= ir2; r.fny[f]= 0.0; r.fnz[f]= -ir2;   ++f;
		r.fnx[f]= 0.0; r.fny[f]= ir2; r.fnz[f]= -ir2;   ++f;
		r.fnx[f]=-ir2; r.fny[f]= 0.0; r.fnz[f]= -ir2;   ++f;

		r.fnx[f]= 0.0; r.fny[f]=-ir2; r.fnz[f]=  ir2;   ++f;
		r.fnx[f]= ir2; r.fny[f]= 0.0; r.fnz[f]=  ir2;   ++f;
		r.fnx[f]= 0.0; r.fny[f]= ir2; r.fnz[f]=  ir2;   ++f;
		r.fnx[f]=-ir2; r.fny[f]= 0.0; r.fnz[f]=  ir2;   ++f;

		r.fnx[f]=-ir2; r.fny[f]=-ir2; r.fnz[f]=    0;   ++f;
		r.fnx[f]= ir2; r.fny[f]=-ir2; r.fnz[f]=    0;   ++f;
		r.fnx[f]= ir2; r.fny[f]= ir2; r.fnz[f]=    0;   ++f;
		r.fnx[f]=-ir2; r.fny[f]= ir2; r.fnz[f]=    0;   ++f;
	    }


	    if (r.got_facet_colors) {
		f = fbase;

		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;

		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;

		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
		r.fr[f] = a->red;   r.fg[f] = a->grn;   r.fb[f] = a->blu;  ++f;
	    }
	}
    }


    /* Transform points if requested: */
    if (a->lv_xtfm != NIL) {
	xthlK1_TransformThing(
	    a->lv_thing,
	    xtfm9b_Find_Matrix( a->lv_xtfm ),
	    pbase,
	    fbase
	);
    }

    return NIL;
}

/* }}} */
/* {{{ xshp24_Insert							*/

LVAL xshp24_Insert( doBox, fn )
int		    doBox;
LVAL			 (*fn)();
{
    struct xshp06_Args_Rec    a  ;
    xshp08_Parse_Shape_Args( &a );
    return fn(               &a, doBox );
}

/* }}} */
/* {{{ xshp25_Insert_Frustum_Fn						*/

LVAL xshp25_Insert_Frustum_Fn()
{
    return xshp24_Insert( /*doBox*/FALSE, xshp22_Insert_Box_Or_Frustum );
}

/* }}} */
/* {{{ xshp29_Insert_Box_Or_Frustum_Hole				*/

LVAL xshp29_Insert_Box_Or_Frustum_Hole(
    struct xshp06_Args_Rec*  a,
    int                      doBox
) {
    float xmin = -0.50*a->scalex + a->x;
    float xmax =  0.50*a->scalex + a->x;

    float ymin = -0.50*a->scaley + a->y;
    float ymax =  0.50*a->scaley + a->y;

    float zmin = -0.05*a->scalez + a->z;
    float zmax =  0.05*a->scalez + a->z;

    /***********************************************************/
    /* Track down the component arrays we need from our grls.  */
    /***********************************************************/
    LVAL lv_point_grl = xthl74_GetProp(
	&a->lv_thing,
	k_pointrelation,
	NIL,			/* default_val */
	TRUE			/* got_default */
    );
    LVAL lv_facet_grl = xthl74_GetProp(
	&a->lv_thing,
	k_facetrelation,
	NIL,			/* default_val */
	TRUE			/* got_default */
    );

    LVAL*p_pArrayList = (LVAL *) xgrl13_pArrayList( lv_point_grl );
    LVAL*f_pArrayList = (LVAL *) xgrl13_pArrayList( lv_facet_grl );



    LVAL lv_point_x   = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointx );
    LVAL lv_point_y   = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointy );
    LVAL lv_point_z   = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointz );

    float*  point_x;
    float*  point_y;
    float*  point_z;

    LVAL lv_facet_0   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facet0 );
    LVAL lv_facet_1   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facet1 );
    LVAL lv_facet_2   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facet2 );
    LVAL lv_facet_3   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facet3 );

    int  *  facet_0;
    int  *  facet_1;
    int  *  facet_2;
    int  *  facet_3;

    LVAL lv_norml_x   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facetnormalx );
    LVAL lv_norml_y   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facetnormaly );
    LVAL lv_norml_z   = (LVAL)   xgrl39_GetArray( f_pArrayList, k_facetnormalz );

    float*  norml_x;
    float*  norml_y;
    float*  norml_z;

    int  oldPointSz;
    int  oldFacetSz;

    int  pointsNeeded = 12;
    int  facetsNeeded = a->omit_bottom ? 7 : 8;

    FLOTYPE Xmin, Xmax;
    FLOTYPE Ymin, Ymax;
    FLOTYPE Zmin, Zmax;
    FLOTYPE thickness;

    float xMin, xMax;
    float yMin, yMax;

    int  b;  /* Base index of point array. */
    int  our_poly;
    int  p,q,r,s;

    xgrl0h_Must_Be_A_XGRL( lv_point_grl );
    xgrl0h_Must_Be_A_XGRL( lv_facet_grl );


    /* Sanity checks to keep user honest: */

    xthlEe_Error_If_Not_Rank_1( lv_point_grl, lv_point_grl );
    xthlEe_Error_If_Not_Rank_1( lv_facet_grl, lv_facet_grl );

    xthlEc_Error_If_Not_FloatVector( lv_point_x, k_pointx );
    xthlEc_Error_If_Not_FloatVector( lv_point_y, k_pointy );
    xthlEc_Error_If_Not_FloatVector( lv_point_z, k_pointz );

    xthlEd_Error_If_Not_Int32Vector( lv_facet_0, k_facet0 );
    xthlEd_Error_If_Not_Int32Vector( lv_facet_1, k_facet1 );
    xthlEd_Error_If_Not_Int32Vector( lv_facet_2, k_facet2 );
    xthlEd_Error_If_Not_Int32Vector( lv_facet_3, k_facet3 );

    xthlEc_Error_If_Not_FloatVector( lv_norml_x, k_facetnormalx );
    xthlEc_Error_If_Not_FloatVector( lv_norml_y, k_facetnormaly );
    xthlEc_Error_If_Not_FloatVector( lv_norml_z, k_facetnormalz );

    if (xmin > xmax) {FLOTYPE f = xmin; xmin = xmax; xmax = f; }
    if (ymin > ymax) {FLOTYPE f = ymin; ymin = ymax; ymax = f; }
    if (zmin > zmax) {FLOTYPE f = zmin; zmin = zmax; zmax = f; }



    /* Grab hard pointers to the relevant facet and point arrays: */

    facet_0     = ((int  *) csry_base( lv_facet_0 ));
    facet_1     = ((int  *) csry_base( lv_facet_1 ));
    facet_2     = ((int  *) csry_base( lv_facet_2 ));
    facet_3     = ((int  *) csry_base( lv_facet_3 ));

    point_x     = ((float*) csry_base( lv_point_x ));
    point_y     = ((float*) csry_base( lv_point_y ));
    point_z     = ((float*) csry_base( lv_point_z ));



    /* Search for a polygon containing our box, leave our_poly set to it: */
    {   int psz = xgrlEh_Logical_Size_Of_Grl( lv_point_grl );
        int fsz = xgrlEh_Logical_Size_Of_Grl( lv_facet_grl );
	for (our_poly = 0;   our_poly < fsz;   ++our_poly) {
	    xMin = point_x[ facet_0[our_poly] ];
	    xMax = point_x[ facet_2[our_poly] ];
	    yMin = point_y[ facet_0[our_poly] ];
	    yMax = point_y[ facet_2[our_poly] ];
	    /* Commented out 'cause it would be a pain to make following */
	    /* code in fn handle arbitrary-order rectangles...someday :) */
	    /* if (xMin > xMax) {float f = xMin; xMin = xMax; xMax = f;} */
	    /* if (yMin > yMax) {float f = yMin; yMin = yMax; yMax = f;} */
	    if (xMin < xmin   &&   xMax > xmax   &&
		yMin < ymin   &&   yMax > ymax
	    ) {
		break;
	    }
	}
	if (our_poly == fsz)   xlerror("No rect holds hole",a->lv_thing);
    }

    /* Vunderbar, ve can go ahead and allocate ze points now, ja: */

    oldPointSz = xthlEf_Resize_Grl( lv_point_grl, pointsNeeded );
    oldFacetSz = xthlEf_Resize_Grl( lv_facet_grl, facetsNeeded );
    b = oldPointSz;



    /* (Re)grab hard pointers to the relevant facet and point arrays: */

    facet_0     = ((int  *) csry_base( lv_facet_0 ));
    facet_1     = ((int  *) csry_base( lv_facet_1 ));
    facet_2     = ((int  *) csry_base( lv_facet_2 ));
    facet_3     = ((int  *) csry_base( lv_facet_3 ));

    point_x     = ((float*) csry_base( lv_point_x ));
    point_y     = ((float*) csry_base( lv_point_y ));
    point_z     = ((float*) csry_base( lv_point_z ));

    norml_x     = ((float*) csry_base( lv_norml_x ));
    norml_y     = ((float*) csry_base( lv_norml_y ));
    norml_z     = ((float*) csry_base( lv_norml_z ));



    /* Figure x-y corners of far face from those of near face,	*/
    /* by constructing a 45 degree bevel:			*/
    thickness	= zmax - zmin;
    Xmin	= doBox   ?   xmin   :   xmin + thickness;
    Xmax	= doBox   ?   xmax   :   xmax - thickness;
    Ymin	= doBox   ?   ymin   :   ymin + thickness;
    Ymax	= doBox   ?   ymax   :   ymax - thickness;
    Zmin	= point_z[ facet_0[our_poly] ];
    Zmax	= Zmin + (zmax-zmin);


    /****************************************************************************/
    /*s:xMin,yMax                                                  r:xMax,yMax	*/
    /*0:xMin,ymax 1:xmin,ymax                          2:xmax,ymax 3:xMax,ymax	*/
    /*		             4:Xmin,Ymax   5:Xmax,Ymax				*/
    /*                       6:Xmin,Ymin   7:Xmax,Ymin				*/
    /*8:xMin,ymin 9:xmin,ymin	      	               A:xmax,ymin B:xMax,ymin	*/
    /*p:xMin,yMin	                      			   q:xMax,yMin	*/
    /****************************************************************************/
    p = facet_0[ our_poly ];
    q = facet_1[ our_poly ];
    r = facet_2[ our_poly ];
    s = facet_3[ our_poly ];
    
    point_x    += oldPointSz;
    point_y    += oldPointSz;
    point_z    += oldPointSz;

    /* 0 */ *point_x++  = xMin;   *point_y++ = ymax;   *point_z++ = Zmin;
    /* 1 */ *point_x++  = xmin;   *point_y++ = ymax;   *point_z++ = Zmin;
    /* 2 */ *point_x++  = xmax;   *point_y++ = ymax;   *point_z++ = Zmin;
    /* 3 */ *point_x++  = xMax;   *point_y++ = ymax;   *point_z++ = Zmin;

    /* 4 */ *point_x++  = Xmin;   *point_y++ = Ymax;   *point_z++ = Zmax;
    /* 5 */ *point_x++  = Xmax;   *point_y++ = Ymax;   *point_z++ = Zmax;

    /* 6 */ *point_x++  = Xmin;   *point_y++ = Ymin;   *point_z++ = Zmax;
    /* 7 */ *point_x++  = Xmax;   *point_y++ = Ymin;   *point_z++ = Zmax;

    /* 8 */ *point_x++  = xMin;   *point_y++ = ymin;   *point_z++ = Zmin;
    /* 9 */ *point_x++  = xmin;   *point_y++ = ymin;   *point_z++ = Zmin;
    /* A */ *point_x++  = xmax;   *point_y++ = ymin;   *point_z++ = Zmin;
    /* B */ *point_x++  = xMax;   *point_y++ = ymin;   *point_z++ = Zmin;



    /* Update existing facet in place: */
    facet_0[ our_poly ] = b+0;
    facet_1[ our_poly ] = b+3;
    facet_2[ our_poly ] =   r;
    facet_3[ our_poly ] =   s;

    /****************************************************************************/
    /*s:xMin,yMax                                                  r:xMax,yMax	*/
    /*0:xMin,ymax 1:xmin,ymax                          2:xmax,ymax 3:xMax,ymax	*/
    /*		             4:Xmin,Ymax   5:Xmax,Ymax				*/
    /*                       6:Xmin,Ymin   7:Xmax,Ymin				*/
    /*8:xMin,ymin 9:xmin,ymin	      	               A:xmax,ymin B:xMax,ymin	*/
    /*p:xMin,yMin	                      			   q:xMax,yMin	*/
    /****************************************************************************/
    /* Deposit the new facets: */
    facet_0    += oldFacetSz;
    facet_1    += oldFacetSz;
    facet_2    += oldFacetSz;
    facet_3    += oldFacetSz;

#define A (10)
#define B (11)
    *facet_0++  = b+8;   *facet_1++ = b+9;   *facet_2++ = b+1;   *facet_3++ = b+0;
    *facet_0++  = b+A;   *facet_1++ = b+B;   *facet_2++ = b+3;   *facet_3++ = b+2;
    *facet_0++  =   p;   *facet_1++ =   q;   *facet_2++ = b+B;   *facet_3++ = b+8;

    *facet_0++  = b+9;   *facet_1++ = b+6;   *facet_2++ = b+4;   *facet_3++ = b+1;
    *facet_0++  = b+9;   *facet_1++ = b+A;   *facet_2++ = b+7;   *facet_3++ = b+6;
    *facet_0++  = b+7;   *facet_1++ = b+A;   *facet_2++ = b+2;   *facet_3++ = b+5;
    *facet_0++  = b+4;   *facet_1++ = b+5;   *facet_2++ = b+2;   *facet_3++ = b+1;

    if (!a->omit_bottom) {
      *facet_0++= b+6;   *facet_1++ = b+7;   *facet_2++ = b+5;   *facet_3++ = b+4;
    }
#undef B
#undef A

    /* Deposit the facet normals, same order as facets: */
    norml_x    += oldFacetSz;
    norml_y    += oldFacetSz;
    norml_z    += oldFacetSz;
    {   float ir2 = doBox ? 1.0 : (0.707107);
        float IR2 = doBox ? 0.0 : (0.707107);

	*norml_x++  =  0.0;   *norml_y++ =  0.0;   *norml_z++ = -1.0;
	*norml_x++  =  0.0;   *norml_y++ =  0.0;   *norml_z++ = -1.0;
	*norml_x++  =  0.0;   *norml_y++ =  0.0;   *norml_z++ = -1.0;

	*norml_x++  =  ir2;   *norml_y++ =  0.0;   *norml_z++ = -IR2;
	*norml_x++  =  0.0;   *norml_y++ =  ir2;   *norml_z++ = -IR2;
	*norml_x++  = -ir2;   *norml_y++ =  0.0;   *norml_z++ = -IR2;
	*norml_x++  =  0.0;   *norml_y++ = -ir2;   *norml_z++ = -IR2;

	if (!a->omit_bottom) {
	  *norml_x++=  0.0;   *norml_y++ =  0.0;   *norml_z++ = -1.0;
    }   }

    return NIL;
}

/* }}} */
/* {{{ xshp30_Insert_Frustum_Hole_Fn					*/

LVAL xshp30_Insert_Frustum_Hole_Fn()
{
    return xshp24_Insert(/*doBox*/FALSE, xshp29_Insert_Box_Or_Frustum_Hole );
}

/* }}} */
/* {{{ xshp32_Insert_Box_Fn						*/

LVAL xshp32_Insert_Box_Fn()
{
    return xshp24_Insert(/*doBox*/TRUE, xshp22_Insert_Box_Or_Frustum );
}

/* }}} */
/* {{{ xshp34_Insert_Ball_Fn						*/

int xshp30_GetColor() {
    LVAL lv = xlgetarg();
    float f = xgbj00_Get_Fix_Or_Flo_Num( lv );
    if (f < 0.0 || f > 1.0) xlerror("Need 0.0 <= color <= 1.0",lv);
    return (int) (255.0 * f);
}
float xshp31_Ave3( v, i,j,k )
float             *v;
int                   i,j,k;
{
    return 0.3333333 * (
	v[ i ] +
	v[ j ] +
	v[ k ]
    );
}
float xshp32_Ave4( v, i,j,k,l )
float             *v;
int                   i,j,k,l;
{
    return 0.25 * (
	v[ i ] +
	v[ j ] +
	v[ k ] +
	v[ l ]
    );
}
#undef  PI
#define PI (3.1415926536)

LVAL xshp33_Insert_Ball(
    struct xshp06_Args_Rec*  a
) {
    float scalex_inv   = 1.0 / (a->radius * a->scalex);
    float scaley_inv   = 1.0 / (a->radius * a->scaley);
    float scalez_inv   = 1.0 / (a->radius * a->scalez);

    /* Compute number of points and facets we'll need: */
    int   points_side0 = (a->u_points + a->v_points) >> 1;
    int   points_side1 = (points_side0 < 3)   ?              3   :   points_side0  ;
    int   odd_points   = (points_side1 & 1)   ?   points_side1   :   points_side1+1;
    int     phi_points = odd_points;
    int   theta_points = odd_points;
    int   pnts         = phi_points * theta_points;
    int     phi_sides  = phi_points-1;
    int   theta_sides  = theta_points;
    int   squares      = phi_sides * theta_sides;

    /* Index variables for azimuthal and longitudinal angles, respectively: */
    float phi          =  -(PI * 0.5);
    float theta        =  -(PI      );

    /* Amounts by which to increment the spherical angles: */
    float delta_phi    = (      PI) / (phi_points -1); /* -1 'cause want both poles. */
    float delta_theta  = (2.0 * PI) / (theta_points ); /* No -1, don't want dup pts. */

    int   point_index  = 0;
    int   facet_index  = 0;
    int   i, j;

    LVAL lv_pointGrl;
    LVAL lv_facetGrl;

    int   facets;
    int   fcts;

    /* Allocate needed numbers of points and facets, remembering old number: */
    int pbase;
    int fbase;

    gt_tri_rec r;

    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, a->lv_thing );
/*    int        csux2   = !r.got_triangles ? xlerror("No :FACET-2!",lv_facetGrl) : 0;*/

    /* Find our relations: */
    if (r.got_points) {
	lv_pointGrl   = xthlA2_Get_Point_Relation_From_Thing( a->lv_thing );
    } else {
	return NIL;
    }
    if (r.got_segments) {
	lv_facetGrl   = xthlA4_Get_Facet_Relation_From_Thing( a->lv_thing );
    }
    if      (r.got_rectangles)   facets =   squares              ;
    else if (r.got_triangles)    facets = 2*squares-2*theta_sides;
    else if (r.got_segments)     facets = 2*squares-  theta_sides;
    else                         facets = 0;

    if (a->want_holes)   fcts = facets / 2;
    else                 fcts = facets    ;

    /* Allocate required numbers of points and facets, remembering old number: */
    if (r.got_points)   pbase = xthlEf_Resize_Grl( lv_pointGrl, pnts );
    if (r.got_segments) fbase = xthlEf_Resize_Grl( lv_facetGrl, fcts );

    /* Reload r, because resizing may have moved (realloc()ed) stuff in ram: */
    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, a->lv_thing );

    /* Define the points.  Phi runs pole-to-pole */
    /* while theta runs on lattitude lines:      */
    for     (i = 0;   i < theta_points;   ++i) {
	phi = -(PI / 2.0);
        for (j = 0;   j <   phi_points;   ++j) {

	    /* Current point, centered on origin: */
	    float xr = a->radius * a->scalex * cos(theta) * ( cos(phi));
	    float yr = a->radius * a->scaley              * (-sin(phi));
	    float zr = a->radius * a->scalez * sin(theta) * ( cos(phi));

	    /* Same point, translated by user-specified origin: */
	    r.x[ pbase + point_index ] = xr + a->x;
	    r.y[ pbase + point_index ] = yr + a->y;
	    r.z[ pbase + point_index ] = zr + a->z;

	    if (r.got_point_textures) {
		r.ptu[ pbase + point_index ] =     ((theta+    PI)/(2.0 * PI));
		r.ptv[ pbase + point_index ] = 1.0-((phi  +0.5*PI)/       PI );
	    }
	    if (r.got_point_normals) {
		r.pnx[ pbase + point_index ] = xr * scalex_inv;
		r.pny[ pbase + point_index ] = yr * scaley_inv;
		r.pnz[ pbase + point_index ] = zr * scalez_inv;
	    }
	    if (r.got_point_colors) {
		float weight0 = (float)j / (float) phi_sides;   /* 0->1 pole->pole*/
		float weight1 = 1.0 - weight0;			/* 1->0 pole->pole*/
		int   red     = (int) (weight0*a->red + weight1*a->red_b);
		int   grn     = (int) (weight0*a->grn + weight1*a->grn_b);
		int   blu     = (int) (weight0*a->blu + weight1*a->blu_b);
		r.pr[ pbase + point_index ] = red;
		r.pg[ pbase + point_index ] = grn;
		r.pb[ pbase + point_index ] = blu;
	    }

	    /* Next point and an upward azimuthal rotation: */
	   point_index += 1;
	   phi         += delta_phi;
	}

	/* Longitudinal rotation: */
	theta	       += delta_theta;
    }
    /* Cheap insurance: */
    if (pbase + point_index > r.pLen) {
	fprintf(stderr,
	    "r.pLen d=%d vs pbase + point_index d=%d\n",
	    r.pLen,   pbase + point_index
	);
        abort();
    }
    if (!r.got_segments)   return NIL;

    /* Define the facets.  One or two triangles, or one rectangle, per square: */
    for     (i = 0;   i < theta_sides;   ++i) {
        for (j = 0;   j <   phi_sides;   ++j) {
	    int pick    = !((i+j)&1);	/* Test for even. */
	    int lo_left = pbase + i*phi_points   +   j;
	    int hi_left = lo_left + 1          ;
	    int lo_roit = (i==theta_sides-1) ? pbase+j : lo_left+phi_points;
	    int hi_roit = lo_roit + 1          ;
	    int       f = fbase + facet_index;
	    if (r.got_rectangles) {
		if (pick || !a->want_holes) {
		    r.f0[f] = lo_left;
		    r.f1[f] = hi_left;
		    r.f2[f] = hi_roit;
		    r.f3[f] = lo_roit;
		    if (r.got_facet_normals) {
			float x=xshp32_Ave4(r.x,lo_left,hi_left,lo_roit,hi_roit);
			float y=xshp32_Ave4(r.y,lo_left,hi_left,lo_roit,hi_roit);
			float z=xshp32_Ave4(r.z,lo_left,hi_left,lo_roit,hi_roit);
			float m=1.0 / sqrt(x*x + y*y + z*z);
			r.fnx[f] = x*m;
			r.fny[f] = y*m;
			r.fnz[f] = z*m;
		    }
		    if (r.got_facet_colors) {
			r.fr[f]  = pick ? a->red : a->red_b;
			r.fg[f]  = pick ? a->grn : a->grn_b;
			r.fb[f]  = pick ? a->blu : a->blu_b;
		    }

		    /* Enter our facet texture coords: */
		    if (r.got_facet_textures) {
			r.ftu0[f] = 0.0; r.ftv0[f] = 0.0;
			r.ftu1[f] = 1.0; r.ftv1[f] = 0.0;
			r.ftu2[f] = 1.0; r.ftv2[f] = 1.0;
			r.ftu3[f] = 0.0; r.ftv3[f] = 1.0;
		    }

		    ++facet_index;
		    ++f;
		}
	    } else if (r.got_triangles) {
		/* Triangle covering lower half of square: */
		if (j > 0) { /* Skip triangles that collapse to lines. */
		    r.f0[f] = lo_left;
		    r.f1[f] = hi_left;
		    r.f2[f] = lo_roit;
		    if (r.got_facet_normals) {
			float x=xshp31_Ave3(r.x,lo_left,hi_left,lo_roit);
			float y=xshp31_Ave3(r.y,lo_left,hi_left,lo_roit);
			float z=xshp31_Ave3(r.z,lo_left,hi_left,lo_roit);
			float m=1.0 / sqrt(x*x + y*y + z*z);
			r.fnx[f] = x*m;
			r.fny[f] = y*m;
			r.fnz[f] = z*m;
		    }
		    if (r.got_facet_colors) {
			r.fr[f]  = pick ? a->red : a->red_b;
			r.fg[f]  = pick ? a->grn : a->grn_b;
			r.fb[f]  = pick ? a->blu : a->blu_b;
		    }
		    if (r.got_facet_textures) {
			r.ftu0[f] = 1.0; r.ftv0[f] = 1.0;
			r.ftu1[f] = 0.0; r.ftv1[f] = 0.0;
			r.ftu2[f] = 0.0; r.ftv2[f] = 1.0;
		    }

		    ++facet_index;
		    ++f;
		}

		/* Triangle covering upper half of square: */
		if (!a->want_holes   &&   j < phi_sides-1) {
		    r.f0[f] = hi_roit;
		    r.f1[f] = lo_roit;
		    r.f2[f] = hi_left;
		    if (r.got_facet_normals) {
			float x=xshp31_Ave3(r.x,hi_roit,lo_roit,hi_left);
			float y=xshp31_Ave3(r.y,hi_roit,lo_roit,hi_left);
			float z=xshp31_Ave3(r.z,hi_roit,lo_roit,hi_left);
			float m=1.0 / sqrt(x*x + y*y + z*z);
			r.fnx[f] = x*m;
			r.fny[f] = y*m;
			r.fnz[f] = z*m;
		    }
		    if (r.got_facet_colors) {
			r.fr[f]  = pick ? a->red : a->red_b;
			r.fg[f]  = pick ? a->grn : a->grn_b;
			r.fb[f]  = pick ? a->blu : a->blu_b;
		    }
		    if (r.got_facet_textures) {
			r.ftu0[f] = 0.0; r.ftv0[f] = 0.0;
			r.ftu1[f] = 1.0; r.ftv1[f] = 1.0;
			r.ftu2[f] = 1.0; r.ftv2[f] = 0.0;
		    }
		    ++facet_index;
		    ++f;
                }
	    } else if (r.got_segments) {
		if (pick || !a->want_holes) {
		    if (j > 0) { /* Skip lines that collapse to points. */
			r.f0[f] = lo_left;
			r.f1[f] = lo_roit;
			if (r.got_facet_normals) {
			    float x=xshp32_Ave4(r.x,lo_left,lo_roit,lo_left,lo_roit);
			    float y=xshp32_Ave4(r.y,lo_left,lo_roit,lo_left,lo_roit);
			    float z=xshp32_Ave4(r.z,lo_left,lo_roit,lo_left,lo_roit);
			    float m=1.0 / sqrt(x*x + y*y + z*z);
			    r.fnx[f] = x*m;
			    r.fny[f] = y*m;
			    r.fnz[f] = z*m;
			}
			if (r.got_facet_colors) {
			    r.fr[f]  = pick ? a->red : a->red_b;
			    r.fg[f]  = pick ? a->grn : a->grn_b;
			    r.fb[f]  = pick ? a->blu : a->blu_b;
			}
			++facet_index;
			++f;
		    }

		    r.f0[f] = lo_left;
		    r.f1[f] = hi_left;
		    if (r.got_facet_normals) {
			float x=xshp32_Ave4(r.x,lo_left,hi_left,lo_left,hi_left);
			float y=xshp32_Ave4(r.y,lo_left,hi_left,lo_left,hi_left);
			float z=xshp32_Ave4(r.z,lo_left,hi_left,lo_left,hi_left);
			float m=1.0 / sqrt(x*x + y*y + z*z);
			r.fnx[f] = x*m;
			r.fny[f] = y*m;
			r.fnz[f] = z*m;
		    }
		    if (r.got_facet_colors) {
			r.fr[f]  = pick ? a->red : a->red_b;
			r.fg[f]  = pick ? a->grn : a->grn_b;
			r.fb[f]  = pick ? a->blu : a->blu_b;
		    }
		    ++facet_index;
		    ++f;
    }   }   }   }
    /* Cheap insurance: */
    if (fbase + facet_index > r.fLen) {
	fprintf(stderr,
	    "r.fLen d=%d vs fbase %d + facet_index %d d=%d\n",
	    r.fLen,   fbase , facet_index,   fbase + facet_index
	);
	abort();
    }


    /* Transform points if requested: */
    if (a->lv_xtfm != NIL) {
	xthlK1_TransformThing(
	    a->lv_thing,
	    xtfm9b_Find_Matrix( a->lv_xtfm ),
	    pbase,
	    fbase
	);
    }

    return NIL;
}
#undef  PI
LVAL xshp39_Insert_Ball_Fn()
{
    struct xshp06_Args_Rec      a  ;
    xshp08_Parse_Shape_Args(   &a );
    return xshp33_Insert_Ball( &a );
}

/* }}} */
/* {{{ xshp44_Insert_Grid_Fn						*/

LVAL xshp43_Insert_Grid(
    struct xshp06_Args_Rec*  a
) {
    /* Find our relations: */
    LVAL lv_pointGrl	= xthlA2_Get_Point_Relation_From_Thing( a->lv_thing );
    LVAL lv_facetGrl	= xthlA4_Get_Facet_Relation_From_Thing( a->lv_thing );

    /* Compute number of points and facets we'll need: */
    gt_tri_rec r;
    int        csux0	= xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    int        csux1	= xthlB1_Process_Thing( &r, a->lv_thing );
    int   points_side0	= ((a->u_points + a->v_points) >> 1) +1;
    int   points_side	= (points_side0 < 3)   ?  3   :   points_side0  ;
    int   pnts		=  points_side * points_side;
    int   side_count	=  points_side -1;
    int   squares	=  side_count * side_count;	/* Provably 0mod4 */
    int   fcts;
    if (r.got_triangles) {
	int   facets	=  r.got_rectangles ? squares : 2*squares;
        fcts		=  a->want_holes ? (facets>>1) + (facets&1) : facets;
    } else if (r.got_segments) {
        fcts		=  squares*2 + side_count*2;
    } else {
        fcts		=  0;
    }
    {   float stepx		= a->scalex / side_count;
	float stepy		= a->scaley / side_count;

	/* Allocate required #s of points & facets, remembering old number: */
	int pbase		= xthlEf_Resize_Grl( lv_pointGrl, pnts );
	int fbase		= xthlEf_Resize_Grl( lv_facetGrl, fcts );

	/* Reload r, resizing may have moved (realloc()ed) stuff in ram: */
	int        csux3	= xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
	int        csux4	= xthlB1_Process_Thing( &r, a->lv_thing );

	/* Define the points: */
	int   point_index	= 0;
	int   facet_index	= 0;
	int   i, j;
	for     (i = 0;   i < points_side;   ++i) {
	    for (j = 0;   j < points_side;   ++j) {

		/* Current point: */
		float half_sidex   = 0.5 * stepx * (float)side_count;
		float half_sidey   = 0.5 * stepy * (float)side_count;
		float x = a->x - half_sidex + (float)i * stepx;
		float y = a->y - half_sidey + (float)j * stepy;
		float z = a->z                              ;

		int pick    = !((i+j)&1);	/* Test for even. */

		r.x[ pbase + point_index ] = x;
		r.y[ pbase + point_index ] = y;
		r.z[ pbase + point_index ] = z;

		if (r.got_point_textures) {
		    r.ptu[pbase+point_index]=((float)i)/(float)(points_side-1);
		    r.ptv[pbase+point_index]=((float)j)/(float)(points_side-1);
		}
		if (r.got_point_normals) {
		    r.pnx[ pbase + point_index ] =  0.0;
		    r.pny[ pbase + point_index ] =  0.0;
		    r.pnz[ pbase + point_index ] = -1.0;
		}
		if (r.got_point_colors) {
		    r.pr[ pbase + point_index ] = pick ? a->red : a->red_b;
		    r.pg[ pbase + point_index ] = pick ? a->grn : a->grn_b;
		    r.pb[ pbase + point_index ] = pick ? a->blu : a->blu_b;
		}

		/* Next point and an upward azimuthal rotation: */
	       point_index += 1;
	}   }

	/* Define the facets: */
	for     (i = 0;   i < side_count;   ++i) {
	    for (j = 0;   j < side_count;   ++j) {
		int pick    = !((i+j)&1);	/* Test for even. */
		int lo_left = pbase + points_side * i   +   j;
		int lo_roit = lo_left + 1          ;
		int hi_left = lo_left + points_side;
		int hi_roit = hi_left + 1          ;
		int       f = fbase + facet_index;
		if (r.got_rectangles) {
		    if (pick || !a->want_holes) {
			r.f0[f] = lo_roit;
			r.f1[f] = hi_roit;
			r.f2[f] = hi_left;
			r.f3[f] = lo_left;
			if (r.got_facet_textures) {
			    r.ftu0[f] = 0.0; r.ftv0[f] = 1.0;
			    r.ftu1[f] = 1.0; r.ftv1[f] = 1.0;
			    r.ftu2[f] = 1.0; r.ftv2[f] = 0.0;
			    r.ftu3[f] = 0.0; r.ftv3[f] = 0.0;
			}
			if (r.got_facet_normals) {
			    r.fnx[f] =  0.0;
			    r.fny[f] =  0.0;
			    r.fnz[f] = -1.0;
			}
			if (r.got_facet_colors) {
			    r.fr[f]  = pick ? a->red : a->red_b;
			    r.fg[f]  = pick ? a->grn : a->grn_b;
			    r.fb[f]  = pick ? a->blu : a->blu_b;
			}
			++facet_index;
			++f;
		    }
		} else if (r.got_triangles) {
		    /* Triangle covering lower half of square: */
		    r.f0[f] = lo_roit;
		    r.f1[f] = hi_left;
		    r.f2[f] = lo_left;
		    if (r.got_facet_textures) {
			r.ftu0[f] = 0.0; r.ftv0[f] = 1.0;
			r.ftu1[f] = 1.0; r.ftv1[f] = 0.0;
			r.ftu2[f] = 0.0; r.ftv2[f] = 0.0;
		    }
		    if (r.got_facet_normals) {
			r.fnx[f] =  0.0;
			r.fny[f] =  0.0;
			r.fnz[f] = -1.0;
		    }
		    if (r.got_facet_colors) {
			r.fr[f]  = pick ? a->red : a->red_b;
			r.fg[f]  = pick ? a->grn : a->grn_b;
			r.fb[f]  = pick ? a->blu : a->blu_b;
		    }
		    ++facet_index;
		    ++f;

		    /* Triangle covering upper half of square: */
		    if (!a->want_holes) {
			r.f0[f] = hi_left;
			r.f1[f] = lo_roit;
			r.f2[f] = hi_roit;
			if (r.got_facet_textures) {
			    r.ftu0[f] = 1.0; r.ftv0[f] = 0.0;
			    r.ftu1[f] = 0.0; r.ftv1[f] = 1.0;
			    r.ftu2[f] = 1.0; r.ftv2[f] = 1.0;
			}
			if (r.got_facet_normals) {
			    r.fnx[f] =  0.0;
			    r.fny[f] =  0.0;
			    r.fnz[f] = -1.0;
			}
			if (r.got_facet_colors) {
			    r.fr[f]  = pick ? a->red : a->red_b;
			    r.fg[f]  = pick ? a->grn : a->grn_b;
			    r.fb[f]  = pick ? a->blu : a->blu_b;
			}
			++facet_index;
			++f;
		    }
		} else if (r.got_segments) {
		    r.f0[f] = lo_left;   r.f1[f] = hi_left;
		    if (r.got_facet_normals) {
			r.fnx[f] =  0.0;
			r.fny[f] =  0.0;
			r.fnz[f] = -1.0;
		    }
		    if (r.got_facet_colors) {
			r.fr[f]  = pick ? a->red : a->red_b;
			r.fg[f]  = pick ? a->grn : a->grn_b;
			r.fb[f]  = pick ? a->blu : a->blu_b;
		    }
		    ++facet_index;
		    ++f;

		    r.f0[f] = lo_left;   r.f1[f] = lo_roit;
		    if (r.got_facet_normals) {
			r.fnx[f] =  0.0;
			r.fny[f] =  0.0;
			r.fnz[f] = -1.0;
		    }
		    if (r.got_facet_colors) {
			r.fr[f]  = pick ? a->red : a->red_b;
			r.fg[f]  = pick ? a->grn : a->grn_b;
			r.fb[f]  = pick ? a->blu : a->blu_b;
		    }
		    ++facet_index;
		    ++f;

		    if (i == side_count-1) {
			r.f0[f] = lo_roit;   r.f1[f] = hi_roit;
			if (r.got_facet_normals) {
			    r.fnx[f] =  0.0;
			    r.fny[f] =  0.0;
			    r.fnz[f] = -1.0;
			}
			if (r.got_facet_colors) {
			    r.fr[f]  = pick ? a->red : a->red_b;
			    r.fg[f]  = pick ? a->grn : a->grn_b;
			    r.fb[f]  = pick ? a->blu : a->blu_b;
			}
			++facet_index;
			++f;
		    }
		    if (j == side_count-1) {
			r.f0[f] = hi_left;   r.f1[f] = hi_roit;
			if (r.got_facet_normals) {
			    r.fnx[f] =  0.0;
			    r.fny[f] =  0.0;
			    r.fnz[f] = -1.0;
			}
			if (r.got_facet_colors) {
			    r.fr[f]  = pick ? a->red : a->red_b;
			    r.fg[f]  = pick ? a->grn : a->grn_b;
			    r.fb[f]  = pick ? a->blu : a->blu_b;
			}
			++facet_index;
			++f;
	}   }   }   }



	/* Cheap insurance: */
	if (fbase + facet_index > r.fLen   ||
	    pbase + point_index > r.pLen
	) {
	    abort();
    	}

	/* Transform points if requested: */
	if (a->lv_xtfm != NIL) {
	    xthlK1_TransformThing(
		a->lv_thing,
		xtfm9b_Find_Matrix( a->lv_xtfm ),
		pbase,
		fbase
	    );
	}
    }

    return NIL;
}
LVAL xshp44_Insert_Grid_Fn()
{
    struct xshp06_Args_Rec      a  ;
    xshp08_Parse_Shape_Args(   &a );
    return xshp43_Insert_Grid( &a );
}

/* }}} */
/* {{{ xshp54_Insert_Rod_Fn						*/

LVAL xshp53_Insert_Rod(
    struct xshp06_Args_Rec*  a
) {
    /* Find our relations: */
    LVAL lv_pointGrl	= xthlA2_Get_Point_Relation_From_Thing( a->lv_thing );
    LVAL lv_facetGrl	= xthlA4_Get_Facet_Relation_From_Thing( a->lv_thing );

    /* Compute number of points and facets we'll need.	*/
    /* We wrap an internal i-coord around rod,		*/
    /* we run  an internal j-coord along  rod.		*/
    gt_tri_rec r;
    int        csux0	= xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    int        csux1	= xthlB1_Process_Thing( &r, a->lv_thing );
    int   pnts		=  a->u_points * a->v_points;
    int   i_squares	=  a->u_points;	/* Because we wrap around. */
    int   j_squares	=  a->v_points -1;
    int   squares	=  i_squares * j_squares;
    int   fcts;
    if (r.got_triangles) {
	int   facets	=  r.got_rectangles ? squares : 2*squares;
        fcts		=  a->want_holes ? (facets>>1) + (facets&1) : facets;
    } else if (r.got_segments) {
        fcts		=  squares*2 + i_squares;
    } else {
        fcts		=  0;
    }

    {   /* Allocate required #s of points & facets, remembering old number: */
	int pbase		= xthlEf_Resize_Grl( lv_pointGrl, pnts );
	int fbase		= xthlEf_Resize_Grl( lv_facetGrl, fcts );

	/* Reload r, resizing may have moved (realloc()ed) stuff in ram: */
	int        csux3	= xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
	int        csux4	= xthlB1_Process_Thing( &r, a->lv_thing );

	int   point_index	= 0;
	int   facet_index	= 0;
	int   i			= 0;
	int   j			= 0;


	geo_point  p0;	/* One end of rod.				*/
	geo_point  p1;	/* Other end of rod.				*/
	geo_point  d10;	/* p1 - p0.					*/
	geo_point  d2;	/* Any  offset not a scaling of d10.		*/
	geo_point  d3;	/* Unit offset perpendicular to d10.		*/
	geo_matrix rot;	/* Origin p0, axis p1-p0, angle from i_points.	*/
	geo_point  p2;	/* Start: p0 + k*d3. Rotates for circumference.	*/
	geo_point  p3;	/* Start: p1 + k*d3. Rotates for circumference.	*/
	geo_point  zero;/* 0,0,0					*/
	zero.x = 0.0;
	zero.y = 0.0;
	zero.z = 0.0;

	if (!a->got_radius_b) a->radius_b = a->radius;

	/* Make sure p0=(x0,y0,z0) != p1=(x1,y1,z1): */
	p0.x = a->x0;	p1.x = a->x1;
	p0.y = a->y0;	p1.y = a->y1;
	p0.z = a->z0;	p1.z = a->z1;
	if (p0.x==p1.x && p0.y==p1.y && p0.z==p1.z)  p1.z += 1.0;

	/* Find difference between p0 and p1: */
	lib11_Vector_Subtract( &d10, &p1, &p0 );
	
	/* Find an offset d2 not co-linear with d10: */
	if (d10.x != d10.z) {
	    d2.x = d10.z;
	    d2.y = 0.0;
	    d2.z = d10.x;
	} else {
	    d2.x = 1.0;
	    d2.y = 0.0;
	    d2.z = 0.0;
	}

	/* Take cross-product to get an    */
	/* offset d3 perpendicular to d10: */
	lib00_Vector_Cross_Product( &d3, &d2, &d10 );

	/* Normalize d3 to unit length: */
	lib08_Vector_Normalize( &d3 );

	/* Construct a rotation matrix with 0,0,0  */
	/* as the origin and p1-p0 as the axis of  */
	/* rotation:                               */
	ctfm31_Rotate( &rot, &zero, &d10, (3.1416*2.0) / (float)a->u_points );

	/* Construct a point p2 == p0 + d3*radius; */
        /* we will rotate around p0 to produce the */
	/* circumference of the rod:               */
	p2.x = p0.x + d3.x * a->radius;
	p2.y = p0.y + d3.y * a->radius;
	p2.z = p0.z + d3.z * a->radius;

	/* A matching point p3 == p1 + d3*radius_b: */
	p3.x = p1.x + d3.x * a->radius_b;
	p3.y = p1.y + d3.y * a->radius_b;
	p3.z = p1.z + d3.z * a->radius_b;


	/* Define the points: */
	for     (i = 0;   i < i_squares;   ++i) {

	    geo_point P2;	/* Next p2.	*/
	    geo_point P3;	/* next p3.	*/
	    geo_point D3;	/* next d3.	*/

	    /* If we're leaving holes, decide */
	    /* whether to skip this facet:    */
	    int pick    = !((i+j)&1);	/* Test for even. */

	    /* Compute point-grl indices for the */
	    /* corners of current rectangle. We	 */
	    /* take p2 as 'lo'    p3 as 'hi',    */
	    /* take p2 as 'left', P2 as 'roit':	 */
	    int lo_left = pbase + point_index;		/* p2 */
	    int hi_left = pbase + point_index +1;	/* p3 */
	    int lo_roit = pbase + point_index +2;	/* P2 */
	    int hi_roit = pbase + point_index +3;	/* P3 */

	    /* Generate next d3 normal: */
	    lib26_Matrix_Apply_To_Point( &D3, &d3, &rot );

	    /* Generate next p2,p3 points: */
	    P2.x = p0.x + D3.x * a->radius;
	    P2.y = p0.y + D3.y * a->radius;
	    P2.z = p0.z + D3.z * a->radius;

	    P3.x = p1.x + D3.x * a->radius_b;
	    P3.y = p1.y + D3.y * a->radius_b;
	    P3.z = p1.z + D3.z * a->radius_b;

	    /* Remember to wrap around on last strip: */
	    if (i == i_squares -1) {
		lo_roit = pbase +0;
		hi_roit = pbase +1;
	    }

	    /* Enter the two current points into point relation: */
	    r.x[ pbase + point_index    ] = p2.x;
	    r.y[ pbase + point_index    ] = p2.y;
	    r.z[ pbase + point_index    ] = p2.z;

	    r.x[ pbase + point_index +1 ] = p3.x;
	    r.y[ pbase + point_index +1 ] = p3.y;
	    r.z[ pbase + point_index +1 ] = p3.z;

	    if (r.got_point_normals) {

		r.pnx[ pbase + point_index    ] = d3.x;
		r.pny[ pbase + point_index    ] = d3.y;
		r.pnz[ pbase + point_index    ] = d3.z;

		r.pnx[ pbase + point_index +1 ] = d3.x;
		r.pny[ pbase + point_index +1 ] = d3.y;
		r.pnz[ pbase + point_index +1 ] = d3.z;
	    }

	    if (r.got_point_colors) {

		r.pr[ pbase + point_index    ] = a->red;
		r.pg[ pbase + point_index    ] = a->grn;
		r.pb[ pbase + point_index    ] = a->blu;

		r.pr[ pbase + point_index +1 ] = a->red;
		r.pg[ pbase + point_index +1 ] = a->grn;
		r.pb[ pbase + point_index +1 ] = a->blu;
	    }

	    if (r.got_point_textures) {
		float tex = 3.0 * ((float)i / (float)i_squares) - 1.0;

		r.ptu[ pbase + point_index    ] =  tex;
		r.ptv[ pbase + point_index    ] = -1.0;

		r.ptu[ pbase + point_index +1 ] =  tex;
		r.ptv[ pbase + point_index +1 ] =  2.0;
	    }

	    point_index += 2;

	    /* Enter the current facet into facet relation: */
	    if (r.got_rectangles) {

		int f = fbase + facet_index;
		facet_index   += 1;

		r.f0[f] = lo_left;
		r.f1[f] = lo_roit;
		r.f2[f] = hi_roit;
		r.f3[f] = hi_left;

		if (r.got_facet_normals) {

		    geo_point a;	/* Average of d3, D3.	*/

		    lib12_Vector_Sum(       &a, &d3, &D3 );
		    lib08_Vector_Normalize( &a );

		    r.fnx[f] = a.x;
		    r.fny[f] = a.y;
		    r.fnz[f] = a.z;
		}

		if (r.got_facet_colors) {
		    r.fr[f] = a->red;
		    r.fg[f] = a->grn;
		    r.fb[f] = a->blu;
		}

		if (r.got_facet_textures) {

		    float t_left = (float)(i  ) / (float)i_squares;
		    float t_roit = (float)(i+1) / (float)i_squares;
		    float t_hi   = 1.0;
		    float t_lo   = 0.0;

		    r.ftu0[f] =  t_left;   r.ftv0[f] = t_lo;
		    r.ftu1[f] =  t_roit;   r.ftv1[f] = t_lo;
		    r.ftu2[f] =  t_roit;   r.ftv2[f] = t_hi;
		    r.ftu3[f] =  t_left;   r.ftv3[f] = t_hi;
		}

	    } else if (r.got_triangles) {

		int f = fbase + facet_index;
		facet_index   += 2;

		r.f0[ f   ] = lo_left;
		r.f1[ f   ] = lo_roit;
		r.f2[ f   ] = hi_roit;

		r.f0[ f+1 ] = lo_left;
		r.f1[ f+1 ] = hi_roit;
		r.f2[ f+1 ] = hi_left;

		if (r.got_facet_normals) {

		    geo_point a;	/* Average of d3, D3.	*/

		    lib12_Vector_Sum(       &a, &d3, &D3 );
		    lib08_Vector_Normalize( &a );

		    r.fnx[ f   ] = a.x;
		    r.fny[ f   ] = a.y;
		    r.fnz[ f   ] = a.z;

		    r.fnx[ f+1 ] = a.x;
		    r.fny[ f+1 ] = a.y;
		    r.fnz[ f+1 ] = a.z;
		}

		if (r.got_facet_colors) {

		    r.fr[ f   ] = a->red;
		    r.fg[ f   ] = a->grn;
		    r.fb[ f   ] = a->blu;

		    r.fr[ f+1 ] = a->red;
		    r.fg[ f+1 ] = a->grn;
		    r.fb[ f+1 ] = a->blu;
		}

		if (r.got_facet_textures) {

		    float t_left = (float)(i  ) / (float)i_squares;
		    float t_roit = (float)(i+1) / (float)i_squares;
		    float t_hi   = 1.0;
		    float t_lo   = 0.0;

		    r.ftu0[ f    ] =  t_left;   r.ftv0[ f    ] = t_lo;
		    r.ftu1[ f    ] =  t_roit;   r.ftv1[ f    ] = t_lo;
		    r.ftu2[ f    ] =  t_roit;   r.ftv2[ f    ] = t_hi;

		    r.ftu0[ f +1 ] =  t_left;   r.ftv0[ f +1 ] = t_lo;
		    r.ftu1[ f +1 ] =  t_roit;   r.ftv1[ f +1 ] = t_hi;
		    r.ftu2[ f +1 ] =  t_left;   r.ftv2[ f +1 ] = t_hi;
		}

	    } else if (r.got_segments) {

		int f = fbase + facet_index;

		facet_index += 2;

		r.f0[ f   ] = lo_left;
		r.f1[ f   ] = hi_left;

		r.f0[ f+1 ] = lo_left;
		r.f1[ f+1 ] = lo_roit;

		if (j == j_squares-1) {

		    facet_index += 1;

		    r.f0[ f+2 ] = hi_left;
		    r.f1[ f+2 ] = hi_roit;
		}

		if (r.got_facet_colors) {

		    r.fr[ f   ] = a->red;
		    r.fg[ f   ] = a->grn;
		    r.fb[ f   ] = a->blu;

		    r.fr[ f+1 ] = a->red;
		    r.fg[ f+1 ] = a->grn;
		    r.fb[ f+1 ] = a->blu;
		}

		if (r.got_facet_normals) {
		    geo_point a;	/* Average of d3, D3.	*/
		    lib12_Vector_Sum(       &a, &d3, &D3 );
		    lib08_Vector_Normalize( &a );

		    r.fnx[ f   ] = d3.x;
		    r.fny[ f   ] = d3.y;
		    r.fnz[ f   ] = d3.z;

		    r.fnx[ f+1 ] = a.x;
		    r.fny[ f+1 ] = a.y;
		    r.fnz[ f+1 ] = a.z;

		    if (j == j_squares-1) {

			r.fnx[ f+2 ] = a.x;
			r.fny[ f+2 ] = a.y;
			r.fnz[ f+2 ] = a.z;
	    }	}   }

	    /* Step our normal and endpoints around: */
	    p2 = P2;
	    p3 = P3;
	    d3 = D3;
	}


	/* Cheap insurance: */
	if (fbase + facet_index > r.fLen   ||
	    pbase + point_index > r.pLen
	) {
	    abort();
    	}

	/* Transform points if requested: */
	if (a->lv_xtfm != NIL) {
	    xthlK1_TransformThing(
		a->lv_thing,
		xtfm9b_Find_Matrix( a->lv_xtfm ),
		pbase,
		fbase
	    );
    }	}

    return NIL;
}
LVAL xshp54_Insert_Rod_Fn()
{
    struct xshp06_Args_Rec     a  ;
    xshp08_Parse_Shape_Args(  &a );
    a.v_points = 2;    /* no other value works yet... (kph, 1998Oct21) */
    return xshp53_Insert_Rod( &a );
}

/* }}} */
/* {{{ xshpE1_Insert_Hershey_String_Fn Convert string to grl points.	*/

/* {{{ struct xshpER_rec -- Context while inserting Hershey symbol(s)	*/

struct xshpER_rec {
    int    point_index;
    int    facet_index;

    int    old_point_size;
    int    old_facet_size;

    int*   facet_0;
    int*   facet_1;
    int*   facet_2;
    int*   facet_3;

    float* point_x;
    float* point_y;
    float* point_z;

    float* point_xx;
    float* point_yy;
    float* point_zz;

    float  cursorX;
    float  cursorY;
    float  cursorZ;

    float  cursorXX;
    float  cursorYY;
    float  cursorZZ;

    float  lastX;
    float  lastY;
    float  lastZ;

    float  leftMargin;
    float  vertSpacing;

    float  scalex;
    float  scaley;
    float  scalez;

    int    pointsNeeded;
    int    facetsNeeded;

    LVAL  lv_point_grl;
    LVAL  lv_facet_grl;

    LVAL  lv_point_x;
    LVAL  lv_point_y;
    LVAL  lv_point_z;

    LVAL  lv_facet_0;
    LVAL  lv_facet_1;
    LVAL  lv_facet_2;
    LVAL  lv_facet_3;

    int   got_segments;
    int   got_triangles;
    int   got_rectangles;

    LVAL  s_cursor_x;
    LVAL  s_cursor_y;
    LVAL  s_cursor_z;

    LVAL *pPropList;
    struct xshp06_Args_Rec*  a;
};

/* Forward declarations: */
void xshpE4_Fill_ER_Rec(
    LVAL  p_as_lval,
    LVAL  f_as_lval,
    struct xshpER_rec *r,
    float x0,
    float y0,
    float z0,
    int   got_xyz,
    float margin,
    int   got_margin,
    float vspacing,
    int   got_vspacing,
    float scalex,
    float scaley,
    float scalez
);
void xshpE5_Update_CursorXYZ(
    struct xshpER_rec *r
);
void xshpE8_Draw(
    struct xshpER_rec *r,
    int                penDown,
    int                x,
    int                y
);
void xshpEb_Resize_GrlPair(
    struct xshpER_rec* r
);
void xshpEc_JustifyText(
    struct xshpER_rec * r,
    LVAL	        lv_justify
);

/* }}} */
/* {{{ xshpE0_Insert_Hershey_String					*/

void
xshpE0_Insert_Hershey_String(
    struct xshp06_Args_Rec*  a
) {
    /**********************************************/
    /* Draw the given string using the given font */
    /* and stick the points in the twin grls.	  */
    /**********************************************/

    short*xhsy40_Font();
    short* fontPtr	= xhsy40_Font( a->font_num );

    LVAL cursorX_lval;

    LVAL   lv_pointGrl  = xthlA2_Get_Point_Relation_From_Thing( a->lv_thing );
    LVAL   lv_facetGrl  = xthlA4_Get_Facet_Relation_From_Thing( a->lv_thing );

    struct xshpER_rec r;
    xshpE4_Fill_ER_Rec(
	lv_pointGrl,
	lv_facetGrl,
	&r,
	a->x, a->y, a->z, a->got_p,
	a->margin,  a->got_margin,
	a->vspacing,a->got_vspacing,
	a->scalex, a->scaley, a->scalez
    );
    r.a = a;

    if (!a->text)  xlfail("No :TEXT");

    /* Count lines and points needed by string: */
    xhsy90_StringStats( a->text, fontPtr, &r.pointsNeeded, &r.facetsNeeded );

    /* Allocate space for that many more lines and points: */
    xshpEb_Resize_GrlPair( &r );

    /* Draw the string: */
    r.cursorX += (
	r.scalex *
	(float)xhsy50_String( a->text, fontPtr, xshpE8_Draw, (char*)&r )
    );

    /* Handle right/center/left justification: */
    xshpEc_JustifyText( &r, a->lv_justify );

    /* Remember the new text-cursor position; */
    /* But widget fns don't want to do this:  */
    if (a->update_cursor) xshpE5_Update_CursorXYZ( &r );

    /* Transform points if requested: */
    if (a->lv_xtfm != NIL) {
	xthlK1_TransformThing(
	    a->lv_thing,
	    xtfm9b_Find_Matrix( a->lv_xtfm ),
            r.old_point_size,
            r.old_facet_size
	);
    }
}

/* }}} */
/* {{{ xshpE2_Insert_Hershey_Symbol					*/

void
xshpE2_Insert_Hershey_Symbol(
    struct xshp06_Args_Rec*  a
) {
    /***********************************************************/
    /* Draw the given symbol and stick the points in the grl.  */
    /***********************************************************/
    LVAL cursorX_lval;
    LVAL lv_pointGrl = xthlA2_Get_Point_Relation_From_Thing( a->lv_thing );
    LVAL lv_facetGrl = xthlA4_Get_Facet_Relation_From_Thing( a->lv_thing );
    struct xshpER_rec r;
    xshpE4_Fill_ER_Rec(
	lv_pointGrl,
	lv_facetGrl,
	&r,
	a->x, a->y, a->z, a->got_p,
	a->margin,  a->got_margin,
	a->vspacing,a->got_vspacing,
	a->scalex, a->scaley, a->scalez
    );

    /* Count lines and points needed by symbol: */
    xhsy89_CharStats( a->symbol, &r.pointsNeeded, &r.facetsNeeded );

    /* Allocate space for that many more lines and points: */
    xshpEb_Resize_GrlPair( &r );

    /* Draw the symbol: */
    r.cursorX += (
	r.scalex *
        (float)xhsy60_Char( a->symbol, 0, xshpE8_Draw, (char*)&r )
    );

    /* Handle right/center/left justification: */
    xshpEc_JustifyText( &r, a->lv_justify );

    /* Remember the new text-cursor position: */
    if (a->update_cursor)   xshpE5_Update_CursorXYZ( &r );
}

/* }}} */
/* {{{ xshpE1_Insert_Hershey_String_Fn					*/

LVAL xshpE1_Insert_Hershey_String_Fn()
/*-
  Convert string to grl points.
-*/
{
    /***************************************************************/
    /* We take a line thing, a string, and a font as arguments, and*/
    /* stick points corresponding to the given string in the given */
    /* font in the given grls.					   */
    /***************************************************************/
    struct xshp06_Args_Rec    a  ;
    a.update_cursor = TRUE;
    xshp08_Parse_Shape_Args( &a );
    if (a.symbol == -1)   xshpE0_Insert_Hershey_String( &a );
    else                  xshpE2_Insert_Hershey_Symbol( &a );
    return NIL;
}

/* }}} */
/* {{{ xshpE3_Insert_Hershey_Symbol_Fn Convert symbol to grl points.	*/

LVAL xshpE3_Insert_Hershey_Symbol_Fn()
{
#ifdef OLD
    /***************************************************************/
    /* We take a line thing symbol as arguments, and  stick        */
    /* points corresponding to the given symbol in the thing grls. */
    /* Symbol is an integer index between 0 and 1594 or so.	   */
    /***************************************************************/

    /* get the point-grl, facet-grl and symbol index: */
    LVAL lv_thing	     = xlgacons();
    LVAL symbol_as_lval      = xlgafixnum();
    int  symbol 	     = getfixnum( symbol_as_lval );
    xllastarg();

    xshpE2_InsertHersheySymbol( lv_thing, symbol );
#else
    /* OK, so I cheat! */
    xshpE1_Insert_Hershey_String_Fn();
#endif
    return NIL;
}

/* }}} */
/* {{{ xshpE4_Fill_ER_Rec						*/

void
xshpE4_Fill_ER_Rec(
    LVAL  p_as_lval,
    LVAL  f_as_lval,
    struct xshpER_rec *r,
    float x0,
    float y0,
    float z0,
    int   got_xyz,
    float margin,
    int   got_margin,
    float vspacing,
    int   got_vspacing,
    float scalex,
    float scaley,
    float scalez
) {
    /***********************************************************/
    /* Track down the component arrays we need from our grls.  */
    /***********************************************************/

    LVAL*p_pArrayList = (LVAL *) xgrl13_pArrayList( p_as_lval );
    LVAL*f_pArrayList = (LVAL *) xgrl13_pArrayList( f_as_lval );
    LVAL r__s_leftMargin;
    LVAL r__s_vertSpacing;

    xthlEe_Error_If_Not_Rank_1( p_as_lval, p_as_lval );
    xthlEe_Error_If_Not_Rank_1( f_as_lval, f_as_lval );

    r->pPropList      = (LVAL*) x03d73_pPropList( f_as_lval );

    r->lv_point_grl   = p_as_lval;
    r->lv_facet_grl   = f_as_lval;

    r->s_cursor_x     = k_cursorx;
    r->s_cursor_y     = k_cursory;
    r->s_cursor_z     = k_cursorz;

    r__s_leftMargin   = k_leftmargin;
    r__s_vertSpacing  = k_verticalspacing;

    if (got_xyz) {
	r->cursorX    = x0;
	r->cursorY    = y0;
	r->cursorZ    = z0;
    } else {
	r->cursorX    = xthlE6_GetNumericProp(*r->pPropList, r->s_cursor_x, 0.0 );
	r->cursorY    = xthlE6_GetNumericProp(*r->pPropList, r->s_cursor_y, 0.0 );
	r->cursorZ    = xthlE6_GetNumericProp(*r->pPropList, r->s_cursor_z, 0.0 );
    }

    /* Spare copies of above: */
    r->cursorXX	      = r->cursorX;
    r->cursorYY       = r->cursorY;
    r->cursorZZ       = r->cursorZ;

    /* Spare copies of above: */
    r->lastX          = r->cursorX;
    r->lastY          = r->cursorY;
    r->lastZ          = r->cursorZ;

    if (got_margin) {
        r->leftMargin = margin;
	xthl82_SetProp( r->pPropList, r__s_leftMargin, cvflonum(margin)  );
    } else {
        r->leftMargin = xthlE6_GetNumericProp(*r->pPropList, r__s_leftMargin, 0.0 );
    }
    if (got_vspacing) {
        r->vertSpacing= vspacing;
	xthl82_SetProp( r->pPropList, r__s_vertSpacing, cvflonum(vspacing) );
    } else {
        r->vertSpacing= xthlE6_GetNumericProp(*r->pPropList, r__s_vertSpacing,1.0);
    }
    r->scalex	      = scalex * 0.035;
    r->scaley	      = scaley * 0.035;
    r->scalez	      = scalez * 0.035;

    r->lv_point_x     = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointx );
    r->lv_point_y     = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointy );
    r->lv_point_z     = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointz );

    xthlEc_Error_If_Not_FloatVector( r->lv_point_x, k_pointx );
    xthlEc_Error_If_Not_FloatVector( r->lv_point_y, k_pointy );
    xthlEc_Error_If_Not_FloatVector( r->lv_point_z, k_pointz );

    r->lv_facet_0     = xthl74_GetProp( f_pArrayList, k_facet0, NIL, TRUE );
    r->lv_facet_1     = xthl74_GetProp( f_pArrayList, k_facet1, NIL, TRUE );
    r->lv_facet_2     = xthl74_GetProp( f_pArrayList, k_facet2, NIL, TRUE );
    r->lv_facet_3     = xthl74_GetProp( f_pArrayList, k_facet3, NIL, TRUE );

    if (r->lv_facet_0 != NIL) {
	xthlEd_Error_If_Not_Int32Vector( r->lv_facet_0, k_facet0 );
    }
    if (r->lv_facet_1 != NIL) {
	xthlEd_Error_If_Not_Int32Vector( r->lv_facet_1, k_facet1 );
    }
    if (r->lv_facet_2 != NIL) {
	xthlEd_Error_If_Not_Int32Vector( r->lv_facet_2, k_facet2 );
    }
    if (r->lv_facet_3 != NIL) {
	xthlEd_Error_If_Not_Int32Vector( r->lv_facet_3, k_facet3 );
    }

    /* Initialize: */
    r->pointsNeeded   = 0;
    r->facetsNeeded   = 0;

    r->old_point_size = 0;
    r->old_facet_size = 0;

    r->got_segments   =    r->lv_facet_0 != NIL  &&  r->lv_facet_1 != NIL;
    r->got_triangles  =    r->got_segments       &&  r->lv_facet_2 != NIL;
    r->got_rectangles =    r->got_triangles      &&  r->lv_facet_3 != NIL;

    r->a = NULL;
}

/* }}} */
/* {{{ xshpE5_Update_CursorXYZ						*/

void xshpE5_Update_CursorXYZ(
    struct xshpER_rec *r
) {
    /* Actually, right now Z can't change during a call. */
    xthl82_SetProp( r->pPropList, r->s_cursor_x, cvflonum(r->cursorX) );
    xthl82_SetProp( r->pPropList, r->s_cursor_y, cvflonum(r->cursorY) );
}

/* }}} */
/* {{{ xshpE8_Draw							*/

void
xshpE8_Draw(
    struct xshpER_rec *r,
    int                penDown,
    int                x,
    int                y
) {
    if (penDown == -1) {

        /* Special newline hack: */
	r->cursorX  = r->leftMargin;
	r->cursorY -= r->vertSpacing;
	return;

    } else {

	/* Regular move/draw code: */
	float X = r->cursorX + r->scalex * x;
	float Y = r->cursorY + r->scaley * y;
	float Z = r->cursorZ                ;
	if (!r->got_triangles) {
	    *r->point_x++ = X;
	    *r->point_y++ = Y;
	    *r->point_z++ = Z;
	     r->point_index++;
	}

	if (r->got_triangles) {

	    r->a->x = X;
	    r->a->y = Y;
	    r->a->z = Z;

	    xshp33_Insert_Ball( r->a );
	}
	if (penDown) {
	    if (r->got_triangles /* Or rectangles */) {

		float old_radius_b = r->a->radius_b;
		int   old_v_points = r->a->v_points;

		r->a->x0 = r->lastX;
		r->a->y0 = r->lastY;
		r->a->z0 = r->lastZ;

		r->a->x1 = X;
		r->a->y1 = Y;
		r->a->z1 = Z;

		r->a->v_points = 2;

		xshp53_Insert_Rod( r->a );

		r->a->radius_b = old_radius_b;
		r->a->v_points = old_v_points;

	    } else if (r->got_segments) {
		*r->facet_0++ = r->point_index -2;
		*r->facet_1++ = r->point_index -1;
	    }
        }
	r->lastX = X;
	r->lastY = Y;
	r->lastZ = Z;
    }
}

/* }}} */
/* {{{ xshpEb_Resize_GrlPair						*/

void
xshpEb_Resize_GrlPair(
    struct xshpER_rec* r
) {
    int oldPointSz;
    int oldFacetSz;
    if (r->got_triangles) {
	r->pointsNeeded = 0;
	r->facetsNeeded = 0;
    }
    oldPointSz = xthlEf_Resize_Grl( r->lv_point_grl, r->pointsNeeded );
    r->point_index = oldPointSz;

    r->old_point_size = oldPointSz;

    if (r->got_segments) {
        oldFacetSz = xthlEf_Resize_Grl( r->lv_facet_grl, r->facetsNeeded );
        r->facet_index    = oldFacetSz;
        r->old_facet_size = oldFacetSz;
    } else {
        r->facet_index    = 0;
        r->old_facet_size = 0;
    }

    /* Grab hard pointers to the relevant facet and point arrays, for speed: */

    r->point_x     = ((float*) csry_base( r->lv_point_x )) + oldPointSz;
    r->point_y     = ((float*) csry_base( r->lv_point_y )) + oldPointSz;
    r->point_z     = ((float*) csry_base( r->lv_point_z )) + oldPointSz;

    /* Extra copies of above: */
    r->point_xx	   = r->point_x;
    r->point_yy    = r->point_y;
    r->point_zz	   = r->point_z;

    if (r->got_segments) {
        r->facet_0 = ((int  *) csry_base( r->lv_facet_0 )) + oldFacetSz;
        r->facet_1 = ((int  *) csry_base( r->lv_facet_1 )) + oldFacetSz;
    } else {
        r->facet_0 = NULL;
        r->facet_1 = NULL;
    }
    if (r->got_triangles) {
        r->facet_2 = ((int  *) csry_base( r->lv_facet_2 )) + oldFacetSz;
    } else {
        r->facet_2 = NULL;
    }
    if (r->got_rectangles) {
        r->facet_3 = ((int  *) csry_base( r->lv_facet_3 )) + oldFacetSz;
    } else {
        r->facet_3 = NULL;
    }
}

/* }}} */
/* {{{ xshpEc_JustifyText						*/

void
xshpEc_JustifyText(
    struct xshpER_rec * r,
    LVAL	        lv_justify
) {
    float offsetX;
    float offsetY;
    float offsetZ;
    float*px = r->point_xx;
    float*py = r->point_yy;
    float*pz = r->point_zz;
    int   i  = r->point_x - px;
    if (  i != r->point_y - py)   abort();
    if (  i != r->point_z - pz)   abort();

    if (lv_justify == k_left) {
	return;
    } else if (lv_justify == k_center) {
	offsetX	= (r->cursorX - r->cursorXX) * 0.5;
	offsetY	= (r->cursorY - r->cursorYY) * 0.5;
	offsetZ	= (r->cursorZ - r->cursorZZ) * 0.5;
    } else if (lv_justify == k_right ) {
	offsetX	= (r->cursorX - r->cursorXX);
	offsetY	= (r->cursorY - r->cursorYY);
	offsetZ	= (r->cursorZ - r->cursorZZ);
    } else {
	abort();
    }

    while (i --> 0) {
	*px++ -= offsetX;
	*py++ -= offsetY;
	*pz++ -= offsetZ;
    }
}

/* }}} */

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

