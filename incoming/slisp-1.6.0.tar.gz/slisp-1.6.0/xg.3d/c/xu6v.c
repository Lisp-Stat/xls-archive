/* {{{ xu6v.h -- 16-bit unsigned vectors.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94May26
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */
/* {{{ --- history ---							*/

/* 94May26 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  

#include "../../xcore/c/xlisp.h"

#include "csry.h"

extern LVAL lv_xu6v;

#include "geo.h"
#include "cu6v.h"
#include "clsp.h"

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xu6v0a_Set_Default -- Set up Default_Initializer in csry_rec.	*/

xu6v0a_Set_Default( h )
csry_rec*           h;
{
    h->default_initializer.i = 0;
}

/* }}} */
/* {{{ xu6v00_List_To_Struct -- Convert x number to C unsigned char.	*/

xu6v00_List_To_Struct( p, p_as_lval, h )
CSRY_UNSIGNED16 *       p;
LVAL			  p_as_lval;
csry_rec*                            h;
/*-
    Convert x number to C unsigned char.
-*/
{
    /* If initializer is null, use default values.  */
    /* (This is also used to supply default values  */
    /* for new slots in redimensioned arrays.)	    */
    if (p_as_lval == NIL) {
        *p = h->default_initializer.u6;
        return;
    }

    *p = (CSRY_UNSIGNED16) xgbj00_Get_Fix_Or_Flo_Num( p_as_lval );
}

/* }}} */
/* {{{ xu6v01_Struct_To_List -- Convert C unsigned char to x fixnum.	*/

LVAL xu6v01_Struct_To_List( p )
CSRY_UNSIGNED16*		    p;
/*-
    Convert C unsigned char to x fixnum.
-*/
{
    return cvfixnum( *p );
}

/* }}} */
/* {{{ xu6v02_Sprintf -- Sprintf unsigned16 into buffer.		*/

xu6v02_Sprintf( buf, p )
char*		buf;
CSRY_UNSIGNED16*	     p;
/*-
    Sprintf point into buffer.
-*/
{
    return sprintf(buf, "%d", *p );
}

/* }}} */
/* {{{ xu6v -- Describe unsigned16 to csry.c.				*/


FORWARD int xu6v54_BCopy();
FORWARD int xu6v55_From_Buf();
FORWARD int xu6v56_To_Buf();
FORWARD int xu6v58_Position();
FORWARD int xu6v62_Delete();
LVAL xsry22_AdjustArray();
LOCAL struct csry_struct xu6v = {
    /* int  k_class             = */ C03D_xU6V,
    /* int  sizeof_struct       = */ sizeof( CSRY_UNSIGNED16 ),
    /* int  (*list_to_struct)() = */ xu6v00_List_To_Struct,
    /* LVAL (*struct_to_list)() = */ xu6v01_Struct_To_List,
    /* int  (*sprintf_struct)() = */ xu6v02_Sprintf,
    /* int  (*copy_struct)   () = */ xu6v54_BCopy,
    /* int  (*initfn)        ();= */ xu6v0a_Set_Default,
    /* LVAL k_ary               = */ NULL,
    /* int  (*from_buf)      ();= */ xu6v55_From_Buf,
    /* int  (*  to_buf)      ();= */ xu6v56_To_Buf,
    /* LVAL (*adjust_array)  ();= */ xsry22_AdjustArray,
    /* int  (*position)      ();= */ xu6v58_Position,
    /* int  (*delete)        ();= */ xu6v62_Delete
};
/*-
    Describe our type to csry.c.
-*/


/* }}} */
/* {{{ xu6v03_Is_New -- Initialize a new unsigned16 array.		*/

LVAL xu6v03_Is_New()
{   xu6v.k_ary = lv_xu6v;  /* Not really the best place to do this... */

    /* This isn't too bad, a good compiler will erase the test: */
    if (sizeof(CSRY_UNSIGNED16) != 2) {
	xlfatal("Please redefine csry.h:CSRY_UNSIGNED16");
    }

    return   xsry00_Is_New( &xu6v );
}

/* }}} */
/* {{{ xu6v04_Get_A_XU6V -- Get arg, must be a unsigned16 vector/array.	*/

LVAL xu6v04_Get_A_XU6V()
/*-
    Get arg, must be a unsigned16-array.
-*/
{
    LVAL m_as_lval = xlgagobject();
    if (!xu6vp( m_as_lval ))   xlbadtype(m_as_lval);
    return m_as_lval;
}

/* }}} */
/* {{{ xu6v32_Copy_Bit_To_Un6                                           */

xu6v32_Copy_Bit_To_Un6( dst, src, cnt, ifv )
CSRY_UNSIGNED16         *dst;
unsigned char               *src;
int                               cnt;
unsigned char                         *ifv;
{
    int            i;
    int            inbits;
    int            ifbits;
    int            val;

    if (ifv == NULL) {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     inbits  = *src++;
	    val = (inbits & 1);
            *dst++ = val;
	    inbits >>= 1;
	}
    } else {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     { inbits  = *src++;   ifbits = *ifv++; }
	    val = (inbits & 1);
            if    (ifbits & 1)   *dst = val;
            ++dst;
	    inbits >>= 1;
	    ifbits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xu6v35_Copy_Fix_To_Un6                                           */

xu6v35_Copy_Fix_To_Un6( dst, src, cnt, ifv )
CSRY_UNSIGNED16         *dst;
CSRY_INT32                  *src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
            *dst++ = (CSRY_UNSIGNED16) *src++;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = (CSRY_UNSIGNED16) *src;
	    ++dst;
            ++src;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xu6v34_Copy_Un6_To_Fix                                           */

xu6v34_Copy_Un6_To_Fix( dst, src, cnt, ifv )
CSRY_INT32             *dst;
CSRY_UNSIGNED16              *src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
            *dst++ = (CSRY_INT32) *src++;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = (CSRY_INT32) *src;
	    ++dst;
            ++src;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xu6v38_Copy_Flo_To_Un6                                           */

xu6v38_Copy_Flo_To_Un6( dst, src, cnt, ifv )
CSRY_UNSIGNED16         *dst;
float                       *src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
            *dst++ = (CSRY_UNSIGNED16) *src++;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = (CSRY_UNSIGNED16) *src;
	    ++src;
            ++dst;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xu6v41_Max_Msg -- Find maximum entry in array.               	*/

int xu6v40_Max( m_as_lval )
LVAL            m_as_lval;
/*-
    Find maximum entry in a vector.
-*/
{   int i, max;
    csry_rec* mh = xsry9c_Find_Immediate_Base( m_as_lval );
    {   CSRY_UNSIGNED16*  mt = (CSRY_UNSIGNED16*) csry_base( m_as_lval );
	i        = mh->size;
        if (mh->rank == 1 && mh->dim[1] >= 0) i = mh->dim[1];/*Respect fillptr*/
        if (!i)   xlfail( "max:  array is empty" );
	max      = *mt;
	while (--i >= 0) {
            if (*mt++ > max)   max = *(mt -1);
    }	}
    return max;
}

LVAL xu6v41_Max_Msg()
/*-
    Find maximum entry in an array.  Message protocol.
-*/
{   LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    xllastarg();
    return cvfixnum( xu6v40_Max( m_as_lval ) );
}

/* }}} */
/* {{{ xu6v43_Min_Msg -- Find minimum entry in array.               	*/

int xu6v42_Min( m_as_lval )
LVAL            m_as_lval;
/*-
    Find minimum entry in a vector.
-*/
{
    int i, min;
    csry_rec* mh = xsry9c_Find_Immediate_Base( m_as_lval );
    {
	CSRY_UNSIGNED16*  mt = (CSRY_UNSIGNED16*) csry_base( m_as_lval );
	i        = mh->size;
        if (mh->rank == 1 && mh->dim[1] >= 0) i = mh->dim[1];/*Respect fillptr*/
        if (!i)   xlfail( "min:  array is empty" );
	min      = *mt;
	while (--i >= 0) {
            if (*mt++ < min)   min = *(mt -1);
	}
    }
    return min;
}

LVAL xu6v43_Min_Msg()
/*-
    Find minimum entry in an array.  Message protocol.
-*/
{
    LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    xllastarg();
    return cvfixnum( xu6v42_Min( m_as_lval ) );
}

/* }}} */
/* {{{ xu6v54_BCopy -- Copy an instance.				*/

xu6v54_BCopy(  dst, src )
CSRY_UNSIGNED16*dst;
CSRY_UNSIGNED16*     src;
/*-
    Copy an instance.
-*/
{
    *dst = *src;
}

/* }}} */
/* {{{ xu6v55_From_Buf -- Copy from buffer into array.			*/

int xu6v55_From_Buf( v_as_lval, buf, cnt, pos, ifv )
LVAL                 v_as_lval;
struct xlsp05_buf *             buf;
int                                  cnt, pos;
unsigned char *                                ifv;
/*-
    Copy from buffer into array.
-*/
{
    CSRY_UNSIGNED16 * vt;
    if (!xu6vp( v_as_lval ))   xlbadtype( v_as_lval );
    vt  = (CSRY_UNSIGNED16*)    csry_base( v_as_lval );
    vt += pos;

    switch (buf->buf_type) {

    case XLSP_TYPE_BIT:
	xu6v32_Copy_Bit_To_Un6( vt, buf->u.bit, cnt, ifv );
        break;

    case XLSP_TYPE_FIX:
	xu6v35_Copy_Fix_To_Un6( vt, buf->u.fix, cnt, ifv );
        break;

    case XLSP_TYPE_FLO:
	xu6v38_Copy_Flo_To_Un6( vt, buf->u.flo, cnt, ifv );
        break;

    default:
        abort();
    }

    return 0;
}

/* }}} */
/* {{{ xu6v56_To_Buf -- Copy from array into buffer.			*/

int xu6v56_To_Buf( v_as_lval, buf, cnt, pos, ifv )
LVAL               v_as_lval;
struct xlsp05_buf *           buf;
int                                cnt, pos;
unsigned char *                              ifv;
/*-
    Copy from array into buffer.
-*/
{
    CSRY_UNSIGNED16* vt;
    if (!xu6vp( v_as_lval ))          xlbadtype( v_as_lval );
    vt            = (CSRY_UNSIGNED16*) csry_base( v_as_lval );

    xu6v34_Copy_Un6_To_Fix( buf->u.fix, vt+pos, cnt, ifv );
    buf->buf_type = XLSP_TYPE_FIX;

    return 0;
}

/* }}} */
/* {{{ xu6v58_Position -- Find value within buffer.			*/

int xu6v58_Position( lv_ary, lv_arg )
LVAL                 lv_ary, lv_arg;
{
    int val;
    csry_rec* mh = xsry9c_Find_Immediate_Base( lv_ary );
    if       (  fixp(lv_arg)) val =       getfixnum( lv_arg );
    else if  (floatp(lv_arg)) val = (int) getflonum( lv_arg );
    else xlerror("xu6v :position needed integer", lv_arg );
    {   CSRY_UNSIGNED16*  mt = (CSRY_UNSIGNED16*) csry_base( lv_ary );
	int  len        = mh->size;
	int  i;
        /* Respect fillpointer: */
        if (mh->rank == 1 && mh->dim[1] >= 0) len = mh->dim[1];
        if (!len)   return -1;
	for (i = 0; i < len; ++i) if (*mt++ == val) return i;
    }
    return -1;
}

/* }}} */
/* {{{ xu6v62_Delete -- Find value within buffer.			*/

int xu6v62_Delete( lv_ary, start, end )
LVAL               lv_ary;
int			   start, end;
{
    int val;
    csry_rec* mh = xsry9c_Find_Immediate_Base( lv_ary );
    CSRY_UNSIGNED16*mt = (CSRY_UNSIGNED16*) csry_base( lv_ary );
    int  len = mh->size;
    int  gap = end-start;
    int  i;
    /* Respect fillpointer. We know mh->rank==1 */
    if (mh->dim[1] >= 0) len = mh->dim[1];
    if (!len)   return -1;
    for (i = start; i < len-gap; ++i)  mt[i] = mt[i+gap];
    /* Set fillpointer to reflect new length: */
    mh->dim[1] = len-gap;
    return 0;
}

/* }}} */
/* {{{ xu6v80_Get_Unsigned6_Base -- Fetch base of Unsigned16vec		*/

CSRY_UNSIGNED16* xu6v80_Get_Unsigned16_Base( self )
LVAL				             self;
{
    if (!gobjectp(self) || !xu6vp(self))   xlbadtype(self);
    return   (CSRY_UNSIGNED16*) csry_base(self);
}

/* }}} */
/* {{{ xu6vwo_Write_Xu6v_To_Graphics_File                               */

xu6vwo_Write_Xu6v_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   xsrywo_Write_Xsry_To_Graphics_File( fdoa, fdob, lv,f,n, "UNSIGNED16" );
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
