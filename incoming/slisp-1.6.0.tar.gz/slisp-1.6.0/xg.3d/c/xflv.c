/* {{{ xflv.c -- 32-bit float vectors.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      90Jan21
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Apr08 jsp: from/to_buf.						*/
/* 91Jul11 jdp: Max, min.						*/
/* 91Jan21 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"

#include "csry.h"

extern LVAL lv_xflv;

#include "geo.h"
#include "cflv.h"
#include "clsp.h"
#include "../../xg.3d.fileio/c/cfil.h"

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xflv0a_Set_Default -- Set up Default_Initializer in csry_rec.	*/

xflv0a_Set_Default( h )
csry_rec*           h;
{
    h->default_initializer.f = 0.0;
}

/* }}} */
/* {{{ xflv00_List_To_Struct -- Convert Lisp number to C float.		*/

xflv00_List_To_Struct( p, p_as_lval, h )
float*		       p;
LVAL			  p_as_lval;
csry_rec*                            h;
/*-
    Convert x flonum to C float.
-*/
{
    /* If initializer is null, use default values.  */
    /* (This is also used to supply default values  */
    /* for new slots in redimensioned arrays.)	    */
    if (p_as_lval == NIL) {
        *p = h->default_initializer.f;
        return;
    }

    *p = xgbj00_Get_Fix_Or_Flo_Num( p_as_lval );
}

/* }}} */
/* {{{ xflv01_Struct_To_List -- Convert C float to x flonum.		*/

LVAL xflv01_Struct_To_List( p )
float*			    p;
/*-
    Convert C float to x flonum.
-*/
{
    return cvflonum( *p );
}

/* }}} */
/* {{{ xflv02_Sprintf -- Sprintf float into buffer.			*/

xflv02_Sprintf( buf, p )
char*		buf;
float*		     p;
/*-
    Sprintf point into buffer.
-*/
{
    return sprintf(buf, "%g", *p );
}

/* }}} */
/* {{{ xflv -- Describe float to csry.c.				*/

FORWARD int xflv54_BCopy();
FORWARD int xflv55_From_Buf();
FORWARD int xflv56_To_Buf();
FORWARD int xflv58_Position();
FORWARD int xflv62_Delete();
LVAL xsry22_AdjustArray();
LOCAL struct csry_struct xflv = {
    /* int  k_class             = */ C03D_xFLV,
    /* int  sizeof_struct       = */ sizeof( float ),
    /* int  (*list_to_struct)() = */ xflv00_List_To_Struct,
    /* LVAL (*struct_to_list)() = */ xflv01_Struct_To_List,
    /* int  (*sprintf_struct)() = */ xflv02_Sprintf,
    /* int  (*copy_struct)   () = */ xflv54_BCopy,
    /* int  (*initfn)        ();= */ xflv0a_Set_Default,
    /* LVAL k_ary               = */ NULL,
    /* int  (*from_buf)      ();= */ xflv55_From_Buf,
    /* int  (*  to_buf)      ();= */ xflv56_To_Buf,
    /* LVAL (*adjust_array)  ();= */ xsry22_AdjustArray,
    /* LVAL (*position)      ();= */ xflv58_Position,
    /* LVAL (*delete)        ();= */ xflv62_Delete
};
/*-
    Describe our type to csry.c.
-*/

/* }}} */
/* {{{ xflv03_Is_New -- Initialize a new float array.			*/

LVAL xflv03_Is_New()
{   xflv.k_ary = lv_xflv;       /* Not really the best place to do this! */
    return xsry00_Is_New( &xflv );
}

/* }}} */
/* {{{ xflv04_Get_A_XFLV -- Get arg, must be a float vector/array.	*/

LVAL xflv04_Get_A_XFLV()
/*-
    Get arg, must be a float-array.
-*/
{
    LVAL m_as_lval = xlgagobject();
    if (!xflvp( m_as_lval ))   xlbadtype(m_as_lval);
    return m_as_lval;
}

/* }}} */
/* {{{ xflv41_Max_Msg -- Find maximum entry in array.               	*/

float xflv40_Max( m_as_lval )
LVAL              m_as_lval;
/*-
    Find maximum entry in a vector.
-*/
{
    int   i;
    float max;
    csry_rec* mh = xsry9c_Find_Immediate_Base( m_as_lval );
    {
	float*mt = (float*) csry_base( m_as_lval );
	i        = mh->size;
        if (mh->rank == 1 && mh->dim[1] >= 0) i = mh->dim[1];/*Respect fillptr*/
        if (!i)   xlfail( "max:  array is empty" );
	max      = *mt;
	while (--i >= 0) {
            if (*mt++ > max)   max = *(mt -1);
	}
    }
    return max;
}

LVAL xflv41_Max_Msg()
/*-
    Find maximum entry in an array.  Message protocol.
-*/
{
    LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    xllastarg();
    return cvflonum( xflv40_Max( m_as_lval ) );
}

/* }}} */
/* {{{ xflv43_Min_Msg -- Find minimum entry in array.               	*/

float xflv42_Min( m_as_lval )
LVAL              m_as_lval;
/*-
    Find minimum entry in a vector.
-*/
{
    int   i;
    float min;
    csry_rec* mh = xsry9c_Find_Immediate_Base( m_as_lval );
    {
	float*mt = (float*) csry_base( m_as_lval );

	i        = mh->size;
        if (mh->rank == 1 && mh->dim[1] >= 0) i = mh->dim[1];/*Respect fillptr*/
        if (!i)   xlfail( "min:  array is empty" );
	min      = *mt;
	while (--i >= 0) {
            if (*mt++ < min)   min = mt[-1];
	}
    }
    return min;
}

LVAL xflv43_Min_Msg()
/*-
    Find minimum entry in an array.  Message protocol.
-*/
{
    LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    xllastarg();
    return cvflonum( xflv42_Min( m_as_lval ) );
}

/* }}} */
/* {{{ xflv54_BCopy -- Copy an instance.				*/

xflv54_BCopy( dst,src )
float*        dst;
float*            src;
/*-
    Copy an instance.
-*/
{
    *dst = *src;
}

/* }}} */
/* {{{ xflv55_From_Buf -- Copy from buffer into array.			*/

int xflv55_From_Buf( v_as_lval, buf, cnt, pos, ifv )
LVAL                 v_as_lval;
struct xlsp05_buf *             buf;
int                                  cnt, pos;
unsigned char *                                ifv;
{
    float   * vt;
    if (!xflvp( v_as_lval ))   xlbadtype(   v_as_lval );
    vt  = (float*) csry_base( v_as_lval );
    vt += pos;

    switch (buf->buf_type) {

    case XLSP_TYPE_BIT:
	xlsp33_Copy_Bit_To_Flo( vt, buf->u.bit, cnt, ifv );
        break;

    case XLSP_TYPE_FIX:
	xlsp36_Copy_Fix_To_Flo( vt, buf->u.fix, cnt, ifv );
        break;

    case XLSP_TYPE_FLO:
	xlsp39_Copy_Flo_To_Flo( vt, buf->u.flo, cnt, ifv );
        break;

    default:
        abort();
    }

    return 0;
}

/* }}} */
/* {{{ xflv56_To_Buf -- Copy from array into buffer.			*/

int xflv56_To_Buf( v_as_lval, buf, cnt, pos, ifv )
LVAL               v_as_lval;
struct xlsp05_buf *           buf;
int                                cnt, pos;
unsigned char *                              ifv;
{
    float   * vt;
    if (!xflvp( v_as_lval ))   xlbadtype( v_as_lval );
    vt            =   (float*) csry_base( v_as_lval );

    xlsp39_Copy_Flo_To_Flo( buf->u.flo, vt+pos, cnt, ifv );
    buf->buf_type = XLSP_TYPE_FLO;

    return 0;
}

/* }}} */
/* {{{ xflv58_Position -- Find value within buffer.			*/

int xflv58_Position( lv_ary, lv_arg )
LVAL                 lv_ary, lv_arg;
{
    float val;
    csry_rec* mh = xsry9c_Find_Immediate_Base( lv_ary );
    if       (  fixp(lv_arg)) val = (float) getfixnum( lv_arg );
    else if  (floatp(lv_arg)) val =         getflonum( lv_arg );
    else xlerror("xflv :position needed float", lv_arg );
    {   float*mt = (float*) csry_base( lv_ary );
	int  len            = mh->size;
	int  i;
        /* Respect fillpointer: */
        if (mh->rank == 1 && mh->dim[1] >= 0) len = mh->dim[1];
        if (!len)   return -1;
	for (i = 0; i < len; ++i) if (*mt++ == val) return i;
    }
    return -1;
}

/* }}} */
/* {{{ xflv62_Delete -- Find value within buffer.			*/

int xflv62_Delete( lv_ary, start, end )
LVAL               lv_ary;
int			   start, end;
{
    int val;
    csry_rec* mh = xsry9c_Find_Immediate_Base( lv_ary );
    float* mt  = (float*) csry_base( lv_ary );
    int  len = mh->size;
    int  gap = end-start;
    int  i;
    /* Respect fillpointer. We know mh->rank==1 */
    if (mh->dim[1] >= 0) len = mh->dim[1];
    if (!len)   return -1;
    for (i = start; i < len-gap; ++i)  mt[i] = mt[i+gap];
    /* Set fillpointer to reflect new length: */
    mh->dim[1] = len-gap;
    return 0;
}

/* }}} */
/* {{{ xflv80_Get_Float_Base -- Fetch base of floatvec			*/

float* xflv80_Get_Float_Base( self )
LVAL			      self;
{
    if (!gobjectp(self) || !xflvp(self))   xlbadtype(self);
    return   (float*) csry_base(self);
}

/* }}} */
/* {{{ xflvwo_Write_Xflv_To_Graphics_File                               */

xflvwo_Write_Xflv_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   xsrywo_Write_Xsry_To_Graphics_File( fdoa, fdob, lv,f,n, "FLOAT" );
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

