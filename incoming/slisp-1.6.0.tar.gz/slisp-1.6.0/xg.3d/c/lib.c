/* {{{ lib.c -- miscellaneous library fns.			     CrT*/

/************************************************************************/
/* Copyright (c) 1991-92 Jeffrey S. Prothero, University of Washington	*/
/* Department of Biological Structure.  All rights reserved.            */ 
/*									*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU Library General Public License as      */
/* published by the Free Software Foundation; either version 2, or      */
/* (at your option) any later version.					*/
/*									*/
/* This program is distributed in the hope that it will be useful,	*/
/* but WITHOUT ANY WARRANTY; without even the implied warranty of	*/
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the	*/
/* GNU Library General Public License for more details.			*/
/*									*/
/* You should have received a copy of the GNU Library General Public	*/
/* License along with this program; if not, write to the Free Software	*/
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.		*/
/*									*/
/* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES	*/
/* WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF	*/
/* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF		*/
/* WASHINGTON NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR	*/
/* CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS	*/
/* OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,		*/
/* NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN		*/
/* CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.		*/
/*									*/
/* Please send modifications and fixes to jsp@glia.biostr.washington.edu*/
/* Post XLISP-specific questions/infor to the newsgroup comp.lang.lisp.x*/
/************************************************************************/ 
  
/* }}} */
/* {{{ --- history ---							*/

/* 96Aug05 jsp	libSunXYZSet: don't crash when normal length wrong.	*/
/* 92Feb25 jsp	Find_Intersection_Of_Line_With_Polygon.			*/
/* 92Feb10 jsp	4_Floats_To_List, 4_Float_List_To_Floats.		*/
/* 91Nov24 jsp	lib40_Vector_Pointwise_Product.				*/
/* 91Aug01 j*p	lib20_Study_Transformed_Points.				*/
/* 91Jul13 jdp	Created, from v.3 lib.  Took vector fns.		*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "geo.h"
#include <math.h>
#include "../../xcore/c/xlisp.h"
#include "csry.h"

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ lib00_Vector_Cross_Product.					*/

lib00_Vector_Cross_Product( p, a, b ) 
geo_point *                 p;
geo_point *                    a;  
geo_point *                       b;  
{  
    /* Compute cross product of two vectors: */  
    p->x     = a->y * b->z   -   b->y * a->z;  
    p->y     = b->x * a->z   -   a->x * b->z;  
    p->z     = a->x * b->y   -   b->x * a->y;  
}  

/* }}} */
/* {{{ lib01_Vector_Distance.						*/

float lib01_Vector_Distance( a, b )
geo_point *		     a;
geo_point *                     b; 
{ 
    float lib05_Vector_Magnitude(); 
    geo_point   d; 

    lib11_Vector_Subtract( &d, a, b ); 
    return   lib05_Vector_Magnitude( &d ); 
}

/* }}} */
/* {{{ lib02_Vector_Distance2.						*/

float lib02_Vector_Distance2( a, b )
geo_point *		      a;
geo_point *                      b; 
{ 
    register geo_point *   aa; 
    register geo_point *   bb; 
    register float   x; 
    register float   y; 
    register float   z; 
  
    aa  = a; 
    bb  = b; 
  
    x   = aa->x - bb->x; 
    y   = aa->y - bb->y; 
    z   = aa->z - bb->z; 
  
    return   x * x   +   y * y   +   z * z; 
} 

/* }}} */
/* {{{ lib03_Vector_Dot_Product						*/

float lib03_Vector_Dot_Product( a, b )
geo_point *	                a;
geo_point *		           b;
{ 
    /* Compute dot product of two vectors: */ 
    return   a->x * b->x	 +   a->y * b->y	 +   a->z * b->z;
} 

/* }}} */
/* {{{ lib04_Vector_Interpolate						*/

lib04_Vector_Interpolate( p, p1,p2,p3,p4, s1,s2,s3,s4 )
geo_point *               p;
geo_point *                  p1;
geo_point *                     p2;
geo_point *                        p3;
geo_point *                           p4;
float                                     s1,s2,s3,s4;
{
    /* Computed weighted sum of up to four vectors. */
    /* Will normally have 1.0 = s1 + s2 + s3 + s4.  */

    float x = 0.0;
    float y = 0.0;
    float z = 0.0;

    /* The "if"s mean we don't have to supply dummy points */
    /* if we're doing a 2- or 3-way interpolation.         */
    if (s1 != 0.0) {x += s1*p1->x;   y += s1*p1->y;   z += s1*p1->z; }
    if (s2 != 0.0) {x += s2*p2->x;   y += s2*p2->y;   z += s2*p2->z; }
    if (s3 != 0.0) {x += s3*p3->x;   y += s3*p3->y;   z += s3*p3->z; }
    if (s4 != 0.0) {x += s4*p4->x;   y += s4*p4->y;   z += s4*p4->z; }

    p->x = x;
    p->y = y;
    p->z = z;
}

/* }}} */
/* {{{ lib05_Vector_Magnitude						*/

float lib05_Vector_Magnitude( v )
geo_point *		      v;
{ 
#ifdef NAIVE
    /********************************************/
    /* NUMERICAL RECIPES IN C (p68) thinks this */
    /* is vulnerable to underflow and overflow: */
    /********************************************/
    register float x, y, z;

    x	= v->x;
    y   = v->y;  
    z   = v->z;  

    return  sqrt(  x*x + y*y + z*z  );
#else
#undef fabs
#define fabs(a) ((a)<0.0 ? -(a) : (a))
    float abX	= fabs( v->x );
    float abY	= fabs( v->y );
    float abZ	= fabs( v->z );
    float inv;

    if (abX > abY   &&	 abX > abZ) {

        inv     = 1.0 / abX;
	abY    *= inv;
	abZ    *= inv;
	return abX * sqrt( 1.0	       +   abY * abY   +   abZ * abZ );

    } else if (abY > abZ) {

        inv     = 1.0 / abY;
        abX    *= inv; 
        abZ    *= inv; 
	return abY * sqrt( abX * abX   +	 1.0   +   abZ * abZ );

    } else if (abZ) {

        inv     = 1.0 / abZ;
	abX    *= inv;
	abY    *= inv;
	return abZ * sqrt( abX * abX   +   abY * abY   +	 1.0 );

    } else {

        return 0.0;  
    }  
#undef fabs
#endif
}

/* }}} */
/* {{{ lib06_Vector_Magnitude2						*/

float lib06_Vector_Magnitude2( v )
geo_point *		       v;
{ 
    register float x, y, z; 
  
    x	= v->x;
    y   = v->y; 
    z   = v->z; 
  
    return   x*x + y*y + z*z; 
} 

/* }}} */
/* {{{ lib07_Vector_Negate						*/

lib07_Vector_Negate( v ) 
geo_point *          v; 
{ 
    v->x     = -v->x; 
    v->y     = -v->y; 
    v->z     = -v->z; 
} 

/* }}} */
/* {{{ lib08_Vector_Normalize						*/

lib08_Vector_Normalize( v )  
geo_point *             v; 
{  
    register float len; 
    register float inv; 
    float lib05_Vector_Magnitude(); 

    /* Normalize vector to unit length: */  
    len = lib05_Vector_Magnitude( v ); 
    if (len > 0.1e-50) { 
  
        inv = 1.0 / len; 
   
        v->x     *= inv; 
        v->y     *= inv; 
        v->z     *= inv; 
    } 
}

/* }}} */
/* {{{ lib09_Vector_Print						*/

lib09_Vector_Print( title, d ) 
char *		    title;
geo_point  *               d; 
{ 
    printf( "\n%s: %6.4f %6.4f %6.4f", title, d->x, d->y, d->z ); 
} 

/* }}} */
/* {{{ lib10_Vector_Scale						*/

lib10_Vector_Scale( v, s )
geo_point *	    v;
float		       s;
{  
    v->x	*= s;
    v->y	*= s;
    v->z	*= s;
}

/* }}} */
/* {{{ lib10_Vector_Subtract						*/

lib11_Vector_Subtract( d, a, b ) 
geo_point *	       d;
geo_point *               a; 
geo_point *                  b; 
{ 
    /* Compute difference of two vectors: */ 
    d->x     = a->x - b->x; 
    d->y     = a->y - b->y; 
    d->z     = a->z - b->z; 
} 

/* }}} */
/* {{{ lib12_Vector_Sum							*/

lib12_Vector_Sum( d, a, b ) 
geo_point *       d;
geo_point *          a; 
geo_point *             b; 
{ 
    /* Compute sum of two vectors: */ 
    d->x     = a->x + b->x; 
    d->y     = a->y + b->y; 
    d->z     = a->z + b->z; 
} 

/* }}} */
/* {{{ lib13_Vector_Zero						*/

lib13_Vector_Zero( d ) 
geo_point *        d;
{ 
    /* Zero a vector: */ 
    d->x     = 0.0;
    d->y     = 0.0;
    d->z     = 0.0;
} 

/* }}} */
/* {{{ lib14_Point_To_List						*/

LVAL lib14_Point_To_List( p )
geo_point*		  p;
/* Convert geo_point to (x y z) list. */
/* This is essentially identical to xgtm15_Point_To_List() */
{
    LVAL result;
    xlsave1(result);
    result = cons( cvflonum(p->z), NIL    );
    result = cons( cvflonum(p->y), result );
    result = cons( cvflonum(p->x), result );
    xlpop();
    return result;
}

/* }}} */
/* {{{ lib16_List_To_Point						*/

lib16_List_To_Point( point, pt_list )
geo_point*	     point;
LVAL		            pt_list;
/* Convert (x y z) list to geo_point. */
/* This is essentially identical to xgtm14_List_To_XYZ() */
{
    LVAL      here   = pt_list;

    if (!consp(here))     xlbadtype(pt_list);
    point->x = xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!consp(here))     xlbadtype(pt_list);
    point->y = xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!consp(here))     xlbadtype(pt_list);
    point->z = xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!null(here))      xlbadtype(pt_list);
}

/* }}} */
/* {{{ lib17_List_To_Color						*/

lib17_List_To_Color( point, pt_list )
geo_point*	     point;
LVAL		            pt_list;
/*-
    Convert (x y z) list to geo_point.
-*/
{
    geo_point  color;
    lib16_List_To_Point( &color, pt_list );
    if (color.x < 0.0 || color.x > 1.0 ||
	color.y < 0.0 || color.y > 1.0 ||
	color.z < 0.0 || color.z > 1.0
    ) {
	xlbadinit( pt_list );
    }
    *point = color;
}

/* }}} */
/* {{{ lib18_Clip_Float_To_Unit_Interval				*/

lib18_Clip_Float_To_Unit_Interval( pf )
float				  *pf;
{   float f = *pf;
    if (f < 0.0)   f = 0.0;
    if (f > 1.0)   f = 1.0;
    *pf = f;
}

/* }}} */
/* {{{ lib20_Study_Transformed_Points					*/

lib20_Study_Transformed_Points( xvec, yvec, zvec, len, mat, fn, fa, buf, buf_len )
float       		       *xvec,*yvec,*zvec;
int				         	  len;
geo_matrix				              *mat;
int						          (*fn)();
int  						               *fa;		
geo_point						           *buf;
int								         buf_len;
/*-
    Transform input point vector in bufferfuls and feed them to fn( fa, ... ). 
-*/
{
    /* Apply the matrix to the (x,y,z) points: */
    int         i       = len;
    geo_point * p       = buf;
    geo_point * buf_lim = &buf[ buf_len ];
    while (i --> 0) {
	
	/* Apply "mat" to "in" resulting in "out". */
	float x     = *xvec++;
	float y     = *yvec++;
	float z     = *zvec++;

	float x_out = x*mat->m[0][0] + y*mat->m[1][0] + z*mat->m[2][0] + mat->m[3][0];
	float y_out = x*mat->m[0][1] + y*mat->m[1][1] + z*mat->m[2][1] + mat->m[3][1];
	float z_out = x*mat->m[0][2] + y*mat->m[1][2] + z*mat->m[2][2] + mat->m[3][2];
	float w_out = x*mat->m[0][3] + y*mat->m[1][3] + z*mat->m[2][3] + mat->m[3][3];

        if (w_out == 0.0)   xlfail( "bad matrix" );

        p->x = x_out / w_out;
        p->y = y_out / w_out;
        p->z = z_out / w_out;

	++p;

	if (!i   ||   p == buf_lim) {
	    if (!fn( fa, buf, p-buf ))   return FALSE;
	    p = buf;
	}
    }    

    return TRUE;
}

/* }}} */
/* {{{ lib23_Matrix_Pure_Rotation -- Convert matrix to pure rotation.	*/

lib23_Matrix_Pure_Rotation( mat ) 
geo_matrix                 *mat;
{ 
    int  i;

    /* Um, I haven't thought hard about this, but seems to me    */
    /* that if we set m[3][*] and m[*][3] to the identity values */
    /* and then normalize each column to unit length, that the   */
    /* matrix has to map unit vectors to unit vectors (shouldn't */
    /* be enough degrees of freedom left for it to do anything   */
    /* very odd) and that any matrix mapping unit vectors to     */
    /* unit vectors should be pure-rotation ... especially if    */
    /* drawn from our typical matrices built only on rotation,   */
    /* translation and scaling *grin*.	Sooo:			 */
    mat->m[0][3] = 0.0;
    mat->m[1][3] = 0.0;
    mat->m[2][3] = 0.0;
    mat->m[3][3] = 1.0;
    mat->m[3][2] = 0.0;
    mat->m[3][1] = 0.0;
    mat->m[3][0] = 0.0;

    for (i = 2;   i --> 0;   ) {
        double len = sqrt(
	    mat->m[0][i] * mat->m[0][i]   +
	    mat->m[1][i] * mat->m[1][i]   +
	    mat->m[2][i] * mat->m[2][i]
	);
	if (len == 0.0) {
	    mat->m[i][i]  = 1.0;	/* Just to have something valid */
	} else {
	    double w = 1.0 / len;
	    mat->m[0][i] *= w;
	    mat->m[1][i] *= w;
	    mat->m[2][i] *= w;
	}
    } 
} 

/* }}} */
/* {{{ lib24_Matrix_Print_Float						*/

lib24_Matrix_Print_Float( title, mat ) 
char  * 	          title;
float                            mat[ 4 ][ 4 ]; 
/*-
    Print a 4x4 float matrix.
-*/
{ 
    int i; 
    int j; 
  
    printf( "\n%s:", title ); 
    for (i = 0;   i < 4;   ++i)   { 
        printf("\n"); 
        for (j = 0;   j < 4;   ++j)   { 
	    printf( " %8.4f", mat[ i ][ j ] );
        } 
    } 
} 

/* }}} */
/* {{{ lib25_Matrix_Print_Double					*/

lib25_Matrix_Print_Double( title, mat ) 
char  * 	           title;
double                            mat[ 4 ][ 4 ]; 
{   /* Print a 4x4 float matrix. */
    int i; 
    int j; 
  
    printf( "\n%s:", title ); 
    for (i = 0;   i < 4;   ++i)   { 
        printf("\n"); 
        for (j = 0;   j < 4;   ++j)   { 
	    printf( " %8.4f", mat[ i ][ j ] );
        } 
    } 
} 

/* }}} */
/* {{{ lib26_Matrix_Apply_to_Point					*/

lib26_Matrix_Apply_To_Point( out, in, mat )
struct {float x,y,z;} *      out;
struct {float x,y,z;} *           in;
double				      mat[4][4];
{
    /* Apply "mat" to "in" resulting in "out". */
    float x = in->x*mat[0][0] + in->y*mat[1][0] + in->z*mat[2][0] + mat[3][0];
    float y = in->x*mat[0][1] + in->y*mat[1][1] + in->z*mat[2][1] + mat[3][1];
    float z = in->x*mat[0][2] + in->y*mat[1][2] + in->z*mat[2][2] + mat[3][2];
    float w = in->x*mat[0][3] + in->y*mat[1][3] + in->z*mat[2][3] + mat[3][3];
    if (w == 0.0)   w = 0.00000001; /* :) */
    out->x = x / w;
    out->y = y / w;
    out->z = z / w;
}

/* }}} */
/* {{{ lib27_Matrix_Apply_to_Normal					*/

lib27_Matrix_Apply_To_Normal( out, in, mat )
struct {float x,y,z;} *	      out;
struct {float x,y,z;} *     	   in;
double				       mat[4][4];
{
    /* Actually, normals should be transformed by inverse transpose */
    /* of mat, but this works for rotations and translations, which */
    /* are our usual fare... and it saves us time/complexity.       */
    geo_point   mashed_axis;
    geo_point unmashed_origin;
    geo_point   mashed_origin;
    lib13_Vector_Zero(          &unmashed_origin );
    lib26_Matrix_Apply_To_Point(&mashed_axis  , in             ,mat);
    lib26_Matrix_Apply_To_Point(&mashed_origin,&unmashed_origin,mat);
    lib11_Vector_Subtract(out,  &mashed_axis  , &mashed_origin    );
}

/* }}} */
/* {{{ lib28_Matrix_Apply_to_Points					*/

lib28_Matrix_Apply_To_Points( px, py, pz, n, mat )
float			     *px,*py,*pz;
int				          n;
double				             mat[4][4];
{
    register float x;
    register float y;
    register float z;

    register float X;
    register float Y;
    register float Z;
    register float W;

    /* Give modern RISCs a chance to load up registers: */
    float m00 = mat[0][0];
    float m01 = mat[0][1];
    float m02 = mat[0][2];
    float m03 = mat[0][3];

    float m10 = mat[1][0];
    float m11 = mat[1][1];
    float m12 = mat[1][2];
    float m13 = mat[1][3];

    float m20 = mat[2][0];
    float m21 = mat[2][1];
    float m22 = mat[2][2];
    float m23 = mat[2][3];

    float m30 = mat[3][0];
    float m31 = mat[3][1];
    float m32 = mat[3][2];
    float m33 = mat[3][3];

    register int i;
    for (i = n;   i --> 0; ) {
	x = *px;
	y = *py;
	z = *pz;
        X = x*m00 + y*m10 + z*m20 + m30;
        Y = x*m01 + y*m11 + z*m21 + m31;
        Z = x*m02 + y*m12 + z*m22 + m32;
        W = x*m03 + y*m13 + z*m23 + m33;
        if (W == 0.0)   W = 0.00000001; /* :) */
	W = 1.0 / W;
        *px++ = X * W;
        *py++ = Y * W;
        *pz++ = Z * W;
    }
}

/* }}} */
/* {{{ lib29_Normalize_Normals						*/

lib29_Normalize_Normals( px, py, pz, n )
float		        *px,*py,*pz;
int				     n;
{
    register float x;
    register float y;
    register float z;

    register float len;
    register float inv;

    register int i;
    for (i = n;   i --> 0; ) {
	x = *px;
	y = *py;
	z = *pz;

	len = sqrt(x*x + y*y + z*z); /* Yeah, Numerical Recipes is smarter. */
        if (len > 0.1e-50) { 
  
            inv = 1.0 / len; 
   
            *px = x * inv; 
            *py = y * inv; 
            *pz = z * inv; 
	}
	++px;
	++py;
	++pz;
    } 
}

/* }}} */
/* {{{ lib30_Maybe_Get_Fix_Or_Flo_Num					*/

lib30_Maybe_Get_Fix_Or_Flo_Num(pf,lv_arg)
float                         *pf;
LVAL				  lv_arg;
{   if (!null(lv_arg)) {
	*pf = xgbj00_Get_Fix_Or_Flo_Num(lv_arg);
        return TRUE;
    } else {
	*pf = 0.0;
        return FALSE;
    }
}

/* }}} */
/* {{{ lib33_2D_Int_List_To_Point					*/

lib33_2D_Int_List_To_Point(  x, y, pt_list )
int			    *x,*y;
LVAL				   pt_list;
{
    LVAL      here   = pt_list;

    if (!consp(here))     xlbadtype(pt_list);
    *x = (int) xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!consp(here))     xlbadtype(pt_list);
    *y = (int) xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!null(here))      xlbadtype(pt_list);
}

/* }}} */
/* {{{ lib34_2D_Int_List_To_Point					*/

LVAL lib34_2D_Int_Point_To_List( x, y )
int				 x, y;
/*-
    Convert x, y to (x y) list.
-*/
{
    LVAL result;
    xlsave1(result);
    result = cons( cvfixnum(y), NIL    );
    result = cons( cvfixnum(x), result );
    xlpop();
    return result;
}

/* }}} */
/* {{{ lib40_Vector_Pointwise_Product					*/

lib40_Vector_Pointwise_Product( d, a, b ) 
geo_point *                     d;
geo_point *                        a;
geo_point *                           b;
{ 
    /* Compute sum of two vectors: */ 
    d->x     = a->x * b->x; 
    d->y     = a->y * b->y; 
    d->z     = a->z * b->z; 
} 

/* }}} */
/* {{{ lib41_4_Floats_To_List						*/

LVAL lib41_4_Floats_To_List( f, g, h, i )
float			     f, g, h, i;
/*-
    Convert four floats to (f g h i) list.
-*/
{
    LVAL result;
    xlsave1(result);
    result = cons( cvflonum(i), NIL    );
    result = cons( cvflonum(h), result );
    result = cons( cvflonum(g), result );
    result = cons( cvflonum(f), result );
    xlpop();
    return result;
}

/* }}} */
/* {{{ lib42_4_Float_List_To_Floats					*/

lib42_4_Float_List_To_Floats( f, g, h, i, pt_list )
float 			     *f,*g,*h,*i;
LVAL		                          pt_list;
{
    LVAL      here   = pt_list;

    if (!consp(here))     xlbadtype(pt_list);
    *f = xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!consp(here))     xlbadtype(pt_list);
    *g = xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!consp(here))     xlbadtype(pt_list);
    *h = xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!consp(here))     xlbadtype(pt_list);
    *i = xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!null(here))      xlbadtype(pt_list);
}

/* }}} */
/* {{{ libE4_2D_List_4_Int						*/

libE4_2D_List_To_4_Int( i, j, k, l, pt_list )
int	               *i,*j,*k,*l; 
LVAL    			    pt_list;
{
    LVAL      here   = pt_list;

    if (!consp(here))     xlbadtype(pt_list);
    *i = (int) xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!consp(here))     xlbadtype(pt_list);
    *j = (int) xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!consp(here))     xlbadtype(pt_list);
    *k = (int) xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!consp(here))     xlbadtype(pt_list);
    *l = (int) xgbj00_Get_Fix_Or_Flo_Num( car(here) );
    here = cdr(here);

    if (!null(here))      xlbadtype(pt_list);
}

/* }}} */
/* {{{ libE5_xlprint_int						*/

libE5_xlprint_int( name, val, fptr )
char*		   name;
int			 val;
LVAL			      fptr;
{
    char buf[ 132 ];
    sprintf( buf, "  %s = %d\n", name, val );
    xlputstr(fptr,buf);
}

/* }}} */
/* {{{ libE6_xlprint_float						*/

libE6_xlprint_float( name, val, fptr )
char*		     name;
float			   val;
LVAL				fptr;
{
    char buf[ 132 ];
    sprintf( buf, "  %s = %-9.6g\n", name, val );
    xlputstr(fptr,buf);
}

/* }}} */
/* {{{ libE7_xlprint_point						*/

libE7_xlprint_point( name, val, fptr )
char*		     name;
geo_point		  *val;
LVAL				fptr;
{
    char buf[ 132 ];
    sprintf( buf, "  %s = (%-9.6g %-9.6g %-9.6g)\n", name, val->x, val->y, val->z );
    xlputstr(fptr,buf);
}

/* }}} */
/* {{{ libE8_xlprint_matrix						*/

libE8_xlprint_matrix( name, val, fptr )
char*		      name;
geo_matrix		   *val;
LVAL				 fptr;
{
    char buf[ 132 ];
    int  i;
    sprintf( buf, "  %s =\n", name );
    xlputstr(fptr,buf);
    for (i = 0;   i < 4;   i++) {
	sprintf( buf,
	    "    | %-9.6g %-9.6g %-9.6g %-9.6g |\n",
	    val->m[i][0],
	    val->m[i][1],
	    val->m[i][2],
	    val->m[i][3]
	);
	xlputstr(fptr,buf);
    }
}

/* }}} */
/* {{{ libF2_Find_Intersection_Of_Line_With_Polygon			*/

libF2_Find_Intersection_Of_Line_With_Polygon( pd, PRM, OBJ,   dmin,dmax, P, L )
float 				             *pd;
geo_point				         *PRM,*OBJ;
float							      dmin,dmax;
geo_point							        *P,*L;
{
    /*******************************************************/ 
    /* GIVEN:                                         	   */
    /*  L (LINE)  is two   points defining a ray L0->L1.   */
    /*  P (PLANE) is three points defining a plane, and	   */
    /*            also a coordinate system with axes   	   */
    /*            s:P0->P1, t:P0->P2.                  	   */
    /*  dmin,dmax, a floatrange explained below.       	   */
    /*                                                 	   */
    /* RETURNED:                                      	   */
    /*  We begin by finding d and *OBJ, the L/P intersect, */
    /*  where *OBJ==LINE0+d*(LINE1-LINE0).  If this is not */
    /*  possible (line parallel to plane or whatever), we  */
    /*  return 0.      We return d via *pd.            	   */
    /*                                                 	   */
    /*  If d is not in (dmin,dmax), we return 1 at this    */
    /*  point. (This is used by caller to ignore           */
    /*  intersections hidden by a previously found         */
    /*  intersection, or the clipping planes.)             */
    /*                                                 	   */
    /*  We then compute the parametric coordinates s,t of  */
    /*  *OBJ relative to P, and return via PRM,            */ 
    /*  finally returning 2.  The s,t coordinates may be   */ 
    /*  used to determine if *OBJ is within the tri/rect-  */
    /*  angle, and also to interpolate values from P to	   */
    /*  *OBJ. (This is adapted from Graphics Gems p390-1.) */
    /*  In the triangular case, the interpolation formula  */
    /*  is u*V0 + s*V1 + t*V2 where u == 1 - (s+t).   	   */
    /*                                                 	   */
    /*******************************************************/ 

    /*******************************************************/ 
    /* Find the intersection of this line with the plane   */
    /* of our given rectangle.  Suppose our three points   */
    /* are arranged so:					   */
    /*							   */
    /*     P2      					   */
    /*     ^      					   */
    /*     |      					   */
    /*     P0-->P1					   */
    /* 							   */
    /* Then the plane may be defined as the set of points  */
    /* P such that P-P0 is perpendicular to the normal to  */
    /* the plane at P0. We may use (P2-P0) CROSS P1-P0 to  */
    /* define a normal to the plane at P0. Remembering     */
    /* that two nonzero vectors are perpendicular iff      */
    /* their dotproduct is zero, our plane can thus be     */
    /* defined as: 					   */
    /* 							   */
    /*	 P such that					   */
    /*     (P-P0) . [ (P2-P0) X (P1-P0) ] == 0	       (1) */
    /* 							   */
    /* Meanwhile, our line of uncertainty consists of all  */
    /* points on the line defined by L0 and L1, which line */
    /* may be expressed parametrically as all points       */
    /* displaced from L0 by an arbitrary scaling of L1-L0: */
    /* 							   */
    /*	 L such that					   */
    /*     L   ==   L0  +  d * (L1-L0)		       (2) */
    /* for some scalar d.				   */
    /* 							   */
    /* To recover the Z coordinate the mouse unkindly	   */
    /* failed to provide us, we need to find the point OBJ */
    /* in the plane by substituting L for P in (1):	   */
    /* 							   */
    /*  ((L0+s*(L1-L0))-P0) . [ (P2-P0) X (P1-P0) ] == 0   */
    /* 							   */
    /* To solve for d, set N === (P2-P0)X(P1-P0) and:	   */
    /* 							   */
    /*           ((L0+d*(L1-L0))-P0).N  == 0		   */
    /*  ((L0-P0)   +  d*(L1-L0))    .N  == 0		   */
    /*   (L0-P0).N +  d*(L1-L0)     .N  == 0		   */
    /*                d*(L1-L0)     .N  ==   (P0-L0).N	   */
    /* 							   */
    /*                                       (P0-L0).N     */
    /*                d                 == -----------     */
    /*                                       (L1-L0).N     */
    /* 							   */
    /* Once derived algebraically, a simple geometric      */
    /* understanding of this formula becomes apparent:	   */
    /*       						   */
    /*  (L1-L0).N is the distance from L0 to the           */
    /*            plane P traversed by the vector L1-L0,   */
    /* 							   */
    /* and						   */
    /* 							   */
    /*  (P1-L0).N is the total distance from L0 to the     */
    /*            plane P,				   */
    /* 							   */
    /* hence the given ratio is the needed value for d,    */
    /* taking us from L0 exactly to P.			   */
    /* 							   */
    /*******************************************************/ 

    /* Declared in order of computation: */
    geo_point P1_P0  ; /*  P1-P0	          */
    geo_point P2_P0  ; /*  P2-P0	          */
    geo_point N      ; /* (P2-P0) X (P1-P0)   */ 	
    geo_point L1_L0  ; /*  L1-L0              */ 	
    float     L1_L0dN; /* (L1-L0).N           */ 	

    geo_point P0_L0  ; /*  P0-L0		  */ 	
    float     P0_L0dN; /* (P0-L0).N           */ 	

    float     d      ; /* (P0-L0).N/(L1-L0).N */ 	

    geo_point L1_L0d ; /* (L1-L0)*d           */ 	

    float     s,  t  ;
    float    u0, v0  ;
    float    u1, v1  ;
    float    u2, v2  ;
    float    denom   ;  /* denom is | u1 u2 | */
			/*          | v1 v2 | */

    /* Compute d: */
    lib11_Vector_Subtract(      &P1_P0, &P[1] , &P[0]  );
    lib11_Vector_Subtract(      &P2_P0, &P[2] , &P[0]  );
    lib00_Vector_Cross_Product( &N    , &P2_P0, &P1_P0 ); 
    lib11_Vector_Subtract(      &L1_L0, &L[1] , &L[0]  );
    L1_L0dN = lib03_Vector_Dot_Product( &L1_L0, &N     );
    if (L1_L0dN == 0.0)   return 0;     /* Line is parallel to plane. */ 

    lib11_Vector_Subtract(      &P0_L0, &P[0], &L[0]   );
    P0_L0dN = lib03_Vector_Dot_Product( &P0_L0, &N     );

    d       = P0_L0dN / L1_L0dN;

    /* Compute mouse location OBJ on thing as d(M1-M0) + M0: */
    L1_L0d  = L1_L0; lib10_Vector_Scale(   &L1_L0d, d   );
    lib12_Vector_Sum( OBJ, &L1_L0d, &L[0] );
    *pd = d;

    if (d < dmin || d > dmax)   return 1;

    /* We project onto one of the coordinate planes now,   */
    /* making sure not to project our polygon into a line: */

    if (N.x < 0.0)  N.x = - N.x;
    if (N.y < 0.0)  N.y = - N.y;
    if (N.z < 0.0)  N.z = - N.z;

    if        (  N.x > N.y   &&   N.x > N.z) {

	u0 = OBJ->y - P[0].y;
	v0 = OBJ->z - P[0].z;

	u1 = P[1].y - P[0].y;
	v1 = P[1].z - P[0].z;

	u2 = P[2].y - P[0].y;
	v2 = P[2].z - P[0].z;

    } else if (/*N.y > N.x   &&*/ N.y > N.z) {

	u0 = OBJ->x - P[0].x;
	v0 = OBJ->z - P[0].z;

	u1 = P[1].x - P[0].x;
	v1 = P[1].z - P[0].z;

	u2 = P[2].x - P[0].x;
	v2 = P[2].z - P[0].z;

    } else     /*N.z > N.x   &&   N.z > N.y*/{

	u0 = OBJ->x - P[0].x;
	v0 = OBJ->y - P[0].y;

	u1 = P[1].x - P[0].x;
	v1 = P[1].y - P[0].y;

	u2 = P[2].x - P[0].x;
	v2 = P[2].y - P[0].y;
    }

    /* Graphics Gems p393 gets very cute here to save */
    /* time, we take a straighforward approach:       */
    denom  = u1*v2 - v1*u2;
    if (denom == 0.0)   return 0; /* Sick input triangle. */
    denom  = 1.0 / denom;
    PRM->x = (u0*v2 - v0*u2) * denom; 
    PRM->y = (u1*v0 - v1*u0) * denom; 
    PRM->z = 0.0;

    return 2;
}

/* }}} */
/* {{{ libP1_InterpolatePointOnLineSeg					*/

libP1_InterpolatePointOnLineseg( result, w, pt0, pt1 )
geo_point	  	        *result;
float					 w;	/* 0 -> 1 weight */
geo_point	  	                   *pt0,*pt1;
{
    /* A simple routine to convert from parametric to absolute coords: */
    float w0 =  w;
    float w1 = (w-1.0);
    result->x = pt0->x * w0   +   pt1->x * w1;
    result->y = pt0->y * w0   +   pt1->y * w1;
    result->z = pt0->z * w0   +   pt1->z * w1;
}

/* }}} */
/* {{{ libP2_InterpolatePointInBox					*/

libP2_InterpolatePointInBox( result, pt, min, max )
geo_point	  	    *result,*pt,*min,*max;
{
    /* A simple routine to convert from parametric to absolute coords: */
    result->x = (max->x - min->x) * pt->x   +   min->x;
    result->y = (max->y - min->y) * pt->y   +   min->y;
    result->z = (max->z - min->z) * pt->z   +   min->z;
}

/* }}} */
/* {{{ libQ0_Quaternion_from_Axis_Angle					*/

libQ0_Quaternion_from_Axis_Angle( axis, angle, q )
geo_point                        *axis;
double  	                        angle;
geo_quaternion                                 q;
{  
  /* Compute the quaternion for an axis of rotation and rotation angle */
  /* (the angle should be specified in radians.)                       */

  q[0] = axis->x * sin(angle / 2.0);
  q[1] = axis->y * sin(angle / 2.0);
  q[2] = axis->z * sin(angle / 2.0);
  q[3] = cos(angle / 2.0);
}

/* }}} */
/* {{{ libQ1_Quaternion_to_Axis_Angle					*/

libQ1_Quaternion_to_Axis_Angle( q, axis, angle )
geo_quaternion                    q;
geo_point                           *axis;
double		                          *angle;
{  
  /* compute the axis of rotation and rotation angle for a given quaternion */
  /* (the angle will be specified in radians.)                              */

  double  denom;

  *angle = acos(q[3]) * 2.0;
  denom  = sin(*angle / 2.0);

  /* If we get a zero-angle rotation (or any multiple thereof), the
   * usual axis computation falls apart due to division by zero.  In
   * such cases, just pick any old axis, since a zero rotation has no
   * effect.  
   */
  if (denom == 0.0) {
    axis->x = 1.0;
    axis->y = 0.0;
    axis->z = 0.0;
  } 
  else {
    axis->x = q[0] / denom;
    axis->y = q[1] / denom;
    axis->z = q[2] / denom;
  }
}

/* }}} */
/* {{{ libQ2_Quaternion_Multiply					*/

libQ2_Quaternion_Multiply( q1, q2, result )
geo_quaternion             q1, q2, result;
{  
    geo_quaternion  tmp;
    tmp[0] = q2[3] * q1[0] + q2[0] * q1[3] +
	q2[1] * q1[2] - q2[2] * q1[1];
    tmp[1] = q2[3] * q1[1] + q2[1] * q1[3] +
	q2[2] * q1[0] - q2[0] * q1[2];
    tmp[2] = q2[3] * q1[2] + q2[2] * q1[3] +
	q2[0] * q1[1] - q2[1] * q1[0];
    tmp[3] = q2[3] * q1[3] - q2[0] * q1[0] -
	q2[1] * q1[1] - q2[2] * q1[2];
    result[0] = tmp[0]; result[1] = tmp[1];
    result[2] = tmp[2]; result[3] = tmp[3];
}

/* }}} */
/* {{{ libQ3_Quaternion_Norm	        				*/

float
libQ3_Quaternion_Norm( q )
geo_quaternion         q;
{  
  /* Quaternions are supposed to obey:  x^2 + y^2 + z^2 + w^2 = 1.0, */
  /* so this should always return (something close to) 1.0.          */
  
  return  (q[0]*q[0] + q[1]*q[1] + q[2]*q[2] + q[3]*q[3]);
}

/* }}} */
/* {{{ libQ4_Quaternion_Normalize					*/

libQ4_Quaternion_Normalize( q )
geo_quaternion              q;
{  
  /* Quaternions always obey:  x^2 + y^2 + z^2 + w^2 = 1.0 */
  /* (but we might need to correct small numerical errors) */

  float  mag = libQ3_Quaternion_Norm( q );
  int    i;

  for (i = 0; i < 4; i++) q[i] /= mag;
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
