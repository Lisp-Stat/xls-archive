/* {{{ ctfm.c -- C support fns for 4x4 transform matrices.	     CrT*/
/*************************************************************************
*
*		This is all C stuff, no xlisp interface code.
* Author:       Jeff Prothero
* Created:      90Dec13
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 98Oct13 kph: Added ctfm75_Decompose_Matrix.                          */
/* 91Sep13 jdp: ctfm28_View finally seems to be bug-free.		*/
/* 91Jul30 jdp: Matrix_Rotate, -Pre, -Post, from Skandha3.		*/
/* 90Dec13 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include <math.h>
#include "../../xcore/c/xlisp.h"
#include "lib.h"
#include "geo.h"
#include "ctfm.h"

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ ctfm00_Identity -- Set to identity matrix.			*/

ctfm00_Identity( m )
geo_matrix*	 m;
/*-
    Set to identity matrix
-*/
{
    int i;
    int j;
    for (i=4; --i>=0;) for (j=4; --j>=0;) m->m[i][j] = 0.0;
    for (i=4; --i>=0;)                    m->m[i][i] = 1.0;
}

/* }}} */
/* {{{ ctfm01_Matrix_Multiply -  Multiply two matrices.			*/

ctfm01_Matrix_Multiply( retrn, a, b )
geo_matrix*		retrn;
geo_matrix*		       a;
geo_matrix*			  b;
/*-
    Multiply two matrices.
-*/
{ 
    register int   i; 
    register int   j; 
  
    /* This routine is probably not a performance bottleneck: */ 
    for (i = 0;   i < 4;   ++i) { 
  
        for (j = 0;   j < 4;   ++j) { 
  
            retrn->m[ i ][ j ] = ( 
  
                a->m[ i ][ 0 ]   *   b->m[ 0 ][ j ] 		+
                a->m[ i ][ 1 ]   *   b->m[ 1 ][ j ] 		+
                a->m[ i ][ 2 ]   *   b->m[ 2 ][ j ] 		+
                a->m[ i ][ 3 ]   *   b->m[ 3 ][ j ] 
            ); 
        } 
    } 
} 

/* }}} */
/* {{{ ctfm02_Matrix_Multiply_Pre -- Pre-multiply matrix by given matrix*/

ctfm02_Matrix_Multiply_Pre( m, x )
geo_matrix*		    m;
geo_matrix*		       x;
/*-
    Pre-multiply matrix by given matrix.
-*/
{
    if (m != x) {
        geo_matrix a;a = *m;
        ctfm01_Matrix_Multiply( m, x, &a );
    } else {
        geo_matrix a;
        geo_matrix b;
        a = *x;
        b = *m;
        ctfm01_Matrix_Multiply( m, &a, &b );
    }
}

/* }}} */
/* {{{ ctfm03_Matrix_Multiply_Post--Post-multiply matrix by given matrix*/

ctfm03_Matrix_Multiply_Post( m, x )
geo_matrix*		     m;
geo_matrix*			x;
/*-
    Post-multiply matrix by given matrix.
-*/
{
    if (m != x) {
        geo_matrix a;a = *m;
        ctfm01_Matrix_Multiply( m, &a, x );
    } else {
        geo_matrix a;
        geo_matrix b;
        a = *m;
        b = *x;
        ctfm01_Matrix_Multiply( m, &a, &b );
    }
}

/* }}} */
/* {{{ ctfm04_Move -- Build XYZ-translation matrix.			*/

ctfm04_Move( m, p )
geo_matrix*  m;
geo_point*	p;
/*-
    Build XYZ-translation matrix.
-*/
{
    ctfm00_Identity(m);
    m->m[ 3 ][ 0 ]   =  p->x;
    m->m[ 3 ][ 1 ]   =  p->y;
    m->m[ 3 ][ 2 ]   =  p->z;
}

/* }}} */
/* {{{ ctfm05_Move_Pre--Build XYZ-translation matrix, pre-multiply by it*/

ctfm05_Move_Pre( m, p )
geo_matrix*	 m;
geo_point*	    p;
/*-
    Build XYZ-translation matrix, pre-multiply by it.
-*/
{
    geo_matrix   a;
    ctfm04_Move(&a,p);
    ctfm02_Matrix_Multiply_Pre(m,&a);
}

/* }}} */
/* {{{ ctfm06_Move_Post--Build XYZ-translation matrix,post-multiply by't*/

ctfm06_Move_Post( m, p )
geo_matrix*	  m;
geo_point*	     p;
/*-
    Build XYZ-translation matrix, post-multiply by it.
-*/
{
    geo_matrix   a;
    ctfm04_Move(&a,p);
    ctfm03_Matrix_Multiply_Post(m,&a);
}

/* }}} */
/* {{{ ctfm07_X_Rotate -- Build X-rotation matrix.			*/

ctfm07_X_Rotate( m, radians )
geo_matrix*	 m;
double              radians;
/*-
    Build X-rotation matrix.
-*/
{
    double       cosr = cos( radians );
    double       sinr = sin( radians );
    ctfm50_X_Rotate_Cos_Sin( m, cosr, sinr );
}

ctfm50_X_Rotate_Cos_Sin( m, cosr, sinr )
geo_matrix*	         m;
double                      cosr, sinr;
/*-
    Build X-rotation matrix.
-*/
{
    ctfm00_Identity(m);
    /* Note: we're using the Right Hand Rule and */
    /* a left-handed coordinate system.          */
    m->m[ 1 ][ 1 ]   =  cosr;    m->m[ 1 ][ 2 ]   = -sinr;
    m->m[ 2 ][ 1 ]   =  sinr;    m->m[ 2 ][ 2 ]   =  cosr;
}

/* }}} */
/* {{{ ctfm08_X_Rotate_Pre--Build X-rotation matrix, pre-multiply by it.*/

ctfm08_X_Rotate_Pre( m, radians )
geo_matrix*	     m;
double			radians;
/*-
    Build X-rotation matrix, pre-multiply by it.
-*/
{
    geo_matrix a;
    ctfm07_X_Rotate(&a,radians);
    ctfm02_Matrix_Multiply_Pre(m,&a);
}

/* }}} */
/* {{{ ctfm09_X_Rotate_Post--Build X-rotation matrix,post-multiply by it*/

ctfm09_X_Rotate_Post( m, radians )
geo_matrix*	      m;
double			 radians;
/*-
    Build X-rotation matrix,post-multiply by it.
-*/
{
    geo_matrix a;
    ctfm07_X_Rotate(&a,radians);
    ctfm03_Matrix_Multiply_Post(m,&a);
}
ctfm51_X_Rotate_Post_Cos_Sin( m, cos_val, sin_val )
geo_matrix*	              m;
double			         cos_val, sin_val;
/*-
    Build X-rotation matrix,post-multiply by it.
-*/
{
    geo_matrix a;
    ctfm50_X_Rotate_Cos_Sin(&a,cos_val,sin_val);
    ctfm03_Matrix_Multiply_Post(m,&a);
}

/* }}} */
/* {{{ ctfm10_Y_Rotate -- Build Y-rotation matrix.			*/

ctfm10_Y_Rotate( m, radians )
geo_matrix*	 m;
double		    radians;
/*-
    Build Y-rotation matrix.
-*/
{
    double       cosr = cos( radians );
    double       sinr = sin( radians );
    ctfm52_Y_Rotate_Cos_Sin( m, cosr, sinr );
}
ctfm52_Y_Rotate_Cos_Sin( m, cosr, sinr )
geo_matrix*	         m;
double                      cosr, sinr;
/*-
    Build Y-rotation matrix.
-*/
{
    ctfm00_Identity(m);
    m->m[ 0 ][ 0 ]   =  cosr;    m->m[ 0 ][ 2 ]   =  sinr;
    m->m[ 2 ][ 0 ]   = -sinr;    m->m[ 2 ][ 2 ]   =  cosr;
}

/* }}} */
/* {{{ ctfm11_Y_Rotate_Pre--Build Y-rotation matrix, pre-multiply by it.*/

ctfm11_Y_Rotate_Pre( m, radians )
geo_matrix*	     m;
double			radians;
/*-
    Build Y-rotation matrix, pre-multiply by it.
-*/
{
    geo_matrix a;
    ctfm10_Y_Rotate(&a,radians);
    ctfm02_Matrix_Multiply_Pre(m,&a);
}

/* }}} */
/* {{{ ctfm12_Y_Rotate_Post--Build Y-rotation matrix,post-multiply by it*/

ctfm12_Y_Rotate_Post( m, radians )
geo_matrix*	      m;
double			 radians;
/*-
    Build Y-rotation matrix,post-multiply by it.
-*/
{
    geo_matrix a;
    ctfm10_Y_Rotate(&a,radians);
    ctfm03_Matrix_Multiply_Post(m,&a);
}
ctfm53_Y_Rotate_Post_Cos_Sin( m, cos_val, sin_val )
geo_matrix*	              m;
double			         cos_val, sin_val;
/*-
    Build Y-rotation matrix,post-multiply by it.
-*/
{
    geo_matrix a;
    ctfm52_Y_Rotate_Cos_Sin(&a,cos_val,sin_val);
    ctfm03_Matrix_Multiply_Post(m,&a);
}

/* }}} */
/* {{{ ctfm13_Z_Rotate -- Build Z-rotation matrix.			*/

ctfm13_Z_Rotate( m, radians )
geo_matrix*	 m;
double		    radians;
/*-
    Build Z-rotation matrix.
-*/
{
    double       sinr = sin( radians );
    double       cosr = cos( radians );
    ctfm54_Z_Rotate_Cos_Sin( m, cosr, sinr );
}
ctfm54_Z_Rotate_Cos_Sin( m, cosr, sinr )
geo_matrix*	         m;
double                      cosr, sinr;
/*-
    Build Z-rotation matrix.
-*/
{
    ctfm00_Identity(m);
    m->m[ 0 ][ 0 ]  =  cosr;    m->m[ 0 ][ 1 ]  = -sinr;
    m->m[ 1 ][ 0 ]  =  sinr;    m->m[ 1 ][ 1 ]  =  cosr;
}

/* }}} */
/* {{{ ctfm14_Z_Rotate_Pre--Build Z-rotation matrix, pre-multiply by it.*/

ctfm14_Z_Rotate_Pre( m, radians )
geo_matrix*	     m;
double			radians;
/*-
    Build Z-rotation matrix, pre-multiply by it.
-*/
{
    geo_matrix a;
    ctfm13_Z_Rotate(&a,radians);
    ctfm02_Matrix_Multiply_Pre(m,&a);
}

/* }}} */
/* {{{ ctfm15_Z_Rotate_Post--Build Z-rotation matrix,post-multiply by it*/

ctfm15_Z_Rotate_Post( m, radians )
geo_matrix*	      m;
double			 radians;
{
/*-
    Build Z-rotation matrix,post-multiply by it.
-*/
    geo_matrix a;
    ctfm13_Z_Rotate(&a,radians);
    ctfm03_Matrix_Multiply_Post(m,&a);
}
ctfm55_Z_Rotate_Post_Cos_Sin( m, cos_val, sin_val )
geo_matrix*	              m;
double			         cos_val, sin_val;
/*-
    Build Y-rotation matrix,post-multiply by it.
-*/
{
    geo_matrix a;
    ctfm54_Z_Rotate_Cos_Sin(&a,cos_val,sin_val);
    ctfm03_Matrix_Multiply_Post(m,&a);
}

/* }}} */
/* {{{ ctfm16_Scale -- Build XYZ-scaling matrix.			*/

ctfm16_Scale(  mat, origin, xyz_scale )
geo_matrix *   mat;
geo_point          *origin,*xyz_scale;
{
    /***********************************************/
    /* "origin" is a point in space.               */
    /* "xyz_scale" is the scale factors.           */
    /***********************************************/

    geo_matrix to_origin;
    geo_matrix scale_at_origin;
    geo_matrix from_origin;
    geo_matrix tmp;

    geo_point origin_inv; origin_inv = *origin;
    lib07_Vector_Negate( &origin_inv );

    /* Translate "origin" to coordinate space origin: */
    ctfm04_Move( &to_origin, &origin_inv );

    /* Scale at origin: */
    ctfm00_Identity(&scale_at_origin);
    scale_at_origin.m[ 0 ][ 0 ]   =  xyz_scale->x;
    scale_at_origin.m[ 1 ][ 1 ]   =  xyz_scale->y;
    scale_at_origin.m[ 2 ][ 2 ]   =  xyz_scale->z;

    /* Translate back to correct spot in space: */
    ctfm04_Move( &from_origin, origin );


    /*************************************/
    /* Multiply all component transforms */
    /* together and return result:       */
    /*************************************/
    ctfm01_Matrix_Multiply( &tmp, &to_origin, &scale_at_origin );
    ctfm01_Matrix_Multiply( mat,  &tmp,       &from_origin     );
}

/* }}} */
/* {{{ ctfm17_Scale_Pre -- Build XYZ-scaling matrix, pre-multiply by it.*/

ctfm17_Scale_Pre( m, origin, xyz_scale )
geo_matrix*	  m;
geo_point           *origin,*xyz_scale;
/*-
    Build XYZ-scaling matrix, pre-multiply by it.
-*/
{
    geo_matrix   a;
    ctfm16_Scale(&a,origin,xyz_scale);
    ctfm02_Matrix_Multiply_Pre(m,&a);
}

/* }}} */
/* {{{ ctfm18_Scale_Post--Build XYZ-translation matrix,post-mult by it. */

ctfm18_Scale_Post( m, origin, xyz_scale )
geo_matrix*	   m;
geo_point            *origin,*xyz_scale;
/*-
    Build XYZ-translation matrix,post-mult by it.
-*/
{
    geo_matrix   a;
    ctfm16_Scale(&a,origin,xyz_scale);
    ctfm03_Matrix_Multiply_Post(m,&a);
}

/* }}} */
/* {{{ ctfm19_Shear -- Build shear matrix.				*/

ctfm19_Shear( m, s10,s20,s01,s21,s02,s12 )
geo_matrix*   m;
double		 s10,s20,s01,s21,s02,s12;
/*-
    Build shear matrix.
-*/
{
    ctfm00_Identity(m);

                    m->m[0][1]=s01; m->m[0][2]=s02; 
    m->m[1][0]=s10;                 m->m[1][2]=s12; 
    m->m[2][0]=s20; m->m[2][1]=s21; 
}

/* }}} */
/* {{{ ctfm20_Shear_Pre -- Build shear matrix, pre-multiply by it.	*/

ctfm20_Shear_Pre( m, s10,s20,s01,s21,s02,s12 )
geo_matrix*	  m;
double		     s10,s20,s01,s21,s02,s12;
/*-
    Build shear matrix, pre-multiply by it.
-*/
{
    geo_matrix   a;
    ctfm19_Shear(&a,s10,s20,s01,s21,s02,s12);
    ctfm02_Matrix_Multiply_Pre(m,&a);
}

/* }}} */
/* {{{ ctfm21_Shear_Post -- Build shear matrix, post-multiply by it.	*/

ctfm21_Shear_Post( m, s10,s20,s01,s21,s02,s12 )
geo_matrix*	   m;
double		      s10,s20,s01,s21,s02,s12;
{
/*-
    Build shear matrix, post-multiply by it.
-*/
    geo_matrix   a;
    ctfm19_Shear(&a,s10,s20,s01,s21,s02,s12);
    ctfm03_Matrix_Multiply_Post(m,&a);
}

/* }}} */
/* {{{ ctfm24_Orthographic -- Build orthographic projection matrix.	*/

ctfm24_Orthographic( m, left, roit, top, bot, far, near )
geo_matrix*          m;
double		        left, roit, top, bot, far, near;
/*-
    Build Orthographic projection matrix.
-*/
{
    /************************************************************/
    /* This fn takes a description of a box viewed from the     */
    /* origin down the Z axis, defined by the given parameters, */
    /* and maps it onto the clipping cube bounded by            */
    /* (-1,-1,-1) and (1,1,1), used by the SGI hardware.        */
    /* Yeah, this is supposed to be machine-independent code :) */
    /************************************************************/
    geo_point origin, xyz_scale;
#ifdef NOISE
printf("\nctfm24_Orthographic: left roit top bot far near %g %g %g %g %g %g\n", left,roit,top,bot,far,near);
#endif

    /* Prevent divide-by-zeros.  The original code did an xlfail(), */
    /* but experience suggests it's more welcome to produce visual  */
    /* nonsense than to crash into the lisp debugger...             */
    if (left     == roit)   left  = roit - 1.0;
    if (top      == bot )   top   = bot  + 1.0;
    if (far      == near)   far   = near + 1.0;

    /* Scale viewed volume to be two units on each axis: */
    origin.x    = 0.0;
    origin.y    = 0.0;
    origin.z    = 0.0;
    xyz_scale.x =  2.0 / (roit - left);
    xyz_scale.y =  2.0 / (top  - bot );
    xyz_scale.z = -2.0 / (far  - near);
    ctfm16_Scale( m, &origin, &xyz_scale );

    /* Translate the viewed volume to origin: */
    m->m[ 3 ][ 0 ]   = -(roit + left) / (roit - left);
    m->m[ 3 ][ 1 ]   = -(top  + bot ) / (top  - bot );
    m->m[ 3 ][ 2 ]   = -(far  + near) / (far  - near);
    m->m[ 3 ][ 3 ]   = 1.0;

    /* Moved here from iris4d driver 92Feb26jsp so picking can work. */
    m->m[2][2] = -m->m[2][2];
/*  m->m[2][3] = -m->m[2][3]; *//* Commented out blindly empirically */
/*  m->m[3][2] = -m->m[3][2]; *//* 95Jan11jsp to get a display... :) */
#ifdef NOISE
lib25_Matrix_Print_Double( "ctfm24_Orthographic", m ) ;
printf("\nctfm24_Orthographic: %g %g %g %g\n", m->m[0][0], m->m[1][1], m->m[2][2], m->m[3][3] ) ;
#endif
}

/* }}} */
/* {{{ ctfm25_Perspective -- Build perspective matrix.			*/

ctfm25_Perspective( m, aspect, fovy, far, near )
geo_matrix*         m;
double		       aspect, fovy, far, near;
/*-
    Build perspective matrix.
-*/
{
    /************************************************************/
    /* This fn takes a description of a frustum viewed from the */
    /* origin down the Z axis, defined by the given parameters, */
    /* and maps it onto the clipping cube bounded by            */
    /* (-1,-1,-1) and (1,1,1), used by the SGI hardware.        */
    /* Yeah, this is supposed to be machine-independent code :) */
    /************************************************************/
    double cot_fovy_2;
    geo_point origin, xyz_scale;

    /* Prevent divide-by-zeros.  The original code did an xlfail(), */
    /* but experience suggests it's more welcome to produce visual  */
    /* nonsense than to crash into the lisp debugger...             */
    if (fovy     <= 0.0)   fovy   =        1.0;
    if (aspect   <= 0.0)   aspect =        1.0;
    if (near     <= 0.0)   near   =        0.0001;
    if (far-near <= 0.0)   far    = near + 1.0;

    /* Set three diagonal entries: */
    cot_fovy_2  = cos( 0.5 * fovy ) / sin( 0.5 * fovy );

    origin.x    = 0.0;
    origin.y    = 0.0;
    origin.z    = 0.0;
    xyz_scale.x = cot_fovy_2 / aspect;
    xyz_scale.y = cot_fovy_2;
    xyz_scale.z = - (far + near) / (far - near);
    ctfm16_Scale( m, &origin, &xyz_scale );

    /****************************************************************/
    /* Set the three remaining entries.  Note that the [3][2] entry */
    /* is documented as negated in the SGI manual                   */
    /* (GT Graphics Library Users Guide Appendix C.5.):             */ 
    /* Un-negated works better for us, I'm not sure whether this is */
    /* a typo or related to our use of a left-handed coord system.  */
    /****************************************************************/
    m->m[ 2 ][ 3 ]   = -1.0;
    m->m[ 3 ][ 2 ]   = (2.0 * far * near) / (far - near);
    m->m[ 3 ][ 3 ]   =  0.0;

    /* Moved here from iris4d driver 92Feb26jsp so picking can work. */
    m->m[2][2] = -m->m[2][2];
    m->m[2][3] = -m->m[2][3];
    m->m[3][2] = -m->m[3][2];
}
#ifndef EYEPHONE_KLUDGE
ctfm2a_Window( m, aspect, fovy, far, near, left_plus_roit, topp_plus_bott )
geo_matrix*    m;
double            aspect, fovy, far, near;
double                                     left_plus_roit, topp_plus_bott;
/*-
      Build window matrix.
      -*/
{
    /************************************************************/
    /* This fn is a variant of ctfm25_Perspective designed to   */
    /* humor the eyephones, which are mounted at a weird angle  */
    /* that requires the sgi window() call or equivalent to     */
    /* distort the image appropriately.  (sgi window() is a     */
    /* superset of sgi perspective(), since it can handle       */
    /* off-axis windows, but perspective() can't.)              */
    /************************************************************/
    
    /* Perspective matrix:
    /
    /  Key:
    /
    /     cot  = cot[ fov/2 ]
    /     asp  = aspect ratio, x/y
    /     far  = far  clipping plane
    /     near = near clipping plane
    /
    /  Definition of matrix entries:
    /
    /  [0][0] = cot/asp
    /  [1][1] = cot
    /  [2][2] = -(far + near) / (far - near)
    /  [3][2] = - 2 * far * near / (far - near)
    /  [2][3] = -1
    */
    
    /* Window matrix:
    /
    /  Key:
    /
    /     n    = near   (z)
    /     f    = far    (z)
    /     l    = left   (x)
    /     r    = roit   (x)
    /     t    = top    (y)
    /     b    = bottom (y)
    /
    /  Definition of matrix entries:
    /
    /  [0][0] = 2n / (r-l)
    /  [1][1] = 2n / (t-b)
    /  [2][2] = -(f + n) / (f - n)
    /  [2][0] =  (r + l) / (r - l)
    /  [2][1] =  (t + b) / (t - b)
    /  [2][3] =  -1
    /  [3][4] = -2 f n / (f - n)
    */
    
    /* This sets all but m[2,0] and m[2,1] correctly: */
    ctfm25_Perspective( m, aspect, fovy, far, near );
    
    /*********************************************************************/
    /* Set m[2,0] and m[2,1].  We are passed r+l and t+b as parameters,  */
    /* and use these for our entries.  We assume that they have already  */
    /* been scaled by 1/(r-l) and 1/(t-b), respectively.		 */
    /*********************************************************************/
    m->m[ 2 ][ 0 ]   = left_plus_roit;
    m->m[ 2 ][ 1 ]   = topp_plus_bott;
}
#endif


/* }}} */
/* {{{ ctfm26_Perspective_Pre--Build perspective matrix, pre-mult by it.*/

ctfm26_Perspective_Pre( m, aspect, fovy, far, near ) 
geo_matrix*	        m;
double		           aspect, fovy, far, near;
/*-
    Build perspective matrix, pre-multiply by it.
-*/
{
    geo_matrix a;
    ctfm25_Perspective( &a, aspect, fovy, far, near );
    ctfm02_Matrix_Multiply_Pre( m, &a );
}

/* }}} */
/* {{{ ctfm27_Perspective_Post--Build perspective matrix, post-mult by't*/

ctfm27_Perspective_Post( m, aspect, fovy, far, near ) 
geo_matrix*	         m;
double		            aspect, fovy, far, near;
/*-
    Build perspective matrix, post-multiply by it.
-*/
{
    geo_matrix a;
    ctfm25_Perspective( &a, aspect, fovy, far, near );
    ctfm03_Matrix_Multiply_Post( m, &a );
}

/* }}} */
/* {{{ ctfm28_View -- Build viewing matrix.				*/

ctfm28_View( viewing_mat, location, target, up )
geo_matrix*  viewing_mat;
geo_point                *location,*target,*up;
/*-
    Build viewing matrix.
-*/
{
    /*************************************************************/
    /* This fn takes a viewpoint, a point to look at, and an 'up'*/
    /* point, and transforms so the viewpoint is at the origin,  */
    /* the 'target' is on the positive the Z axis, and 'up' is   */
    /* as near the positive Y axis as we can manage.             */
    /*								 */
    /* Actually, we compute the inverse transform, that puts the */
    /* origin on 'location', the z axis through 'target' etc ... */
    /* because it gets inverted when we draw.  (For consistency  */
    /* with other positioning matrices...)                       */
    /*								 */
    /* Strategy is:						 */
    /* (1) Translate so location is at origin.			 */
    /* (2) Rotate target vector into YZ plane.			 */
    /* (3) Rotate target vector onto +Z axis.			 */
    /* (4) Rotate 'up'   vector into YZ plane.			 */
    /*************************************************************/

    /* 'T' is for Target, 'U' is for Up ... */
    geo_point t;
    geo_point t_sqr;
    float     t_xz;  /* Length of XZ-plane-projected target vector. */
    float     t_xyz; /* Length of                    target vector. */

    float cos_x; /* Sin/Cos of angle to rotate through around X axis. */
    float sin_x;

    float cos_y; /* Sin/Cos of angle to rotate through around Y axis. */
    float sin_y;

    float cos_z; /* Sin/Cos of angle to rotate through around Z axis. */
    float sin_z;

    /* Compute direction to target from target and location: */
    lib11_Vector_Subtract( &t, target, location ); 

    /* Compute target vector length, absolutely and in XZ plane: */
    lib40_Vector_Pointwise_Product( &t_sqr, &t, &t );
    t_xz	= sqrt( t_sqr.x +           t_sqr.z );
    t_xyz	= sqrt( t_sqr.x + t_sqr.y + t_sqr.z );

    /********************************************************************/
    /* If target vector is of length zero, our direction is undefined.	*/
    /* Since the user can probably do this interactively, we do some-	*/
    /* thing arbitrary rather than crashing at the lisp (much less C!)	*/
    /* level:								*/
    /********************************************************************/
    if (t_xyz <= 0.0) {  /* <= not == because I don't trust float arithmetic */

        cos_x = cos_y = cos_z = 1.0;
        sin_x = sin_y = sin_z = 0.0;

    } else {

	/****************************************************************/
	/* First step is to rotate target vector into YZ plane.  If our */
	/* target vector points along Y axis, we don't need to do any-  */
	/* thing except avoid a divide-by-zero:                         */
	/****************************************************************/
	if (t_xz <= 0.0) { /* Should be == not <=, algebraically :) */
	    cos_y = 1.0;
	    sin_y = 0.0;
	} else {
	    cos_y  =  t.z  / t_xz;
	    sin_y  =  t.x  / t_xz;
	}

	/****************************************************************/
        /* Target vector is now in YZ plane, we need that x-rotation    */
	/* which will align target vector with positive Z axis:         */
	/****************************************************************/
        cos_x  =  t_xz / t_xyz; 
        sin_x  =  t.y  / t_xyz;

	/****************************************************************/
	/* Target vector now points along positive Z axis, we need that */
	/* z-rotation which will put the 'up' vector in the YZ plane.   */
	/* We start out by figuring where we've transformed 'up' to so  */
	/* far:								*/
	/****************************************************************/
	{   geo_matrix inv ;
	    geo_point u;
	    geo_point u_sqr;
	    float     u_xy;  /* Length of XY-plane-projected up     vector. */

	    /* Figure rotation-to-date remembering we need inverse actually:*/
            /* Note sin(-a) == -sin(a) but cos(-a)==cos(a) ... */
	    ctfm00_Identity( &inv );
	    ctfm53_Y_Rotate_Post_Cos_Sin( &inv, cos_y,  sin_y );
	    ctfm51_X_Rotate_Post_Cos_Sin( &inv, cos_x, -sin_x );

	    /* Compute 'up' direction from 'up' point and 'location' point: */
	    lib11_Vector_Subtract( &u, up, location ); 

	    /* Figure out what we've done to 'up' direction so far:         */
	    lib26_Matrix_Apply_To_Point( &u, &u, &inv );

	    /* Figure length of transformed, XY-plane-projected up vector:  */
	    lib40_Vector_Pointwise_Product( &u_sqr, &u, &u );
	    u_xy	= sqrt( u_sqr.x + u_sqr.y );

	    /* If u_xy is zero, then 'up' vector is aligned with 'target'   */
	    /* vector and doesn't specify an up direction at all.  Again,   */
	    /* interactive user can probably do this, so we default to null */
	    /* rotation rather than crash:				    */
	    if (u_xy <= 0.0) {
		cos_z = 1.0;
		sin_z = 0.0;
	    } else {
		/* Note zero angle is wrt y axis here, not x! */
		cos_z = u.y / u_xy;
		sin_z = u.x / u_xy;
    }	}   }

    /* Okie, string them all together in reversed order and we're done!	    */
    ctfm00_Identity(              viewing_mat			);
    ctfm55_Z_Rotate_Post_Cos_Sin( viewing_mat,  cos_z,  sin_z   );
    ctfm51_X_Rotate_Post_Cos_Sin( viewing_mat,  cos_x,  sin_x   );
    ctfm53_Y_Rotate_Post_Cos_Sin( viewing_mat,  cos_y, -sin_y	);
    ctfm06_Move_Post( 		  viewing_mat,  location	);

    /* If you're tinkering with this fn, the basic */
    /* invariants to maintain are checked so:      */
#ifdef LOCAL_INVARIANTS /* Never actually #defined anywhere :) */
    {   geo_matrix inv;  geo_point u;
	ctfm44_Invert_Matrix( &inv, viewing_mat );
	lib26_Matrix_Apply_To_Point( &u, target, &inv );
	if (u.x != 0.0 || u.y != 0.0) xlfail("ctfm28_View/target");
	lib26_Matrix_Apply_To_Point( &u, up, &inv );
	if (u.x != 0.0) xlfail("ctfm28_View/up"); /* u.z==0.0 if user cooperated. */
    }
#endif
}

/* }}} */
/* {{{ ctfm29_View_Pre -- Build viewing matrix, pre-mult by it.		*/

ctfm29_View_Pre( m, from, to, up ) 
geo_matrix*	 m;
geo_point          *from,*to,*up;
/*-
    Build viewing matrix, pre-multiply by it.
-*/
{
    geo_matrix a;
    ctfm28_View( &a, from, to, up );
    ctfm02_Matrix_Multiply_Pre( m, &a );
}

/* }}} */
/* {{{ ctfm30_View_Post -- Build viewing matrix, post-mult by it.	*/

ctfm30_View_Post( m, from, to, up ) 
geo_matrix*	  m;
geo_point           *from,*to,*up;
/*-
    Build viewing matrix, post-multiply by it.
-*/
{
    geo_matrix a;
    ctfm28_View( &a, from, to, up );
    ctfm03_Matrix_Multiply_Post( m, &a );
}

/* }}} */
/* {{{ ctfm31_Rotate -- Build rotation matrix.				*/

ctfm31_Rotate( mat, origin, axis, radians )
geo_matrix *   mat;
geo_point  *        origin;
geo_point  *                axis;
double                            radians;
{
    /***********************************************/
    /* "origin" is a point in space.               */
    /* "axis" is a direction vector at that point. */
    /* We want to construct a transform that will  */
    /* rotate space by "radians" around origin/    */
    /* axis.                                       */
    /*   Foley & van Dam p258 (sec 7.6) give one   */
    /* approach.  Ours is from comp.graphics:      */
    /***********************************************/

    geo_matrix to_Origin;
    geo_matrix around_Axis;
    geo_matrix from_Origin;
    geo_matrix tmp;

    geo_point origin_inv; origin_inv = *origin;
    lib07_Vector_Negate( &origin_inv );

    /* Translate "origin" to coordinate space origin: */
    ctfm04_Move( &to_Origin, &origin_inv );

    /* Rotate around given axis: */
    ctfm32_Rotate_Dan( &around_Axis, axis, radians );

    /* Translate back to correct spot in space: */
    ctfm04_Move( &from_Origin, origin );


    /*************************************/
    /* Multiply all component transforms */
    /* together and return result:       */
    /*************************************/
    ctfm01_Matrix_Multiply( &tmp, &to_Origin, &around_Axis );
    ctfm01_Matrix_Multiply( mat,  &tmp,       &from_Origin );
}
ctfm32_Rotate_Dan( mat, axis, rad_arg )
geo_matrix *       mat;
geo_point  *            axis;          /* Normalized!                */
double                        rad_arg; /* Rotate through this angle. */
{
    /******************************************************/
    /* Takes a vector whose direction defines an axis     */
    /* of rotation, plus an angle of rotation in radians, */
    /* and fills in the corresponding (4x4) rotation      */
    /* matrix.  Obtained from a paper by Michael Pique.   */
    /*                                                    */
    /*   To construct a rotation which maps V1 to V2:     */
    /*   axis = V1 x V2   (May have the order backwards.) */
    /*   angle = arcsin( length( axis ) )                 */
    /*                                                    */
    /* Since the cross product produces a vector whose    */
    /* length is the sine of the angle between the two    */
    /* vectors, we must take the arcsin as above.         */
    /*                                                    */
    /*   jdchrist@watcgl.waterloo.edu (Dan Christensen)   */
    /*   Newsgroups: comp.sys.sgi,comp.graphics           */
    /*   Date: 31 May 90 17:19:37 GMT                     */
    /*   Computer Graphics Lab, University of Waterloo    */
    /******************************************************/

    float   x = axis->x;
    float   y = axis->y;
    float   z = axis->z;
    float   sinA;
    float   cosA;
    float   t;
    float   len2 = x*x + y*y + z*z;
    float   radians = -rad_arg;   /* For right-hand rule in left-handed coords. */
    if (len2 < 0.999   ||   len2 > 1.0001) {
        float lenInv = 1.0   /   sqrt( len2 );
        x *= lenInv;
        y *= lenInv;
        z *= lenInv;
    }

    sinA = sin( radians );
    cosA = cos( radians );
    t    = 1.0 - cosA;

    mat->m[0][0] = t * x*x + cosA;
    mat->m[0][1] = t * x*y + sinA*z;
    mat->m[0][2] = t * x*z - sinA*y;
    mat->m[0][3] = 0;

    mat->m[1][0] = t * y*x - sinA*z;
    mat->m[1][1] = t * y*y + cosA;
    mat->m[1][2] = t * y*z + sinA*x;
    mat->m[1][3] = 0;

    mat->m[2][0] = t * x*z + sinA*y;
    mat->m[2][1] = t * y*z - sinA*x;
    mat->m[2][2] = t * z*z + cosA;
    mat->m[2][3] = 0;

    mat->m[3][0] = 0;
    mat->m[3][1] = 0;
    mat->m[3][2] = 0;
    mat->m[3][3] = 1;
}

/* }}} */
/* {{{ ctfm33_Rotate_Pre -- Build rotation matrix, pre-mult by it.   	*/

ctfm33_Rotate_Pre( mat, origin, axis, radians )
geo_matrix *       mat;
geo_point  *            origin;
geo_point  *                    axis;         /* Must be unit length. */
double                                radians;
{  
    geo_matrix tmpA;
    geo_matrix tmpB;
      
    ctfm31_Rotate( &tmpA,   origin, axis, radians );  
    tmpB    = *mat;     
    		
    ctfm01_Matrix_Multiply( mat, &tmpA, &tmpB );
}     
      
/* }}} */
/* {{{ ctfm34_Rotate_Post -- Build rotation matrix, post-mult by it. 	*/

ctfm34_Rotate_Post( mat, origin, axis, radians )
geo_matrix * 	    mat;
geo_point  * 		 origin;
geo_point  *            	 axis;         /* Must be unit length. */
double			               radians;
{  
    geo_matrix tmpA;     
    geo_matrix tmpB;
      
    tmpA    = *mat;     
    ctfm31_Rotate( &tmpB,   origin, axis, radians );  
      
    ctfm01_Matrix_Multiply( mat, &tmpA, &tmpB );
}     
      
/* }}} */
/* {{{ ctfm37_Move_Axis -- Build XYZ-translation matrix.		*/

ctfm37_Move_Axis( m, axis, distance )
geo_matrix*       m;
geo_point*	     axis;
double*                    distance;
/*-
    Build XYZ-translation matrix.
-*/
{
    ctfm00_Identity(m);
    m->m[ 3 ][ 0 ]   =  axis->x ** distance;
    m->m[ 3 ][ 1 ]   =  axis->y ** distance;
    m->m[ 3 ][ 2 ]   =  axis->z ** distance;
}

/* }}} */
/* {{{ ctfm38_Move_Axis_Pre--Build XYZ-translation matrix, pre-mult by't*/

ctfm38_Move_Axis_Pre( m, axis, distance )
geo_matrix*	      m;
geo_point*	         axis;
double*                        distance;
/*-
    Build XYZ-translation matrix, pre-multiply by it.
-*/
{
    geo_matrix   a;
    ctfm37_Move_Axis(&a, axis, distance );
    ctfm02_Matrix_Multiply_Pre(m,&a);
}

/* }}} */
/* {{{ ctfm39_Move_Axis_Post--Build XYZ-translation matrix,post-mult    */

ctfm39_Move_Axis_Post( m, axis, distance )
geo_matrix*	       m;
geo_point*	          axis;
double*				distance;
/*-
    Build XYZ-translation matrix, post-multiply by it.
-*/
{
    geo_matrix   a;
    ctfm37_Move_Axis(&a,axis,distance);
    ctfm03_Matrix_Multiply_Post(m,&a);
}

/* }}} */
/* {{{ ctfm45_Invert_Matrix						*/

/* Following fns adapted from Graphic Gems p766.   */
/* I'm somewhat suspicious of this code!!! jsp...  */
/* I'm not at all sure Numerical Recipes would     */
/* approve of the stability or efficiency...       */
/* nor does the original coding inspire confidence.*/

#define SMALL_NUMBER (1e-10)

#define det2x2(a,b,c,d) (a*d-b*c)

double ctfm41_det3x3( a1,a2,a3, b1,b2,b3, c1,c2,c3 )
double		      a1,a2,a3, b1,b2,b3, c1,c2,c3 ;
{
    double ans;
    ans = a1 * det2x2( b2, b3, c2, c3 )
        - b1 * det2x2( a2, a3, c2, c3 )
        + c1 * det2x2( a2, a3, b2, b3 )
    ;
    return ans;
}

double ctfm42_det4x4( m )
geo_matrix           *m;
{
    /* Calculate determinant of a 4x4 matrix. */
    double ans;
    double a1, a2, a3, a4;
    double b1, b2, b3, b4;
    double c1, c2, c3, c4;
    double d1, d2, d3, d4;

    a1 = m->m[0][0]; b1 = m->m[0][1];
    c1 = m->m[0][2]; d1 = m->m[0][3];

    a2 = m->m[1][0]; b2 = m->m[1][1];
    c2 = m->m[1][2]; d2 = m->m[1][3];

    a3 = m->m[2][0]; b3 = m->m[2][1];
    c3 = m->m[2][2]; d3 = m->m[2][3];

    a4 = m->m[3][0]; b4 = m->m[3][1];
    c4 = m->m[3][2]; d4 = m->m[3][3];

    ans = a1 * ctfm41_det3x3( b2,b3,b4, c2,c3,c4, d2,d3,d4 )
        - b1 * ctfm41_det3x3( a2,a3,a4, c2,c3,c4, d2,d3,d4 )
        + c1 * ctfm41_det3x3( a2,a3,a4, b2,b3,b4, d2,d3,d4 )
        - d1 * ctfm41_det3x3( a2,a3,a4, b2,b3,b4, c2,c3,c4 )
    ;

    return ans;
}

ctfm43_adjoint( out, in )
geo_matrix     *out,*in;
{
    /* If Aij is minor determinant of matrix A,		*/
    /* obtained by deleting ith row and jth col, then	*/
    /*            (i+j)					*/
    /* Bij == (-1)     * Aij				*/
    /* is the adjoint of A.				*/
    double a1,a2,a3,a4, b1,b2,b3,b4;
    double c1,c2,c3,c4, d1,d2,d3,d4;

    /* Cache input matrix in variables: */
    a1 = in->m[0][0]; b1 = in->m[0][1];
    c1 = in->m[0][2]; d1 = in->m[0][3];

    a2 = in->m[1][0]; b2 = in->m[1][1];
    c2 = in->m[1][2]; d2 = in->m[1][3];

    a3 = in->m[2][0]; b3 = in->m[2][1];
    c3 = in->m[2][2]; d3 = in->m[2][3];

    a4 = in->m[3][0]; b4 = in->m[3][1];
    c4 = in->m[3][2]; d4 = in->m[3][3];

    /* Row/column labelling reversed since we transpose rows and columns: */
    out->m[0][0] =  ctfm41_det3x3( b2,b3,b4, c2,c3,c4, d2,d3,d4 );
    out->m[1][0] = -ctfm41_det3x3( a2,a3,a4, c2,c3,c4, d2,d3,d4 );
    out->m[2][0] =  ctfm41_det3x3( a2,a3,a4, b2,b3,b4, d2,d3,d4 );
    out->m[3][0] = -ctfm41_det3x3( a2,a3,a4, b2,b3,b4, c2,c3,c4 );

    out->m[0][1] = -ctfm41_det3x3( b1,b3,b4, c1,c3,c4, d1,d3,d4 );
    out->m[1][1] =  ctfm41_det3x3( a1,a3,a4, c1,c3,c4, d1,d3,d4 );
    out->m[2][1] = -ctfm41_det3x3( a1,a3,a4, b1,b3,b4, d1,d3,d4 );
    out->m[3][1] =  ctfm41_det3x3( a1,a3,a4, b1,b3,b4, c1,c3,c4 );

    out->m[0][2] =  ctfm41_det3x3( b1,b2,b4, c1,c2,c4, d1,d2,d4 );
    out->m[1][2] = -ctfm41_det3x3( a1,a2,a4, c1,c2,c4, d1,d2,d4 );
    out->m[2][2] =  ctfm41_det3x3( a1,a2,a4, b1,b2,b4, d1,d2,d4 );
    out->m[3][2] = -ctfm41_det3x3( a1,a2,a4, b1,b2,b4, c1,c2,c4 );

    out->m[0][3] = -ctfm41_det3x3( b1,b2,b3, c1,c2,c3, d1,d2,d3 );
    out->m[1][3] =  ctfm41_det3x3( a1,a2,a3, c1,c2,c3, d1,d2,d3 );
    out->m[2][3] = -ctfm41_det3x3( a1,a2,a3, b1,b2,b3, d1,d2,d3 );
    out->m[3][3] =  ctfm41_det3x3( a1,a2,a3, b1,b2,b3, c1,c2,c3 );
}

ctfm44_Invert_Matrix( out, in ) /* Called from xcmr.c too... */
geo_matrix           *out,*in;
{
    int i,j;
    double det, det4x4();
    double det_inv;

    /* Calculate the adjoint matrix: */
    ctfm43_adjoint( out, in );

    /* Check 4x4 determinant -- if zero, inverse is nonunique: */
    det = ctfm42_det4x4( out );
#ifdef THIS_IS_A_PAIN
    if (fabs(det) < SMALL_NUMBER)   xlfail("non-singular matrix, no inverse!");
#else
    /* Crashing every time the user happens to pass through a singular */
    /* configuration doesn't make for terribly convenient graphics, so */
    /* we return nonsense instead.  Ponder correctness proofs :).      */
    if (fabs(det) < SMALL_NUMBER) {
	ctfm00_Identity(out);
	return;
    }
#endif
    det_inv = 1.0 / det;

    /* Scale adjoint to get the inverse: */
    for     (i = 0;   i < 4;   ++i) {
	for (j = 0;   j < 4;   ++j) {
	    out->m[i][j] *= det_inv;
	}
    }
}

ctfm45_Invert_Matrix( m )
geo_matrix*           m;
{   geo_matrix  out;
    ctfm44_Invert_Matrix( &out, m );
    *m = out;
}

/* }}} */
/* {{{ ctfm47_Transpose_Matrix						*/

ctfm47_Transpose_Matrix( m )
geo_matrix*             m;
{
    int i, j;
    for     (i = 4;   i --> 0; ) {
        for (j = 4;   j --> 0; ) {
	    if (i > j) {
		float f    = m->m[i][j];
		m->m[i][j] = m->m[j][i];
		m->m[j][i] = f;
    }   }   }
}

/* }}} */
/* {{{ ctfm48_Zero_Matrix_Translation_Entries				*/

ctfm48_Zero_Matrix_Translation_Entries( m )
geo_matrix*       		       m;
{
    m->m[3][0] = 0.0;
    m->m[3][1] = 0.0;
    m->m[3][2] = 0.0;
}

/* }}} */
/* {{{ ctfm49_Scale_Matrix_Rows_To_Unit_Length				*/

ctfm49_Scale_Matrix_Rows_To_Unit_Length( m )
geo_matrix*       		         m;
{
    geo_point pt;

    pt.x = m->m[0][0];    pt.y = m->m[0][1];    pt.z = m->m[0][2];
    lib08_Vector_Normalize( &pt );
    m->m[0][0] = pt.x;    m->m[0][1] = pt.y;    m->m[0][2] = pt.z;

    pt.x = m->m[1][0];    pt.y = m->m[1][1];    pt.z = m->m[1][2];
    lib08_Vector_Normalize( &pt );
    m->m[1][0] = pt.x;    m->m[1][1] = pt.y;    m->m[1][2] = pt.z;

    pt.x = m->m[2][0];    pt.y = m->m[2][1];    pt.z = m->m[2][2];
    lib08_Vector_Normalize( &pt );
    m->m[2][0] = pt.x;    m->m[2][1] = pt.y;    m->m[2][2] = pt.z;
}

/* }}} */
/* {{{ ctfm70_Initialize_Put_Rec					*/

void ctfm70_Initialize_Put_Rec(struct ctfm_Put_Rec *r ) {

    r->location_is_valid = FALSE;
    r->angle_is_valid    = FALSE;
    r->diameter_is_valid = FALSE;
    r->target_is_valid   = FALSE;
    r->up_is_valid       = FALSE;
    r->left_is_valid     = FALSE;
    r->roit_is_valid     = FALSE;
    r->top_is_valid      = FALSE;
    r->bot_is_valid      = FALSE;
    r->near_is_valid     = FALSE;
    r->far_is_valid      = FALSE;

}

/* }}} */
/* {{{ ctfm75_Decompose_Matrix  					*/

/* Adaptation of Spencer Thomas's "unmatrix" code in Graphics Gems II.
 * Variables and functions have been modified to use existing Skandha
 * conventions.  (added kph, 1998Oct13)
 */

/* Return the transpose of a matrix (Note that ctfm47_Transpose_Matrix
 * alters the original matrix, which is not how the original code was 
 * designed. 
 */
geo_matrix *ctfm71_Transpose_Matrix_Copy(a, b)
geo_matrix *a, *b;
{
int i, j;
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
			b->m[i][j] = a->m[j][i];
	return(b);
}

/* multiply a hom. point by a matrix and return the transformed point */
ctfm_Vector4 *ctfm72_V4MulPointByMatrix(pin, m, pout)
ctfm_Vector4 *pin, *pout;
geo_matrix *m;
{
	pout->x = (pin->x * m->m[0][0]) + (pin->y * m->m[1][0]) +
		(pin->z * m->m[2][0]) + (pin->w * m->m[3][0]);
	pout->y = (pin->x * m->m[0][1]) + (pin->y * m->m[1][1]) +
		(pin->z * m->m[2][1]) + (pin->w * m->m[3][1]);
	pout->z = (pin->x * m->m[0][2]) + (pin->y * m->m[1][2]) +
		(pin->z * m->m[2][2]) + (pin->w * m->m[3][2]);
	pout->w = (pin->x * m->m[0][3]) + (pin->y * m->m[1][3]) +
		(pin->z * m->m[2][3]) + (pin->w * m->m[3][3]);
        return(pout);
}

/* helper function that acts like Graphics Gems "V3Combine".
 * result = (a * ascl) + (b * bscl) 
 */
geo_point *ctfm73_Combine_Vectors(a, b, result, ascl, bscl)
geo_point *a, *b, *result;
double    ascl, bscl;
{
  lib04_Vector_Interpolate(result, 
			   a, b,        /* the real vectors */
			   b, b,        /* dummy vectors */
			   (float) ascl, 
			   (float) bscl,
			   0, 0);
  return result;
}

/* helper function that acts like Graphics Gems "V3Scale"
 * (*sets* the scale, instead of scaling by a multiple)
 */
geo_point *ctfm74_Set_Vector_Scale(v, newlen)
geo_point *v;
float     newlen;
{
  float len = lib05_Vector_Magnitude(v);
  if (len != 0.0) {
    v->x *= newlen/len;   v->y *= newlen/len;  v->z *= newlen/len;
  }
  return(v);
}


/* Decompose a non-degenerate 4x4 transformation matrix into
 * 	the sequence of transformations that produced it.
 * [Sx][Sy][Sz][Shearx/y][Sx/z][Sz/y][Rx][Ry][Rz][Tx][Ty][Tz][P(x,y,z,w)]
 *
 * The coefficient of each transformation is returned in the corresponding
 * element of the vector tran.
 *
 * Returns 1 upon success, 0 if the matrix is singular.
 */
int
ctfm75_Decompose_Matrix( mat, tran )
geo_matrix *mat;
double tran[16];
{
  register int i, j;
  geo_matrix locmat;
  geo_matrix pmat, invpmat, tinvpmat;
  /* Vector4 type and functions need to be added to the common set. */
  ctfm_Vector4 prhs, psol;
  geo_point row[3], pdum3;

  locmat = *mat;
  /* Normalize the matrix. */
  if ( pmat.m[3][3] = 0 )
    return 0;
  for ( i=0; i<4;i++ )
    for ( j=0; j<4; j++ )
      locmat.m[i][j] /= locmat.m[3][3];
  /* pmat is used to solve for perspective, but it also provides
   * an easy way to test for singularity of the upper 3x3 component.
   */
  pmat = locmat;
  for ( i=0; i<3; i++ )
    pmat.m[i][3] = 0;
  pmat.m[3][3] = 1;

  /*** bug fix of original code (kph, 1998Oct11) ***/
  if ( ctfm42_det4x4(mat) == 0.0 )
    return 0;

  /* First, isolate perspective.  This is the messiest. */
  if ( locmat.m[0][3] != 0 || locmat.m[1][3] != 0 ||
      locmat.m[2][3] != 0 ) {
    /* prhs is the right hand side of the equation. */
    prhs.x = locmat.m[0][3];
    prhs.y = locmat.m[1][3];
    prhs.z = locmat.m[2][3];
    prhs.w = locmat.m[3][3];

    /* Solve the equation by inverting pmat and multiplying
     * prhs by the inverse.  (This is the easiest way, not
     * necessarily the best.)
     * inverse function (and det4x4, above) from the Matrix
     * Inversion gem in the first volume.
     */
    ctfm44_Invert_Matrix( &invpmat, &pmat );
    ctfm71_Transpose_Matrix_Copy( &invpmat, &tinvpmat );
    ctfm72_V4MulPointByMatrix(&prhs, &tinvpmat, &psol);
 
    /* Stuff the answer away. */
    tran[CTFM_U_PERSPX] = psol.x;
    tran[CTFM_U_PERSPY] = psol.y;
    tran[CTFM_U_PERSPZ] = psol.z;
    tran[CTFM_U_PERSPW] = psol.w;
    /* Clear the perspective partition. */
    locmat.m[0][3] = locmat.m[1][3] = locmat.m[2][3] = 0;
    locmat.m[3][3] = 1;
  } else		/* No perspective. */
    tran[CTFM_U_PERSPX] = tran[CTFM_U_PERSPY] = tran[CTFM_U_PERSPZ] =
      tran[CTFM_U_PERSPW] = 0;

  /* Next take care of translation (easy). */
  for ( i=0; i<3; i++ ) {
    tran[CTFM_U_TRANSX + i] = locmat.m[3][i];
    locmat.m[3][i] = 0;
  }

  /* Now get scale and shear. */
  for ( i=0; i<3; i++ ) {
    row[i].x = locmat.m[i][0];
    row[i].y = locmat.m[i][1];
    row[i].z = locmat.m[i][2];
  }

  /* Compute X scale factor and normalize first row. */
  tran[CTFM_U_SCALEX] = lib05_Vector_Magnitude(&row[0]);
  row[0] = *ctfm74_Set_Vector_Scale(&row[0], 1.0);

  /* Compute XY shear factor and make 2nd row orthogonal to 1st. */
  tran[CTFM_U_SHEARXY] = lib03_Vector_Dot_Product(&row[0], &row[1]);
  (void)ctfm73_Combine_Vectors(&row[1], &row[0], &row[1], 
			       1.0, -tran[CTFM_U_SHEARXY]);

  /* Now, compute Y scale and normalize 2nd row. */
  tran[CTFM_U_SCALEY] = lib05_Vector_Magnitude(&row[1]);
  ctfm74_Set_Vector_Scale(&row[1], 1.0);
  tran[CTFM_U_SHEARXY] /= tran[CTFM_U_SCALEY];

  /* Compute XZ and YZ shears, orthogonalize 3rd row. */
  tran[CTFM_U_SHEARXZ] = lib03_Vector_Dot_Product(&row[0], &row[2]);
  (void)ctfm73_Combine_Vectors(&row[2], &row[0], &row[2], 
			       1.0, -tran[CTFM_U_SHEARXZ]);
  tran[CTFM_U_SHEARYZ] = lib03_Vector_Dot_Product(&row[1], &row[2]);
  (void)ctfm73_Combine_Vectors(&row[2], &row[1], &row[2], 
			       1.0, -tran[CTFM_U_SHEARYZ]);

  /* Next, get Z scale and normalize 3rd row. */
  tran[CTFM_U_SCALEZ] = lib05_Vector_Magnitude(&row[2]);
  ctfm74_Set_Vector_Scale(&row[2], 1.0);
  tran[CTFM_U_SHEARXZ] /= tran[CTFM_U_SCALEZ];
  tran[CTFM_U_SHEARYZ] /= tran[CTFM_U_SCALEZ];
 
  /* At this point, the matrix (in rows[]) is orthonormal.
   * Check for a coordinate system flip.  If the determinant
   * is -1, then negate the matrix and the scaling factors.
   */
  if ( lib03_Vector_Dot_Product( &row[0], 
				lib00_Vector_Cross_Product(&pdum3,
							   &row[1], 
							   &row[2]) ) < 0 )
    for ( i = 0; i < 3; i++ ) {
      tran[CTFM_U_SCALEX+i] *= -1;
      row[i].x *= -1;
      row[i].y *= -1;
      row[i].z *= -1;
    }
 
  /* Now, get the rotations out, as described in the gem. */
  /* 
   * NOTE:  Skandha uses a left-handed coordinate system, but the
   * original code appeared to work for a right-handed system.
   * Therefore the rotation angles have all been negated.
   * (kph, 1998Oct13)
   */

  tran[CTFM_U_ROTATEY] = - asin(-row[0].z);
  if ( cos(tran[CTFM_U_ROTATEY]) != 0 ) {
    tran[CTFM_U_ROTATEX] = - atan2(row[1].z, row[2].z);
    tran[CTFM_U_ROTATEZ] = - atan2(row[0].y, row[0].x);
  } else {
    tran[CTFM_U_ROTATEX] = - atan2(row[1].x, row[1].y);
    tran[CTFM_U_ROTATEZ] = 0;
  }
  /* All done! */
  return 1;
}

/* }}} */


/* ctfm50's taken for fill-ins. */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
