/* {{{ x01v.h -- bit vectors.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Jun13
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_x01v;

extern LVAL x01v03_Show_Msg();
extern LVAL x01v04_Aref_Msg();
extern LVAL x01v06_Setf_Msg();
extern LVAL x01v08_Copy_Msg();
extern LVAL x01v21_AdjustArray_Msg();
extern LVAL x01v24_RowMajorAref_Msg();
extern LVAL x01v26_RowMajorSetf_Msg();
extern LVAL x01v29_Equalp_Msg();
extern LVAL x01v32_Fill_Pointer_Msg();
extern LVAL x01v34_Vector_Push_Msg();
extern LVAL x01v35_Vector_Push_Extend_Msg();
extern LVAL x01v36_Vector_Pop_Msg();
extern LVAL x01v37_Setf_Fill_Pointer_Msg();

extern LVAL x01v00_Is_New();
#endif

#ifdef MODULE_XLFTAB_C_GLOBALS
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	NULL,	x01v00_Is_New			)
DEFINE_SUBR(	NULL,	x01v03_Show_Msg			)
DEFINE_SUBR(	NULL,	x01v04_Aref_Msg			)
DEFINE_SUBR(	NULL,	x01v06_Setf_Msg			)
DEFINE_SUBR(	NULL,	x01v08_Copy_Msg			)
DEFINE_SUBR(	NULL,	x01v21_AdjustArray_Msg		)
DEFINE_SUBR(	NULL,	x01v24_RowMajorAref_Msg		)
DEFINE_SUBR(	NULL,	x01v26_RowMajorSetf_Msg		)
DEFINE_SUBR(	NULL,	x01v29_Equalp_Msg		)
DEFINE_SUBR(	NULL,	x01v32_Fill_Pointer_Msg		)
DEFINE_SUBR(	NULL,	x01v34_Vector_Push_Msg		)
DEFINE_SUBR(	NULL,	x01v35_Vector_Push_Extend_Msg	)
DEFINE_SUBR(	NULL,	x01v36_Vector_Pop_Msg		)
DEFINE_SUBR(	NULL,	x01v37_Setf_Fill_Pointer_Msg	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_x01v;

LOCAL struct x01v_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} x01v_table[] = {
    {	":ISNEW",		x01v00_Is_New			},
    {	":SHOW",		x01v03_Show_Msg			},
    {	":AREF",		x01v04_Aref_Msg			},
    {	":SETF",		x01v06_Setf_Msg			},
    {	":COPY",		x01v08_Copy_Msg			},
    {	":ADJUST-ARRAY",	x01v21_AdjustArray_Msg		},
    {	":ROW-MAJOR-AREF",	x01v24_RowMajorAref_Msg		},
    {	":ROW-MAJOR-SETF",	x01v26_RowMajorSetf_Msg		},
    {	":EQUALP",		x01v29_Equalp_Msg		},
    {	":FILL-POINTER",	x01v32_Fill_Pointer_Msg		},
    {	":VECTOR-PUSH",		x01v34_Vector_Push_Msg		},
    {	":VECTOR-PUSH-EXTEND",	x01v35_Vector_Push_Extend_Msg	},
    {	":VECTOR-POP",		x01v36_Vector_Pop_Msg		},
    {	":SETF-FILL-POINTER",	x01v37_Setf_Fill_Pointer_Msg	},

    {	NULL,			NULL				}
};
#endif

#ifdef MODULE_XLOBJ_C_OBSYMBOLS
    lv_x01v = getvalue(xlenter("CLASS-BIT-ARRAY"));
#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_x01v = xgbj58_Create_Class("CLASS-BIT-ARRAY",lv_xsry);
    xgbj56_Enter_Messages(lv_x01v,x01v_table);
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
