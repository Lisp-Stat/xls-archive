/* {{{ xthl.c -- thinglists.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jun29, from xthl.c stuff.
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

/* {{{ --- history ---							*/

/* 95Oct02 jsp: Added :[cursor|popup]-bitplanes[-erase] support.        */
/* 95Sep29 jsp: Added :overlay-bitplanes-erase support.                 */
/* 95Jul25 jsp: Init_Tri_Rec was missing lv_use_normals, lv_use_colors. */
/* 95Apr11 jsp: Arrays weren't respecting :per-frame-hook.		*/
/* 92Jun29 jsp: Created, from xthl.c stuff.				*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"

#include "geo.h"
#include "csry.h"
#include "clgt.h"
#include "cmdl.h"
#include "cmtl.h"
#include "ctxr.h"
#include "cthl.h"
#include "ctfm.h"
#include "cgrl.h"
#include "c01v.h"
#include "cu8v.h"
#include "c32v.h"
#include "cflv.h"
#include "cf8v.h"
#include "cf6v.h"

extern LVAL xsendmsg0(); 
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();

/* external variables */
extern LVAL obarray,s_unbound;
extern LVAL xlenv,xlfenv,xldenv;

extern LVAL k_on_facets;
extern LVAL k_on_points;
extern LVAL k_use_normals;
extern LVAL k_use_colors;
extern LVAL k_background;
extern LVAL k_dropbackfaces;
extern LVAL k_facetif;
extern LVAL k_facetrelation;
extern LVAL k_fixlightsonobject;
extern LVAL k_foreground;
extern LVAL k_invisible;
extern LVAL k_lightingmodel;
extern LVAL k_lights;
extern LVAL k_material;
extern LVAL k_pickas;
extern LVAL k_pixelrelation;
extern LVAL k_pointif;
extern LVAL k_pointrelation;
extern LVAL k_redraw;
extern LVAL k_solid;
extern LVAL k_transform;
extern LVAL k_deselecthook;
extern LVAL k_downclickhook;
extern LVAL k_draghook;
extern LVAL k_widget;
extern LVAL k_facet0;
extern LVAL k_facet1;
extern LVAL k_facet2;
extern LVAL k_facet3;
extern LVAL k_pointblue;
extern LVAL k_pointgreen;
extern LVAL k_pointnormalx;
extern LVAL k_pointnormaly;
extern LVAL k_pointnormalz;
extern LVAL k_texture;
extern LVAL k_pointtextureu;
extern LVAL k_pointtexturev;
extern LVAL k_facettextureu0;
extern LVAL k_facettexturev0;
extern LVAL k_facettextureu1;
extern LVAL k_facettexturev1;
extern LVAL k_facettextureu2;
extern LVAL k_facettexturev2;
extern LVAL k_facettextureu3;
extern LVAL k_facettexturev3;
extern LVAL k_facetneighbor0;
extern LVAL k_facetneighbor1;
extern LVAL k_facetneighbor2;
extern LVAL k_facetneighbor3;
extern LVAL k_pointred;
extern LVAL k_pointx;
extern LVAL k_pointy;
extern LVAL k_pointz;
extern LVAL k_reselecthook;
extern LVAL k_selecthook;
extern LVAL k_upclickhook;
extern LVAL s_arraylist;
extern LVAL k_facet2;
extern LVAL k_facet3;
extern LVAL k_facetblue;
extern LVAL k_facetgreen;
extern LVAL k_facetnormalx;
extern LVAL k_facetnormaly;
extern LVAL k_facetnormalz;
extern LVAL k_facetred;
extern LVAL k_pixelblue;
extern LVAL k_pixelgreen;
extern LVAL k_pixelred;
extern LVAL k_pixeldepth;
extern LVAL k_thing;
extern LVAL k_whichbitplanes;
extern LVAL k_rgbbitplanes;
extern LVAL k_overlaybitplanes;
extern LVAL k_overlaybitplaneserase;
extern LVAL k_cursorbitplanes;
extern LVAL k_cursorbitplaneserase;
extern LVAL k_popupbitplanes;
extern LVAL k_popupbitplaneserase;


float*          xthlC3_Check_PLen();
float*          xthlC4_Check_FLen();
unsigned char** xthlCa_Check_RLen();


/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */

/* {{{ xthl07_Init_Want_Args						*/

void xthl07_Init_Want_Args( r )
struct xthl06_Want_Rec     *r;
{
    extern LVAL true;

    /* We use a fn mostly because NIL isn't a constant,  */
    /* and in particular can't be counted on to be NULL: */
    r->want_point_normals = 0;
    r->want_facet_normals = 0;
    r->want_point_colors = 0;
    r->want_facet_colors = 0;
    r->want_point_textures = 0;
    r->want_facet_textures = 0;
    r->want_facet_neighbors = 0;
    r->redraw = TRUE;
    r->lv_use_colors = true;
    r->lv_use_normals = true;
    r->lv_pickas = NIL;
    r->lv_pointif = NIL;
    r->lv_facetif = NIL;
    r->lv_dropbackfaces = NIL;
    r->lv_fixlightsonobject = NIL;
    r->lv_lights = NIL;
    r->lv_lightingmodel = NIL;
    r->lv_material = NIL;
    r->lv_transform = NIL;
    r->lv_widget = NIL;
    r->lv_downclickhook = NIL;
    r->lv_draghook = NIL;
    r->lv_upclickhook = NIL;
    r->lv_reselecthook = NIL;
    r->lv_selecthook = NIL;
    r->lv_deselecthook = NIL;
    r->lv_whichbitplanes = NIL;
}

/* }}} */
/* {{{ xthl08_Parse_Want_Args						*/

xthl08_Parse_Want_Args( r )
struct xthl06_Want_Rec *r;
{
    extern LVAL k_wantpointnormals;
    extern LVAL k_wantfacetnormals;
    extern LVAL k_wantpointcolors;
    extern LVAL k_wantfacetcolors;
    extern LVAL k_wantpointtextures;
    extern LVAL k_wantfacettextures;
    extern LVAL k_wantfacetneighbors;
    xthl07_Init_Want_Args( r );
    while (moreargs()) {
        LVAL       key = xlgasymbol();
        if        (key == k_wantpointnormals) {

	    r->want_point_normals = !null(xlgetarg());

        } else if (key == k_wantpointcolors) {

	    r->want_point_colors = !null(xlgetarg());

        } else if (key == k_wantfacetnormals) {

	    r->want_facet_normals = !null(xlgetarg());

        } else if (key == k_wantfacetcolors) {

	    r->want_facet_colors = !null(xlgetarg());

        } else if (key == k_wantpointtextures) {

	    r->want_point_textures = !null(xlgetarg());

        } else if (key == k_wantfacettextures) {

	    r->want_facet_textures = !null(xlgetarg());

        } else if (key == k_wantfacetneighbors) {

	    r->want_facet_neighbors = !null(xlgetarg());

        } else if (key == k_dropbackfaces) {

	    r->lv_dropbackfaces = xlgetarg();

        } else if (key == k_fixlightsonobject) {

	    r->lv_fixlightsonobject = xlgetarg();

        } else if (key == k_lights) {

	    r->lv_lights = xlgacons();

        } else if (key == k_lightingmodel) {

	    r->lv_lightingmodel = xlgetarg();/*xmdl01_Get_A_XMDL() or xlgasymbol()*/

        } else if (key == k_whichbitplanes) {

	    r->lv_whichbitplanes = xlgasymbol();

        } else if (key == k_pickas) {

	    r->lv_pickas = xlgasymbol();

        } else if (key == k_use_colors) {

#ifdef NIL_IS_NOT_A_SYMBOL /* ???!! */
	    r->lv_use_colors = xlgasymbol();
#else
	    r->lv_use_colors = xlgetarg();
#endif

        } else if (key == k_use_normals) {

#ifdef NIL_IS_NOT_A_SYMBOL /* ???!! */
	    r->lv_use_normals = xlgasymbol();
#else
	    r->lv_use_normals = xlgetarg();
#endif

        } else if (key == k_pointif) {

	    r->lv_pointif = xlgasymbol();

        } else if (key == k_facetif) {

	    r->lv_facetif = xlgasymbol();

        } else if (key == k_material) {

	    r->lv_material = xlgetarg(); /* xmtl01_Get_A_XMTL() or xlgasymbol()*/

        } else if (key == k_transform) {

	    r->lv_transform = xlgetarg(); /*xtfm01_Get_A_XTFM() | xlgasymbol()*/

        } else if (key == k_widget) {

	    r->lv_widget = xlgagobject();

        } else if (key == k_downclickhook) {

	    xthlF2_Check_hookFns( r->lv_downclickhook = xlgetarg() );

        } else if (key == k_draghook) {

	    xthlF2_Check_hookFns( r->lv_draghook = xlgetarg() );

        } else if (key == k_upclickhook) {

	    xthlF2_Check_hookFns( r->lv_upclickhook = xlgetarg() );

        } else if (key == k_reselecthook) {

	    xthlF2_Check_hookFns( r->lv_reselecthook = xlgetarg() );

        } else if (key == k_selecthook) {

	    xthlF2_Check_hookFns( r->lv_selecthook = xlgetarg() );

        } else if (key == k_deselecthook) {

	    xthlF2_Check_hookFns( r->lv_deselecthook = xlgetarg() );

        } else if (key == k_redraw) {

	   r->redraw = !null(xlgetarg());

	} else {
            xlerror( "Expected keyword", key );
    }   }
}

/* }}} */
/* {{{ xthl09_MakePointGrl_Fn						*/

LVAL xthl02_Make_Point_Grl( r, size )
struct xthl06_Want_Rec     *r;
int			       size;
{
    extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xu8v;
    extern LVAL lv_x32v;
    extern LVAL lv_xflv;
    extern LVAL lv_xf8v;

    extern LVAL k_pointx;
    extern LVAL k_pointy;
    extern LVAL k_pointz;

    extern LVAL k_pointnormalx;
    extern LVAL k_pointnormaly;
    extern LVAL k_pointnormalz;

    extern LVAL k_pointtextureu;
    extern LVAL k_pointtexturev;

    extern LVAL k_pointred;
    extern LVAL k_pointgreen;
    extern LVAL k_pointblue;

    extern LVAL k_setarray;

    extern LVAL k_show;

    LVAL lv_shape;
    LVAL lv_grl;

    LVAL lv_pointx;
    LVAL lv_pointy;
    LVAL lv_pointz;

    LVAL lv_pointred;
    LVAL lv_pointgreen;
    LVAL lv_pointblue;

    LVAL lv_pointnormalx;
    LVAL lv_pointnormaly;
    LVAL lv_pointnormalz;

    LVAL lv_pointtextureu;
    LVAL lv_pointtexturev;

    int        toProt = 13;
    xlstkcheck(toProt);

    xlsave(lv_shape     );
    xlsave(lv_grl       );

    xlsave(lv_pointx    );
    xlsave(lv_pointy    );
    xlsave(lv_pointz    );

    xlsave(lv_pointred  );
    xlsave(lv_pointgreen);
    xlsave(lv_pointblue );

    xlsave(lv_pointnormalx    );
    xlsave(lv_pointnormaly    );
    xlsave(lv_pointnormalz    );

    xlsave(lv_pointtextureu   );
    xlsave(lv_pointtexturev   );

    /* Create our point relation: */
    lv_shape = cvfixnum(size);
    lv_grl   = xsendmsg1( lv_xgrl, k_new, lv_shape );

    /* Create point-x/y/z arrays to go in point relation: */
    lv_pointx = xsendmsg1( lv_xflv, k_new, lv_shape );
    lv_pointy = xsendmsg1( lv_xflv, k_new, lv_shape );
    lv_pointz = xsendmsg1( lv_xflv, k_new, lv_shape );


    /* Insert point-x/y/z arrays in point relation: */
    xsendmsg2( lv_grl, k_setarray, k_pointx, lv_pointx );
    xsendmsg2( lv_grl, k_setarray, k_pointy, lv_pointy );
    xsendmsg2( lv_grl, k_setarray, k_pointz, lv_pointz );



    if (r->want_point_colors) {

	/* Create point-red/green/blue arrays to go in point relation: */
	lv_pointred   = xsendmsg1( lv_xf8v, k_new, lv_shape );
	lv_pointgreen = xsendmsg1( lv_xf8v, k_new, lv_shape );
	lv_pointblue  = xsendmsg1( lv_xf8v, k_new, lv_shape );

	/* Insert point-red/green/blue arrays in point relation: */
	xsendmsg2( lv_grl, k_setarray, k_pointred  , lv_pointred   );
	xsendmsg2( lv_grl, k_setarray, k_pointgreen, lv_pointgreen );
	xsendmsg2( lv_grl, k_setarray, k_pointblue , lv_pointblue  );
    }

    if (r->want_point_normals) {

	/* Create point-normal-x/y/z arrays to go in point relation: */
	lv_pointnormalx = xsendmsg1( lv_xflv, k_new, lv_shape );
	lv_pointnormaly = xsendmsg1( lv_xflv, k_new, lv_shape );
	lv_pointnormalz = xsendmsg1( lv_xflv, k_new, lv_shape );

	/* Insert point-normal-x/y/z arrays in point relation: */
	xsendmsg2( lv_grl, k_setarray, k_pointnormalx, lv_pointnormalx );
	xsendmsg2( lv_grl, k_setarray, k_pointnormaly, lv_pointnormaly );
	xsendmsg2( lv_grl, k_setarray, k_pointnormalz, lv_pointnormalz );
    }

    if (r->want_point_textures) {

	/* Create point-normal-x/y/z arrays to go in point relation: */
	lv_pointtextureu = xsendmsg1( lv_xflv, k_new, lv_shape );
	lv_pointtexturev = xsendmsg1( lv_xflv, k_new, lv_shape );

	/* Insert point-normal-x/y/z arrays in point relation: */
	xsendmsg2( lv_grl, k_setarray, k_pointtextureu, lv_pointtextureu );
	xsendmsg2( lv_grl, k_setarray, k_pointtexturev, lv_pointtexturev );
    }

    xlpopn(toProt);

    return lv_grl;
}
LVAL  xthl09_MakePointGrl_Fn()
{   struct xthl06_Want_Rec         r     ;
    xthl08_Parse_Want_Args(       &r    );
    return xthl02_Make_Point_Grl( &r, 0 );
}

/* }}} */
/* {{{ xthl15_MakeGrlOfLines_Fn						*/

LVAL xthl12_Make_Grl_Of_Facets( r, n )
struct xthl06_Want_Rec         *r   ;
int			           n;
{   extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xu8v;
    extern LVAL lv_x32v;
    extern LVAL lv_xflv;
    extern LVAL lv_xf8v;

    extern LVAL k_facet0;
    extern LVAL k_facet1;
    extern LVAL k_facet2;
    extern LVAL k_facet3;

    extern LVAL k_facetred;
    extern LVAL k_facetgreen;
    extern LVAL k_facetblue;

    extern LVAL k_facetnormalx;
    extern LVAL k_facetnormaly;
    extern LVAL k_facetnormalz;

    extern LVAL k_facettextureu0;
    extern LVAL k_facettexturev0;
    extern LVAL k_facettextureu1;
    extern LVAL k_facettexturev1;
    extern LVAL k_facettextureu2;
    extern LVAL k_facettexturev2;
    extern LVAL k_facettextureu3;
    extern LVAL k_facettexturev3;

    extern LVAL k_facetneighbor0;
    extern LVAL k_facetneighbor1;
    extern LVAL k_facetneighbor2;
    extern LVAL k_facetneighbor3;

    extern LVAL k_setarray;

    extern LVAL k_show;

    LVAL lv_shape;
    LVAL lv_grl;

    LVAL lv_facet0;
    LVAL lv_facet1;
    LVAL lv_facet2;
    LVAL lv_facet3;

    LVAL lv_facetred;
    LVAL lv_facetgreen;
    LVAL lv_facetblue;

    LVAL lv_facetnormalx;
    LVAL lv_facetnormaly;
    LVAL lv_facetnormalz;

    LVAL lv_facettextureu0;
    LVAL lv_facettexturev0;
    LVAL lv_facettextureu1;
    LVAL lv_facettexturev1;
    LVAL lv_facettextureu2;
    LVAL lv_facettexturev2;
    LVAL lv_facettextureu3;
    LVAL lv_facettexturev3;

    LVAL lv_facetneighbor0;
    LVAL lv_facetneighbor1;
    LVAL lv_facetneighbor2;
    LVAL lv_facetneighbor3;

    int        toProt = 24;
    xlstkcheck(toProt);

    xlsave(lv_shape     );
    xlsave(lv_grl       );

    xlsave(lv_facet0    );
    xlsave(lv_facet1    );
    xlsave(lv_facet2    );
    xlsave(lv_facet3    );

    xlsave(lv_facetred  );
    xlsave(lv_facetgreen);
    xlsave(lv_facetblue );

    xlsave(lv_facetnormalx    );
    xlsave(lv_facetnormaly    );
    xlsave(lv_facetnormalz    );


    xlsave(lv_facettextureu0  );    xlsave(lv_facettexturev0  );
    xlsave(lv_facettextureu1  );    xlsave(lv_facettexturev1  );
    xlsave(lv_facettextureu2  );    xlsave(lv_facettexturev2  );
    xlsave(lv_facettextureu3  );    xlsave(lv_facettexturev3  );

    xlsave(lv_facetneighbor0  );
    xlsave(lv_facetneighbor1  );
    xlsave(lv_facetneighbor2  );
    xlsave(lv_facetneighbor3  );

    /* Create our facet relation: */
    lv_shape = cvfixnum(0);
    lv_grl		= xsendmsg1( lv_xgrl, k_new, lv_shape );

    /* Create facet-0/1/2/3 arrays to go in facet relation: */
    if (n > 0)   lv_facet0 = xsendmsg1( lv_x32v, k_new, lv_shape );
    if (n > 1)   lv_facet1 = xsendmsg1( lv_x32v, k_new, lv_shape );
    if (n > 2)   lv_facet2 = xsendmsg1( lv_x32v, k_new, lv_shape );
    if (n > 3)   lv_facet3 = xsendmsg1( lv_x32v, k_new, lv_shape );

    /* Insert facet-0/1/2/3 arrays in facet relation: */
    if (n > 0)   xsendmsg2( lv_grl, k_setarray, k_facet0, lv_facet0 );
    if (n > 1)   xsendmsg2( lv_grl, k_setarray, k_facet1, lv_facet1 );
    if (n > 2)   xsendmsg2( lv_grl, k_setarray, k_facet2, lv_facet2 );
    if (n > 3)   xsendmsg2( lv_grl, k_setarray, k_facet3, lv_facet3 );



    if (r->want_facet_colors) {

	/* Create facet-red/green/blue arrays to go in facet relation: */
	lv_facetred   = xsendmsg1( lv_xf8v, k_new, lv_shape );
	lv_facetgreen = xsendmsg1( lv_xf8v, k_new, lv_shape );
	lv_facetblue  = xsendmsg1( lv_xf8v, k_new, lv_shape );

	/* Insert facet-red/green/blue arrays in facet relation: */
	xsendmsg2( lv_grl, k_setarray, k_facetred  , lv_facetred   );
	xsendmsg2( lv_grl, k_setarray, k_facetgreen, lv_facetgreen );
	xsendmsg2( lv_grl, k_setarray, k_facetblue , lv_facetblue  );
    }

    if (r->want_facet_normals) {

	/* Create facet-normal-x/y/z arrays to go in facet relation: */
	lv_facetnormalx = xsendmsg1( lv_xflv, k_new, lv_shape );
	lv_facetnormaly = xsendmsg1( lv_xflv, k_new, lv_shape );
	lv_facetnormalz = xsendmsg1( lv_xflv, k_new, lv_shape );

	/* Insert facet-normal-x/y/z arrays in facet relation: */
	xsendmsg2( lv_grl, k_setarray, k_facetnormalx, lv_facetnormalx );
	xsendmsg2( lv_grl, k_setarray, k_facetnormaly, lv_facetnormaly );
	xsendmsg2( lv_grl, k_setarray, k_facetnormalz, lv_facetnormalz );
    }
    if (r->want_facet_textures) {

	/* Create facet-texture-x/y-0/1/2/3 arrays to go in facet relation: */
	if (n > 0) lv_facettextureu0 = xsendmsg1( lv_xflv, k_new, lv_shape );
	if (n > 0) lv_facettexturev0 = xsendmsg1( lv_xflv, k_new, lv_shape );
	if (n > 1) lv_facettextureu1 = xsendmsg1( lv_xflv, k_new, lv_shape );
	if (n > 1) lv_facettexturev1 = xsendmsg1( lv_xflv, k_new, lv_shape );
	if (n > 2) lv_facettextureu2 = xsendmsg1( lv_xflv, k_new, lv_shape );
	if (n > 2) lv_facettexturev2 = xsendmsg1( lv_xflv, k_new, lv_shape );
	if (n > 3) lv_facettextureu3 = xsendmsg1( lv_xflv, k_new, lv_shape );
	if (n > 3) lv_facettexturev3 = xsendmsg1( lv_xflv, k_new, lv_shape );

	/* Insert facet-texture-x/y-0/1/2/3 arrays in facet relation: */
	if(n>0)xsendmsg2(lv_grl,k_setarray,k_facettextureu0,lv_facettextureu0);
	if(n>0)xsendmsg2(lv_grl,k_setarray,k_facettexturev0,lv_facettexturev0);
	if(n>1)xsendmsg2(lv_grl,k_setarray,k_facettextureu1,lv_facettextureu1);
	if(n>1)xsendmsg2(lv_grl,k_setarray,k_facettexturev1,lv_facettexturev1);
	if(n>2)xsendmsg2(lv_grl,k_setarray,k_facettextureu2,lv_facettextureu2);
	if(n>2)xsendmsg2(lv_grl,k_setarray,k_facettexturev2,lv_facettexturev2);
	if(n>3)xsendmsg2(lv_grl,k_setarray,k_facettextureu3,lv_facettextureu3);
	if(n>3)xsendmsg2(lv_grl,k_setarray,k_facettexturev3,lv_facettexturev3);
    }

    if (r->want_facet_neighbors) {

	/* Create facet-neighbor-0/1/2/3 arrays to go in facet relation: */
	if (n > 0) lv_facetneighbor0 = xsendmsg1( lv_x32v, k_new, lv_shape );
	if (n > 1) lv_facetneighbor1 = xsendmsg1( lv_x32v, k_new, lv_shape );
	if (n > 2) lv_facetneighbor2 = xsendmsg1( lv_x32v, k_new, lv_shape );
	if (n > 3) lv_facetneighbor3 = xsendmsg1( lv_x32v, k_new, lv_shape );

	/* Insert facet-neighbor-0/1/2/3 arrays in facet relation: */
	if(n>0)xsendmsg2(lv_grl,k_setarray,k_facetneighbor0,lv_facetneighbor0);
	if(n>1)xsendmsg2(lv_grl,k_setarray,k_facetneighbor1,lv_facetneighbor1);
	if(n>2)xsendmsg2(lv_grl,k_setarray,k_facetneighbor2,lv_facetneighbor2);
	if(n>3)xsendmsg2(lv_grl,k_setarray,k_facetneighbor3,lv_facetneighbor3);
    }

    xlpopn(toProt);

    return lv_grl;
}
LVAL xthl15_MakeGrlOfLines_Fn()
{   struct xthl06_Want_Rec r;
    xthl08_Parse_Want_Args( &r );
    return xthl12_Make_Grl_Of_Facets( &r, 2 );
}

/* }}} */
/* {{{ xthl16_MakeGrlOfTriangles_Fn					*/

LVAL xthl16_MakeGrlOfTriangles_Fn()
{   struct xthl06_Want_Rec r;
    xthl08_Parse_Want_Args( &r );
    return xthl12_Make_Grl_Of_Facets( &r, 3 );
}

/* }}} */
/* {{{ xthl17_MakeGrlOfRectangles_Fn					*/

LVAL xthl17_MakeGrlOfRectangles_Fn()
{   struct xthl06_Want_Rec             r     ;
    xthl08_Parse_Want_Args(           &r    );
    return xthl12_Make_Grl_Of_Facets( &r, 4 );
}

/* }}} */
/* {{{ xthl29_MakeImageGrl_Fn						*/

LVAL
xthl28_MakeImageGrl(
   int  rows,
   int  cols,
   LVAL lv_justlike,
   int  want_red,
   int  want_green,
   int  want_blue,
   int  want_depth
) {
    extern LVAL k_new;
    extern LVAL lv_xgrl;
    extern LVAL lv_xf8v;
    extern LVAL lv_xflv;

    extern LVAL k_pixelred;
    extern LVAL k_pixelgreen;
    extern LVAL k_pixelblue;
    extern LVAL k_pixeldepth;

    extern LVAL k_setarray;

    extern LVAL k_show;

    LVAL lv_shape;
    LVAL lv_grl;

    LVAL lv_red;
    LVAL lv_grn;
    LVAL lv_blu;
    LVAL lv_dep;
    int        toProt = 7;
    xlstkcheck(toProt);
    xlsave(lv_shape );
    xlsave(lv_grl   );
    xlsave(lv_red   );
    xlsave(lv_grn   );
    xlsave(lv_blu   );
    xlsave(lv_dep   );
    xlprot1(lv_justlike);

    /* Create our pixel relation: */
    lv_shape = cons(cvfixnum(cols),     NIL);
    lv_shape = cons(cvfixnum(rows),lv_shape);
    lv_grl		= xsendmsg1( lv_xgrl, k_new, lv_shape );

#ifdef OLD
    if (xgrlp(lv_justlike)) {
	LVAL*p = xgrl13_pArrayList( lv_justlike );

	want_red   = xthl74_GetProp(p, k_pixelred  , NULL,1 ) != NULL;
	want_green = xthl74_GetProp(p, k_pixelgreen, NULL,1 ) != NULL;
	want_blue  = xthl74_GetProp(p, k_pixelblue , NULL,1 ) != NULL;
	want_depth = xthl74_GetProp(p, k_pixeldepth, NULL,1 ) != NULL;
    }

    if (want_red  ) {
	lv_red = xsendmsg1( lv_xf8v, k_new, lv_shape );
	xsendmsg2( lv_grl, k_setarray, k_pixelred  , lv_red );
    }
    if (want_green) {
	lv_grn = xsendmsg1( lv_xf8v, k_new, lv_shape );
	xsendmsg2( lv_grl, k_setarray, k_pixelgreen, lv_grn );
    }
    if (want_blue ) {
	lv_blu = xsendmsg1( lv_xf8v, k_new, lv_shape );
	xsendmsg2( lv_grl, k_setarray, k_pixelblue , lv_blu );
    }
    if (want_depth) {
	lv_dep = xsendmsg1( lv_xf8v, k_new, lv_shape );
	xsendmsg2( lv_grl, k_setarray, k_pixeldepth, lv_dep );
    }
#else
    if (!xgrlp(lv_justlike)) {
	if (want_red  ) {
	    lv_red = xsendmsg1( lv_xf8v, k_new, lv_shape );
	    xsendmsg2( lv_grl, k_setarray, k_pixelred  , lv_red );
	}
	if (want_green) {
	    lv_grn = xsendmsg1( lv_xf8v, k_new, lv_shape );
	    xsendmsg2( lv_grl, k_setarray, k_pixelgreen, lv_grn );
	}
	if (want_blue ) {
	    lv_blu = xsendmsg1( lv_xf8v, k_new, lv_shape );
	    xsendmsg2( lv_grl, k_setarray, k_pixelblue , lv_blu );
	}
	if (want_depth) {
	    lv_dep = xsendmsg1( lv_xf8v, k_new, lv_shape );
	    xsendmsg2( lv_grl, k_setarray, k_pixeldepth, lv_dep );
	}
    } else {
	LVAL*lst = xgrl13_pArrayList( lv_justlike );
	LVAL p;
	for (p = *lst; consp(p) && consp(cdr(p)); p = cdr(cdr(p))) {
	    LVAL key = car(p);
	    LVAL val = car(cdr(p));
	    if (xf8vp(val)) {
		LVAL lv = xsendmsg1( lv_xf8v, k_new, lv_shape );
		xsendmsg2( lv_grl, k_setarray, key, lv );
	    } else if (xflvp( val )) {
		LVAL lv = xsendmsg1( lv_xflv, k_new, lv_shape );
		xsendmsg2( lv_grl, k_setarray, key, lv );
	    }
	}
    }

#endif

    xlpopn(toProt);

    return lv_grl;
}
LVAL xthl29_MakeImageGrl_Fn()
{
    extern LVAL k_want;
    extern LVAL k_justlike;
    LVAL lv_justlike = NIL;
    LVAL lv_shape = xlgacons();
    int  rows, cols;
    int  seen_want  = FALSE;
    int  want_red   = TRUE;
    int  want_green = TRUE;
    int  want_blue  = TRUE;
    int  want_depth = TRUE;

    while (moreargs()) {
        LVAL       key = xlgasymbol();
        if        (key == k_justlike) {
	    lv_justlike = xlgetarg();
        } else if (key == k_want) {
	    LVAL lv_color = xlgasymbol();
	    if (!seen_want) {
		seen_want  = TRUE;
		want_red   = FALSE;
		want_green = FALSE;
		want_blue  = FALSE;
		want_depth = FALSE;
	    }
	    if      (lv_color == k_pixelred  )  want_red   = TRUE;
	    else if (lv_color == k_pixelgreen)  want_green = TRUE;
	    else if (lv_color == k_pixelblue )  want_green = TRUE;
	    else if (lv_color == k_pixeldepth)  want_depth = TRUE;
	    else xlerror("invalid :WANT keyword",lv_color);
	} else {
            xlerror("Expected :JUST-LIKE",key);
    }   }
    lib33_2D_Int_List_To_Point( &rows, &cols, lv_shape    );
    return xthl28_MakeImageGrl(
        rows,
        cols,
        lv_justlike,
        want_red,
        want_green,
        want_blue,
        want_depth
    );
}

/* }}} */
/* {{{ xthl32_GetFacet0123						*/

xthl32_GetFacet0123(  f0,  f1,  f2,  f3,  lv_grl )
int		    **f0,**f1,**f2,**f3;
LVAL					  lv_grl;
{
    extern LVAL k_facet0;
    extern LVAL k_facet1;
    extern LVAL k_facet2;
    extern LVAL k_facet3;
    LVAL lv_facet0;
    LVAL lv_facet1;
    LVAL lv_facet2;
    LVAL lv_facet3;
    LVAL*p = xgrl13_pArrayList( lv_grl );
    int  n = 0;

    if (n==0 && ((lv_facet0 = xthl74_GetProp(p, k_facet0, NULL,1 )) != NULL))   ++n;
    if (n==1 && ((lv_facet1 = xthl74_GetProp(p, k_facet1, NULL,1 )) != NULL))   ++n;
    if (n==2 && ((lv_facet2 = xthl74_GetProp(p, k_facet2, NULL,1 )) != NULL))   ++n;
    if (n==3 && ((lv_facet3 = xthl74_GetProp(p, k_facet3, NULL,1 )) != NULL))   ++n;

    if (n > 0)  xthlEd_Error_If_Not_Int32Vector( lv_facet0, k_facet0 );
    if (n > 1)  xthlEd_Error_If_Not_Int32Vector( lv_facet1, k_facet1 );
    if (n > 2)  xthlEd_Error_If_Not_Int32Vector( lv_facet2, k_facet2 );
    if (n > 3)  xthlEd_Error_If_Not_Int32Vector( lv_facet3, k_facet3 );
    
    if (n > 0)  *f0 = ((int  *) csry_base( lv_facet0 ));
    if (n > 1)  *f1 = ((int  *) csry_base( lv_facet1 ));
    if (n > 2)  *f2 = ((int  *) csry_base( lv_facet2 ));
    if (n > 3)  *f3 = ((int  *) csry_base( lv_facet3 ));

    return n;
}

/* }}} */
/* {{{ xthl34_GetFacetRedGreenBlue					*/

xthl34_GetFacetRedGreenBlue( b0,  b1,  b2,  lv_grl )
unsigned char		   **b0,**b1,**b2;
LVAL					    lv_grl;
{
    extern LVAL k_facetred;
    extern LVAL k_facetgreen;
    extern LVAL k_facetblue;
    LVAL lv_facetred;
    LVAL lv_facetgreen;
    LVAL lv_facetblue;
    LVAL*p = xgrl13_pArrayList( lv_grl );
    int  n = 0;
    if (((lv_facetred   = xthl74_GetProp(p, k_facetred  , NULL,1 )) != NULL))   ++n;
    if (((lv_facetgreen = xthl74_GetProp(p, k_facetgreen, NULL,1 )) != NULL))   ++n;
    if (((lv_facetblue  = xthl74_GetProp(p, k_facetblue , NULL,1 )) != NULL))   ++n;

    if (n != 3)   return FALSE;

    xthlEg_Error_If_Not_8BitFloatVector( lv_facetred  , k_facetred   );
    xthlEg_Error_If_Not_8BitFloatVector( lv_facetgreen, k_facetgreen );
    xthlEg_Error_If_Not_8BitFloatVector( lv_facetblue , k_facetblue  );

    *b0 = ((unsigned char*) csry_base( lv_facetred   ));
    *b1 = ((unsigned char*) csry_base( lv_facetgreen ));
    *b2 = ((unsigned char*) csry_base( lv_facetblue  ));

    return n;
}

/* }}} */
/* {{{ xthl36_GetFacetNormalXYZ						*/

xthl36_GetFacetNormalXYZ( f0,  f1,  f2, lv_grl )
float			**f0,**f1,**f2;
LVAL					lv_grl;
{
    extern LVAL k_facetnormalx;
    extern LVAL k_facetnormaly;
    extern LVAL k_facetnormalz;
    LVAL lv_facetnormalx;
    LVAL lv_facetnormaly;
    LVAL lv_facetnormalz;
    LVAL*p = xgrl13_pArrayList( lv_grl );
    int  n = 0;
    if (((lv_facetnormalx = xthl74_GetProp(p, k_facetnormalx, NULL,1)) != NULL))   ++n;
    if (((lv_facetnormaly = xthl74_GetProp(p, k_facetnormaly, NULL,1)) != NULL))   ++n;
    if (((lv_facetnormalz = xthl74_GetProp(p, k_facetnormalz, NULL,1)) != NULL))   ++n;

    if (n != 3)   return FALSE;

    xthlEc_Error_If_Not_FloatVector( lv_facetnormalx, k_facetnormalx );
    xthlEc_Error_If_Not_FloatVector( lv_facetnormaly, k_facetnormaly );
    xthlEc_Error_If_Not_FloatVector( lv_facetnormalz, k_facetnormalz );

    *f0 = ((float*) csry_base( lv_facetnormalx ));
    *f1 = ((float*) csry_base( lv_facetnormaly ));
    *f2 = ((float*) csry_base( lv_facetnormalz ));

    return n;
}

/* }}} */
/* {{{ xthl3a_GetPixelRedGreenBlueIfPresent				*/

xthl3a_GetPixelRedGreenBlueIfPresent( b0,  b1,  b2, lv_grl )
LVAL			             *b0, *b1, *b2;
LVAL				                         lv_grl;
{
    extern LVAL k_pixelred  ;
    extern LVAL k_pixelgreen;
    extern LVAL k_pixelblue ;
    LVAL lv_pixelred;
    LVAL lv_pixelgreen;
    LVAL lv_pixelblue;
    LVAL*p = xgrl13_pArrayList( lv_grl );
    int  n = 0;
    if (((lv_pixelred   = xthl74_GetProp(p, k_pixelred  , NULL,1 )) != NULL))   ++n;
    if (((lv_pixelgreen = xthl74_GetProp(p, k_pixelgreen, NULL,1 )) != NULL))   ++n;
    if (((lv_pixelblue  = xthl74_GetProp(p, k_pixelblue , NULL,1 )) != NULL))   ++n;

    if (lv_pixelred  ) xthlEj_Error_If_Not_8BitFloatArray( lv_pixelred  , k_pixelred   );
    if (lv_pixelgreen) xthlEj_Error_If_Not_8BitFloatArray( lv_pixelgreen, k_pixelgreen );
    if (lv_pixelblue ) xthlEj_Error_If_Not_8BitFloatArray( lv_pixelblue , k_pixelblue  );

    *b0 = lv_pixelred  ;
    *b1 = lv_pixelgreen;
    *b2 = lv_pixelblue ;

    return n;
}

/* }}} */
/* {{{ xthl3b_GetPixelRedGreenBlueDepthIfPresent			*/

xthl3b_GetPixelRedGreenBlueDepthIfPresent( b0,  b1,  b2,  b3, lv_grl )
LVAL			                  *b0, *b1, *b2, *b3;
LVAL					                      lv_grl;
{
    extern LVAL k_pixelred  ;
    extern LVAL k_pixelgreen;
    extern LVAL k_pixelblue ;
    extern LVAL k_pixeldepth;
    LVAL lv_pixelred;
    LVAL lv_pixelgreen;
    LVAL lv_pixelblue;
    LVAL lv_pixeldepth;
    LVAL*p = xgrl13_pArrayList( lv_grl );
    int  n = 0;
    if (((lv_pixelred   = xthl74_GetProp(p, k_pixelred  , NULL,1 )) != NULL))   ++n;
    if (((lv_pixelgreen = xthl74_GetProp(p, k_pixelgreen, NULL,1 )) != NULL))   ++n;
    if (((lv_pixelblue  = xthl74_GetProp(p, k_pixelblue , NULL,1 )) != NULL))   ++n;
    if (((lv_pixeldepth = xthl74_GetProp(p, k_pixeldepth, NULL,1 )) != NULL))   ++n;

    if (lv_pixelred  ) xthlEj_Error_If_Not_8BitFloatArray( lv_pixelred  , k_pixelred   );
    if (lv_pixelgreen) xthlEj_Error_If_Not_8BitFloatArray( lv_pixelgreen, k_pixelgreen );
    if (lv_pixelblue ) xthlEj_Error_If_Not_8BitFloatArray( lv_pixelblue , k_pixelblue  );
    if (lv_pixeldepth) xthlEj_Error_If_Not_8BitFloatArray( lv_pixeldepth, k_pixeldepth );

    *b0 = lv_pixelred  ;
    *b1 = lv_pixelgreen;
    *b2 = lv_pixelblue ;
    *b3 = lv_pixeldepth;

    return n;
}

/* }}} */
/* {{{ xthl42_GetPointXYZ						*/

xthl42_GetPointXYZ( f0,  f1,  f2, lv_grl )
float		  **f0,**f1,**f2;
LVAL				  lv_grl;
{
    extern LVAL k_pointx;
    extern LVAL k_pointy;
    extern LVAL k_pointz;
    LVAL lv_pointx;
    LVAL lv_pointy;
    LVAL lv_pointz;
    LVAL*p = xgrl13_pArrayList( lv_grl );

    int  n = 0;
    if (((lv_pointx = xthl74_GetProp(p, k_pointx, NULL,1)) != NULL))   ++n;
    if (((lv_pointy = xthl74_GetProp(p, k_pointy, NULL,1)) != NULL))   ++n;
    if (((lv_pointz = xthl74_GetProp(p, k_pointz, NULL,1)) != NULL))   ++n;

    if (n != 3)   return FALSE;

    xthlEc_Error_If_Not_FloatVector( lv_pointx, k_pointx );
    xthlEc_Error_If_Not_FloatVector( lv_pointy, k_pointy );
    xthlEc_Error_If_Not_FloatVector( lv_pointz, k_pointz );

    *f0 = ((float*) csry_base( lv_pointx ));
    *f1 = ((float*) csry_base( lv_pointy ));
    *f2 = ((float*) csry_base( lv_pointz ));

    return n;
}

/* }}} */
/* {{{ xthl44_GetPointRedGreenBlue					*/

xthl44_GetPointRedGreenBlue( b0,  b1,  b2,  lv_grl )
unsigned char		   **b0,**b1,**b2;
LVAL					    lv_grl;
{
    extern LVAL k_pointred;
    extern LVAL k_pointgreen;
    extern LVAL k_pointblue;
    LVAL lv_pointred;
    LVAL lv_pointgreen;
    LVAL lv_pointblue;
    LVAL*p = xgrl13_pArrayList( lv_grl );
    int  n = 0;
    if (((lv_pointred   = xthl74_GetProp(p, k_pointred  , NULL,1)) != NULL))   ++n;
    if (((lv_pointgreen = xthl74_GetProp(p, k_pointgreen, NULL,1)) != NULL))   ++n;
    if (((lv_pointblue  = xthl74_GetProp(p, k_pointblue , NULL,1)) != NULL))   ++n;

    if (n != 3)   return FALSE;

    xthlEg_Error_If_Not_8BitFloatVector( lv_pointred  , k_pointred   );
    xthlEg_Error_If_Not_8BitFloatVector( lv_pointgreen, k_pointgreen );
    xthlEg_Error_If_Not_8BitFloatVector( lv_pointblue , k_pointblue  );

    *b0 = ((unsigned char*) csry_base( lv_pointred   ));
    *b1 = ((unsigned char*) csry_base( lv_pointgreen ));
    *b2 = ((unsigned char*) csry_base( lv_pointblue  ));

    return n;
}

/* }}} */
/* {{{ xthl46_GetPointNormalXYZ						*/

xthl46_GetPointNormalXYZ( f0,  f1,  f2, lv_grl )
float			**f0,**f1,**f2;
LVAL					lv_grl;
{
    extern LVAL k_pointnormalx;
    extern LVAL k_pointnormaly;
    extern LVAL k_pointnormalz;
    LVAL lv_pointnormalx;
    LVAL lv_pointnormaly;
    LVAL lv_pointnormalz;
    int  n = 0;
    LVAL*p = xgrl13_pArrayList( lv_grl );
    if (((lv_pointnormalx = xthl74_GetProp(p, k_pointnormalx, NULL,1)) != NULL))   ++n;
    if (((lv_pointnormaly = xthl74_GetProp(p, k_pointnormaly, NULL,1)) != NULL))   ++n;
    if (((lv_pointnormalz = xthl74_GetProp(p, k_pointnormalz, NULL,1)) != NULL))   ++n;

    if (n != 3)   return FALSE;

    xthlEc_Error_If_Not_FloatVector( lv_pointnormalx, k_pointnormalx );
    xthlEc_Error_If_Not_FloatVector( lv_pointnormaly, k_pointnormaly );
    xthlEc_Error_If_Not_FloatVector( lv_pointnormalz, k_pointnormalz );

    *f0 = ((float*) csry_base( lv_pointnormalx ));
    *f1 = ((float*) csry_base( lv_pointnormaly ));
    *f2 = ((float*) csry_base( lv_pointnormalz ));

    return n;
}

/* }}} */
/* {{{ xthlz1_MakeThing							*/

LVAL xthlz1_Make_Thing( r, n )
struct xthl06_Want_Rec* r;
int                        n;
{
    extern LVAL k_pointrelation;
    extern LVAL k_facetrelation;
    extern LVAL k_pickas;
    extern LVAL k_pointif;
    extern LVAL k_facetif;
    extern LVAL k_dropbackfaces;
    extern LVAL k_fixlightsonobject;
    extern LVAL k_lights;
    extern LVAL k_lightingmodel;
    extern LVAL k_material;
    extern LVAL k_transform;
    extern LVAL k_widget;
    extern LVAL k_downclickhook;
    extern LVAL k_draghook;
    extern LVAL k_upclickhook;
    extern LVAL k_reselecthook;
    extern LVAL k_selecthook;
    extern LVAL k_deselecthook;
    extern LVAL k_redraw;

    LVAL lv_thinglist;
    LVAL lv_pointthing;
    LVAL lv_facetthing;

    int toProt = 22;
    xlstkcheck(toProt);
    xlsave(	lv_thinglist		);
    xlsave(	lv_pointthing		);
    xlsave(	lv_facetthing		);

    xlprotect(	r->lv_whichbitplanes	);
    xlprotect(	r->lv_use_colors	);
    xlprotect(	r->lv_use_normals	);
    xlprotect(	r->lv_pickas		);
    xlprotect(	r->lv_pointif		);
    xlprotect(	r->lv_facetif		);
    xlprotect(	r->lv_dropbackfaces	);
    xlprotect(	r->lv_fixlightsonobject	);

    xlprotect(	r->lv_lights		);
    xlprotect(	r->lv_lightingmodel	);
    xlprotect(	r->lv_material		);
    xlprotect(	r->lv_transform		);
    xlprotect(	r->lv_widget		);

    xlprotect(	r->lv_downclickhook	);
    xlprotect(	r->lv_draghook		);
    xlprotect(	r->lv_upclickhook	);

    xlprotect(	r->lv_reselecthook	);
    xlprotect(	r->lv_selecthook	);
    xlprotect(	r->lv_deselecthook	);

    /* Create our (usually) two relations: */
    lv_pointthing = xthl02_Make_Point_Grl( r, 0 );
    if (n) {
	lv_facetthing = xthl12_Make_Grl_Of_Facets( r, n );
    }

    /* Construct thinglist proper: */
    lv_thinglist = cons(     lv_pointthing,		lv_thinglist );
    lv_thinglist = cons(      k_pointrelation,		lv_thinglist );

    if (!null(lv_facetthing)) {
	lv_thinglist = cons( lv_facetthing,		lv_thinglist );
	lv_thinglist = cons(  k_facetrelation,		lv_thinglist );
    }

    if (!null(r->lv_deselecthook)) {
	lv_thinglist = cons( r->lv_deselecthook,	lv_thinglist );
	lv_thinglist = cons(  k_deselecthook,		lv_thinglist );
    }

    if (!null(r->lv_selecthook)) {
	lv_thinglist = cons( r->lv_selecthook,		lv_thinglist );
	lv_thinglist = cons(  k_selecthook,		lv_thinglist );
    }

    if (!null(r->lv_reselecthook)) {
	lv_thinglist = cons( r->lv_reselecthook,	lv_thinglist );
	lv_thinglist = cons(  k_reselecthook,		lv_thinglist );
    }

    if (!null(r->lv_upclickhook)) {
	lv_thinglist = cons( r->lv_upclickhook,		lv_thinglist );
	lv_thinglist = cons(  k_upclickhook,		lv_thinglist );
    }

    if (!null(r->lv_draghook)) {
	lv_thinglist = cons( r->lv_draghook,		lv_thinglist );
	lv_thinglist = cons(  k_draghook,		lv_thinglist );
    }

    if (!null(r->lv_downclickhook)) {
 	lv_thinglist = cons( r->lv_downclickhook,	lv_thinglist );
 	lv_thinglist = cons(  k_downclickhook,		lv_thinglist );
    }

    if (!null(r->lv_widget)) {
 	lv_thinglist = cons( r->lv_widget,		lv_thinglist );
 	lv_thinglist = cons(  k_widget,			lv_thinglist );
    }

    if (!null(r->lv_transform)) {
 	lv_thinglist = cons( r->lv_transform,		lv_thinglist );
 	lv_thinglist = cons(  k_transform,		lv_thinglist );
    }

    if (!null(r->lv_material)) {
 	lv_thinglist = cons( r->lv_material,		lv_thinglist );
 	lv_thinglist = cons(  k_material,		lv_thinglist );
    }

    if (!null(r->lv_lightingmodel)) {
 	lv_thinglist = cons( r->lv_lightingmodel,	lv_thinglist );
 	lv_thinglist = cons(  k_lightingmodel,		lv_thinglist );
    }

    if (!null(r->lv_lights)) {
 	lv_thinglist = cons( r->lv_lights,		lv_thinglist );
 	lv_thinglist = cons(  k_lights,			lv_thinglist );
    }

    if (!null(r->lv_fixlightsonobject)) {
 	lv_thinglist = cons( r->lv_fixlightsonobject,	lv_thinglist );
 	lv_thinglist = cons(  k_fixlightsonobject,	lv_thinglist );
    }

    if (!null(r->lv_dropbackfaces)) {
 	lv_thinglist = cons( r->lv_dropbackfaces,	lv_thinglist );
 	lv_thinglist = cons(  k_dropbackfaces,		lv_thinglist );
    }

    if (!null(r->lv_facetif)) {
 	lv_thinglist = cons( r->lv_facetif,		lv_thinglist );
 	lv_thinglist = cons(  k_facetif,		lv_thinglist );
    }

    if (!null(r->lv_pointif)) {
 	lv_thinglist = cons( r->lv_pointif,		lv_thinglist );
 	lv_thinglist = cons(  k_pointif,		lv_thinglist );
    }

    if (!null(r->lv_pickas)) {
 	lv_thinglist = cons( r->lv_pickas,		lv_thinglist );
 	lv_thinglist = cons(  k_pickas,			lv_thinglist );
    }

    if (!null(r->lv_use_colors)) {
 	lv_thinglist = cons( r->lv_use_colors,		lv_thinglist );
 	lv_thinglist = cons(  k_use_colors,		lv_thinglist );
    }

    if (!null(r->lv_use_normals)) {
 	lv_thinglist = cons( r->lv_use_normals,		lv_thinglist );
 	lv_thinglist = cons(  k_use_normals,		lv_thinglist );
    }

    if (!null(r->lv_whichbitplanes)) {
 	lv_thinglist = cons( r->lv_whichbitplanes,	lv_thinglist );
 	lv_thinglist = cons(  k_whichbitplanes,		lv_thinglist );
    }

    if (!r->redraw) {
 	lv_thinglist = cons(       NIL,			lv_thinglist );
 	lv_thinglist = cons(  k_redraw,			lv_thinglist );
    }

    xlpopn(toProt);
    return lv_thinglist;
}

/* }}} */
/* {{{ xthl52_MakeThing							*/

LVAL xthl52_MakeThing( n )
int		       n;
{   struct xthl06_Want_Rec     r     ;
    xthl08_Parse_Want_Args(   &r    );
    return xthlz1_Make_Thing( &r, n );
}

/* }}} */
/* {{{ xthlz3_Simple_MakeThing -- C callable MakeThing with fewer args.	*/

LVAL xthlz3_Simple_MakeThing(
    n, 
    want_point_normals,
    want_point_colors,
    want_facet_normals,
    want_facet_colors
)
int n;
int want_point_normals;
int want_point_colors;
int want_facet_normals;
int want_facet_colors;
{
    struct xthl06_Want_Rec  r;
    xthl07_Init_Want_Args( &r );
    r.want_point_normals = want_point_normals;
    r.want_point_colors  = want_point_colors;
    r.want_facet_normals = want_facet_normals;
    r.want_facet_colors  = want_facet_colors;

    return xthlz1_Make_Thing( &r, n );
}

/* }}} */
/* {{{ xthl55_MakeThingOfPoints_Fn					*/

LVAL xthl55_MakeThingOfPoints_Fn()
{
    return xthl52_MakeThing( 1 );
}

/* }}} */
/* {{{ xthl64_MakeThingOfLines_Fn					*/

LVAL xthl64_MakeThingOfLines_Fn()
{
    return xthl52_MakeThing( 2 );
}

/* }}} */
/* {{{ xthl66_MakeThingOfTriangles_Fn					*/

LVAL xthl66_MakeThingOfTriangles_Fn()
{
    return xthl52_MakeThing( 3 );
}

/* }}} */
/* {{{ xthl68_MakeThingOfRectangles_Fn					*/

LVAL xthl68_MakeThingOfRectangles_Fn()
{
    return xthl52_MakeThing( 4 );
}

/* }}} */
/* {{{ xthl74_GetProp							*/

LVAL  xthl74_GetProp( pPropList, key, default_val, got_default )    
LVAL                 *pPropList, key, default_val;
int						   got_default;
{
    LVAL val = xthl80_FindProp( *pPropList, key );
    if (val == NIL) {
	if (got_default)   return default_val;
        xlerror( "No such property", key );
    }
    return car(val);
}

/* }}} */
/* {{{ xthl80_FindProp -- Find a property pair.				*/

LVAL xthl80_FindProp( lst, prp )
LVAL		      lst, prp;
{
    /* Near-replica of xlsym.c:findprop(). */
    LVAL p;
    for (p = lst; consp(p) && consp(cdr(p)); p = cdr(cdr(p))) {
	if (car(p) == prp) {
	    return cdr(p);
	}
    }
    return NIL;
}

/* }}} */
/* {{{ xthl81_SetProp_Dups_Ok--Push a property value onto a property lst*/

LVAL xthl81_SetProp_Dups_Ok( pLst,prp,val )
LVAL	                    *pLst,prp,val;
{/* Push a property value onto a property list w/o checking for duplicates. */
    xlprot1(prp);
    *pLst = cons(prp,cons(val,*pLst));
    xlpop();
    return val;
}

/* }}} */
/* {{{ xthl82_SetProp -- Set a property value on a property list.	*/

LVAL xthl82_SetProp( pLst,prp,val )
LVAL	            *pLst,prp,val;
{/* Near-replica of xlsym.c:xlputprop(). */
    LVAL pair = xthl80_FindProp(*pLst,prp);
    if (!null(pair)) {
	rplaca(pair,val);
    } else {
	/********************************************************/
	/* If the propertylist is nonempty, we insert within it */
	/* rather than appending to its head.  This somewhat    */
	/* unlispish approach is primarily for the benefit of   */
	/* hook functions which want to update a thing without  */
	/* knowing what thinglist(s) the thing is in.		*/
	/********************************************************/
	xlprot1(prp);
	if (null(pair = *pLst)) {
	    /* Null propertylist, we *have* to update head pointer: */
	    *pLst = cons(prp,cons(val,*pLst));
	} else {
	    /* Nonnull propertylist, we can insert without updating head pointer: */
	    if (null(pair=cdr(pair))) xlerror("Invalid proplist",*pLst);
	    rplacd(pair,(cons(prp,cons(val,cdr(pair)))));
	}
	xlpop();
    }
    return val;
}

/* }}} */
/* {{{ xthl83_RemProp -- Remove a property from a property list.	*/

LVAL xthl83_RemProp( pLst, prp )
LVAL	            *pLst, prp;
/*-
    Remove a property from a property list.
    Near-replica of xlsym.c:xlremprop().
-*/
{
    LVAL* last = pLst;
    LVAL p     = *last;
    while (consp(p) && consp(cdr(p))) {
	if (car(p) == prp) {
	    *last = cdr(cdr(p));

	    /********************************************/
	    /* Return a (key . val) dotted pair.  This: */ 
	    /* (1) Gives both useful values to user.    */
	    /* (2) Makes a minimum commitment in terms  */
	    /*     of number of cons cells returns.     */
	    /* (3) Keeps caller's sticky fingers off of */
	    /*     the rest of the property list. :)    */
	    /********************************************/
	    rplacd(p,car(cdr(p)));
	    return p;
	}
	last = &cdr(cdr(p));
	p    = *last;
    }
    return NIL;
}

/* }}} */
/* {{{ xthl85_GetAddressOfSymbolValue--Get address of value of a symbol.*/

LVAL* xthl85_GetAddressOfSymbolValue( sym )
LVAL				       sym;
{
    /* Near-replica of xlsym.c:xlxgetvalue(). */
    /* buggo, this fn used only in xwmr.c: May be able to phase this fn out. */
    register LVAL fp,ep;
    LVAL* pval;

    /* Check the environment list */
    for (fp = xlenv; fp; fp = cdr(fp)) {

	/* Check for an instance variable: */
	if ((ep = car(fp)) && objectp(car(ep))) {
	    if (xthl87_GetAddressOfObjectVariableValue(car(ep),cdr(ep),sym,&pval))
		return pval;
	} else {
	    /* Check an environment stack frame: */
	    for (; ep; ep = cdr(ep)) {
		if (sym ==  car(car(ep))) {
		    return &cdr(car(ep));
		}
	    }
	}
    }

    /* Return address of global value: */
    return &getvalue(sym);
}

/* }}} */
/* {{{ xthl86_GetAddressOfSymbolValueErrorIfUnbound.			*/

LVAL* xthl86_GetAddressOfSymbolValueErrorIfUnbound( sym )
LVAL						    sym;
{
    /* Get address of value of a symbol (with check). */
    /* Near-replica of xlsym.c:xlgetvalue().          */

    /* Look for the value of the symbol: */
    LVAL* val;
    while (*(val = xthl85_GetAddressOfSymbolValue(sym)) == s_unbound) {
	xlunbound(sym);
    }
    return val;
}

/* }}} */
/* {{{ xthl87_GetAddressOfObjectVariableValue				*/

int xthl87_GetAddressOfObjectVariableValue(obj,cls,sym,ppval)
LVAL obj,cls;/* This pair is from an xlenv environment frame.   */
             /* obj is an object.                               */
             /* cls is a [maybe super-]class of object.         */
LVAL sym;   /* Symbol whose value we're trying to locate.       */
LVAL**ppval;/* Return path for value address.                   */
{           /* Return TRUE if we find sym, else FALSE.          */
    /* Get address of value of an instance variable. */
    /* Near-replica of xlobj.c:xlobgetvalue().       */
    LVAL names;
    int ivtotal,n;

    /* Find the instance or class variable: */
    for (; objectp(cls); cls = getivar(cls,SUPERCLASS)) {

	/* Check the instance variables: */
	names = getivar(cls,IVARS);
	ivtotal = getivcnt(cls,IVARTOTAL);
	for (n = ivtotal - getivcnt(cls,IVARCNT); n < ivtotal; ++n) {
	    if (car(names) == sym) {
		*ppval = &getivar(obj,n);
		return TRUE;
	    }
	    names = cdr(names);
	}

	/* Check the class variables: */
	names = getivar(cls,CVARS);
	for (n = 0; consp(names); ++n) {
	    if (car(names) == sym) {
		*ppval = &getelement(getivar(cls,CVALS),n);
		return TRUE;
	    }
	    names = cdr(names);
	}
    }

    /* Variable not found: */
    return   FALSE;
}

/* }}} */
/* {{{ xthl88_GetAddressOfObjectVariableValueErrorIfMissing		*/

xthl88_GetAddressOfObjectVariableValueErrorIfMissing(lv_obj,lv_cls,lv_sym,pplv_val)
LVAL						     lv_obj,lv_cls,lv_sym;   
LVAL									**pplv_val;
{   /* Yeah, it's a long fn name.  <;^p ! */
    if (!xthl87_GetAddressOfObjectVariableValue(lv_obj,lv_cls,lv_sym,pplv_val)) {
	xlerror("No instance variable",lv_sym);
    }
}

/* }}} */
/* {{{ xthl89_GetAddressOfObjectVariableValueErrorIfUnbound		*/

xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(lv_obj,lv_cls,lv_sym,pplv_val)
LVAL						     lv_obj,lv_cls,lv_sym;   
LVAL									**pplv_val;
{
    for (;;) {
        xthl88_GetAddressOfObjectVariableValueErrorIfMissing(
	    lv_obj,lv_cls,lv_sym,pplv_val
        );
	if (**pplv_val != s_unbound)   return;
	xlunbound(lv_sym);
    }
}

/* }}} */
/* {{{ xthl8a_GetObjectProp						*/

LVAL xthl8a_GetObjectProp( lv_self, lv_sym, default_val, got_default )
LVAL			   lv_self, lv_sym, default_val;
int                                                     got_default;
{   LVAL*pPropList  = x03d73_pPropList( lv_self );
    return            xthl74_GetProp( pPropList, lv_sym, default_val, got_default );
}

/* xthl9b_SetObjectProp became x03d9b_SetObjectProp (which see). */

/* }}} */
/* {{{ xthl90_GetObjectVariable						*/

LVAL xthl90_GetObjectVariable(lv_obj,lv_sym)
LVAL			      lv_obj,lv_sym;
{   LVAL*pLval;
    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
        lv_obj,
        getclass( lv_obj ),
        lv_sym,
        &pLval
    );
    return *pLval;
}

/* }}} */
/* {{{ xthl91_SetObjectVariable						*/

xthl91_SetObjectVariable(lv_obj,lv_sym,lv_val)
LVAL			 lv_obj,lv_sym,lv_val;
{   LVAL*pLval;
    xthl88_GetAddressOfObjectVariableValueErrorIfMissing(
        lv_obj,
        getclass( lv_obj ),
        lv_sym,
        &pLval
    );
    *pLval = lv_val;
}

/* }}} */
/* {{{ xthl93_ListNth -- Nth element of propertylist.			*/

LVAL x03d92_ListNth( lst, n )
LVAL		     lst;
int			  n;
{
    LVAL p;
    for (p = lst; consp(p) && consp(cdr(p)); p = cdr(cdr(p))) {
	if (n-- == 0)   return p;
    }
    return NIL;
}
LVAL xthl93_ListNth( propList, n, err_n, default_val, got_default )
LVAL                 propList;
int			       n;
LVAL                              err_n, default_val;
int			       		              got_default;
{
    LVAL pair = x03d92_ListNth( propList, n );
    if (pair == NIL) {
	if (got_default)   return default_val;
        xlerror( "No property #", err_n );
    }
    return car(pair);
}

/* }}} */
/* {{{ xthl95_nth -- Nth element of regular list.			*/

LVAL xthl95_nth(lv_list, n, default_val, got_default)
LVAL		lv_list;
int			 n;
LVAL                        default_val;
int			       		 got_default;
{   /* This is basically xllist.c:nth made c-callable... */
    LVAL lv = lv_list;
    while (consp(lv)   &&   n --> 0)   lv = cdr(lv);

    if (null(lv)) {
	if (got_default)   return default_val;
    }
    if (consp(lv))   return car(lv);

    {   char buf[ 128 ];
	sprintf(buf, "Can't find %dth element", n );
	xlerror(buf,lv_list);
    }
    return NIL; /* Some compiler will thank us. */
}

/* }}} */
/* {{{ xthl97_Remove -- DESTRUCTIVELY remove given element from list.	*/

xthl97_Remove( plv_list, lv_element )
LVAL          *plv_list, lv_element;
{   LVAL lv_list;
    LVAL lv_last;

    /* Can't delete elements from empty list: */
    if (!consp(*plv_list))   return;

    /* Have to special-case deleting from first element of list: */
    if (car(*plv_list) == lv_element) {
	*plv_list = cdr(*plv_list);
        if (!consp(*plv_list))   return;
    }

    /* Delete nonfirst by pointing previous cell to next cell: */
    for(lv_last =     *plv_list ,
	lv_list = cdr(*plv_list);

	consp(lv_list);

	lv_last =     lv_list,
	lv_list = cdr(lv_list)
    ) {
	if (car(lv_list) == lv_element) {
	    rplacd(lv_last,cdr(lv_list));
    }	}
}

/* }}} */
/* {{{ xthlA2_Get_Point_Relation_From_Thing				*/

LVAL xthlA2_Get_Point_Relation_From_Thing( lv_thing )
LVAL					   lv_thing;
{
    extern LVAL k_pointrelation;
    LVAL lv_pointGrl = xthl74_GetProp( &lv_thing, k_pointrelation, NULL,TRUE );
    if (lv_pointGrl == NULL) xlerror("No :POINT-RELATION!",lv_thing);
    if (!xgrlp(lv_pointGrl)) xlerror(":POINT-RELATION isn't a grl!",lv_pointGrl);
    return lv_pointGrl;
}

/* }}} */
/* {{{ xthlA4_Get_Facet_Relation_From_Thing				*/

LVAL xthlA4_Get_Facet_Relation_From_Thing( lv_thing )
LVAL					   lv_thing;
{
    extern LVAL k_facetrelation;
    LVAL lv_facetGrl = xthl74_GetProp( &lv_thing, k_facetrelation, NULL,TRUE );
    if (lv_facetGrl == NULL) xlerror("No :FACET-RELATION!",lv_thing);
    if (!xgrlp(lv_facetGrl)) xlerror(":FACET-RELATION isn't a grl!",lv_facetGrl);
    return lv_facetGrl;
}

/* }}} */
/* {{{ xthlAY_Process_Thinglist_KeyVal_Pair				*/

xthlAY_Process_Thinglist_KeyVal_Pair( r, lv_key, lv_val )
gt_tri_rec       		     *r;
LVAL		       			 lv_key, lv_val;
/*-
    Fill in a gt_tri_rec from an thinglist key/val pair.
-*/
{
    /********************************************************************/
    /* As documented in 3d.texi:"send <cmr> :DRAW ...", the format      */
    /* of an thinglist is:                                             */
    /*                                                                  */
    /*	( [ :PICK-AS  @{ :SOLID | :BACKGROUND | :FOREGROUND  | :INVISIBLE @} ] 	*/
    /*	  [ :USE-COLORS  @{ T | :ON-FACETS | :ON-POINTS | NIL @} ] 	*/
    /*	  [ :USE-NORMALS @{ T | :ON-FACETS | :ON-POINTS | NIL @} ] 	*/
    /*	  [ :POINT-RELATION <point-relation> ]	    	    	       	*/
    /*	  [ :FACET-RELATION <facet-relation> ]	    	    	       	*/
    /*	  [ :PIXEL-RELATION <pixel-relation> ]	    	    	       	*/
    /*	  [ :TRANSFORM <modelling-matrix> ] 	    	    	       	*/
    /*	  [ :FIX-LIGHTS-ON-OBJECT t ]  	    	    	    	       	*/
    /*	  [ :LIGHTS <lightlist> ]   	    	    	    	       	*/
    /*	  [ :LIGHTING-MODEL <lighting-model> ]	    	    	       	*/
    /*	  [ :MATERIAL <material> ]  	    	    	    	       	*/
    /*	  [ :DROP-BACKFACES t]	    	    	    	    	       	*/
    /*	  [ :DOWNCLICK-HOOK <hook-fn(s)>                  ] 	       	*/
    /*	  [ :DRAG-HOOK      <hook-fn(s)>                  ] 	       	*/
    /*	  [ :UPCLICK-HOOK   <hook-fn(s)>                  ] 	       	*/
    /*	  [ :SELECT-HOOK    <hook-fn(s)>                  ] 	       	*/
    /*	  [ :DESELECT-HOOK  <hook-fn(s)>                  ] 	       	*/
    /*	  [ :RESELECT-HOOK  <hook-fn(s)>                  ] 	       	*/
    /*	  [ :<anykeyword>   <anyvalue>	                  ] 	       	*/
    /*   )                                                              */
    /*                                                                  */
    /* Order of components within the list is not significant.          */
    /* Additional property-value pairs may be present for use by        */
    /* the application program, we simply ignore such.                  */
    /********************************************************************/

    extern LVAL true;
    char* badkey    = "Bad objlist keyword"       ;
    char* badgrl    = "Need a relation"           ;
    char* badcolors = "Bad :USE-COLORS value"     ;
    char* badnormals= "Bad :USE-NORMALS value"    ;
    char* badfacet  = "nonsymbol :FACET-IF value" ;
    char* badpoint  = "nonsymbol :POINT-IF value" ;
    char* badpick   = "Bad :PICK-AS value"        ;
    char* badtfm    = "Bad :TRANSFORM value"      ;
    char* badmtl    = "Bad :MATERIAL value"       ;
    char* badtxr    = "Bad :TEXTURE value"        ;
    char* badmdl    = "Bad :LIGHTING-MODEL value" ;
    char* badwhich  = "Bad :WHICH-BITPLANES value";
    LVAL  lv_oval   = lv_val;

    if (!symbolp( lv_key ))    xlerror( badkey, lv_key );
    lv_key = getvalue(lv_key);
    if (!symbolp( lv_key ))    xlerror( badkey, lv_key );

    if (symbolp( lv_val  ))    lv_val  = getvalue(lv_val);


    if          (lv_key == k_pointrelation  ||
		 lv_key == k_pixelrelation  ||
		 lv_key == k_facetrelation
    ) {

	if (!xgrlp( lv_val ))  xlerror( badgrl, lv_val );
	xthlB3_Fill_Tri_Rec_From_Grl( r, lv_val );

    } else if (lv_key == k_pickas       ) {

	if (lv_val == k_background  ||
	    lv_val == k_foreground  ||
	    lv_val == k_solid       ||
	    lv_val == k_invisible
	) {
	    r->lv_pick_as = (char*) lv_val;
	} else {
	    xlerror(badpick,lv_val);
	}

    } else if (lv_key == k_use_normals) {

	if (lv_val == true          ||
	    lv_val == k_on_facets   ||
	    lv_val == k_on_points   ||
	    lv_val == NIL
	) {
	    r->lv_use_normals = (char*) lv_val;
	} else {
	    xlerror(badnormals,lv_val);
	}

    } else if (lv_key == k_use_colors) {

	if (lv_val == true          ||
	    lv_val == k_on_facets   ||
	    lv_val == k_on_points   ||
	    lv_val == NIL
	) {
	    r->lv_use_colors = (char*) lv_val;
	} else {
	    xlerror(badcolors,lv_val);
	}

    } else if (lv_key == k_whichbitplanes  ) {

	if        (lv_val == k_rgbbitplanes) {
	    r->which_bitplanes = GT_RGB_BITPLANES;

	} else if (lv_val == k_overlaybitplanes) {
	    r->which_bitplanes = GT_OVERLAY_BITPLANES;
	} else if (lv_val == k_overlaybitplaneserase) {
	    r->which_bitplanes = GT_OVERLAY_BITPLANES_ERASE;

	} else if (lv_val == k_cursorbitplanes) {
	    r->which_bitplanes = GT_CURSOR_BITPLANES;
	} else if (lv_val == k_cursorbitplaneserase) {
	    r->which_bitplanes = GT_CURSOR_BITPLANES_ERASE;

	} else if (lv_val == k_popupbitplanes) {
	    r->which_bitplanes = GT_POPUP_BITPLANES;
	} else if (lv_val == k_popupbitplaneserase) {
	    r->which_bitplanes = GT_POPUP_BITPLANES_ERASE;

	} else {
	    xlerror(badwhich,lv_val);
	}

    } else if (lv_key == k_facetif) {

	if (!symbolp(lv_val)) xlerror(badfacet,lv_val);
	r->lv_facet_if = (char*) lv_val;

    } else if (lv_key == k_pointif) {

	if (!symbolp(lv_val)) xlerror(badpoint,lv_val);
	r->lv_point_if = (char*) lv_val;

    } else if (lv_key == k_dropbackfaces) {

	r->drop_backfaces = !null(lv_val);

    } else if (lv_key == k_fixlightsonobject) {

	r->fix_lights_on_object = !null(lv_val);

    } else if (lv_key == k_transform      ) {

	ctfm_rec * m;
	if (!xtfmp( lv_val ))	xlerror(badtfm,lv_val);
	m        = xtfm9c_Find_Immediate_Base( lv_val );
	r->model = (gt_mat*) &m->m;

    } else if (lv_key == k_lights         ) {

	xthlAZ_Process_Light_List( r, lv_val );

    } else if (lv_key == k_lightingmodel  ) {

	if (!null(lv_val)) {
	    if (!xmdlp(lv_val))	xlerror(badmdl,lv_val);
	    r->light_model = xmdl04_Get_Light_Model_Rec(lv_val);
	}

    } else if (lv_key == k_material       ) {

	if (!null(lv_val)) {
	    if (!xmtlp(lv_val))	xlerror(badmtl,lv_val);
	    r->material    = xmtl04_Get_Material_Rec(lv_val);
	}

    } else if (lv_key == k_texture        ) {

	if (!null(lv_val)) {
	    LVAL lv_grl;
	    extern LVAL s_graphicrelation;
	    if (!xtxrp(lv_val))	xlerror(badtxr,lv_val);
	    lv_grl = xthl90_GetObjectVariable( lv_val, s_graphicrelation );
	    if (lv_grl != NIL) {
		if (!xgrlp(lv_grl))  xlerror(badtxr,lv_val);
		r->doing_texture = TRUE ;
		r->texture       = xtxr04_Get_Texture_Rec(lv_val);
		xthlB3_Fill_Tri_Rec_From_Grl( r, lv_grl );
		r->doing_texture = FALSE;
	}   }

    } else if (lv_key == k_downclickhook  ) {

	xthlF2_Check_hookFns( lv_oval );
	r->lv_downclick_hook = (char*) lv_oval;

    } else if (lv_key == k_draghook       ) {

	xthlF2_Check_hookFns( lv_oval );
	r->lv_drag_hook      = (char*) lv_oval;

    } else if (lv_key == k_upclickhook  ) {

	xthlF2_Check_hookFns( lv_oval );
	r->lv_upclick_hook   = (char*) lv_oval;

    } else if (lv_key == k_selecthook  ) {

	xthlF2_Check_hookFns( lv_oval );
	r->lv_select_hook    = (char*) lv_oval;

    } else if (lv_key == k_deselecthook  ) {

	xthlF2_Check_hookFns( lv_oval );
	r->lv_deselect_hook    = (char*) lv_oval;

    } else if (lv_key == k_reselecthook  ) {

	xthlF2_Check_hookFns( lv_oval );
	r->lv_reselect_hook    = (char*) lv_oval;

    } else if (lv_key == k_redraw  ) {

	r->redraw              = !null(lv_val);

    } else {

	/********************************************/
	/* Ignore unknown key/value pairs.  This    */
	/* lets the application programmer add	    */
	/* arbitrary data to the thinglist for	    */
	/* his/her own purposes.		    */
	/********************************************/
	return FALSE;	/* Keyword not recognized.  */
    }
    return TRUE;	/* Keyword was recognized.  */
}

/* }}} */
/* {{{ xthlAZ_Process_Light_List					*/

xthlAZ_Process_Light_List( r, lights )
gt_tri_rec		  *r;
LVAL			      lights;
{
    int i;
    LVAL here = lights;
    if (null(here))   return; /* Make sure we always have one light. */
    /* Hmm. GT_MAX_LIGHTS is specific to a particular driver, */
    /* doesn't belong here in our machine-independent codde.  */
    /* A buggo to be fixed in due course...		      */
    for (i = 0;   i < GT_MAX_LIGHTS;   ++i) r->light[i] = NULL;
    for (i = 0;   i < GT_MAX_LIGHTS;   ++i, here = cdr(here)) {
	LVAL light;
	if (null(here))  break;
	if (!consp(here))    xlerror("Non-CONS in light list",lights);
	light = car( here );
	if (!xlgtp(light))   xlerror("Non-light in light list",light);
	r->light[i] = xlgt04_Get_Light_Rec( light );
    }
}

/* }}} */
/* {{{ xthlB0_Process_Thing_List					*/

xthlB0_Process_Thing_List( things, default_r, fn, fa )
LVAL			   things;
gt_tri_rec *			   default_r;
int					    (*fn)();
char*						  fa;
/*-
    Process a collection of things.  This fn basically fills in
    a gt_tri_rec once for each thing (point-grl topology-grl model-matrix list)
    and calls a given fn with the result.
-*/
{
    gt_tri_rec r;

    LVAL      err_things = things;
    default_r->default_r = TRUE;

    /* Over all things to be drawn: */
    for (;   !null(things);   things = cdr(things) ) {

	LVAL cell;
        if (!consp( things ))    xlerror("Non-CONS in thinglist",things);
	cell = car( things );

	if (consp(cell)) {

	    /* Initialize our per-thing structure: */
	    r	      = *default_r;
	    default_r->default_r = FALSE;

	    /* Extract the arrays we want from the xtfm/pointgrl/facetgrl list: */
	    xthlB1_Process_Thing( &r, cell );

	    if (!fn(fa,&r,cell)) return FALSE;

	} else if (symbolp(cell)) {

	    things = cdr(things);
	    if (!consp(things)) xlerror("Keyword has no value!",cell);
	    xthlAY_Process_Thinglist_KeyVal_Pair( default_r, cell, car(things) );

	} else {
	    xlerror("Bad thinglist constituent",cell);
	}
    }

    return TRUE;
}

/* }}} */
/* {{{ xthlB1_Process_Thing						*/

xthlB1_Process_Thing( r, thing )
gt_tri_rec           *r;
LVAL		         thing;
/*-
    Fill in a gt_tri_rec from an thinglist.
-*/
{
    LVAL key;
    LVAL val;

    for (;   !null(thing);   thing = cdr(thing) ) {
	char* badcons = "Non-CONS in thing"      ;

	if (!consp( thing))    xlerror( badcons, thing );

	key   = car(thing);

	thing = cdr(thing);
	if (!consp( thing))    xlerror( badcons, thing );
	val   = car(thing);

	xthlAY_Process_Thinglist_KeyVal_Pair( r, key, val );
    }
}

/* }}} */
/* {{{ xthlB2_Figure_Got_Fields						*/

xthlB2_Figure_Got_Fields( r )
gt_tri_rec               *r;
{
    r->got_points = (
        r->x   != NULL &&
        r->y   != NULL &&
        r->z   != NULL
    );
    r->got_segments = (
        r->f0  != NULL &&
        r->f1  != NULL
    );
    r->got_triangles = (
        r->got_segments &&
        r->f2  != NULL
    );
    r->got_rectangles = (
        r->got_triangles &&
        r->f3  != NULL
    );
    r->got_facet_normals = (
        r->fnx != NULL &&
        r->fny != NULL &&
        r->fnz != NULL
    );
    r->got_point_normals = (
        r->pnx != NULL &&
        r->pny != NULL &&
        r->pnz != NULL
    );
    r->got_facet_colors = (
        r->fr  != NULL &&
        r->fg  != NULL &&
        r->fb  != NULL
    );
    r->got_point_colors = (
        r->pr  != NULL &&
        r->pg  != NULL &&
        r->pb  != NULL
    );
    r->got_point_textures = (
        r->ptu != NULL &&
        r->ptv != NULL
    );
    r->got_facet_textures = (
	r->ftu0 != NULL &&
        r->ftv0 != NULL
    );
    if (r->got_segments) {
        r->got_facet_textures = (
            r->got_facet_textures &&
	    r->ftu1 != NULL &&
	    r->ftv1 != NULL
	);
    }
    if (r->got_triangles) {
        r->got_facet_textures = (
            r->got_facet_textures &&
	    r->ftu2 != NULL &&
	    r->ftv2 != NULL
	);
    }
    if (r->got_rectangles) {
        r->got_facet_textures = (
            r->got_facet_textures &&
	    r->ftu3 != NULL &&
	    r->ftv3 != NULL
	);
    }
    r->got_facet_neighbors = (
	r->fn0 != NULL
    );
    if (r->got_segments) {
        r->got_facet_neighbors = (
            r->got_facet_neighbors &&
	    r->fn1 != NULL
	);
    }
    if (r->got_triangles) {
        r->got_facet_neighbors = (
            r->got_facet_neighbors &&
	    r->fn2 != NULL
	);
    }
    if (r->got_rectangles) {
        r->got_facet_neighbors = (
            r->got_facet_neighbors &&
	    r->fn3 != NULL
	);
    }



    /* Now check flags saying to ignore some of this: */

    if ((LVAL)(r->lv_use_colors) == k_on_facets) {
	r->got_point_colors = FALSE;
    }
    if ((LVAL)(r->lv_use_colors) == k_on_points) {
	r->got_facet_colors = FALSE;
    }
    if ((LVAL)(r->lv_use_colors) == NIL) {
	r->got_point_colors = FALSE;
	r->got_facet_colors = FALSE;
    }

    if ((LVAL)(r->lv_use_normals) == k_on_facets) {
	r->got_point_normals = FALSE;
    }
    if ((LVAL)(r->lv_use_normals) == k_on_points) {
	r->got_facet_normals = FALSE;
    }
    if ((LVAL)(r->lv_use_normals) == NIL) {
	r->got_point_normals = FALSE;
	r->got_facet_normals = FALSE;
    }
}

/* }}} */
/* {{{ xthlB3_Fill_Tri_Rec_From_Grl                                     */

xthlB3_Fill_Tri_Rec_From_Grl( r, grl )
gt_tri_rec*                   r;
LVAL                             grl; 
{
    /* Find our list of arrays: */
    LVAL*pArrayList;
    LVAL prop_cell;
    LVAL valu_cell;
    int  prev_fLen = r->fLen;
    int  prev_pLen = r->pLen;
    if (!xthl87_GetAddressOfObjectVariableValue(
        grl,
        getclass( grl ),
        s_arraylist,
        &pArrayList
    )) {
        xlbadtype( grl );/* No arraylist! Should not be user-triggerable. */
    }

    /* Enter all recognized arrays into r, validating type and length: */
    prop_cell = *pArrayList;
    while (consp(prop_cell) && consp(valu_cell=cdr(prop_cell))) {
        xthlC1_Note_Tri_Rec_Entry( r, car(prop_cell), car(valu_cell) );
        prop_cell = cdr( valu_cell );
    }

    /* Reset r->fLen/pLen according to grl fill pointers if present: */
    if (r->fLen != prev_fLen) {
	int i;
        csry_rec* h = xsry9c_Find_Immediate_Base( grl );
	if (h->rank == 1   &&   (i=h->dim[1]) >= 0) {
	    r->fLen = i;
	}
    }
    if (r->pLen != prev_pLen) {
	int i;
        csry_rec* h = xsry9c_Find_Immediate_Base( grl );
	if (h->rank == 1   &&   (i=h->dim[1]) >= 0) {
	    r->pLen = i;
	}
    }
    xthlB2_Figure_Got_Fields( r );
}

/* }}} */
/* {{{ xthlC2_Init_Tri_Rec -- Initialize a gt_tri_rec record.           */

#define C1_Need_X01V   (1)
#define C1_Need_X32V   (2)
#define C1_Need_XFLV   (3)
#define C1_Need_XF8V   (4)
xthlC0_Check_Array_Type( v_as_lval, which_check )
LVAL                     v_as_lval;
int                                 which_check;
{
    switch (which_check) {
    case C1_Need_X01V:
	if (!x01vp( v_as_lval ))   xlerror( "Must be bit array",   v_as_lval );
	break;
    case C1_Need_X32V:
	if (!x32vp( v_as_lval ))   xlerror( "Must be int32 array", v_as_lval );
	break;
    case C1_Need_XFLV:
	if (!xflvp( v_as_lval ))   xlerror( "Must be float array", v_as_lval );
	break;
    case C1_Need_XF8V:
	if (!xf8vp( v_as_lval ))   xlerror( "Must be 8-bit-float array", v_as_lval );
	break;
    default:
	abort();
    }
}
xthlC1_Note_Tri_Rec_Entry( r, key, val )
gt_tri_rec*                r;
LVAL			      key, val;
{
    typedef unsigned char u8;

    /* Stick an entry in a triangle record: */
    if        (key    == k_pointif   ||   key == (LVAL) r->lv_point_if) {
	r->doPoint    = (char*) xthlC3_Check_PLen( r, val, C1_Need_X01V );
    } else if (key    == k_pointx) {
	r->x          =         xthlC3_Check_PLen( r, val, C1_Need_XFLV );
    } else if (key    == k_pointy) {
	r->y          =         xthlC3_Check_PLen( r, val, C1_Need_XFLV );
    } else if (key    == k_pointz) {
	r->z          =         xthlC3_Check_PLen( r, val, C1_Need_XFLV );
    } else if (key    == k_pointtextureu) {
	r->ptu        =         xthlC3_Check_PLen( r, val, C1_Need_XFLV );
    } else if (key    == k_pointtexturev) {
	r->ptv        =         xthlC3_Check_PLen( r, val, C1_Need_XFLV );
    } else if (key    == k_facettextureu0) {
	r->ftu0       =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key    == k_facettexturev0) {
	r->ftv0       =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key    == k_facettextureu1) {
	r->ftu1       =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key    == k_facettexturev1) {
	r->ftv1       =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key    == k_facettextureu2) {
	r->ftu2       =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key    == k_facettexturev2) {
	r->ftv2       =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key    == k_facettextureu3) {
	r->ftu3       =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key    == k_facettexturev3) {
	r->ftv3       =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key    == k_pointnormalx) {
	r->pnx        =         xthlC3_Check_PLen( r, val, C1_Need_XFLV );
    } else if (key    == k_pointnormaly) {
	r->pny        =         xthlC3_Check_PLen( r, val, C1_Need_XFLV );
    } else if (key    == k_pointnormalz) {
	r->pnz        =         xthlC3_Check_PLen( r, val, C1_Need_XFLV );
    } else if (key    == k_pointred) {
	r->pr         = (u8*)   xthlC3_Check_PLen( r, val, C1_Need_XF8V );
    } else if (key    == k_pointgreen) {
	r->pg         = (u8*)   xthlC3_Check_PLen( r, val, C1_Need_XF8V );
    } else if (key    == k_pointblue) {
	r->pb         = (u8*)   xthlC3_Check_PLen( r, val, C1_Need_XF8V );
    } else if (key    == k_facetif   ||   key == (LVAL) r->lv_facet_if) {
	r->doFacet = (char*) xthlC4_Check_FLen( r, val, C1_Need_X01V );
    } else if (key    == k_facet0) {
	r->f0         = (int*)  xthlC4_Check_FLen( r, val, C1_Need_X32V );
    } else if (key    == k_facet1) {
	r->f1         = (int*)  xthlC4_Check_FLen( r, val, C1_Need_X32V );
    } else if (key    == k_facet2) {
	r->f2         = (int*)  xthlC4_Check_FLen( r, val, C1_Need_X32V );
    } else if (key    == k_facet3) {
	r->f3         = (int*)  xthlC4_Check_FLen( r, val, C1_Need_X32V );
    } else if (key    == k_facetneighbor0) {
	r->fn0        = (int*)  xthlC4_Check_FLen( r, val, C1_Need_X32V );
    } else if (key    == k_facetneighbor1) {
	r->fn1        = (int*)  xthlC4_Check_FLen( r, val, C1_Need_X32V );
    } else if (key    == k_facetneighbor2) {
	r->fn2        = (int*)  xthlC4_Check_FLen( r, val, C1_Need_X32V );
    } else if (key    == k_facetneighbor3) {
	r->fn3        = (int*)  xthlC4_Check_FLen( r, val, C1_Need_X32V );
    } else if (key    == k_facetnormalx) {
	r->fnx        =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key == k_facetnormaly) {
	r->fny        =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key == k_facetnormalz) {
	r->fnz        =         xthlC4_Check_FLen( r, val, C1_Need_XFLV );
    } else if (key == k_facetred) {
	r->fr         = (u8*)   xthlC4_Check_FLen( r, val, C1_Need_XF8V );
    } else if (key == k_facetgreen) {
	r->fg         = (u8*)   xthlC4_Check_FLen( r, val, C1_Need_XF8V );
    } else if (key == k_facetblue) {
	r->fb         = (u8*)   xthlC4_Check_FLen( r, val, C1_Need_XF8V );
    } else if (key == k_pixelred) {
        if (r->doing_texture) {
	    r->texture_red =    xthlCa_Check_RLen( r, val, C1_Need_XF8V, key );
	} else {
	    r->raster_red  =    xthlCa_Check_RLen( r, val, C1_Need_XF8V, key );
	}
    } else if (key == k_pixelgreen) {
        if (r->doing_texture) {
	    r->texture_grn =    xthlCa_Check_RLen( r, val, C1_Need_XF8V, key );
	} else {
	    r->raster_grn  =    xthlCa_Check_RLen( r, val, C1_Need_XF8V, key );
	}
    } else if (key == k_pixelblue) {
        if (r->doing_texture) {
	    r->texture_blu =    xthlCa_Check_RLen( r, val, C1_Need_XF8V, key );
	} else {
	    r->raster_blu  =    xthlCa_Check_RLen( r, val, C1_Need_XF8V, key );
	}
    } else {
	/* Must allow graphic relations to have unknown arrays: */
/*	xlbadtype(key); */
    }
}

xthlC2_Init_Tri_Rec( r, view, proj, viewing_mat_inv )
gt_tri_rec*          r;
LVAL			view, proj;
ctfm_rec*                           viewing_mat_inv;
{
    extern LVAL true;

    /* Set up default values in our argument record: */
    r->pLen = r->fLen                  =   -1;
    r->x    = r->y    = r->z           = NULL;
    r->pnx  = r->pny  = r->pnz         = NULL;
    r->ptu  = r->ptv                   = NULL;
    r->pr   = r->pg   = r->pb          = NULL;
    r->doPoint                         = NULL;
    r->f0   = r->f1   = r->f2  = r->f3 = NULL;
    r->fnx  = r->fny  = r->fnz         = NULL;
    r->ftu0 = r->ftv0                  = NULL;
    r->ftu1 = r->ftv1                  = NULL;
    r->ftu2 = r->ftv2                  = NULL;
    r->ftu3 = r->ftv3                  = NULL;
    r->fn0  = r->fn1  = r->fn2 = r->fn3= NULL;
    r->fr   = r->fg   = r->fb          = NULL;
    r->doFacet			       = NULL;
    r->model          =		         NULL;
    r->view           =		         NULL;
    r->perspective    =		         NULL;
    r->drop_backfaces =			FALSE;

    r->fix_lights_on_object =		FALSE;

    r->raster_xSize   =			    0;
    r->raster_ySize   =			    0;
    r->raster_red     =			 NULL;
    r->raster_grn     =			 NULL;
    r->raster_blu     =			 NULL;

    r->texture_xSize  =			    0;
    r->texture_ySize  =			    0;
    r->texture_red    =			 NULL;
    r->texture_grn    =			 NULL;
    r->texture_blu    =			 NULL;

    r->lv_downclick_hook =	(char*)	  NIL;
    r->lv_drag_hook      =	(char*)	  NIL;
    r->lv_upclick_hook   =	(char*)	  NIL;
    r->lv_select_hook	 =	(char*)	  NIL;
    r->lv_deselect_hook	 =	(char*)	  NIL;
    r->lv_reselect_hook	 =	(char*)	  NIL;

    r->lv_use_normals    =      (char*)  true;
    r->lv_use_colors     =      (char*)  true;
    r->lv_pick_as	 =	(char*)	k_solid;
    r->redraw		 =		  TRUE;

    r->lv_facet_if	 =	(char*)	  NIL;
    r->lv_point_if	 =	(char*)	  NIL;

    r->default_r	 =		 FALSE; /* xshp.c needs this default */
    r->doing_texture	 =		 FALSE;

    r->which_bitplanes	 =  GT_RGB_BITPLANES;

    r->texture		 =		  NULL;
    {   extern cmtl_rec xmtl_defaults;
	r->material   =		         &xmtl_defaults.r;
    }
    {   extern cmdl_rec xmdl_defaults;
	r->light_model=		         &xmdl_defaults.r;
    }
    {   int i;
	extern clgt_rec xlgt_defaults;
	for (i = GT_MAX_LIGHTS;   i --> 0; ) {
	    r->light[ i ] = NULL;
	}
	r->light[0]   =		         &xlgt_defaults.r;
    }

    /* Find our transforms: */
    if (!null(view)) {
	ctfm_rec* viewing_mat = xtfm9c_Find_Immediate_Base( view );

	*viewing_mat_inv = *viewing_mat;
	ctfm44_Invert_Matrix( &viewing_mat_inv->m, &viewing_mat->m );

        r->view        = (gt_mat*) &viewing_mat_inv->m;
    }
    if (!null(proj)) {
	ctfm_rec* persp_mat   = xtfm9c_Find_Immediate_Base( proj );
        r->perspective = (gt_mat*) &persp_mat->m ;
    }
    xthlB2_Figure_Got_Fields( r );
}

float* xthlC3_Check_PLen( r, v_as_lval, which_check )
gt_tri_rec*               r;
LVAL                         v_as_lval;
int	                                which_check;
{
    /* Check that point array is the right length and type, and return it: */
    float*    p = (float   *)   csry_base( v_as_lval );
    csry_rec* h = xsry9c_Find_Immediate_Base( v_as_lval );

    /* Figure array size, respecting fillpointers: */
    int pLen    = (h->rank==1 && h->dim[1] >= 0) ? h->dim[1] : h->size;
    xthlC0_Check_Array_Type( v_as_lval, which_check );
    if (r->pLen == -1) {
        r->pLen = pLen;
    } else if (pLen != r->pLen) {
	char buf[ 128 ];
	sprintf( buf, "Pntgrl array len==%d, should be %d", pLen, r->pLen );
	xlerror( buf, v_as_lval );
    }
    return p;
}
float* xthlC4_Check_FLen( r, v_as_lval, which_check )
gt_tri_rec*               r;
LVAL                         v_as_lval;
int                                     which_check;
{
    /* Check that triangle array is right length and type, and return it: */
    float*    p = (float   *)   csry_base( v_as_lval );
#ifdef OLD
    csry_rec* h = (csry_rec*) gobjimmbase( v_as_lval );
#else
    csry_rec* h = xsry9c_Find_Immediate_Base( v_as_lval );
#endif
    /* Figure array size, respecting fillpointers: */
    int fLen    = (h->rank==1 && h->dim[1] >= 0) ? h->dim[1] : h->size;
    xthlC0_Check_Array_Type( v_as_lval, which_check );
    if (r->fLen == -1) {
        r->fLen = fLen;
    } else if (fLen != r->fLen) {
	char buf[ 128 ];
	sprintf( buf, "Fctgrl array len==%d, should be %d", fLen, r->fLen );
	xlerror( buf, v_as_lval );
    }
    return p;
}

/* Index arrays into pixel buffers: */

/* For generic image arrays to be drawn: */
int             xthlCb_size = 0;
unsigned char** xthlCc_red  = NULL;
unsigned char** xthlCd_grn  = NULL;
unsigned char** xthlCe_blu  = NULL;

/* For global-level texture image arrays: */
int             xthlCg_size = 0;
unsigned char** xthlCh_red  = NULL;
unsigned char** xthlCi_grn  = NULL;
unsigned char** xthlCj_blu  = NULL;

/* For  local-level texture image arrays: */
int             xthlCl_size = 0;
unsigned char** xthlCm_red  = NULL;
unsigned char** xthlCn_grn  = NULL;
unsigned char** xthlCo_blu  = NULL;

unsigned char** xthlCa_Check_RLen( r, v_as_lval, which_check, key )
gt_tri_rec*                        r;
LVAL                                  v_as_lval;
int                                              which_check;
LVAL                                                          key;
{
    /* Default to generic image index arrays: */
    int*             pSiz = &xthlCb_size;
    unsigned char*** pRed = &xthlCc_red;
    unsigned char*** pGrn = &xthlCd_grn;
    unsigned char*** pBlu = &xthlCe_blu;

    /* Default to generic image return-parameter size arrays: */
    int* pXSize = &r->raster_xSize;
    int* pYSize = &r->raster_ySize;

    /* Check that raster array is the right length */
    /* and type, and return a row-index to it:     */
    unsigned char* p = (unsigned char*)   csry_base( v_as_lval );
    unsigned char**q;
    csry_rec* h = xsry9c_Find_Immediate_Base( v_as_lval );
    if (h->rank != 2 || h->dim[0] < 1  ||  h->dim[1] < 1) {
	xlerror("pixel raster not two-dimensional",v_as_lval);
    }
    xthlC0_Check_Array_Type( v_as_lval, which_check );

    /* If we're doing a texture, use one of the two  */
    /* alternate index array sets, to avoid conflict */
    /* between current image to draw, current global */
    /* texture, and current local-to-thing texture:  */
    if (r->doing_texture) {
        pXSize = &r->texture_xSize;
	pYSize = &r->texture_ySize;
	if (r->default_r) {
	    pSiz = &xthlCg_size;
	    pRed = &xthlCh_red;
	    pGrn = &xthlCi_grn;
	    pBlu = &xthlCj_blu;
	} else {
	    pSiz = &xthlCl_size;
	    pRed = &xthlCm_red;
	    pGrn = &xthlCn_grn;
	    pBlu = &xthlCo_blu;
    }   }

    if (*pXSize == 0   &&
	*pYSize == 0
    ) { int siz = h->dim[0] * sizeof(unsigned char*);

	/* Remember shape of pixel array: */
	*pXSize = h->dim[1];
	*pYSize = h->dim[0];
	
	/* Re/allocate pixel-array indices, as needed: */
	if (!*pSiz) {
	    *pSiz = h->dim[0];
	    *pRed = (unsigned char**) malloc( siz );
	    *pGrn = (unsigned char**) malloc( siz );
	    *pBlu = (unsigned char**) malloc( siz );
	} else if (*pSiz < h->dim[0]) {
	    *pSiz = h->dim[0];
	    *pRed = (unsigned char**) realloc( (char*)xthlCc_red, siz );
	    *pGrn = (unsigned char**) realloc( (char*)xthlCd_grn, siz );
	    *pBlu = (unsigned char**) realloc( (char*)xthlCe_blu, siz );
	}
	if (*pRed == NULL ||
	    *pGrn == NULL ||
	    *pBlu == NULL
	) {
	    xlfail("out of ram");
	}

    } else if (*pXSize != h->dim[1] ||	*pYSize != h->dim[0]) {

	char buf[ 128 ];
	sprintf(
	    buf,
	    "Raster array size is %dx%x, should be %dx%d",
	    h->dim[1], h->dim[0],
	    *pYSize, *pXSize
	);
	xlerror( buf, v_as_lval );
    }

    /* Select which index array to use: */
    if      (key == k_pixelred  )   q = *pRed;
    else if (key == k_pixelgreen)   q = *pGrn;
    else if (key == k_pixelblue )   q = *pBlu;
    else                            abort();

    /* Fill in the index.  The index is intended to allow us to */
    /* display any subrectangle of the full image, although we  */
    /* don't actually implement a user interface to this yet... */
    {   int i;
	for (i = h->dim[0];   i --> 0;   ) {
	    q[ i ] = p  +  i * h->dim[1];
    }   }

    return q;
}

/* }}} *//* {{{ xthlE6_GetNumericProp						*/

float xthlE6_GetNumericProp( propList, prop, default_val )
LVAL 		             propList;
int				       prop;
float				 	     default_val;
{
    LVAL xthl80_FindProp();
    LVAL lv_num;
    LVAL pair = xthl80_FindProp( propList, prop );
    if ( pair == NIL)   return default_val;
    return xgbj00_Get_Fix_Or_Flo_Num(car(pair));
}

/* }}} */
/* {{{ xthlEc_Error_If_Not_FloatVector					*/

xthlEc_Error_If_Not_FloatVector( obj, sym )
LVAL				 obj, sym;
{    
    if (!xflvp(obj))   xlerror("Need float-array for",sym);
    xthlEe_Error_If_Not_Rank_1( obj, sym );
}

/* }}} */
/* {{{ xthlEd_Error_If_Not_Int32Vector					*/

xthlEd_Error_If_Not_Int32Vector( obj, sym )
LVAL				 obj, sym;
{    
    if (!x32vp(obj))   xlerror("Need int32-array for",sym);
    xthlEe_Error_If_Not_Rank_1( obj, sym );
}

/* }}} */
/* {{{ xthlEg_Error_If_Not_8BitFloatVector				*/

xthlEg_Error_If_Not_8BitFloatVector( obj, sym )
LVAL				     obj, sym;
{
    if (!xf8vp(obj))   xlerror("Need 16-bit-float-array for",sym);
    xthlEe_Error_If_Not_Rank_1( obj, sym );
}

/* }}} */
/* {{{ xthlEh_Error_If_Not_FloatArray					*/

xthlEh_Error_If_Not_FloatArray( obj, sym )
LVAL				obj, sym;
{    
    if (!xflvp(obj))   xlerror("Need float-array for",sym);
}
 
/* }}} */
/* {{{ xthlEi_Error_If_Not_Int32Array					*/

xthlEi_Error_If_Not_Int32Array( obj, sym )
LVAL				obj, sym;
{    
    if (!x32vp(obj))   xlerror("Need int32-array for",sym);
}

/* }}} */
/* {{{ xthlEj_Error_If_Not_8BitFloatArray				*/

xthlEj_Error_If_Not_8BitFloatArray( obj, sym )
LVAL				    obj, sym;
{
    if (!xf8vp(obj))   xlerror("Need 8-bit-float-array for",sym);
}

/* }}} */
/* {{{ xthlEe_Error_If_Not_Rank_1					*/

xthlEe_Error_If_Not_Rank_1( obj, sym )
LVAL			    obj, sym;
{
#ifdef OLD
    csry_rec * h = (csry_rec*) gobjimmbase( obj );
#else
    csry_rec* h = xsry9c_Find_Immediate_Base( obj );
#endif
    if (h->rank != 1)   xlerror( "Need rank 1 for", sym );
}

/* }}} */
/* {{{ xthlEf_Resize_Grl						*/

xthlEf_Resize_Grl( grl, newSlotsNeeded )
LVAL		   grl;
int			newSlotsNeeded;
{    
    /*************************************************************/
    /* We are given a graphic relation, guaranteed to be rank 1, */
    /* plus the number of entries caller intends to add to it.   */
    /* We make sure there is enough room, resizing grl if need   */
    /* be, set the fill pointer to the *end* of the allocated    */
    /* region, and return the *start* of the allocated region.   */
    /*************************************************************/
    csry_rec* h_grl = xsry9c_Find_Immediate_Base( grl );
    int		oldSize  = h_grl->dim[0];
    LVAL	shape;
    int		base;
    int		newFillPointer;

    /* Allocated region starts at fill-pointer, else end of relation: */
    if (h_grl->dim[1] < 0)   base = h_grl->dim[0];  /* Have no fill-pointer. */
    else		     base = h_grl->dim[1];  /* Have a  fill-pointer. */

    /* Enlarge relation if needed: */
    newFillPointer	= base + newSlotsNeeded;
    shape		= cvfixnum( newFillPointer );
    if (newFillPointer > oldSize) {

	/* Enlarge relation: */
	csry_rec   h_new;
	h_new        = *h_grl;
	h_new.dim[0] = newFillPointer;
	xlprot1( shape ); /* Maybe not needed, but good insurance. */
	xgrl22_AdjustArray( grl, &h_new, shape );    
	xlpop();
    }

    /* Set new fill-pointer: */
    xgrl30_Fill_Pointer( grl, shape );

    return base;	/* The call a volcano answered. */
}
 
/* }}} */
/* {{{ xthlF3_Get_Hook_Fns -- Read valid argument for Call_hookFn	*/

xthlF1_Check_hookFn( fun )
LVAL                 fun;
{
    /* This replicates an unfortunate amount of xlapply logic, */
    /* to avoid tinkering with xcore files while giving prompt */
    /* error messages ... we *could* just let xlapply catch    */
    /* these ... maybe should?                                 */
    extern LVAL s_lambda;
    if (symbolp(fun)) {
	LVAL val;
	while ((val = getfunction(fun)) == s_unbound) {
	    xlfunbound(fun);
	}
        if (null(val)) {
	    xlerror("getfunction(hook-fn symbol) is null",fun);
	}
	fun = val;
    }

    /* check for nil */
    if (null(fun))   xlfail("null hook function");

    /* dispatch on node type */
    switch (ntype(fun)) {
    case SUBR:
	break;
    case CONS:
	if (!consp(cdr(fun))  ||
	    car(fun) != s_lambda
	) {
	    xlerror("Hook fn list not a valid LAMBDA?!",fun);
	} else {
	    xlerror(
		"For efficiency, hook fn should be closure, not lambda list",
		fun
	    );
	}
	break;
    case CLOSURE:
	if (gettype(fun) != s_lambda) {
	    xlerror("hook fn is bad closure -- likely a macro",fun);
	}
	break;
    default:
	xlerror("unrecognizable type of hook function",fun);
    }
}
xthlF2_Check_hookFns( arg )
LVAL                  arg;
{   if     (! null(arg)) {
	if (!consp(arg)) {
	    xthlF1_Check_hookFn( arg );
	} else {
	    LVAL hook = arg;	    
	    for (;  consp(hook);   hook = cdr(hook)) {
		xthlF1_Check_hookFn( car(hook) );
    }   }   }
}
LVAL xthlF3_Get_hookFns()
{   LVAL                  arg = xlgetarg();
    xthlF2_Check_hookFns( arg );
    return                arg;
}

/* }}} */
/* {{{ xthlF6_Call_HookFns_Fn -- Iterate over all hooks in a hooklist.	*/

xthlF4_Call_HookFn(fun)
LVAL               fun;
{   LVAL *newfp;
    newfp = xlsp;
    pusharg(cvfixnum((FIXTYPE)(newfp - xlfp)));
    pusharg(fun);
    pusharg(cvfixnum((FIXTYPE)0));
    xlfp = newfp;
    return (xlapply(0) != NIL);
}
LVAL xthlF5_Call_HookFns( lv_hook )
LVAL		          lv_hook;
{
    if (symbolp(lv_hook)) {
	LVAL lv = getfunction( lv_hook );
	if (lv != s_unbound)   lv_hook = lv;
	else                   lv_hook = getvalue( lv_hook );
    }
    if (null(lv_hook) || lv_hook == s_unbound) {
        return NIL;
    }
    if (!consp(lv_hook)) {
        xthlF4_Call_HookFn( lv_hook );
    } else { 
	for (;  consp(lv_hook);   lv_hook = cdr(lv_hook)) {
	    xthlF4_Call_HookFn( car(lv_hook) );
    }   }
    return NIL;
}
LVAL xthlF6_Call_HookFns_Fn()
{   LVAL lv_hook = xlgetarg();
    xllastarg(); 
    return xthlF5_Call_HookFns( lv_hook );
}

/* }}} */
/* {{{ xthlG0_Get_Fn--Fetch named property from disembodied propertylist*/

LVAL xthlG0_Get_Fn()
{   LVAL plist = xlgalist();
    LVAL prop  = xlgetarg();
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    return xthl74_GetProp( &plist, prop, default_val, got_default );
}

/* }}} */
/* {{{ xthlG1_Set_Fn--Store named property into disembodied propertylist*/

LVAL xthlG1_Set_Fn()
{
    LVAL plist = xlgalist();
    LVAL prop  = xlgetarg();
    LVAL val   = xlgetarg();
    xllastarg();
    xthl82_SetProp( &plist, prop, val );
    return plist;
}

/* }}} */
/* {{{ xthlG2_Rem_Fn--Remove named property from disembodied proplist.	*/

LVAL xthlG2_Rem_Fn()
{
    LVAL plist = xlgalist();
    LVAL prop  = xlgetarg();
    xllastarg();
    xthl83_RemProp( &plist, prop );
    return plist;
}

/* }}} */
/* {{{ xthlG3_Length_Fn--Return number of prop-val PAIRS in propertylist*/

LVAL xthlG3_Length_Fn()
{
    LVAL plist = xlgalist();
    xllastarg();
    return cvfixnum( x03d89_PropListLength( plist ) );
}

/* }}} */
/* {{{ xthlG4_Nth_Fn--Return property name from Nth prop-val pairs.	*/

LVAL xthlG4_Nth_Fn()
{
    LVAL plist = xlgalist();
    LVAL n     = xlgafixnum();
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    return xthl93_ListNth( plist, getfixnum(n), n, default_val, got_default );
}

/* }}} */
/* {{{ xthlG7_Copy_List - Return one-deep copy of list.			*/

LVAL xthlG7_Copy_List( lv_list )
LVAL                   lv_list;
{
    if (!consp(lv_list))   return lv_list;

    return cons(
	car(lv_list),
	xthlG7_Copy_List( cdr(lv_list) )
    );
}

/* }}} */
/* {{{ xthlG8_DeepCopy_List - Copy all conses reachable from 'lv_list'.	*/

LVAL xthlG8_DeepCopy_List( lv_list )
LVAL                       lv_list;
{
    if (!consp(lv_list))   return lv_list;

    return cons(
	xthlG8_DeepCopy_List( car(lv_list) ),
	xthlG8_DeepCopy_List( cdr(lv_list) )
    );
    
}

/* }}} */
/* {{{ xthlH1_Get_A_Point_GRL -- Get grl with :POINT-X/Y/Z.		*/

LVAL xthlH0_Check_A_Point_GRL( x, y, z, point_grl ) /* Also called from xcmr... */
LVAL			      *x,*y,*z, point_grl;
{
    LVAL*p_pArrayList = (LVAL *) xgrl13_pArrayList( point_grl );

    LVAL lv_point_x   = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointx );
    LVAL lv_point_y   = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointy );
    LVAL lv_point_z   = (LVAL)   xgrl39_GetArray( p_pArrayList, k_pointz );

    xthlEc_Error_If_Not_FloatVector( lv_point_x, k_pointx );
    xthlEc_Error_If_Not_FloatVector( lv_point_y, k_pointy );
    xthlEc_Error_If_Not_FloatVector( lv_point_z, k_pointz );

    *x = lv_point_x;
    *y = lv_point_y;
    *z = lv_point_z;

    return point_grl;
}
LVAL xthlH1_Get_A_Point_GRL( x, y, z ) /* Also called from xcmr... */
LVAL			    *x,*y,*z;
{
    return xthlH0_Check_A_Point_GRL( x, y, z, xgrl01_Get_A_XGRL() );
}

/* }}} */
/* {{{ xthlH3_Get_A_Facet_GRL -- Get grl with :FACET-0/1/2/3.		*/

LVAL xthlH2_Check_A_Facet_GRL( f0, f1, f2, f3, req, facet_grl )
LVAL			      *f0,*f1,*f2,*f3;
int					       req;  /* Require this many. */
LVAL						    facet_grl;
{
    /* We return a grl with at least 'req' facet0/1/2/3 arrays.   */
    /* and set *f0/1/2/3 to the facet0/1/2/3 if present else NIL. */
    LVAL*p_pArrayList = (LVAL *) xgrl13_pArrayList( facet_grl );

    LVAL lv_facet_0;
    LVAL lv_facet_1;
    LVAL lv_facet_2;
    LVAL lv_facet_3;

    lv_facet_0 = (LVAL) xthl74_GetProp( p_pArrayList, k_facet0, NIL, req <= 0 );
    lv_facet_1 = (LVAL) xthl74_GetProp( p_pArrayList, k_facet1, NIL, req <= 1 );
    lv_facet_2 = (LVAL) xthl74_GetProp( p_pArrayList, k_facet2, NIL, req <= 2 );
    lv_facet_3 = (LVAL) xthl74_GetProp( p_pArrayList, k_facet3, NIL, req <= 3 );

    if (!null(lv_facet_0)) xthlEd_Error_If_Not_Int32Vector( lv_facet_0, k_facet0 );
    if (!null(lv_facet_1)) xthlEd_Error_If_Not_Int32Vector( lv_facet_1, k_facet1 );
    if (!null(lv_facet_2)) xthlEd_Error_If_Not_Int32Vector( lv_facet_2, k_facet2 );
    if (!null(lv_facet_3)) xthlEd_Error_If_Not_Int32Vector( lv_facet_3, k_facet3 );

    *f0 = lv_facet_0;
    *f1 = lv_facet_1;
    *f2 = lv_facet_2;
    *f3 = lv_facet_3;

    return facet_grl;
}
LVAL xthlH3_Get_A_Facet_GRL( f0, f1, f2, f3, req ) /* Also called from xcmr... */
LVAL			    *f0,*f1,*f2,*f3;
int					     req;  /* Require this many. */
{
    return xthlH2_Check_A_Facet_GRL( f0, f1, f2, f3, req, xgrl01_Get_A_XGRL() );
}

/* }}} */
/* {{{ xthlH6_Get_A_Point_GRL_Plus_Index--Get :POINT-X/Y/Z grl plus idx.*/

xthlH6_Get_A_Point_GRL_Plus_Index( r )
cthl_point			  *r;
{
    r     ->lv_grl   = xthlH1_Get_A_Point_GRL(
	&r->lv_arrayX,
	&r->lv_arrayY,
	&r->lv_arrayZ
    );
    r     ->lv_index = xthlI9_Get_A_GRL_Index( r->lv_grl   );
    r     ->   index = getfixnum(              r->lv_index );
    /* We leave validating index wrt arrayX/Y/Z until	*/
    /* we do the actual point-store, to guard against	*/
    /* resizing in the interim...			*/
}

/* }}} */
/* {{{ xthlI5_Fetch_Point_From_GRL_Triple--Get a pt, usually :POINTX/Y/Z*/

xthlI5_Fetch_Point_From_GRL_Triple( r, pt )
cthl_point			   *r;
geo_point			      *pt;
{
    float* arrayX = (float*) (csry_base( r->lv_arrayX ));
    float* arrayY = (float*) (csry_base( r->lv_arrayY ));
    float* arrayZ = (float*) (csry_base( r->lv_arrayZ ));

    xthlI7_Check_A_GRL_Index( r->lv_arrayX, r->index );
    xthlI7_Check_A_GRL_Index( r->lv_arrayY, r->index );
    xthlI7_Check_A_GRL_Index( r->lv_arrayZ, r->index );

    pt->x = arrayX[ r->index ];
    pt->y = arrayY[ r->index ];
    pt->z = arrayZ[ r->index ];
}

/* }}} */
/* {{{ xthlI6_Store_Point_In_GRL_Triple--Store pt, prolly in :POINTX/Y/Z*/

xthlI6_Store_Point_In_GRL_Triple( r, pt )
cthl_point			 *r;
geo_point			    *pt;
{
    float* arrayX = (float*) (csry_base( r->lv_arrayX ));
    float* arrayY = (float*) (csry_base( r->lv_arrayY ));
    float* arrayZ = (float*) (csry_base( r->lv_arrayZ ));

    xthlI7_Check_A_GRL_Index( r->lv_arrayX, r->index );
    xthlI7_Check_A_GRL_Index( r->lv_arrayY, r->index );
    xthlI7_Check_A_GRL_Index( r->lv_arrayZ, r->index );

    arrayX[ r->index ] = pt->x;
    arrayY[ r->index ] = pt->y;
    arrayZ[ r->index ] = pt->z;
}

/* }}} */
/* {{{ xthlI7_Check_A_GRL_Index -- Validate integer index to given grl.	*/

xthlI7_Check_A_GRL_Index( grl, index )
LVAL			  grl;
int			       index;
{
#ifdef OLD
    csry_rec*h = (csry_rec*) gobjimmbase( grl );
#else
    csry_rec*h = xsry9c_Find_Immediate_Base( grl );
#endif
    if (index < 0   ||   index > h->size) {
	xlerror( "Grl index out of range", cvfixnum( index ));
    }
    return index;
}

/* }}} */
/* {{{ xthlI8_Check_A_GRL_Index -- Validate  fixnum index to given grl.	*/

LVAL xthlI8_Check_A_GRL_Index( grl, lv_index )
LVAL			       grl, lv_index;
{
    xthlI7_Check_A_GRL_Index( grl, getfixnum( lv_index ) );
    return lv_index;
}

/* }}} */
/* {{{ xthlI9_Get_A_GRL_Index   -- Get valid fixnum index to given grl.	*/

LVAL xthlI9_Get_A_GRL_Index( grl ) /* Also called from xcmr... */
LVAL			     grl;
{
    return xthlI8_Check_A_GRL_Index( grl, xlgafixnum() );
}

/* }}} */
/* {{{ xthlJ2_EmptyThing_Fn     -- Set relations in thing to empty.	*/

xthlJ1_EmptyThing( lv_thing )
LVAL               lv_thing;
{
    LVAL lv_points = xthlA2_Get_Point_Relation_From_Thing( lv_thing );
    LVAL lv_facets = xthlA4_Get_Facet_Relation_From_Thing( lv_thing );
    LVAL lv_shape  = cvfixnum( 0 );
    xthlEe_Error_If_Not_Rank_1( lv_points, lv_points );
    xthlEe_Error_If_Not_Rank_1( lv_facets, lv_facets );
    xgrl30_Fill_Pointer( lv_points, lv_shape );
    xgrl30_Fill_Pointer( lv_facets, lv_shape );
}
LVAL xthlJ2_EmptyThing_Fn()
{
    LVAL lv_thing = NIL;
    while (moreargs()) {
        LVAL key = xlgasymbol();
        if (key == k_thing) {
	    lv_thing = xlgacons();
	} else {
            xlerror("bad XTHL-EMPTY-THING keyword",key);
        }
    }
    if (null(lv_thing)) xlfail("No :THING");
    xthlJ1_EmptyThing( lv_thing );
    return lv_thing;
}

/* }}} */
/* {{{ xthlK2_TransformThing_Fn -- Apply a 4x4 matrix to thing.		*/

xthlK0_Build_Normal_Tranforming_Matrix( dst, src )
geo_matrix			       *dst,*src;
{
    /* Construct inverse transpose for normals: */
    *dst = *src;
    ctfm47_Transpose_Matrix( 		     dst );
    ctfm45_Invert_Matrix(    		     dst );
    ctfm48_Zero_Matrix_Translation_Entries(  dst );
    ctfm49_Scale_Matrix_Rows_To_Unit_Length( dst );
    return TRUE;
}
xthlK1_TransformThing( lv_thing, matrix, p, f )
LVAL		       lv_thing;
geo_matrix			*matrix;
int					 p, f; /* points and facets to skip. */
{
    LVAL lv_points = xthlA2_Get_Point_Relation_From_Thing( lv_thing );
    LVAL lv_facets = xthlA4_Get_Facet_Relation_From_Thing( lv_thing );
    gt_tri_rec r;
    geo_matrix	it_matrix;
    int	        built_it = FALSE;
    xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
    r.default_r = FALSE;
    xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_points );

    if (r.got_points) {
	lib28_Matrix_Apply_To_Points(
	    r.x +p,  r.y +p,  r.z +p,
	    r.pLen -p,
	    matrix
	);
    }

    
    if (r.got_point_normals) {
	built_it = xthlK0_Build_Normal_Tranforming_Matrix( &it_matrix, matrix );
	lib28_Matrix_Apply_To_Points(
	    r.pnx +p ,r.pny +p, r.pnz +p,
	    r.pLen -p,
	    &it_matrix
	);
    }
    if (!null(lv_facets)) {
	xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_facets );
	if (r.got_facet_normals) {
	    if (!built_it) {
	        xthlK0_Build_Normal_Tranforming_Matrix( &it_matrix, matrix );
	    }
	    lib28_Matrix_Apply_To_Points(
		r.fnx +f, r.fny +f, r.fnz +f,
		r.fLen -f,
		&it_matrix
	    );
	}
    }
}
LVAL xthlK2_TransformThing_Fn()
{
    LVAL lv_thing = NIL;
    LVAL lv_xtfm  = NIL;
    while (moreargs()) {
        LVAL key = xlgasymbol();
        if        (key == k_thing) {
	    lv_thing	= xlgacons();
        } else if (key == k_transform) {
	    lv_xtfm	= xtfm01_Get_A_XTFM();
	} else {
            xlerror("bad XTHL-TRANFORM-THING keyword",key);
        }
    }
    if (null(lv_thing))     xlfail("No :THING");
    if (null(lv_xtfm ))     xlfail("No :TRANSFORM");
    xthlK1_TransformThing( lv_thing, xtfm9b_Find_Matrix( lv_xtfm ), 0, 0 );
    return lv_thing;
}

/* }}} */
/* {{{ xthlK4_NormalizeThingNormals_Fn -- Make all normals unit length.	*/

xthlK3_NormalizeThingNormals( lv_thing )
LVAL			      lv_thing;
{
    LVAL lv_points = xthlA2_Get_Point_Relation_From_Thing( lv_thing );
    LVAL lv_facets = xthlA4_Get_Facet_Relation_From_Thing( lv_thing );
    gt_tri_rec r;
    xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
    r.default_r = FALSE;
    xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_points );

    if (r.got_point_normals) {
	lib29_Normalize_Normals(     r.pnx,r.pny,r.pnz,r.fLen );
    }
    if (!null(lv_facets)) {
	xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_facets );
	if (r.got_facet_normals) {
	    lib29_Normalize_Normals( r.fnx,r.fny,r.fnz,r.fLen );
	}
    }
}
LVAL xthlK4_NormalizeThingNormals_Fn()
{
    LVAL lv_thing = NIL;
    while (moreargs()) {
        LVAL key = xlgasymbol();
        if      (key == k_thing) {
	    lv_thing = xlgacons();
	} else {
            xlerror("bad XTHL-NORMALIZE-THING-NORMALS keyword",key);
        }
    }
    if (null(lv_thing))     xlfail("No :THING");
    xthlK3_NormalizeThingNormals( lv_thing );
    return lv_thing;
}

/* }}} */
/* {{{ xthlL2_ObjectspaceBoundingBoxOfThing				*/

xthlL2_ObjectspaceBoundingBoxOfThing( min, max, lv_thing )
geo_point	  		     *min,*max;
LVAL						lv_thing;
{
    float min_x = GEO_FLOAT_MAX;
    float min_y = GEO_FLOAT_MAX;
    float min_z = GEO_FLOAT_MAX;

    float max_x = GEO_FLOAT_MIN;
    float max_y = GEO_FLOAT_MIN;
    float max_z = GEO_FLOAT_MIN;

    LVAL lv_points = xthlA2_Get_Point_Relation_From_Thing( lv_thing );
    gt_tri_rec r;
    xthlC2_Init_Tri_Rec( &r, NULL, NULL, NULL );
    r.default_r = FALSE;
    xthlB3_Fill_Tri_Rec_From_Grl( &r, lv_points );
    if (!r.got_points)   xlerror("Need :POINTS-X/Y/Z",lv_thing);

    {   int i;
	float *px = r.x;
	float *py = r.y;
	float *pz = r.z;
	for (i = r.pLen;   i --> 0;   ) {
	    float x = *px++;
	    float y = *py++;
	    float z = *pz++;

	    if (min_x > x)   min_x = x;
	    if (min_y > y)   min_y = y;
	    if (min_z > z)   min_z = z;

	    if (max_x < x)   max_x = x;
	    if (max_y < y)   max_y = y;
	    if (max_z < z)   max_z = z;
    }	}

    min->x = min_x;
    min->y = min_y;
    min->z = min_z;

    max->x = max_x;
    max->y = max_y;
    max->z = max_z;
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
