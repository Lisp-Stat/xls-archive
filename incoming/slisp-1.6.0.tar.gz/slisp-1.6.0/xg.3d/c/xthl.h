/* {{{ xthl.h -- thinglists.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Jun29, from x03d.h stuff.
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS

extern LVAL xthl09_MakePointGrl_Fn();
extern LVAL xthl15_MakeGrlOfLines_Fn();
extern LVAL xthl16_MakeGrlOfTriangles_Fn();
extern LVAL xthl17_MakeGrlOfRectangles_Fn();
extern LVAL xthl29_MakeImageGrl_Fn();

extern LVAL xthl55_MakeThingOfPoints_Fn();
extern LVAL xthl64_MakeThingOfLines_Fn();
extern LVAL xthl66_MakeThingOfTriangles_Fn();
extern LVAL xthl68_MakeThingOfRectangles_Fn();

extern LVAL xthlF6_Call_HookFns_Fn();

extern LVAL xthlG0_Get_Fn();
extern LVAL xthlG1_Set_Fn();
extern LVAL xthlG2_Rem_Fn();
extern LVAL xthlG3_Length_Fn();
extern LVAL xthlG4_Nth_Fn();
extern LVAL xthlG7_Copy_List();
extern LVAL xthlJ2_EmptyThing_Fn();
extern LVAL xthlK2_TransformThing_Fn();
extern LVAL xthlK4_NormalizeThingNormals_Fn();

#ifndef EXTERNED_WHICHBITPLANES
extern LVAL k_whichbitplanes;
#define EXTERNED_WHICHBITPLANES
#endif

#ifndef EXTERNED_RGBBITPLANES
extern LVAL k_rgbbitplanes;
#define EXTERNED_RGBBITPLANES
#endif

#ifndef EXTERNED_OVERLAYBITPLANES
extern LVAL k_overlaybitplanes;
#define EXTERNED_OVERLAYBITPLANES
#endif

#ifndef EXTERNED_OVERLAYBITPLANESERASE
extern LVAL k_overlaybitplaneserase;
#define EXTERNED_OVERLAYBITPLANESERASE
#endif

#ifndef EXTERNED_CURSORBITPLANES
extern LVAL k_cursorbitplanes;
#define EXTERNED_CURSORBITPLANES
#endif

#ifndef EXTERNED_CURSORBITPLANESERASE
extern LVAL k_cursorbitplaneserase;
#define EXTERNED_CURSORBITPLANESERASE
#endif

#ifndef EXTERNED_POPUPBITPLANES
extern LVAL k_popupbitplanes;
#define EXTERNED_POPUPBITPLANES
#endif

#ifndef EXTERNED_POPUPBITPLANESERASE
extern LVAL k_popupbitplaneserase;
#define EXTERNED_POPUPBITPLANESERASE
#endif

#ifndef EXTERNED_JUSTLIKE
extern LVAL k_justlike;/* Keyword ":just-like" */
#define EXTERNED_JUSTLIKE
#endif

#ifndef EXTERNED_FIXLIGHTSONOBJECT
extern LVAL k_fixlightsonobject;/* Keyword ":fix-lights-on-object" */
#define EXTERNED_FIXLIGHTSONOBJECT
#endif

#ifndef EXTERNED_WANTFACETNORMALS
extern LVAL k_wantfacetnormals;/* Keyword ":want-facet-normals" */
#define EXTERNED_WANTFACETNORMALS
#endif

#ifndef EXTERNED_WANTFACETCOLORS
extern LVAL k_wantfacetcolors;/* Keyword ":want-facet-colors" */
#define EXTERNED_WANTFACETCOLORS
#endif

#ifndef EXTERNED_WANTPOINTNORMALS
extern LVAL k_wantpointnormals;/* Keyword ":want-point-normals" */
#define EXTERNED_WANTPOINTNORMALS
#endif

#ifndef EXTERNED_WANTPOINTCOLORS
extern LVAL k_wantpointcolors;/* Keyword ":want-point-colors" */
#define EXTERNED_WANTPOINTCOLORS
#endif

#ifndef EXTERNED_WANTPOINTTEXTURES
extern LVAL k_wantpointtextures;/* Keyword ":want-point-textures" */
#define EXTERNED_WANTPOINTTEXTURES
#endif

#ifndef EXTERNED_WANTFACETTEXTURES
extern LVAL k_wantfacettextures;/* Keyword ":want-facet-textures" */
#define EXTERNED_WANTFACETTEXTURES
#endif

#ifndef EXTERNED_WANTFACETNEIGHBORS
extern LVAL k_wantfacetneighbors;/* Keyword ":want-facet-neighbors" */
#define EXTERNED_WANTFACETNEIGHBORS
#endif

#ifndef EXTERNED_WIDGET
extern LVAL k_widget;/* Keyword ":widget" */
#define EXTERNED_WIDGET
#endif

#ifndef EXTERNED_COPYPROPLIST
extern LVAL k_copyproplist;/* Keyword ":copy-proplist" */
#define EXTERNED_COPYPROPLIST
#endif

#ifndef EXTERNED_SHALLOW
extern LVAL k_shallow;/* Keyword ":shallow" */
#define EXTERNED_DEEP
#endif

#ifndef EXTERNED_POINTER
extern LVAL k_pointer;/* Keyword ":pointer" */
#define EXTERNED_POINTER
#endif

#ifndef EXTERNED_DEEP
extern LVAL k_deep;/* Keyword ":deep" */
#define EXTERNED_DEEP
#endif

#ifndef EXTERNED_REDRAW
extern LVAL k_redraw;/* Keyword ":REDRAW" */
#define EXTERNED_REDRAW
#endif

#ifndef EXTERNED_DRAWAS
extern LVAL k_drawas;/* Keyword ":DRAW-AS" */
#define EXTERNED_DRAWAS
#endif

#ifndef EXTERNED_PICKAS
extern LVAL k_pickas;/* Keyword ":PICK-AS" */
#define EXTERNED_PICKAS
#endif

#ifndef EXTERNED_USE_NORMALS
extern LVAL k_use_normals;/* Keyword ":USE-NORMALS" */
#define EXTERNED_USE_NORMALS
#endif

#ifndef EXTERNED_USE_COLORS
extern LVAL k_use_colors;/* Keyword ":USE-COLORS" */
#define EXTERNED_USE_COLORS
#endif

#ifndef EXTERNED_ON_FACETS
extern LVAL k_on_facets;/* Keyword ":ON-FACETS" */
#define EXTERNED_ON_FACETS
#endif

#ifndef EXTERNED_ON_POINTS
extern LVAL k_on_points;/* Keyword ":ON-POINTS" */
#define EXTERNED_ON_POINTS
#endif

#ifndef EXTERNED_SOLID
extern LVAL k_solid;/* Keyword ":SOLID" */
#define EXTERNED_SOLID
#endif

#ifndef EXTERNED_FACETS
extern LVAL k_facets;/* Keyword ":FACETS" */
#define EXTERNED_FACETS
#endif

#ifndef EXTERNED_WIREFRAME
extern LVAL k_wireframe;/* Keyword ":WIRE-FRAME" */
#define EXTERNED_WIREFRAME
#endif

#ifndef EXTERNED_POINTCLOUD
extern LVAL k_pointcloud;/* Keyword ":POINT-CLOUD" */
#define EXTERNED_POINTCLOUD
#endif

#ifndef EXTERNED_INVISIBLE
extern LVAL k_invisible;/* Keyword ":INVISIBLE" */
#define EXTERNED_INVISIBLE
#endif

#ifndef EXTERNED_FOREGROUND
extern LVAL k_foreground;/* Keyword ":FOREGROUND" */
#define EXTERNED_FOREGROUND
#endif

#ifndef EXTERNED_BACKGROUND
extern LVAL k_background;/* Keyword ":BACKGROUND" */
#define EXTERNED_BACKGROUND
#endif



#ifndef EXTERNED_POINTIF
extern LVAL k_pointif;/* Keyword ":POINT-IF" */
#define EXTERNED_POINTIF
#endif

#ifndef EXTERNED_TEXTURE
extern LVAL k_texture;/* Keyword ":TEXTURE" */
#define EXTERNED_TEXTURE
#endif

#ifndef EXTERNED_POINTTEXTUREU
extern LVAL k_pointtextureu;/* Keyword ":POINT-TEXTURE-U" */
#define EXTERNED_POINTTEXTUREU
#endif

#ifndef EXTERNED_POINTTEXTUREV
extern LVAL k_pointtexturev;/* Keyword ":POINT-TEXTURE-V" */
#define EXTERNED_POINTTEXTUREV
#endif

#ifndef EXTERNED_FACETTEXTUREU0
extern LVAL k_facettextureu0;/* Keyword ":FACET-TEXTURE-U-0" */
#define EXTERNED_FACETTEXTUREU0
#endif

#ifndef EXTERNED_FACETTEXTUREV0
extern LVAL k_facettexturev0;/* Keyword ":FACET-TEXTURE-V-0" */
#define EXTERNED_FACETTEXTUREV0
#endif

#ifndef EXTERNED_FACETTEXTUREU1
extern LVAL k_facettextureu1;/* Keyword ":FACET-TEXTURE-U-1" */
#define EXTERNED_FACETTEXTUREU1
#endif

#ifndef EXTERNED_FACETTEXTUREV1
extern LVAL k_facettexturev1;/* Keyword ":FACET-TEXTURE-V-1" */
#define EXTERNED_FACETTEXTUREV1
#endif

#ifndef EXTERNED_FACETTEXTUREU2
extern LVAL k_facettextureu2;/* Keyword ":FACET-TEXTURE-U-2" */
#define EXTERNED_FACETTEXTUREU2
#endif

#ifndef EXTERNED_FACETTEXTUREV2
extern LVAL k_facettexturev2;/* Keyword ":FACET-TEXTURE-V-2" */
#define EXTERNED_FACETTEXTUREV2
#endif

#ifndef EXTERNED_FACETTEXTUREU3
extern LVAL k_facettextureu3;/* Keyword ":FACET-TEXTURE-U-3" */
#define EXTERNED_FACETTEXTUREU3
#endif

#ifndef EXTERNED_FACETTEXTUREV3
extern LVAL k_facettexturev3;/* Keyword ":FACET-TEXTURE-V-3" */
#define EXTERNED_FACETTEXTUREV3
#endif

#ifndef EXTERNED_FACETNEIGHBOR0
extern LVAL k_facetneighbor0;/* Keyword ":FACET-NEIGHBOR-0" */
#define EXTERNED_FACETNEIGHBOR0
#endif

#ifndef EXTERNED_FACETNEIGHBOR1
extern LVAL k_facetneighbor1;/* Keyword ":FACET-NEIGHBOR-1" */
#define EXTERNED_FACETNEIGHBOR1
#endif

#ifndef EXTERNED_FACETNEIGHBOR2
extern LVAL k_facetneighbor2;/* Keyword ":FACET-NEIGHBOR-2" */
#define EXTERNED_FACETNEIGHBOR2
#endif

#ifndef EXTERNED_FACETNEIGHBOR3
extern LVAL k_facetneighbor3;/* Keyword ":FACET-NEIGHBOR-3" */
#define EXTERNED_FACETNEIGHBOR3
#endif

#ifndef EXTERNED_POINTX
extern LVAL k_pointx;/* Keyword ":POINT-X" */
#define EXTERNED_POINTX
#endif

#ifndef EXTERNED_POINTY
extern LVAL k_pointy;/* Keyword ":POINT-Y" */
#define EXTERNED_POINTY
#endif

#ifndef EXTERNED_POINTZ
extern LVAL k_pointz;/* Keyword ":POINT-Z" */
#define EXTERNED_POINTZ
#endif



#ifndef EXTERNED_POINTNORMALX
extern LVAL k_pointnormalx;/* Keyword ":POINT-NORMAL-X" */
#define EXTERNED_POINTNORMALX
#endif

#ifndef EXTERNED_POINTNORMALY
extern LVAL k_pointnormaly;/* Keyword ":POINT-NORMAL-Y" */
#define EXTERNED_POINTNORMALY
#endif

#ifndef EXTERNED_POINTNORMALZ
extern LVAL k_pointnormalz;/* Keyword ":POINT-NORMAL-Z" */
#define EXTERNED_POINTNORMALZ
#endif



#ifndef EXTERNED_POINTRED
extern LVAL k_pointred;/* Keyword ":POINT-RED" */
#define EXTERNED_POINTRED
#endif

#ifndef EXTERNED_POINTGREEN
extern LVAL k_pointgreen;/* Keyword ":POINT-GREEN" */
#define EXTERNED_POINTGREEN
#endif

#ifndef EXTERNED_POINTBLUE
extern LVAL k_pointblue;/* Keyword ":POINT-BLUE" */
#define EXTERNED_POINTBLUE
#endif



#ifndef EXTERNED_PIXELRED
extern LVAL k_pixelred;/* Keyword ":PIXEL-RED" */
#define EXTERNED_PIXELRED
#endif

#ifndef EXTERNED_PIXELGREEN
extern LVAL k_pixelgreen;/* Keyword ":PIXEL-GREEN" */
#define EXTERNED_PIXELGREEN
#endif

#ifndef EXTERNED_PIXELBLUE
extern LVAL k_pixelblue;/* Keyword ":PIXEL-BLUE" */
#define EXTERNED_PIXELBLUE
#endif

#ifndef EXTERNED_PIXELDEPTH
extern LVAL k_pixeldepth;/* Keyword ":PIXEL-DEPTH" */
#define EXTERNED_PIXELDEPTH
#endif



#ifndef EXTERNED_FACETIF
extern LVAL k_facetif;/* Keyword ":FACET-IF" */
#define EXTERNED_FACETIF
#endif

#ifndef EXTERNED_FACET0
extern LVAL k_facet0;/* Keyword ":FACET-0" */
#define EXTERNED_FACET0
#endif

#ifndef EXTERNED_FACET1
extern LVAL k_facet1;/* Keyword ":FACET-1" */
#define EXTERNED_FACET1
#endif

#ifndef EXTERNED_FACET2
extern LVAL k_facet2;/* Keyword ":FACET-2" */
#define EXTERNED_FACET2
#endif

#ifndef EXTERNED_FACET3
extern LVAL k_facet3;/* Keyword ":FACET-3" */
#define EXTERNED_FACET3
#endif



#ifndef EXTERNED_FACETNORMALX
extern LVAL k_facetnormalx;/* Keyword ":FACET-NORMAL-X" */
#define EXTERNED_FACETNORMALX
#endif

#ifndef EXTERNED_FACETNORMALY
extern LVAL k_facetnormaly;/* Keyword ":FACET-NORMAL-Y" */
#define EXTERNED_FACETNORMALY
#endif

#ifndef EXTERNED_FACETNORMALZ
extern LVAL k_facetnormalz;/* Keyword ":FACET-NORMAL-Z" */
#define EXTERNED_FACETNORMALZ
#endif



#ifndef EXTERNED_FACETRED
extern LVAL k_facetred;/* Keyword ":FACET-RED" */
#define EXTERNED_FACETRED
#endif

#ifndef EXTERNED_FACETGREEN
extern LVAL k_facetgreen;/* Keyword ":FACET-GREEN" */
#define EXTERNED_FACETGREEN
#endif

#ifndef EXTERNED_FACETBLUE
extern LVAL k_facetblue;/* Keyword ":FACET-BLUE" */
#define EXTERNED_FACETBLUE
#endif


#ifndef EXTERNED_WANT
extern LVAL k_want;/* Keyword ":WANT" */
#define EXTERNED_WANT
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR("XG.3D-MAKE-POINT-GRL",		xthl09_MakePointGrl_Fn	       )
DEFINE_SUBR("XG.3D-MAKE-GRL-OF-LINES",		xthl15_MakeGrlOfLines_Fn       )
DEFINE_SUBR("XG.3D-MAKE-GRL-OF-TRIANGLES",	xthl16_MakeGrlOfTriangles_Fn   )
DEFINE_SUBR("XG.3D-MAKE-GRL-OF-RECTANGLES",	xthl17_MakeGrlOfRectangles_Fn  )
DEFINE_SUBR("XG.3D-MAKE-IMAGE-GRL",		xthl29_MakeImageGrl_Fn	       )

DEFINE_SUBR("XG.3D-MAKE-THING-OF-POINTS",		xthl55_MakeThingOfPoints_Fn    )
DEFINE_SUBR("XG.3D-MAKE-THING-OF-LINES",		xthl64_MakeThingOfLines_Fn     )
DEFINE_SUBR("XG.3D-MAKE-THING-OF-TRIANGLES",	xthl66_MakeThingOfTriangles_Fn )
DEFINE_SUBR("XG.3D-MAKE-THING-OF-RECTANGLES",	xthl68_MakeThingOfRectangles_Fn)

DEFINE_SUBR("XG.3D-CALL-HOOK-FUNCTIONS",		xthlF6_Call_HookFns_Fn	       )

DEFINE_SUBR("XG.3D-GET",				xthlG0_Get_Fn		       )
DEFINE_SUBR("XG.3D-SET",				xthlG1_Set_Fn		       )
DEFINE_SUBR("XG.3D-REM",				xthlG2_Rem_Fn		       )
DEFINE_SUBR("XG.3D-LENGTH",			xthlG3_Length_Fn	       )
DEFINE_SUBR("XG.3D-NTH",				xthlG4_Nth_Fn		       )

DEFINE_SUBR("XG.3D-EMPTY-THING",			xthlJ2_EmptyThing_Fn	       )
DEFINE_SUBR("XG.3D-TRANSFORM-THING",		xthlK2_TransformThing_Fn       )
DEFINE_SUBR("XG.3D-NORMALIZE-THING-NORMALS",	xthlK4_NormalizeThingNormals_Fn)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
#ifdef MAYBE_SOMEDAY
LVAL lv_xthl;
LOCAL struct xthl_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xthl_table[] = {

    {	NULL,			NULL				}
};
#endif

#ifndef DEFINED_WHICHBITPLANES
LVAL k_whichbitplanes;/* Keyword ":which-bitplanes" */
#define DEFINED_WHICHBITPLANES
#endif

#ifndef DEFINED_RGBBITPLANES
LVAL k_rgbbitplanes;/* Keyword ":rgb-bitplanes" */
#define DEFINED_RGBBITPLANES
#endif

#ifndef DEFINED_OVERLAYBITPLANES
LVAL k_overlaybitplanes;/* Keyword ":overlay-bitplanes" */
#define DEFINED_OVERLAYBITPLANES
#endif

#ifndef DEFINED_OVERLAYBITPLANESERASE
LVAL k_overlaybitplaneserase;/* Keyword ":overlay-bitplanes-erase" */
#define DEFINED_OVERLAYBITPLANESERASE
#endif

#ifndef DEFINED_CURSORBITPLANES
LVAL k_cursorbitplanes;/* Keyword ":cursor-bitplanes" */
#define DEFINED_CURSORBITPLANES
#endif

#ifndef DEFINED_CURSORBITPLANESERASE
LVAL k_cursorbitplaneserase;/* Keyword ":cursor-bitplanes-erase" */
#define DEFINED_CURSORBITPLANESERASE
#endif

#ifndef DEFINED_POPUPBITPLANES
LVAL k_popupbitplanes;/* Keyword ":popup-bitplanes" */
#define DEFINED_POPUPBITPLANES
#endif

#ifndef DEFINED_POPUPBITPLANESERASE
LVAL k_popupbitplaneserase;/* Keyword ":popup-bitplanes-erase" */
#define DEFINED_POPUPBITPLANESERASE
#endif

#ifndef DEFINED_JUSTLIKE
LVAL k_justlike;/* Keyword ":just-like" */
#define DEFINED_JUSTLIKE
#endif

#ifndef DEFINED_FIXLIGHTSONOBJECT
LVAL k_fixlightsonobject;/* Keyword ":fix-lights-on-object" */
#define DEFINED_FIXLIGHTSONOBJECT
#endif

#ifndef DEFINED_WANTFACETNORMALS
LVAL k_wantfacetnormals;/* Keyword ":want-facet-normals" */
#define DEFINED_WANTFACETNORMALS
#endif

#ifndef DEFINED_WANTFACETCOLORS
LVAL k_wantfacetcolors;/* Keyword ":want-facet-colors" */
#define DEFINED_WANTFACETCOLORS
#endif

#ifndef DEFINED_WANTPOINTNORMALS
LVAL k_wantpointnormals;/* Keyword ":want-point-normals" */
#define DEFINED_WANTPOINTNORMALS
#endif

#ifndef DEFINED_WANTPOINTCOLORS
LVAL k_wantpointcolors;/* Keyword ":want-point-colors" */
#define DEFINED_WANTPOINTCOLORS
#endif

#ifndef DEFINED_WANTFACETTEXTURES
LVAL k_wantfacettextures;/* Keyword ":want-facet-textures" */
#define DEFINED_WANTFACETTEXTURES
#endif

#ifndef DEFINED_WANTPOINTTEXTURES
LVAL k_wantpointtextures;/* Keyword ":want-point-textures" */
#define DEFINED_WANTPOINTTEXTURES
#endif

#ifndef DEFINED_WANTFACETNEIGHBORS
LVAL k_wantfacetneighbors;/* Keyword ":want-facet-neighbors" */
#define DEFINED_WANTFACETNEIGHBORS
#endif

#ifndef DEFINED_WIDGET
LVAL k_widget;/* Keyword ":widget" */
#define DEFINED_WIDGET
#endif

#ifndef DEFINED_COPYPROPLIST
LVAL k_copyproplist;/* Keyword ":copy-proplist" */
#define DEFINED_COPYPROPLIST
#endif

#ifndef DEFINED_SHALLOW
LVAL k_shallow;/* Keyword ":shallow" */
#define DEFINED_SHALLOW
#endif

#ifndef DEFINED_POINTER
LVAL k_pointer;/* Keyword ":pointer" */
#define DEFINED_POINTER
#endif

#ifndef DEFINED_DEEP
LVAL k_deep;/* Keyword ":deep" */
#define DEFINED_DEEP
#endif

#ifndef DEFINED_REDRAW
LVAL k_redraw;/* Keyword ":REDRAW" */
#define DEFINED_REDRAW
#endif

#ifndef DEFINED_DRAWAS
LVAL k_drawas;/* Keyword ":DRAW-AS" */
#define DEFINED_DRAWAS
#endif

#ifndef DEFINED_PICKAS
LVAL k_pickas;/* Keyword ":PICK-AS" */
#define DEFINED_PICKAS
#endif

#ifndef DEFINED_USE_NORMALS
LVAL k_use_normals;/* Keyword ":USE-NORMALS" */
#define DEFINED_USE_NORMALS
#endif

#ifndef DEFINED_USE_COLORS
LVAL k_use_colors;/* Keyword ":USE-COLORS" */
#define DEFINED_USE_COLORS
#endif

#ifndef DEFINED_ON_FACETS
LVAL k_on_facets;/* Keyword ":ON-FACETS" */
#define DEFINED_ON_FACETS
#endif

#ifndef DEFINED_ON_POINTS
LVAL k_on_points;/* Keyword ":ON-POINTS" */
#define DEFINED_ON_POINTS
#endif

#ifndef DEFINED_SOLID
LVAL k_solid;/* Keyword ":SOLID" */
#define DEFINED_SOLID
#endif

#ifndef DEFINED_FACETS
LVAL k_facets;/* Keyword ":FACETS" */
#define DEFINED_FACETS
#endif

#ifndef DEFINED_WIREFRAME
LVAL k_wireframe;/* Keyword ":WIRE-FRAME" */
#define DEFINED_WIREFRAME
#endif

#ifndef DEFINED_POINTCLOUD
LVAL k_pointcloud;/* Keyword ":POINT-CLOUD" */
#define DEFINED_POINTCLOUD
#endif

#ifndef DEFINED_INVISIBLE
LVAL k_invisible;/* Keyword ":INVISIBLE" */
#define DEFINED_INVISIBLE
#endif

#ifndef DEFINED_FOREGROUND
LVAL k_foreground;/* Keyword ":FOREGROUND" */
#define DEFINED_FOREGROUND
#endif

#ifndef DEFINED_BACKGROUND
LVAL k_background;/* Keyword ":BACKGROUND" */
#define DEFINED_BACKGROUND
#endif


#ifndef DEFINED_POINTIF
LVAL k_pointif;/* Keyword ":POINT-IF" */
#define DEFINED_POINTIF
#endif

#ifndef DEFINED_TEXTURE
LVAL k_texture;/* Keyword ":TEXTURE" */
#define DEFINED_TEXTURE
#endif

#ifndef DEFINED_POINTTEXTUREU
LVAL k_pointtextureu;/* Keyword ":POINT-TEXTURE-U" */
#define DEFINED_POINTTEXTUREU
#endif

#ifndef DEFINED_POINTTEXTUREV
LVAL k_pointtexturev;/* Keyword ":POINT-TEXTURE-V" */
#define DEFINED_POINTTEXTUREV
#endif

#ifndef DEFINED_FACETTEXTUREU0
LVAL k_facettextureu0;/* Keyword ":FACET-TEXTURE-U-0" */
#define DEFINED_FACETTEXTUREU0
#endif

#ifndef DEFINED_FACETTEXTUREV0
LVAL k_facettexturev0;/* Keyword ":FACET-TEXTURE-V-0" */
#define DEFINED_FACETTEXTUREV0
#endif

#ifndef DEFINED_FACETTEXTUREU1
LVAL k_facettextureu1;/* Keyword ":FACET-TEXTURE-U-1" */
#define DEFINED_FACETTEXTUREU1
#endif

#ifndef DEFINED_FACETTEXTUREV1
LVAL k_facettexturev1;/* Keyword ":FACET-TEXTURE-V-1" */
#define DEFINED_FACETTEXTUREV1
#endif

#ifndef DEFINED_FACETTEXTUREU2
LVAL k_facettextureu2;/* Keyword ":FACET-TEXTURE-U-2" */
#define DEFINED_FACETTEXTUREU2
#endif

#ifndef DEFINED_FACETTEXTUREV2
LVAL k_facettexturev2;/* Keyword ":FACET-TEXTURE-V-2" */
#define DEFINED_FACETTEXTUREV2
#endif

#ifndef DEFINED_FACETTEXTUREU3
LVAL k_facettextureu3;/* Keyword ":FACET-TEXTURE-U-3" */
#define DEFINED_FACETTEXTUREU3
#endif

#ifndef DEFINED_FACETTEXTUREV3
LVAL k_facettexturev3;/* Keyword ":FACET-TEXTURE-V-3" */
#define DEFINED_FACETTEXTUREV3
#endif

#ifndef DEFINED_FACETNEIGHBOR0
LVAL k_facetneighbor0;/* Keyword ":FACET-NEIGHBOR-0" */
#define DEFINED_FACETNEIGHBOR0
#endif

#ifndef DEFINED_FACETNEIGHBOR1
LVAL k_facetneighbor1;/* Keyword ":FACET-NEIGHBOR-1" */
#define DEFINED_FACETNEIGHBOR1
#endif

#ifndef DEFINED_FACETNEIGHBOR2
LVAL k_facetneighbor2;/* Keyword ":FACET-NEIGHBOR-2" */
#define DEFINED_FACETNEIGHBOR2
#endif

#ifndef DEFINED_FACETNEIGHBOR3
LVAL k_facetneighbor3;/* Keyword ":FACET-NEIGHBOR-3" */
#define DEFINED_FACETNEIGHBOR3
#endif

#ifndef DEFINED_POINTX
LVAL k_pointx;/* Keyword ":POINT-X" */
#define DEFINED_POINTX
#endif

#ifndef DEFINED_POINTY
LVAL k_pointy;/* Keyword ":POINT-Y" */
#define DEFINED_POINTY
#endif

#ifndef DEFINED_POINTZ
LVAL k_pointz;/* Keyword ":POINT-Z" */
#define DEFINED_POINTZ
#endif



#ifndef DEFINED_POINTNORMALX
LVAL k_pointnormalx;/* Keyword ":POINT-NORMAL-X" */
#define DEFINED_POINTNORMALX
#endif

#ifndef DEFINED_POINTNORMALY
LVAL k_pointnormaly;/* Keyword ":POINT-NORMAL-Y" */
#define DEFINED_POINTNORMALY
#endif

#ifndef DEFINED_POINTNORMALZ
LVAL k_pointnormalz;/* Keyword ":POINT-NORMAL-Z" */
#define DEFINED_POINTNORMALZ
#endif



#ifndef DEFINED_POINTRED
LVAL k_pointred;/* Keyword ":POINT-RED" */
#define DEFINED_POINTRED
#endif

#ifndef DEFINED_POINTGREEN
LVAL k_pointgreen;/* Keyword ":POINT-GREEN" */
#define DEFINED_POINTGREEN
#endif

#ifndef DEFINED_POINTBLUE
LVAL k_pointblue;/* Keyword ":POINT-BLUE" */
#define DEFINED_POINTBLUE
#endif



#ifndef DEFINED_PIXELRED
LVAL k_pixelred;/* Keyword ":PIXEL-RED" */
#define DEFINED_PIXELRED
#endif

#ifndef DEFINED_PIXELGREEN
LVAL k_pixelgreen;/* Keyword ":PIXEL-GREEN" */
#define DEFINED_PIXELGREEN
#endif

#ifndef DEFINED_PIXELBLUE
LVAL k_pixelblue;/* Keyword ":PIXEL-BLUE" */
#define DEFINED_PIXELBLUE
#endif

#ifndef DEFINED_PIXELDEPTH
LVAL k_pixeldepth;/* Keyword ":PIXEL-DEPTH" */
#define DEFINED_PIXELDEPTH
#endif



#ifndef DEFINED_FACETIF
LVAL k_facetif;/* Keyword ":FACET-IF" */
#define DEFINED_FACETIF
#endif

#ifndef DEFINED_FACET0
LVAL k_facet0;/* Keyword ":FACET-0" */
#define DEFINED_FACET0
#endif

#ifndef DEFINED_FACET1
LVAL k_facet1;/* Keyword ":FACET-1" */
#define DEFINED_FACET1
#endif

#ifndef DEFINED_FACET2
LVAL k_facet2;/* Keyword ":FACET-2" */
#define DEFINED_FACET2
#endif

#ifndef DEFINED_FACET3
LVAL k_facet3;/* Keyword ":FACET-3" */
#define DEFINED_FACET3
#endif



#ifndef DEFINED_FACETNORMALX
LVAL k_facetnormalx;/* Keyword ":FACET-NORMAL-X" */
#define DEFINED_FACETNORMALX
#endif

#ifndef DEFINED_FACETNORMALY
LVAL k_facetnormaly;/* Keyword ":FACET-NORMAL-Y" */
#define DEFINED_FACETNORMALY
#endif

#ifndef DEFINED_FACETNORMALZ
LVAL k_facetnormalz;/* Keyword ":FACET-NORMAL-Z" */
#define DEFINED_FACETNORMALZ
#endif



#ifndef DEFINED_FACETRED
LVAL k_facetred;/* Keyword ":FACET-RED" */
#define DEFINED_FACETRED
#endif

#ifndef DEFINED_FACETGREEN
LVAL k_facetgreen;/* Keyword ":FACET-GREEN" */
#define DEFINED_FACETGREEN
#endif

#ifndef DEFINED_FACETBLUE
LVAL k_facetblue;/* Keyword ":FACET-BLUE" */
#define DEFINED_FACETBLUE
#endif

#ifndef DEFINED_WANT
LVAL k_want;/* Keyword ":WANT" */
#define DEFINED_WANT
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_WHICHBITPLANES
    k_whichbitplanes = xlenter(":WHICH-BITPLANES");
#define CREATED_WHICHBITPLANES
#endif

#ifndef CREATED_RGBBITPLANES
    k_rgbbitplanes = xlenter(":RGB-BITPLANES");
#define CREATED_RGBBITPLANES
#endif

#ifndef CREATED_OVERLAYBITPLANES
    k_overlaybitplanes = xlenter(":OVERLAY-BITPLANES");
#define CREATED_OVERLAYBITPLANES
#endif

#ifndef CREATED_OVERLAYBITPLANESERASE
    k_overlaybitplaneserase = xlenter(":OVERLAY-BITPLANES-ERASE");
#define CREATED_OVERLAYBITPLANESERASE
#endif

#ifndef CREATED_CURSORBITPLANES
    k_cursorbitplanes = xlenter(":CURSOR-BITPLANES");
#define CREATED_CURSORBITPLANES
#endif

#ifndef CREATED_CURSORBITPLANESERASE
    k_cursorbitplaneserase = xlenter(":CURSOR-BITPLANES-ERASE");
#define CREATED_CURSORBITPLANESERASE
#endif

#ifndef CREATED_POPUPBITPLANES
    k_popupbitplanes = xlenter(":POPUP-BITPLANES");
#define CREATED_POPUPBITPLANES
#endif

#ifndef CREATED_POPUPBITPLANESERASE
    k_popupbitplaneserase = xlenter(":POPUP-BITPLANES-ERASE");
#define CREATED_POPUPBITPLANESERASE
#endif

#ifndef CREATED_JUSTLIKE
    k_justlike = xlenter(":JUST-LIKE");
#define CREATED_JUSTLIKE
#endif

#ifndef CREATED_FIXLIGHTSONOBJECT
    k_fixlightsonobject = xlenter(":FIX-LIGHTS-ON-OBJECT");
#define CREATED_FIXLIGHTSONOBJECT
#endif

#ifndef CREATED_WANTFACETNORMALS
    k_wantfacetnormals = xlenter(":WANT-FACET-NORMALS");
#define CREATED_WANTFACETNORMALS
#endif

#ifndef CREATED_WANTFACETCOLORS
    k_wantfacetcolors = xlenter(":WANT-FACET-COLORS");
#define CREATED_WANTFACETCOLORS
#endif

#ifndef CREATED_WANTPOINTNORMALS
    k_wantpointnormals = xlenter(":WANT-POINT-NORMALS");
#define CREATED_WANTPOINTNORMALS
#endif

#ifndef CREATED_WANTPOINTCOLORS
    k_wantpointcolors = xlenter(":WANT-POINT-COLORS");
#define CREATED_WANTPOINTCOLORS
#endif

#ifndef CREATED_WANTFACETTEXTURES
    k_wantfacettextures = xlenter(":WANT-FACET-TEXTURES");
#define CREATED_WANTFACETTEXTURES
#endif

#ifndef CREATED_WANTPOINTTEXTURES
    k_wantpointtextures = xlenter(":WANT-POINT-TEXTURES");
#define CREATED_WANTPOINTTEXTURES
#endif

#ifndef CREATED_WANTFACETNEIGHBORS
    k_wantfacetneighbors = xlenter(":WANT-FACET-NEIGHBORS");
#define CREATED_WANTFACETNEIGHBORS
#endif

#ifndef CREATED_WIDGET
    k_widget = xlenter(":WIDGET");
#define CREATED_WIDGET
#endif

#ifndef CREATED_COPYPROPLIST
    k_copyproplist = xlenter(":COPY-PROPLIST");
#define CREATED_COPYPROPLIST
#endif

#ifndef CREATED_SHALLOW
    k_shallow = xlenter(":SHALLOW");
#define CREATED_SHALLOW
#endif

#ifndef CREATED_POINTER
    k_pointer = xlenter(":POINTER");
#define CREATED_POINTER
#endif

#ifndef CREATED_DEEP
    k_deep = xlenter(":DEEP");
#define CREATED_DEEP
#endif

#ifndef CREATED_REDRAW
    k_redraw = xlenter(":REDRAW");
#define CREATED_REDRAW
#endif

#ifndef CREATED_DRAWAS
    k_drawas = xlenter(":DRAW-AS");
#define CREATED_DRAWAS
#endif

#ifndef CREATED_PICKAS
    k_pickas = xlenter(":PICK-AS");
#define CREATED_PICKAS
#endif

#ifndef CREATED_USE_NORMALS
    k_use_normals = xlenter(":USE-NORMALS");
#define CREATED_USE_NORMALS
#endif

#ifndef CREATED_USE_COLORS
    k_use_colors = xlenter(":USE-COLORS");
#define CREATED_USE_COLORS
#endif

#ifndef CREATED_ON_FACETS
    k_on_facets = xlenter(":ON-FACETS");
#define CREATED_ON_FACETS
#endif

#ifndef CREATED_ON_POINTS
    k_on_points = xlenter(":ON-POINTS");
#define CREATED_ON_POINTS
#endif

#ifndef CREATED_SOLID
    k_solid = xlenter(":SOLID");
#define CREATED_SOLID
#endif

#ifndef CREATED_FACETS
    k_facets = xlenter(":FACETS");
#define CREATED_FACETS
#endif

#ifndef CREATED_WIREFRAME
    k_wireframe = xlenter(":WIRE-FRAME");
#define CREATED_WIREFRAME
#endif

#ifndef CREATED_POINTCLOUD
    k_pointcloud = xlenter(":POINT-CLOUD");
#define CREATED_POINTCLOUD
#endif

#ifndef CREATED_INVISIBLE
    k_invisible = xlenter(":INVISIBLE");
#define CREATED_INVISIBLE
#endif

#ifndef CREATED_FOREGROUND
    k_foreground = xlenter(":FOREGROUND");
#define CREATED_FOREGROUND
#endif

#ifndef CREATED_BACKGROUND
    k_background = xlenter(":BACKGROUND");
#define CREATED_BACKGROUND
#endif


#ifndef CREATED_POINTIF
    k_pointif = xlenter(":POINT-IF");/* Keyword ":POINT-IF" */
#define CREATED_POINTIF
#endif

#ifndef CREATED_TEXTURE
    k_texture = xlenter(":TEXTURE");
#define CREATED_TEXTURE
#endif

#ifndef CREATED_POINTTEXTUREU
    k_pointtextureu = xlenter(":POINT-TEXTURE-U");
#define CREATED_POINTTEXTUREU
#endif

#ifndef CREATED_POINTTEXTUREV
    k_pointtexturev = xlenter(":POINT-TEXTURE-V");
#define CREATED_POINTTEXTUREV
#endif

#ifndef CREATED_FACETTEXTUREU0
    k_facettextureu0 = xlenter(":FACET-TEXTURE-U-0");
#define CREATED_FACETTEXTUREU0
#endif

#ifndef CREATED_FACETTEXTUREV0
    k_facettexturev0 = xlenter(":FACET-TEXTURE-V-0");
#define CREATED_FACETTEXTUREV0
#endif

#ifndef CREATED_FACETTEXTUREU1
    k_facettextureu1 = xlenter(":FACET-TEXTURE-U-1");
#define CREATED_FACETTEXTUREU1
#endif

#ifndef CREATED_FACETTEXTUREV1
    k_facettexturev1 = xlenter(":FACET-TEXTURE-V-1");
#define CREATED_FACETTEXTUREV1
#endif

#ifndef CREATED_FACETTEXTUREU2
    k_facettextureu2 = xlenter(":FACET-TEXTURE-U-2");
#define CREATED_FACETTEXTUREU2
#endif

#ifndef CREATED_FACETTEXTUREV2
    k_facettexturev2 = xlenter(":FACET-TEXTURE-V-2");
#define CREATED_FACETTEXTUREV2
#endif

#ifndef CREATED_FACETTEXTUREU3
    k_facettextureu3 = xlenter(":FACET-TEXTURE-U-3");
#define CREATED_FACETTEXTUREU3
#endif

#ifndef CREATED_FACETTEXTUREV3
    k_facettexturev3 = xlenter(":FACET-TEXTURE-V-3");
#define CREATED_FACETTEXTUREV3
#endif

#ifndef CREATED_FACETNEIGHBOR0
    k_facetneighbor0 = xlenter(":FACET-NEIGHBOR-0");
#define CREATED_FACETNEIGHBOR0
#endif

#ifndef CREATED_FACETNEIGHBOR1
    k_facetneighbor1 = xlenter(":FACET-NEIGHBOR-1");
#define CREATED_FACETNEIGHBOR1
#endif

#ifndef CREATED_FACETNEIGHBOR2
    k_facetneighbor2 = xlenter(":FACET-NEIGHBOR-2");
#define CREATED_FACETNEIGHBOR2
#endif

#ifndef CREATED_FACETNEIGHBOR3
    k_facetneighbor3 = xlenter(":FACET-NEIGHBOR-3");
#define CREATED_FACETNEIGHBOR3
#endif

#ifndef CREATED_POINTX
    k_pointx = xlenter(":POINT-X");/* Keyword ":POINT-X" */
#define CREATED_POINTX
#endif

#ifndef CREATED_POINTY
    k_pointy = xlenter(":POINT-Y");/* Keyword ":POINT-Y" */
#define CREATED_POINTY
#endif

#ifndef CREATED_POINTZ
    k_pointz = xlenter(":POINT-Z");/* Keyword ":POINT-Z" */
#define CREATED_POINTZ
#endif



#ifndef CREATED_POINTNORMALX
    k_pointnormalx = xlenter(":POINT-NORMAL-X");/* Keyword ":POINT-NORMAL-X" */
#define CREATED_POINTNORMALX
#endif

#ifndef CREATED_POINTNORMALY
    k_pointnormaly = xlenter(":POINT-NORMAL-Y");/* Keyword ":POINT-NORMAL-Y" */
#define CREATED_POINTNORMALY
#endif

#ifndef CREATED_POINTNORMALZ
    k_pointnormalz = xlenter(":POINT-NORMAL-Z");/* Keyword ":POINT-NORMAL-Z" */
#define CREATED_POINTNORMALZ
#endif



#ifndef CREATED_POINTRED
    k_pointred = xlenter(":POINT-RED");/* Keyword ":POINT-RED" */
#define CREATED_POINTRED
#endif

#ifndef CREATED_POINTGREEN
    k_pointgreen = xlenter(":POINT-GREEN");/* Keyword ":POINT-GREEN" */
#define CREATED_POINTGREEN
#endif

#ifndef CREATED_POINTBLUE
    k_pointblue = xlenter(":POINT-BLUE");/* Keyword ":POINT-BLUE" */
#define CREATED_POINTBLUE
#endif



#ifndef CREATED_PIXELRED
    k_pixelred = xlenter(":PIXEL-RED");/* Keyword ":PIXEL-RED" */
#define CREATED_PIXELRED
#endif

#ifndef CREATED_PIXELGREEN
    k_pixelgreen = xlenter(":PIXEL-GREEN");/* Keyword ":PIXEL-GREEN" */
#define CREATED_PIXELGREEN
#endif

#ifndef CREATED_PIXELBLUE
    k_pixelblue = xlenter(":PIXEL-BLUE");/* Keyword ":PIXEL-BLUE" */
#define CREATED_PIXELBLUE
#endif

#ifndef CREATED_PIXELDEPTH
    k_pixeldepth = xlenter(":PIXEL-DEPTH");/* Keyword ":PIXEL-DEPTH" */
#define CREATED_PIXELDEPTH
#endif



#ifndef CREATED_FACETIF
    k_facetif = xlenter(":FACET-IF");/* Keyword ":FACET-IF" */
#define CREATED_FACETIF
#endif

#ifndef CREATED_FACET0
    k_facet0 = xlenter(":FACET-0");/* Keyword ":FACET-0" */
#define CREATED_FACET0
#endif

#ifndef CREATED_FACET1
    k_facet1 = xlenter(":FACET-1");/* Keyword ":FACET-1" */
#define CREATED_FACET1
#endif

#ifndef CREATED_FACET2
    k_facet2 = xlenter(":FACET-2");/* Keyword ":FACET-2" */
#define CREATED_FACET2
#endif

#ifndef CREATED_FACET3
    k_facet3 = xlenter(":FACET-3");/* Keyword ":FACET-3" */
#define CREATED_FACET3
#endif



#ifndef CREATED_FACETNORMALX
    k_facetnormalx = xlenter(":FACET-NORMAL-X");/* Keyword ":FACET-NORMAL-X" */
#define CREATED_FACETNORMALX
#endif

#ifndef CREATED_FACETNORMALY
    k_facetnormaly = xlenter(":FACET-NORMAL-Y");/* Keyword ":FACET-NORMAL-Y" */
#define CREATED_FACETNORMALY
#endif

#ifndef CREATED_FACETNORMALZ
    k_facetnormalz = xlenter(":FACET-NORMAL-Z");/* Keyword ":FACET-NORMAL-Z" */
#define CREATED_FACETNORMALZ
#endif



#ifndef CREATED_FACETRED
    k_facetred = xlenter(":FACET-RED");/* Keyword ":FACET-RED" */
#define CREATED_FACETRED
#endif

#ifndef CREATED_FACETGREEN
    k_facetgreen = xlenter(":FACET-GREEN");/* Keyword ":FACET-GREEN" */
#define CREATED_FACETGREEN
#endif

#ifndef CREATED_FACETBLUE
    k_facetblue = xlenter(":FACET-BLUE");/* Keyword ":FACET-BLUE" */
#define CREATED_FACETBLUE
#endif


#ifndef CREATED_WANT
    k_want = xlenter(":WANT");/* Keyword ":WANT" */
#define CREATED_WANT
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
#ifdef MAYBE_SOMEDAY
    xgbj56_Enter_Messages( lv_x03d,  xthl_table );
#endif
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
