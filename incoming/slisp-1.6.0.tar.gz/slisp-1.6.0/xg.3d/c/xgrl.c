/* {{{ xgrl.c -- graphic relations.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Jan26
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 94Dec12 jsp: k_ary wasn't being initialized in xgrl00_Is_New().     	*/
/* 92Apr09 jsp: Validate().                                          	*/
/* 92Feb22 jsp: Finished&tested aref/setf/push/pop/[setf]fillpointer.	*/
/* 92Feb22 jsp: Factored iterations into xgrl14_Map_ArrayList.		*/
/* 92Feb09 jsp: Array_List_Length, Array_List_Nth.     			*/
/* 92Feb09 jsp: Array_List_Length, Array_List_Nth.     			*/
/* 92Feb04 jsp: String_Msg, Symbol_Msg.         			*/
/* 91Jul15 jdp: Get_Msg, Put_Msg, Bounding_Box.				*/
/* 91Jan26 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"


extern LVAL lv_xgrl;

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 
extern LVAL xsendmsg1();
extern LVAL xgtmDx_Draw_Lotsa_Stuff();

extern LVAL k_adjustarray;
extern LVAL k_fillpointer;
extern LVAL k_initialcontents;
extern LVAL k_initialelement;
extern LVAL k_pointx;
extern LVAL k_pointy;
extern LVAL k_pointz;
extern LVAL k_rmaref;
extern LVAL k_rmsetf;
extern LVAL k_setffillpointer;
extern LVAL k_show;
extern LVAL k_copy;
extern LVAL k_to;
extern LVAL s_arraylist;
extern LVAL k_start;
extern LVAL k_end;

#include <math.h>
#include <stdlib.h>
#include "csry.h"
#include "geo.h"
#include "lib.h"
#include "cgrl.h"
#include "cmtl.h"
#include "cmdl.h"
#include "clgt.h"
#include "cflv.h"
#include "c01v.h"
#include "c03d.h"
#include "cthl.h"
#include "c32v.h"
#include "cu8v.h"
#include "ctfm.h"

/* Forward declarations: */
LVAL*  xgrl13_pArrayList();
LVAL   xgrl23_RowMajorAref();
LVAL   xgrl27_AdjustArray();
LVAL   xgrl41_SetArray();
/* Imported fns: */
extern float xflv40_Max();
extern float xflv42_Min();
  
/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xgrl--Describe xgrls to csry.c...'cept we rarely/never call it ;)*/

/* int abort(); */
extern LVAL xsry22_AdjustArray();
LOCAL struct csry_struct xgrl_rec = {
    /* int  k_class             = */ C03D_xGRL,
    /* int  sizeof_struct       = */ 0,
    /* int  (*list_to_struct)() = */ NULL,
    /* LVAL (*struct_to_list)() = */ NULL,
    /* int  (*sprintf_struct)() = */ NULL,
    /* int  (*initfn)        ();= */ NULL,
    /* int  (*copy_struct)   () = */ NULL,
    /* LVAL k_ary               = */ NULL,
    /* int  (*from_buf)      ();= */ (int(*)())abort, /* Should never be called. */
    /* int  (*  to_buf)      ();= */ (int(*)())abort, /* "                     " */
    /* LVAL (*adjust_array)  ();= */ xsry22_AdjustArray,
    /* LVAL (*position)      ();= */ NULL,
    /* LVAL (*delete)        ();= */ NULL,
};
/*-
    Describe our type to csry.c.
-*/

/* }}} */
/* {{{ xgrl00_Is_New -- Initialize a new xgrl instance.			*/

LVAL xgrl00_Is_New()
{   extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    xgrl_rec.k_ary = lv_xgrl;

#if DOESNT_WORK_NOW
    if (!xgrlp(m))   xlbadtype(m);
#endif

    /* Allocate space for array header: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( csry_rec ) );
    {   csry_rec* h  = (csry_rec*) gobjimmbase( lv );
	h->s         = &xgrl_rec;
	h->k_class   = xgrl_rec.k_class;
	h->fileInfo  = c03d_fileInfo_Init;
        xfil50_Maybe_Note_New_3D_Object( lv );

        /* (*s->initfn)( h ); /* No default_initializer for grls... */
    }

    return xgrl27_AdjustArray( lv );
}

/* }}} */
/* {{{ xgrl01_Get_A_XGRL -- Get arg, must be of class xgrl.		*/

xgrl0h_Must_Be_A_XGRL(m_as_lval)
LVAL                  m_as_lval;
{
    if (!xgrlp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) != sizeof(csry_rec) 
    ) {
        xlbadtype(m_as_lval);
    }
}
LVAL xgrl01_Get_A_XGRL() /* Also called from xcmr... */
/*-
    Get arg, must be of class xgrl.
-*/
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XGRL has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xgrl.  Similarly,          */
    /* nobody but nobody has any business resizing a xgrl,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    xgrl0h_Must_Be_A_XGRL(m_as_lval);

    return m_as_lval;
}

/* }}} */
/* {{{ xgrl21_AdjustArray_Msg -- Change shape of grl.			*/

xgrl20_AdjustSubarray( shape, name, array )
LVAL		       shape, name, array;
{
    xsendmsg1( array, k_adjustarray, shape );
    return FALSE; /* Keep iterating */
}

LVAL xgrl22_AdjustArray( gobject, new_h, shape )
LVAL		         gobject;
csry_rec*			  new_h;
LVAL                                     shape;
/*-
    Change shape of grl array, set up default values.
-*/
{
    csry_rec* h;
    int total_slots   = xsry20_ArrayTotalSize( new_h );

    h		      = (csry_rec*) gobjimmbase( gobject );
    h->k_class	      = C03D_xGRL;

    /* Reset all arrays: */
    xgrl14_Map_ArrayList( gobject, xgrl20_AdjustSubarray, shape );

    /* Remember new shape: */
    {   int i;
	h->rank = new_h->rank;
	h->size = total_slots;
	for (i = h->rank;   i --> 0;   )   h->dim[i] = new_h->dim[i];
	if (h->rank == 1)  h->dim[1] = -1; /* No fill pointer */
    }

    return gobject;
}

LVAL xgrl27_AdjustArray( lv )
LVAL			 lv;
/*-
    Change shape of imm array, process 
    :INITIAL-CONTENTS and :INITIAL-ELEMENT.
-*/
{
    FORWARD LVAL xgrl22_AdjustArray();
    LVAL shape = moreargs() ? xlgetarg() : NIL;
    csry_rec hx;
    xlprot1(shape);
    xsry14_Figure_Shape(    &hx, shape );
    xgrl22_AdjustArray( lv, &hx, shape );
    xlpop(); /* shape */

    while (moreargs()) {
        LVAL       key = xlgasymbol();
        if        (key == k_initialcontents) {

            /* Handle ":initial-contents '((1 0 0)(...)(...)(...)...)" */
            xgrl15_Initial_Contents( lv, xlgalist() );

        } else if (key == k_initialelement) {

            /* Handle ":initial-element 2.0 ..." */
            xgrl16_Initial_Element( lv, xlgetarg() );

        } else if (key == k_fillpointer) {

            /* Handle ":fill-pointer t ..." */
            xgrl30_Fill_Pointer( lv, xlgetarg() );

	} else {

            xlbadinit(key);
        }
    }
    x03d9d_Maybe_Run_PerframeHooks( lv );

    return lv;
}
LVAL xgrl21_AdjustArray_Msg()
/*-
    Change shape of imm array.
-*/
{
    /* Get gobject and requested array size: */
    return xgrl27_AdjustArray( xlgagobject() );
}

/* }}} */
/* {{{ xgrl03_Show_Msg -- Show the contents of a cgrl.			*/

xgrl02_Show_Subarray( fptr, name, array )
LVAL		      fptr, name, array;
{
    xlputstr(fptr,"Subarray ");
    xlprint(fptr,name,TRUE);
    xlputstr(fptr," = ");
    xlterpri(fptr);
    xsendmsg0(array,k_show);
    return FALSE; /* Continue iteration. */
}

LVAL xgrl03_Show_Msg()
/*-
    Show the contents of a grl.
-*/
{
    LVAL self,fptr;
    int i;
    csry_rec* h;

    /* get self and the file pointer */
    self = xgrl01_Get_A_XGRL();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the grl's arrays: */
    xgrl14_Map_ArrayList( self, xgrl02_Show_Subarray, fptr );

    return self;
}

/* }}} */
/* {{{ xgrl04_Aref_Msg -- Get given entry.				*/

struct xgrl0b_rec {
   LVAL result;
   LVAL index;
};
xgrl0a_Subarray_Aref( fa, name, array )
struct xgrl0b_rec *   fa;
LVAL		          name, array;
{
    LVAL aref_val = xsendmsg1(array,k_rmaref,fa->index);
    xlprot1(aref_val);
    fa->result    = cons( aref_val, fa->result );
    fa->result    = cons( name    , fa->result );
    xlpop(); /* aref_val */
    return FALSE; /* Continue iteration. */
}
LVAL xgrl0g_Aref( m_as_lval, i_as_lval )
LVAL	          m_as_lval, i_as_lval;
{
    struct xgrl0b_rec r;
    xlstkcheck(2);
    xlsave(r.result);
    xlsave(r.index);
    r.index = i_as_lval;
    xgrl14_Map_ArrayList( m_as_lval, xgrl0a_Subarray_Aref, &r );
    xlpopn(2); /* r.result */
    return r.result;
}
LVAL xgrl05_Aref( m_as_lval, i )
LVAL		  m_as_lval;
int                          i;
{
    return xgrl23_RowMajorAref( m_as_lval, cvfixnum(i) );
}

LVAL xgrl04_Aref_Msg()
/*-
    Get given entry.
-*/
{
    LVAL m_as_lval = xgrl01_Get_A_XGRL();
    return xgrl05_Aref(
        m_as_lval,
        xsry02_Get_Index( m_as_lval )
    );
}

/* }}} */
/* {{{ xgrl06_Setf_Msg -- Set given entry.				*/

struct xgrl0d_rec {
   LVAL v_as_lval; /* [:array-name  array-value-to-store]* list. */
   LVAL our_index; /* Index to store value at in each subarray.  */
   LVAL our_name;  /* Keyword for this particular array.         */
   LVAL our_array; /*             This particular array.         */
   LVAL our_value; /* Value   for this particular array.         */
};
xgrl0c_Find_Value_To_Store( r, name, value )
struct xgrl0d_rec *         r;
LVAL		               name, value;
{
    if (name == r->our_name) {
	/* Found the value to store: */
	r->our_value   = value;
	return TRUE; /* Stop iteration. */
    }
    return FALSE; /* Continue iteration. */
}
xgrl0e_Setf_Subarray( r, name, array )
struct xgrl0d_rec *   r;
LVAL		         name, array;
{
    /* Find value to store, letting it default to NIL if not given: */
    r->our_array  = array;
    r->our_name   = name;
    r->our_value  = NIL;
    x03d14_Map_PairList( r->v_as_lval, xgrl0c_Find_Value_To_Store, r );

    /* Do the store: */
    xsendmsg2(r->our_array,k_rmsetf,r->our_value,r->our_index);

    return FALSE; /* Continue iteration. */
}
LVAL xgrl0f_Setf( m_as_lval, i_as_lval, v_as_lval )
LVAL	          m_as_lval, i_as_lval, v_as_lval;
{
    /* Stash args where our subfns can find them: */
    struct xgrl0d_rec r;
    xlstkcheck(2);
    xlsave(r.v_as_lval);
    xlsave(r.our_index);
    r.our_index = i_as_lval;
    r.v_as_lval = v_as_lval;

    /* Set given slot of every array in the graphic relation: */
    xgrl14_Map_ArrayList( m_as_lval, xgrl0e_Setf_Subarray, &r );

    xlpopn(2);
    return r.v_as_lval;
}

LVAL xgrl07_Setf( m_as_lval, i, v_as_lval )
LVAL		  m_as_lval;
int                          i;
LVAL		  		v_as_lval;
/*-
    Set given entry.
-*/
{
    return xgrl0f_Setf( m_as_lval, cvfixnum(i), v_as_lval );
}

LVAL xgrl06_Setf_Msg()
/*-
    Set given entry.
-*/
{
    LVAL m_as_lval = xgrl01_Get_A_XGRL();
    LVAL v_as_lval = xlgalist();
    return xgrl07_Setf(
        m_as_lval,
        xsry02_Get_Index( m_as_lval ),
        v_as_lval
    );
}

/* }}} */
/* {{{ xgrl08_Copy_Msg -- Build copy of given CGRL.			*/

LVAL
xgrl0x_Copy_ArrayList(
    LVAL lv_grl,	/* Relation holding arraylist	*/
    LVAL lv_orig	/* Arraylist.			*/
) {
    int  toProt = 7;
    LVAL lv_head;  /* First cell of duplicate list.   */
    LVAL lv_this;  /* Last  cell of duplicate list.   */
    LVAL lv_next;  /* Latest cell under construction. */
    LVAL lv_list;  /* Cell being duplicated in lv_orig*/
    LVAL lv_ary;   /* Array being duplicated. (tmp).  */
    xlstkcheck(toProt);
    xlprotect(lv_grl );
    xlprotect(lv_orig);
    xlsave(   lv_list);
    xlsave(   lv_this);
    xlsave(   lv_next);
    xlsave(   lv_head);
    xlsave(   lv_ary );
    lv_list = lv_orig;

    while (!null(lv_list)) {
	/* Check that we do indeed have a cons cell: */
	if (!consp(lv_list)) {
	    xlerror(":COPY: bad array-list on relation?!",lv_orig);
	}

	/* Construct cell containing array name (a keyword): */
	lv_next = cons( car(lv_list), NIL );

	/* Append array-name cell to growing duplicate list: */
	if (lv_this==NIL)    lv_head = lv_next;
        else                 rplacd(lv_this,lv_next);
	/* Keep 'this' pointing to end cell: */
	lv_this = lv_next;

	/* Step to cell containing array proper: */
	lv_list = cdr(lv_list);
	if (!consp(lv_list)) {
	    xlerror(":COPY: bad array-list on relation?!",lv_orig);
	}

	/* Find the array we want to copy: */
	lv_ary = car(lv_list);
	/* Make sure that it's an appropriate value: */
	if (!xgrl4d_Is_Compatible_Array_Type( lv_grl, lv_ary )) {
	    xlerror(":COPY: non-array in array-list?!",lv_orig);
	}
	/* Make a copy of the array: */
	lv_ary = xsendmsg0(lv_ary,k_copy);
	lv_next = cons( lv_ary, NIL );

	/* Append array cell to growing duplicate list: */
        rplacd(lv_this,lv_next);
	/* Keep 'this' pointing to end cell: */
	lv_this = lv_next;

	lv_list = cdr(lv_list);	
    }

    xlpopn(toProt);

    /* Return duplicate arraylist: */
    return lv_head;
}

LVAL xgrl09_Copy( lv_m, depth )
LVAL		  lv_m;
int                     depth;
/*-
    Build copy of given CGRL.
-*/
{
    /* Create a new array to hold result: */
    csry_rec*mh = xsry9c_Find_Immediate_Base( lv_m );
    int  toProt = 2;
    LVAL lv_r;
    xlstkcheck(toProt);
    xlprotect(lv_m);
    xlsave(   lv_r);
    lv_r  = xsendmsg0(mh->s->k_ary,k_new);

    /* Set new matrix to shape of old matrix: */
    xsry22_AdjustArray( lv_r, mh );

    /* Get list of arrays in original object: */
    {   LVAL* pArrayListM = xgrl13_pArrayList( lv_m );
	/* Duplicate it, including the arrays: */
	LVAL  dupList    = xgrl0x_Copy_ArrayList( lv_m, *pArrayListM );
	/* Locate list of arrays in new object: */
	LVAL* pArrayListR = xgrl13_pArrayList( lv_r );
	/* Overwrite it with our duplicate: */
	*pArrayListR = dupList;
    }

    /* Copy property list as well: */
    x03d81_CopyProplist( lv_r, lv_m, depth );

    xlpopn(toProt);
    return lv_r;
}

LVAL xgrl08_Copy_Msg()
/*-
    Build copy of given CGRL.
-*/
{   LVAL lv_m;
    LVAL lv_x = xgrl01_Get_A_XGRL();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    return xgrl09_Copy( lv_x, depth );
}

/* }}} */
/* {{{ xgrl13_pArrayList -- Return pointer to array list for grl. 	*/

LVAL* xgrl13_pArrayList( m )
LVAL                     m;
{   /* Return pointer to array list for grl.*/

    /* Find our list of arrays: */
    LVAL*pArrayList;
    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
        m,
        getclass( m ),
        s_arraylist,
        &pArrayList
    );
    return pArrayList;
}

/* }}} */
/* {{{ xgrl14_Map_ArrayList -- Iterate over array list for grl. 	*/

xgrl14_Map_ArrayList( lv_grl, fn,    fa )
LVAL                  lv_grl;
int			    (*fn)(),*fa;
{   LVAL*pArrayList = xgrl13_pArrayList( lv_grl );
    return x03d14_Map_PairList( *pArrayList, fn, fa );
}

/* }}} */
/* {{{ xgrl15_Initial_Contents -- Apply an initializer list.		*/

xgrl15_Initial_Contents( m, init )
LVAL		         m, init;
{
    /********************************************/
    /* Apply an initializer list to array.      */
    /* m:     Array being initialized.          */
    /* init:  Our part of the initializer tree. */
    /********************************************/

    /* Find our list of arrays: */
    LVAL* pArrayList = xgrl13_pArrayList( m );
    LVAL  arrayList  = *pArrayList;
    xlprot1(arrayList);

    while (init != NIL) {
	LVAL prop;
	LVAL val;
        xlstkcheck(2);
	xlsave(prop);
	xlsave(val);

	/* Get property symbol: */
	if (!consp(init))     xlbadinit(init);
	prop = car(init);
	if (!symbolp(prop))   xlbadinit(prop);
	init = cdr(init);

	/* Get property value: */
	if (!consp(init))     xlbadinit(init);
	val  = car(init);
	init = cdr(init);

	/* Add array val to xgrl: */
        xgrl41_SetArray( m, pArrayList, prop, val );

	xlpopn(2);   /* prop,val  */
    }
    xlpop(); /* arraylist */
}

/* }}} */
/* {{{ xgrl16_Initial_Element--Initialize array to given initial element*/

xgrl16_Initial_Element( m, el )
LVAL		        m, el;
/*-
    Initialize array to given initial element.
    Apply an initializer list to array.
    m:     Array being initialized.
    el:    Initial element.
-*/
{
    csry_rec* h   = (csry_rec*) gobjimmbase( m );
    int       i;
    char*     dst = csry_base(m);
    char*     src = dst;
    int       siz = h->s->sizeof_struct;
    int       len = h->size;

#ifdef XGRL_IS_PARANOID
    if (len < 1)   xlfail("xgrl16:internal error");
#endif

    /* Convert el to internal array form: */
    h->s->list_to_struct( dst, el, h );

    /* Copy initial element all over array: */
    for (i = 1;   i < len;   ++i) {
	dst += siz;
        h->s->bcopy( dst, src );
    }
}

/* }}} */
/* {{{ xgrl23_RowMajorAref -- Get given entry, ignoring shape.		*/

LVAL xgrl23_RowMajorAref( m_as_lval, i_as_lval )
LVAL		          m_as_lval, i_as_lval;
/*-
    Get given entry, ignoring shape.
-*/
{
    csry_rec* h = xsry9c_Find_Immediate_Base( m_as_lval );
    char*     p = csry_base(                  m_as_lval );
    int       i = getfixnum( i_as_lval );
    if (i < 0 || i >= h->size) xlerror("bad index value",i_as_lval);
    return xgrl0g_Aref( m_as_lval, i_as_lval );
}

LVAL xgrl24_RowMajorAref_Msg()
/*-
    Get given entry, ignoring shape.  Message protocol.
-*/
{
    LVAL m_as_lval = xgrl01_Get_A_XGRL();
    LVAL i_as_lval = xlgafixnum();
    xllastarg();
    return xgrl23_RowMajorAref(m_as_lval,i_as_lval);
}

/* }}} */
/* {{{ xgrl25_RowMajorSetf -- Set given entry, ignoring shape.		*/

LVAL xgrl25_RowMajorSetf( m_as_lval, i_as_lval, v_as_lval )
LVAL		          m_as_lval, i_as_lval, v_as_lval;
/*-
    Set given entry, ignoring shape.
-*/
{
    csry_rec* h = xsry9c_Find_Immediate_Base( m_as_lval );
    char*     p = csry_base(               m_as_lval );
    int       i = getfixnum( i_as_lval );
    if (i < 0 || i >= h->size) xlerror("bad index value",i_as_lval);
    p          += i * h->s->sizeof_struct;
    h->s->list_to_struct( p, v_as_lval, h );
    return v_as_lval;
}

LVAL xgrl26_RowMajorSetf_Msg()
/*-
    Set given entry, ignoring shape.  Message protocol.
-*/
{
    LVAL m_as_lval = xgrl01_Get_A_XGRL();
    LVAL v_as_lval = xlgetarg();
    LVAL i_as_lval = xlgafixnum();
    xllastarg();
    return xgrl25_RowMajorSetf(m_as_lval,i_as_lval,v_as_lval);
}

/* }}} */
/* {{{ xgrl28_Equal -- Compare two arrays for equality.			*/

LVAL xgrl28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    xlerror(":EQUALP of grls not implemented yet",m_as_lval);
}

LVAL xgrl29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xgrl01_Get_A_XGRL();
    LVAL n_as_lval = xgrl01_Get_A_XGRL();
    xllastarg();
    return xgrl28_Equal( m_as_lval, n_as_lval );
}

/* }}} */
/* {{{ xgrl30_Fill_Pointer--Set fill pointer to :FILL-POINTER value.	*/

xgrl3b_Set_Fill_Pointer_Of_Subarray( i_as_lval, name, array )
LVAL				     i_as_lval, name, array;
{
    xsendmsg1( array, k_setffillpointer, i_as_lval );
    return FALSE; /* Continue iteration. */
}
xgrl30_Fill_Pointer( m_as_lval, fill_as_lval )
LVAL		     m_as_lval, fill_as_lval;
/*-
    Set fill pointer to :FILL-POINTER value.
-*/
{
    csry_rec* h   = xsry9c_Find_Immediate_Base( m_as_lval );
    extern LVAL true;/*xlglob.c*/

    if (h->rank != 1) {
	xlerror( ":FILL-POINTER: Array rank must be 1", m_as_lval );
    }

    if (null( fill_as_lval )) {
	h->dim[1] = 0;
	xgrl14_Map_ArrayList(
	    m_as_lval,
	    xgrl3b_Set_Fill_Pointer_Of_Subarray,
	    cvfixnum(0) /* Don't need to gc-protect zero :) */
	);
        return;
    }

    if (fill_as_lval == true) {
	LVAL size_as_lval;
	xlsave1(size_as_lval);
	h->dim[1] = h->size;
	xgrl14_Map_ArrayList(
	    m_as_lval,
	    xgrl3b_Set_Fill_Pointer_Of_Subarray,
	    size_as_lval = cvfixnum(h->size)
	);
	xlpop();
        return;
    }

    if (fixp( fill_as_lval )) {
	int f = getfixnum( fill_as_lval );
	if (f >= 0 && f <= h->size) {
	    h->dim[1] = f;
	    xgrl14_Map_ArrayList(
		m_as_lval,
		xgrl3b_Set_Fill_Pointer_Of_Subarray,
		fill_as_lval
	    );
	    return;
	}
    }

    xlerror("Bad :FILL-POINTER",fill_as_lval);
}

/* }}} */
/* {{{ xgrl31_Get_Array_With_Fill_Pointer				*/

LVAL xgrl31_Get_Array_With_Fill_Pointer( hp )
csry_rec**				 hp;
/*-
-*/
{
    LVAL a_as_lval = xgrl01_Get_A_XGRL();
    csry_rec* h    = xsry9c_Find_Immediate_Base( a_as_lval );
    if (h->rank != 1)   xlerror("No fill pointer",a_as_lval);
    if (h->dim[1] == -1)   h->dim[1] = 0;
    *hp = h;
    return a_as_lval;
}

/* }}} */
/* {{{ xgrl32_Fill_Pointer_Msg -- Return fill pointer.			*/

LVAL xgrl32_Fill_Pointer_Msg()
/*-
    Return fill pointer.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = xgrl31_Get_Array_With_Fill_Pointer( &h );
    return cvfixnum( h->dim[1] );
}

/* }}} */
/* {{{ xgrl34_Vector_Push_Msg -- Push element onto array.		*/

LVAL xgrl33_Vector_Push( a_as_lval, v_as_lval, h )
LVAL			 a_as_lval, v_as_lval;
csry_rec*				       h;
/*-
    Push element onto array, sufficient space guaranteed.
-*/
{
    int   i             = h->dim[1];
    LVAL  old_i_as_lval;
    LVAL  new_i_as_lval;
    if (i < 0 || i >= h->size)   return NIL;
    xlstkcheck(2);
    xlsave( old_i_as_lval );
    xlsave( new_i_as_lval );
    old_i_as_lval = cvfixnum( i   );
    new_i_as_lval = cvfixnum( i+1 );

    /* Do an assignment to all our subarrays: */
    xgrl0f_Setf( a_as_lval, old_i_as_lval, v_as_lval );

    /* Bump our fill pointer: */
    h->dim[1]      = i+1;

    /* Set all our arrays to have same fillpointer as us: */
    xgrl30_Fill_Pointer( a_as_lval, new_i_as_lval );

    xlpopn(2);
    return old_i_as_lval;
}

LVAL xgrl34_Vector_Push_Msg()
/*-
    Push element onto array.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = xgrl31_Get_Array_With_Fill_Pointer( &h );
    LVAL v_as_lval = xlgalist();
    return xgrl33_Vector_Push( a_as_lval, v_as_lval, h );
}

/* }}} */
/* {{{ xgrl35_Vector_Push_Extend_Msg -- Push element onto array.	*/

LVAL xgrlZ0_Vector_Push_Extend( a_as_lval, v_as_lval, h )
LVAL                            a_as_lval, v_as_lval;
csry_rec*                                             h;
/*-
      Push element onto array.
-*/
{
    /* If fillpointer has reached end of array, expand array: */
    int i = h->dim[1];
    if (i == h->size) {
	csry_rec  hx;
	LVAL shape;
	hx.rank    = 1;
	hx.dim[0]  = (
            i +
            CSRY_VECTOR_EXPANSION_INCREMENT +
           (h->size / CSRY_VECTOR_EXPANSION_RATIO)
        );
	/* The following will actually remove the fillpointers */
	/* from all our subarrays, but the Set_Fill_Pointer we */
	/* are about to do in xgrl33_Vector_Push will re-build */
	/* them:					       */
	shape = cvfixnum(hx.dim[0]);
	xlprot1(shape);
        xgrl22_AdjustArray( a_as_lval, &hx, shape );
	xlpop();
	/* Gotcha #1: Header may have moved: */
	h          = (csry_rec*) gobjimmbase( a_as_lval );
	/* Gotcha #2: Fill pointer will have been reset: */
	h->dim[1]  = i;
    }

    return xgrl33_Vector_Push( a_as_lval, v_as_lval, h );
}

LVAL xgrl35_Vector_Push_Extend_Msg()
/*-
    Push element onto array.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = xgrl31_Get_Array_With_Fill_Pointer( &h );
    LVAL v_as_lval = moreargs() ? xlgetarg() : NIL;
    return xgrlZ0_Vector_Push_Extend( a_as_lval, v_as_lval, h );
}

/* }}} */
/* {{{ xgrl36_Vector_Pop_Msg -- Pop element off array.			*/

LVAL xgrl36_Vector_Pop_Msg()
/*-
    Pop element off array.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = xgrl31_Get_Array_With_Fill_Pointer( &h );
    char* p        = csry_base( a_as_lval );
    int i          = h->dim[1];

    if (i <= 0 || i > h->size)   xlerror("Can't pop empty relation",a_as_lval);

    h->dim[1]      = --i;

    {   /* Set all our arrays to have same fillpointer as us: */
	LVAL    result;
	LVAL    i_as_lval = cvfixnum(i);
	xlprot1(i_as_lval);
	xgrl30_Fill_Pointer( a_as_lval, i_as_lval );

	/* Return popped element: */
	result = xgrl23_RowMajorAref( a_as_lval, i_as_lval );
	xlpop();
	return result;
    }
}

/* }}} */
/* {{{ xgrl37_Setf_Fill_Pointer_Msg -- Set fill pointer.		*/

LVAL xgrl37_Setf_Fill_Pointer_Msg()
/*-
    Set fill pointer.
-*/
{
#ifdef STRICT_COMMONLISP
    csry_rec* h;
    LVAL    a_as_lval = xgrl31_Get_Array_With_Fill_Pointer( &h );
#else
    /* We allow adding a fill pointer to our relations after-the-fact: */
    LVAL a_as_lval = xgrl01_Get_A_XGRL();
#endif
    LVAL fill_as_lval = xlgetarg();
    xgrl30_Fill_Pointer( a_as_lval, fill_as_lval );
    return   fill_as_lval;
}

/* }}} */
/* {{{ xgrl40_GetArray_Msg -- Fetch named array.			*/

LVAL  xgrl39_GetArray( pArrayList, key )    
LVAL                  *pArrayList, key;
{
    return xthl74_GetProp( pArrayList, key, /*deflt_val*/NIL,/*got_default*/FALSE );
}
/* Called by xlsp.c: */
LVAL xgrl3c_Get_Array( g_as_lval, key, default_val, got_default )
LVAL		       g_as_lval, key, default_val;
int					            got_default;
{
    return xthl74_GetProp(xgrl13_pArrayList(g_as_lval), key, default_val, got_default);
}
LVAL xgrl3a_GetArray( g_as_lval )
LVAL		      g_as_lval;
{
    LVAL key         = xlgasymbol();
    LVAL*pArrayList  = xgrl13_pArrayList( g_as_lval );
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    return xthl74_GetProp( pArrayList, key, default_val, got_default );
}
LVAL xgrl40_GetArray_Msg()
{
    return xgrl3a_GetArray( xgrl01_Get_A_XGRL() );
}

/* }}} */
/* {{{ xgrl42_SetArray_Msg -- Store named array.			*/

xgrl4d_Is_Compatible_Array_Type( g_as_lval, lv_ary )
LVAL                             g_as_lval, lv_ary;
{
    /* Check that value is right type and shape: */
    csry_rec* h     = xsry9c_Find_Immediate_Base( g_as_lval );
    csry_rec* ah;
    int       g_class = 0;
    if (!gobjectp(lv_ary)
    ||  getgobjimmbytes(lv_ary) < sizeof(csry_rec) 
    ||  !(ah = xsry9c_Find_Immediate_Base(lv_ary))
    ||  !(g_class = ah->k_class)
    ||  !C03D_IS_GRL_CLASS(g_class)
    ){
printf("xgrl4d_Is_Compatible_Array_Type/FALSE: g_class x=%x C03D_IS_GRL_CLASS(g_class) x=%x\n",g_class,C03D_IS_GRL_CLASS(g_class));
	return FALSE;
    }
    return TRUE;
}
xgrl4c_Is_Compatible_Array( g_as_lval, ary )
LVAL                        g_as_lval, ary;
{
    /* Check that value is right type and shape: */
    if (!xgrl4d_Is_Compatible_Array_Type( g_as_lval, ary )) {
printf("wrong type");
	return FALSE;
    }
    {   csry_rec* h  = xsry9c_Find_Immediate_Base( g_as_lval );
        csry_rec* ah = xsry9c_Find_Immediate_Base( ary );
        if (!xgrl99_Same_Shape( h, ah )) {
printf("wrong shape");
            return FALSE;
	}
    }
    return TRUE;
}
xgrl4a_Check_Array_Shape( g_as_lval, ary )
LVAL                      g_as_lval, ary;
{
    if (!xgrl4c_Is_Compatible_Array( g_as_lval, ary )) {
	xlerror("Array is incompatible with relation",ary);
    }
}
LVAL xgrl41_SetArray( lv_grl,  pArrayList, lv_key, lv_val )
LVAL                  lv_grl, *pArrayList, lv_key, lv_val;
{
    /* If val isn't an array, should be class of array to create: */
    if (!gobjectp(lv_val)) {

	/* Create array (?) of given type: */
	LVAL lv_ary = xsendmsg0(lv_val,k_new);

	/* Check that we got a reasonable array class: */
	if (!xgrl4d_Is_Compatible_Array_Type( lv_grl, lv_ary )) {
	    xlerror("Array type is incompatible with relation",lv_val);
	} else {
	    lv_val = lv_ary;
	}

	/* Set array size and shape to match our grl: */
        {   csry_rec* hr = xsry9c_Find_Immediate_Base( lv_grl );
            csry_rec* ha = xsry9c_Find_Immediate_Base( lv_val );
	    ha->s->adjust_array( lv_val, hr );
    }   }

    xgrl4a_Check_Array_Shape( lv_grl, lv_val );

    /* Add new array to xgrl: */
    return xthl82_SetProp( pArrayList, lv_key, lv_val );
}
LVAL xgrl4b_SetArray( g_as_lval, key, val ) /* Called from xlsp.c */
LVAL                  g_as_lval, key, val;
{
    return xgrl41_SetArray( g_as_lval, xgrl13_pArrayList(g_as_lval), key, val );
}
LVAL xgrl42_SetArray_Msg()
{
    LVAL g_as_lval  = xgrl01_Get_A_XGRL();
    LVAL*pArrayList = xgrl13_pArrayList( g_as_lval );
    LVAL key        = xlgasymbol();
    LVAL val        = xlgetarg(); /* Allow either array or class */
    xllastarg();
    return xgrl41_SetArray( g_as_lval, pArrayList, key, val );
}

/* }}} */
/* {{{ xgrl44_Validate -- Check that all arrays are right shape.	*/

xgrl44_Validate( g_as_lval )
LVAL             g_as_lval;
{
    LVAL p;
    LVAL* pArrayList;
    xgrl0h_Must_Be_A_XGRL(g_as_lval);
    pArrayList = xgrl13_pArrayList( g_as_lval );
    for (p = *pArrayList; consp(p) && consp(cdr(p)); p = cdr(cdr(p))) {
	xgrl4a_Check_Array_Shape( g_as_lval, car(cdr(p)) );
    }
}

/* }}} */
/* {{{ xgrl76_Get_Msg -- Get keyword properties.                        */

LVAL xgrl76_Get_Msg()
/*-
    Return keyword properties for an xgrl object.
-*/
{
    LVAL   x03d75_Get(			   );
    return x03d75_Get( xgrl01_Get_A_XGRL() );
}

/* }}} */
/* {{{ xgrl79_Set_Msg -- Write keyword properties.                      */

LVAL xgrl79_Set_Msg()
/*-
    Write keyword properties for an xgrl object.
-*/
{
    LVAL   x03d78_Set(			   );
    return x03d78_Set( xgrl01_Get_A_XGRL() );
}

/* }}} */
/* {{{ xgrl99_Same_Shape--Return TRUE iff given csry_recs are same shape*/

xgrl99_Same_Shape( h0, h1 )
csry_rec          *h0,*h1;
/*-
    Return TRUE iff given csry_recs are same shape.
-*/
{
    int rank = h0->rank;
    int i;
    if (h1->rank != rank) {
printf("h0->rank d=%d h1->rank d=%d\n",h0->rank,h1->rank);
	return FALSE;
    }
    for (i = rank;   i --> 0;   ) {
	if (h0->dim[i] != h1->dim[i]) {
printf("h0->dim[%d] d=%d h1->dim[%d] d=%d\n",i,h0->dim[i],i,h1->dim[i]);
	    return FALSE;
	}
    }
    return TRUE;
}

/* }}} */
/* {{{ xgrlA1_Bounding_Box_Msg -- Compute a bounding box of grl entries.*/

xgrlA0_Bounding_Box( min,  max,   pointx, pointy, pointz )
geo_point           *min, *max;
LVAL	                          pointx, pointy, pointz;
{
    min->x = xflv42_Min( pointx );
    min->y = xflv42_Min( pointy );
    min->z = xflv42_Min( pointz );

    max->x = xflv40_Max( pointx );
    max->y = xflv40_Max( pointy );
    max->z = xflv40_Max( pointz );
}

LVAL xgrlA1_Bounding_Box_Msg()
/*-
    Compute a bounding box for a set of x,y,z arrays.
-*/
{
    /* Compute the extrema: */
    geo_point min, max;
    LVAL m_as_lval  = xgrl01_Get_A_XGRL();
    LVAL*pArrayList = xgrl13_pArrayList( m_as_lval );
    LVAL pointx     = xgrl39_GetArray( pArrayList, k_pointx );
    LVAL pointy     = xgrl39_GetArray( pArrayList, k_pointy );
    LVAL pointz     = xgrl39_GetArray( pArrayList, k_pointz );
    int ansi_sux    = xgrlA0_Bounding_Box( &min, &max,   pointx, pointy, pointz );

    /* Store the extrema in a list: */
    LVAL result;
    xlsave1(result);
    result = cons( lib14_Point_To_List( &max ), NIL    );
    result = cons( lib14_Point_To_List( &min ), result );
    xlpop();
    return result;
}

/* }}} */
/* {{{ xgrla5_Delete_Msg						*/

struct xgrla2_rec {
   int start;
   int end  ;
};
xgrla3_Delete(     r, name, array )
struct xgrla2_rec* r;
LVAL		      name, array;
{
    /* Do the delete: */
    xsrya4_Delete( array, r->start, r->end );

    /* Continue iteration: */
    return FALSE;
}
int xgrla4_Delete( lv_ary, start, end, h )
LVAL	 	   lv_ary;
int                        start, end;
csry_rec*                              h;
{   
    int  gap = end-start;
    int  len                = h->size;
    if (h->dim[1] >= 0) len = h->dim[1];

    /* Stash args where our subfns can find them: */
    {   struct xgrla2_rec r;
	r.start  = start;
	r.end    = end;

	/* Set given slot of every array in the graphic relation: */
	xgrl14_Map_ArrayList( lv_ary, xgrla3_Delete, &r );

	/* Set fillpointer to reflect new length: */
	h->dim[1] =  len - gap;
    }
}

LVAL xgrla5_Delete_Msg()
{   csry_rec* h;
    LVAL lv_ary   = xgrl31_Get_Array_With_Fill_Pointer( &h );
    int  start    = 0;
    int  end      = h->dim[0];
    if (h->rank != 1)  xlerror("Relation must be one-dimensional to do :delete",lv_ary);
    /* Respect fillpointer: */
    if (h->dim[1] >= 0 && h->dim[1] < end)   end = h->dim[1];
    while (moreargs()) {
        LVAL lv_key      = xlgasymbol();
        LVAL lv_val      = xlgafixnum();
        int     val      = getfixnum(lv_val);
	if (lv_key == k_start) {
	    if (val < 0)     val = 0;
	    if (val > end-1) val = end-1;
	    start = val;
	} else if (lv_key == k_end) {
	    if (val < start+1)     val = start+1;
	    if (val > end)         val = end;
	    end = val;
	} else {
	    xlerror("Unsupported :delete keyword",lv_key);
	}
    }

    xgrla4_Delete( lv_ary, start, end, h );
    return NIL;
}

/* }}} */
/* {{{ xgrlEh_Logical_Size_Of_Grl					*/

xgrlEh_Logical_Size_Of_Grl( grl )
LVAL		    	    grl;
{    
    csry_rec *	h_grl    = xsry9c_Find_Immediate_Base( grl );
    if (h_grl->rank != 1)   return h_grl->size;
    if (h_grl->dim[1] < 0)  return h_grl->dim[0];  /* Have no fill-pointer. */
    return		           h_grl->dim[1];  /* Have a  fill-pointer. */
}

/* }}} */
/* {{{ xgrlF1_Array_List_Length_Msg -- Number of arrays in grl.		*/

int xgrlF0_Array_List_Length( g_as_lval, pArrayList )
LVAL			      g_as_lval,*pArrayList;
{       
    LVAL p;
    int  i;
    for (i=0, p=(*pArrayList);   consp(p) && consp(cdr(p));   i++, p=cdr(cdr(p)));
    return i;
}
LVAL xgrlF1_Array_List_Length_Msg()
/*-
    Count and return number of arrays in array list.
-*/
{
    LVAL self = xgrl01_Get_A_XGRL();
    LVAL*pArrayList = xgrl13_pArrayList( self );
    int len = xgrlF0_Array_List_Length( self, pArrayList );
    xllastarg();
    return cvfixnum( len );
}

/* }}} */
/* {{{ xgrlF3_Array_List_Nth_Msg -- Nth array in grl.			*/

LVAL xgrlF2_Array_List_Nth( g_as_lval, pArrayList, index_as_lval )
LVAL	  	            g_as_lval,*pArrayList, index_as_lval;
{       
    LVAL     result;
    LVAL     p;
    unsigned index = (unsigned) getfixnum( index_as_lval );
    unsigned i;
    for (p = *pArrayList, i = index;   ;   p = cdr(cdr(p))) {
        if (!consp(p)||!consp(cdr(p))) xlerror("No array numbered",index_as_lval);
	if (!i--)   break;
    }
    return car(p);
}
LVAL xgrlF3_Array_List_Nth_Msg()
/*-
    Return nth of array in array list.
-*/
{
    LVAL self		= xgrl01_Get_A_XGRL();
    LVAL index_as_lval  = xlgafixnum();
    LVAL*pArrayList = xgrl13_pArrayList( self );
    xllastarg();
    return xgrlF2_Array_List_Nth( self, pArrayList, index_as_lval );
}

/* }}} */
/* {{{ xgrlF8_Remove_Array_Msg -- Remove array from arraylist.          */

LVAL xgrlF7_Remove_Array( g_as_lval )
LVAL                      g_as_lval;
{
    LVAL*pArrayList = xgrl13_pArrayList( g_as_lval );
    LVAL key        = xlgasymbol();
    xllastarg();
    return xthl83_RemProp( pArrayList, key );
}

LVAL xgrlF8_Remove_Array_Msg()
/*-
    Remove array from arrayist.
-*/
{
    return xgrlF7_Remove_Array( xgrl01_Get_A_XGRL() );
}

/* }}} */
/* {{{ xgrlFb_Rename_Array_Msg -- Rename array in arraylist.            */

LVAL xgrlFa_Rename_Array( g_as_lval )
LVAL                      g_as_lval;
{
    LVAL*pArrayList = xgrl13_pArrayList( g_as_lval );
    LVAL oldname   = xlgasymbol();
    LVAL to        = xlgasymbol();
    LVAL newname   = xlgasymbol();
    LVAL key_val;
    if (to != k_to) xlerror(":RENAME-ARRAY expected ':TO'",to);
    xllastarg();
    /* Note that we can't just set the name slot w/o   */
    /* risking winding up with two properties with the */
    /* same name on the propertylist.  Since we need   */
    /* to prevent this, might as well just do an       */
    /* insert-delete sequence.  Generating needless    */
    /* garbage *sigh*.                                 */
    key_val = xthl83_RemProp( pArrayList, oldname               );
    return    xthl82_SetProp( pArrayList, newname, cdr(key_val) );
}

LVAL xgrlFb_Rename_Array_Msg()
/*-
    Rename array in arrayist.
-*/
{
    return xgrlFa_Rename_Array( xgrl01_Get_A_XGRL() );
}

/* }}} */
/* {{{ xgrlwo_Write_Xgrl_To_Graphics_File                               */

xgrlwo_Write_Xgrl_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    char buf[256];
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new ",getstring(name));
    xsry88_Build_Shape_Info_String(buf,lv);
    fputs(buf,fdoa);
    fputs("))\n",fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
