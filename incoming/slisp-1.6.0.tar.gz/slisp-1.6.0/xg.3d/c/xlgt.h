/* {{{ xlgt.h -- light objects.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Aug15
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
  
#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xlgt;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xlgt00_Is_New();
extern LVAL xlgt08_Copy_Msg();
extern LVAL xlgt03_Show_Msg();
extern LVAL xlgt40_Get_Msg();
extern LVAL xlgt42_Set_Msg();
extern LVAL xlgt44_Frame_Things_Msg();
extern LVAL xlgt91_ProplistLength_Msg();
extern LVAL xlgt95_ProplistNth_Msg();
extern LVAL xlgtF0_Copy_Contents_Msg();



#ifndef EXTERNED_TRANSFORM
extern LVAL k_transform;   /* Keyword ":transform" */
#define EXTERNED_TRANSFORM
#endif


#ifndef EXTERNED_ISLOCAL
extern LVAL k_islocal;    /* Keyword ":is-local" */
#define EXTERNED_ISLOCAL
#endif

#ifndef EXTERNED_COLOR
extern LVAL k_color;   /* Keyword ":color" */
#define EXTERNED_COLOR
#endif

#ifndef EXTERNED_AMBIENTCOLOR
extern LVAL k_ambientcolor;  /* Keyword ":ambient-color" */
#define EXTERNED_AMBIENTCOLOR
#endif

#ifndef EXTERNED_TARGET
extern LVAL k_target;   /* Keyword ":target" */
#define EXTERNED_TARGET
#endif

#ifndef EXTERNED_LOCATION
extern LVAL k_location;   /* Keyword ":location" */
#define EXTERNED_LOCATION
#endif

#ifndef EXTERNED_TWIST
extern LVAL k_twist;      /* Keyword ":twist" */
#define EXTERNED_TWIST
#endif

#ifndef EXTERNED_DEGREES
extern LVAL k_degrees;      /* Keyword ":degrees" */
#define EXTERNED_DEGREES
#endif

#ifndef EXTERNED_RADIANS
extern LVAL k_radians;      /* Keyword ":radians" */
#define EXTERNED_RADIANS
#endif

#ifndef EXTERNED_DIAMETER
extern LVAL k_diameter;     /* Keyword ":diameter" */
#define EXTERNED_DIAMETER
#endif

#ifndef EXTERNED_SHOW
extern LVAL k_show;/* Keyword ":show" */
#define EXTERNED_SHOW
#endif

#ifndef EXTERNED_VIEWING_TRANSFORM
extern LVAL s_viewing_transform; /* Symbol "viewing-transform" */
#define EXTERNED_VIEWING_TRANSFORM
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,	xlgt00_Is_New			)
DEFINE_SUBR(	NULL,	xlgt08_Copy_Msg			)
DEFINE_SUBR(	NULL,	xlgt03_Show_Msg			)
DEFINE_SUBR(	NULL,	xlgt40_Get_Msg			)
DEFINE_SUBR(	NULL,	xlgt42_Set_Msg			)
DEFINE_SUBR(	NULL,	xlgt44_Frame_Things_Msg	)
DEFINE_SUBR(	NULL,	xlgt91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,	xlgt95_ProplistNth_Msg		)
DEFINE_SUBR(	NULL,	xlgtF0_Copy_Contents_Msg	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLINIT
    xlgt0_Init();
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xlgt;
LOCAL struct xlgt_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xlgt_table[] = {
    {	":ISNEW",		xlgt00_Is_New			},
    {	":COPY",		xlgt08_Copy_Msg			},
    {	":SHOW",		xlgt03_Show_Msg			},
    {	":GET", 		xlgt40_Get_Msg			},
    {	":SET", 		xlgt42_Set_Msg			},
    {	":FRAME-THINGS",	xlgt44_Frame_Things_Msg		},
    {	":PROPERTY-LIST-LENGTH",xlgt91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xlgt95_ProplistNth_Msg		},
    {	":COPY-CONTENTS",	xlgtF0_Copy_Contents_Msg	},

    {	NULL,			NULL				}
};



#ifndef DEFINED_ISLOCAL
LVAL k_islocal;    /* Keyword ":is_local" */
#define DEFINED_ISLOCAL
#endif

#ifndef DEFINED_COLOR
LVAL k_color;   /* Keyword ":color" */
#define DEFINED_COLOR
#endif

#ifndef DEFINED_AMBIENTCOLOR
LVAL k_ambientcolor;   /* Keyword ":ambient-color" */
#define DEFINED_AMBIENTCOLOR
#endif

#ifndef DEFINED_TRANSFORM
LVAL k_transform;   /* Keyword ":transform" */
#define DEFINED_TRANSFORM
#endif

#ifndef DEFINED_TARGET
LVAL k_target;   /* Keyword ":target" */
#define DEFINED_TARGET
#endif

#ifndef DEFINED_LOCATION
LVAL k_location;   /* Keyword ":location" */
#define DEFINED_LOCATION
#endif

#ifndef DEFINED_TWIST
LVAL k_twist;         /* Keyword ":twist" */
#define DEFINED_TWIST
#endif

#ifndef DEFINED_DEGREES
LVAL k_degrees;      /* Keyword ":degrees" */
#define DEFINED_DEGREES
#endif

#ifndef DEFINED_RADIANS
LVAL k_radians;      /* Keyword ":radians" */
#define DEFINED_RADIANS
#endif

#ifndef DEFINED_DIAMETER
LVAL k_diameter;     /* Keyword ":diameter" */
#define DEFINED_DIAMETER
#endif

#ifndef DEFINED_SHOW
LVAL k_show;/* Keyword ":show" */
#define DEFINED_SHOW
#endif

#ifndef DEFINED_VIEWING_TRANSFORM
LVAL s_viewing_transform;/* Symbol "viewing-transform" */
#define DEFINED_VIEWING_TRANSFORM
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_ISLOCAL
    k_islocal = xlenter(":IS-LOCAL");
#define CREATED_ISLOCAL
#endif

#ifndef CREATED_COLOR
    k_color = xlenter(":COLOR");
#define CREATED_COLOR
#endif

#ifndef CREATED_AMBIENTCOLOR
    k_ambientcolor = xlenter(":AMBIENT-COLOR");
#define CREATED_AMBIENTCOLOR
#endif

#ifndef CREATED_TRANSFORM
    k_transform = xlenter(":TRANSFORM");
#define CREATED_TRANSFORM
#endif

#ifndef CREATED_TARGET
    k_target = xlenter(":TARGET");
#define CREATED_TARGET
#endif

#ifndef CREATED_LOCATION
    k_location = xlenter(":LOCATION");
#define CREATED_LOCATION
#endif

#ifndef CREATED_TWIST
    k_twist = xlenter(":TWIST");
#define CREATED_TWIST
#endif

#ifndef CREATED_DEGREES
    k_degrees = xlenter(":DEGREES");
#define CREATED_DEGREES
#endif

#ifndef CREATED_RADIANS
    k_radians = xlenter(":RADIANS");
#define CREATED_RADIANS
#endif

#ifndef CREATED_DIAMETER
    k_diameter = xlenter(":DIAMETER");
#define CREATED_DIAMETER
#endif

#ifndef CREATED_SHOW
    k_show = xlenter(":SHOW");
#define CREATED_SHOW
#endif

#ifndef CREATED_VIEWING_TRANSFORM
    s_viewing_transform = xlenter("VIEWING-TRANSFORM");
#define CREATED_VIEWING_TRANSFORM
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xlgt = xgbj58_Create_Class("CLASS-LIGHT",lv_x03d);
    xgbj57_Add_Instance_Variable( lv_xlgt,"VIEWING-TRANSFORM");
    xgbj56_Enter_Messages( lv_xlgt,  xlgt_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
