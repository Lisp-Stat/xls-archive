/* {{{ clgt.h -- xlgt light objects.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Aug15
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
********************************************************************************
*/
/* }}} */

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#include "c03d.h"

#define CLGT_REC_VERSION (27)

/* A struct type that holds everything we need to know about a light.   */
/* WARNING:  xlgt.c depends on the below order to initialize correctly. */
/* See xlgt00_Is_New.     						*/ 
struct clgt_struct {
    int           k_class; /* k_class should always be first in record. */
    c03d_fileInfo fileInfo;/* Always 2nd in record.  Save-file.         */
    gt_light_rec  r;
};
typedef struct clgt_struct  clgt_rec;

#define xlgtp(o) (gobjectp(o) && ((((clgt_rec*)(gobjimmbase(o)))->k_class) == C03D_xLGT))

LVAL xlgt01_Get_A_XLGT();
gt_light_rec * xlgt04_Get_Light_Rec();

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
