/* {{{ ctfm.h -- xtfm.h 4x4 matrices.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Jun18
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#include "c03d.h"

#define CTFM_REC_VERSION (17)

#include "geo.h"

/* A struct type that holds everything we need to know about a transform.*/
/* WARNING:  xtfm.c depends on the below order to initialize correctly. */
/* See xtfm00_Is_New.     						*/ 
struct ctfm_struct {
    int           k_class; /* k_class should always be first in record. */
    c03d_fileInfo fileInfo;/* Always 2nd in record.  Save-file.         */

    /* Some stuff used in save/restore logic: */
#define CTFM_FIRST_DOUBLE m
#define CTFM_DOUBLE_COUNT 16
#define CTFM_FIRST_FLOAT location
#define CTFM_FLOAT_COUNT 17
#define CTFM_FIRST_INT32 want_to_recompute_matrix
#define CTFM_INT32_COUNT 1

    geo_matrix	 m;

    geo_point location;    /* Location of camera/light/etc.		*/
    float     angle_of_view_in_radians;
    float     diameter;    /* Diameter of view volume.			*/
    float     left,roit;   /* Orthographic viewing volume.              */
    float     top, bot ;   /* Orthographic viewing volume.              */
    float     near,far ;   /* Orthographic viewing volume.              */
    geo_point target;      /* Target camera is pointing at.		*/
    geo_point up;          /* Up point for 				*/
    int       want_to_recompute_matrix; /* TRUE iff above have been modified.*/
};
typedef struct ctfm_struct  ctfm_rec;

struct ctfm_Put_Rec {
    int       location_is_valid;   geo_point location;
    int       angle_is_valid;      float     angle_of_view_in_radians;

    /* Diameter of view volume.          */
    int       diameter_is_valid;   float     diameter;

    /* Target camera is pointing at: */
    int       target_is_valid;     geo_point target;

    /* Point to be 'up': */
    int       up_is_valid;         geo_point up;

    int       left_is_valid;       float     left;
    int       roit_is_valid;       float     roit;
    int        top_is_valid;       float     top;
    int        bot_is_valid;       float     bot;
    int       near_is_valid;       float     near;
    int        far_is_valid;       float     far;
};

#define xtfmp(o) (gobjectp(o) && ((((ctfm_rec*)(gobjimmbase(o)))->k_class) == C03D_xTFM))

extern LVAL        xtfm01_Get_A_XTFM();
extern geo_matrix* xtfm9b_Find_Matrix();
extern ctfm_rec*   xtfm9c_Find_Immediate_Base();
extern LVAL        xtfmF8_MouseHitRectangleP();
extern void ctfm70_Initialize_Put_Rec(struct ctfm_Put_Rec *r );

extern ctfm_rec    xtfm___defaults;

/* definitions needed by ctfm74_Decompose_Matrix
 * (adapted from Graphics Gems)
 */

enum ctfm_unmatrix_indices {
 	CTFM_U_SCALEX,
 	CTFM_U_SCALEY,
 	CTFM_U_SCALEZ,
 	CTFM_U_SHEARXY,
 	CTFM_U_SHEARXZ,
 	CTFM_U_SHEARYZ,
 	CTFM_U_ROTATEX,
 	CTFM_U_ROTATEY,
 	CTFM_U_ROTATEZ,
 	CTFM_U_TRANSX,
 	CTFM_U_TRANSY,
 	CTFM_U_TRANSZ,
 	CTFM_U_PERSPX,
 	CTFM_U_PERSPY,
 	CTFM_U_PERSPZ,
 	CTFM_U_PERSPW
};

typedef struct {
	double x,y,z,w;
} ctfm_Vector4;


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
