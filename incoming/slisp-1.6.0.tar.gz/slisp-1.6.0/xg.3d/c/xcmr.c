/* {{{ xcmr.c -- camera objects.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Jul12
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */

/* {{{ --- history ---							*/

/* 95Jul12 jsp: Add 0.01 err tolerance to :viewport-[size|spot]-[x|y]   */
/* 91Jul12 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xcmr;

extern LVAL s_stdout;
extern LVAL xsendmsg0();
LVAL xcmr41_Set();

#include <math.h>
#include "geo.h"
#include "csry.h"
#include "ccmr.h"
#include "cmtl.h"
#include "cmdl.h"
#include "ctfm.h"
#include "lib.h"
#include "cgrl.h"
#include "c03d.h"
#include "cthl.h"
#include "../../xg.3d.fileio/c/cfil.h"

#define iabs(x)	((x) >= 0 ? (x) : -(x))
#define DEGREES_TO_RADIANS (3.1415926535897932384626 / 180.0)
#define RADIANS_TO_DEGREES (180.0 / 3.1415926535897932)

LOCAL     xcmr02_Update_State();
LVAL    * xcmr33_Find_Viewing_Transform();
LVAL    * xcmr34_Find_Projection_Transform();
ccmr_rec* xcmr9c_Find_Immediate_Base();

struct xcmrC4_RunWidgets_struct xcmrC2_RunWidgets_Rec;
int    xcmrC3_RunningWidgets = FALSE;

extern LVAL k_degrees;
extern LVAL k_diameter;
extern LVAL k_left;
extern LVAL k_right;
extern LVAL k_top;
extern LVAL k_bottom;
extern LVAL k_near;
extern LVAL k_far;
extern LVAL k_framenumber;
extern LVAL k_location;
extern LVAL k_radians;
extern LVAL k_scriptrate;
extern LVAL k_show;
extern LVAL k_target;
extern LVAL k_transform;
extern LVAL k_projectiontransform;
extern LVAL k_up;
extern LVAL k_viewportsizecols;
extern LVAL k_viewportsizerows;
extern LVAL k_viewportsizex;
extern LVAL k_viewportspotcol;
extern LVAL k_viewportspotrow;
extern LVAL k_viewportspotx;
extern LVAL lv_xtfm;
extern LVAL s_xg3ddebug;
extern LVAL s_perspective_transform;
extern LVAL s_viewing_transform;
extern LVAL k_aspect;
extern LVAL k_mousecol;
extern LVAL k_mouselocationx;
extern LVAL k_mouselocationy;
extern LVAL k_mouserow;
extern LVAL k_scripttime;
extern LVAL k_scripttime;
extern LVAL k_selectedfacet;
extern LVAL k_selectedparametricfacetlocationx;
extern LVAL k_selectedparametricfacetlocationy;
extern LVAL k_selectedthing;
extern LVAL k_selectedthingspacelocationx;
extern LVAL k_selectedthingspacelocationy;
extern LVAL k_selectedthingspacelocationz;
extern LVAL k_viewportsizey;
extern LVAL k_viewportspoty;
extern LVAL k_windowfactors;
extern LVAL k_default;
extern LVAL k_downclick;
extern LVAL k_drag;
extern LVAL k_initializefromfile;
extern LVAL k_select;
extern LVAL k_things;
extern LVAL k_upclick;
extern LVAL s_xg3dcurrentcamera;
extern LVAL s_xg3ddraggedcamera;
extern LVAL s_xg3ddraggeddraghook;
extern LVAL s_xg3ddraggedthing;
extern LVAL s_xg3ddraggedupclickhook;
extern LVAL s_xg3dscripttime;
extern LVAL k_blockuntilinputarrives;
extern LVAL s_xg3dkeyboardchar;
extern LVAL s_xg3dkeyboardcharhook;
extern LVAL s_xg3dmousecol;
extern LVAL s_xg3dmouserow;
extern LVAL s_xg3dmousepressure;
extern LVAL s_xg3dmousestate;
extern LVAL s_xg3dredrawhook;
extern LVAL s_xg3dselectedcamera;
extern LVAL s_xg3dselecteddeselecthook;
extern LVAL s_xg3dselectedthing;


/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xcmr00_Is_New -- Initialize a new xcmr instance.			*/

/* Used to initialize graphics driver exactly once: */
int  xcmr04_GraphicsDriverIsInitialized = FALSE;

/* Incremented every time we clear the zbuffer. Main   */
/* purpose is to make it easy for objects to recompute */
/* themselves exactly once per display frame.          */
/*(Buggo: Should switch to counting swapbuffer calls)*/
int  xcmr05_Frame_Number = 0;

/* Conceptually, Script_Time is the time-in-frames     */
/* relative to the current animation script. Since the */
/* user may scroll back and forth in animation 'time', */
/* Script_Time can *not* be assumed to change in a     */
/* monotonic fashion ... or indeed, to change at all   */
/* from frame to frame.				       */
float xcmr06_Script_Time = 0.0;
float xcmr07_Script_Rate = 0.0;

LVAL xcmr00_Is_New()
/*-
    Initialize a new xcmr instance.
-*/
{
    static ccmr_rec defaults = {
        C03D_xCMR      ,   /* k_class			*/
        C03D_FILEiNFO_INIT,/* Always 2nd in record.     */

        0.0, 0.0       ,   /* Port location (x, y).     */
        1.0, 1.0       ,   /* Port size     (x, y).     */

/* These now need to be permanent for save/restore: */
/* #ifndef EYEPHONE_KLUDGE */
        /* The eyephone kludges: */
	0.0, 0.0,	/* Left + roit, topp + bott */
/* #endif */
	0.0,		/* Aspect ratio */
    };

    LVAL viewing_transform;
    LVAL perspective_transform;
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    ccmr_rec* r;

    /* This is a quick kludge ... the graphics driver */
    /* code is due for a major rewrite soon anyhow... */
    if(!xcmr04_GraphicsDriverIsInitialized) {  /*buggo*/
	xcmr04_GraphicsDriverIsInitialized = TRUE;
	xgtm2a_Graphics_Mode();
	xgtmAa_Set_Double_Buffering_Is_On( TRUE );
	xgtmAb_Set_Zbuffering_Is_On(       TRUE );
    }


#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xcmrp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( ccmr_rec ) );

    /* Initialize camera record to reasonable default values: */
    r	= (ccmr_rec*) gobjimmbase( lv );
   *r   = defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

#ifdef OLD
    r->port_loc_x = 0;
    r->port_siz_x = xgtm3a_2D_X_Max( gt_stat );

    r->port_loc_y = 0;
    r->port_siz_y = xgtm4a_2D_Y_Max( gt_stat );
#endif

    {   struct ctfm_Put_Rec r;
        /* Parse user args and save in r.  Can't apply them until   */
        /* we've created viewing and projection matrices, and can't */
	/* create those matrices until we've parsed the args. Sigh. */
	xcmr41_Set( lv, &r );

	/* Create our initial viewing_transform and save  */
	/* it in instance variable VIEWING_TRANSFORM:     */
	{   LVAL* p_view = xcmr33_Find_Viewing_Transform( lv );
	    if (* p_view == NULL) {
		viewing_transform  = xsendmsg0(lv_xtfm,k_new);
	        * p_view = viewing_transform;
		xtfmc5_Want_To_Recompute_State( viewing_transform );
	}   }

	/* Create our initial perspective_transform and save */
	/* it in instance variable PERSPECTIVE_TRANSFORM:    */
	perspective_transform = xsendmsg0(lv_xtfm,k_new);
	{   LVAL* p_persp = xcmr34_Find_Projection_Transform( lv );
	    *     p_persp = perspective_transform;
	}
        xtfmc5_Want_To_Recompute_State( perspective_transform );

	/* Apply state in self and r to update our matrices: */
	xcmr02_Update_State( lv, &r );
    }

    return lv;
}

/* }}} */
/* {{{ xcmr01_Get_A_XCMR -- Get arg, must be of class xcmr.		*/

LVAL xcmr01_Get_A_XCMR()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XCMR has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xcmr.  Similarly,          */
    /* nobody but nobody has any business resizing a xcmr,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xcmrp(m_as_lval) ||
        getgobjimmbytes(m_as_lval) != sizeof(ccmr_rec)
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xcmr02_Update_State -- Apply Put_Rec to our state.		*/

LOCAL xcmr02_Update_State( lv_camera, r )
LVAL			   lv_camera;
struct ctfm_Put_Rec		     *r;
{
    LVAL* p_viewing_transform  = xcmr33_Find_Viewing_Transform( lv_camera );
    xtfmc2_Update_State( *p_viewing_transform, r );
}

/* }}} */
/* {{{ xcmr03_Show_Msg -- Show the contents of a ccmr.			*/

LVAL xcmr03_Show_Msg()
{
    /* get self and the file pointer */
    LVAL self = xcmr01_Get_A_XCMR();
    LVAL fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the cmr record: */
    {   ccmr_rec*p = xcmr9c_Find_Immediate_Base( self );
	LVAL* p_view  = xcmr33_Find_Viewing_Transform( self );
	LVAL* p_persp = xcmr34_Find_Projection_Transform( self );

	libE6_xlprint_float(   "vport_min_x",   p->vport_min_x,  fptr );
	libE6_xlprint_float(   "vport_min_y",   p->vport_min_y,  fptr );
	libE6_xlprint_float(   "vport_max_x",   p->vport_max_x,  fptr );
	libE6_xlprint_float(   "vport_max_y",   p->vport_max_y,  fptr );
	if (p->aspect != 0.0) {
	    libE6_xlprint_float( "aspect",   p->aspect,      fptr );
	}

#ifndef EYEPHONE_KLUDGE
	libE5_xlprint_int(   "left_plus_roit",  p->left_plus_roit, fptr );
	libE5_xlprint_int(   "topp_plus_bott",  p->topp_plus_bott, fptr );
#endif
	xlputstr(fptr,"  viewing tranform\n");
	xsendmsg0( *p_view,  k_show );

	xlputstr(fptr,"  perspective tranform\n");
	xsendmsg0( *p_persp, k_show );

	xlputstr(fptr,"  --- end of cmr ---\n");
    }


    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xcmr08_Copy_Msg -- Build copy of given CCMR.			*/

LVAL xcmr09_Copy( m_as_lval )
LVAL		  m_as_lval;
{
    /* Create a new gobject to hold result: */
    ccmr_rec*mh = xcmr9c_Find_Immediate_Base( m_as_lval );
    ccmr_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xcmr,k_new);
    xlpop();
    nh = (ccmr_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}

LVAL xcmr08_Copy_Msg()
/*-
    Build copy of given CCMR.
-*/
{   LVAL m_as_lval;
    LVAL x_as_lval = xcmr01_Get_A_XCMR();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xcmr09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xcmr12_Get_Viewport_In_Pixel_Coords				*/

xcmr11_Get_Viewport_In_Pixel_Coords(       xcmr, xmin, xmax, ymin, ymax )
ccmr_rec				*  xcmr;
int						*xmin,*xmax,*ymin,*ymax;
{   extern char* xgtmG8_State();
    char* state		= xgtmG8_State();
    int x_min, x_max; float x_siz;
    int y_min, y_max; float y_siz;
    xgtmF4_Get_Window(   state, &x_min, &x_max, &y_min, &y_max );
    x_siz = (float)(x_max - x_min +1);
    y_siz = (float)(y_max - y_min +1);
    /* vport_max_[xy] actually points one pixel too high.  */
    /* This makes it possible to tile the window with non- */
    /* overlapping viewports simply by making the mincoord */
    /* of one viewport the same as the parametric maxcoord */
    /* of the viewport adjacent.                           */
    *xmin = (int) (xcmr->vport_min_x * x_siz + 0.5); /* 0.5 to round nicely */
    *ymin = (int) (xcmr->vport_min_y * y_siz + 0.5);
    *xmax = (int) (xcmr->vport_max_x * x_siz - 0.5);
    *ymax = (int) (xcmr->vport_max_y * y_siz - 0.5);
}
xcmr12_Get_Viewport_In_Pixel_Coords(    lv_xcmr, xmin, xmax, ymin, ymax )
LVAL					lv_xcmr;
int						*xmin,*xmax,*ymin,*ymax;
{   ccmr_rec* xcmr      = xcmr9c_Find_Immediate_Base( lv_xcmr );
    xcmr11_Get_Viewport_In_Pixel_Coords(   xcmr, xmin, xmax, ymin, ymax );
}

/* }}} */
/* {{{ xcmr14_Set_Viewport_In_Pixel_Coords				*/

xcmr14_Set_Viewport_In_Pixel_Coords(    lv_xcmr, xmin, xmax, ymin, ymax )
LVAL					lv_xcmr;
int						 xmin, xmax, ymin, ymax;
{   ccmr_rec* xcmr;
    extern char* xgtmG8_State();
    char* state		= xgtmG8_State();
    int x_min, x_max; float x_siz;
    int y_min, y_max; float y_siz;
    if (!xcmrp(lv_xcmr) ||
        getgobjimmbytes(lv_xcmr) != sizeof(ccmr_rec)
    ) {
        xlbadtype(lv_xcmr);
    }
    xcmr      = xcmr9c_Find_Immediate_Base( lv_xcmr );
    xgtmF4_Get_Window(   state, &x_min, &x_max, &y_min, &y_max );
    x_siz = (float)(x_max - x_min +1);
    y_siz = (float)(y_max - y_min +1);
    if (xmin >= xmax) xlfail("new port x size nonpositive");
    if (ymin >= ymax) xlfail("new port y size nonpositive");
    if (x_siz == 0.0) xlfail("old port x size zero");
    if (y_siz == 0.0) xlfail("old port y size zero");
    /* vport_max_[xy] actually points one pixel too high.  */
    /* This makes it possible to tile the window with non- */
    /* overlapping viewports simply by making the mincoord */
    /* of one viewport the same as the parametric maxcoord */
    /* of the viewport adjacent.                           */
    xcmr->vport_min_x = (float)(xmin  ) / x_siz;
    xcmr->vport_min_y = (float)(ymin  ) / y_siz;
    xcmr->vport_max_x = (float)(xmax+1) / x_siz;
    xcmr->vport_max_y = (float)(ymax+1) / y_siz;
    lib18_Clip_Float_To_Unit_Interval( &xcmr->vport_min_x );
    lib18_Clip_Float_To_Unit_Interval( &xcmr->vport_min_y );
    lib18_Clip_Float_To_Unit_Interval( &xcmr->vport_max_x );
    lib18_Clip_Float_To_Unit_Interval( &xcmr->vport_max_y );
}

/* }}} */
/* {{{ xcmr28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xcmr28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {   char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {   extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xcmr29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xcmr01_Get_A_XCMR();
    LVAL n_as_lval = xcmr01_Get_A_XCMR();
    xllastarg();
    return xcmr28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xcmr33_Find_Viewing_Transform					*/

LVAL* xcmr33_Find_Viewing_Transform( m )
LVAL                     	     m;
{   /* Return pointer to viewing transform slot in cmr: */
    LVAL*pLval;
    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
        m,
        getclass( m ),
        s_viewing_transform,
        &pLval
    );
    return pLval;
}

/* }}} */
/* {{{ xcmr34_Find_Projection_Transform					*/

LVAL* xcmr34_Find_Projection_Transform( m )
LVAL                     		m;
{
    /* Return pointer to projection transform slot in cmr. */
    LVAL*pLval;
    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
        m,
        getclass( m ),
        s_perspective_transform,
        &pLval
    );
    return pLval;
}

/* }}} */
/* {{{ xcmr35_Find_Viewing_Matrix					*/

xcmr35_Find_Viewing_Matrix( lv_camera, view )
LVAL			    lv_camera;
ctfm_rec			     **view ;
{   /* Build C pointers to our transform matrices: */
    LVAL* p_viewing_transform  = xcmr33_Find_Viewing_Transform( lv_camera );
   *view             = (ctfm_rec*) gobjimmbase( *p_viewing_transform );
    !xtfmp(*p_viewing_transform) && xlbadtype(  *p_viewing_transform );
}

/* }}} */
/* {{{ xcmr36_Find_Projection_Matrix					*/

xcmr36_Find_Projection_Matrix( lv_camera, perspective )
LVAL			       lv_camera;
ctfm_rec				**perspective;
/*-
    Build C pointers to our transform matrices.
-*/
{
    LVAL* p_persp_transform  = xcmr34_Find_Projection_Transform( lv_camera );
   *perspective      = (ctfm_rec*) gobjimmbase( *p_persp_transform );
    !xtfmp(*p_persp_transform)  && xlbadtype(   *p_persp_transform );
}

/* }}} */
/* {{{ xcmr38_Update_Transform_Projection -- Recompute our t-matrix.	*/

xcmr38_Update_Transform_Projection( lv_camera )
LVAL            		    lv_camera;
/*-
    Recompute our projection matrix from scratch according to our high-level fields.
-*/
{
    /* This function is now called only immediately before drawing. */

    ccmr_rec* camera = xcmr9c_Find_Immediate_Base( lv_camera );
    ctfm_rec*persp_mat;
    ctfm_rec*viewing_mat;
    geo_point location;
    LVAL* p_view_transform  = xcmr33_Find_Viewing_Transform( lv_camera );
    xtfma0_Compute_Location( &location, *p_view_transform  );
    xcmr35_Find_Viewing_Matrix(    lv_camera, &viewing_mat );
    xcmr36_Find_Projection_Matrix( lv_camera, &persp_mat   );

    /* Handle perspective transform: */
    {   /* See SGI GL Programming Guide, Perspective Transformations, C.5: */
	float fov       = viewing_mat->angle_of_view_in_radians;
	float view_mid  = lib01_Vector_Distance( &location, &viewing_mat->target );
	float far       = view_mid   +   0.50 * viewing_mat->diameter;
	float near      = view_mid   -   0.50 * viewing_mat->diameter;

	float aspect    = camera->aspect;
#ifdef NOISE
printf("xcmr38_Update_Transform_Projection: location.x g=%g\n",location.x);
printf("xcmr38_Update_Transform_Projection: location.y g=%g\n",location.y);
printf("xcmr38_Update_Transform_Projection: location.z g=%g\n",location.z);
printf("xcmr38_Update_Transform_Projection: fov g=%g\n",fov);
printf("xcmr38_Update_Transform_Projection: view_mid g=%g\n",view_mid);
printf("xcmr38_Update_Transform_Projection: viewing_mat->diameter g=%g\n",viewing_mat->diameter);
printf("xcmr38_Update_Transform_Projection: far g=%g\n",far);
printf("xcmr38_Update_Transform_Projection: near g=%g\n",near);
#endif
	if (camera->aspect == 0.0) {
	    int xmin, xmax;
	    int ymin, ymax;
	    /* This assumes square pixels, of course. */
	    /* That's safe nowadays...?               */
	    int csux = xcmr12_Get_Viewport_In_Pixel_Coords(
		lv_camera,
		&xmin, &xmax,
		&ymin, &ymax
	    );
	    float x_siz = (float) (xmax - xmin);
	    float y_siz = (float) (ymax - ymin);
	    if (y_siz  == 0.0)   aspect = 1.0; /* At least won't crash :) */
	    else                 aspect = x_siz / y_siz;
	}

#ifndef EYEPHONE_KLUDGE
        if (camera->left_plus_roit == 0.0   &&
	    camera->topp_plus_bott == 0.0
 	) {
	    if (fov != 0.0) {
		ctfm25_Perspective( &persp_mat->m, aspect, fov, far, near );
	    } else {
		/* Interpret a field-of-view of 0 as a  */
		/* request for orthographic projection: */
		double top  = 0.50 * viewing_mat->diameter;
		double bot  = - top;
		double roit = top * aspect;
		double left = -roit;
		if (viewing_mat->left != viewing_mat->roit) {
		    left = viewing_mat->left;
		    roit = viewing_mat->roit;
		}
		if (viewing_mat->top  != viewing_mat->bot) {
		    top  = viewing_mat->top ;
		    bot  = viewing_mat->bot ;
		}
		if (viewing_mat->near != viewing_mat->far) {
		    near = viewing_mat->near;
		    far  = viewing_mat->far ;
		}
		ctfm24_Orthographic( &persp_mat->m, left, roit, top, bot, far, near );
	    }
 	} else {
 	    float lpr = camera->left_plus_roit;
 	    float tpb = camera->topp_plus_bott;
 	    ctfm2a_Window( &persp_mat->m, aspect, fov, far, near, lpr, tpb );
 	}
#else
	ctfm25_Perspective( &persp_mat->m, aspect, fov, far, near );
#endif
	persp_mat->want_to_recompute_matrix = FALSE;
    }
}

/* }}} */
/* {{{ xcmr38_Check_Vector -- Normalize vector to unit length.		*/

#if APPARENTLY_UNUSED

xcmr38_Check_Vector( vector, pt_list )
geo_point *          vector;
LVAL           		     pt_list;
{
    LVAL      here   = pt_list;
    float     norm;
    float     len2   = (
        vector->x * vector->x   +
        vector->y * vector->y   +
        vector->z * vector->z
    );

    if (len2 < 0.1e-50)     xlbadtype(pt_list);

    norm = 1.0 / sqrt( len2 );

    vector->x *= norm;
    vector->y *= norm;
    vector->z *= norm;
}
#endif

/* }}} */
/* {{{ xcmr40_Get_Msg -- Get keyword properties.                        */

LVAL xcmr39_Get( lv_camera )
LVAL             lv_camera;
{
    ccmr_rec* camera = xcmr9c_Find_Immediate_Base( lv_camera );
    LVAL key = xlgasymbol();
    LVAL result;
    ctfm_rec*viewing_mat;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    char*err_widget  = "Property only supported during :RUN-WIDGETS:";
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    xcmr35_Find_Viewing_Matrix( lv_camera, &viewing_mat );

    if (key == k_transform) {

	/* Fetch camera location: */
	LVAL* p_view = xcmr33_Find_Viewing_Transform( lv_camera );
	result = *p_view;

    } else if (key == k_projectiontransform) {

	/* Fetch camera perspective matrix: */
	LVAL* p_view = xcmr34_Find_Projection_Transform( lv_camera );
	result = *p_view;

    } else if (key == k_location) {

	/* Fetch camera location: */
	geo_point location;
	LVAL* p_view = xcmr33_Find_Viewing_Transform( lv_camera );
	xtfma0_Compute_Location( &location, *p_view );
	result = lib14_Point_To_List( &location );

    } else if (key == k_target) {

	/* Fetch target point: */
        result = lib14_Point_To_List( &viewing_mat->target );

    } else if (key == k_up) {

	/* Fetch up:" */
        result = lib14_Point_To_List( &viewing_mat->up );

    } else if (key == k_radians) {

	/* Fetch angle: */
	result = cvflonum( viewing_mat->angle_of_view_in_radians );

    } else if (key == k_degrees) {

	/* Fetch angle: */
	result = cvflonum(viewing_mat->angle_of_view_in_radians*RADIANS_TO_DEGREES);

    } else if (key == k_diameter) {

	/* Fetch diameter: */
	result = cvflonum( viewing_mat->diameter );

    } else if (key == k_framenumber) {

	/* Fetch framenumber: */
	result = cvfixnum( xcmr05_Frame_Number );

    } else if (key == k_scripttime) {

	/* Fetch scripttime: */
	result = cvflonum( xcmr06_Script_Time );

    } else if (key == k_scriptrate) {

	/* Fetch scriptrate: */
	result = cvflonum( xcmr07_Script_Rate );

    } else if (key == k_viewportspotrow) {

	/* Fetch viewport location: */
	int xmin, xmax;
	int ymin, ymax;
	xcmr12_Get_Viewport_In_Pixel_Coords( lv_camera, &xmin,&xmax, &ymin,&ymax );
	result = cvfixnum( ymin );

    } else if (key == k_viewportsizerows) {

	/* Fetch viewport location: */
	int xmin, xmax;
	int ymin, ymax;
	xcmr12_Get_Viewport_In_Pixel_Coords( lv_camera, &xmin,&xmax, &ymin,&ymax );
	result = cvfixnum( ymax-ymin );

    } else if (key == k_viewportspotcol) {

	/* Fetch viewport location: */
	int xmin, xmax;
	int ymin, ymax;
	xcmr12_Get_Viewport_In_Pixel_Coords( lv_camera, &xmin,&xmax, &ymin,&ymax );
	result = cvfixnum( xmin );

    } else if (key == k_viewportsizecols) {

	/* Fetch viewport location: */
	int xmin, xmax;
	int ymin, ymax;
	xcmr12_Get_Viewport_In_Pixel_Coords( lv_camera, &xmin,&xmax, &ymin,&ymax );
	result = cvfixnum( xmax-xmin );

    } else if (key == k_viewportspotx) {

	/* Fetch viewport location: */
	result = cvflonum( camera->vport_min_x );

    } else if (key == k_viewportsizex) {

	/* Fetch viewport location: */
	result = cvflonum( camera->vport_max_x - camera->vport_min_x );

    } else if (key == k_viewportspoty) {

	/* Fetch viewport location: */
	result = cvflonum( camera->vport_min_y );

    } else if (key == k_viewportsizey) {

	/* Fetch viewport location: */
	result = cvflonum( camera->vport_max_y - camera->vport_min_y );

    } else if (key == k_aspect) {

	/* Fetch aspect ratio: */
	result = cvflonum( camera->aspect );

#ifndef EYEPHONE_KLUDGE
    } else if (key == k_windowfactors) {

        xlsave1(result);
	result = cons( cvflonum(camera->left_plus_roit), NIL    );
	result = cons( cvflonum(camera->topp_plus_bott), result );
	xlpop();
#endif

    } else if (key == k_mouselocationx) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvflonum( xcmrC2_RunWidgets_Rec.mouse_location.x );
    } else if (key == k_mouselocationy) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvflonum( xcmrC2_RunWidgets_Rec.mouse_location.y );
    } else if (key == k_mouserow) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvfixnum( xcmrC2_RunWidgets_Rec.mouse_row );
    } else if (key == k_mousecol) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvfixnum( xcmrC2_RunWidgets_Rec.mouse_col );
    } else if (key == k_selectedthing) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
 	result = xcmrC2_RunWidgets_Rec.lv_selected_thing;
    } else if (key == k_selectedfacet) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvfixnum( xcmrC2_RunWidgets_Rec.selected_facet );
    } else if (key == k_selectedthingspacelocationx) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvflonum( xcmrC2_RunWidgets_Rec.selected_thing_space_location.x );
    } else if (key == k_selectedthingspacelocationy) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvflonum( xcmrC2_RunWidgets_Rec.selected_thing_space_location.y );
    } else if (key == k_selectedthingspacelocationz) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvflonum( xcmrC2_RunWidgets_Rec.selected_thing_space_location.z );
    } else if (key == k_selectedparametricfacetlocationx) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvflonum( xcmrC2_RunWidgets_Rec.selected_parametric_facet_location.x );
    } else if (key == k_selectedparametricfacetlocationy) {
	if (!xcmrC3_RunningWidgets) xlerror(err_widget,key);
	result = cvflonum( xcmrC2_RunWidgets_Rec.selected_parametric_facet_location.y );

    } else {

	/* If this isn't a property we know, do a generic get property: */
        result = xthl8a_GetObjectProp( lv_camera, key, default_val, got_default );
    }
    return result;
}

LVAL xcmr40_Get_Msg()
/*-
    Return keyword properties for a camera object.
-*/
{
    return xcmr39_Get( xcmr01_Get_A_XCMR() );
}

/* }}} */
/* {{{ xcmr42_Set_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Set, update XCMR_PROPS and xcmr94_ProplistNth. */
#ifndef EYEPHONE_KLUDGE
#define XCMR_PROPS (27)
#else
#define XCMR_PROPS (16)
#endif

LVAL xcmr41_Set( lv_camera, r )
LVAL             lv_camera;
struct ctfm_Put_Rec	   *r;
{
    ccmr_rec* camera = xcmr9c_Find_Immediate_Base( lv_camera );

    ctfm70_Initialize_Put_Rec( r );

    while (moreargs()) {
        LVAL init = xlgasymbol();

	if (init == k_transform) {

	    /* Fetch camera location: */
	    LVAL xtfm01_Get_A_XTFM();
	    LVAL* p_view = xcmr33_Find_Viewing_Transform( lv_camera );
	   *p_view = xtfm01_Get_A_XTFM();

	} else if (init == k_projectiontransform) {

	    /* Fetch camera perspective matrix: */
	    LVAL xtfm01_Get_A_XTFM();
	    LVAL* p_view = xcmr34_Find_Projection_Transform( lv_camera );
	   *p_view = xtfm01_Get_A_XTFM();

        } else if (init == k_location) {

            /* Handle ":location '(1 1 1)" */
            lib16_List_To_Point( &r->location, xlgalist() );
	    r->location_is_valid = TRUE;

        } else if (init == k_target) {

            /* Handle ":target '(1 1 1)" */
            lib16_List_To_Point( &r->target, xlgalist() );
	    r->target_is_valid = TRUE;

        } else if (init == k_up) {

            /* Handle ":up 5" */
            lib16_List_To_Point( &r->up, xlgalist() );
	    r->up_is_valid	= TRUE;

        } else if (init == k_radians) {

            /* Handle ":radians 1.1" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp >= 3.14159)   xlfail("silly view angle");

	    r->angle_of_view_in_radians = tmp;
	    r->angle_is_valid		= TRUE;

        } else if (init == k_degrees) {

            /* Handle ":radians 1.1" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() ) * DEGREES_TO_RADIANS;
	    if (tmp < 0.0 || tmp >= 3.14159)   xlfail("silly view angle");

	    r->angle_of_view_in_radians = tmp;
	    r->angle_is_valid		= TRUE;

        } else if (init == k_diameter) {

            /* Handle ":diameter 12" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp <= 0.0)   xlfail("nonpositive diameter");

	    r->diameter			= tmp;
	    r->diameter_is_valid	= TRUE;

        } else if (init == k_left) {

	    r->left		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->left_is_valid	= TRUE;

        } else if (init == k_right) {

	    r->roit		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->roit_is_valid	= TRUE;

        } else if (init == k_top) {

	    r->top		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->top_is_valid	= TRUE;

        } else if (init == k_bottom) {

	    r->bot		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->bot_is_valid	= TRUE;

        } else if (init == k_near) {

	    r->near		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->near_is_valid	= TRUE;

        } else if (init == k_far) {

	    r->far		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->far_is_valid	= TRUE;

        } else if (init == k_framenumber) {

	    xlfail("May not set :FRAME-NUMBER!");

        } else if (init == k_scripttime) {

            /* Handle ":script-time 1.20" */
	    xcmr06_Script_Time = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

        } else if (init == k_scriptrate) {

            /* Handle ":script-rate 0.20" */
	    xcmr07_Script_Rate = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (init == k_viewportspotrow) {

	    /* Set viewport location: */
	    int ymin, ymax, ysiz;
	    int xmin, xmax;
	    int y = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (y < 0) xlerror("Too small",k_viewportspotrow);
	    xcmr12_Get_Viewport_In_Pixel_Coords(lv_camera, &xmin,&xmax,&ymin,&ymax);
	    ysiz = ymax-ymin;
	    ymin = y;
	    ymax = ymin+ysiz;
	    xcmr14_Set_Viewport_In_Pixel_Coords(lv_camera, xmin,xmax,ymin,ymax);

	} else if (init == k_viewportsizerows) {

	    /* Set viewport location: */
	    int ymin, ymax;
	    int xmin, xmax;
	    int y = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (y <= 0) xlerror("Too small",k_viewportsizerows);
	    xcmr12_Get_Viewport_In_Pixel_Coords(lv_camera, &xmin,&xmax,&ymin,&ymax);
	    ymax = ymin + y -1;
	    xcmr14_Set_Viewport_In_Pixel_Coords(lv_camera, xmin,xmax,ymin,ymax);

	} else if (init == k_viewportspotcol) {

	    /* Set viewport location: */
	    int xmin, xmax, xsiz;
	    int ymin, ymax;
	    int x = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (x < 0) xlerror("Too small",k_viewportspotcol);
	    xcmr12_Get_Viewport_In_Pixel_Coords(lv_camera, &xmin,&xmax,&ymin,&ymax);
	    xsiz = xmax-xmin;
	    xmin = x;
	    xmax = xmin+xsiz;
	    xcmr14_Set_Viewport_In_Pixel_Coords(lv_camera, xmin,xmax,ymin,ymax);

	} else if (init == k_viewportsizecols) {

	    /* Set viewport location: */
	    int xmin, xmax;
	    int ymin, ymax;
	    int x = (int) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (x <= 0) xlerror("Too small",k_viewportsizecols);
	    xcmr12_Get_Viewport_In_Pixel_Coords(lv_camera, &xmin,&xmax,&ymin,&ymax);
	    xmax = xmin + x -1;
	    xcmr14_Set_Viewport_In_Pixel_Coords(lv_camera, xmin,xmax,ymin,ymax);

	} else if (init == k_viewportspotx) {

	    /* Set viewport location: */
	    float siz = camera->vport_max_x - camera->vport_min_x;
	    float loc = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (loc < 0.0 || loc > 1.0) {
		/* Floating point errors were resulting in the */
		/* above test crashing us with loc values like */
		/* -0.005, so we allow some tolerance:         */
		if      (loc < 0.0 && loc > -0.01) loc = 0.0;
		else if (loc > 1.0 && loc <  1.01) loc = 1.0;
		else                               xlerror("bad val",k_viewportspotx);
	    }
	    camera->vport_min_x = 			loc;
	    camera->vport_max_x = camera->vport_min_x + siz;
	    lib18_Clip_Float_To_Unit_Interval( &camera->vport_min_x );
	    lib18_Clip_Float_To_Unit_Interval( &camera->vport_max_x );

	} else if (init == k_viewportsizex) {

	    /* Set viewport location: */
	    float siz = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (siz < 0.0 || siz > 1.0) {
		/* Allow some tolerance for falliable hardware: */
		if      (siz < 0.0 && siz > -0.01) siz = 0.0;
		else if (siz > 1.0 && siz <  1.01) siz = 1.0;
		else                               xlerror("bad val",k_viewportsizex);
	    }
	    camera->vport_max_x = camera->vport_min_x + siz;
	    lib18_Clip_Float_To_Unit_Interval( &camera->vport_max_x );

	} else if (init == k_viewportspoty) {

	    /* Set viewport location: */
	    float siz = camera->vport_max_y - camera->vport_min_y;
	    float loc = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    /* Floating point errors were resulting in the */
	    /* above test crashing us with loc values like */
	    /* -0.005, so we allow some tolerance:         */
	    if (loc < 0.0 || loc > 1.0) {
		if      (loc < 0.0 && loc > -0.01) loc = 0.0;
		else if (loc > 1.0 && loc <  1.01) loc = 1.0;
		else                               xlerror("bad val",k_viewportspoty);
	    }
	    camera->vport_min_y = 			loc;
	    camera->vport_max_y = camera->vport_min_y + siz;
	    lib18_Clip_Float_To_Unit_Interval( &camera->vport_min_y );
	    lib18_Clip_Float_To_Unit_Interval( &camera->vport_max_y );

	} else if (init == k_viewportsizey) {

	    /* Set viewport location: */
	    float siz = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (siz < 0.0 || siz > 1.0) {
		/* Allow some tolerance for falliable hardware: */
		if      (siz < 0.0 && siz > -0.01) siz = 0.0;
		else if (siz > 1.0 && siz <  1.01) siz = 1.0;
		else                               xlerror("bad val",k_viewportsizey);
	    }
	    camera->vport_max_y = camera->vport_min_y + siz;
	    lib18_Clip_Float_To_Unit_Interval( &camera->vport_max_y );

	} else if (init == k_aspect) {

	    /* Set perspective matrix aspect ratio: */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp <= 0.0)   xlfail("nonpositive aspect ratio");
	    camera->aspect = tmp;

#ifndef EYEPHONE_KLUDGE
	} else if (init == k_windowfactors) {

            /* Store windowfactors: */
	    LVAL pt_list = xlgacons();
	    LVAL here    = pt_list;

	    if (!consp(here))     xlbadtype(pt_list);
	    camera->left_plus_roit = xgbj00_Get_Fix_Or_Flo_Num( car(here) );
	    here = cdr(here);

	    if (!consp(here))     xlbadtype(pt_list);
	    camera->topp_plus_bott = xgbj00_Get_Fix_Or_Flo_Num( car(here) );
	    here = cdr(here);

	    if (!null(here))      xlbadtype(pt_list);
#endif
        } else if (init == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xcmrz7_Read_Xcmr_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_camera,
		getfile(xlgetfile()),
		xcmrz7_Read_Xcmr_From_File,NULL
	    );

	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_camera, init, xlgetarg() );
    }   }

    return lv_camera;
}

LVAL xcmr42_Set_Msg()
/*-
    Read keyword properties for a camera object.
-*/
{
    struct ctfm_Put_Rec r;
    LVAL   lv_camera = xcmr01_Get_A_XCMR();
    LVAL   result    = xcmr41_Set( lv_camera, &r );
    xcmr02_Update_State(	   lv_camera, &r );
    return result;
}

/* }}} */
/* {{{ xcmr43_Set_Viewport -- Exported fn to set camera viewport from C.*/

/* xcmr43 is only used by xwmr, which should itself be phased out, */
/* and should be replaced by direct calls to xcmr14 sometime.      */
xcmr43_Set_Viewport( lv_camera, xloc, yloc, xsiz, ysiz )
LVAL                 lv_camera;
int		                xloc, yloc, xsiz, ysiz;
{
    xcmr14_Set_Viewport_In_Pixel_Coords(
	lv_camera,
	xloc,   xloc + xsiz,
	yloc,   yloc + ysiz
    );
}

/* }}} */
/* {{{ xcmr44_Frame_Things_Msg -- Find a frame containing things.	*/

LVAL xcmr44_Frame_Things_Msg()
{   LVAL   lv_xcmr = xcmr01_Get_A_XCMR();
    ccmr_rec* cam  = xcmr9c_Find_Immediate_Base(    lv_xcmr );
    LVAL *plv_xtfm = xcmr33_Find_Viewing_Transform( lv_xcmr );
    float     high = cam->vport_max_y - cam->vport_min_y; 
    float     wide = cam->vport_max_x - cam->vport_min_x; 
    float   aspect = high != 0.0 ? wide/high : 1.0;
    return x03d44_Frame_Things( lv_xcmr, *plv_xtfm, aspect );
}

/* }}} */
/* {{{ xcmr46_Draw_Msg -- Draw a collection of things.			*/

LVAL xcmr45_Draw( lv_camera )
LVAL		  lv_camera;
{
    int  xcmr47_Draw_Fn();
    LVAL lv_thinglist = NIL;
    ccmr_rec* camera = xcmr9c_Find_Immediate_Base(       lv_camera );
    LVAL* plv_view   = xcmr33_Find_Viewing_Transform(    lv_camera );
    LVAL* plv_persp  = xcmr34_Find_Projection_Transform( lv_camera );
    gt_tri_rec	          r;
    ctfm_rec              viewing_mat_inv;
    xthlC2_Init_Tri_Rec( &r, *plv_view, *plv_persp, &viewing_mat_inv );
    r.default_r      = TRUE;

    while (moreargs()) {
        LVAL       key = xlgasymbol();
	if        (key == k_things) {
	    lv_thinglist = xlgalist();
	} else {
	    if (!xthlAY_Process_Thinglist_KeyVal_Pair( &r, key, xlgetarg() )) {
	        xlerror("Bad :DRAW keyword",key);
    }   }   }

    if (null(lv_thinglist)) {
        lv_thinglist = xthl8a_GetObjectProp( lv_camera, k_things, NIL,TRUE );
    }

    if (null(lv_thinglist)) {
        lv_thinglist = xthl8a_GetObjectProp( *plv_view, k_things, NIL,TRUE );
    }

    if (!null(lv_thinglist)) {

	xcmr38_Update_Transform_Projection( lv_camera );

	xthlB0_Process_Thing_List(
	    lv_thinglist,
	    &r,
	    xcmr47_Draw_Fn, camera
	);
    }

    return lv_camera;
}

LVAL xcmr46_Draw_Msg()
/*-
    Draw a collection of things.
-*/
{
    return xcmr45_Draw( xcmr01_Get_A_XCMR() );
}

xcmr47_Draw_Fn( xcmr, r )
ccmr_rec*       xcmr;
gt_tri_rec	     *r;
{
    int    old_x_min, old_y_min;
    int    old_x_max, old_y_max;

    int    our_x_min, our_y_min;
    int    our_x_max, our_y_max;

    xgtmE0_Get_Viewport(
	gt_stat,
	&old_x_min, &old_x_max,
	&old_y_min, &old_y_max
    );

    xcmr11_Get_Viewport_In_Pixel_Coords(
	xcmr,
	&our_x_min, &our_x_max,
	&our_y_min, &our_y_max
    );

    xgtmE5_Set_Viewport(
	gt_stat,
	our_x_min, our_x_max,
	our_y_min, our_y_max
    );

    xgtmDx_Draw_Lotsa_Stuff( gt_stat, r );

    xgtmE5_Set_Viewport(
	gt_stat,
	old_x_min, old_x_max,
	old_y_min, old_y_max
    );

    return TRUE;
}

/* }}} */
/* {{{ xcmr49_NextFrame_Msg -- Advance (:GET <cmr> :FRAME-NUMBER) etc.  */

LVAL xcmr48_NextFrame() {

    xcmr05_Frame_Number += 1;
    xcmr06_Script_Time  += xcmr07_Script_Rate;

/*printf("xcmr48: FRAME %-5d------------------------------------------\n",xcmr05_Frame_Number);*/
    return NIL;
}

LVAL xcmr49_NextFrame_Msg()
/*-
    Advance :SCRIPT-TIME by :SCRIPT-RATE and :FRAME-NUMBER by 1.
-*/
{
    LVAL self = xcmr01_Get_A_XCMR();
    xllastarg();
    xcmr48_NextFrame();
    return NIL;
}

/* }}} */
/* {{{ xcmr51_Clear_Viewport_Msg -- Clear camera viewport.              */

LVAL xcmr51_Clear_Viewport_Msg()
/*-
    Clear camera viewport.
-*/
{
    LVAL self = xcmr01_Get_A_XCMR();
    geo_point colour;

    ccmr_rec* xcmr = xcmr9c_Find_Immediate_Base( self );

    int    old_x_min, old_y_min;
    int    old_x_max, old_y_max;

    int    our_x_min, our_y_min;
    int    our_x_max, our_y_max;

    xgtmE0_Get_Viewport(
	gt_stat,
	&old_x_min, &old_x_max,
	&old_y_min, &old_y_max
    );

    xcmr11_Get_Viewport_In_Pixel_Coords(
	xcmr,
	&our_x_min, &our_x_max,
	&our_y_min, &our_y_max
    );

    xgtmE5_Set_Viewport(
	gt_stat,
	our_x_min, our_x_max,
	our_y_min, our_y_max
    );

    /* Background color defaults to black: */
    colour.x = 0.0;
    colour.y = 0.0;
    colour.z = 0.0;
    if (moreargs()) {
        lib17_List_To_Color( &colour, xlgalist() );
    }
    xllastarg();
    xgtm7a_Set_Color( &colour );
    xgtmC4_Clear_Viewport_Fn();

    xgtmE5_Set_Viewport(
	gt_stat,
	old_x_min, old_x_max,
	old_y_min, old_y_max
    );

    return NIL;
}

/* }}} */
/* {{{ xcmr53_Clear_Zbuffer_Msg -- Clear camera zbuffer.                */

LVAL xcmr53_Clear_Zbuffer_Msg()
{
    int    old_x_min, old_y_min;
    int    old_x_max, old_y_max;

    int    our_x_min, our_y_min;
    int    our_x_max, our_y_max;

    LVAL lv = xcmr01_Get_A_XCMR();
    ccmr_rec* xcmr = xcmr9c_Find_Immediate_Base( lv );

    xllastarg();

    xgtmE0_Get_Viewport(
	gt_stat,
	&old_x_min, &old_x_max,
	&old_y_min, &old_y_max
    );

    xcmr11_Get_Viewport_In_Pixel_Coords(
	xcmr,
	&our_x_min, &our_x_max,
	&our_y_min, &our_y_max
    );

    xgtmE5_Set_Viewport(
	gt_stat,
	our_x_min, our_x_max,
	our_y_min, our_y_max
    );

    xgtmC5_Clear_Zbuffer();

    xgtmE5_Set_Viewport(
	gt_stat,
	old_x_min, old_x_max,
	old_y_min, old_y_max
    );

    return NIL;
}

/* }}} */
/* {{{ xcmr55_Swap_Buffers_Msg -- Swap screen buffers.                  */

LVAL xcmr55_Swap_Buffers_Msg()
/*-
    Swap screen buffers.
-*/
{
    LVAL self = xcmr01_Get_A_XCMR();
    xllastarg();
    xgtmB8_Swap_Buffers_Fn();
    return NIL;
}

/* }}} */
/* {{{ xcmr57_ScriptTime_Fn -- Get current script time.			*/

LVAL xcmr57_ScriptTime_Fn() {
    static float last_val = -3.1411;
    xllastarg();
    if (last_val != xcmr06_Script_Time) {
        last_val  = xcmr06_Script_Time;
        setvalue( s_xg3dscripttime, cvflonum( xcmr06_Script_Time ) );
    }
    return getvalue(s_xg3dscripttime);
}

/* }}} */
/* {{{ xcmr59_Clear_Overlay_Bitplanes_Msg -- Clear viewport overlays.	*/

LVAL xcmr59_Clear_Overlay_Bitplanes_Msg()
{
    int    old_x_min, old_y_min;
    int    old_x_max, old_y_max;

    int    our_x_min, our_y_min;
    int    our_x_max, our_y_max;

    LVAL lv = xcmr01_Get_A_XCMR();
    ccmr_rec* xcmr = xcmr9c_Find_Immediate_Base( lv );

    xllastarg();

    xgtmE0_Get_Viewport(
	gt_stat,
	&old_x_min, &old_x_max,
	&old_y_min, &old_y_max
    );

    xcmr11_Get_Viewport_In_Pixel_Coords(
	xcmr,
	&our_x_min, &our_x_max,
	&our_y_min, &our_y_max
    );

    xgtmE5_Set_Viewport(
	gt_stat,
	our_x_min, our_x_max,
	our_y_min, our_y_max
    );

    {   extern LVAL true;/*xlglob.c*/

	int got_decent_overlays = xgtmC7_Clear_Overlay_Bitplanes();
	
	xgtmE5_Set_Viewport(
	    gt_stat,
	    old_x_min, old_x_max,
	    old_y_min, old_y_max
	);

        return got_decent_overlays ? true : NIL;
    }
}

/* }}} */
/* {{{ xcmr91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xcmr90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{   LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XCMR_PROPS + x03d89_PropListLength( *pPropList ) );
}
LVAL xcmr91_ProplistLength_Msg()
{   /* Return length of propertylist. */
    return xcmr90_ProplistLength( xcmr01_Get_A_XCMR() );
}

/* }}} */
/* {{{ xcmr95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xcmr94_ProplistNth( g_as_lval )
LVAL                     g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL n_as_lval  = xlgafixnum();
    int  n          = getfixnum(n_as_lval);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case  0:    return k_transform;
    case  1:    return k_location;
    case  2:    return k_target;
    case  3:    return k_up;
    case  4:    return k_radians;
    case  5:    return k_left;
    case  6:    return k_right;
    case  7:    return k_top;
    case  8:    return k_bottom;
    case  9:    return k_near;
    case 10:    return k_far;
    case 11:    return k_degrees;
    case 12:    return k_diameter;
    case 13:    return k_framenumber;
    case 14:    return k_scripttime;
    case 15:    return k_scriptrate;
    case 16:    return k_viewportspotrow;
    case 17:    return k_viewportsizerows;
    case 18:    return k_viewportspotcol;
    case 19:    return k_viewportsizecols;
    case 20:    return k_viewportspotx;
    case 21:    return k_viewportsizex;
    case 22:    return k_viewportspoty;
    case 23:    return k_viewportsizey;
    case 24:    return k_projectiontransform;
#ifndef EYEPHONE_KLUDGE
    case 25:    return k_windowfactors;
    case 26:    return k_aspect;
#else
    case 14:    return k_aspect;
#endif
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XCMR_PROPS,
	    n_as_lval,
	    default_val,
	    got_default
	);
    }
}

LVAL xcmr95_ProplistNth_Msg()
/*-
    Return Nth item from propertylist.
-*/
{
    return xcmr94_ProplistNth( xcmr01_Get_A_XCMR() );
}

/* }}} */
/* {{{ xcmr99_Bounding_Box_Msg -- Compute a bounding box of thinglist.	*/

LVAL xcmr99_Bounding_Box_Msg()
/*-
    Compute a bounding box for an thinglist.
-*/
{
    LVAL result;
    geo_point min, max;
    int    got_default  = FALSE;
    LVAL   lv_camera	= xcmr01_Get_A_XCMR();
    LVAL   lv_thinglist	= NIL;
    LVAL   lv_default	= NIL;
    LVAL *plv_xtfm	= xcmr33_Find_Viewing_Transform( lv_camera );

    while (moreargs()) {
        LVAL       key = xlgasymbol();
	if        (key == k_things)  {
	    lv_thinglist = xlgalist();
	} else if (key == k_default) {
	    lv_default  = xlgetarg();
	    got_default	= TRUE;
	} else {
	    xlerror("Bad :BOUNDING-BOX keyword",key);
    }   }

    if (null(lv_thinglist)) {
        lv_thinglist = xthl8a_GetObjectProp( lv_camera, k_things, NIL,TRUE );
    }

    if (null(lv_thinglist)) {
        lv_thinglist = xthl8a_GetObjectProp( *plv_xtfm, k_things, NIL,TRUE );
    }

    if (null(lv_thinglist)) {
	if (got_default)  return lv_default;
        xlerror(":BOUNDING-BOX <cmr>: no thinglist!",lv_camera);
    }

    /* Compute the extrema: */
    xtfm92_Bounding_Box( *plv_xtfm, lv_thinglist, &min, &max );

    /* Worry about no points found: */
    if (min.x > max.x
    ||  min.y > max.y
    ||  min.z > max.z
    ){
	if (got_default)  return lv_default;
        xlerror(":BOUNDING-BOX <cmr>: no points in thinglist!",lv_thinglist);
    }

    /* Store the extrema in a list: */
    xlsave1(result);
    result = cons( lib14_Point_To_List( &max ), NIL    );
    result = cons( lib14_Point_To_List( &min ), result );
    xlpop();
    return result;
}

/* }}} */
/* {{{ xcmr9c_Find_Immediate_Base					*/

ccmr_rec* xcmr9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    ccmr_rec*cmr = (ccmr_rec*) gobjimmbase( lv );
    return cmr;
}

/* }}} */
/* {{{ xcmrD9_RunWidgets -- Activate any user-selected widgets.		*/

/* {{{ struct xcmrC0_rec --						*/

struct xcmrC0_rec {
    LVAL lv_xcmr;
    LVAL lv_result;

    LVAL* p_lv_view;
    LVAL* p_lv_persp;

    LVAL lv_thinglist;

    LVAL lv_thing_to_check;
    int  facet_to_check;

    float dmin;
    float dmax;

    struct xcmrC4_RunWidgets_struct s;

    LVAL lv_mouse_state;

    LVAL lv_downclick_hit;
    LVAL      lv_drag_hit;
    LVAL   lv_upclick_hit;
    LVAL    lv_select_hit;
    LVAL  lv_deselect_hit;
    LVAL  lv_reselect_hit;
    int   redraw;

    int  xmin, xmax, xsiz;
    int  ymin, ymax, ysiz;

    gt_tri_rec* r;

    ctfm_rec   viewing_mat_inv;
};

/* }}} */
/* {{{ xcmrC1_Initialize_C0Rec --					*/

xcmrC1_Initialize_C0Rec( r, s, lv_xcmr )
struct xcmrC0_rec       *r;
gt_tri_rec                 *s;
LVAL			       lv_xcmr;
{   extern char* xgtmG8_State();

    LVAL  ansisux = (r->lv_xcmr	= lv_xcmr);/*ansisux is a dummy, of course.*/

    LVAL* p_view  = xcmr33_Find_Viewing_Transform(    r->lv_xcmr );
    LVAL* p_persp = xcmr34_Find_Projection_Transform( r->lv_xcmr );
    char* state		= xgtmG8_State();

    r->lv_mouse_state			= NIL;
    r->s. mouse_row			= -1;
    r->s. mouse_col			= -1;
    r->s.lv_selected_camera		= lv_xcmr;
    r->s.lv_selected_thing		= NIL;
    r->s.   selected_facet		= -1;

    r->s.mouse_location.x		= 0.0;
    r->s.mouse_location.y		= 0.0;
    r->s.mouse_location.z		= 0.0;

    r->s.selected_thing_space_location.x		= 0.0;
    r->s.selected_thing_space_location.y		= 0.0;
    r->s.selected_thing_space_location.z		= 0.0;

    r->s.selected_parametric_facet_location.x		= 0.0;
    r->s.selected_parametric_facet_location.y		= 0.0;
    r->s.selected_parametric_facet_location.z		= 0.0;

    r->lv_thing_to_check		= NIL;
    r->facet_to_check			= -1;

    r->lv_thinglist			= NIL;

    r->dmin				=  0.0;
    r->dmax				=  1.0;

    r->lv_downclick_hit			= NIL;
    r->lv_drag_hit			= NIL;
    r->lv_upclick_hit			= NIL;
    r->lv_select_hit			= NIL;
    r->lv_deselect_hit			= NIL;
    r->lv_reselect_hit			= NIL;

    xcmr12_Get_Viewport_In_Pixel_Coords(
	lv_xcmr,
	&r->xmin, &r->xmax,
	&r->ymin, &r->ymax
    );
    r->xsiz = r->xmax - r->xmin;
    r->ysiz = r->ymax - r->ymin;
    if (r->xsiz < 2) r->xsiz =2; /* Prevent divide-by-zero */
    if (r->ysiz < 2) r->ysiz =2; /* Prevent divide-by-zero */

    r->r				= s;

    xthlC2_Init_Tri_Rec( s, *p_view, *p_persp, &r->viewing_mat_inv );
    s->default_r = TRUE;
}

/* }}} */
/* {{{ xcmrD3_Run_Hook --						*/

xcmrD3_Run_Hook( lv_xcmr, lv_hook, r )
LVAL		 lv_xcmr, lv_hook;
struct xcmrC4_RunWidgets_struct   *r;
{   int                             old_running  = xcmrC3_RunningWidgets;
    LVAL                            old_camera   = getvalue( s_xg3dcurrentcamera );
    struct xcmrC4_RunWidgets_struct old_state;
    /* Can't do automatic aggregate initialization on some (MIPS) compilers: */
    old_state    = xcmrC2_RunWidgets_Rec;

    if (lv_hook == NIL) {
        return;
    }

    /* Set up state for hooks to run in: */
    setvalue( s_xg3dcurrentcamera, lv_xcmr );
    xcmrC2_RunWidgets_Rec = *r;
    xcmrC3_RunningWidgets = TRUE;

    /* Run hooks: */
    xthlF5_Call_HookFns( lv_hook );
    /* Obscure bug: the following won't be restored if lisp */
    /* longjumps past us for an error or catch/throw. We    */
    /* need to figure out how to do unwind-protects from C. */
    /* I'm not *sure* it's possible for this to cause a bug.*/

    /* Restore previous state: */
    xcmrC3_RunningWidgets = old_running;
    xcmrC2_RunWidgets_Rec = old_state;
    setvalue( s_xg3dcurrentcamera, old_camera );
}

/* }}} */
/* {{{ xcmrD4_HaveHook_CheckThing --					*/

xcmrD4_HaveHook_CheckThing( r, s, lv_cell )
struct xcmrC0_rec          *r;
gt_tri_rec		      *s;
LVAL				  lv_cell;
{
    /* We return FALSE when we want to terminate iteration: */
    if        (r->lv_mouse_state == k_select) {
	if (!null((LVAL)s->lv_select_hook  ))	return FALSE;
	if (!null((LVAL)s->lv_deselect_hook))	return FALSE;
	if (!null((LVAL)s->lv_reselect_hook))	return FALSE;
    } else if (r->lv_mouse_state == k_downclick) {
	if (!null((LVAL)s->lv_downclick_hook)) return FALSE;
	if (!null((LVAL)s->lv_upclick_hook  )) return FALSE;
	if (!null((LVAL)s->lv_drag_hook     )) return FALSE;
    } else {
	abort();
    }
    return TRUE;
}

/* }}} */
/* {{{ xcmrD5_Need_To_Do_Hit_Testing --					*/

xcmrD5_Need_To_Do_Hit_Testing( s0, lv_thinglist, r )
gt_tri_rec		      *s0;
LVAL				   lv_thinglist;
struct xcmrC0_rec				*r;
{
    /********************************************************************/
    /* At this point, we know:						*/
    /*									*/
    /* o  The mouse state is non-NIL.					*/
    /* o  The thinglist  is non-NIL.					*/
    /* o  For :DOWNCLICK or :SELECT, mouse is in our viewport.		*/
    /* o  For :UPCLICK   or :DRAG, we are the XG.3D-DRAGGED-CAMERA.	*/
    /*									*/
    /* We want to return TRUE iff there is some valid reason to do	*/
    /* hit-testing (which can be a very expensive operation).		*/
    /*									*/
    /* Sometimes we need to hit-test against all polygons, sometimes	*/
    /* only against the dragged polygon:				*/
    /*									*/
    /* The valid reasons to do hit-testing are:				*/
    /*									*/
    /* :DOWNCLICK state:						*/
    /*  o Full hit-test if the thinglist contains any			*/
    /*	    :DOWNCLICK-HOOK,						*/
    /*	    :DRAG-HOOK, or						*/
    /*	    :UPCLICK-HOOK						*/
    /*	  values.							*/
    /*									*/
    /* :DRAG state:							*/
    /*  o Hit-test dragged polygon if the dragged thing has a		*/
    /*	    :DRAG-HOOK							*/
    /*	  value.							*/
    /*									*/
    /* :UPCLICK state:							*/
    /*  o Hit-test dragged polygon if the dragged thing has an		*/
    /*	    :UPCLICK-HOOK						*/
    /*	  value.							*/
    /*									*/
    /* :SELECT state:							*/
    /*  o Full hit-test if the thinglist contains any			*/
    /*	    :RESELECT-HOOK,						*/
    /*	      :SELECT-HOOK, or						*/
    /*	    :DESELECT-HOOK						*/
    /*	  values.							*/
    /*									*/
    /* To request a hit-test of only the dragged polygon, we set	*/
    /*   r->lv_thing_to_check						*/
    /* before returning true.						*/
    /********************************************************************/
    if        (r->lv_mouse_state == k_drag) {
	if (getvalue( s_xg3ddraggedcamera   ) != NIL  &&
	    getvalue( s_xg3ddraggeddraghook ) != NIL
	) {
	    r->lv_thing_to_check = getvalue( s_xg3ddraggedthing );
	    return TRUE;
	}
	return FALSE;
    } else if (r->lv_mouse_state == k_upclick) {
	if (getvalue( s_xg3ddraggedcamera      ) != NIL  &&
	    getvalue( s_xg3ddraggedupclickhook ) != NIL
	) {
	    r->lv_thing_to_check = getvalue( s_xg3ddraggedthing );
	    return TRUE;
	}
	return FALSE;
    } else if (r->lv_mouse_state == k_downclick) {
	/* Just fall through to bottom-of-page code. */
    } else if (r->lv_mouse_state == k_select) {
	/* Just fall through to bottom-of-page code. */
    } else {
	abort();
    }

    /* Search entire thinglist for interesting hooks: */
    {   int         xcmrD4_HaveHook_CheckThing();
	gt_tri_rec	s; s = *s0; /* Some cc reject "gt_tri_rec s=*s0;" */
	return !xthlB0_Process_Thing_List(
	    lv_thinglist,
	    &s,
	    xcmrD4_HaveHook_CheckThing,
	    r
	);
    }
}

/* }}} */
/* {{{ xcmrD6_GetPoint --						*/

xcmrD6_GetPoint( s,  pt, index )
gt_tri_rec	*s;
geo_point           *pt;
int			 index;
{
    pt->x = s->x[ index ];
    pt->y = s->y[ index ];
    pt->z = s->z[ index ];
}

/* }}} */
/* {{{ xcmrD7_ClipMouseLoc --						*/

xcmrD7_ClipMouseLoc( state, x, y )
char*                state;
int                        *x,*y;
{   int x_min, x_max, y_min, y_max;
    int x_siz,        y_siz       ;
    xgtmF4_Get_Window( state, &x_min, &x_max, &y_min, &y_max );
    x_siz = x_max - x_min;
    y_siz = y_max - y_min;
    if (*x <  0    )   *x = 0;
    if (*y <  0    )   *y = 0;
    if (*x >= x_siz)   *x = x_siz-1;
    if (*y >= y_siz)   *x = y_siz-1;
}

/* }}} */
/* {{{ xcmrDA_NoteHit --						*/

xcmrDA_NoteHit(    r, s, d, PRM, OBJ, i, ggt )
struct xcmrC0_rec *r;
gt_tri_rec	     *s;
float                    d;
geo_point                  *PRM,*OBJ;
int				      i;
LVAL					 ggt;
{
    if (d < r->dmin || d > r->dmax)   return;

    /* We have a hit, remember it: */
    r->dmax		= d;	/* Henceforth, ignore polygons we hide.	*/

    r->s.selected_parametric_facet_location	= *PRM;
    r->s.selected_facet				= i;
    r->s.lv_selected_thing			= ggt;
    r->s.selected_thing_space_location		= *OBJ;

    r->lv_downclick_hit	= (LVAL) s->lv_downclick_hook;
    r->lv_drag_hit	= (LVAL) s->lv_drag_hook;
    r->lv_upclick_hit	= (LVAL) s->lv_upclick_hook;
    r->lv_select_hit	= (LVAL) s->lv_select_hook;
    r->lv_deselect_hit	= (LVAL) s->lv_deselect_hook;
    r->lv_reselect_hit	= (LVAL) s->lv_reselect_hook;
    r->redraw           =        s->redraw;
}

/* }}} */
/* {{{ xcmrD8_RunWidgets --						*/

xcmrD8_RunWidgets( r,  s, ggt )
struct xcmrC0_rec *r;
gt_tri_rec	      *s;
LVAL			  ggt;
{
    extern LVAL k_invisible;
    extern LVAL k_background;
    extern LVAL k_foreground;
    geo_matrix  overall_transform;
    geo_matrix  inverse_transform;
    geo_point   mouse_loc;
    geo_point   M[2];
    geo_point   OBJ;
    geo_point   PRM;
    geo_point   P[4];
    int		i;
    float       d;
    int		hit;

    /************************************************************/
    /* It is possible for us to wind up doing the same matrix   */
    /* computations over here for each thing in an thinglist,   */
    /* this could be optimized at some point.  Then again, it's */
    /* just as usual for each thing to have a different model   */
    /* matrix, and the win probably isn't that big anyhow...    */
    /************************************************************/

    /* If this is a :DRAG or :UPCLICK call, we already know the  */
    /* thing and facet we care about, and can ignore all others: */
    if (r->lv_thing_to_check != NIL &&
	r->lv_thing_to_check != ggt
    ) {
	/* Continue iteration: */
	return TRUE;
    }

    /* If we can't improve on previous hit, end iteration: */
    if (r->dmax == 0.0) {
        return FALSE;
    }

    /* If object is invisible, return immediately: */
    if ((LVAL)(s->lv_pick_as) == k_invisible) {
	return TRUE;
    }

    /* Handle :PICK-AS :BACKGROUND/:FOREGROUND, in which we  */
    /* ignore the object geometry (if any) and just pick the */
    /* viewport:					     */
    PRM = r->s.mouse_location;
    OBJ = r->s.mouse_location;
    i   = -1;
    if ((LVAL)(s->lv_pick_as) == k_background) {
	d   = 1.0;
	xcmrDA_NoteHit(    r, s, d, &PRM, &OBJ, i, ggt );
	return TRUE;
    }
    if ((LVAL)(s->lv_pick_as) == k_foreground) {
	/* It is convenient (for the flight simulator, at least :)  */
	/* if the foreground is transparent in the sense that it is */
	/* ignored if it has no relevant hook.  This lets us use    */
	/* :SELECT on the :FOREGROUND to steer with, while still    */
	/* having :DOWNCLICK select real objects:		    */
	int want_foreground;
	if        (r->lv_mouse_state == k_drag) {
	    want_foreground = !null( (LVAL) s->lv_drag_hook );
	} else if (r->lv_mouse_state == k_upclick) {
	    want_foreground = !null( (LVAL) s->lv_upclick_hook   );
	} else if (r->lv_mouse_state == k_downclick) {
	    want_foreground = !null( (LVAL) s->lv_downclick_hook );
	} else if (r->lv_mouse_state == k_select) {
	    want_foreground = (
		!null( (LVAL) s->lv_select_hook   )   ||
		!null( (LVAL) s->lv_deselect_hook )   ||
		!null( (LVAL) s->lv_reselect_hook )
	    );
	} else {
	    abort();
	}
	if (want_foreground) {
	    d   = 0.0;
	    xcmrDA_NoteHit(    r, s, d, &PRM, &OBJ, i, ggt );
        }
	return TRUE;
    }

    /* Multiply our transforms to get overall thingspace->screen mapping: */
    if (!s->model) {
	ctfm01_Matrix_Multiply(
	    &overall_transform,
	    s->view->m,
	    s->perspective->m
	);
    } else {
	geo_matrix temporary_matrix;
	ctfm01_Matrix_Multiply(
	    &temporary_matrix,
	    s->model->m,
	    s->view->m
	);
	ctfm01_Matrix_Multiply(
	    &overall_transform,
	    &temporary_matrix,
	    s->perspective->m
	);
    }

    /* Invert to get screen->thingspace mapping.  We're    */
    /* missing a coordinate in screenspace, of course,     */
    /* since mouse gives x,y but no z:			   */
    ctfm44_Invert_Matrix( &inverse_transform, &overall_transform );

    /* Cursor arrives in [0,1]^2, we need it in [-1,1]^2,  */
    /* which is the range into which our overall_transform */
    /* maps the viewing volume: 			   */
    mouse_loc.x = r->s.mouse_location.x * 2.0 - 1.0;
    mouse_loc.y = r->s.mouse_location.y * 2.0 - 1.0;

    /* Map cursor back into thingspace.  Doing so twice   */
    /* starting with different Zs is a convenient way of   */
    /* defining the line of uncertainty along which the    */
    /* the target of the mouseclick lies.  The specific	   */
    /* values picked are *not* arbitrary, they are used	   */
    /* to specify the near/far clipping planes...          */
    mouse_loc.z =                       -1.0;
    lib26_Matrix_Apply_To_Point( &M[0], &mouse_loc, &inverse_transform );
    mouse_loc.z =                        1.0;
    lib26_Matrix_Apply_To_Point( &M[1], &mouse_loc, &inverse_transform );

    {   extern LVAL true;/*xlglob.c*/
	int i;
	int lo_lim = 0;
	int hi_lim = s->fLen;

	if (r->facet_to_check != -1) {
	    lo_lim = r->facet_to_check;
	    hi_lim = lo_lim +1;
	    if (lo_lim < 0        ||
		lo_lim >= s->fLen
	    ) {
		/* We issue error instead of silently returning in order to */
		/* encourage folks to delete on :UPCLICK not :DOWNCLICK     */
		xlfail("Dragged polygon has vanished!");
	    }
	} else {
	    lo_lim = 0;
	    hi_lim = s->fLen;
	}

	/* We don't hittest lines, need at least 3 sides to facet: */
	if (s->f2 == NULL) {
	    return TRUE;
	}

/* unfinished fix for the :FACET-IF bug */
#if 0
	/* get facet_if bitvector, if one exists */                      /*kph*/
	lv_facets   = xthl74_GetProp(&lv_thing, k_facetrelation, NIL, 0);/*kph*/
	lv_facet_if = xsendmsg2(lv_facets, k_getarray, k_facetif, NIL);  /*kph*/
	facet_if = null(lv_facet_if) ? NULL : csry_base(lv_facet_if);    /*kph*/
#endif

/* buggo: we still need to ignore facets which have been set not to draw. */
/* buggo: :draw-as :wire-frame/:point-cloud/:invisible also matters.      */
/* buggo: :drop-backfaces t can be a problem when picking. :-/            */
/* buggo: in DRAG case, we need to accept 'hits' that miss polygon.       */
	/* Over all facets eligible for hit-testing in thing: */
	for (i = lo_lim;   i < hi_lim;   ++i) {

/* unfinished fix for the :FACET-IF bug */
#if 0
	    /* skip supressed facets */                          /* kph */
            if (facet_if && (XCMR_GET_BIT(facet_if, i) == 0))    /* kph */
	      continue;                                          /* kph */
#endif
	    xcmrD6_GetPoint( s, &P[0], s->f0[i] );
	    xcmrD6_GetPoint( s, &P[1], s->f1[i] );
	    if (s->f3 == NULL) {
		/* Triangle case: */
		xcmrD6_GetPoint( s, &P[2], s->f2[i] );
		hit = libF2_Find_Intersection_Of_Line_With_Polygon(
		    &d,&PRM,&OBJ, /*dmin,dmax:*/r->dmin,r->dmax, P, M
		);

		/* Skip nonhits or hits outside volume of interest: */
		if (hit < 2)   continue;

		/* Skip hits outside triangle: */
		if (PRM.x < 0.0 || PRM.y < 0.0 || (PRM.x+PRM.y > 1.0)) continue;

	    } else {

		/* Rectangle case: */
		xcmrD6_GetPoint( s, &P[2], s->f3[i] );
		hit = libF2_Find_Intersection_Of_Line_With_Polygon(
		    &d,&PRM, &OBJ, /*dmin,dmax:*/r->dmin,r->dmax, P, M
		);

		/* Skip nonhits or hits outside volume of interest: */
		if (hit < 2)   continue;

		/* Skip hits outside rectangle.  This test is only   */
		/* valid for parallelograms, not for general 4-sided */
		/* figures, may want to hack this some more someday: */
		if (PRM.x < 0.0 || PRM.x > 1.0 ||
		    PRM.y < 0.0 || PRM.y > 1.0
		) {
		    continue;
	    }   }

            xcmrDA_NoteHit( r, s, d, &PRM, &OBJ, i, ggt );
	}
    }

    /* Continue iteration: */
    return TRUE;
}

/* }}} */

LVAL xcmrD9_RunWidgets_Msg()
{
    static struct xcmrC4_RunWidgets_struct dragged_state;
    static struct xcmrC4_RunWidgets_struct selected_state;

    struct        xcmrC4_RunWidgets_struct* default_state = NULL;

    LVAL* p_view;
    LVAL* p_persp;
    LVAL		lv_xcmr = xcmr01_Get_A_XCMR();
    ccmr_rec*		xcmr    = xcmr9c_Find_Immediate_Base( lv_xcmr );
    gt_tri_rec		s;
    struct xcmrC0_rec	r;
    int                 csux0   = xcmrC1_Initialize_C0Rec( &r, &s, lv_xcmr );
    int                 ran_hook= FALSE;

    LVAL old_s_xg3ddraggeddraghook    = getvalue( s_xg3ddraggeddraghook    );
    LVAL old_s_xg3ddraggedcamera      = getvalue( s_xg3ddraggedcamera      );
    LVAL old_s_xg3ddraggedthing       = getvalue( s_xg3ddraggedthing       );
    LVAL old_s_xg3ddraggedupclickhook = getvalue( s_xg3ddraggedupclickhook );

    LVAL  lv_mouse_state= getvalue(s_xg3dmousestate);
    LVAL  lv_mouse_row	= getvalue(s_xg3dmouserow);
    LVAL  lv_mouse_col	= getvalue(s_xg3dmousecol);
    char* err_mouse	= "Mouse coord not fixnum";
    int   csux1         = fixp(lv_mouse_row) || xlerror(err_mouse,lv_mouse_row);
    int   csux2         = fixp(lv_mouse_col) || xlerror(err_mouse,lv_mouse_col);
    int   mouse_row	= getfixnum( lv_mouse_row  );
    int   mouse_col	= getfixnum( lv_mouse_col  );


    /**************************************************************************/
    /* We need to run some small state machines here, driven by the mouse     */
    /* events we recieve and the things indicated by the mouse.               */
    /* Specifically:                                                          */
    /*                                                                        */
    /* 1 When the mouse button is down, we (often) need to track the          */
    /*   currently selected camera, thing, and facet, since these are         */
    /*   not allowed to change during a drag.  ("Often" == "whenever          */
    /*   :DRAG-HOOK or :UPCLICK-HOOK is supplied for a downclicked thing".)   */
    /*                                                                        */
    /* 2 When the mouse button is up, we (often) need to track the            */
    /*   currently selected camera, thing and :DESELECT-HOOK, so that         */
    /*   (1) We know whether to do a :SELECT or :RESELECT if an thing         */
    /*       is under the mouse cursor, and                                   */
    /*   (2) We know to do a :DESELECT if the thing under the cursor          */
    /*       is other than the tracked one.                                   */
    /*                                                                        */
    /* (We could save some state variables by combining some of the above     */
    /* state machines, but it seems to reduce complexity and increase         */
    /* clarity to keep them distinct.)                                        */
    /*                                                                        */
    /* To implement each of the above:                                        */
    /*                                                                        */
    /* 1 It is sufficient,                                                    */
    /*   o Any time a :DOWNCLICK event occurs on an thing                     */
    /*     with a :DRAG-HOOK or :UPCLICK-HOOK, to set                         */
    /*       XG.3D-DRAGGED-CAMERA,                                            */
    /*       XG.3D-DRAGGED-THING,  and                                        */
    /*       dragged_state                                                    */
    /*   o To clear XG.3D-DRAGGED-* on every :UPCLICK event.                  */
    /*                                                                        */
    /* 2 Any time :SELECT fails to match XG.3D-SELECTED-* data, to            */
    /*   o Execute XG.3D-SELECTED-DESELECT-HOOK on selected_state, if set.    */
    /*   o Clear XG.3D-SELECTED-*                                             */
    /*   o If something new was selected, to set                              */
    /*       XG.3D-SELECTED-CAMERA,                                           */
    /*       XG.3D-SELECTED-THING,                                            */
    /*       XG.3D-SELECTED-DESELECT-HOOK and                                 */
    /*       selected_state                                                   */
    /*     appropriately.                                                     */
    /*                                                                        */
    /* (The LVALs are stored in proper lisp variables to protect them from    */
    /* garbage collection between calls.)                                     */
    /**************************************************************************/


    /* Find and parse all our :THINGS stuff: */
    while (moreargs()) {
        LVAL key = xlgasymbol();
        if (key == k_things) {
	    r.lv_thinglist            = xlgalist();
	} else {
	    if (!xthlAY_Process_Thinglist_KeyVal_Pair( &s, key, xlgetarg() )) {
	        xlerror("Bad :RUN-WIDGETS keyword",key);
        }   }
    }
    if (null(r.lv_thinglist)) {
        r.lv_thinglist = xthl8a_GetObjectProp( lv_xcmr, k_things, NIL,TRUE );
    }
    if (null(r.lv_thinglist)) {
        r.lv_thinglist = xthl8a_GetObjectProp(
	    *xcmr33_Find_Viewing_Transform( lv_xcmr ),
            k_things,
            NIL,TRUE
        );
    }
    if (null(r.lv_thinglist)) {
	if (old_s_xg3ddraggedcamera != NIL) {
	    setvalue( s_xg3ddraggeddraghook    , old_s_xg3ddraggeddraghook     );
	    setvalue( s_xg3ddraggedcamera      , old_s_xg3ddraggedcamera       );
	    setvalue( s_xg3ddraggedthing       , old_s_xg3ddraggedthing        );
	    setvalue( s_xg3ddraggedupclickhook , old_s_xg3ddraggedupclickhook  );
	}
        return NIL;
    }

    /* Validate mouse state: */
    if (lv_mouse_state != k_downclick	&&
	lv_mouse_state != k_upclick	&&
	lv_mouse_state != k_select	&&
	lv_mouse_state != k_drag	&&
	lv_mouse_state != NIL
    ) {
	xlfail("Bad :RUN-WIDGETS :MOUSE-STATE",lv_mouse_state);
    }

    /* If no mouse event to process, just return: */
    if (lv_mouse_state == NIL) {
        return NIL;
    }

    /* If mouse state is :SELECT and we have a :DESELECT-HOOK */
    /* and mouse location is outside XG.3D-SELECTED-CAMERA's  */
    /* viewport, run and then clear the :DESELECT-HOOK:	      */
    if (lv_mouse_state == k_select		&&
        getvalue(s_xg3dselectedcamera) != NIL
    ) {
	LVAL	lv_xcmr = getvalue(s_xg3dselectedcamera);
	int	xmin, xmax;
	int	ymin, ymax;
	xcmr12_Get_Viewport_In_Pixel_Coords(
	    lv_xcmr,
	    &xmin, &xmax,
	    &ymin, &ymax
	);
	if (mouse_col <  xmin   ||   mouse_col >= xmax   ||
	    mouse_row <  ymin   ||   mouse_row >= ymax
	) {
	    /* Mouse has left selected viewport. */

	    /* Run :DESELECT-HOOK, if any:       */
	    xcmrD3_Run_Hook(
		lv_xcmr,
		getvalue( s_xg3dselecteddeselecthook ),
		&selected_state
	    );

	    /* Clear select state: */
	    setvalue( s_xg3dselectedcamera      , NIL );
	    setvalue( s_xg3dselecteddeselecthook, NIL );
    }	}


    if (lv_mouse_state == k_downclick ||
	lv_mouse_state == k_select
    ) {
	/* If mouse state is :DOWNCLICK or :SELECT but */
	/* outside our viewport, we're not interested: */
	if (mouse_col <  r.xmin   ||   mouse_col >= r.xmax   ||
	    mouse_row <  r.ymin   ||   mouse_row >= r.ymax
	) {
	    return NIL;
	}
        if (lv_mouse_state == k_downclick) {
	    setvalue( s_xg3ddraggedcamera, lv_xcmr );
	}
	setvalue( s_xg3ddraggedthing      , NIL );
	setvalue( s_xg3ddraggeddraghook   , NIL );
	setvalue( s_xg3ddraggedupclickhook, NIL );
    } else {
	/* Mouse state is :DRAG or :UPCLICK. */
	/* If we are not the active camera,  */
	/* we're done:                       */
	if (r.lv_xcmr != getvalue(s_xg3ddraggedcamera)) {
            return NIL;
    }   }

    /* Look at the state we're in and the things on the thinglist   */
    /* in order to decide whether we really need to do hit-testing. */
    /* Since hit-testing can be very expensive, we want to avoid it */
    /* whenever possible:					    */
    r.lv_mouse_state = lv_mouse_state;
    if (!xcmrD5_Need_To_Do_Hit_Testing( &s, r.lv_thinglist, &r )) {
	if (old_s_xg3ddraggedcamera != NIL) {
	    setvalue( s_xg3ddraggeddraghook    , old_s_xg3ddraggeddraghook     );
	    setvalue( s_xg3ddraggedcamera      , old_s_xg3ddraggedcamera       );
	    setvalue( s_xg3ddraggedthing       , old_s_xg3ddraggedthing        );
	    setvalue( s_xg3ddraggedupclickhook , old_s_xg3ddraggedupclickhook  );
	}
        if (lv_mouse_state == k_upclick) {
	    /* Clear drag info: */
	    setvalue( s_xg3ddraggeddraghook   , NIL );
	    setvalue( s_xg3ddraggedupclickhook, NIL );
	    setvalue( s_xg3ddraggedcamera     , NIL );
	    setvalue( s_xg3ddraggedthing      , NIL );
	}
        return NIL;
    }

    /* If r.lv_thing_to_check is not NIL, we want to test only    */
    /* against a single polygon.				  */
    if (r.lv_thing_to_check != NIL) {
	r.facet_to_check = dragged_state.selected_facet;
    }

    /* Clip mouse location to viewport:   */
    if (mouse_col <  r.xmin)   mouse_col = r.xmin;
    if (mouse_row <  r.ymin)   mouse_row = r.ymin;
    if (mouse_col >= r.xmax)   mouse_col = r.xmax -1;
    if (mouse_row >= r.ymax)   mouse_row = r.ymax -1;

    /* Convert mouse location from window */
    /*  to viewport coordinate system:    */
    mouse_col -= r.xmin;
    mouse_row -= r.ymin;

    /* Save mouse location for hook fns:  */
    r.s.mouse_col = mouse_col;
    r.s.mouse_row = mouse_row;

    /* Express mouse location in [0,1]    */
    /* viewport-based coordinate system:  */
    r.s.mouse_location.x = ((float)mouse_col) / ((float)(r.xsiz -1));
    r.s.mouse_location.y = ((float)mouse_row) / ((float)(r.ysiz -1));

    /* Check to see which thing is active  (:DOWNCLICK or :SELECT) */
    /* or which point on thing is selected (:DRAG and :UPCLICK):   */
    xthlB0_Process_Thing_List(
	r.lv_thinglist,
	&s,
	xcmrD8_RunWidgets,
	&r
    );

    /* If state is :SELECT but selected thing is not what	*/
    /* it used to be, we may want to run a :DESELECT-HOOK:	*/
    if (r.lv_mouse_state == k_select) {
	LVAL    lv_old_selected_thing = getvalue( s_xg3dselectedthing );
	if (    lv_old_selected_thing != r.s.lv_selected_thing) {
	    if (lv_old_selected_thing != NIL) {
		xcmrD3_Run_Hook(
		    getvalue( s_xg3dselectedcamera       ),
		    getvalue( s_xg3dselecteddeselecthook ),
		    &selected_state
		);

		/* Clear select state: */
		setvalue( s_xg3dselectedcamera, NIL );
    }   }   }

    /* If we are in :DRAG or :UPCLICK mode, and mouse missed dragged */
    /* polygon, we want to act as though it hit the last known spot: */

/* BUG:  this doesn't seem to work.  If you move off of a polygon, the
   "remembered" location is that of the click, not the last known drag.
   (kph, 1998Oct28)
*/
    if (null(r.s.lv_selected_thing)) {
	if (lv_mouse_state == k_drag) {
	    r.s		     = dragged_state;
	    r.lv_drag_hit    = getvalue( s_xg3ddraggeddraghook    );
        }
	if (lv_mouse_state == k_upclick) {
	    r.s		     = dragged_state;
	    r.lv_upclick_hit = getvalue( s_xg3ddraggedupclickhook );
        }
    }
/* buggo, should implement a truly-hit flag at some point. */

    /* Run any appropriate hook: */
    if (!null(r.s.lv_selected_thing)) {
	LVAL     lv_hook        =  NIL;
	LVAL     lv_mouse_state =  r.lv_mouse_state;
	if      (lv_mouse_state == k_downclick)   lv_hook = r.lv_downclick_hit;
	else if (lv_mouse_state == k_drag     )   lv_hook = r.lv_drag_hit     ;
	else if (lv_mouse_state == k_upclick  )   lv_hook = r.lv_upclick_hit  ;
	else if (lv_mouse_state == k_select   ) {
	    /* On first :SELECT of an thing, maybe run :RESELECT-HOOK: */
	    if (getvalue( s_xg3dselectedthing ) != r.s.lv_selected_thing) {
		lv_hook = r.lv_reselect_hit;
	    } else {
		lv_hook = r.lv_select_hit;
	    }
	} else {
	    abort(); /* Note we've already returned if null(lv_mouse_state) */
	}

	xcmrD3_Run_Hook( lv_xcmr, lv_hook, &r.s );
        if (r.redraw) {
            ran_hook = TRUE;
	}
    }

    /* For :DOWNCLICK and :SELECT, we need to remember state, */
    /* for :UPCLICK we need to forget some state:	      */
    if        (r.lv_mouse_state == k_select   ) {
	selected_state = r.s;
	setvalue( s_xg3dselectedcamera      , lv_xcmr			);
	setvalue( s_xg3dselectedthing      , r.s.lv_selected_thing	);
	setvalue( s_xg3dselecteddeselecthook, r.lv_deselect_hit		);
    } else if (r.lv_mouse_state == k_downclick) {
	dragged_state  = r.s;
	/* The next two 'if's are a rather ugly 96Sep21jsp hack   */
	/* attempting to have upclick work usably in the presence */
	/* of overlapping windows by preserving the dragged* info */
	/* from a downclick action in preference to the dragged*  */
	/* info from windows without a downclick action firing:   */
	if (ran_hook) {
	    setvalue( s_xg3ddraggedcamera     , lv_xcmr		    );
	    setvalue( s_xg3ddraggedthing      , r.s.lv_selected_thing   );
	    setvalue( s_xg3ddraggeddraghook   , r.lv_drag_hit           );
	    setvalue( s_xg3ddraggedupclickhook, r.lv_upclick_hit        );
	} else {
	    if (old_s_xg3ddraggedcamera != NIL) {
		setvalue( s_xg3ddraggeddraghook    , old_s_xg3ddraggeddraghook     );
		setvalue( s_xg3ddraggedcamera      , old_s_xg3ddraggedcamera       );
		setvalue( s_xg3ddraggedthing       , old_s_xg3ddraggedthing        );
		setvalue( s_xg3ddraggedupclickhook , old_s_xg3ddraggedupclickhook  );
	    }
	}
    } else if (r.lv_mouse_state == k_upclick) {
	/* Upclick means it is time to clear our dragstate: */
	setvalue( s_xg3ddraggeddraghook   , NIL );
	setvalue( s_xg3ddraggedupclickhook, NIL );
	setvalue( s_xg3ddraggedcamera     , NIL );
	setvalue( s_xg3ddraggedthing      , NIL );
    } else if (r.lv_mouse_state == k_drag) {
	/* 96Sep26jsp addition to better support overlapping cameras: */
	if (ran_hook) {
	    setvalue( s_xg3ddraggedcamera     , lv_xcmr		    );
	    setvalue( s_xg3ddraggedthing      , r.s.lv_selected_thing   );
	    setvalue( s_xg3ddraggeddraghook   , r.lv_drag_hit           );
	    setvalue( s_xg3ddraggedupclickhook, r.lv_upclick_hit        );
	} else {
	    if (old_s_xg3ddraggedcamera != NIL) {
		setvalue( s_xg3ddraggeddraghook    , old_s_xg3ddraggeddraghook     );
		setvalue( s_xg3ddraggedcamera      , old_s_xg3ddraggedcamera       );
		setvalue( s_xg3ddraggedthing       , old_s_xg3ddraggedthing        );
		setvalue( s_xg3ddraggedupclickhook , old_s_xg3ddraggedupclickhook  );
	    }
	}
    }

    {   extern LVAL true;/*xlglob.c*/
	return ran_hook ? true : NIL;
    }
}

/* }}} */
/* {{{ xcmrE5_ReadMouseState_Msg -- Set XG.3D-MOUSE-ROW/COL/STATE.	*/

xcmrE4_ReadMouseState( block_until_input_arrives )
int                    block_until_input_arrives;
{
    static int		frame_Of_Last_Mouse_Event = -1;
    static int		mouse_Button_Is_Depressed = FALSE;

    extern char* xgtmG8_State();
    char*        state	      = xgtmG8_State();
    int          events_read  = 0;

    while (
        block_until_input_arrives              ||
        xgtmG4_Queue_Input_Available( state )
    ) {
	LVAL lv_click;
	int  event;
	int  value;
	int  x;
	int  y;
	xgtmG0_Blocking_Queue_Read( state, &event, &value, &x, &y );
        block_until_input_arrives = FALSE;
	++events_read;

	switch (event) {

	case GT_REDRAW:
	    /* Call XG.3D-REDRAW-HOOK fns, if any: */
	    xthlF5_Call_HookFns( getvalue( s_xg3dredrawhook ) );
	    /* Maybe should do this a maximum of once per call? */
	    break;

	case GT_KEYBOARD:
	    /* Call XG.3D-KEYBOARD-CHAR-HOOK fns, if any: */
	    setvalue( s_xg3dkeyboardchar, cvchar(value) );
	    xthlF5_Call_HookFns( getvalue( s_xg3dkeyboardcharhook ) );
	    break;

	case GT_DOWNCLICK:
	    /* Return (:DOWNCLICK <x> <y>): */
	    lv_click = k_downclick;
	    mouse_Button_Is_Depressed	= TRUE;
	    goto click_join;
	case GT_UPCLICK:
	    /* Return (:UPCLICK <x> <y>): */
	    mouse_Button_Is_Depressed	= FALSE;
	    lv_click = k_upclick;
	click_join:
	    xcmrD7_ClipMouseLoc( state, &x, &y );
	    setvalue( s_xg3dmousestate     , lv_click    );
	    setvalue( s_xg3dmousecol       , cvfixnum(x) );
	    setvalue( s_xg3dmouserow       , cvfixnum(y) );
	    setvalue( s_xg3dmousepressure  ,
	        cvfixnum(1024*mouse_Button_Is_Depressed)
	    );
	    frame_Of_Last_Mouse_Event = xcmr05_Frame_Number;
	    return events_read;

	default:
	    /* Can only happen on broken driver: */
	    abort();
    }	}

    /* No click:  Poll for current mouse position: */
    {   int x, y;
	xgtmF0_Mouse_Position( state, &x, &y );
	xcmrD7_ClipMouseLoc(   state, &x, &y );
	setvalue( s_xg3dmouserow  , cvfixnum( y ) );
	setvalue( s_xg3dmousecol  , cvfixnum( x ) );
	setvalue( s_xg3dmousepressure  ,
	    cvfixnum(1024*mouse_Button_Is_Depressed)
	);
    }

    /* Maybe synthesize a :DRAG or :SELECT event: */
    {   LVAL lv_mouse_state = NIL;
	if (frame_Of_Last_Mouse_Event != xcmr05_Frame_Number) {
	    if (mouse_Button_Is_Depressed)	lv_mouse_state = k_drag;
	    else				lv_mouse_state = k_select;
	}
	setvalue( s_xg3dmousestate, lv_mouse_state );
    }
    frame_Of_Last_Mouse_Event = xcmr05_Frame_Number;
    return events_read;
}
LVAL xcmrE5_ReadMouseState_Msg() {
    LVAL lv_xcmr = xcmr01_Get_A_XCMR();
    int  block_until_input_arrives = TRUE;
    extern LVAL true;/*xlglob.c*/
    while (moreargs()) {
        LVAL lv_key = xlgasymbol();
	if (lv_key == k_blockuntilinputarrives) {
            block_until_input_arrives = !null(xlgetarg());
        } else {
	    xlerror("Bad :READ-MOUSE-STATE keyword:",lv_key);
    }	}
    return xcmrE4_ReadMouseState(block_until_input_arrives) ? true : NIL;
}

/* }}} */
/* {{{ xcmrF0_Copy_Contents_Msg--Copy contents of another xcmr into self*/

LVAL xcmrF1_Copy_Contents( m_as_lval, x_as_lval, depth )
LVAL			   m_as_lval, x_as_lval;
int						 depth;
{
    ccmr_rec * m = xcmr9c_Find_Immediate_Base( m_as_lval );
    ccmr_rec * x = xcmr9c_Find_Immediate_Base( x_as_lval );
    c03d_fileInfo f;

    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    f           = m->fileInfo;
    *m          = *x;
    m->fileInfo = f;

    return x_as_lval;
}

LVAL xcmrF0_Copy_Contents_Msg()
/*-
    Copy contents of another xcmr into self.
-*/
{
    LVAL m_as_lval = xcmr01_Get_A_XCMR();
    LVAL x_as_lval = xcmr01_Get_A_XCMR();
    int  depth = x03d80_GetProplistCopyDepth();
    return xcmrF1_Copy_Contents( m_as_lval, x_as_lval, depth );
}

/* }}} */
/* {{{ xcmrz7_Read_Xcmr_From_File                                       */

xcmrz7_Read_Xcmr_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   ccmr_rec* h;
    char*     p;
    if (version != CCMR_REC_VERSION) {
	xlerror("xcmrz7: unsupported version",cvfixnum(version));
    }
    h = (ccmr_rec*) gobjimmbase( lv );

    p = (char*) &h->CCMR_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CCMR_INT32_COUNT,  magic, fp );

    p = (char*) &h->CCMR_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CCMR_FLOAT_COUNT,  magic, fp );
}

/* }}} */
/* {{{ xcmrwo_Write_Xcmr_To_Graphics_File                               */

xcmrwo_Write_Xcmr_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   ccmr_rec* h = (ccmr_rec*) gobjimmbase( lv );

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CCMR_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CCMR_FIRST_INT32, CCMR_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CCMR_FIRST_FLOAT, CCMR_FLOAT_COUNT, fdob);
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
