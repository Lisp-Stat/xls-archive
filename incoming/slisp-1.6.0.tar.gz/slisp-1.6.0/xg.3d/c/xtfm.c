/* {{{ xtfm.c -- 4x4 transform matrices.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      90Nov20
* Modified:
* Language:     C
* Package:      N/A
* Status:
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */
/* {{{ --- history ---							*/

/* 98Oct13 kph: Added xtfmH0_Decompose_Matrix.                          */
/* 96Nov05 jsp: xtfmb2_Compute_Bounding_Box verifies POINT-X/Y/Z present*/
/* 95Jan10 jsp: xtfm93_Frame_Things fix for ortho view (radians==0.0).	*/
/* 92Mar22 jsp: Copy_Spaceball_Matrix.              			*/
/* 91Nov21 jsp: Turtle forward, pitch, yaw, rotate.			*/
/* 91Jul30 jdp: Rotates around an arbitrary axis and origin.		*/
/* 90Nov20 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL s_stdout;
extern LVAL xsendmsg0();
#ifndef NEW
LOCAL LVAL xtfm05_Identity();
#endif

extern LVAL k_axis;
extern LVAL k_degrees;
extern LVAL k_initialcontents;
extern LVAL k_initializefromfile;
extern LVAL k_move;
extern LVAL k_origin;
extern LVAL k_radians;
extern LVAL k_rotate;
extern LVAL k_scale;
extern LVAL k_shear;
extern LVAL k_xfmaxis;
extern LVAL k_xfmorigin;
extern LVAL k_xrotate;
extern LVAL k_yrotate;
extern LVAL k_zrotate;
extern LVAL lv_xtfm;
extern LVAL k_diameter;
extern LVAL k_left;
extern LVAL k_right;
extern LVAL k_top;
extern LVAL k_bottom;
extern LVAL k_near;
extern LVAL k_far;
extern LVAL k_location;
extern LVAL k_perframehook;
extern LVAL k_target;
extern LVAL k_transform;
extern LVAL k_up;
extern LVAL k_perspective;

#include <math.h>
#include "geo.h"
#include "ctfm.h"
#include "cgrl.h"
#include "csry.h"
#include "clgt.h"
#include "cmtl.h"
#include "cmdl.h"
#include "c03d.h"
#include "cthl.h"
#include "lib.h"
#include "../../xg.3d.fileio/c/cfil.h"


#define iabs(x)	((x) >= 0 ? (x) : -(x))
#define DEGREES_TO_RADIANS (3.1415926535897932384626 / 180.0)
#define RADIANS_TO_DEGREES (180.0 / 3.1415926535897932384626)

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xtfm00_Is_New -- Initialize a new xtfm instance.			*/

ctfm_rec xtfm___defaults = {
    C03D_xTFM,	      /* k_class			*/
    C03D_FILEiNFO_INIT,   /* Always 2nd in record.          */
#ifndef sgi
    {{1.0, 0.0, 0.0, 0.0},
     {0.0, 1.0, 0.0, 0.0},
     {0.0, 0.0, 1.0, 0.0},
     {0.0, 0.0, 0.0, 1.0}},
#else
    {1.0, 0.0, 0.0, 0.0,
     0.0, 1.0, 0.0, 0.0,
     0.0, 0.0, 1.0, 0.0,
     0.0, 0.0, 0.0, 1.0},
#endif
    {0.0, 0.0, 0.0},		/* Camera location.		*/
    1.0,			/* angle_of_view_in_radians.	*/
    1.0,			/* Diameter of bounding box.	*/
    0.0, 0.0,			/* left, roit.			*/
    0.0, 0.0,			/* top , bot .			*/
    0.0, 0.0,			/* near, far .			*/
    { 0.0, 0.0  , 1.0 },	/* Camera target.		*/
    { 0.0, 1.0e7, 0.0 },        /* Camera 'up' point. 1.0e27 is	*/
				/* too large, m[0][0] & m[1][1] */
				/* wind up 0 instead of 1 ... ! */
    0,				/* want_to_recompute_matrix.	*/
};


LVAL xtfm00_Is_New()
{
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv   = xlgagobject();
    LVAL init = NIL;
    ctfm_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xtfmp(lv))   xlerror("bad argument type",lv);
#endif
    xgbj11_Set_Size_In_Bytes( lv, sizeof(ctfm_rec) );

    /* Initialize camera record to reasonable default values: */
    r	= (ctfm_rec*) gobjimmbase( lv );
   *r   = xtfm___defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    if (moreargs()) {
        init = xlgasymbol();
        if (init == k_initialcontents) {
            /* Handle ":initial-contents '((1 0 0 0)(...)(...)(...))" */
	    ctfm_rec * mat = (ctfm_rec*) gobjimmbase(lv);
	    LVAL row;
	    int  i;
	    int  j;
            row = init = xlgalist();
	    for (i=0; i<4; ++i) {
		LVAL col;
		if (!consp(row)) xlbadinit(init);
		col = car(row);
		row = cdr(row);
		for (j=0; j<4; ++j) {
		    LVAL f_as_lval;
		    if (!consp(col)) xlbadinit(init);
		    f_as_lval    = car(col);
		    col          = cdr(col);
		    mat->m.m[i][j] = xgbj00_Get_Fix_Or_Flo_Num(f_as_lval);
		}
		if (col != NULL)  xlbadinit(init);
	    }
	    if (row != NULL)  xlbadinit(init);

        } else if (init == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xtfmz7_Read_Xtfm_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv,
		getfile(xlgetfile()),
		xtfmz7_Read_Xtfm_From_File,NULL
	    );

        } else if (init == k_move) {

            /* Handle ":new :move 0 1 2" */
            FORWARD LVAL xtfm19_Move();
            lv = xtfm19_Move(lv);

        } else if (init == k_scale) {

            /* Handle ":new :scale 0 1 2" */
            FORWARD LVAL xtfm61_Scale();
            lv = xtfm61_Scale(lv);

        } else if (init == k_shear) {

            /* Handle ":new :shear 0 1 2 3 4 5" */
            FORWARD LVAL xtfm68_Shear();
            lv = xtfm68_Shear(lv);

        } else if (init == k_xrotate) {

            /* Handle ":new :x-rotate pi2" */
            FORWARD LVAL xtfm34_X_Rotate();
            lv = xtfm34_X_Rotate(lv);

        } else if (init == k_yrotate) {

            /* Handle ":new :y-rotate pi2" */
            FORWARD LVAL xtfm43_Y_Rotate();
            lv = xtfm43_Y_Rotate(lv);

        } else if (init == k_zrotate) {

            /* Handle ":new :z-rotate pi2" */
            FORWARD LVAL xtfm52_Z_Rotate();
            lv = xtfm52_Z_Rotate(lv);

        } else if (init == k_rotate) {

            /* Handle ":new :rotate :radians pi2" */
	    FORWARD LVAL xtfm24_Rotate();
	    lv = xtfm24_Rotate( lv );

        } else {

            xlerror("bad argument",init);
        }
    }
    xllastarg();

    return lv;
}

/* }}} */
/* {{{ xtfm01_Get_A_XTFM -- Get arg, must be of class xtfm.		*/

LVAL xtfm01_Get_A_XTFM() /* Also called from xcmr.c... */
/*-
    Get arg, must be of class xtfm.
-*/
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XTFM has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xtfm.  Similarly,          */
    /* nobody but nobody has any business resizing a xtfm,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xtfmp(m_as_lval) ||
        getgobjimmbytes(m_as_lval) != sizeof(ctfm_rec)
    ) {
        xlerror("bad argument type",m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xtfm02_Get_Index -- Get valid index (0 <= fixnum <4).		*/

LOCAL xtfm02_Get_Index( i_as_lval )
LVAL              	i_as_lval;
/*-
    Get valid index (0 <= fixnum <4).
-*/
{
    int i = getfixnum( i_as_lval );
    if (i < 0 || i > 3) xlerror("bad index value",i_as_lval);
    return i;
}

/* }}} */
/* {{{ xtfm03_Show_Msg -- Show the contents of a xtfm.		       	*/

LVAL xtfm03_Show_Msg()
/*-
    Show the contents of a xtfm.
-*/
{
    LVAL self,fptr;
    int i,j;
    ctfm_rec * m;

    /* get self and the file pointer */
    self = xtfm01_Get_A_XTFM();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the matrix proper: */
    m = xtfm9c_Find_Immediate_Base( self );
    libE7_xlprint_point( "location" , &m->location, fptr );
    libE7_xlprint_point( "target  " , &m->target  , fptr );
    libE7_xlprint_point( "up      " , &m->up      , fptr );
    for (    i = 0;   i < 4;   ++i) {
        for (j = 0;   j < 4;   ++j) {
            char buf[32];
            double d = m->m.m[i][j];
            sprintf(buf,"  %-7.5g",d);
	    xlputstr(fptr,buf);
        }
	xlterpri(fptr);
    }

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xtfm04_Identity_Msg -- Set to identity matrix.			*/

LOCAL LVAL xtfm05_Identity( m_as_lval )
LVAL			    m_as_lval;
/*-
    Set to identity matrix.
-*/
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );

#ifdef OLD
    ctfm00_Identity(&m->m);
#else
   *m   = xtfm___defaults;
#endif

    return m_as_lval;
}

LVAL xtfm04_Identity_Msg()
/*-
    Set to identity matrix.
-*/
{
    LVAL m_as_lval = xtfm01_Get_A_XTFM();
    xllastarg();
    return xtfm05_Identity(m_as_lval);
}

/* }}} */
/* {{{ xtfm06_Get_Msg -- get given entry.				*/

LVAL xtfm07_Get( m_as_lval, i_as_lval, j_as_lval )
LVAL		 m_as_lval, i_as_lval, j_as_lval;
/*-
    Get given entry.
-*/
{
    ctfm_rec *   m = xtfm9c_Find_Immediate_Base( m_as_lval );
    int          i =            xtfm02_Get_Index(i_as_lval);
    int          j =            xtfm02_Get_Index(j_as_lval);
    return cvflonum(m->m.m[i][j]);
}

LVAL xtfm06_Get_Msg()
/*-
    Get given entry.
-*/
{
    LVAL m_as_lval = xtfm01_Get_A_XTFM();
    LVAL i_as_lval = xlgafixnum();
    LVAL j_as_lval = xlgafixnum();
    xllastarg();
    return xtfm07_Get(m_as_lval,i_as_lval,j_as_lval);
}

/* }}} */
/* {{{ xtfm08_Set_Msg -- Set given entry.				*/

LVAL xtfm09_Set( m_as_lval, v_as_lval, i_as_lval, j_as_lval )
LVAL		 m_as_lval, v_as_lval, i_as_lval, j_as_lval;
/*-
    Set given entry.
-*/
{

    ctfm_rec *      m = xtfm9c_Find_Immediate_Base( m_as_lval );
    FLOTYPE         v =   xgbj00_Get_Fix_Or_Flo_Num(v_as_lval);
    int             i =   xtfm02_Get_Index(         i_as_lval);
    int             j =   xtfm02_Get_Index(         j_as_lval);

    m->m.m[i][j] = v;

    return v_as_lval;
}

LVAL xtfm08_Set_Msg()
/*-
    Set given entry.
-*/
{
    LVAL m_as_lval = xtfm01_Get_A_XTFM();
    LVAL v_as_lval = xlgetarg();/* May be fix or flo. */
    LVAL i_as_lval = xlgafixnum();
    LVAL j_as_lval = xlgafixnum();
    xllastarg();
    return xtfm09_Set(m_as_lval,v_as_lval,i_as_lval,j_as_lval);
}

/* }}} */
/* {{{ xtfm10_Matrix_Multiply_Msg--Return product of us and given matrix*/

LVAL xtfm11_Matrix_Multiply( m_as_lval, x_as_lval )
LVAL			     m_as_lval, x_as_lval;
/*-
    Return product of us and given matrix.
-*/
{
    /* Create a new matrix to hold result: */
    LVAL r_as_lval; /* Result matrix. */
    xlstkcheck(2);
    xlprotect(m_as_lval);
    xlprotect(x_as_lval);
    r_as_lval = xsendmsg0(lv_xtfm,k_new);
    xlpopn(2);

    /* Do the multiply and return product: */
    {
        ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
        ctfm_rec * x = xtfm9c_Find_Immediate_Base( x_as_lval );
        ctfm_rec * r = xtfm9c_Find_Immediate_Base( r_as_lval );
        ctfm01_Matrix_Multiply( &r->m, &m->m, &x->m ) ;
        r->want_to_recompute_matrix = FALSE;
    }
    return r_as_lval;
}

LVAL xtfm10_Matrix_Multiply_Msg()
/*-
    Return product of us and given matrix.
-*/
{
    LVAL m_as_lval = xtfm01_Get_A_XTFM();
    LVAL x_as_lval = xtfm01_Get_A_XTFM();
    xllastarg();
    return xtfm11_Matrix_Multiply(m_as_lval,x_as_lval);
}

/* }}} */
/* {{{ xtfm12_Matrix_Multiply_Pre_Msg--Pre-mult matrix by given matrix.	*/

LVAL xtfm13_Matrix_Multiply_Pre( m_as_lval, x_as_lval )
LVAL				 m_as_lval, x_as_lval;
/*-
    Pre-multiply matrix by given matrix.
-*/
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm_rec * x = xtfm9c_Find_Immediate_Base( x_as_lval );
    ctfm02_Matrix_Multiply_Pre(&m->m,&x->m);
    return m_as_lval;
}

LVAL xtfm12_Matrix_Multiply_Pre_Msg()
/*-
    Pre-multiply matrix by given matrix.
-*/
{
    LVAL m_as_lval = xtfm01_Get_A_XTFM();
    LVAL x_as_lval = xtfm01_Get_A_XTFM();
    xllastarg();
    return xtfm13_Matrix_Multiply_Pre(m_as_lval,x_as_lval);
}

/* }}} */
/* {{{ xtfm14_Matrix_Multiply_Post_Msg--Post-mult matrix by given mat. 	*/

LVAL xtfm15_Matrix_Multiply_Post( m_as_lval, x_as_lval )
LVAL				  m_as_lval, x_as_lval;
/*-
    Post-multiply matrix by given mat.
-*/
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm_rec * x = xtfm9c_Find_Immediate_Base( x_as_lval );
    ctfm03_Matrix_Multiply_Post(&m->m,&x->m);
    return m_as_lval;
}

LVAL xtfm14_Matrixt_Multiply_Post_Msg()
/*-
    Post-multiply matrix by given mat.
-*/
{
    LVAL m_as_lval = xtfm01_Get_A_XTFM();
    LVAL x_as_lval = xtfm01_Get_A_XTFM();
    xllastarg();
    return xtfm15_Matrix_Multiply_Post(m_as_lval,x_as_lval);
}

/* }}} */
/* {{{ xtfm16_Copy_Msg -- Build copy of given XTFM.			*/

LVAL xtfm17_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given XTFM.
-*/
{
    /* Create a new matrix to hold result: */
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval = xsendmsg0(lv_xtfm,k_new);
    xlpop();

    /* Copy contents of old matrix to new and return new: */
    {
        ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
        ctfm_rec * r = xtfm9c_Find_Immediate_Base( r_as_lval );
        *r = *m;
    }
    return r_as_lval;
}

LVAL xtfm16_Copy_Msg()
/*-
    Build copy of given XTFM.
-*/
{
    LVAL m_as_lval;
    LVAL x_as_lval = xtfm01_Get_A_XTFM();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xtfm17_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xtfm18_Move_Msg -- Build XYZ-translation matrix.			*/

xtfm20_Move_Args( m_as_lval, offset, axis, distance )
LVAL	          m_as_lval;
geo_point		    *offset,*axis;
double*				           distance;
{
    /****************************************************/
    /* 'move' commands can look like any of:		*/
    /* (:move-post m 4 0 0)				*/
    /* (:move-post m :axis             '(1 0 0) 4)	*/
    /* (:move-post m :transformed-axis '(1 0 0) 4)	*/
    /****************************************************/

    if (!symbolp(*xlargv)) {
        LVAL x_as_lval = xlgetarg();/* May be fix or flo. */
        LVAL y_as_lval = xlgetarg();/* May be fix or flo. */
        LVAL z_as_lval = xlgetarg();/* May be fix or flo. */
	xllastarg();

        offset->x = xgbj00_Get_Fix_Or_Flo_Num(x_as_lval);
        offset->y = xgbj00_Get_Fix_Or_Flo_Num(y_as_lval);
        offset->z = xgbj00_Get_Fix_Or_Flo_Num(z_as_lval);

	return FALSE;
    }

    {
        LVAL key = xlgasymbol();
	LVAL arg;
        if (key == k_axis) {

            /* Handle ":axis '(1.0 0.0 0.0)" */
            lib16_List_To_Point( axis, arg=xlgalist() );

	    /* Null axes are hard to rotate around: */
	regular_axis_code:
	    if (
                axis->x * axis->x +
                axis->y * axis->y +
                axis->z * axis->z
					<
		1e-50
            ) {
                xlbadinit(arg);
	    }

        } else if (key == k_xfmaxis) {

            /* Handle ":transformed-axis '(1.0 0.0 0.0)" */
	    geo_point unmashed_axis;
	    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
            lib16_List_To_Point(               &unmashed_axis, arg=xlgalist() );
	    lib27_Matrix_Apply_To_Normal(axis ,&unmashed_axis, &mat->m);

	    goto regular_axis_code;

	} else {

            xlbadinit(key);
        }
    }
    lib08_Vector_Normalize( axis );
    *distance = (double) xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    xllastarg();
    return TRUE;
}


LVAL xtfm19_Move( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build XYZ-translation matrix.
-*/
{
    geo_point offset, axis;
    double    distance;
    if (!xtfm20_Move_Args( m_as_lval, &offset, &axis, &distance )) {
	ctfm_rec* m = xtfm9c_Find_Immediate_Base( m_as_lval );
	ctfm04_Move(&m->m,&offset);
    } else {
	ctfm_rec* m = xtfm9c_Find_Immediate_Base( m_as_lval );
	ctfm37_Move_Axis(&m->m,&axis,&distance);
    }
    return m_as_lval;
}

LVAL xtfm18_Move_Msg()
/*-
    Build XYZ-translation matrix.
-*/
{
    return xtfm19_Move(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm21_Move_Pre_Msg--Build XYZ-translation matrix, pre-mult by it*/

LVAL xtfm22_Move_Pre( m_as_lval )
LVAL		      m_as_lval;
/*-
    Build XYZ-translation matrix, pre-multiply by it.
-*/
{
    geo_point offset, axis;
    double    distance;
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    if (!xtfm20_Move_Args( m_as_lval, &offset, &axis, &distance )) {
	ctfm05_Move_Pre(&m->m,&offset);
    } else {
	ctfm38_Move_Axis_Pre(&m->m,&axis,&distance);
    }
    return m_as_lval;
}

LVAL xtfm21_Move_Pre_Msg()
/*-
    Build XYZ-translation matrix, pre-multiply by it.
-*/
{
    return xtfm22_Move_Pre(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm23_Move_Post_Msg--Build XYZ-translation mat, post-mult by it.*/

LVAL xtfm24_Move_Post( m_as_lval )
LVAL		       m_as_lval;
/*-
    Build XYZ-translation mat, post-multiply by it.
-*/
{
    geo_point offset, axis;
    double    distance;
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    if (!xtfm20_Move_Args( m_as_lval, &offset, &axis, &distance )) {
	ctfm06_Move_Post(&m->m,&offset);
    } else {
	ctfm39_Move_Axis_Post(&m->m,&axis,&distance);
    }
    return m_as_lval;
}

LVAL xtfm23_Move_Post_Msg()
/*-
    Build XYZ-translation mat, post-multiply by it.
-*/
{
    return xtfm24_Move_Post(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm25_Rotate_Msg -- Build rotation matrix.			*/

xtfm26_Rotate_Args( m_as_lval, origin, axis, radians, got_axis )
LVAL	            m_as_lval;
geo_point		      *origin,*axis;
double*				             radians;
int						      got_axis;
{
    static geo_point def_origin  = {0.0, 0.0, 0.0};
    static geo_point def_axis    = {0.0, 1.0, 0.0};
    int just_radians = TRUE;

    *                   origin  = def_origin;
    if (!got_axis)     *axis    = def_axis;
    *                   radians = (3.14159265358979 / 180.0) * 5.0;

    while (moreargs()) {
        LVAL init = xlgasymbol();
	LVAL arg;
        if (init == k_axis) {

            /* Handle ":axis '(1.0 0.0 0.0)" */
            lib16_List_To_Point( axis, arg=xlgalist() );

	    /* Null axes are hard to rotate around: */
	regular_axis_code:
	    if (
                axis->x * axis->x +
                axis->y * axis->y +
                axis->z * axis->z
					<
		0.000001
            ) {
                xlbadinit(arg);
	    }
	    just_radians = FALSE;

        } else if (init == k_xfmaxis) {

            /* Handle ":transformed-axis '(1.0 0.0 0.0)" */
	    geo_point unmashed_axis;
	    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
            lib16_List_To_Point(               &unmashed_axis, arg=xlgalist() );
	    lib27_Matrix_Apply_To_Normal(axis ,&unmashed_axis,  &mat->m);

	    goto regular_axis_code;

        } else if (init == k_origin) {

            /* Handle ":origin '(0.0 1.0 0.0)" */
            lib16_List_To_Point( origin, xlgalist() );
	    just_radians = FALSE;

        } else if (init == k_xfmorigin) {

            /* Handle ":transformed-origin '(0.0 1.0 0.0)" */
	    ctfm_rec* mat = xtfm9c_Find_Immediate_Base( m_as_lval );
	    geo_point untransformed_origin;
            lib16_List_To_Point( &untransformed_origin, xlgalist() );
	    lib26_Matrix_Apply_To_Point( origin, &untransformed_origin, &mat->m );
	    just_radians = FALSE;

        } else if (init == k_radians) {

            /* Handle ":radians 1.1" */
	   * radians = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

        } else if (init == k_degrees) {

            /* Handle ":degrees 30.3" */
	   * radians = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() ) * DEGREES_TO_RADIANS;

	} else {

            xlbadinit(init);
        }
    }
    lib08_Vector_Normalize( axis );
    return   !just_radians;
}

LVAL xtfm24_Rotate( m_as_lval )
LVAL                m_as_lval;
/*-
    Build rotation matrix.
-*/
{
    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    geo_point    axis   ;
    double       radians;

    /* Process lisp args so we can C them. */
    xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 0 );

    /* Rotate: */
    xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm31_Rotate( &mat->m, &origin, &axis, radians );

    return m_as_lval;
}

LVAL xtfm25_Rotate_Msg()
/*-
    Build rotation matrix.
-*/
{
    return xtfm24_Rotate(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm27_Rotate_Pre_Msg--Build rotation matrix, pre-mult by it.    */

LVAL xtfm28_Rotate_Pre( m_as_lval )
LVAL			m_as_lval;
/*-
    Build rotation matrix, pre-multiply by it.
-*/
{
    ctfm_rec * m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    geo_point    axis   ;
    double       radians;

    /* Process lisp args so we can C them. */
    xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 0 );

    ctfm33_Rotate_Pre(&m->m, &origin, &axis, radians);

    return m_as_lval;
}

LVAL xtfm27_Rotate_Pre_Msg()
/*-
    Build rotation matrix, pre-multiply by it.
-*/
{
    return xtfm28_Rotate_Pre(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm30_Rotate_Post_Msg--Build rotation matrix, post-mult by it.  */

LVAL xtfm31_Rotate_Post( m_as_lval )
LVAL			 m_as_lval;
/*-
    Build rotation matrix, post-multiply by it.
-*/
{
    ctfm_rec * m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    geo_point    axis   ;
    double       radians;

    /* Process lisp args so we can C them. */
    xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 0 );

    ctfm34_Rotate_Post(&m->m, &origin, &axis, radians );

    return m_as_lval;
}

LVAL xtfm30_Rotate_Post_Msg()
/*-
    Build rotation matrix, post-multiply by it.
-*/
{
    return xtfm31_Rotate_Post(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm33_X_Rotate_Msg -- Build X-rotation matrix.			*/

geo_point xtfmx_axis = {1.0, 0.0, 0.0};
geo_point xtfmy_axis = {0.0, 1.0, 0.0};
geo_point xtfmz_axis = {0.0, 0.0, 1.0};
LVAL xtfm35_X_Rotate( m_as_lval, radians )
LVAL		      m_as_lval;
double		                 radians;
/*-
    Build X-rotation matrix.
-*/
{
    ctfm_rec * m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm07_X_Rotate(&m->m,radians);
    return m_as_lval;
}

LVAL xtfm34_X_Rotate( m_as_lval )
LVAL		      m_as_lval;
/*-
    Build X-rotation matrix.
-*/
{
    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    double       radians;
    geo_point    axis   ;axis = xtfmx_axis;

    /* Process lisp args so we can C them. */
    if (xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 1 )) {
	ctfm31_Rotate( &mat->m, &origin, &axis, radians );
    } else {
	xtfm35_X_Rotate(m_as_lval,radians);
    }
    return m_as_lval;
}

LVAL xtfm33_X_Rotate_Msg()
/*-
    Build X-rotation matrix.
-*/
{
    return xtfm34_X_Rotate(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm36_X_Rotate_Pre_Msg--Build X-rotation matrix, pre-mult by it.*/

LVAL xtfm38_X_Rotate_Pre( m_as_lval, radians )
LVAL			  m_as_lval;
double			  	     radians;
/*-
    Build X-rotation matrix, pre-multiply by it.
-*/
{
    ctfm_rec * m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm08_X_Rotate_Pre(&m->m,radians);
    return m_as_lval;
}

LVAL xtfm37_X_Rotate_Pre( m_as_lval )
LVAL			  m_as_lval;
/*-
    Build X-rotation matrix, pre-multiply by it.
-*/
{
    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    double       radians;
    geo_point    axis   ;axis = xtfmx_axis;

    /* Process lisp args so we can C them. */
    if (xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 1 )) {
        ctfm33_Rotate_Pre(&mat->m, &origin, &axis, radians);
    } else {
	xtfm38_X_Rotate_Pre(m_as_lval,radians);
    }
    return m_as_lval;
}

LVAL xtfm36_X_Rotate_Pre_Msg()
/*-
    Build X-rotation matrix, pre-multiply by it.
-*/
{
    return xtfm37_X_Rotate_Pre(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm39_X_Rotate_Post_Msg--Build X-rotation mat, post-mult by it.	*/

LVAL xtfm41_X_Rotate_Post( m_as_lval, radians )
LVAL			   m_as_lval;
double			   	      radians;
/*-
    Build X-rotation mat, post-multiply by it.
-*/
{
    ctfm_rec * m       =  xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm09_X_Rotate_Post(&m->m,radians);
    return m_as_lval;
}

LVAL xtfm40_X_Rotate_Post( m_as_lval )
LVAL			   m_as_lval;
/*-
    Build X-rotation mat, post-multiply by it.
-*/
{
    ctfm_rec* mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    double       radians;
    geo_point    axis   ;axis = xtfmx_axis;

    /* Process lisp args so we can C them. */
    if (xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 1 )) {
        ctfm34_Rotate_Post(&mat->m, &origin, &axis, radians );
    } else {
	xtfm41_X_Rotate_Post(m_as_lval,radians);
    }
    return m_as_lval;
}

LVAL xtfm39_X_Rotate_Post_Msg()
/*-
    Build X-rotation mat, post-multiply by it.
-*/
{
    return xtfm40_X_Rotate_Post(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm42_Y_Rotate_Msg -- Build Y-rotation matrix.		       	*/

LVAL xtfm44_Y_Rotate( m_as_lval, radians )
LVAL		      m_as_lval;
double		                 radians;
{   /* Build Y-rotation matrix. */
    ctfm_rec * m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm10_Y_Rotate(&m->m,radians);
    return m_as_lval;
}
LVAL xtfm43_Y_Rotate( m_as_lval )
LVAL		      m_as_lval;
{   /* Build Y-rotation matrix. */
    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    double       radians;
    geo_point    axis   ;axis = xtfmy_axis;

    /* Process lisp args so we can C them. */
    if (xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 1 )) {
	ctfm31_Rotate( &mat->m, &origin, &axis, radians );
    } else {
        xtfm44_Y_Rotate(m_as_lval,radians);
    }
    return m_as_lval;
}
LVAL xtfm42_Y_Rotate_Msg()
{   /* Build Y-rotation matrix. */
    return xtfm43_Y_Rotate(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm45_Y_Rotate_Pre_Msg--Build Y-rotation matrix, pre-mult by it.*/

LVAL xtfm47_Y_Rotate_Pre( m_as_lval, radians )
LVAL			  m_as_lval;
double			             radians;
{   /* Build Y-rotation matrix, pre-multiply by it. */
    ctfm_rec * m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm11_Y_Rotate_Pre(&m->m,radians);
    return m_as_lval;
}

LVAL xtfm46_Y_Rotate_Pre( m_as_lval )
LVAL			  m_as_lval;
/*-
    Build Y-rotation matrix, pre-multiply by it.
-*/
{
    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    double       radians;
    geo_point    axis   ;axis = xtfmy_axis;

    /* Process lisp args so we can C them. */
    if (xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 1 )) {
        ctfm33_Rotate_Pre(&mat->m, &origin, &axis, radians);
    } else {
	xtfm47_Y_Rotate_Pre(m_as_lval,radians);
    }
    return m_as_lval;
}

LVAL xtfm45_Y_Rotate_Pre_Msg()
/*-
    Build Y-rotation matrix, pre-multiply by it.
-*/
{
    return xtfm46_Y_Rotate_Pre(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm48_Y_Rotate_Post_Msg--Build Y-rotation mat, post-mult by it.	*/

LVAL xtfm50_Y_Rotate_Post( m_as_lval, radians )
LVAL			   m_as_lval;
double			   	      radians;
/*-
    Build Y-rotation mat, post-multiply by it.
-*/
{
    ctfm_rec* m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm12_Y_Rotate_Post(&m->m,radians);
    return m_as_lval;
}

LVAL xtfm49_Y_Rotate_Post( m_as_lval )
LVAL			   m_as_lval;
/*-
    Build Y-rotation mat, post-multiply by it.
-*/
{
    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    double       radians;
    geo_point    axis   ;axis = xtfmy_axis;

    /* Process lisp args so we can C them. */
    if (xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 1 )) {
        ctfm34_Rotate_Post(&mat->m, &origin, &axis, radians );
    } else {
	xtfm50_Y_Rotate_Post(m_as_lval,radians);
    }
    return m_as_lval;
}

LVAL xtfm48_Y_Rotate_Post_Msg()
/*-
    Build Y-rotation mat, post-multiply by it.
-*/
{
    return xtfm49_Y_Rotate_Post(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm51_Z_Rotate_Msg -- Build Z-rotation matrix.			*/

LVAL xtfm53_Z_Rotate( m_as_lval, radians )
LVAL		      m_as_lval;
double		      		 radians;
/*-
    Build Z-rotation matrix.
-*/
{
    ctfm_rec * m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm13_Z_Rotate(&m->m,radians);
    return m_as_lval;
}

LVAL xtfm52_Z_Rotate( m_as_lval )
LVAL		      m_as_lval;
/*-
    Build Z-rotation matrix.
-*/
{
    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    double       radians;
    geo_point    axis   ;axis = xtfmz_axis;

    /* Process lisp args so we can C them. */
    if (xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 1 )) {
	ctfm31_Rotate( &mat->m, &origin, &axis, radians );
    } else {
	xtfm53_Z_Rotate(m_as_lval,radians);
    }
xtfm9c_Find_Immediate_Base( m_as_lval );
    return m_as_lval;
}

LVAL xtfm51_Z_Rotate_Msg()
/*-
    Build Z-rotation matrix.
-*/
{
    return xtfm52_Z_Rotate(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm54_Z_Rotate_Pre_Msg--Build Z-rotation mat, pre-multiply by it*/

LVAL xtfm56_Z_Rotate_Pre( m_as_lval, radians )
LVAL			  m_as_lval;
double			             radians;
/*-
    Build Z-rotation mat, pre-multiply by it.
-*/
{
    ctfm_rec * m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm14_Z_Rotate_Pre(&m->m,radians);
    return m_as_lval;
}

LVAL xtfm55_Z_Rotate_Pre( m_as_lval )
LVAL			  m_as_lval;
/*-
    Build Z-rotation mat, pre-multiply by it.
-*/
{
    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    double       radians;
    geo_point    axis   ;axis = xtfmz_axis;

    /* Process lisp args so we can C them. */
    if (xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 1 )) {
        ctfm33_Rotate_Pre(&mat->m, &origin, &axis, radians);
    } else {
	xtfm56_Z_Rotate_Pre(m_as_lval,radians);
    }
    return m_as_lval;
}

LVAL xtfm54_Z_Rotate_Pre_Msg()
/*-
    Build Z-rotation mat, pre-multiply by it.
-*/
{
    return xtfm55_Z_Rotate_Pre(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm57_Z_Rotate_Post_Msg--Build Z-rotation mat, post-mult by it.	*/

LVAL xtfm59_Z_Rotate_Post( m_as_lval, radians )
LVAL			   m_as_lval;
double			              radians;
/*-
    Build Z-rotation mat, post-multiply by it.
-*/
{
    ctfm_rec * m       = xtfm9c_Find_Immediate_Base( m_as_lval );
    ctfm15_Z_Rotate_Post(&m->m,radians);
    return m_as_lval;
}

LVAL xtfm58_Z_Rotate_Post( m_as_lval )
LVAL			   m_as_lval;
/*-
    Build Z-rotation mat, post-multiply by it.
-*/
{
    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point    origin ;
    double       radians;
    geo_point    axis   ;axis = xtfmz_axis;

    /* Process lisp args so we can C them. */
    if (xtfm26_Rotate_Args( m_as_lval, &origin, &axis, &radians, 1 )) {
        ctfm34_Rotate_Post(&mat->m, &origin, &axis, radians );
    } else {
	xtfm59_Z_Rotate_Post(m_as_lval,radians);
    }
    return m_as_lval;
}

LVAL xtfm57_Z_Rotate_Post_Msg()
/*-
    Build Z-rotation mat, post-multiply by it.
-*/
{
    return xtfm58_Z_Rotate_Post(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm60_Scale_Msg -- Build XYZ-scaling matrix.			*/

xtfm62_Scale_Args( m_as_lval, origin, xyz_scale )
LVAL	           m_as_lval;
geo_point	             *origin,*xyz_scale;
{
    LVAL x_as_lval = xlgetarg();/* May be fix or flo. */
    LVAL y_as_lval = xlgetarg();/* May be fix or flo. */
    LVAL z_as_lval = xlgetarg();/* May be fix or flo. */
    static geo_point def_origin  = {0.0, 0.0, 0.0};

    *origin = def_origin;

    xyz_scale->x = xgbj00_Get_Fix_Or_Flo_Num(x_as_lval);
    xyz_scale->y = xgbj00_Get_Fix_Or_Flo_Num(y_as_lval);
    xyz_scale->z = xgbj00_Get_Fix_Or_Flo_Num(z_as_lval);

    while (moreargs()) {
        LVAL init = xlgasymbol();
	LVAL arg;
        if (init == k_origin) {

            /* Handle ":origin '(0.0 1.0 0.0)" */
            lib16_List_To_Point( origin, xlgalist() );

        } else if (init == k_xfmorigin) {

            /* Handle ":transformed-origin '(0.0 1.0 0.0)" */
	    ctfm_rec * mat = xtfm9c_Find_Immediate_Base( m_as_lval );
	    geo_point untransformed_origin;
            lib16_List_To_Point( &untransformed_origin, xlgalist() );
	    lib26_Matrix_Apply_To_Point( origin, &untransformed_origin, &mat->m );

	} else {

            xlbadinit(init);
        }
    }
}

LVAL xtfm61_Scale( m_as_lval )
LVAL		   m_as_lval;
/*-
    Build XYZ-scaling matrix.
-*/
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point origin, xyz_scale;
    xtfm62_Scale_Args( m_as_lval, &origin, &xyz_scale );
    ctfm16_Scale( &m->m, &origin, &xyz_scale );
    return m_as_lval;
}

LVAL xtfm60_Scale_Msg()
/*-
    Build XYZ-scaling matrix.
-*/
{
    return xtfm61_Scale(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm63_Scale_Pre_Msg--Build XYZ-scaling matrix,pre-multiply by it*/

LVAL xtfm64_Scale_Pre( m_as_lval )
LVAL		       m_as_lval;
/*-
    Build XYZ-scaling matrix, pre-multiply by it.
-*/
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point origin, xyz_scale;
    xtfm62_Scale_Args( m_as_lval, &origin, &xyz_scale );
    ctfm17_Scale_Pre( &m->m, &origin, &xyz_scale );
    return m_as_lval;
}

LVAL xtfm63_Scale_Pre_Msg()
/*-
    Build XYZ-scaling matrix, pre-multiply by it.
-*/
{
    return xtfm64_Scale_Pre(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm65_Scale_Post_Msg--Build XYZ-translation mat, post-mult by it*/

LVAL xtfm66_Scale_Post( m_as_lval )
LVAL			m_as_lval;
/*-
    Build XYZ-translation mat, post-multiply by it.
-*/
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point origin, xyz_scale;
    xtfm62_Scale_Args( m_as_lval, &origin, &xyz_scale );
    ctfm18_Scale_Post( &m->m,     &origin, &xyz_scale );
    return m_as_lval;
}

LVAL xtfm65_Scale_Post_Msg()
/*-
    Build XYZ-translation mat, post-multiply by it.
-*/
{
    return xtfm66_Scale_Post(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm67_Shear_Msg -- Build shear matrix.				*/

LVAL xtfm69_Shear( m_as_lval, v10,v20,v01,v21,v02,v12 )
LVAL		   m_as_lval, v10,v20,v01,v21,v02,v12;
/*-
    Build shear matrix.
-*/
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    double s10  = xgbj00_Get_Fix_Or_Flo_Num(v10);
    double s20  = xgbj00_Get_Fix_Or_Flo_Num(v20);
    double s01  = xgbj00_Get_Fix_Or_Flo_Num(v01);
    double s21  = xgbj00_Get_Fix_Or_Flo_Num(v21);
    double s02  = xgbj00_Get_Fix_Or_Flo_Num(v02);
    double s12  = xgbj00_Get_Fix_Or_Flo_Num(v12);
    ctfm19_Shear(&m->m,s10,s20,s01,s21,s02,s12);
    return m_as_lval;
}

LVAL xtfm68_Shear( m_as_lval )
LVAL		   m_as_lval;
/*-
    Build shear matrix.
-*/
{
    LVAL v10 = xlgetarg();/* May be fix or flo. */
    LVAL v20 = xlgetarg();/* May be fix or flo. */
    LVAL v01 = xlgetarg();/* May be fix or flo. */
    LVAL v21 = xlgetarg();/* May be fix or flo. */
    LVAL v02 = xlgetarg();/* May be fix or flo. */
    LVAL v12 = xlgetarg();/* May be fix or flo. */
    xllastarg();
    return xtfm69_Shear(m_as_lval,v10,v20,v01,v21,v02,v12);
}

LVAL xtfm67_Shear_Msg()
/*-
    Build shear matrix.
-*/
{
    return xtfm68_Shear(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfm70_Shear_Pre_Msg -- Build shear matrix, pre-multiply by it.	*/

LVAL xtfm71_Shear_Pre( m_as_lval, v10,v20,v01,v21,v02,v12 )
LVAL		       m_as_lval, v10,v20,v01,v21,v02,v12;
/*-
    Build shear matrix, pre-multiply by it.
-*/
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    double s10  = xgbj00_Get_Fix_Or_Flo_Num(v10);
    double s20  = xgbj00_Get_Fix_Or_Flo_Num(v20);
    double s01  = xgbj00_Get_Fix_Or_Flo_Num(v01);
    double s21  = xgbj00_Get_Fix_Or_Flo_Num(v21);
    double s02  = xgbj00_Get_Fix_Or_Flo_Num(v02);
    double s12  = xgbj00_Get_Fix_Or_Flo_Num(v12);
    ctfm20_Shear_Pre(&m->m,s10,s20,s01,s21,s02,s12);
    return m_as_lval;
}

LVAL xtfm70_Shear_Pre_Msg()
/*-
    Build shear matrix, pre-multiply by it.
-*/
{
    LVAL m_as_lval = xtfm01_Get_A_XTFM();
    LVAL v10 = xlgetarg();/* May be fix or flo. */
    LVAL v20 = xlgetarg();/* May be fix or flo. */
    LVAL v01 = xlgetarg();/* May be fix or flo. */
    LVAL v21 = xlgetarg();/* May be fix or flo. */
    LVAL v02 = xlgetarg();/* May be fix or flo. */
    LVAL v12 = xlgetarg();/* May be fix or flo. */
    xllastarg();
    return xtfm71_Shear_Pre(m_as_lval,v10,v20,v01,v21,v02,v12);
}

/* }}} */
/* {{{ xtfm72_Shear_Post_Msg--Build shear matrix, post-multiply by it.	*/

LVAL xtfm73_Shear_Post( m_as_lval, v10,v20,v01,v21,v02,v12 )
LVAL			m_as_lval, v10,v20,v01,v21,v02,v12;
/*-
    Build shear matrix, post-multiply by it.
-*/
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    double s10  = xgbj00_Get_Fix_Or_Flo_Num(v10);
    double s20  = xgbj00_Get_Fix_Or_Flo_Num(v20);
    double s01  = xgbj00_Get_Fix_Or_Flo_Num(v01);
    double s21  = xgbj00_Get_Fix_Or_Flo_Num(v21);
    double s02  = xgbj00_Get_Fix_Or_Flo_Num(v02);
    double s12  = xgbj00_Get_Fix_Or_Flo_Num(v12);
    ctfm21_Shear_Post(&m->m,s10,s20,s01,s21,s02,s12);
    return m_as_lval;
}

LVAL xtfm72_Shear_Post_Msg()
/*-
    Build shear matrix, post-multiply by it.
-*/
{
    LVAL m_as_lval = xtfm01_Get_A_XTFM();
    LVAL v10 = xlgetarg();/* May be fix or flo. */
    LVAL v20 = xlgetarg();/* May be fix or flo. */
    LVAL v01 = xlgetarg();/* May be fix or flo. */
    LVAL v21 = xlgetarg();/* May be fix or flo. */
    LVAL v02 = xlgetarg();/* May be fix or flo. */
    LVAL v12 = xlgetarg();/* May be fix or flo. */
    xllastarg();
    return xtfm73_Shear_Post(m_as_lval,v10,v20,v01,v21,v02,v12);
}

/* }}} */
/* {{{ xtfm74_Transform_Point--Apply matrix to a point and return result*/

LVAL xtfm74_Transform_Point( m_as_lval )
LVAL			     m_as_lval;
{
    LVAL lib14_Point_To_List();
    geo_point pt_in;
    geo_point pt_out;
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    lib16_List_To_Point( &pt_in, xlgalist() );
    xllastarg();
    lib26_Matrix_Apply_To_Point( &pt_out, &pt_in, &m->m );
    return lib14_Point_To_List( &pt_out );
}

LVAL xtfm75_Transform_Point_Msg()
/*-
    Apply matrix to a point and return result.
-*/
{
    return xtfm74_Transform_Point( xtfm01_Get_A_XTFM() );
}

/* }}} */
/* {{{ xtfm76_Transform_Normal--Apply matrix to a normal & return result*/

LVAL xtfm76_Transform_Normal( m_as_lval )
LVAL			      m_as_lval;
{
    /* This is buggy, we should be using the inverse transpose  */
    /* of the matrix...						*/
    geo_point pt_in0;
    geo_point pt_in1;
    geo_point pt_out0;
    geo_point pt_out1;
    geo_point pt_out;
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    lib16_List_To_Point( &pt_in1, xlgalist() );
    xllastarg();
    lib13_Vector_Zero(   &pt_in0 );
    lib26_Matrix_Apply_To_Point( &pt_out0, &pt_in0 , &m->m );
    lib26_Matrix_Apply_To_Point( &pt_out1, &pt_in1 , &m->m );
    lib11_Vector_Subtract(       &pt_out , &pt_out1, &pt_out0 );
    lib08_Vector_Normalize(      &pt_out );
    return lib14_Point_To_List(  &pt_out );
}

LVAL xtfm77_Transform_Normal_Msg()
/*-
    Apply matrix to a normal and return result.
-*/
{
    return xtfm76_Transform_Normal( xtfm01_Get_A_XTFM() );
}

/* }}} */
/* {{{ xtfm78_Invert_Matrix						*/

LVAL xtfm78_Invert_Matrix( lv_m )
LVAL		           lv_m;
{   ctfm_rec * m = xtfm9c_Find_Immediate_Base( lv_m );
    ctfm45_Invert_Matrix( &m->m );
    return lv_m;
}
LVAL xtfm79_Invert_Msg()
{
    return xtfm78_Invert_Matrix( xtfm01_Get_A_XTFM() );
}

/* }}} */
/* {{{ xtfm80_Transpose_Matrix						*/

LVAL xtfm80_Transpose_Matrix( lv_m )
LVAL		              lv_m;
{
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( lv_m );
    ctfm47_Transpose_Matrix( &m->m );
    return lv_m;
}
LVAL xtfm81_Transpose_Msg()
{   /* Transpose matrix. */
    return xtfm80_Transpose_Matrix( xtfm01_Get_A_XTFM() );
}

/* }}} */
/* {{{ xtfm86_Get_Msg -- Get keyword properties.                        */

/* Number of specially interpreted properties for this class.    */
/* If you hack 85_Get, update XTFM_PROPS and xtfme4_ProplistNth. */
#define XTFM_PROPS (13)

LVAL xtfm85_Get( t_as_lval )
LVAL             t_as_lval;
{
    ctfm_rec* viewing_mat = xtfm9c_Find_Immediate_Base( t_as_lval );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if (key == k_transform) {

	result = t_as_lval;

    } else if (key == k_location) {

	/* Fetch camera location: */
	result = lib14_Point_To_List( &viewing_mat->location );

    } else if (key == k_target) {

	/* Fetch target point: */
        result = lib14_Point_To_List( &viewing_mat->target );

    } else if (key == k_up) {

	/* Fetch 'up' point:" */
        result = lib14_Point_To_List( &viewing_mat->up );

    } else if (key == k_radians) {

	/* Fetch angle: */
	result = cvflonum( viewing_mat->angle_of_view_in_radians );

    } else if (key == k_degrees) {

	/* Fetch angle: */
	result = cvflonum(viewing_mat->angle_of_view_in_radians*RADIANS_TO_DEGREES);

    } else if (key == k_diameter) {

	/* Fetch diameter: */
	result = cvflonum( viewing_mat->diameter );

    } else if (key == k_left) {

	result = cvflonum( viewing_mat->left );

    } else if (key == k_right) {

	result = cvflonum( viewing_mat->roit );

    } else if (key == k_top) {

	result = cvflonum( viewing_mat->top );

    } else if (key == k_bottom) {

	result = cvflonum( viewing_mat->bot );

    } else if (key == k_near) {

	result = cvflonum( viewing_mat->near );

    } else if (key == k_near) {

	result = cvflonum( viewing_mat->far );

    } else {

	/* If this isn't a property we know, do a generic get property: */
        result = xthl8a_GetObjectProp( t_as_lval, key, default_val, got_default );
    }
    return result;
}

LVAL xtfm86_Get_Msg()
/*-
    Return keyword properties for a camera object.
-*/
{
    return xtfm85_Get( xtfm01_Get_A_XTFM() );
}

/* }}} */
/* {{{ xtfm89_Set_Msg -- Write keyword properties.                      */

LVAL xtfm88_Set( lv_tfm, r )
LVAL             lv_tfm;
struct ctfm_Put_Rec	   *r;
{
    ctfm_rec* transform = xtfm9c_Find_Immediate_Base( lv_tfm );

    ctfm70_Initialize_Put_Rec( r );

    while (moreargs()) {
        LVAL lv_init = xlgasymbol();
	LVAL arg;

        if (lv_init == k_location) {

            /* Handle ":location '(1 1 1)" */
            lib16_List_To_Point( &r->location, arg=xlgalist() );
	    r->location_is_valid = TRUE;

        } else if (lv_init == k_transform) {

	    xlfail("May not set :TRANSFORM property of a tfm!");

        } else if (lv_init == k_target) {

            /* Handle ":target '(1 1 1)" */
            lib16_List_To_Point( &r->target, xlgalist() );
	    r->target_is_valid = TRUE;

        } else if (lv_init == k_up) {

            /* Handle ":up '(0 1 1)" */
            lib16_List_To_Point( &r->up, xlgalist() );
	    r->up_is_valid = TRUE;

        } else if (lv_init == k_radians) {

            /* Handle ":radians 1.1" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp >= 3.14159)   xlfail("silly view angle");

	    r->angle_of_view_in_radians = tmp;
	    r->angle_is_valid		= TRUE;

        } else if (lv_init == k_degrees) {

            /* Handle ":radians 1.1" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() ) * DEGREES_TO_RADIANS;
	    if (tmp < 0.0 || tmp >= 3.14159)   xlfail("silly view angle");

	    r->angle_of_view_in_radians = tmp;
	    r->angle_is_valid		= TRUE;

        } else if (lv_init == k_diameter) {

            /* Handle ":diameter 12" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp <= 0.0)   xlfail("nonpositive diameter");

	    r->diameter			= tmp;
	    r->diameter_is_valid	= TRUE;

        } else if (lv_init == k_left) {

	    r->left		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->left_is_valid	= TRUE;

        } else if (lv_init == k_right) {

	    r->roit		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->roit_is_valid	= TRUE;

        } else if (lv_init == k_top) {

	    r->top		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->top_is_valid	= TRUE;

        } else if (lv_init == k_bottom) {

	    r->bot		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->bot_is_valid	= TRUE;

        } else if (lv_init == k_near) {

	    r->near		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->near_is_valid	= TRUE;

        } else if (lv_init == k_far) {

	    r->far		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->far_is_valid	= TRUE;

	} else {

            /* If this isn't a property we know, do a generic set property: */
            x03d9b_SetObjectProp( lv_tfm, lv_init, xlgetarg() );
        }
    }

    return lv_tfm;
}

LVAL xtfm89_Set_Msg()
/*-
    Read keyword properties for a transform object.
-*/
{
    struct ctfm_Put_Rec r;
    LVAL   t_as_lval = xtfm01_Get_A_XTFM();
    LVAL   result    = xtfm88_Set( t_as_lval, &r );
    xtfmc2_Update_State(	   t_as_lval, &r );
    return result;
}

/* }}} */
/* {{{ xtfm94_Frame_Things_Msg -- Find a frame containing things.	*/

xtfm92_Bounding_Box( m_as_lval, thing_list, min, max ) /* Called from xcmr.c */
LVAL                 m_as_lval, thing_list;
geo_point                                  *min,*max;
{   ctfm_rec* viewing_mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    viewing_mat->want_to_recompute_matrix = FALSE;

    min->x = GEO_FLOAT_MAX;
    min->y = GEO_FLOAT_MAX;
    min->z = GEO_FLOAT_MAX;

    max->x = GEO_FLOAT_MIN;
    max->y = GEO_FLOAT_MIN;
    max->z = GEO_FLOAT_MIN;

    xtfmb2_Compute_Bounding_Box( m_as_lval, thing_list, min, max );
}
LVAL xtfm93_Frame_Things( lv_xtfm, lv_thinglist, tight_fit, wide_high )
LVAL			  lv_xtfm, lv_thinglist;
int						 tight_fit;	
float							    wide_high;
{
    ctfm_rec* viewing_mat = xtfm9c_Find_Immediate_Base( lv_xtfm );

    /* Compute bounding box and save in C min,max structs: */

    geo_point min, max, mid, mov;

    xtfm92_Bounding_Box( lv_xtfm, lv_thinglist, &min, &max );


    /* Find an average point (i.e., center of box): */
    lib12_Vector_Sum(   &mid, &min, &max );
    lib10_Vector_Scale( &mid, 0.5        );


    /* Figure difference between current target and midbox, */
    /* apply to both camera target and camera position:     */
    lib11_Vector_Subtract(   &mov,              &mid,   &viewing_mat->target );
    lib12_Vector_Sum(        &viewing_mat->target,  &viewing_mat->target,   &mov     );
    lib12_Vector_Sum(        &viewing_mat->location,&viewing_mat->location, &mov     );

    /* Slide camera along line until thing (reasonably) fills field of view: */
    {
        /* Take distance between mid and min as radius of */
        /* sphere we're centering in the field of view.  */
	float radius;
	float needed_distance_from_target;
	float actual_distance_from_target;
        geo_point camera_to_target;

	if (!tight_fit) {

	    /* This is the normal fit designed so that the framed */
	    /* thing can be freely rotated without leaving the   */
	    /* clipping volume:					  */
	    radius = lib01_Vector_Distance( &mid, &min );

	} else {

	    /* This fit is designed to make widgets (or whatever) */
	    /* as nearly as possible fill the entire viewport:	  */
	    float h_radius = mid.y - min.y;
	    float w_radius = mid.x - min.x;
	    float w_h      = h_radius != 0.0 ? w_radius/h_radius : 1.0;
	    radius	   = h_radius;

	    /* Um, I don't understand this correction. */
	    /* And I wrote it!  :(.  Rethink sometime: */
            /* Later (92Oct21): sure screws up titlebars. Commented out. */
            /* if (w_h > wide_high)   radius  *= w_h * 0.5; */

	    /* Cheap insurance: */
	    if (radius == 0.0) {
		radius = lib01_Vector_Distance( &mid, &min );
	    }
	}

        /* Remember so we can set clipping planes reasonably: */
        viewing_mat->diameter = radius * 2;

	if (viewing_mat->angle_of_view_in_radians != 0.0) {
	    needed_distance_from_target = (
		radius   /   sin( viewing_mat->angle_of_view_in_radians * 0.5 )
	    );
	} else {
	    /* Orthographic projection:  Distance doesn't */
	    /* matter as long as it's great enough to     */
	    /* avoid clipping the object:                 */
	    needed_distance_from_target = radius * 4;
	}

	for (;;) {
	    actual_distance_from_target = lib01_Vector_Distance(
		&mid, &viewing_mat->location
	    );

	    /* Avoid special case and division by zero: */
	    if (actual_distance_from_target != 0.0)   break;
	    viewing_mat->location.z -= 1000.0;
	}
	
	/* Compute current offset between camera and target: */
        lib11_Vector_Subtract(
            &camera_to_target,
            &viewing_mat->location,
            &viewing_mat->target
        );

	/* Compute required offset between camera and target: */
        lib10_Vector_Scale(
            &camera_to_target,
	    needed_distance_from_target / actual_distance_from_target
        );

	/* Set camera location to target + required offset: */
        lib12_Vector_Sum(
            &viewing_mat->location,
            &viewing_mat->target,
            &camera_to_target
        );

	/* Offset camera 'up' by same amount.	*/
	/* This keeps the camera from flipping	*/
	/* over if the required offset happens	*/
	/* to be larger than the old distance	*/
	/* between 'loc' and 'up' -- which is	*/
	/* disconcerting when it happens!	*/
	/*					*/
	/* It will also be a bit disconcerting	*/
	/* to the user to find 'up' changing	*/
	/* mysteriously, but probably less so.	*/
	/*					*/
	/* Lesson for the future is probably to */
	/* make 'up' and 'target' be direction  */
	/* vectors rather than points, if we	*/
	/* ever redesign.			*/
        lib12_Vector_Sum(
            &viewing_mat->up,
            &viewing_mat->up,
            &camera_to_target
        );
    }

    viewing_mat->want_to_recompute_matrix = TRUE;
    xtfm9a_Update_Transform(
	lv_xtfm,
       &viewing_mat->location,
       &viewing_mat->target,
       &viewing_mat->up
    );

    return lv_xtfm;
}

LVAL xtfm94_Frame_Things_Msg()
{
    LVAL lv_xtfm = xtfm01_Get_A_XTFM();
    return x03d44_Frame_Things( lv_xtfm, lv_xtfm, 1.0 );
}

/* }}} */
/* {{{ xtfm9a_Update_Transform						*/

xtfm9a_Update_Transform( m_as_lval, location, target, up )
LVAL            	 m_as_lval;
geo_point			   *location,*target,*up;
{
    ctfm_rec*viewing_mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    if (viewing_mat->want_to_recompute_matrix) {
        viewing_mat->want_to_recompute_matrix = FALSE;
        ctfm28_View( &viewing_mat->m, location, target, up );
    }
}

/* }}} */
/* {{{ xtfm9b_Find_Matrix						*/

geo_matrix* xtfm9b_Find_Matrix( m_as_lval )
LVAL				m_as_lval;
{
    ctfm_rec*viewing_mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    return &viewing_mat->m;
}

/* }}} */
/* {{{ xtfm9c_Find_Immediate_Base					*/

ctfm_rec* xtfm9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int csux  = xtfm9d_Maybe_Run_PerframeHooks( lv );
    ctfm_rec*viewing_mat = (ctfm_rec*) gobjimmbase( lv );
/*printf("xtfm9c_Find_Immediate_Base: lv %x -gobjimmbase-> %x\n",lv,viewing_mat);*/

    /* If user has modified our high-level specs, may */
    /* be time to recompute matrix from them:         */
    if (viewing_mat->want_to_recompute_matrix) {
        viewing_mat->want_to_recompute_matrix = FALSE;
        ctfm28_View(
	    &viewing_mat->m,
	    &viewing_mat->location,
	    &viewing_mat->target,
	    &viewing_mat->up
	);
    }
    return viewing_mat;
}

/* }}} */
/* {{{ xtfm9d_Maybe_Run_PerframeHooks					*/

xtfm9d_Maybe_Run_PerframeHooks( lv )
LVAL				lv;
{   extern xcmr05_Frame_Number;
    ctfm_rec*viewing_mat = (ctfm_rec*) gobjimmbase( lv );

    /* If user has supplied code to compute value */
    /* of matrix, it may be time to call it:      */
/*printf("xtfm9d_Maybe_Run_PerframeHooks: lv %x viewing_mat %x\n",lv,viewing_mat);*/
/*printf("  viewing_mat->fileInfo.may_have_hooks d=%d\n",viewing_mat->fileInfo.may_have_hooks);*/
/*printf("  viewing_mat->fileInfo.last_hooks d=%d\n",viewing_mat->fileInfo.last_hooks);*/
    if (viewing_mat->fileInfo.may_have_hooks &&
	viewing_mat->fileInfo.last_hooks != xcmr05_Frame_Number
    ) {
        LVAL lv_hooks = xthl8a_GetObjectProp( lv, k_perframehook, NIL,TRUE );
	if (null(lv_hooks)) {
/*printf("xtfm9d_Maybe_Run_PerframeHooks: No hooks actually found!\n");*/
	    viewing_mat->fileInfo.may_have_hooks = FALSE;
	} else {
	    viewing_mat->fileInfo.last_hooks  = xcmr05_Frame_Number;
/*printf("xtfm9d_Maybe_Run_PerframeHooks: running HookFns.\n");*/
            xthlF5_Call_HookFns( lv_hooks );
    }   }
    return 0;
}

/* }}} */
/* {{{ xtfma0_Compute_Location		of camera			*/

xtfma0_Compute_Location( loc, m_as_lval ) /* ALSO CALLED from xcmr.c */
geo_point		*loc;
LVAL			      m_as_lval;
/*-
    Compute location of camera.
-*/
{
    ctfm_rec* viewing_mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    *loc = viewing_mat->location;
}

/* }}} */
/* {{{ xtfma1_Compute_Axis			of camera		*/

#ifdef UNUSED_YET
xtfma1_Compute_Axis( loc, m_as_lval )
geo_point	    *loc;
LVAL			  m_as_lval;
/*-
    Compute axis of camera.
-*/
{
    ctfm_rec* viewing_mat = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point zero; lib13_Vector_Zero( &zero );
    zero.z = 1.0;
    lib27_Matrix_Apply_To_Normal( loc, &zero,  &viewing_mat->m );
}
#endif

/* }}} */
/* {{{ xtfmb2_Compute_Bounding_Box		of a given thing-list	*/

struct xtfmb2_rec {
    geo_point *min,*max;
};
xtfmb2_Compute_Bounding_Box( m_as_lval, things, min, max )
LVAL			     m_as_lval;
LVAL				        things;
geo_point				       *min,*max;
/*-
    Compute bounding box of an thing list.
-*/
{
    gt_tri_rec r;
    ctfm_rec   viewing_mat_inv;
    struct xtfmb2_rec minmax;
    int xtfmb3_Compute_Bounding_Box_PerObj();
    minmax.min = min;
    minmax.max = max;
    xthlC2_Init_Tri_Rec(
	&r,
	/*view*/ m_as_lval,
	/*proj*/ m_as_lval, /* Perspective matrix doesn't matter on this call. */
	&viewing_mat_inv
    );
    r.default_r = TRUE;
    xthlB0_Process_Thing_List(
	things,  /* Things		*/
	&r,
	xtfmb3_Compute_Bounding_Box_PerObj, &minmax
    );
}

#undef  MAX_BUF
#define MAX_BUF (100)
xtfmb3_Compute_Bounding_Box_PerObj( minmax, r )
struct xtfmb2_rec                  *minmax;
gt_tri_rec			           *r;
{
    /* If no modelling matrix supplied, plug in a null one: */
    int xtfmb4_Compute_Bounding_Box_PerBuf();
    geo_matrix mat;
    gt_mat* old_model = r->model;
    geo_point  buf[ MAX_BUF ];
    if (r->model == NULL) {
	r->model = (gt_mat*) &mat;
	ctfm00_Identity( &mat );
    }

    if (!r->got_points)   xlfail("compute-bounding-box needs :POINT-X/Y/Z");
    lib20_Study_Transformed_Points(
	r->x, r->y, r->z, r->pLen,
	r->model,
	xtfmb4_Compute_Bounding_Box_PerBuf, minmax,
	buf, MAX_BUF
    );
    r->model = old_model;  /* Not needed yet. Bug prophylaxis. */
    return TRUE;
}
#undef  MAX_BUF

xtfmb4_Compute_Bounding_Box_PerBuf( minmax, point_buf, point_count )
struct xtfmb2_rec                  *minmax;
geo_point			           *point_buf;
int						       point_count;
{
    register i = point_count;
    register geo_point* p = point_buf;

    /* A few register vars would speed this up... but it */
    /* shouldn't be a bottleneck, so:			 */
    while (i --> 0) {

	if (minmax->min->x > p->x)   minmax->min->x = p->x;
	if (minmax->min->y > p->y)   minmax->min->y = p->y;
	if (minmax->min->z > p->z)   minmax->min->z = p->z;

	if (minmax->max->x < p->x)   minmax->max->x = p->x;
	if (minmax->max->y < p->y)   minmax->max->y = p->y;
	if (minmax->max->z < p->z)   minmax->max->z = p->z;

	++p;
    }
    return TRUE;
}

/* }}} */
/* {{{ xtfmc2_Update_State -- Apply Put_Rec to our state.		*/

xtfmc0_Update_Transform_Viewing( lv_t )
LVAL            		 lv_t;
{
    ctfm_rec*viewing_mat= xtfm9c_Find_Immediate_Base( lv_t );
    /* The above call is sufficient to trigger the recomputation :) */
}

xtfmc1_Update_Transform( lv_t )
LVAL            	 lv_t;
/*-
    Recompute our matrices from scratch according to our high-level fields.
-*/
{
    xtfmc0_Update_Transform_Viewing( lv_t );
}

xtfmc2_Update_State( lv_t, r )
LVAL		     lv_t;
struct ctfm_Put_Rec	  *r;
/*-
    Apply Put_Rec to our state.
-*/
{
    ctfm_rec*viewing_mat = xtfm9c_Find_Immediate_Base( lv_t );

    /* This basically ugly hack is needed because is_new has to parse  */
    /* its arguments before it can send the messages needed to create  */
    /* our viewing and projection matrices, hence _Put cannot assume */
    /* said matrices exist, and must passively stuff things into rec.  */
    if (r->location_is_valid) {
	viewing_mat->location = r->location;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }

    if (r->angle_is_valid) {
	viewing_mat->angle_of_view_in_radians = r->angle_of_view_in_radians;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }

    if (r->diameter_is_valid) {
	viewing_mat->diameter = r->diameter;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }

    if (r->target_is_valid) {
        viewing_mat->target   = r->target;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }

    if (r->up_is_valid) {
	viewing_mat->up       = r->up;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }

    if (r->left_is_valid) {
	viewing_mat->left      = r->left;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }
    if (r->roit_is_valid) {
	viewing_mat->roit      = r->roit;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }
    if (r->top_is_valid) {
	viewing_mat->top       = r->top;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }
    if (r->bot_is_valid) {
	viewing_mat->bot       = r->bot;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }
    if (r->near_is_valid) {
	viewing_mat->near      = r->near;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }
    if (r->far_is_valid) {
	viewing_mat->far       = r->far;
	viewing_mat->want_to_recompute_matrix = TRUE;
    }

    xtfmc1_Update_Transform( lv_t );
}

/* }}} */
/* {{{ xtfmc5_Want_To_Recompute_State -- Set dirty flag in record.	*/

xtfmc5_Want_To_Recompute_State( lv_t ) /* Called from xcmr.c etc. */
LVAL            	        lv_t;
/*-
    Set want_to_recompute_matrix = TRUE;
-*/
{
    ctfm_rec*viewing_mat= xtfm9c_Find_Immediate_Base( lv_t );
    viewing_mat->want_to_recompute_matrix = TRUE;
}

/* }}} */
/* {{{ xtfmd1_Turtle_Forward_Msg -- Move in local coordinate system.    */

LVAL xtfmd0_Turtle_Forward( lv_m )
LVAL		            lv_m;
{
    float dist = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( lv_m );
    geo_point direction;
    xllastarg();
    lib11_Vector_Subtract(  &direction, &m->target, &m->location );
    lib08_Vector_Normalize( &direction );
    lib10_Vector_Scale(     &direction, dist );
    lib12_Vector_Sum(       &m->target,   &m->target,   &direction );
    lib12_Vector_Sum(       &m->location, &m->location, &direction );
    m->want_to_recompute_matrix = TRUE;
    return lv_m;
}

LVAL xtfmd1_Turtle_Forward_Msg()
/*-
    Move in local coordinate system.
-*/
{
    return xtfmd0_Turtle_Forward(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfmd2_Turtle_Rot_Msg -- Rotate in local coordinate system.	*/

LVAL xtfmd2_Turtle_Rot( m_as_lval, rot_fn )
LVAL		        m_as_lval;
int				 (*rot_fn)(); /* ctfm07_X_Rotate() etc. */
{
    ctfm_rec * m  = xtfm9c_Find_Immediate_Base( m_as_lval );
    double           xtfmd5_Turtle_Angle();
    double radians = xtfmd5_Turtle_Angle();
    geo_matrix inv;
    geo_matrix rot;
    geo_point  target;
    geo_point  up;

    /* Figure matrix based on current location, target, twist: */
    m->want_to_recompute_matrix = TRUE;
    xtfmc1_Update_Transform( m_as_lval );

    /* Figure inverse of matrix based on current location, target, up: */
    ctfm44_Invert_Matrix( &inv, &m->m );

    /* Transform target, up into turtlespace via inverse transform: */
    lib26_Matrix_Apply_To_Point( &target, &m->target, &inv );
    lib26_Matrix_Apply_To_Point( &up    , &m->up    , &inv );

    /* Apply desired roll/pitch/yaw transform to target, up: */
    rot_fn( &rot, radians );
    lib26_Matrix_Apply_To_Point( &target, &target, &rot );
    lib26_Matrix_Apply_To_Point( &up    , &up    , &rot );

    /* Transform target, up back to original space: */
    lib26_Matrix_Apply_To_Point( &m->target, &target, &m->m );
    lib26_Matrix_Apply_To_Point( &m->up    , &up    , &m->m );

    m->want_to_recompute_matrix = TRUE;

    return m_as_lval;
}

/* }}} */
/* {{{ xtfmd4_Turtle_Pitch_Msg--Pitch-rotate in local coordinate system.*/

double xtfmd5_Turtle_Angle()
{
    LVAL key = xlgasymbol();
    double  r = 0.0;
    if        (key == k_radians) {
	r = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    } else if (key == k_degrees) {
	r = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() ) * DEGREES_TO_RADIANS;
    } else {
	xlerror("Need :DEGREES or :RADIANS",key);
    }
    xllastarg();
    return r;
}

LVAL xtfmd3_Turtle_Pitch( m_as_lval )
LVAL		          m_as_lval;
{
    int ctfm07_X_Rotate();
    return xtfmd2_Turtle_Rot( m_as_lval, ctfm07_X_Rotate );
}

LVAL xtfmd4_Turtle_Pitch_Msg()
/*-
    Pitch-rotate in local coordinate system.
-*/
{
    return xtfmd3_Turtle_Pitch(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfmd7_Turtle_Roll_Msg -- Roll-rotate in local coordinate system */

LVAL xtfmd6_Turtle_Roll( m_as_lval )
LVAL		         m_as_lval;
{
    int ctfm13_Z_Rotate();
    return xtfmd2_Turtle_Rot( m_as_lval, ctfm13_Z_Rotate );
}

LVAL xtfmd7_Turtle_Roll_Msg()
/*-
    Roll-rotate in local coordinate system.
-*/
{
    return xtfmd6_Turtle_Roll(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfmd9_Turtle_Yaw_Msg -- Yaw-rotate in local coordinate system.  */

LVAL xtfmd8_Turtle_Yaw( m_as_lval )
LVAL		        m_as_lval;
{
    int ctfm10_Y_Rotate();
    return xtfmd2_Turtle_Rot( m_as_lval, ctfm10_Y_Rotate );
}

LVAL xtfmd9_Turtle_Yaw_Msg()
/*-
    Yaw-rotate in local coordinate system.
-*/
{
    return xtfmd8_Turtle_Yaw(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfmdb_Turtle_Right_Msg -- Move in local coordinate system.      */

LVAL xtfmda_Turtle_Right( m_as_lval )
LVAL		          m_as_lval;
{
    float dist = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point target_direction;
    geo_point upward_direction;
    geo_point toRoit_direction;
    xllastarg();

    /* We take cross-product of 'forward' and 'up' to get 'right'.    */
    /* 'Up' isn't perpendicular to 'forward', in general, but luckily */
    /* Cross-product doesn't care ...                                 */
    lib11_Vector_Subtract(  &target_direction, &m->target, &m->location );
    lib11_Vector_Subtract(  &upward_direction, &m->up,     &m->location );
    lib08_Vector_Normalize( &target_direction );
    lib08_Vector_Normalize( &upward_direction );
    lib00_Vector_Cross_Product(
	&toRoit_direction,
	&upward_direction,
	&target_direction
    );
    lib10_Vector_Scale( &toRoit_direction, dist );
    lib12_Vector_Sum(       &m->target,   &m->target,   &toRoit_direction );
    lib12_Vector_Sum(       &m->location, &m->location, &toRoit_direction );
    m->want_to_recompute_matrix = TRUE;
    return m_as_lval;
}

LVAL xtfmdb_Turtle_Right_Msg()
/*-
    Move in local coordinate system.
-*/
{
    return xtfmda_Turtle_Right(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfmdd_Turtle_Up_Msg -- Move in local coordinate system.         */

LVAL xtfmdc_Turtle_Up( m_as_lval )
LVAL		       m_as_lval;
{
    float dist = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
    ctfm_rec * m = xtfm9c_Find_Immediate_Base( m_as_lval );
    geo_point target_direction;
    geo_point upward_direction;
    geo_point toRoit_direction;
    geo_point trueUp_direction;
    xllastarg();

    /* 'Up' isn't perpendicular to 'forward', in general, so we first */
    /* find their right-ward mutual perpendicular, then we find the   */
    /* upward mutual perpendicular to 'right' and 'forward':          */
    lib11_Vector_Subtract(  &target_direction, &m->target, &m->location );
    lib11_Vector_Subtract(  &upward_direction, &m->up,     &m->location );
    lib08_Vector_Normalize( &target_direction );
    lib08_Vector_Normalize( &upward_direction );
    lib00_Vector_Cross_Product(
	&toRoit_direction,
	&upward_direction,
	&target_direction
    );
    lib00_Vector_Cross_Product(
	&trueUp_direction,
	&target_direction,
	&toRoit_direction
    );
    lib10_Vector_Scale( &trueUp_direction, dist );
    lib12_Vector_Sum(       &m->target,   &m->target,   &trueUp_direction );
    lib12_Vector_Sum(       &m->location, &m->location, &trueUp_direction );
    m->want_to_recompute_matrix = TRUE;
    return m_as_lval;
}

LVAL xtfmdd_Turtle_Up_Msg()
/*-
    Move in local coordinate system.
-*/
{
    return xtfmdc_Turtle_Up(xtfm01_Get_A_XTFM());
}

/* }}} */
/* {{{ xtfme1_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xtfme0_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XTFM_PROPS + x03d89_PropListLength( *pPropList ) );
}

LVAL xtfme1_ProplistLength_Msg()
/*-
    Return length of propertylist.
-*/
{
    return xtfme0_ProplistLength( xtfm01_Get_A_XTFM() );
}

/* }}} */
/* {{{ xtfme5_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xtfme4_ProplistNth( g_as_lval )
LVAL                     g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL n_as_lval  = xlgafixnum();
    int  n          = getfixnum(n_as_lval);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case  0:    return k_transform;
    case  1:    return k_location;
    case  2:    return k_target;
    case  3:    return k_up;
    case  4:    return k_radians;
    case  5:    return k_degrees;
    case  6:    return k_diameter;
    case  7:    return k_left;
    case  8:    return k_right;
    case  9:    return k_top;
    case 10:    return k_bottom;
    case 11:    return k_near;
    case 12:    return k_far;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XTFM_PROPS,
	    n_as_lval,
	    default_val,
	    got_default
	);
    }
}

LVAL xtfme5_ProplistNth_Msg()
/*-
    Return Nth item from propertylist.
-*/
{
    return xtfme4_ProplistNth( xtfm01_Get_A_XTFM() );
}

/* }}} */
/* {{{ xtfmF0_Copy_Contents_Msg--Copy contents of another xtfm into self*/

LVAL xtfmF1_Copy_Contents( lv_m, lv_x, depth )
LVAL			   lv_m, lv_x;
int				       depth;
{
    ctfm_rec *    m = xtfm9c_Find_Immediate_Base( lv_m );
    ctfm_rec *    x = xtfm9c_Find_Immediate_Base( lv_x );
    c03d_fileInfo f;

    x03d81_CopyProplist( lv_m, lv_x, depth );
    f           = m->fileInfo;
    *m          = *x;
    m->fileInfo = f;

    return lv_x;
}

LVAL xtfmF0_Copy_Contents_Msg()
/*-
    Copy contents of another xtfm into self.
-*/
{
    LVAL m_as_lval = xtfm01_Get_A_XTFM();
    LVAL x_as_lval = xtfm01_Get_A_XTFM();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    return xtfmF1_Copy_Contents(m_as_lval,x_as_lval,depth);
}

/* }}} */
/* {{{ xtfmF4_Copy_Spaceball_Matrix_Msg--Copy spaceball matrix into tfm.*/

LVAL xtfmF3_Copy_Spaceball_Matrix( m_as_lval, scale )
LVAL                               m_as_lval;
float                                         scale;
/*-
      Post-multiply spaceball matrix into tfm.
      -*/
{
#ifdef SUPPORT_SPACEBALL
    int        i, j;
    ctfm_rec * m        = xtfm9c_Find_Immediate_Base( m_as_lval );
    char*      state    = xgtmG8_State();
    gt_mat *   s;

    /* Post-multiply by spaceball matrix: */
    xspb40_Get_Matrix( m, scale );
#endif

    return m_as_lval;
}

LVAL xtfmF4_Copy_Spaceball_Matrix_Msg()
/*-
      Copy spaceball matrix into xtfm.
      -*/
{
    LVAL  m_as_lval     = xtfm01_Get_A_XTFM();
    LVAL  scale_as_lval = xlgaflonum();
    float scale         = getflonum( scale_as_lval );
    xllastarg();
    return xtfmF3_Copy_Spaceball_Matrix( m_as_lval, scale );
}

/* }}} */
/* {{{ xtfmG5_Set_To_Product_Msg					*/

LVAL xtfmG4_Set_To_Product( lv_self, lv_full_list )
LVAL                        lv_self, lv_full_list;
{   LVAL lv_list = lv_full_list;
    LVAL lv_this;
    char*errmsg ="Bad :SET-TO-PRODUCT tfm list.";
    ctfm_rec*self = xtfm9c_Find_Immediate_Base( lv_self );
    ctfm_rec*this;

    /* Could maybe save a little work by checking update times on our	*/
    /* input objects and not recomputing if nothing has changed.	*/
    /* Remember that they may have :per-frame-hooks specified if you	*/
    /* try it.								*/

    /* The first transform in the product list just gets copied over us: */
    if (null(lv_list))   return lv_self;
    if (!consp(lv_list) || !xtfmp(car(lv_list)))   xlerror(errmsg,lv_full_list);
    this = xtfm9c_Find_Immediate_Base( car(lv_list) );
    self->m = this->m;    
    self->want_to_recompute_matrix = FALSE;
    lv_list = cdr(lv_list);
    
    /* Nonfirst tranforms in the product list get multiplied into us: */
    for (;  !null(lv_list);   lv_list = cdr(lv_list)) {
        if (!consp(lv_list) || !xtfmp(car(lv_list)))   xlerror(errmsg,lv_full_list);

	xtfm15_Matrix_Multiply_Post( lv_self, car(lv_list) );
    }    
    return lv_self;
}
LVAL xtfmG5_Set_To_Product_Msg()
{   LVAL lv_self = xtfm01_Get_A_XTFM();
    LVAL lv_list = xlgalist();
    xllastarg();
    return xtfmG4_Set_To_Product( lv_self, lv_list );
}

/* }}} */
/* {{{ xtfmH1_Decompose_Msg						*/

LVAL xtfmH0_Decompose_Matrix( lv_m )
LVAL		              lv_m;
{   
  double   tran[16];  /* 16 basic transform coefficients */
  ctfm_rec *m;        /* contents of matrix */
  LVAL     lv_val;
  LVAL     lv_list;
  LVAL     lv_coeffs;

  int        toProt = 4;
  xlstkcheck(toProt);
  xlprotect(lv_m);
  xlsave(lv_val);
  xlsave(lv_list);
  xlsave(lv_coeffs);

  /* if it didn't work, return NIL */
  m = xtfm9c_Find_Immediate_Base( lv_m );
  if (ctfm75_Decompose_Matrix( &m->m, tran ) == 0) {
    lv_coeffs = NIL;
  }
  /* if it worked, return a property list of coeffs */
  else {
    /* perspective */
    lv_list = NIL;
    lv_val  = cvflonum( tran[CTFM_U_PERSPW] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_PERSPZ] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_PERSPY] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_PERSPX] );
    lv_list = cons(lv_val, lv_list);
    lv_coeffs = cons(lv_list, lv_coeffs);
    lv_coeffs = cons(k_perspective, lv_coeffs);

    /* translation */
    lv_list = NIL;
    lv_val  = cvflonum( tran[CTFM_U_TRANSZ] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_TRANSY] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_TRANSX] );
    lv_list = cons(lv_val, lv_list);
    lv_coeffs = cons(lv_list, lv_coeffs);
    lv_coeffs = cons(k_move, lv_coeffs);

    /* rotation */
    lv_list = NIL;
    lv_val  = cvflonum( tran[CTFM_U_ROTATEZ] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_ROTATEY] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_ROTATEX] );
    lv_list = cons(lv_val, lv_list);
    lv_coeffs = cons(lv_list, lv_coeffs);
    lv_coeffs = cons(k_rotate, lv_coeffs);

    /* shear */
    lv_list = NIL;
    lv_val  = cvflonum( tran[CTFM_U_SHEARYZ] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_SHEARXZ] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_SHEARXY] );
    lv_list = cons(lv_val, lv_list);
    lv_coeffs = cons(lv_list, lv_coeffs);
    lv_coeffs = cons(k_shear, lv_coeffs);

    /* scale */
    lv_list = NIL;
    lv_val  = cvflonum( tran[CTFM_U_SCALEZ] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_SCALEY] );
    lv_list = cons(lv_val, lv_list);
    lv_val  = cvflonum( tran[CTFM_U_SCALEX] );
    lv_list = cons(lv_val, lv_list);
    lv_coeffs = cons(lv_list, lv_coeffs);
    lv_coeffs = cons(k_scale, lv_coeffs);
  }
  xlpopn(toProt);
  return lv_coeffs;
}

LVAL xtfmH1_Decompose_Msg()
{
    return xtfmH0_Decompose_Matrix( xtfm01_Get_A_XTFM() );
}

/* }}} */
/* {{{ xtfmH2_Combine_Rotations_Fn					*/

LVAL xtfmH2_Combine_Rotations_Fn()
{
  /* Combine several rotations about arbitrary axes into a single
   * rotation about an axis.  This works by converting rotations into
   * quaternions and doing the math there.
   *
   * USAGE:  (xg.3d-combine-rotations 
   *            (<x1> <y1> <z1>)  <angle1>
   *            (<x2> <y2> <z2>)  <angle2>
   *          ...)
   *
   *         angles should be specified in radians
   *
   * For more info, see:
   *   - Shoemake, K., Animating rotation with quaternion curves, Computer
   *     Graphics 19, No 3 (Proc. SIGGRAPH'85), 245-254, 1985.
   *
   *     He has a short writeup online at:
   *       ftp://ftp.cis.upenn.edu/pub/graphics/shoemake/
   *
   * Acknowledgments:  
   *   adapted from code written by Gavin Bell (gavin@wasabisoft.com)
   */

  double           angle;
  double           final_angle;
  geo_point        axis = {1.0, 0.0, 0.0};
  geo_point        final_axis;
  geo_quaternion   Qnew;         /* current quaternion */
  geo_quaternion   Qall;         /* combination of all rotations */
  LVAL             lv_arg;
  LVAL             lv_result;
  
  int        toProt = 2;
  xlstkcheck(toProt);
  xlsave(lv_arg);
  xlsave(lv_result);

  /* init the combined quaternion with a zero rotation */
  libQ0_Quaternion_from_Axis_Angle(&axis, 0.0, Qall);

  while (moreargs()) {

    /* fetch an axis and an angle */
    lib16_List_To_Point( &axis, lv_arg=xlgalist() );
    angle = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

    /* convert and add to combined quaternion */
    libQ0_Quaternion_from_Axis_Angle(&axis, angle, Qnew);
    libQ2_Quaternion_Multiply(Qall, Qnew, Qall);
  }

  /* return the combined axis and angle */
  libQ1_Quaternion_to_Axis_Angle( Qall, &final_axis, &final_angle );
  lv_result = cons( cvflonum(final_angle), NIL );
  lv_result = cons( lib14_Point_To_List(&final_axis), lv_result );

  xlpopn(toProt);
  return lv_result;
}

/* }}} */
/* {{{ xtfmz7_Read_Xtfm_From_File                                       */

xtfmz7_Read_Xtfm_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   ctfm_rec* h;
    char*     p;
    if (version != CTFM_REC_VERSION) {
	xlerror("xtfmz7: unsupported version",cvfixnum(version));
    }
    h = (ctfm_rec*) gobjimmbase( lv );

    p = (char*) &h->CTFM_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CTFM_INT32_COUNT,  magic, fp );

    p = (char*) &h->CTFM_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CTFM_FLOAT_COUNT,  magic, fp );

    p = (char*) &h->CTFM_FIRST_DOUBLE;
    p = cfil53_Read_Doubles_From_File( p, CTFM_DOUBLE_COUNT, magic, fp );
}

/* }}} */
/* {{{ xtfmwo_Write_Xtfm_To_Graphics_File                               */

xtfmwo_Write_Xtfm_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"    ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   ctfm_rec* h = (ctfm_rec*) gobjimmbase( lv );

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CTFM_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File( &h->CTFM_FIRST_INT32,  CTFM_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File( &h->CTFM_FIRST_FLOAT,  CTFM_FLOAT_COUNT, fdob);
	cfil46_Write_Doubles_To_File(&h->CTFM_FIRST_DOUBLE, CTFM_DOUBLE_COUNT,fdob);
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
