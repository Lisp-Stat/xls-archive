/* {{{ xsry.c -- Structure aRraY -- generic vector code.	     CrT*/
/*************************************************************************
*
*		This file does not itself implement a class, but
*		rather provides library support for xpta.c (point-array),
*		xtra.c (triangle-array) &tc.
* Author:       Jeff Prothero
* Created:      90Decl4
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */
/* {{{ --- history ---							*/

/* 95Oct05 jsp: Support for hardwired :initial-element property.	*/
/* 93Nov03 jsp: Speed hack in xsry22_AdjustArray: don't rezero.		*/
/* 91Oct04 jdp: Save to and restore from file works.			*/
/* 90Dec14 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  

#include "../../xcore/c/xlisp.h"

/* external variables */
extern LVAL obarray,s_unbound;
extern LVAL xlenv,xlfenv,xldenv;
extern LVAL k_start;
extern LVAL k_end;
extern LVAL k_fillpointer;
extern LVAL k_initialcontents;
extern LVAL k_initialelement;
extern LVAL k_initializefromfile;
extern LVAL lv_x32v;
extern LVAL lv_xflv;

#include "csry.h"
#include "cgrl.h"
#include "cthl.h"
#include "geo.h"
#include "c03d.h"
#include "../../xg.3d.fileio/c/cfil.h"

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 

FORWARD char* xsry15_Initial_Contents();
LVAL xsry86_Return_Default_Element();

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xsry21_AdjustArray_Msg -- Change shape of imm array.		*/

int xsry20_ArrayTotalSize( h ) /* NB: Also called from xgrl.c. */
csry_rec*		   h;
/*-
    Compute total number of elements in array.
-*/
{
    int       siz  = 1;
    int	      i    = h->rank;
    while (i --> 0)  siz *= h->dim[ i ];
    if (siz < 0)   xlerror("negative array size",cvfixnum(siz));
    return   siz;
}

LVAL xsry22_AdjustArray( gobject, new_h )
LVAL		         gobject;
csry_rec*			  new_h;
/*-
    Change shape of imm array, set up default values.
-*/
{
    csry_rec* h       = (csry_rec*) gobjimmbase( gobject );
    int total_slots   = xsry20_ArrayTotalSize( new_h );
    int new_imm_bytes = total_slots * h->s->sizeof_struct + sizeof(csry_rec);
    int old_imm_bytes = getgobjimmbytes( gobject );
    int bytes_delta   = new_imm_bytes - old_imm_bytes;
    int bytes_offset  = gobjsizeinbytes( gobject );
    
    if (new_imm_bytes < sizeof(csry_rec)) {
        xlerror("negative array size",cvfixnum(new_imm_bytes));
    }

    xgbj48_Adjust( gobject, bytes_offset, bytes_delta );
    setgobjimmbytes( gobject, new_imm_bytes );
    h		      = (csry_rec*) gobjimmbase( gobject );

    /* If we've added new structs, initialize them: */
    if (old_imm_bytes < new_imm_bytes) {
        char* structs = csry_base(gobject);
        char* base    = (char*) gobjimmbase( gobject );
        char* old_lim = base + old_imm_bytes;
        char* new_lim = base + new_imm_bytes;
	int   siz     = h->s->sizeof_struct;
        structs = old_lim;
        if (structs <  new_lim) {
            h->s->list_to_struct(structs,NIL,h);
            structs += siz;
        }
	switch (siz) {
	case 1:
	    {   register int i = new_lim - structs;
		register unsigned char*p   = (unsigned char*)structs;
		register unsigned char val = p[-1];
		/* xgbj48_Adjust zero-fills, nothing to do if val==0: */
		if (val) {
		    while (i --> 0) {
			if (i < 7) {
			    *p++ = val;
			} else {
			    *p++ = val; *p++ = val;	*p++ = val; *p++ = val;
			    *p++ = val; *p++ = val;	*p++ = val; *p++ = val;
			    i -= 7;
	    }	}   }   }
	    break;
	case 2:
	    {   register int i = (new_lim - structs)/2;
		register unsigned short*p   = (unsigned short*)structs;
		register unsigned short val = p[-1];
		if (sizeof(unsigned short)!=2)abort();
		if (val) {
		    while (i --> 0) {
			if (i < 7) {
			    *p++ = val;
			} else {
			    *p++ = val; *p++ = val;	*p++ = val; *p++ = val;
			    *p++ = val; *p++ = val;	*p++ = val; *p++ = val;
			    i -= 7;
	    }	}   }   }
	    break;
	case 4:
	    {   register int i = (new_lim - structs)/4;
		register unsigned *p  = (unsigned*)structs;
		register unsigned val = p[-1];
		if (sizeof(unsigned)!=4)abort();
		if (val) {
		    while (i --> 0) {
			if (i < 7) {
			    *p++ = val;
			} else {
			    *p++ = val; *p++ = val;	*p++ = val; *p++ = val;
			    *p++ = val; *p++ = val;	*p++ = val; *p++ = val;
			    i -= 7;
	    }	}   }   }
	    break;
	default:
	    while (structs < new_lim) {
		h->s->list_to_struct(structs,NIL,h);
		structs += siz;
    }	}   }

    /* Remember new shape: */
    {   int i;
	h->rank = new_h->rank;
	h->size = total_slots;
	for (i = h->rank;   i --> 0;   )   h->dim[i] = new_h->dim[i];
    }

    /* Make sure fill pointer gets copied, and is rational still: */
    h->dim[1] = new_h->dim[1];
    if (h->rank == 1   &&   h->dim[1] > h->size)   h->dim[1] = h->size;

    return gobject;
}

LVAL xsry27_AdjustArray( lv )
LVAL			 lv;
/*-
    Change shape of imm array, process 
    :INITIAL-CONTENTS, :INITIAL-ELEMENT, and :INITIALIZE-FROM-FILE.
-*/
{
    FORWARD LVAL xsry22_AdjustArray();
    csry_rec hx;
    xsry14_Figure_Shape(   &hx, moreargs() ? xlgetarg() : NIL );
    xsry22_AdjustArray( lv, &hx );

    while (moreargs()) {
        LVAL init = xlgasymbol();
        if (init == k_initialcontents) {

            /* Handle ":initial-contents '((1 0 0)(...)(...)(...)...)" */
	    char* p   = csry_base(lv);
            p         = xsry15_Initial_Contents( lv, xlgalist(), 0, p );

        } else if (init == k_initialelement) {

            /* Handle ":initial-element 2.0 ..." */
            xsry16_Initial_Element( lv, xlgetarg() );

        } else if (init == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xsryz7_Read_Array_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv,
		getfile(xlgetfile()),
		xsryz7_Read_Array_From_File,NULL
	    );

        } else if (init == k_fillpointer) {

            /* Handle ":fill-pointer t ..." */
            xsry30_Fill_Pointer( lv, xlgetarg() );

	} else {

            xlbadinit(init);
    }   }
    x03d9d_Maybe_Run_PerframeHooks( lv );
    return lv;
}
LVAL xsry21_AdjustArray_Msg()
/*-
    Change shape of imm array.
-*/
{
    /* Get gobject and requested array size: */
    return xsry27_AdjustArray( xlgagobject() );
}

/* }}} */
/* {{{ xsry00_Is_New -- Initialize a new ary instance.			*/

LVAL xsry00_Is_New( s )
csry_fns*           s;
{   LVAL lv    = xlgagobject();

#ifdef DONT_DO_IT
    /* This test won't work because we haven't set k_class yet. */
    if (!csryp(lv,s))   xlbadtype(lv);
#endif

    /* Set array's PROPERTY-LIST to NIL (right now it's unbound): */
/*    xlsetvalue( s_propertylist, NIL );*/

    /* Allocate space for array header, store s in it: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof(csry_rec) );
    {   csry_rec* h  = (csry_rec*) gobjimmbase( lv );
	h->s         = s;
	h->k_class   = s->k_class;
        h->fileInfo  = c03d_fileInfo_Init;
        xfil50_Maybe_Note_New_3D_Object( lv );
	(*s->initfn)( h ); /* Set up default_initializer. */
    }

    return xsry27_AdjustArray( lv );
}

/* }}} */
/* {{{ xsry01_Get_A_Struct_Array--Get arg, must be of appropriate class.*/

xsry0b_Is_A_Struct_Array( m_as_lval )
LVAL                      m_as_lval;
{   csry_rec* h;
    int  m_class;
    if (!gobjectp(m_as_lval))   return FALSE;
    h       = xsry9c_Find_Immediate_Base(m_as_lval);
    m_class = h->k_class;
    return C03D_IS_GRL_CLASS(m_class);
}
xsry0a_Must_Be_A_Struct_Array( m_as_lval )
LVAL                           m_as_lval;
{   if (!xsry0b_Is_A_Struct_Array( m_as_lval )) {
	xlerror("Not a legal GRL array type",m_as_lval);
    }
    return 0;
}
LVAL xsry01_Get_A_Struct_Array()   /* Also called from xgrl.c. */
/*-
    Get arg, must be a legal GRL array type:
-*/
{
    LVAL m_as_lval = xlgagobject();
    xsry0a_Must_Be_A_Struct_Array( m_as_lval );
    return m_as_lval;
}

/* }}} */
/* {{{ xsry0c_Get_A_Struct_Array_Or_Grl --Get arg, must be of appropriate class.*/

LVAL xsry0c_Get_A_Struct_Array_Or_Grl()   /* Also called from xgrl.c. */
/*-
    Get arg, must be a legal GRL array type or a GRL proper:
-*/
{
    LVAL m_as_lval = xlgagobject();
    if (!xsry0b_Is_A_Struct_Array( m_as_lval )
    &&  !xgrlp( m_as_lval )
    ){
	xlerror("Not a GRL and not a legal GRL array type",m_as_lval);
    }
    return m_as_lval;
}
/* }}} */
/* {{{ xsry02_Get_Index -- Get valid index (0 <= fixnum <oursize)	*/

xsry02_Get_Index( p_as_lval )
LVAL	          p_as_lval;
/*-
    Get valid index (0 <= fixnum < oursize).
-*/
{
    csry_rec* h = xsry9c_Find_Immediate_Base( p_as_lval );
    int       r = h->rank;
    int	      x = 0;
    int	      i = 0;
    for (     i = 0;   i < r;   ++i) {
	LVAL  l = xlgafixnum();
	int   m = getfixnum( l );
        if (m < 0 || m >= h->dim[i]) {
	    xlerror("bad index value",l);
	}
        x       = x * h->dim[i] + m;
    }
    xllastarg();
#ifdef XSRY_IS_PARANOID
    if (x >= h->size) xlfail("xsry02:internal error");
#endif 
    return x;
}

/* }}} */
/* {{{ xsry03_Show_Msg -- Show the contents of a csry.			*/

LVAL xsry03_Show_Msg()
/*-
    Show the contents of a csry.
-*/
{
    LVAL self,fptr;
    int i,j;
    char* m;
    char* lim;
    csry_rec* h;

    /* get self and the file pointer */
    self = xsry01_Get_A_Struct_Array();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);
 
    /* Print the gobject's STRUCT array: */
    m   = csry_base(self);
    h = xsry9c_Find_Immediate_Base( self );
    lim = (char*) m + (getgobjimmbytes(self) - sizeof(csry_rec));
    for (;   m < lim;   m += h->s->sizeof_struct) {
	char buf[256];
        h->s->sprintf_struct( buf, m );
	xlputstr(fptr,buf);
	xlterpri(fptr);
    }

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xsry04_Aref_Msg -- Get given entry.				*/

LVAL xsry05_Aref( m_as_lval, i )
LVAL		  m_as_lval;
int                          i;
/*-
    Get given entry.
-*/
{
    csry_rec*h = xsry9c_Find_Immediate_Base( m_as_lval               );
    char*    p = csry_base(                  m_as_lval               );

    return h->s->struct_to_list( p   +   i * h->s->sizeof_struct  );
}

LVAL xsry04_Aref_Msg()
/*-
    Get given entry.
-*/
{
    LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    return xsry05_Aref(
        m_as_lval,
        xsry02_Get_Index( m_as_lval )
    );
}

/* }}} */
/* {{{ xsry06_Setf_Msg -- Set given entry.				*/

LVAL xsry07_Setf( p_as_lval, i, v_as_lval )
LVAL		  p_as_lval;
int			     i;
LVAL 				v_as_lval;
/*-
    Set given entry.
-*/
{
    csry_rec*h = xsry9c_Find_Immediate_Base( p_as_lval );
    char* p    = csry_base(                  p_as_lval );
    p         += i*h->s->sizeof_struct;
    h->s->list_to_struct( p, v_as_lval, h );
    return v_as_lval;
}

LVAL xsry06_Setf_Msg()
/*-
    Set given entry.
-*/
{
    LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    LVAL v_as_lval = xlgetarg();
    return xsry07_Setf(
        m_as_lval,
        xsry02_Get_Index( m_as_lval ),
        v_as_lval
    );
}

/* }}} */
/* {{{ xsry08_Copy_Msg -- Build copy of given CSRY.			*/

LVAL xsry09_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given CSRY.
-*/
{
    /* Create a new array to hold result: */
    csry_rec*mh = xsry9c_Find_Immediate_Base( m_as_lval );
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(mh->s->k_ary,k_new);
    xlpop();

    /* Set new matrix to shape of old matrix: */
    xsry22_AdjustArray( r_as_lval, mh );

    /* Copy contents of old matrix to new and return new: */
    {
	int       i =         getgobjimmbytes( m_as_lval );
	char *  src = (char*) gobjimmbase(     m_as_lval );
	char *  dst = (char*) gobjimmbase(     r_as_lval );
	while (--i >= 0)   *dst++ = *src++;
    }
    return r_as_lval;
}

LVAL xsry08_Copy_Msg()
/*-
    Build copy of given CSRY.
-*/
{   LVAL m_as_lval;
    LVAL x_as_lval = xsry01_Get_A_Struct_Array();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xsry09_Copy(x_as_lval);
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xsry10_ArrayDimensions_Msg -- Get shape of imm array.		*/

LVAL xsry10_ArrayDimensions_Msg()
/*-
    Get shape of imm array.
-*/
{
    int  i;
    LVAL a_cons;
    LVAL a_fixn;
    LVAL gobject   = xlgagobject();
    csry_rec* h    = xsry9c_Find_Immediate_Base( gobject );
    xllastarg();
    xlstkcheck(2);
    xlsave(a_cons);
    xlsave(a_fixn);

    for (i = h->rank;   i --> 0;   ) {
	a_fixn = cvfixnum(  h->dim[i] );
	a_cons = cons( a_fixn, a_cons );
    }

    xlpopn(2);
    return a_cons;
}

/* }}} */
/* {{{ xsry11_ArrayDimension_Msg -- Get one dimension of imm array.	*/

LVAL xsry11_ArrayDimension_Msg()
/*-
    Get one dimension of imm array.
-*/
{
    LVAL gobject   = xlgagobject();
    csry_rec* h    = xsry9c_Find_Immediate_Base( gobject );
    LVAL d_as_lval = xlgafixnum();
    int  dim       = getfixnum( d_as_lval );
    xllastarg();
    if (dim < 0 || dim >= h->rank) {
        xlerror("bad dimension",d_as_lval);
    }
    return cvfixnum( h->dim[ dim ] );
}

/* }}} */
/* {{{ xsry12_ArrayRank_Msg -- Get rank of imm array.			*/

LVAL xsry12_ArrayRank_Msg()
/*-
    Get rank of imm array.
-*/
{
    LVAL gobject   = xlgagobject();
    csry_rec* h    = xsry9c_Find_Immediate_Base( gobject );
    return cvfixnum( h->rank );
}

/* }}} */
/* {{{ xsry13_ArrayTotalSize_Msg--Get total number of elements in array	*/

LVAL xsry13_ArrayTotalSize_Msg()
/*-
    Get total number of elements in array.
-*/
{
    LVAL gobject   = xlgagobject();
    csry_rec* h    = xsry9c_Find_Immediate_Base( gobject );
    return cvfixnum( h->size );
}

/* }}} */
/* {{{ xsry14_Figure_Shape -- Figure shape of array.			*/

xsry14_Figure_Shape( h, spec ) /* NB: Also called from xgrl.c. */
csry_rec*	     h;
LVAL			spec;
/*-
    Figure shape of array given Lisp spec.
-*/
{
    /**************************************************/
    /* Following CLtL2:442-3, the spec may be any of: */
    /* NIL:  A rank-zero array with one element.      */
    /* FIXNUM: A rank-one array of given length.      */
    /* Length-N List of FIXNUM: rank-N array.	      */
    /**************************************************/
    char * neg_dim = "Negative dimension";
    h->rank   = 0;   /* Handle bad spec more cleanly. */
    if (fixp( spec )) {
	int idim  = getfixnum( spec );
        if (idim < 0)     xlerror(neg_dim,spec);
	h->rank   = 1;
	h->dim[0] = idim;
	h->dim[1] = -1; /* No fill pointer */
    } else if (null( spec )) {
	h->rank   = 0;
    } else if (consp( spec )) {
        int  len  = 0;
        LVAL here = spec;
        do {
	    LVAL ldim   = car(here);
	    int  idim;
	    if (!fixp(ldim))  xlerror("Bad array dimension",ldim);
	    idim   = getfixnum(ldim);
            if (idim < 0)     xlerror(neg_dim,ldim);
	    h->dim[len] = idim;
	    here        = cdr(here);
	    if (++len > CSRY_MAX_RANK)   xlerror("> 7 dims not supported",spec);
        } while (consp(here));
	if (!null(here))     xlerror("Junk in dimension list",spec);
	h->rank   = len;
	if (h->rank == 1)   h->dim[1] = -1; /* No fill pointer */
    } else {
	xlerror("Unrecognized dimension",spec);
	xlbadtype(spec);
    }
}

/* }}} */
/* {{{ xsry15_Initial_Contents -- Apply an initializer list.		*/

char* xsry15_Initial_Contents( m, init, dim, p )
LVAL			       m, init;
int                                     dim;
char*					     p;
/*-
    Apply an initializer list to array.
    m:     Array being initialized.
    init:  Our part of the initializer tree.
    dim:   Our dimension: 0 <= dim < array-rank.
    p:     Next slot to initialize.
-*/
{
    csry_rec* h    = xsry9c_Find_Immediate_Base( m );
    int       lim  = h->dim[ dim ];
    LVAL      here = init;
    int       i;

    if (dim >= h->rank)   xlbadinit(init);

    for (i = 0;   i < lim;   ++i) {
	if (!consp(here))     xlbadtype(init);
	if (dim == h->rank -1) {
	    h->s->list_to_struct( p, car(here), h );
	    p += h->s->sizeof_struct;
	} else {
	    p = xsry15_Initial_Contents( m, car(here), dim+1, p );
	}
	here = cdr(here);
    }
    if (!null(here))          xlbadtype(init);

    return p;
}

/* }}} */
/* {{{ xsry16_Initial_Element--Initialize array to given initial element*/

xsry16_Initial_Element( m, el )
LVAL		        m, el;
/*-
    Initialize array to given initial element.
    Apply an initializer list to array.
    m:     Array being initialized.
    el:    Initial element.
-*/
{
    csry_rec* h   = xsry9c_Find_Immediate_Base( m );
    int       i;
    char*     dst = csry_base(m);
    char*     src = (char*) &h->default_initializer.i;
    int       siz = h->s->sizeof_struct;
    int       len = h->size;

#ifdef XSRY_IS_PARANOID
    if (len < 0)   xlfail("xsry16:internal error");
#endif

    /* Convert el to internal array form: */
    h->s->list_to_struct( src, el, h );

    /* Copy initial element all over array: */
    if (len) {
        h->s->bcopy( dst, src );
	src = dst;
    }
    for (i = 1;   i < len;   ++i) {
	dst += siz;
        h->s->bcopy( dst, src );
    }
}

/* }}} */
/* {{{ xsry23_RowMajorAref -- Get given entry, ignoring shape.		*/

LVAL xsry23_RowMajorAref( m_as_lval, i_as_lval )
LVAL		          m_as_lval, i_as_lval;
/*-
    Get given entry, ignoring shape.
-*/
{
    csry_rec* h = xsry9c_Find_Immediate_Base( m_as_lval );
    char*     p = csry_base(                  m_as_lval );
    int       i = getfixnum( i_as_lval );
    if (i < 0 || i >= h->size) xlerror("bad index value",i_as_lval);
    return h->s->struct_to_list( p + i*h->s->sizeof_struct );
}

LVAL xsry24_RowMajorAref_Msg()
/*-
    Get given entry, ignoring shape.  Message protocol.
-*/
{
    LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    LVAL i_as_lval = xlgafixnum();
    xllastarg();
    return xsry23_RowMajorAref(m_as_lval,i_as_lval);
}

/* }}} */
/* {{{ xsry25_RowMajorSetf -- Set given entry, ignoring shape.		*/

LVAL xsry25_RowMajorSetf( m_as_lval, i_as_lval, v_as_lval )
LVAL		          m_as_lval, i_as_lval, v_as_lval;
/*-
    Set given entry, ignoring shape.
-*/
{
    csry_rec* h = xsry9c_Find_Immediate_Base( m_as_lval );
    char*     p = csry_base(                  m_as_lval );
    int       i = getfixnum( i_as_lval );
    if (i < 0 || i >= h->size) xlerror("bad index value",i_as_lval);
    p          += i * h->s->sizeof_struct;
    h->s->list_to_struct( p, v_as_lval, h );
    return v_as_lval;
}

LVAL xsry26_RowMajorSetf_Msg()
/*-
    Set given entry, ignoring shape.  Message protocol.
-*/
{
    LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    LVAL v_as_lval = xlgetarg();
    LVAL i_as_lval = xlgafixnum();
    xllastarg();
    return xsry25_RowMajorSetf(m_as_lval,i_as_lval,v_as_lval);
}

/* }}} */
/* {{{ xsry28_Equalp -- Compare two arrays for equality.		*/

LVAL xsry28_Equalp( m_as_lval, n_as_lval )
LVAL		    m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int d;
    csry_rec* mh = xsry9c_Find_Immediate_Base( m_as_lval );
    csry_rec* nh = xsry9c_Find_Immediate_Base( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (d = mh->rank;   d --> 0; ) {
        if (mh->dim[d] != nh->dim[d]) return NIL;
    }
    {   /* Compare only up to limit indicated by fill pointers: */
	int len = mh->size;
	if (mh->rank == 1) {
	    d = mh->dim[1];   if (d >= 0 && d < len)   len = d;
	    d = nh->dim[1];   if (d >= 0 && d < len)   len = d;
	}

	/* Compare by ints if practical, else chars: */
	if (sizeof(int) == mh->s->sizeof_struct) {
	    register int* mt = (int*) csry_base( m_as_lval );
	    register int* nt = (int*) csry_base( n_as_lval );
	    register int   i  = len;
	    while (--i >= 0)   if (*mt++ != *nt++)   return NIL;
	} else {
	    register char* mt = (char*) csry_base( m_as_lval );
	    register char* nt = (char*) csry_base( n_as_lval );
	    register int   i  = len * mh->s->sizeof_struct;	
	    while (--i >= 0)   if (*mt++ != *nt++)   return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xsry29_Equalp_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    LVAL n_as_lval = xsry01_Get_A_Struct_Array();
    xllastarg();
    return xsry28_Equalp( m_as_lval, n_as_lval );
}

/* }}} */
/* {{{ xsry30_Fill_Pointer -- Set fill pointer to :FILL-POINTER value.	*/

xsry30_Fill_Pointer( m_as_lval, fill_as_lval )
LVAL		     m_as_lval, fill_as_lval;
/*-
    Set fill pointer to :FILL-POINTER value.
-*/
{
    csry_rec* h   = xsry9c_Find_Immediate_Base( m_as_lval );
    extern LVAL true;/*xlglob.c*/

    if (h->rank != 1) {
	xlerror(":FILL-POINTER: Array rank must be 1",m_as_lval);
    }

    if (null( fill_as_lval )) {
	h->dim[1] = 0;
        return;
    }

    if (fill_as_lval == true) {
	h->dim[1] = h->size;
        return;
    }

    if (fixp( fill_as_lval )) {
	int f = getfixnum( fill_as_lval );
	if (f >= 0 && f <= h->size) {
	    h->dim[1] = f;
	    return;
	}
    }

    xlerror("Bad :FILL-POINTER",fill_as_lval);
}

/* }}} */
/* {{{ xsry31_Get_Array_With_Fill_Pointer				*/

LVAL xsry31_Get_Array_With_Fill_Pointer( hp )
csry_rec**				 hp;
/*-
-*/
{
    LVAL a_as_lval = xsry01_Get_A_Struct_Array();
    csry_rec* h    = xsry9c_Find_Immediate_Base( a_as_lval );
    if (h->rank != 1 || h->dim[1] < 0)   xlfail("No fill pointer",a_as_lval);
    *hp = h;
    return a_as_lval;
}

/* }}} */
/* {{{ xsry32_Fill_Pointer_Msg -- Return fill pointer.			*/

LVAL xsry32_Fill_Pointer_Msg()
/*-
    Return fill pointer.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = xsry31_Get_Array_With_Fill_Pointer( &h );
    return cvfixnum( h->dim[1] );
}

/* }}} */
/* {{{ xsry34_Vector_Push_Msg -- Push element onto array.		*/

LVAL xsry33_Vector_Push( a_as_lval, v_as_lval, h )
LVAL			 a_as_lval, v_as_lval;
csry_rec*				       h;
/*-
    Push element onto array, sufficient space guaranteed.
-*/
{
    char* p        = csry_base( a_as_lval );
    int   i        = h->dim[1];
    if (i < 0 || i >= h->size)   return NIL;
    p             += i * h->s->sizeof_struct;
    if (null(v_as_lval)) {
        csry_rec* h   = xsry9c_Find_Immediate_Base( a_as_lval );
        char*     src = (char*) &h->default_initializer.i;
        h->s->bcopy( p, src );
    } else {
        h->s->list_to_struct( p, v_as_lval, h );
    }
    h->dim[1]      = i+1;
    return cvfixnum( i );
}

LVAL xsry34_Vector_Push_Msg()
/*-
    Push element onto array.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = xsry31_Get_Array_With_Fill_Pointer( &h );
    LVAL v_as_lval = moreargs() ? xlgetarg() : NIL;
    return xsry33_Vector_Push( a_as_lval, v_as_lval, h );
}

/* }}} */
/* {{{ xsry35_Vector_Push_Extend_Msg -- Push element onto array.	*/

LVAL xsryZ0_Vector_Push_Extend( a_as_lval, v_as_lval, h )
LVAL                            a_as_lval, v_as_lval;
csry_rec*                                             h;
/*-
      Push element onto array.
-*/
{
    int i = h->dim[1];
    if (i == h->size) {
 	csry_rec  hx;
 	hx.rank   = 1;
	hx.dim[0] = (
            i +
            CSRY_VECTOR_EXPANSION_INCREMENT +
           (h->size / CSRY_VECTOR_EXPANSION_RATIO)
        );
	hx.dim[1] = h->dim[1];
 	xsry22_AdjustArray( a_as_lval, &hx );
 	/* Gotcha #1: Header may have moved: */
 	h         = xsry9c_Find_Immediate_Base( a_as_lval );
    }
    return xsry33_Vector_Push( a_as_lval, v_as_lval, h );
}

LVAL xsry35_Vector_Push_Extend_Msg()
/*-
    Push element onto array.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = xsry31_Get_Array_With_Fill_Pointer( &h );
    LVAL v_as_lval = moreargs() ? xlgetarg() : NIL;
    return xsryZ0_Vector_Push_Extend( a_as_lval, v_as_lval, h );
}

/* }}} */
/* {{{ xsry36_Vector_Pop_Msg -- Pop element off array.			*/

LVAL xsry36_Vector_Pop_Msg()
/*-
    Pop element off array.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = xsry31_Get_Array_With_Fill_Pointer( &h );
    char* p        = csry_base( a_as_lval );
    int i          = h->dim[1];

    if (i <= 0 || i > h->size)   xlfail("Can't pop empty vector",a_as_lval);

    h->dim[1]      = --i;

    return h->s->struct_to_list( p + i*h->s->sizeof_struct );
}

/* }}} */
/* {{{ xsry37_Setf_Fill_Pointer_Msg -- Set fill pointer.		*/

LVAL xsry37_Setf_Fill_Pointer_Msg()
{
#ifdef STRICT_COMMONLISP
    csry_rec* h;
    LVAL a_as_lval = xsry31_Get_Array_With_Fill_Pointer( &h );
#else
    /* We allow adding a fill pointer to our arrays after-the-fact: */
    LVAL a_as_lval = xsry01_Get_A_Struct_Array();
#endif
    LVAL fill_as_lval = xlgetarg();
    xsry30_Fill_Pointer( a_as_lval, fill_as_lval );
    return   fill_as_lval;
}

/* }}} */
/* {{{ xsry39_Array_Row_Major_Index_Msg--Convert (i j k) idx to rowmajor*/

LVAL xsry39_Array_Row_Major_Index_Msg()
{   LVAL a = xsry01_Get_A_Struct_Array();
    int  i = xsry02_Get_Index( a );
    xllastarg();
    return cvfixnum( i );
}

/* }}} */
/* {{{ xsry59_Write_Array_To_Binary_File				*/

xsry59_Write_Array_To_Binary_File( lv, fdob )
LVAL                               lv;
FILE                                  *fdob;
{   csry_rec* h = xsry9c_Find_Immediate_Base( lv );

    /* Write byte-order signature plus record version number: */
    cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CSRY_REC_VERSION );

    /* Write out array contents: */
    switch (h->s->sizeof_struct) {
    case 1: cfil45_Write_Bytes_To_File(   h+1, h->size, fdob ); break;
    case 4:
	if        (getclass(lv) == lv_xflv) {
	    cfil47_Write_Floats_To_File(  h+1, h->size, fdob ); break;
	} else if (getclass(lv) == lv_x32v) {
	    cfil48_Write_Int32s_To_File(  h+1, h->size, fdob ); break;
	} else {
	    xlfail("xsry59.A"); /* Impossible :) */
	}
    case 8: cfil46_Write_Doubles_To_File( h+1, h->size, fdob ); break;
    default:
	xlfail("xsry59.B");     /* Impossible :) */
    }
}

/* }}} */
/* {{{ xsry76_Get_Msg -- Get keyword properties.                        */

LVAL xsry75_Get( lv_g )
LVAL		 lv_g;
/*-
    Return keyword properties for an xsry object.
-*/
{
    LVAL key         = xlgasymbol();
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    if (key == k_initialelement) {
	return xsry86_Return_Default_Element( lv_g );
    }

    return xthl8a_GetObjectProp( lv_g, key, default_val, got_default );
}

LVAL xsry76_Get_Msg()
/*-
    Return keyword properties for an xsry object.
-*/
{
    return xsry75_Get( xsry01_Get_A_Struct_Array() );
}

/* }}} */
/* {{{ xsry79_Set_Msg -- Write keyword properties.                      */

LVAL xsry78_Set( g_as_lval )
LVAL             g_as_lval;
/*-
    Write keyword properties for an xsry object.
-*/
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL key;
    LVAL val = NIL;
    while (moreargs()) {
        LVAL key        = xlgasymbol();
        LVAL val        = xlgetarg();
	if (key == k_initialelement) {
	    xlerror("May not currently change :initial-element",val);
	}
	xthl82_SetProp( pPropList, key, val );
    }
    return val;
}

LVAL xsry79_Set_Msg()
/*-
    Write keyword properties for an xsry object.
-*/
{
    return xsry78_Set( xsry01_Get_A_Struct_Array() );
}

/* }}} */
/* {{{ xsry86_Return_Default_Element -- Get :INITIAL-ELEMENT value */

LVAL xsry86_Return_Default_Element( lv )
LVAL                                lv;
{   csry_rec* h  = xsry9c_Find_Immediate_Base( lv );
    int i;
    if (h->s->k_class == C03D_xFLV) {
	cvflonum( h->default_initializer.f );
    } else {
	cvfixnum( h->default_initializer.i );
    }
}

/* }}} */
/* {{{ xsry87_Build_Default_Element_String -- Write :INITIAL-ELEMENT <#>*/

xsry87_Build_Default_Element_String( buf, lv )
char                                *buf;
LVAL                                      lv;
{   csry_rec* h  = xsry9c_Find_Immediate_Base( lv );
    int i;
    if (h->s->k_class == C03D_xFLV) {
	sprintf(buf," :initial-element %#g",h->default_initializer.f);
    } else {
	sprintf(buf," :initial-element %d", h->default_initializer.i);
    }
}

/* }}} */
/* {{{ xsry88_Build_Shape_Info_String--Write lisp declaration for array.*/

xsry88_Build_Shape_Info_String( buf, lv )
char                           *buf;
LVAL                                 lv;
{   csry_rec* h  = xsry9c_Find_Immediate_Base( lv );
    int i;
    /* Write out '(4 2) for a 4x2 array, etc: */
    *buf++ = '\'';
    *buf++ = '(';
    for (i = 0;   i < h->rank;   ++i) {
	sprintf(buf,"%d",h->dim[i]); buf += strlen(buf);
	if (i < h->rank-1) *buf++ = ' ';
    }
    *buf++ = ')';

    /* Write out :fill-pointer N if array has fillpointer set: */
    if (h->rank == 1   &&   h->dim[1] >= 0) {
	sprintf(buf," :fill-pointer %d",h->dim[1]); buf += strlen(buf);
    }
    *buf++ = '\0';
}

/* }}} */
/* {{{ xsry90_Write_To_File_Msg -- Write array to file in binary format.*/

LVAL xsry89_Write_To_File( lv )
LVAL	  	           lv;
{       
    CSRY_INT32 imm_bytes;
    char * base;
    LVAL   fptr_lval = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    FILE * fp        = getfile( fptr_lval );
    xllastarg();

    /* Pointer to data to write out: */
    base = (char*) csry_base( lv );

    /* Number of bytes to write out: */
    imm_bytes = getgobjimmbytes( lv ) - sizeof(csry_rec);

    /* Record number of bytes in the vector: */
    fwrite( &imm_bytes, sizeof(CSRY_INT32), 1, fp );

    /* Write it out: */
    fwrite( base, 1, imm_bytes, fp );

    return lv;
}
LVAL xsry90_Write_To_File_Msg()
/*-
    Write array to file in binary format.
-*/
{
    LVAL self = xsry01_Get_A_Struct_Array();
    return xsry89_Write_To_File( self );
}

/* }}} */
/* {{{ xsry91_ProplistLength_Msg -- Return length of propertylist.      */

#define XSRY_PROPS 1
LVAL xsry90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XSRY_PROPS + x03d89_PropListLength( *pPropList ) );
}

LVAL xsry91_ProplistLength_Msg()
/*-
    Return length of propertylist.
-*/
{
#ifdef OLD
    return xsry90_ProplistLength( xsry01_Get_A_Struct_Array() );
#else
    return xsry90_ProplistLength( xsry0c_Get_A_Struct_Array_Or_Grl() );
#endif
}

/* }}} */
/* {{{ xsry95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xsry94_ProplistNth( g_as_lval )
LVAL                     g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL n_as_lval  = xlgafixnum();
    int  n          = getfixnum(n_as_lval);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case 0:    return k_initialelement;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XSRY_PROPS,
	    n_as_lval,
	    default_val,
	    got_default
	);
    }
}

LVAL xsry95_ProplistNth_Msg()
/*-
    Return Nth item from propertylist.
-*/
{
#ifdef OLD
    return xsry94_ProplistNth( xsry01_Get_A_Struct_Array() );
#else
    return xsry94_ProplistNth( xsry0c_Get_A_Struct_Array_Or_Grl() );
#endif
}

/* }}} */
/* {{{ xsry9c_Find_Immediate_Base					*/

csry_rec* xsry9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    csry_rec*sry = (csry_rec*) gobjimmbase( lv );
    return sry;
}

/* }}} */
/* {{{ xsrya1_Position_Msg						*/

int xsrya0_Position( lv_ary, lv_arg )
LVAL	 	     lv_ary, lv_arg;
{   csry_rec*sry = xsry9c_Find_Immediate_Base( lv_ary );
    return sry->s->position( lv_ary, lv_arg );
}

LVAL xsrya1_Position_Msg()
{   LVAL lv_ary   = xsry01_Get_A_Struct_Array();
    LVAL lv_arg   = xlgetarg();
    int  position = xsrya0_Position( lv_ary, lv_arg );
    if  (position == -1)   return NIL;
    return cvfixnum( position );
}

/* }}} */
/* {{{ xsrya5_Delete_Msg						*/

int xsrya4_Delete( lv_ary, start, end )
LVAL	 	   lv_ary;
int                        start, end;
{   csry_rec*sry = xsry9c_Find_Immediate_Base( lv_ary );
    return sry->s->delete( lv_ary, start, end );
}

LVAL xsrya5_Delete_Msg()
{   LVAL lv_ary   = xsry01_Get_A_Struct_Array();
    csry_rec*h    = xsry9c_Find_Immediate_Base( lv_ary );
    int  start    = 0;
    int  end      = h->dim[0];
    if (h->rank != 1)  xlerror("Array must be one-dimensional to do :delete",lv_ary);
    /* Respect fillpointer: */
    if (h->dim[1] >= 0 && h->dim[1] < end)   end = h->dim[1];
    while (moreargs()) {
        LVAL lv_key      = xlgasymbol();
        LVAL lv_val      = xlgafixnum();
        int     val      = getfixnum(lv_val);
	if (lv_key == k_start) {
	    if (val < 0)     val = 0;
	    if (val > end-1) val = end-1;
	    start = val;
	} else if (lv_key == k_end) {
	    if (val < start+1)     val = start+1;
	    if (val > end)         val = end;
	    end = val;
	} else {
	    xlerror("Unsupported :delete keyword",lv_key);
	}
    }

    xsrya4_Delete( lv_ary, start, end );
    return NIL;
}

/* }}} */
/* {{{ xsryz7_Read_Array_From_File					*/

xsryz7_Read_Array_From_File( dum, lv, fp, magic, version )
char                        *dum;
LVAL                              lv;
FILE                                 *fp;
CSRY_INT32                                magic;
int                                              version;
{   csry_rec* h;
    char*     p;
    if (version != CSRY_REC_VERSION) {
	xlerror("xsry57: unsupported version",cvfixnum(version));
    }
    h = (csry_rec*) gobjimmbase( lv );
    p = (char*) (h+1);
    switch (h->s->sizeof_struct) {
    case 1:
	p = cfil52_Read_Bytes_From_File(   p, h->size, magic, fp );
	break;
    case sizeof(CSRY_INT32):
	if        (getclass(lv) == lv_xflv) {
	    p = cfil54_Read_Floats_From_File(  p, h->size, magic, fp );
	} else if (getclass(lv) == lv_x32v) {
	    p = cfil55_Read_Int32s_From_File(  p, h->size, magic, fp );
	} else {
	    xlfail("xsryz7"); /* Impossible :) */
	}
	break;
    case sizeof(double):
	p = cfil53_Read_Doubles_From_File( p, h->size, magic, fp );
	break;
    default:
	xlfail("xsry57 broke");
    }
}

/* }}} */
/* {{{ xsrywo_Write_Xsry_To_Graphics_File                               */

xsrywo_Write_Xsry_To_Graphics_File( fdoa, fdob, lv,f,n, classname )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
char                                                   *classname;
/* buggo, 'classname' can probably be deleted, Find_Class_Name replaces. ^ */
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    char buf[256];
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new ",getstring(name));
/*  fprintf(fdoa,"(setq xfil-this (send CLASS-%s-ARRAY :new ",classname); */
    xsry88_Build_Shape_Info_String(buf,lv);
    fputs(buf,fdoa);
    xsry87_Build_Default_Element_String(buf,lv);
    fputs(buf,fdoa);
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n",fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    xsry59_Write_Array_To_Binary_File( lv, fdob );
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
