/* {{{ xmtl.c -- materials.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Aug18
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */
/* {{{ --- history ---							*/

/* 91Aug15 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

extern LVAL lv_xmtl;
extern LVAL k_alphaimplementation;
extern LVAL k_ordereddither;
extern LVAL k_random16x16patterns;
extern LVAL k_random32x32patterns;
extern LVAL k_random64x64patterns;
extern LVAL k_alpha;
extern LVAL k_alphaweight;
extern LVAL k_ambientcolor;
extern LVAL k_ambientweight;
extern LVAL k_diffusecolor;
extern LVAL k_diffuseweight;
extern LVAL k_drawas;
extern LVAL k_emissioncolor;
extern LVAL k_emissionweight;
extern LVAL k_invisible;
extern LVAL k_pointcloud;
extern LVAL k_shininess;
extern LVAL k_shininessweight;
extern LVAL k_solid;
extern LVAL k_specularcolor;
extern LVAL k_specularweight;
extern LVAL k_wireframe;
extern LVAL k_initializefromfile;
extern LVAL k_facets;

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 
LVAL xmtl41_Set();

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#include <math.h>
#include "geo.h"
#include "csry.h"
#include "cmtl.h"
#include "ctfm.h"
#include "lib.h"
#include "cgrl.h"
#include "c03d.h"
#include "cthl.h"
#include "../../xg.3d.fileio/c/cfil.h"

gt_material_rec * xmtl04_Get_Material_Rec();
cmtl_rec* xmtl9c_Find_Immediate_Base();

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xmtl00_Is_New -- Initialize a new xmtl instance.			*/

cmtl_rec xmtl_defaults = { /* Also used by xgtm.c. */
    C03D_xMTL,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */
    {
	1,			/* material_ID			*/
	GT_AS_SOLID,		/* draw_as			*/
	GT_OPACITY_TYPE_ALPHA,	/* opacity_type			*/
	1,			/* dirty			*/

	{0.0, 0.0, 0.0},	/* emission_color		*/
	{0.2, 0.2, 0.2},	/* ambient_color		*/
	{0.8, 0.8, 0.8},	/* diffuse_color		*/
	{0.0, 0.0, 0.0},	/* specular_color		*/

	0.0,		/* shininess			*/   
	1.0,		/* alpha			*/   

	0.0,		/* emission_weight		*/
	0.0,		/* ambient_weight		*/
	0.0,		/* diffuse_weight		*/
	0.0,		/* specular_weight		*/
	0.0,		/* shininess_weight		*/
	0.0		/* alpha_weight			*/
    },
};

LVAL xmtl00_Is_New()
/*-
    Initialize a new xmtl instance.
-*/
{
    static materials_created = 5;/* 0 is SGI GL-reserved, we use 1 internally. */
				 /* 2,3,4,5 are just fudge factor.             */
  
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    cmtl_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xmtlp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( cmtl_rec ) );

    /* Initialize material record to reasonable default values: */
    r	= (cmtl_rec*) gobjimmbase( lv );
   *r   = xmtl_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    /* Issue each material a unique id: */
    r->r.material_ID   = ++materials_created;
    r->r.dirty         = TRUE;

    /* Parse user args and save in r.  Can't apply them until   */
    /* we've created viewing matrix, and can't create that      */
    /* matrix until we've parsed the args. Sigh.		*/
    {   struct ctfm_Put_Rec r;
	xmtl41_Set( lv, &r );
    }

    return lv;
}

/* }}} */
/* {{{ xmtl01_Get_A_XMTL -- Get arg, must be of class xmtl.		*/

LVAL xmtl01_Get_A_XMTL()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XMTL has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xmtl.  Similarly,          */
    /* nobody but nobody has any business resizing a xmtl,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xmtlp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) != sizeof(cmtl_rec) 
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xmtl03_Show_Msg -- Show the contents of a cmtl.			*/

LVAL xmtl03_Show_Msg()
/*-
    Show the contents of a mtl.
-*/
{
    LVAL self,fptr;

    /* get self and the file pointer */
    self = xmtl01_Get_A_XMTL();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the mtl record: */
    {   static char* drawas[] = {
            ":DEFAULT",
            ":SOLID",
            ":WIRE-FRAME",
            ":POINT-CLOUD",
            ":INVISIBLE"
        };
	gt_material_rec * p = xmtl04_Get_Material_Rec( self );
	libE5_xlprint_int(  "material_ID"      , p->material_ID            ,fptr);
        xlputstr(fptr,"draw_as")               ,xlputstr(fptr,drawas[p->draw_as]);
	libE7_xlprint_point("ambient_color"    ,&p->ambient_color          ,fptr);
	libE7_xlprint_point("emission_color"   ,&p->emission_color         ,fptr);
	libE7_xlprint_point("diffuse_color"    ,&p->diffuse_color          ,fptr);
	libE7_xlprint_point("specular_color"   ,&p->specular_color         ,fptr);
	libE6_xlprint_float("shininess"        , p->shininess              ,fptr);
	libE6_xlprint_float("alpha"            , p->alpha                  ,fptr);
    }

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xmtl04_Get_Material_Rec -- Get pointer to internal record.	*/

gt_material_rec * xmtl04_Get_Material_Rec( lv_material ) /* Called by xtfm.c */
LVAL				     	   lv_material;
/*-
    Get pointer to internal record.
-*/
{
    /* This function sorta breaks the privacy of the class... that's	*/
    /* pretty normal in interfaces to the machine-dependent code   :).	*/
    /* Probably need a way of formally splitting a class this way. :)	*/
    cmtl_rec * l   = xmtl9c_Find_Immediate_Base(       lv_material );

    return &l->r;
}

/* }}} */
/* {{{ xmtl08_Copy_Msg -- Build copy of given CMTL.			*/

LVAL xmtl09_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given CMTL.
-*/
{
    /* Create a new gobject to hold result: */
    cmtl_rec*mh = xmtl9c_Find_Immediate_Base( m_as_lval );
    cmtl_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xmtl,k_new);
    xlpop();
    nh = (cmtl_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}

LVAL xmtl08_Copy_Msg()
/*-
    Build copy of given CMTL.
-*/
{   LVAL m_as_lval;
    LVAL x_as_lval = xmtl01_Get_A_XMTL();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xmtl09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xmtl28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xmtl28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {
	char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xmtl29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xmtl01_Get_A_XMTL();
    LVAL n_as_lval = xmtl01_Get_A_XMTL();
    xllastarg();
    return xmtl28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xmtl40_Get_Msg -- Get keyword properties.                        */

LVAL xmtl39_Get( lv_material )
LVAL             lv_material;
{
    cmtl_rec* material = xmtl9c_Find_Immediate_Base( lv_material );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if        (key == k_ambientcolor) {

        result = lib14_Point_To_List( &material->r.ambient_color );

    } else if (key == k_diffusecolor) {

        result = lib14_Point_To_List( &material->r.diffuse_color );

    } else if (key == k_emissioncolor) {

        result = lib14_Point_To_List( &material->r.emission_color );

    } else if (key == k_specularcolor) {

        result = lib14_Point_To_List( &material->r.specular_color );

    } else if (key == k_shininess) {

	result = cvflonum( material->r.shininess );

    } else if (key == k_alpha) {

	result = cvflonum( material->r.alpha );

    } else if (key == k_alphaimplementation) {

	switch (material->r.opacity_type) {
        case GT_OPACITY_TYPE_ORDERED_DITHER:
	    result = k_ordereddither;
	    break;
        case GT_OPACITY_TYPE_OLD_16:
	    result = k_random16x16patterns;
	    break;
        case GT_OPACITY_TYPE_OLD_32:
	    result = k_random32x32patterns;
	    break;
        case GT_OPACITY_TYPE_OLD_64:
	    result = k_random64x64patterns;
	    break;
        case GT_OPACITY_TYPE_ALPHA:
	    result = k_alpha;
	    break;
	default:
	    xlfail("xmtl39");
	}

    } else if (key == k_ambientweight) {

        result = cvflonum( material->r.ambient_weight );

    } else if (key == k_diffuseweight) {

        result = cvflonum( material->r.diffuse_weight );

    } else if (key == k_emissionweight) {

        result = cvflonum( material->r.emission_weight );

    } else if (key == k_specularweight) {

        result = cvflonum( material->r.specular_weight );

    } else if (key == k_shininessweight) {

	result = cvflonum( material->r.shininess_weight );

    } else if (key == k_alphaweight) {

	result = cvflonum( material->r.alpha_weight );

    } else if   (key == k_drawas) {

        switch (material->r.draw_as) {
	case GT_AS_DEFAULT:  	result = NIL;  		break;
	case GT_AS_WIRE_FRAME:  result = k_wireframe;	break;
	case GT_AS_POINT_CLOUD: result = k_pointcloud;	break;
	case GT_AS_SOLID:       result = k_solid;	break;
	case GT_AS_INVISIBLE:   result = k_invisible;	break;
	case GT_AS_FACETS:      result = k_facets;	break;
        default:
	    xlerror("oops",cvfixnum(material->r.draw_as));/*not possible*/
	}

    } else {

	/* If this isn't a property we know, do a generic get property: */
        result = xthl8a_GetObjectProp( lv_material, key, default_val, got_default );
    }
    return result;
}

LVAL xmtl40_Get_Msg()
/*-
    Return keyword properties for a material object.
-*/
{
    return xmtl39_Get( xmtl01_Get_A_XMTL() );
}

/* }}} */
/* {{{ xmtl42_Set_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Set, update XMTL_PROPS and xmtl94_ProplistNth. */
#define XMTL_PROPS (14)

LVAL xmtl41_Set( lv_material, r )
LVAL             lv_material;
struct ctfm_Put_Rec	     *r;
{
    cmtl_rec* material = xmtl9c_Find_Immediate_Base( lv_material );

    /* Buggo? Not clear r ever gets used? 91Nov23CrT */
    ctfm70_Initialize_Put_Rec( r );

    while (moreargs()) {
        LVAL init = xlgasymbol();
	LVAL arg;

        if        (init == k_ambientcolor) {

            /* Handle ":ambient-color '(1 1 1)" */
            lib17_List_To_Color( &material->r.ambient_color, xlgalist() ); 
	    material->r.dirty      = TRUE;

        } else if (init == k_diffusecolor) {

            /* Handle ":diffuse-color '(1 1 1)" */
            lib17_List_To_Color( &material->r.diffuse_color, xlgalist() ); 
	    material->r.dirty      = TRUE;

        } else if (init == k_emissioncolor) {

            /* Handle ":emission-color '(1 1 1)" */
            lib17_List_To_Color( &material->r.emission_color, xlgalist() ); 
	    material->r.dirty      = TRUE;

        } else if (init == k_specularcolor) {

            /* Handle ":specular-color '(1 1 1)" */
            lib17_List_To_Color( &material->r.specular_color, xlgalist() ); 
	    material->r.dirty      = TRUE;

        } else if (init == k_shininess) {

            /* Handle ":shininess 0.4" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly shininess",tmp);
            material->r.shininess = tmp;
	    material->r.dirty      = TRUE;

        } else if (init == k_alpha) {

            /* Handle ":alpha 0.4" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly alpha",tmp);
            material->r.alpha = tmp;
	    material->r.dirty      = TRUE;

        } else if (init == k_alphaimplementation) {

	    LVAL val  = xlgasymbol();
	    if        (val == k_ordereddither) {
		material->r.opacity_type = GT_OPACITY_TYPE_ORDERED_DITHER;
	    } else if (val == k_random16x16patterns) {
		material->r.opacity_type = GT_OPACITY_TYPE_OLD_16;
	    } else if (val == k_random32x32patterns) {
		material->r.opacity_type = GT_OPACITY_TYPE_OLD_32;
	    } else if (val == k_random64x64patterns) {
		material->r.opacity_type = GT_OPACITY_TYPE_OLD_64;
	    } else if (val == k_alpha || val == NIL) {
		material->r.opacity_type = GT_OPACITY_TYPE_ALPHA;
	    } else {
		xlerror("bad :alpha-implementation val",val);
	    }

        } else if (init == k_ambientweight) {

            /* Handle ":ambient-weight '(1 1 1)" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly ambient-weight",tmp);
            material->r.ambient_weight	= tmp;
	    material->r.dirty      	= TRUE;

        } else if (init == k_diffuseweight) {

            /* Handle ":diffuse-weight '(1 1 1)" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly diffuse-weight",tmp);
            material->r.diffuse_weight	= tmp;
	    material->r.dirty      	= TRUE;

        } else if (init == k_emissionweight) {

            /* Handle ":emission-weight '(1 1 1)" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly emission-weight",tmp);
            material->r.emission_weight	= tmp;
	    material->r.dirty      	= TRUE;

        } else if (init == k_specularweight) {

            /* Handle ":specular-weight '(1 1 1)" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly specular-weight",tmp);
            material->r.specular_weight	= tmp;
	    material->r.dirty      	= TRUE;

        } else if (init == k_shininessweight) {

            /* Handle ":shininess-weight 0.4" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly shininess-weight",tmp);
            material->r.shininess_weight= tmp;
	    material->r.dirty      	= TRUE;

        } else if (init == k_alphaweight) {

            /* Handle ":alpha-weight 0.4" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly alpha-weight",tmp);
            material->r.alpha_weight = tmp;
	    material->r.dirty        = TRUE;

        } else if (init == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xmtlz7_Read_Xmtl_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_material,
		getfile(xlgetfile()),
		xmtlz7_Read_Xmtl_From_File,NULL
	    );

        } else if   (init == k_drawas) {
            LVAL val = xlgetarg();
	    if      (val == NIL        )  material->r.draw_as = GT_AS_DEFAULT;
	    else if (val == k_wireframe)  material->r.draw_as = GT_AS_WIRE_FRAME;
	    else if (val == k_pointcloud) material->r.draw_as = GT_AS_POINT_CLOUD;
	    else if (val == k_solid)      material->r.draw_as = GT_AS_SOLID;
	    else if (val == k_facets)     material->r.draw_as = GT_AS_FACETS;
	    else if (val == k_invisible)  material->r.draw_as = GT_AS_INVISIBLE;
	    else {
		xlerror("bad :draw-as val",val);
	    }

	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_material, init, xlgetarg() );
    }   }

    return lv_material;
}

LVAL xmtl42_Set_Msg()
{   /* Read keyword properties for a material object: */
    struct ctfm_Put_Rec r;
    LVAL   lv_material = xmtl01_Get_A_XMTL();
    LVAL   result    = xmtl41_Set( lv_material, &r );
    return result;
}

/* }}} */
/* {{{ xmtl91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xmtl90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XMTL_PROPS + x03d89_PropListLength( *pPropList ) );
}

LVAL xmtl91_ProplistLength_Msg()
{   /* Return length of propertylist: */
    return xmtl90_ProplistLength( xmtl01_Get_A_XMTL() );
}

/* }}} */
/* {{{ xmtl95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xmtl94_ProplistNth( g_as_lval )
LVAL                     g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL n_as_lval  = xlgafixnum();
    int  n          = getfixnum(n_as_lval);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case  0:    return k_ambientcolor;
    case  1:    return k_diffusecolor;
    case  2:    return k_emissioncolor;
    case  3:    return k_specularcolor;
    case  4:    return k_shininess;
    case  5:    return k_alpha;
    case  6:    return k_ambientweight;
    case  7:    return k_diffuseweight;
    case  8:    return k_emissionweight;
    case  9:    return k_specularweight;
    case 10:    return k_shininessweight;
    case 11:    return k_alphaweight;
    case 12:    return k_drawas;
    case 13:    return k_alphaimplementation;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XMTL_PROPS,
	    n_as_lval,
	    default_val,
	    got_default
	);
    }
}

LVAL xmtl95_ProplistNth_Msg()
{/* Return Nth item from propertylist. */
    return xmtl94_ProplistNth( xmtl01_Get_A_XMTL() );
}

/* }}} */
/* {{{ xmtl9c_Find_Immediate_Base					*/

cmtl_rec* xmtl9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    cmtl_rec*mtl = (cmtl_rec*) gobjimmbase( lv );
    return mtl;
}

/* }}} */
/* {{{ xmtlG5_Set_To_Product_Msg					*/

xmtlG2_ScalarWeightedAverage( out, in, weight )
float                        *out, in, weight;
{   *out = (
	(1.0-weight) * *out   +
	(    weight) *   in
    );
}
xmtlG3_PointWeightedAverage( out, in, weight )
geo_point                   *out,*in;
float                                 weight;
{   xmtlG2_ScalarWeightedAverage( &out->x, in->x, weight );
    xmtlG2_ScalarWeightedAverage( &out->y, in->y, weight );
    xmtlG2_ScalarWeightedAverage( &out->z, in->z, weight );
}
LVAL xmtlG4_Set_To_Product( lv_self, lv_full_list )
LVAL                        lv_self, lv_full_list;
{   LVAL lv_list = lv_full_list;
    LVAL lv_this;
    char*errmsg ="Bad :SET-TO-PRODUCT mtl list.";
    cmtl_rec*self = xmtl9c_Find_Immediate_Base( lv_self );
    cmtl_rec*this;

    /* Could maybe save a little work by checking update times on our	*/
    /* input colors and not recomputing if nothing has changed.		*/
    /* Remember that they may have :per-frame-hooks specified if you	*/
    /* try it.								*/

    /* The first material in the product list just gets copied over us: */
    if (null(lv_list))   return lv_self;
    if (!consp(lv_list) || !xmtlp(car(lv_list)))   xlerror(errmsg,lv_full_list);
    this = xmtl9c_Find_Immediate_Base( car(lv_list) );
    {   int id  = self->r.material_ID;
        self->r = this->r;    
        self->r.material_ID = id;
        self->r.dirty	    = TRUE;
    }
    lv_list = cdr(lv_list);
    
    /* Nonfirst materials in the product list get combined with us: */
    for (;  !null(lv_list);   lv_list = cdr(lv_list)) {
        if (!consp(lv_list) || !xmtlp(car(lv_list)))   xlerror(errmsg,lv_full_list);
        this = xmtl9c_Find_Immediate_Base( car(lv_list) );

	/* Integer properties: */
	if (this->r.draw_as) {
	    self->r.draw_as = this->r.draw_as;
        }

	/* Float properties: */
	xmtlG2_ScalarWeightedAverage(
	   &self->r.shininess,
	    this->r.shininess,
	    this->r.shininess_weight
	);
	xmtlG2_ScalarWeightedAverage(
	   &self->r.alpha,
	    this->r.alpha,
	    this->r.alpha_weight
	);

	/* RGB properties: */
        xmtlG3_PointWeightedAverage(
	    &self->r.emission_color,
	    &this->r.emission_color,
	     this->r.emission_weight
	);
        xmtlG3_PointWeightedAverage(
	    &self->r.ambient_color,
	    &this->r.ambient_color,
	     this->r.ambient_weight
	);
        xmtlG3_PointWeightedAverage(
	    &self->r.diffuse_color,
	    &this->r.diffuse_color,
	     this->r.diffuse_weight
	);
        xmtlG3_PointWeightedAverage(
	    &self->r.specular_color,
	    &this->r.specular_color,
	     this->r.specular_weight
	);
    }    
    return lv_self;
}
LVAL xmtlG5_Set_To_Product_Msg()
{   LVAL lv_self = xmtl01_Get_A_XMTL();
    LVAL lv_list = xlgalist();
    xllastarg();
    return xmtlG4_Set_To_Product( lv_self, lv_list );
}

/* }}} */
/* {{{ xmtlF0_Copy_Contents_Msg--Copy contents of another xmtl into self*/

LVAL xmtlF1_Copy_Contents( m_as_lval, x_as_lval, depth )
LVAL			   m_as_lval, x_as_lval;
int						 depth;
{
    cmtl_rec * m = xmtl9c_Find_Immediate_Base( m_as_lval );
    cmtl_rec * x = xmtl9c_Find_Immediate_Base( x_as_lval );
    c03d_fileInfo f;

    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    f           = m->fileInfo;
    *m          = *x;
    m->fileInfo = f;

    return x_as_lval;
}

LVAL xmtlF0_Copy_Contents_Msg()
/*-
    Copy contents of another xmtl into self.
-*/
{
    LVAL m_as_lval = xmtl01_Get_A_XMTL();
    LVAL x_as_lval = xmtl01_Get_A_XMTL();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    return xmtlF1_Copy_Contents(m_as_lval,x_as_lval,depth);
}

/* }}} */
/* {{{ xmtlz7_Read_Xmtl_From_File                                       */

xmtlz7_Read_Xmtl_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   cmtl_rec* h;
    char*     p;
    if (version != CMTL_REC_VERSION) {
	xlerror("xmtlz7: unsupported version",cvfixnum(version));
    }
    h = (cmtl_rec*) gobjimmbase( lv );

    p = (char*) &h->CMTL_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CMTL_INT32_COUNT,  magic, fp );

    p = (char*) &h->CMTL_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CMTL_FLOAT_COUNT,  magic, fp );
}

/* }}} */
/* {{{ xmtlwo_Write_Xmtl_To_Graphics_File                               */

xmtlwo_Write_Xmtl_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   cmtl_rec* h = (cmtl_rec*) gobjimmbase( lv );

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CMTL_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CMTL_FIRST_INT32, CMTL_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CMTL_FIRST_FLOAT, CMTL_FLOAT_COUNT, fdob);
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

