/* {{{ xtxr.c -- materials.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94Mar31
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */
/* {{{ --- history ---							*/

/* 94Mar31 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

extern LVAL lv_xtxr;
extern LVAL s_graphicrelation;
extern LVAL k_graphicrelation;
extern LVAL k_minifyfn;
extern LVAL k_magnifyfn;
extern LVAL k_mipmappoint;
extern LVAL k_mipmaplinear;
extern LVAL k_mipmapbilinear;
extern LVAL k_mipmaptrilinear;
extern LVAL k_point;
extern LVAL k_bilinear;
extern LVAL k_mergetype;
extern LVAL k_wraptype;
extern LVAL k_repeat;
extern LVAL k_clamp;
extern LVAL k_decal;
extern LVAL k_modulate;
extern LVAL k_drawas;
extern LVAL k_textureis;
extern LVAL k_on;
extern LVAL k_off;
extern LVAL k_bypoint;
extern LVAL k_byfacet;
extern LVAL k_initializefromfile;

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 
LVAL xtxr41_Set();

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"
#include <math.h>
#include "geo.h"
#include "csry.h"
#include "ctxr.h"
#include "ctfm.h"
#include "lib.h"
#include "cgrl.h"
#include "c03d.h"
#include "cthl.h"
#include "../../xg.3d.fileio/c/cfil.h"

gt_texture_rec * xtxr04_Get_Texture_Rec();
ctxr_rec* xtxr9c_Find_Immediate_Base();

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xtxr00_Is_New -- Initialize a new xtxr instance.			*/

ctxr_rec xtxr_defaults = { /* Also used by xgtm.c. */
    C03D_xTXR,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */
    {
	1,			/* texture_ID			*/
	GT_MIPMAP_LINEAR,	/* min_filter			*/
	GT_BILINEAR,		/* mag_filter			*/
	GT_REPEAT,		/* wrap_type			*/
	GT_MODULATE,		/* merge_type			*/
	GT_BY_ON,		/* texture_is			*/
	1,			/* dirty			*/

    },
};

LVAL xtxr00_Is_New()
/*-
    Initialize a new xtxr instance.
-*/
{
    static textures_created = 5;/* 0 is SGI GL-reserved, we use 1 internally.*/
				 /* 2,3,4,5 are just fudge factor.           */
  
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    ctxr_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xtxrp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( ctxr_rec ) );

    /* Initialize texture record to reasonable default values: */
    r	= (ctxr_rec*) gobjimmbase( lv );
   *r   = xtxr_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    /* Issue each texture a unique id: */
    r->r.texture_ID   = ++textures_created;
    r->r.texture_is   = GT_BY_ON;
    r->r.dirty        = TRUE;

    xthl91_SetObjectVariable( lv, s_graphicrelation, NIL );

    /* Parse user args and save in r: */
    xtxr41_Set( lv );

    return lv;
}

/* }}} */
/* {{{ xtxr01_Get_A_XTXR -- Get arg, must be of class xtxr.		*/

LVAL xtxr01_Get_A_XTXR()
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XTXR has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xtxr.  Similarly,          */
    /* nobody but nobody has any business resizing a xtxr,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xtxrp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) != sizeof(ctxr_rec) 
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xtxr03_Show_Msg -- Show the contents of a ctxr.			*/

LVAL xtxr03_Show_Msg()
/*-
    Show the contents of a txr.
-*/
{
    LVAL self,fptr;

    /* get self and the file pointer */
    self = xtxr01_Get_A_XTXR();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the txr record: */
    {   gt_texture_rec * p = xtxr04_Get_Texture_Rec( self );
	libE5_xlprint_int(  "texture_ID"       , p->texture_ID      ,fptr);
	libE5_xlprint_int(  "min_filter"       , p->min_filter      ,fptr);
	libE5_xlprint_int(  "mag_filter"       , p->mag_filter      ,fptr);
	libE5_xlprint_int(  "merge_type"       , p->merge_type      ,fptr);
	libE5_xlprint_int(  "texture_is"       , p->texture_is      ,fptr);
	libE5_xlprint_int(  "wrap_type"        , p->wrap_type       ,fptr);
    }

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xtxr04_Get_Texture_Rec -- Get pointer to internal record.	*/

gt_texture_rec * xtxr04_Get_Texture_Rec( lv_texture ) /* Called by xtfm.c */
LVAL				     	 lv_texture;
/*-
    Get pointer to internal record.
-*/
{
    /* This function sorta breaks the privacy of the class... that's	*/
    /* pretty normal in interfaces to the machine-dependent code   :).	*/
    /* Probably need a way of formally splitting a class this way. :)	*/
    ctxr_rec * l   = xtxr9c_Find_Immediate_Base(       lv_texture );

    return &l->r;
}

/* }}} */
/* {{{ xtxr08_Copy_Msg -- Build copy of given CTXR.			*/

LVAL xtxr09_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given CTXR.
-*/
{
    /* Create a new gobject to hold result: */
    ctxr_rec*mh = xtxr9c_Find_Immediate_Base( m_as_lval );
    ctxr_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xtxr,k_new);
    xlpop();
    nh = (ctxr_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}

LVAL xtxr08_Copy_Msg()
/*-
    Build copy of given CMTL.
-*/
{   LVAL m_as_lval;
    LVAL x_as_lval = xtxr01_Get_A_XTXR();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xtxr09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xtxr28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xtxr28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two textures for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {
	char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xtxr29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xtxr01_Get_A_XTXR();
    LVAL n_as_lval = xtxr01_Get_A_XTXR();
    xllastarg();
    return xtxr28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xtxr40_Get_Msg -- Get keyword properties.                        */

LVAL xtxr39_Get( lv_texture )
LVAL             lv_texture;
{
    ctxr_rec* texture= xtxr9c_Find_Immediate_Base( lv_texture );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL lv_result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if        (key == k_minifyfn) {

	switch (texture->r.min_filter) {
	case GT_POINT           : lv_result = k_point;	         break;
	case GT_BILINEAR        : lv_result = k_bilinear;        break;
	case GT_MIPMAP_POINT    : lv_result = k_mipmappoint;     break;
	case GT_MIPMAP_LINEAR   : lv_result = k_mipmaplinear;    break;
	case GT_MIPMAP_BILINEAR : lv_result = k_mipmapbilinear;  break;
	case GT_MIPMAP_TRILINEAR: lv_result = k_mipmaptrilinear; break;
	default:
	    xlfail("bad texture state");
	}

    } else if (key == k_magnifyfn) {

	switch (texture->r.mag_filter) {
	case GT_POINT           : lv_result = k_point;	         break;
	case GT_BILINEAR        : lv_result = k_bilinear;        break;
	default:
	    xlfail("bad texture state");
	}


    } else if (key == k_wraptype) {

	switch (texture->r.wrap_type) {
	case GT_REPEAT          : lv_result = k_repeat;	         break;
	case GT_CLAMP           : lv_result = k_clamp;           break;
	default:
	    xlfail("bad texture state");
	}

    } else if (key == k_mergetype) {

	switch (texture->r.merge_type) {
	case GT_DECAL           : lv_result = k_decal;	         break;
	case GT_MODULATE        : lv_result = k_modulate;        break;
	default:
	    xlfail("bad texture state");
	}

    } else if (key == k_graphicrelation) {

        lv_result = xthl90_GetObjectVariable( lv_texture, s_graphicrelation );

    } else if (key == k_textureis) {

	switch (texture->r.texture_is) {
        case GT_BY_DEFAULT: lv_result = NIL      ; break;
        case GT_BY_POINT:   lv_result = k_bypoint; break;
        case GT_BY_FACET:   lv_result = k_byfacet; break;
        case GT_BY_ON:      lv_result = k_on     ; break;
        case GT_BY_OFF:     lv_result = k_off    ; break;
	default:
	    abort();
	}

    } else {

	/* If this isn't a property we know, do a generic get property: */
        lv_result = xthl8a_GetObjectProp( lv_texture, key, default_val, got_default );
    }
    return lv_result;
}

LVAL xtxr40_Get_Msg()
/*-
    Return keyword properties for a texture object.
-*/
{
    return xtxr39_Get( xtxr01_Get_A_XTXR() );
}

/* }}} */
/* {{{ xtxr42_Set_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Set, update XTXR_PROPS and xtxr94_ProplistNth. */
#define XTXR_PROPS (6)

LVAL xtxr41_Set( lv_texture )
LVAL             lv_texture;
{
    ctxr_rec* texture = xtxr9c_Find_Immediate_Base( lv_texture );

    while (moreargs()) {
        LVAL init = xlgasymbol();
	LVAL arg;

        if        (init == k_minifyfn) {

	    LVAL lv_key = xlgetarg();
	    if (lv_key == k_point) {
		texture->r.min_filter	= GT_POINT;
		texture->r.dirty	= TRUE;
	    } else if (lv_key == k_bilinear) {
		texture->r.min_filter	= GT_BILINEAR;
		texture->r.dirty	= TRUE;
	    } else if (lv_key == k_mipmappoint) {
		texture->r.min_filter	= GT_MIPMAP_POINT;
		texture->r.dirty	= TRUE;
	    } else if (lv_key == k_mipmaplinear) {
		texture->r.min_filter	= GT_MIPMAP_LINEAR;
		texture->r.dirty	= TRUE;
	    } else if (lv_key == k_mipmapbilinear) {
		texture->r.min_filter	= GT_MIPMAP_BILINEAR;
		texture->r.dirty	= TRUE;
	    } else if (lv_key == k_mipmaptrilinear) {
		texture->r.min_filter	= GT_MIPMAP_TRILINEAR;
		texture->r.dirty	= TRUE;
	    } else {
		xlerror("bad :minify-fn val",lv_key);
	    }

        } else if (init == k_magnifyfn) {

	    LVAL lv_key = xlgetarg();
	    if (lv_key == k_point) {
		texture->r.mag_filter	= GT_POINT;
		texture->r.dirty	= TRUE;
	    } else if (lv_key == k_bilinear) {
		texture->r.mag_filter	= GT_BILINEAR;
		texture->r.dirty	= TRUE;
	    } else {
		xlerror("bad :magnify-fn val",lv_key);
	    }

        } else if (init == k_mergetype) {

	    LVAL lv_key = xlgetarg();
	    if (lv_key == k_decal) {
		texture->r.merge_type	= GT_DECAL;
		texture->r.dirty	= TRUE;
	    } else if (lv_key == k_modulate) {
		texture->r.merge_type	= GT_MODULATE;
		texture->r.dirty	= TRUE;
	    } else {
		xlerror("bad :merge-type val",lv_key);
	    }

        } else if (init == k_wraptype) {

	    LVAL lv_key = xlgetarg();
	    if (lv_key == k_clamp) {
		texture->r.wrap_type	= GT_CLAMP;
		texture->r.dirty	= TRUE;
	    } else if (lv_key == k_repeat) {
		texture->r.wrap_type	= GT_REPEAT;
		texture->r.dirty	= TRUE;
	    } else {
		xlerror("bad :wrap-type val",lv_key);
	    }

        } else if (init == k_graphicrelation) {

	    /* Yah, be nice to do some validation: */
	    LVAL lv_grl = xlgetarg();
	    if (!xgrlp(lv_grl))  xlerror("bad :graphic-relation val",lv_grl);
	    xthl91_SetObjectVariable( lv_texture, s_graphicrelation, lv_grl );

        } else if (init == k_textureis) {

	    LVAL     lv_key= xlgetarg();
	    if      (lv_key==k_bypoint) texture->r.texture_is = GT_BY_POINT;
	    else if (lv_key==k_byfacet) texture->r.texture_is = GT_BY_FACET;
	    else if (lv_key==k_on     ) texture->r.texture_is = GT_BY_ON;
	    else if (lv_key==k_off    ) texture->r.texture_is = GT_BY_OFF;
	    else                        texture->r.texture_is = GT_BY_DEFAULT;

        } else if (init == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xtxrz7_Read_Xtxr_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_texture,
		getfile(xlgetfile()),
		xtxrz7_Read_Xtxr_From_File,NULL
	    );

	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_texture, init, xlgetarg() );
    }   }

    return lv_texture;
}

LVAL xtxr42_Set_Msg()
{   /* Read keyword properties for a texture object: */
    LVAL   lv_texture = xtxr01_Get_A_XTXR();
    LVAL   result     = xtxr41_Set( lv_texture );
    return result;
}

/* }}} */
/* {{{ xtxr91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xtxr90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XTXR_PROPS + x03d89_PropListLength( *pPropList ) );
}

LVAL xtxr91_ProplistLength_Msg()
{   /* Return length of propertylist: */
    return xtxr90_ProplistLength( xtxr01_Get_A_XTXR() );
}

/* }}} */
/* {{{ xtxr95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xtxr94_ProplistNth( g_as_lval )
LVAL                     g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL n_as_lval  = xlgafixnum();
    int  n          = getfixnum(n_as_lval);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case  0:    return k_minifyfn;
    case  1:    return k_magnifyfn;
    case  2:    return k_mergetype;
    case  3:    return k_wraptype;
    case  4:    return k_graphicrelation;
    case  5:    return k_textureis;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XTXR_PROPS,
	    n_as_lval,
	    default_val,
	    got_default
	);
    }
}

LVAL xtxr95_ProplistNth_Msg()
{/* Return Nth item from propertylist. */
    return xtxr94_ProplistNth( xtxr01_Get_A_XTXR() );
}

/* }}} */
/* {{{ xtxr9c_Find_Immediate_Base					*/

ctxr_rec* xtxr9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    ctxr_rec*txr = (ctxr_rec*) gobjimmbase( lv );
    return txr;
}

/* }}} */
/* {{{ xtxrF0_Copy_Contents_Msg--Copy contents of another xtxr into self*/

LVAL xtxrF1_Copy_Contents( m_as_lval, x_as_lval, depth )
LVAL			   m_as_lval, x_as_lval;
int						 depth;
{
    ctxr_rec * m = xtxr9c_Find_Immediate_Base( m_as_lval );
    ctxr_rec * x = xtxr9c_Find_Immediate_Base( x_as_lval );
    c03d_fileInfo f;

    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    f           = m->fileInfo;
    *m          = *x;
    m->fileInfo = f;

    return x_as_lval;
}

LVAL xtxrF0_Copy_Contents_Msg()
/*-
    Copy contents of another xtxr into self.
-*/
{
    LVAL m_as_lval = xtxr01_Get_A_XTXR();
    LVAL x_as_lval = xtxr01_Get_A_XTXR();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    return xtxrF1_Copy_Contents(m_as_lval,x_as_lval,depth);
}

/* }}} */
/* {{{ xtxrz7_Read_Xtxr_From_File                                       */

xtxrz7_Read_Xtxr_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   ctxr_rec* h;
    char*     p;
    if (version != CTXR_REC_VERSION) {
	xlerror("xtxrz7: unsupported version",cvfixnum(version));
    }
    h = (ctxr_rec*) gobjimmbase( lv );

    p = (char*) &h->CTXR_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CTXR_INT32_COUNT,  magic, fp );

#ifdef NOT_CURRENTLY_NEEDED
    p = (char*) &h->CTXR_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CTXR_FLOAT_COUNT,  magic, fp );
#endif
}

/* }}} */
/* {{{ xtxrwo_Write_Xtxr_To_Graphics_File                               */

xtxrwo_Write_Xtxr_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   ctxr_rec* h = (ctxr_rec*) gobjimmbase( lv );

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CTXR_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CTXR_FIRST_INT32, CTXR_INT32_COUNT, fdob);
#ifdef NOT_CURRENTLY_NEEDED
	cfil47_Write_Floats_To_File(&h->CTXR_FIRST_FLOAT, CTXR_FLOAT_COUNT, fdob);
#endif
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

