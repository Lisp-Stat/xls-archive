/* {{{ x01v.c -- bit vectors.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Jun13
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 92Apr08 jsp: from/to_buf.						*/
/* 92Feb02 jsp: x01v03_Show_Msg assumed nonzero size.  Fixed.		*/
/* 92Jan04 jdp: C fn version of push_extend_msg added.			*/
/* 91Jun13 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"

/* external variables */
extern LVAL obarray,s_unbound;
extern LVAL xlenv,xlfenv,xldenv;
extern LVAL k_initialcontents;
extern LVAL k_initialelement;
extern LVAL k_initializefromfile;
extern LVAL k_fillpointer;
extern LVAL lv_x01v;

#include "csry.h"
#include "c01v.h"
#include "clsp.h"
#include "../../xg.3d.fileio/c/cfil.h"

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 

#define loop    while (1)

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ x01v21_AdjustArray_Msg -- Change shape of bit array.		*/

LVAL x01v22_AdjustArray( gobject, new_h )
LVAL		         gobject;
csry_rec*			  new_h;
/*-
    Change shape of bit array, set up default values.
-*/
{
    csry_rec* h;
    int total_slots   = xsry20_ArrayTotalSize( new_h );
    int new_imm_bytes = ((total_slots +7) >> 3) + sizeof(csry_rec);
    int old_imm_bytes = getgobjimmbytes( gobject );
    int bytes_delta   = new_imm_bytes - old_imm_bytes;
    int bytes_offset  = gobjsizeinbytes( gobject );
    
    if (new_imm_bytes < sizeof(csry_rec)) {
        xlerror("negative array size",cvfixnum(new_imm_bytes));
    }

    xgbj48_Adjust( gobject, bytes_offset, bytes_delta );
    setgobjimmbytes( gobject, new_imm_bytes );
    h                 = xsry9c_Find_Immediate_Base( gobject );
    h->k_class	      = C03D_x01V;

    /* If we've added new bits, initialize them: */
    if (old_imm_bytes < new_imm_bytes) {
        char* base    = (char*) gobjimmbase( gobject );
        char* old_lim = base + old_imm_bytes;
        char* new_lim = base + new_imm_bytes;
        while (old_lim < new_lim) *old_lim++ = h->default_initializer.i;
    }

    /* Remember new shape: */
    {   int i;
	h->rank = new_h->rank;
	h->size = total_slots;
	for (i = h->rank;   i --> 0;   )   h->dim[i] = new_h->dim[i];
    }

    /* Make sure fill pointer gets copied: */
    h->dim[1] = new_h->dim[1];

    return gobject;
}

LVAL x01v27_AdjustArray( lv )
LVAL			 lv;
/*-
    Change shape of bit array, process 
    :INITIAL-CONTENTS and :INITIAL-ELEMENT.
-*/
{
    FORWARD LVAL x01v22_AdjustArray();
    csry_rec hx;
    xsry14_Figure_Shape(   &hx, moreargs() ? xlgetarg() : NIL );
    x01v22_AdjustArray( lv, &hx );

    while (moreargs()) {
        LVAL init = xlgasymbol();
        if (init == k_initialcontents) {

            /* Handle ":initial-contents '((1 0 0)(...)(...)(...)...)" */
            x01v15_Initial_Contents( lv, xlgalist(), 0, 0 );

        } else if (init == k_initialelement) {
 
            /* Handle ":initial-element 1 ..." */
            x01v16_Initial_Element( lv, xlgetarg() );

        } else if (init == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int x01vz7_Read_Array_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv,
		getfile(xlgetfile()),
		x01vz7_Read_Array_From_File,NULL
	    );

        } else if (init == k_fillpointer) {

            /* Handle ":fill-pointer t ..." */
            x01v30_Fill_Pointer( lv, xlgetarg() );

	} else {

            xlbadinit(init);
    }   }
    return lv;
}
LVAL x01v21_AdjustArray_Msg()
/*-
    Change shape of bit array.
-*/
{
    /* Get gobject and requested array size: */
    return x01v27_AdjustArray( xlgagobject() );
}
 
/* }}} */
/* {{{ x01v--Describe int01 to csry.c...'cept we rarely/never call it ;)*/

FORWARD int x01v55_From_Buf();
FORWARD int x01v56_To_Buf();
FORWARD int x01v58_Position();
FORWARD int x01v62_Delete();

LOCAL struct csry_struct x01v = {
    /* int  k_class             = */ C03D_x01V,
    /* int  sizeof_struct       = */ 0,
    /* int  (*list_to_struct)() = */ NULL,
    /* LVAL (*struct_to_list)() = */ NULL,
    /* int  (*sprintf_struct)() = */ NULL,
    /* int  (*initfn)        ();= */ NULL,
    /* int  (*copy_struct)   () = */ NULL,
    /* LVAL k_ary               = */ NULL,
    /* int  (*from_buf)      ();= */ x01v55_From_Buf,
    /* int  (*  to_buf)      ();= */ x01v56_To_Buf,
    /* LVAL (*adjust_array)  ();= */ x01v22_AdjustArray,
    /* int  (*position)      ();= */ x01v58_Position,
    /* int  (*delete)        ();= */ x01v62_Delete
};
/*-
    Describe our type to csry.c.
-*/

/* }}} */
/* {{{ x01v00_Is_New -- Initialize a new ary instance.			*/

LVAL x01v00_Is_New()
{   LVAL lv  = xlgagobject();
    x01v.k_ary = lv_x01v;

    /* Allocate space for array header, store s in it: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( csry_rec ) );
    {   csry_rec* h  = (csry_rec*) gobjimmbase( lv );
	h->s         = &x01v;
	h->fileInfo  = c03d_fileInfo_Init;
	h->default_initializer.i = 0;
        xfil50_Maybe_Note_New_3D_Object( lv );
    }

    return   x01v27_AdjustArray( lv );
}

/* }}} */
/* {{{ x01v01_Get_A_X01V -- Get arg, must be of class x01v.		*/

LVAL x01v01_Get_A_X01V()
/*-
    Get arg, must be of class x01v.
-*/
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class X01V has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a x01v.  Similarly,          */
    /* nobody but nobody has any business resizing a x01v,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!x01vp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) < sizeof(csry_rec) 
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ x01v03_Show_Msg -- Show the contents of a bit array.		*/

LVAL x01v03_Show_Msg()
/*-
    Show the contents of a csry.
-*/
{
    LVAL self,fptr;
    int i,j;
    char* m;
    csry_rec* h;

    /* get self and the file pointer */
    self = x01v01_Get_A_X01V();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the gobject's bit array: */
    m   = csry_base(self);
    h   = xsry9c_Find_Immediate_Base( self );
    i   = h->size;
    if (!i)   return self;
    loop {
	int val = *m++;
        for (j = 8;   j --> 0; ) {
	    int bit = val & 1;
	    char buf[256];
            val >>= 1;
	    sprintf( buf, "%d ", bit );
	    xlputstr(fptr,buf);
	    if (!--i) { xlterpri(fptr);  return self; }
	}    
    }
}

/* }}} */
/* {{{ x01v04_Aref_Msg -- Get given entry.				*/

LVAL x01v05_Aref( m_as_lval, i )
LVAL		  m_as_lval;
int                          i;
/*-
    Get given entry.
-*/
{
    char*    p = csry_base( m_as_lval );
    return cvfixnum(   (p[ i >> 3 ]   >>   (i & 7))    &    1   );
}

LVAL x01v04_Aref_Msg()
/*-
    Get given entry.
-*/
{
    LVAL m_as_lval = x01v01_Get_A_X01V();
    return x01v05_Aref(
        m_as_lval,
        xsry02_Get_Index( m_as_lval )
    );
}

/* }}} */
/* {{{ x01v06_Setf_Msg -- Set given entry.				*/

LVAL x01v07_Setf( p_as_lval, i, v_as_lval )
LVAL		  p_as_lval;
int			     i;
LVAL 				v_as_lval;
/*-
    Set given entry.
-*/
{
    char* p     = csry_base( p_as_lval );
    int  v;
    int  bit_no = i &  7;
    int  byt_no = i >> 3;
    char mask   = ~(1 << bit_no);

    /* If initializer is null, use default values.  */
    /* (This is also used to supply default values  */
    /* for new slots in redimensioned arrays.)	    */
    if (v_as_lval == NIL) {
        csry_rec* h = xsry9c_Find_Immediate_Base( p_as_lval );
        v = h->default_initializer.i & 1;
    } else {
	v  = (int) xgbj00_Get_Fix_Or_Flo_Num( v_as_lval ) ? 1 : 0;
    }	
    p[ byt_no ] = (p[ byt_no ] & mask)   |   (v << bit_no);
    return v_as_lval;
}

LVAL x01v06_Setf_Msg()
/*-
    Set given entry.
-*/
{
    LVAL m_as_lval = x01v01_Get_A_X01V();
    LVAL v_as_lval = xlgetarg();
    return x01v07_Setf(
        m_as_lval,
        xsry02_Get_Index( m_as_lval ),
        v_as_lval
    );
}

/* }}} */
/* {{{ x01v08_Copy_Msg -- Build copy of given BIT-ARRAY.		*/

LVAL x01v09_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given BIT-ARRAY.
-*/
{
    /* Create a new array to hold result: */
    csry_rec*mh = xsry9c_Find_Immediate_Base( m_as_lval );
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_x01v,k_new);
    xlpop();

    /* Set new matrix to shape of old matrix: */
    x01v22_AdjustArray( r_as_lval, mh );

    /* Copy contents of old matrix to new and return new: */
    {
	int       i =         getgobjimmbytes( m_as_lval );
	char *  src = (char*) gobjimmbase(     m_as_lval );
	char *  dst = (char*) gobjimmbase(     r_as_lval );
	while (--i >= 0)   *dst++ = *src++;
    }
    return r_as_lval;
}

LVAL x01v08_Copy_Msg()
/*-
    Build copy of given CSRY.
-*/
{   LVAL m_as_lval;
    LVAL x_as_lval = x01v01_Get_A_X01V();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = x01v09_Copy(x_as_lval);
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ x01v15_Initial_Contents -- Apply an initializer list.		*/

x01v15_Initial_Contents( m, init, dim, p )
LVAL	                 m, init;
int                               dim;
int 			               p;
/*-
    Apply an initializer list to array.
    m:     Array being initialized.
    init:  Our part of the initializer tree.
    dim:   Our dimension: 0 <= dim < array-rank.
    p:     Next slot to initialize.
-*/
{
    csry_rec* h    = xsry9c_Find_Immediate_Base( m );
    int       lim  = h->dim[ dim ];
    LVAL      here = init;
    int       i;
    if (dim >= h->rank)   xlbadinit(init);

    for (i = 0;   i < lim;   ++i) {
	if (!consp(here))     xlbadtype(init);
	if (dim == h->rank -1) {
            x01v07_Setf( m, p++, car(here) );
	} else {
	    p = x01v15_Initial_Contents( m, car(here), dim+1, p );
	}
	here = cdr(here);
    }
    if (!null(here))          xlbadtype(init);

    return p;
}

/* }}} */
/* {{{ x01v16_Initial_Element--Initialize array to given initial element*/

x01v16_Initial_Element( m, el )
LVAL		        m, el;
/*-
    Initialize array to given initial element.
    Apply an initializer list to array.
    m:     Array being initialized.
    el:    Initial element.
-*/
{
    csry_rec* h   = xsry9c_Find_Immediate_Base( m );
    int       len = (h->size +7) >> 3;
    int       byt = (int) xgbj00_Get_Fix_Or_Flo_Num( el ) ? 0xff : 0;
    h->default_initializer.i = byt;
#ifdef X01V_IS_PARANOID
    if (len < 0)   xlfail("x01v16:internal error");
#endif

    /* Copy initial element all over array: */
    memset( csry_base(m), byt, len );
}

/* }}} */
/* {{{ x01v23_RowMajorAref -- Get given entry, ignoring shape.		*/

LVAL x01v23_RowMajorAref( m_as_lval, i_as_lval )
LVAL		          m_as_lval, i_as_lval;
/*-
    Get given entry, ignoring shape.
-*/
{
    csry_rec* h = xsry9c_Find_Immediate_Base( m_as_lval );
    char*     p = csry_base(               m_as_lval );
    int       i = getfixnum( i_as_lval );
    if (i < 0 || i >= h->size) xlerror("bad index value",i_as_lval);
    return   x01v05_Aref( m_as_lval, i );
}

LVAL x01v24_RowMajorAref_Msg()
/*-
    Get given entry, ignoring shape.  Message protocol.
-*/
{
    LVAL m_as_lval = x01v01_Get_A_X01V();
    LVAL i_as_lval = xlgafixnum();
    xllastarg();
    return x01v23_RowMajorAref(m_as_lval,i_as_lval);
}

/* }}} */
/* {{{ x01v25_RowMajorSetf -- Set given entry, ignoring shape.		*/

LVAL x01v25_RowMajorSetf( m_as_lval, i_as_lval, v_as_lval )
LVAL		          m_as_lval, i_as_lval, v_as_lval;
/*-
    Set given entry, ignoring shape.
-*/
{
    csry_rec* h = xsry9c_Find_Immediate_Base( m_as_lval );
    int i = getfixnum( i_as_lval );
    if (i < 0 || i >= h->size) xlerror("bad index value",i_as_lval);
    x01v07_Setf( m_as_lval, i, v_as_lval );
    return v_as_lval;
}

LVAL x01v26_RowMajorSetf_Msg()
/*-
    Set given entry, ignoring shape.  Message protocol.
-*/
{
    LVAL m_as_lval = x01v01_Get_A_X01V();
    LVAL v_as_lval = xlgetarg();
    LVAL i_as_lval = xlgafixnum();
    xllastarg();
    return x01v25_RowMajorSetf(m_as_lval,i_as_lval,v_as_lval);
}

/* }}} */
/* {{{ x01v28_Equalp -- Compare two arrays for equality.		*/

LVAL x01v28_Equalp( m_as_lval, n_as_lval )
LVAL		    m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    /* Check that two arrays are same shape: */
    int d;
    csry_rec* mh = xsry9c_Find_Immediate_Base( m_as_lval );
    csry_rec* nh = xsry9c_Find_Immediate_Base( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (d = mh->rank;   d --> 0; ) {
        if (mh->dim[d] != nh->dim[d]) return NIL;
    }

    /* Check that two arrays have same contents: */
    {   int i;
	char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );

	/* Compare only up to limit indicated by fill pointers: */
	int len = mh->size;
	if (mh->rank == 1) {
	    d = mh->dim[1];   if (d >= 0 && d < len)   len = d;
	    d = nh->dim[1];   if (d >= 0 && d < len)   len = d;
	}
	i        = len >> 3;

	if (memcmp( mt, nt, i ))   return NIL;
	{
	    int bad_bits = 8 - (len & 7);
	    char m       = mt[i] << bad_bits;
	    char n       = nt[i] << bad_bits;
	    if (m != n)   return NIL;
        }
    }
    {   extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL x01v29_Equalp_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = x01v01_Get_A_X01V();
    LVAL n_as_lval = x01v01_Get_A_X01V();
    xllastarg();
    return x01v28_Equalp( m_as_lval, n_as_lval );
}

/* }}} */
/* {{{ x01v30_Fill_Pointer -- Set fill pointer to :FILL-POINTER value.	*/

x01v30_Fill_Pointer( m_as_lval, fill_as_lval )
LVAL		     m_as_lval, fill_as_lval;
/*-
    Set fill pointer to :FILL-POINTER value.
-*/
{
    csry_rec* h   = xsry9c_Find_Immediate_Base( m_as_lval );
    extern LVAL true;/*xlglob.c*/

    if (h->rank != 1) {
	xlerror(":FILL-POINTER: Array rank must be 1",m_as_lval);
    }

    if (null( fill_as_lval )) {
	h->dim[1] = 0;
        return;
    }

    if (fill_as_lval == true) {
	h->dim[1] = h->size;
        return;
    }

    if (fixp( fill_as_lval )) {
	int f = getfixnum( fill_as_lval );
	if (f >= 0 && f <= h->size) {
	    h->dim[1] = f;
	    return;
	}
    }

    xlerror("Bad :FILL-POINTER",fill_as_lval);
}

/* }}} */
/* {{{ x01v31_Get_Array_With_Fill_Pointer				*/

LVAL x01v31_Get_Array_With_Fill_Pointer( hp )
csry_rec**				 hp;
/*-
-*/
{
    LVAL a_as_lval = x01v01_Get_A_X01V();
    csry_rec* h    = xsry9c_Find_Immediate_Base( a_as_lval );
    if (h->rank != 1 || h->dim[1] < 0)   xlfail("No fill pointer",a_as_lval);
    *hp = h;
    return a_as_lval;
}

/* }}} */
/* {{{ x01v32_Fill_Pointer_Msg -- Return fill pointer.			*/

LVAL x01v32_Fill_Pointer_Msg()
/*-
    Return fill pointer.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = x01v31_Get_Array_With_Fill_Pointer( &h );
    return cvfixnum( h->dim[1] );
}

/* }}} */
/* {{{ x01v34_Vector_Push_Msg -- Push element onto array.		*/

LVAL x01v33_Vector_Push( a_as_lval, v_as_lval, h )
LVAL			 a_as_lval, v_as_lval;
csry_rec*				       h;
/*-
    Push element onto array, sufficient space guaranteed.
-*/
{                  
    int   v;
    char* p        = csry_base( a_as_lval );
    int   i        = h->dim[1];
    int  bit_no    = i &  7;
    int  byt_no    = i >> 3;
    char mask      = ~(1 << bit_no);
    if (i < 0 || i >= h->size)   return NIL;
    if (v_as_lval == NIL) {
        v = h->default_initializer.i;
    } else {
	v = (int) xgbj00_Get_Fix_Or_Flo_Num( v_as_lval );
    }	
    p[ byt_no ]    = (p[ byt_no ] & mask)   |   (v << bit_no);
    h->dim[1]      = i+1;
    return cvfixnum( i );
}
LVAL x01v34_Vector_Push_Msg()
/*-
    Push element onto array.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = x01v31_Get_Array_With_Fill_Pointer( &h );
    LVAL v_as_lval = moreargs() ? xlgetarg() : NIL;
    return x01v33_Vector_Push( a_as_lval, v_as_lval, h );
}

/* }}} */
/* {{{ x01v35_Vector_Push_Extend_Msg -- Push element onto array.	*/

LVAL x01vA0_Vector_Push_Extend( a_as_lval, v_as_lval, h )
LVAL                            a_as_lval, v_as_lval;
csry_rec*                                             h;
/*-
      Push element onto array.
-*/
{
    int i = h->dim[1];
    if (i == h->size) {
	csry_rec  hx;
	hx.rank   = 1;
	hx.dim[0] = (
            i +
            CSRY_VECTOR_EXPANSION_INCREMENT +
           (h->size / CSRY_VECTOR_EXPANSION_RATIO)
        );
	hx.dim[1] = h->dim[1];
        x01v22_AdjustArray( a_as_lval, &hx );
	/* Gotcha #1: Header may have moved: */
	h         = xsry9c_Find_Immediate_Base( a_as_lval );
#ifdef SHOULD_NOT_BE_NEEDED_NOW
	/* Gotcha #2: Fill pointer will have been zeroed: */
	h->dim[1] = i;
#endif
    }
    return x01v33_Vector_Push( a_as_lval, v_as_lval, h );
}
LVAL x01v35_Vector_Push_Extend_Msg()
/*-
    Push element onto array.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = x01v31_Get_Array_With_Fill_Pointer( &h );
    LVAL v_as_lval = moreargs() ? xlgetarg() : NIL;
    return x01vA0_Vector_Push_Extend( a_as_lval, v_as_lval, h );
}

/* }}} */
/* {{{ x01v36_Vector_Pop_Msg -- Pop element off array.			*/

LVAL x01v36_Vector_Pop_Msg()
/*-
    Pop element off array.
-*/
{
    csry_rec* h;
    LVAL a_as_lval = x01v31_Get_Array_With_Fill_Pointer( &h );
    char* p        = csry_base( a_as_lval );
    int i          = h->dim[1];

    if (i <= 0 || i > h->size)   xlfail("Can't pop empty vector",a_as_lval);

    h->dim[1]      = --i;

    return cvfixnum(   (p[ i >> 3 ]   >>   (i & 7))     &     1   );
}

/* }}} */
/* {{{ x01v37_Setf_Fill_Pointer_Msg -- Set fill pointer.		*/

LVAL x01v37_Setf_Fill_Pointer_Msg()
/*-
    Set fill pointer.
-*/
{
#ifdef STRICT_COMMONLISP
    csry_rec* h;
    LVAL a_as_lval = x01v31_Get_Array_With_Fill_Pointer( &h );
#else
    /* We allow adding a fill pointer to our arrays after-the-fact: */
    LVAL a_as_lval = x01v01_Get_A_X01V();
#endif
    LVAL fill_as_lval = xlgetarg();
    x01v30_Fill_Pointer( a_as_lval, fill_as_lval );
    return   fill_as_lval;
}

/* }}} */
/* {{{ x01v55_From_Buf -- Copy from buffer into array.			*/

int x01v55_From_Buf( v_as_lval, buf, cnt, pos, ifv )
LVAL                 v_as_lval;
struct xlsp05_buf *             buf;
int                                  cnt, pos;
unsigned char *                                ifv;
/*-
    Copy from buffer into array.
-*/
{
    unsigned char * vt;
    if (!x01vp( v_as_lval ))   xlbadtype( v_as_lval );
    vt  = (unsigned char*)     csry_base( v_as_lval );
    if (pos & 7)   abort();
    vt += (pos >> 3);

    switch (buf->buf_type) {

    case XLSP_TYPE_BIT:
	xlsp31_Copy_Bit_To_Bit( vt, buf->u.bit, cnt, ifv );
        break;

    case XLSP_TYPE_FIX:
	xlsp34_Copy_Fix_To_Bit( vt, buf->u.fix, cnt, ifv );
        break;

    case XLSP_TYPE_FLO:
	xlsp37_Copy_Flo_To_Bit( vt, buf->u.flo, cnt, ifv );
        break;

    default:
        abort();
    }

    return 0;
}

/* }}} */
/* {{{ x01v56_To_Buf -- Copy from array into buffer.			*/

int x01v56_To_Buf( v_as_lval, buf, cnt, pos, ifv )
LVAL               v_as_lval;
struct xlsp05_buf *           buf;
int                                cnt, pos;
unsigned char *                              ifv;
{   unsigned char* vt;
    if (!x01vp( v_as_lval ))         xlbadtype( v_as_lval );
    vt            = (unsigned char*) csry_base( v_as_lval );

    xlsp31_Copy_Bit_To_Bit( buf->u.fix, vt+(pos>>3), cnt, ifv );
    buf->buf_type = XLSP_TYPE_BIT;

    return 0;
}

/* }}} */
/* {{{ x01v58_Position -- Find value within buffer.			*/

int x01v58_Position( lv_ary, lv_arg )
LVAL                 lv_ary, lv_arg;
{
    csry_rec* mh = xsry9c_Find_Immediate_Base( lv_ary );

    int len3;
    int i;
    char  arg;
    unsigned char* mt = (unsigned char*) csry_base( lv_ary );

    /* Compare only up to limit indicated by fill pointers: */
    int len = mh->size;
    if (mh->rank == 1) {
	int d = mh->dim[1];   if (d >= 0 && d < len)   len = d;
    }
    len3 = len >> 3;
    if (lv_arg == cvfixnum(0)) {
	int c;
	for (i = 0;  i < len3;  ++i) {
	    c = mt[i];
	    if (c == 0xff)    continue;
	    if (!(c & 0x80))  return (i << 3) + 0;
	    if (!(c & 0x40))  return (i << 3) + 1;
	    if (!(c & 0x20))  return (i << 3) + 2;
	    if (!(c & 0x10))  return (i << 3) + 3;
	    if (!(c & 0x08))  return (i << 3) + 4;
	    if (!(c & 0x04))  return (i << 3) + 5;
	    if (!(c & 0x02))  return (i << 3) + 6;
	    if (!(c & 0x01))  return (i << 3) + 7;
	}
	c = mt[len3];
	i = len & 7;
	if (!i--)   return -1;	if (!(c & 0x80))  return (len3 << 3) + 0;
	if (!i--)   return -1;	if (!(c & 0x40))  return (len3 << 3) + 1;
	if (!i--)   return -1;	if (!(c & 0x20))  return (len3 << 3) + 2;
	if (!i--)   return -1;	if (!(c & 0x10))  return (len3 << 3) + 3;
	if (!i--)   return -1;	if (!(c & 0x08))  return (len3 << 3) + 4;
	if (!i--)   return -1;	if (!(c & 0x04))  return (len3 << 3) + 5;
	if (!i--)   return -1;	if (!(c & 0x02))  return (len3 << 3) + 6;
	if (!i--)   return -1;	if (!(c & 0x01))  return (len3 << 3) + 7;
	return -1;
    } else {
	int c;
	for (i = 0;  i < len3;  ++i) {
	    c = mt[i];
	    if (c == 0x00)    continue;
	    if ( (c & 0x80))  return (i << 3) + 0;
	    if ( (c & 0x40))  return (i << 3) + 1;
	    if ( (c & 0x20))  return (i << 3) + 2;
	    if ( (c & 0x10))  return (i << 3) + 3;
	    if ( (c & 0x08))  return (i << 3) + 4;
	    if ( (c & 0x04))  return (i << 3) + 5;
	    if ( (c & 0x02))  return (i << 3) + 6;
	    if ( (c & 0x01))  return (i << 3) + 7;
	}
	c = mt[len3];
	i = len & 7;
	if (!i--)   return -1;	if ( (c & 0x80))  return (len3 << 3) + 0;
	if (!i--)   return -1;	if ( (c & 0x40))  return (len3 << 3) + 1;
	if (!i--)   return -1;	if ( (c & 0x20))  return (len3 << 3) + 2;
	if (!i--)   return -1;	if ( (c & 0x10))  return (len3 << 3) + 3;
	if (!i--)   return -1;	if ( (c & 0x08))  return (len3 << 3) + 4;
	if (!i--)   return -1;	if ( (c & 0x04))  return (len3 << 3) + 5;
	if (!i--)   return -1;	if ( (c & 0x02))  return (len3 << 3) + 6;
	if (!i--)   return -1;	if ( (c & 0x01))  return (len3 << 3) + 7;
	return -1;
    }
}

/* }}} */
/* {{{ x01v62_Delete -- Find value within buffer.			*/

int x01v62_Delete( lv_ary, start, end )
LVAL               lv_ary;
int			   start, end;
{
    int val;
    csry_rec* mh     = xsry9c_Find_Immediate_Base( lv_ary );
    unsigned char* p = (unsigned char*) csry_base( lv_ary );
    int  len = mh->size;
    int  gap = end-start;
    int  i;
    /* Respect fillpointer. We know mh->rank==1 */
    if (mh->dim[1] >= 0) len = mh->dim[1];
    if (!len)   return -1;

    /* En-lil grant we don't do this often! */
    for (i = start; i < len-gap; ++i) {
        /* mt[i] = mt[i+gap]; */

	/* Figure coords of source bit: */
	int  src_bit_no    = (i+gap) &  7;
	int  src_byt_no    = (i+gap) >> 3;

	/* Fetch bit: */
	int  v           = (p[ src_byt_no ]   >>   src_bit_no)    &    1;

	/* Figure coords of destination bit: */
	int  dst_bit_no = i &  7;
	int  dst_byt_no = i >> 3;
	char dst_mask   = ~(1 << dst_bit_no);

	/* Store bit: */
        p[ dst_byt_no ] = (p[ dst_byt_no ] & dst_mask)   |   (v << dst_bit_no);
    }

    /* Set fillpointer to reflect new length: */
    mh->dim[1] = len-gap;
    return 0;
}

/* }}} */
/* {{{ x01vz7_Read_Array_From_File					*/

x01vz7_Read_Array_From_File( dum, lv, fp, magic, version )
char                        *dum;
LVAL                              lv;
FILE                                 *fp;
CSRY_INT32                                magic;
int                                              version;
{   csry_rec* h;
    char*     p;
    if (version != CSRY_REC_VERSION) {
	xlerror("x01v57: unsupported version",cvfixnum(version));
    }
    h = (csry_rec*) gobjimmbase( lv );
    p = (char*) (h+1);
    p = cfil52_Read_Bytes_From_File(   p, (h->size+7)>>3, magic, fp );
}

/* }}} */
/* {{{ x01vwo_Write_X01v_To_Graphics_File                               */

x01vwo_Write_X01v_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    char buf[256];
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new ",getstring(name));
    xsry88_Build_Shape_Info_String(buf,lv);
    fputs(buf,fdoa);
    xsry87_Build_Default_Element_String(buf,lv);
    fputs(buf,fdoa);
    fputs("\n  :initialize-from-file xfil-fd-binary))\n",fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   csry_rec* h = xsry9c_Find_Immediate_Base( lv );

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CSRY_REC_VERSION );

	/* Write out array contents: */
	cfil45_Write_Bytes_To_File( (char*)(h+1), (h->size+7)>>3, fdob );
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
