/* {{{ xlgt.c -- light objects.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Aug15
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 95Apr11 jsp: Get_Light_Rec() was still calling gobjimmbase()		*/
/*		instead of xtfm9c_Find_Immediate_Base() resulting	*/
/*		in :per-frame-hook on light transforms not running.	*/
/* 91Aug15 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xlgt;

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 
LVAL xlgt41_Set();

#include <math.h>
#include "geo.h"
#include "csry.h"
#include "clgt.h"
#include "ctfm.h"
#include "lib.h"
#include "cgrl.h"
#include "c03d.h"
#include "cthl.h"
#include "../../xg.3d.fileio/c/cfil.h"

#define iabs(x)	((x) >= 0 ? (x) : -(x))
#define DEGREES_TO_RADIANS (3.1415926535897932384626 / 180.0)
#define RADIANS_TO_DEGREES (180.0 / 3.1415926535897932)

LOCAL xlgt02_Update_State();
LVAL* xlgt33_Find_Viewing_Transform();
clgt_rec* xlgt9c_Find_Immediate_Base();

extern LVAL k_left;
extern LVAL k_right;
extern LVAL k_top;
extern LVAL k_bottom;
extern LVAL k_near;
extern LVAL k_far;
extern LVAL k_ambientcolor;
extern LVAL k_color;
extern LVAL k_degrees;
extern LVAL k_diameter;
extern LVAL k_islocal;
extern LVAL k_location;
extern LVAL k_radians;
extern LVAL k_show;
extern LVAL k_target;
extern LVAL k_transform;
extern LVAL k_up;
extern LVAL lv_xtfm;
extern LVAL s_viewing_transform;
extern LVAL k_initializefromfile;

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xlgt00_Is_New -- Initialize a new xlgt instance.			*/

gt_mat xlgt_ident = {
    1.0, 0.0, 0.0, 0.0,
    0.0, 1.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
};
clgt_rec xlgt_defaults = {
    C03D_xLGT,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */
    {   1,			/* light_ID			*/   
	0,			/* light_is_local		*/   
	1,			/* dirty			*/

	{0.0, 0.0, 0.0},	/* ambient_color		*/
	{1.0, 1.0, 1.0},	/* light_color			*/
	NULL,			/* location			*/
    },
};

xlgt0_Init() {
    /* Can't figure out how to get MIPS CC to do this initialization, so: */
    xlgt_defaults.r.location = &xlgt_ident;
}

LVAL xlgt00_Is_New()
/*-
    Initialize a new xlgt instance.
-*/
{
    static lights_created = 5;/* 0 is SGI GL-reserved, we use 1 internally. */
			      /* 2,3,4,5 are just fudge factor.             */
  
    LVAL viewing_transform;
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    clgt_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xlgtp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( clgt_rec ) );

    /* Initialize light record to reasonable default values: */
    r	= (clgt_rec*) gobjimmbase( lv );
   *r   = xlgt_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    /* Issue each light a unique id: */
    r->r.light_ID   = ++lights_created;
    r->r.dirty      = TRUE;

    {   struct ctfm_Put_Rec r;
        /* Parse user args and save in r.  Can't apply them until   */
        /* we've created viewing matrix, and can't create that      */
	/* matrix until we've parsed the args. Sigh.		    */
	xlgt41_Set( lv, &r );

	/* Create our initial viewing_transform and save  */
	/* it in instance variable VIEWING_TRANSFORM:     */
	{   LVAL* p_view = xlgt33_Find_Viewing_Transform( lv );
	    if (*p_view == NULL) { 
		viewing_transform  = xsendmsg0(lv_xtfm,k_new);
	        *p_view = viewing_transform;
	}   }

	/* Apply state in self and r to update our matrix: */
	xlgt02_Update_State( lv, &r );
    }

    return lv;
}

/* }}} */
/* {{{ xlgt01_Get_A_XLGT -- Get arg, must be of class xlgt.		*/

LVAL xlgt01_Get_A_XLGT()
{   LVAL m_as_lval = xlgagobject();

    /* Nobody but class XLGT has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xlgt.  Similarly,          */
    /* nobody but nobody has any business resizing a xlgt,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xlgtp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) != sizeof(clgt_rec) 
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xlgt02_Update_State -- Apply Put_Rec to our state.		*/

LOCAL xlgt02_Update_State( lv_light, r )
LVAL			   lv_light;
struct ctfm_Put_Rec		     *r;
/*-
    Apply Put_Rec to our state.
-*/
{
    LVAL* p_viewing_transform  = xlgt33_Find_Viewing_Transform( lv_light );
    xtfmc2_Update_State( *p_viewing_transform, r );
}

/* }}} */
/* {{{ xlgt03_Show_Msg -- Show the contents of a clgt.			*/

LVAL xlgt03_Show_Msg()
/*-
    Show the contents of a lgt.
-*/
{
    LVAL self,fptr;

    /* get self and the file pointer */
    self = xlgt01_Get_A_XLGT();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the lgt record: */
    {
	LVAL* p_view   = xlgt33_Find_Viewing_Transform( self );
	gt_light_rec * p = xlgt04_Get_Light_Rec( self );
	libE5_xlprint_int(   "light_is_local",  p->light_is_local, fptr );
	libE5_xlprint_int(   "light_ID"      ,  p->light_ID      , fptr );
	libE7_xlprint_point( "ambient_color" , &p->ambient_color , fptr );
	libE7_xlprint_point( "light_color  " , &p->light_color   , fptr );
	xlputstr(fptr,"  location tranform\n");
	xsendmsg0( *p_view,  k_show );
/*	libE8_xlprint_matrix("location" ,       p->location      , fptr );*/
    }

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xlgt04_Get_Light_Rec -- Get pointer to internal record.		*/

gt_light_rec * xlgt04_Get_Light_Rec( lv_light ) /* Called by xtfm.c */
LVAL				     lv_light;
/*-
    Get pointer to internal record.
-*/
{
    /* This function sorta breaks the privacy of the class... that's	*/
    /* pretty normal in interfaces to the machine-dependent code   :).	*/
    /* Probably need a way of formally splitting a class this way. :)	*/

    /* Update the pointer to our transform matrix, then return: */
    clgt_rec * l   = xlgt9c_Find_Immediate_Base(    lv_light );
    LVAL* p_view   = xlgt33_Find_Viewing_Transform( lv_light );
#ifdef OLD
    ctfm_rec * t   = (ctfm_rec*) gobjimmbase(      *p_view    );
#else
    ctfm_rec * t   = xtfm9c_Find_Immediate_Base(   *p_view    );
#endif
    l->r.location  = (gt_mat*) &t->m;

    return &l->r;
}

/* }}} */
/* {{{ xlgt08_Copy_Msg -- Build copy of given CLGT.			*/

LVAL xlgt09_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given CLGT.
-*/
{
    /* Create a new gobject to hold result: */
    clgt_rec*mh = xlgt9c_Find_Immediate_Base( m_as_lval );
    clgt_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xlgt,k_new);
    xlpop();
    nh = (clgt_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}

LVAL xlgt08_Copy_Msg()
/*-
    Build copy of given CLGT.
-*/
{   LVAL m_as_lval;
    LVAL x_as_lval = xlgt01_Get_A_XLGT();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xlgt09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xlgt28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xlgt28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {
	char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xlgt29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xlgt01_Get_A_XLGT();
    LVAL n_as_lval = xlgt01_Get_A_XLGT();
    xllastarg();
    return xlgt28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xlgt33_Find_Viewing_Transform					*/

LVAL* xlgt33_Find_Viewing_Transform( lv )
LVAL                     	     lv;
{   /* Return pointer to viewing transform slot in lgt: */
    LVAL*pLval;
    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
        lv,
        getclass( lv ),
        s_viewing_transform,
        &pLval
    );
    return pLval;
}

/* }}} */
/* {{{ xlgt35_Find_Viewing_Matrix					*/

xlgt35_Find_Viewing_Matrix( lv_light, view )
LVAL			    lv_light;
ctfm_rec			     **view ;
{   /* Build C pointers to our transform matrices. */
    LVAL* p_viewing_transform  = xlgt33_Find_Viewing_Transform( lv_light );
   *view             = (ctfm_rec*) gobjimmbase( *p_viewing_transform );
    !xtfmp(*p_viewing_transform) && xlbadtype(  *p_viewing_transform );
}

/* }}} */
/* {{{ xlgt40_Get_Msg -- Get keyword properties.                        */

LVAL xlgt39_Get( lv_light )
LVAL             lv_light;
{
    clgt_rec* light = xlgt9c_Find_Immediate_Base( lv_light );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL result;
    ctfm_rec*viewing_mat;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    xlgt35_Find_Viewing_Matrix( lv_light, &viewing_mat );

    if (key == k_transform) {

	LVAL* p_view = xlgt33_Find_Viewing_Transform( lv_light );
	result = *p_view;

    } else if (key == k_location) {

	/* Fetch light location: */
	geo_point location;
	LVAL* p_view = xlgt33_Find_Viewing_Transform( lv_light );
	xtfma0_Compute_Location( &location, *p_view );
	result = lib14_Point_To_List( &location );

    } else if (key == k_target) {

	/* Fetch target point: */
        result = lib14_Point_To_List( &viewing_mat->target );

    } else if (key == k_up) {

	/* Fetch up:" */
        result = lib14_Point_To_List( &viewing_mat->up );

    } else if (key == k_radians) {

	/* Fetch angle: */
	result = cvflonum( viewing_mat->angle_of_view_in_radians );

    } else if (key == k_degrees) {

	/* Fetch angle: */
	result = cvflonum(viewing_mat->angle_of_view_in_radians*RADIANS_TO_DEGREES);

    } else if (key == k_diameter) {

	/* Fetch diameter: */
	result = cvflonum( viewing_mat->diameter );

    } else if (key == k_islocal) {

        extern LVAL true;/*xlglob.c*/
        result = light->r.light_is_local ? true : NIL;

    } else if (key == k_color) {

        result = lib14_Point_To_List( &light->r.light_color );

    } else if (key == k_ambientcolor) {

        result = lib14_Point_To_List( &light->r.ambient_color );

    } else {

	/* If this isn't a property we know, do a generic get property: */
        result = xthl8a_GetObjectProp( lv_light, key, default_val,got_default );
    }
    return result;
}

LVAL xlgt40_Get_Msg()
/*-
    Return keyword properties for a light object.
-*/
{
    return xlgt39_Get( xlgt01_Get_A_XLGT() );
}

/* }}} */
/* {{{ xlgt42_Set_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Set, update XLGT_PROPS and xlgt94_ProplistNth. */
#define XLGT_PROPS (9)

LVAL xlgt41_Set( lv_light, r )
LVAL             lv_light;
struct ctfm_Put_Rec	  *r;
{
    clgt_rec* light = xlgt9c_Find_Immediate_Base( lv_light );

    ctfm70_Initialize_Put_Rec( r );

    while (moreargs()) {
        LVAL init = xlgasymbol();
	LVAL arg;

	if (init == k_transform) {

	    /* Fetch light location: */
	    LVAL xtfm01_Get_A_XTFM();
	    LVAL* p_view = xlgt33_Find_Viewing_Transform( lv_light );
	   *p_view = xtfm01_Get_A_XTFM();

        } else if (init == k_location) {

            /* Handle ":location '(1 1 1)" */
            lib16_List_To_Point( &r->location, arg=xlgalist() ); 
	    r->location_is_valid = TRUE;

        } else if (init == k_target) {

            /* Handle ":target '(1 1 1)" */
            lib16_List_To_Point( &r->target, xlgalist() ); 
	    r->target_is_valid = TRUE;

        } else if (init == k_up) {

            /* Handle ":up '(0 1 0)" */
            lib16_List_To_Point( &r->up, xlgalist() ); 
	    r->up_is_valid	= TRUE;

        } else if (init == k_radians) {

            /* Handle ":radians 1.1" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp <= 0.0 || tmp >= 3.14159)   xlfail("silly view angle");

	    r->angle_of_view_in_radians = tmp;
	    r->angle_is_valid		= TRUE;

        } else if (init == k_degrees) {

            /* Handle ":degrees 15" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() ) * DEGREES_TO_RADIANS;
	    if (tmp <= 0.0 || tmp >= 3.14159)   xlfail("silly view angle");

	    r->angle_of_view_in_radians = tmp;
	    r->angle_is_valid		= TRUE;

        } else if (init == k_diameter) {

            /* Handle ":diameter 12" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp <= 0.0)   xlfail("nonpositive diameter");

	    r->diameter			= tmp;
	    r->diameter_is_valid	= TRUE;

        } else if (init == k_left) {

	    r->left		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->left_is_valid	= TRUE;

        } else if (init == k_right) {

	    r->roit		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->roit_is_valid	= TRUE;

        } else if (init == k_top) {

	    r->top		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->top_is_valid	= TRUE;

        } else if (init == k_bottom) {

	    r->bot		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->bot_is_valid	= TRUE;

        } else if (init == k_near) {

	    r->near		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->near_is_valid	= TRUE;

        } else if (init == k_far) {

	    r->far		= xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    r->far_is_valid	= TRUE;

	} else if (init == k_islocal) {

	    light->r.light_is_local = !null(xlgetarg());
	    light->r.dirty	    = TRUE;

        } else if (init == k_color) {

            /* Handle ":color '(1 1 1)" */
/* TEST!  kph 98Oct02 */
            /* lib17_List_To_Color( &light->r.light_color, xlgalist() ); */
            lib16_List_To_Point( &light->r.light_color, xlgalist() ); 
	    light->r.dirty	    = TRUE;

        } else if (init == k_ambientcolor) {

            /* Handle ":ambient-color '(1 1 1)" */
/* TEST!  kph 98Oct02 */
            /* lib17_List_To_Color( &light->r.ambient_color, xlgalist() ); */
            lib16_List_To_Point( &light->r.ambient_color, xlgalist() ); 
	    light->r.dirty	    = TRUE;

        } else if (init == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xlgtz7_Read_Xlgt_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_light,
		getfile(xlgetfile()),
		xlgtz7_Read_Xlgt_From_File,NULL
	    );

	} else {

            /* If this isn't a property we know, do a generic put property: */
            x03d9b_SetObjectProp( lv_light, init, xlgetarg() );
        }
    }

    return lv_light;
}

LVAL xlgt42_Set_Msg()
/*-
    Read keyword properties for a light object.
-*/
{
    struct ctfm_Put_Rec r;
    LVAL   lv_light = xlgt01_Get_A_XLGT();
    LVAL   result    = xlgt41_Set( lv_light, &r );
    xlgt02_Update_State(	   lv_light, &r );
    return result;
}

/* }}} */
/* {{{ xlgt44_Frame_Things_Msg -- Find a frame containing things.       */

LVAL xlgt44_Frame_Things_Msg()
{   LVAL   lv_xlgt = xlgt01_Get_A_XLGT();
    LVAL *plv_xtfm = xlgt33_Find_Viewing_Transform( lv_xlgt );
    return x03d44_Frame_Things( lv_xlgt, *plv_xtfm, 1.0 );
}

/* }}} */
/* {{{ xlgt91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xlgt90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XLGT_PROPS + x03d89_PropListLength( *pPropList ) );
}

LVAL xlgt91_ProplistLength_Msg()
/*-
    Return length of propertylist.
-*/
{
    return xlgt90_ProplistLength( xlgt01_Get_A_XLGT() );
}

/* }}} */
/* {{{ xlgt95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xlgt94_ProplistNth( g_as_lval )
LVAL                     g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL n_as_lval  = xlgafixnum();
    int  n          = getfixnum(n_as_lval);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case 0:    return k_location;
    case 1:    return k_target;
    case 2:    return k_up;
    case 3:    return k_radians;
    case 4:    return k_degrees;
    case 5:    return k_diameter;
    case 6:    return k_islocal;
    case 7:    return k_color;
    case 8:    return k_ambientcolor;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XLGT_PROPS,
	    n_as_lval,
	    default_val,
	    got_default
	);
    }
}

LVAL xlgt95_ProplistNth_Msg()
/*-
    Return Nth item from propertylist.
-*/
{
    return xlgt94_ProplistNth( xlgt01_Get_A_XLGT() );
}

/* }}} */
/* {{{ xlgt9c_Find_Immediate_Base					*/

clgt_rec* xlgt9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    clgt_rec*lgt = (clgt_rec*) gobjimmbase( lv );
    return lgt;
}

/* }}} */
/* {{{ xlgtF0_Copy_Contents_Msg--Copy contents of another xlgt into self*/

LVAL xlgtF1_Copy_Contents( lv_m, lv_x, depth )
LVAL			   lv_m, lv_x;
int				       depth;
{
    clgt_rec * m = xlgt9c_Find_Immediate_Base( lv_m );
    clgt_rec * x = xlgt9c_Find_Immediate_Base( lv_x );

    x03d81_CopyProplist( lv_m, lv_x, depth );
    {   gt_mat *      t;
        c03d_fileInfo f;
        f  = m->fileInfo;
        t  = m->r.location;
        *m = *x;
        m->fileInfo   = f;	/* Restore clobbered file info */
        m->r.location = t;	/* Restore clobbered matrix pointer */
    }
 
    /* Need to copy contents of light transforms, too: */
    {   LVAL* plv_m   = xlgt33_Find_Viewing_Transform( lv_m );
	LVAL* plv_x   = xlgt33_Find_Viewing_Transform( lv_x );
	xtfmF1_Copy_Contents( *plv_m, *plv_x, depth );
    }

    return lv_x;
}

LVAL xlgtF0_Copy_Contents_Msg()
/*-
    Copy contents of another xlgt into self.
-*/
{
    LVAL m_as_lval = xlgt01_Get_A_XLGT();
    LVAL x_as_lval = xlgt01_Get_A_XLGT();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    return xlgtF1_Copy_Contents(m_as_lval,x_as_lval,depth);
}

/* }}} */
/* {{{ xlgtz7_Read_Xlgt_From_File                                       */

xlgtz7_Read_Xlgt_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   clgt_rec* h;
    char*     p;
    if (version != CLGT_REC_VERSION) {
	xlerror("xlgtz7: unsupported version",cvfixnum(version));
    }
    h = (clgt_rec*) gobjimmbase( lv );

    p = (char*) &h->CLGT_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CLGT_INT32_COUNT,  magic, fp );

    p = (char*) &h->CLGT_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CLGT_FLOAT_COUNT,  magic, fp );
}

/* }}} */
/* {{{ xlgtwo_Write_Xlgt_To_Graphics_File                               */

xlgtwo_Write_Xlgt_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   clgt_rec* h = (clgt_rec*) gobjimmbase( lv );
	char*     p;

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CLGT_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CLGT_FIRST_INT32, CLGT_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CLGT_FIRST_FLOAT, CLGT_FLOAT_COUNT, fdob);
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

