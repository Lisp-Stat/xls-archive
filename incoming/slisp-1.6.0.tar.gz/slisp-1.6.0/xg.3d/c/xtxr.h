/* {{{ xtxr.h -- materials.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94Mar31
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1994, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xtxr;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xtxr00_Is_New();
extern LVAL xtxr08_Copy_Msg();
extern LVAL xtxr03_Show_Msg();
extern LVAL xtxr40_Get_Msg();
extern LVAL xtxr42_Set_Msg();
extern LVAL xtxr91_ProplistLength_Msg();
extern LVAL xtxr95_ProplistNth_Msg();
extern LVAL xtxrF0_Copy_Contents_Msg();



#ifndef EXTERNED_S_PROPERTYLIST
extern LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define EXTERNED_S_PROPERTYLIST
#endif

#ifndef EXTERNED_S_GRAPHICRELATION
extern LVAL s_graphicrelation;/* Symbol "GRAPHIC-RELATION" */
#define EXTERNED_S_GRAPHICRELATION
#endif

#ifndef EXTERNED_GRAPHICRELATION
extern LVAL k_graphicrelation;/* Keyword ":GRAPHIC-RELATION" */
#define EXTERNED_GRAPHICRELATION
#endif

#ifndef EXTERNED_MINIFYFN
extern LVAL k_minifyfn;  /* Keyword ":minify-fn" */
#define EXTERNED_MINIFYFN
#endif

#ifndef EXTERNED_MAGNIFYFN
extern LVAL k_magnifyfn;  /* Keyword ":magnify-fn" */
#define EXTERNED_MAGNIFYFN
#endif

#ifndef EXTERNED_MIPMAPPOINT
extern LVAL k_mipmappoint;  /* Keyword ":mipmap-point" */
#define EXTERNED_MIPMAPPOINT
#endif

#ifndef EXTERNED_MIPMAPLINEAR
extern LVAL k_mipmaplinear;  /* Keyword ":mipmap-linear" */
#define EXTERNED_MIPMAPLINEAR
#endif

#ifndef EXTERNED_MIPMAPBILINEAR
extern LVAL k_mipmapbilinear;  /* Keyword ":mipmap-bilinear" */
#define EXTERNED_MIPMAPBILINEAR
#endif

#ifndef EXTERNED_MIPMAPTRILINEAR
extern LVAL k_mipmaptrilinear;  /* Keyword ":mipmap-trilinear" */
#define EXTERNED_MIPMAPTRILINEAR
#endif

#ifndef EXTERNED_POINT
extern LVAL k_point;  /* Keyword ":point" */
#define EXTERNED_POINT
#endif

#ifndef EXTERNED_BILINEAR
extern LVAL k_bilinear;  /* Keyword ":bilinear" */
#define EXTERNED_BILINEAR
#endif

#ifndef EXTERNED_CLAMP
extern LVAL k_clamp;  /* Keyword ":clamp" */
#define EXTERNED_CLAMP
#endif

#ifndef EXTERNED_REPEAT
extern LVAL k_repeat;  /* Keyword ":repeat" */
#define EXTERNED_REPEAT
#endif

#ifndef EXTERNED_DECAL
extern LVAL k_decal;  /* Keyword ":decal" */
#define EXTERNED_DECAL
#endif

#ifndef EXTERNED_MODULATE
extern LVAL k_modulate;  /* Keyword ":modulate" */
#define EXTERNED_MODULATE
#endif

#ifndef EXTERNED_TEXTUREIS
extern LVAL k_textureis;  /* Keyword ":texture-is" */
#define EXTERNED_TEXTUREIS
#endif

#ifndef EXTERNED_ON
extern LVAL k_on;  /* Keyword ":on" */
#define EXTERNED_ON
#endif

#ifndef EXTERNED_OFF
extern LVAL k_off;  /* Keyword ":off" */
#define EXTERNED_OFF
#endif

#ifndef EXTERNED_BYPOINT
extern LVAL k_bypoint;  /* Keyword ":by-point" */
#define EXTERNED_BYPOINT
#endif

#ifndef EXTERNED_BYFACET
extern LVAL k_byfacetu;  /* Keyword ":by-facet" */
#define EXTERNED_BYFACET
#endif

#ifndef EXTERNED_MERGETYPE
extern LVAL k_mergeype;  /* Keyword ":merge-type" */
#define EXTERNED_MERGETYPE
#endif

#ifndef EXTERNED_WRAPTYPE
extern LVAL k_wraptype;  /* Keyword ":wrap-type" */
#define EXTERNED_WRAPTYPE
#endif

#ifndef EXTERNED_SHOW
extern LVAL k_show;/* Keyword ":show" */
#define EXTERNED_SHOW
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,	xtxr00_Is_New			)
DEFINE_SUBR(	NULL,	xtxr08_Copy_Msg			)
DEFINE_SUBR(	NULL,	xtxr03_Show_Msg			)
DEFINE_SUBR(	NULL,	xtxr40_Get_Msg			)
DEFINE_SUBR(	NULL,	xtxr42_Set_Msg			)
DEFINE_SUBR(	NULL,	xtxr91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,	xtxr95_ProplistNth_Msg		)
DEFINE_SUBR(	NULL,	xtxrF0_Copy_Contents_Msg	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xtxr;
LOCAL struct xtxr_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xtxr_table[] = {
    {	":ISNEW",		xtxr00_Is_New			},
    {	":COPY",		xtxr08_Copy_Msg			},
    {	":SHOW",		xtxr03_Show_Msg			},
    {	":GET", 		xtxr40_Get_Msg			},
    {	":SET", 		xtxr42_Set_Msg			},
    {	":PROPERTY-LIST-LENGTH",xtxr91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xtxr95_ProplistNth_Msg		},
    {	":COPY-CONTENTS",	xtxrF0_Copy_Contents_Msg	},

    {	NULL,			NULL				}
};



#ifndef DEFINED_S_PROPERTYLIST
LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define DEFINED_S_PROPERTYLIST
#endif

#ifndef DEFINED_S_GRAPHICRELATION
LVAL s_graphicrelation;/* Symbol "GRAPHIC-RELATION" */
#define DEFINED_S_GRAPHICRELATION
#endif

#ifndef DEFINED_GRAPHICRELATION
LVAL k_graphicrelation;/* Keyword ":GRAPHIC-RELATION" */
#define DEFINED_GRAPHICRELATION
#endif

#ifndef DEFINED_MINIFYFN
LVAL k_minifyfn;   /* Keyword ":minify-fn" */
#define DEFINED_MINIFYFN
#endif

#ifndef DEFINED_MAGNIFYFN
LVAL k_magnifyfn;   /* Keyword ":magnify-fn" */
#define DEFINED_MAGNIFYFN
#endif

#ifndef DEFINED_MIPMAPPOINT
LVAL k_mipmappoint;   /* Keyword ":mipmap-point" */
#define DEFINED_MIPMAPPOINT
#endif

#ifndef DEFINED_MIPMAPLINEAR
LVAL k_mipmaplinear;   /* Keyword ":mipmap-linear" */
#define DEFINED_MIPMAPLINEAR
#endif

#ifndef DEFINED_MIPMAPBILINEAR
LVAL k_mipmapbilinear;   /* Keyword ":mipmap-bilinear" */
#define DEFINED_MIPMAPBILINEAR
#endif

#ifndef DEFINED_MIPMAPTRILINEAR
LVAL k_mipmaptrilinear;   /* Keyword ":mipmap-trilinear" */
#define DEFINED_MIPMAPTRILINEAR
#endif

#ifndef DEFINED_POINT
LVAL k_point;   /* Keyword ":point" */
#define DEFINED_POINT
#endif

#ifndef DEFINED_BILINEAR
LVAL k_bilinear;   /* Keyword ":bilinear" */
#define DEFINED_BILINEAR
#endif

#ifndef DEFINED_CLAMP
LVAL k_clamp;   /* Keyword ":clamp" */
#define DEFINED_CLAMP
#endif

#ifndef DEFINED_REPEAT
LVAL k_repeat;   /* Keyword ":repeat" */
#define DEFINED_REPEAT
#endif

#ifndef DEFINED_DECAL
LVAL k_decal;   /* Keyword ":decal" */
#define DEFINED_DECAL
#endif

#ifndef DEFINED_MODULATE
LVAL k_modulate;   /* Keyword ":modulate" */
#define DEFINED_MODULATE
#endif

#ifndef DEFINED_TEXTUREIS
LVAL k_textureis;   /* Keyword ":texture-is" */
#define DEFINED_TEXTUREIS
#endif

#ifndef DEFINED_ON
LVAL k_on;   /* Keyword ":on" */
#define DEFINED_ON
#endif

#ifndef DEFINED_OFF
LVAL k_off;   /* Keyword ":off" */
#define DEFINED_OFF
#endif

#ifndef DEFINED_BYPOINT
LVAL k_bypoint;   /* Keyword ":by-point" */
#define DEFINED_BYPOINT
#endif

#ifndef DEFINED_BYFACET
LVAL k_byfacet;   /* Keyword ":by-facet" */
#define DEFINED_BYFACET
#endif

#ifndef DEFINED_MERGETYPE
LVAL k_mergetype;   /* Keyword ":merge-type" */
#define DEFINED_MERGETYPE
#endif

#ifndef DEFINED_WRAPTYPE
LVAL k_wraptype;   /* Keyword ":wrap-type" */
#define DEFINED_WRAPTYPE
#endif

#ifndef DEFINED_SHOW
LVAL k_show;/* Keyword ":show" */
#define DEFINED_SHOW
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_S_PROPERTYLIST
    s_propertylist = xlenter("PROPERTY-LIST");
#define CREATED_S_PROPERTYLIST
#endif

#ifndef CREATED_S_GRAPHICRELATION
    s_graphicrelation = xlenter("GRAPHIC-RELATION");
#define CREATED_S_GRAPHICRELATION
#endif

#ifndef CREATED_GRAPHICRELATION
    k_graphicrelation = xlenter(":GRAPHIC-RELATION");
#define CREATED_GRAPHICRELATION
#endif

#ifndef CREATED_MINIFYFN
    k_minifyfn = xlenter(":MINIFY-FN");
#define CREATED_MINIFYFN
#endif

#ifndef CREATED_MAGNIFYFN
    k_magnifyfn = xlenter(":MAGNIFY-FN");
#define CREATED_MAGNIFYFN
#endif

#ifndef CREATED_MIPMAPPOINT
    k_mipmappoint = xlenter(":MIPMAP-POINT");
#define CREATED_MIPMAPPOINT
#endif

#ifndef CREATED_MIPMAPLINEAR
    k_mipmaplinear = xlenter(":MIPMAP-LINEAR");
#define CREATED_MIPMAPLINEAR
#endif

#ifndef CREATED_MIPMAPBILINEAR
    k_mipmapbilinear = xlenter(":MIPMAP-BILINEAR");
#define CREATED_MIPMAPBILINEAR
#endif

#ifndef CREATED_MIPMAPTRILINEAR
    k_mipmaptrilinear = xlenter(":MIPMAP-TRILINEAR");
#define CREATED_MIPMAPTRILINEAR
#endif

#ifndef CREATED_POINT
    k_point = xlenter(":POINT");
#define CREATED_POINT
#endif

#ifndef CREATED_BILINEAR
    k_bilinear = xlenter(":BILINEAR");
#define CREATED_BILINEAR
#endif

#ifndef CREATED_CLAMP
    k_clamp = xlenter(":CLAMP");
#define CREATED_CLAMP
#endif

#ifndef CREATED_REPEAT
    k_repeat = xlenter(":REPEAT");
#define CREATED_REPEAT
#endif

#ifndef CREATED_DECAL
    k_decal = xlenter(":DECAL");
#define CREATED_DECAL
#endif

#ifndef CREATED_MODULATE
    k_modulate = xlenter(":MODULATE");
#define CREATED_MODULATE
#endif

#ifndef CREATED_TEXTUREIS
    k_textureis = xlenter(":TEXTURE-IS");
#define CREATED_TEXTUREIS
#endif

#ifndef CREATED_ON
    k_on = xlenter(":ON");
#define CREATED_ON
#endif

#ifndef CREATED_OFF
    k_off = xlenter(":OFF");
#define CREATED_OFF
#endif

#ifndef CREATED_BYPOINT
    k_bypoint = xlenter(":BY-POINT");
#define CREATED_BYPOINT
#endif

#ifndef CREATED_BYFACET
    k_byfacet = xlenter(":BY-FACET");
#define CREATED_BYFACET
#endif

#ifndef CREATED_MERGETYPE
    k_mergetype = xlenter(":MERGE-TYPE");
#define CREATED_MERGETYPE
#endif

#ifndef CREATED_WRAPTYPE
    k_wraptype = xlenter(":WRAP-TYPE");
#define CREATED_WRAPTYPE
#endif

#ifndef CREATED_SHOW
    k_show = xlenter(":SHOW");
#define CREATED_SHOW
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xtxr = xgbj58_Create_Class("CLASS-TEXTURE",lv_x03d);
    xgbj57_Add_Instance_Variable( lv_xtxr,"GRAPHIC-RELATION");
    xgbj56_Enter_Messages( lv_xtxr,  xtxr_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
