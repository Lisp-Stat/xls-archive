/* {{{ c03d.h -- class 3d, superclass for 3d/c/* classes.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Feb11
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifndef INCLUDED_C03D_H
#define INCLUDED_C03D_H

/* }}} */

/* Values for k_class: */

/* The lower case 'x's here are just to make sure */
/* I fix all references to these values during the */
/* change from bit-per-class to number-per-class, */
/* and can be changed back to cap-xs as soon as this */
/* change is working solidly. 94Apr06jsp */

/* The classes allowed as components of graphic  */
/* relations come first, so that we can identify */
/* them by a simple range check:                 */

/*******************************************************************/
/* WARNING: IF YOU ADD A NEW VALUE HERE, YOU NEED TO ADD A LINE TO */
/*          xfil27_Write_Object_To_Graphics_File.		   */
/*******************************************************************/
#define C03D_xFLV	(0x70000001)
#define C03D_xF8V	(0x70000002)
#define C03D_x01V	(0x70000003)
#define C03D_x32V	(0x70000004)
#define C03D_xU8V	(0x70000005)
#define C03D_xU6V	(0x70000006)
#define C03D_xI6V	(0x70000007)
#define C03D_xF6V	(0x70000008)
#define C03D_xF2V	(0x70000009)
#define C03D_GRL_MAX	(0x00000100)
#define C03D_GRL_MASK	(0x0FFFFFFF)

#define C03D_x03D	(0x70000101)
#define C03D_xGRL	(0x70000102)
#define C03D_xCMR	(0x70000103)
#define C03D_xLGT	(0x70000104)
#define C03D_xMTL	(0x70000105)
#define C03D_xMDL	(0x70000106)
#define C03D_xSRY	(0x70000107)
#define C03D_xTFM	(0x70000108)
#define C03D_xFIL	(0x70000109)
#define C03D_xS1D	(0x7000010A)
#define C03D_xCHC	(0x7000010B)
#define C03D_xGTX	(0x7000010C)
#define C03D_xFRM	(0x7000010D)
#define C03D_xTUB	(0x7000010E)
#define C03D_xCLR	(0x7000010F)
#define C03D_xLID	(0x70000110)
#define C03D_xLIT	(0x70000111)
#define C03D_xSUB	(0x70000112)
#define C03D_xTRN	(0x70000113)
#define C03D_xLST	(0x70000114)
#define C03D_xTXR	(0x70000115)
#define C03D_xTXF	(0x70000116)
#define C03D_xPGN	(0x70000117)
#define C03D_xEDT	(0x70000118)
#define C03D_xEYE	(0x70000119)
#define C03D_xSLC	(0x70000120)
#define C03D_MAGC	(0x70000000)

/* Arrays we allow in a Graphic Relation: */
#define C03D_IS_GRL_CLASS(x) (((x)&C03D_GRL_MASK)<=C03D_GRL_MAX)

/* This struct occurs at a fixed offset in every class in this */
/* directory, and contains the information needed to write the */
/* object back to the file from whence it came, while preserv- */
/* references to other objects.                                */
struct c03d_struct_of_file_info {
    int  object_number;	/* All objects within a file are numbered sequentially. */
    LVAL file_object;

    /* This stuff has nothing whatever to do with file info.   */
    /* Included here just because I likewise want it in every  */
    /* object at a fixed offset, without the clutter of running*/
    /* around explicitly putting it in them all:               */
    int	      may_have_hooks;  /* => We may have :PER-FRAME-HOOK	*/	
    int       last_hooks;      /* Last time we evaluated hooks fns.	*/
};
typedef struct c03d_struct_of_file_info c03d_fileInfo;
/* Initializer for c03d_fileInfo records: */
#define C03D_FILEiNFO_INIT {-1,NULL,1,-1}
extern c03d_fileInfo c03d_fileInfo_Init; /* Record initialized to that. */

struct c03d_struct {
    int k_class;             /* Always 1st in record.                       */
    c03d_fileInfo fileInfo;  /* Always 2nd in record. What file to save in. */
};
typedef struct c03d_struct  c03d_rec;

#define x03dp(o) (gobjectp(o) && ((((c03d_rec*)(gobjimmbase(o)))->k_class) == C03D_x03D))

LVAL  x03d01_Get_A_X03D();
LVAL  x03d40_Get_Msg();
LVAL  x03d42_Put_Msg();
LVAL  x03d44_Frame_Things();
LVAL* x03d73_pPropList();
LVAL  x03d75_Get();
LVAL  x03d9b_SetObjectProp();
LVAL  x03dfc_Find_Class_Name();

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
#endif
/* }}} */
