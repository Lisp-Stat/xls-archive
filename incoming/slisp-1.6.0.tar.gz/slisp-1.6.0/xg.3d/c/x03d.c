/* {{{ x03d.c -- Class 3D, superclass for 3d/c/* classes.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Feb11
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 94Apr06 jsp: Switch from bit-per-class to int-per-class in c03d.h.   */
/* 92May02 jsp: Write_Object[s_Lvals]_To_Graphics_File.                 */
/* 92Apr26 jsp: Map_PairList imported from xgrl.c.			*/
/* 92Feb29 jsp: Getf_Fn/Setf_Fn/Remf_Fn/Length_Fn/Nth_Fn.		*/
/* 92Feb29 jsp: Call_Hook_Fns.                                 		*/
/* 92Feb28 jsp: Answer_Msg.                                    		*/
/* 92Feb12 jsp: Remprop, Propertylist-length, propertylist-nth.		*/
/* 92Feb11 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/

#include "../../xcore/c/xlisp.h"

/* external variables */
extern LVAL obarray,s_unbound;
extern LVAL xlenv,xlfenv,xldenv;

extern LVAL k_copyproplist;
extern LVAL k_frametightly;
extern LVAL k_perframehook;
extern LVAL k_things;
extern LVAL s_propertylist;

extern LVAL lv_x03d;

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 
LVAL x03d41_Set();

#include <math.h>
#include "csry.h"
#include "c03d.h"
#include "cthl.h"
#include "../../xg.3d.fileio/c/cfil.h"
#include "lib.h"

c03d_fileInfo c03d_fileInfo_Init = C03D_FILEiNFO_INIT;

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ x03d00_Is_New -- Initialize a new x03d instance.			*/

LVAL x03d00_Is_New()
{   extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    c03d_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!x03dp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for our record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( c03d_rec ) );

    /* Initialize our record to reasonable default values: */
    r	        = (c03d_rec*) gobjimmbase( lv );
    r->k_class  = C03D_x03D;
    r->fileInfo = c03d_fileInfo_Init;
    xfil50_Maybe_Note_New_3D_Object( lv );

    return lv;
}

/* }}} */
/* {{{ x03d01_Get_A_X03D -- Get arg, must be of class x03d.		*/

LVAL x03d01_Get_A_X03D()
/*-
    Get arg, must be of class x03d.
-*/
{
    LVAL m_as_lval = xlgagobject();
    if (!x03dp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) != sizeof( c03d_rec )
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ x03d03_Show_Msg -- Show the contents of a c03d.			*/

LVAL x03d03_Show_Msg()
/*-
    Show the contents of a 03d.
-*/
{
    LVAL self,fptr;
    int i;

    /* get self and the file pointer */
    self = x03d01_Get_A_X03D();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the 03d record:  */
    /* Well, nothing int it:) */

    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ x03d08_Copy_Msg -- Build copy of given C03D.			*/

LVAL x03d09_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given C03D.
-*/
{
    /* Create a new gobject to hold result: */
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_x03d,k_new);
    xlpop();

    /* Here we'd normally copy our values :) */

    return r_as_lval;
}

LVAL x03d08_Copy_Msg()
/*-
    Build copy of given C03D.
-*/
{   LVAL m_as_lval;
    LVAL x_as_lval = x03d01_Get_A_X03D();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = x03d09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ x03d14_Map_PairList -- Apply fn,fa to everything in a pair list.	*/

x03d14_Map_PairList( pairList, fn,    fa )
LVAL                 pairList;
int			     (*fn)(),*fa;
{   int result;
    xlstkcheck(3);
    xlprotect(pairList);
    while (!null(pairList)) {
	LVAL  propname;
	LVAL  propval;
	xlstkcheck(2);
	xlsave(propname);
	xlsave(propval);
	if (!consp(pairList))     xlbadtype(pairList);
	propname  = car( pairList );  /* Name of array */
	pairList  = cdr( pairList );  /* Value cell */
	if (!consp(pairList))     xlbadtype(pairList);
	propval   = car( pairList );  /* array      */
	if (result = (*fn)(fa, propname, propval )) {
	    xlpopn(3);
	    return result;
	}
	pairList = cdr( pairList );  /* Prop  cell */
	xlpopn(2);
    }		
    xlpop();
    return 0;
}

/* }}} */
/* {{{ x03d44_Frame_Things--Common xcmr/xtfm/xlgt FrameThings_Msg code. */

LVAL x03d44_Frame_Things( lv_self, lv_xtfm, wide_high )
LVAL			  lv_self, lv_xtfm;
float					    wide_high;/* screen aspect ratio */
{
    /* This function is in this file just because xtfm, xcmr and xlgt */
    /* all export about the same message, and it's not clear where    */
    /* else to put the common code.				      */
    LVAL   lv_thinglist = NIL;
    int    frame_tightly = FALSE;

    while (moreargs()) {
        LVAL       key = xlgasymbol();
	if        (key == k_things)	  {
	    lv_thinglist = xlgalist();
	} else if (key == k_frametightly) {
	    frame_tightly = !null(xlgetarg());
	} else {
	    xlerror("Bad :FRAME-THINGS keyword",key);
    }   }

    if (null(lv_thinglist)) {
        lv_thinglist = xthl8a_GetObjectProp( lv_self, k_things, NIL,TRUE );
    }

    if (null(lv_thinglist)) {
        lv_thinglist = xthl8a_GetObjectProp( lv_xtfm, k_things, NIL,TRUE );
    }

    if (null(lv_thinglist)) {
	xlerror("No :THINGS for :FRAME-THINGS msg",lv_self);
    }

    xtfm93_Frame_Things( lv_xtfm, lv_thinglist, frame_tightly, wide_high );
    return lv_self;
}

/* }}} */
/* {{{ x03d73_pPropList -- Return pointer to property list for sry.	*/

LVAL* x03d73_pPropList( m )
LVAL                    m;
{
    /* Find our list of properties: */
    LVAL*pPropList;
    xthl89_GetAddressOfObjectVariableValueErrorIfUnbound(
        m,
        getclass( m ),
        s_propertylist,
        &pPropList
    );
    return pPropList;
}

/* }}} */
/* {{{ x03d76_Get_Msg -- Get keyword properties.                        */

LVAL x03d75_Get( g_as_lval )  /* WARNING: Called from other files. */
LVAL		 g_as_lval;
/*-
    Return keyword properties for an xsry object.
-*/
{
    LVAL key         = xlgasymbol();
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    return xthl8a_GetObjectProp( g_as_lval, key, default_val, got_default );
}

LVAL x03d76_Get_Msg()
/*-
    Return keyword properties for an xsry object.
-*/
{
    return x03d75_Get( xlgagobject() ); /* Allow other classes to use fn. */
}

/* }}} */
/* {{{ x03d79_Set_Msg -- Write keyword properties.                      */

LVAL x03d78_Set( g_as_lval ) /* WARNING: Called from other files. */
LVAL             g_as_lval;
/*-
    Write keyword properties for an object.
-*/
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL key;
    LVAL val;
    while (moreargs()) {
        LVAL key        = xlgasymbol();
        LVAL val        = xlgetarg();
	xthl82_SetProp( pPropList, key, val );
    }

    /* While we don't store :PER-FRAME-HOOK specially,	*/
    /* we *do* keep track of whether it is (possibly) present,	*/
    /* just as an efficiency hack:				*/
    if (key == k_perframehook) {
        c03d_rec* r  = (c03d_rec*) gobjimmbase( g_as_lval );
	xthlF2_Check_hookFns( val );
	r->fileInfo.may_have_hooks = TRUE;
    }

    return val;
}

LVAL x03d79_Set_Msg()
/*-
    Write keyword properties for an xsry object.
-*/
{
    return x03d78_Set( xlgagobject() ); /* Allow other classes to use fn. */
}

/* }}} */
/* {{{ x03d80_GetProplistCopyDepth -- Parse :COPY-PROPLIST T/:DEEP	*/

x03d80_GetProplistCopyDepth() {

    if (!moreargs())   return FALSE;

    {   extern LVAL k_deep;
        extern LVAL k_shallow;
        extern LVAL k_pointer;
        LVAL lv_key = xlgasymbol();
        if (lv_key != k_copyproplist) xlerror("Expected :COPY-PROPLIST");
        if (!moreargs())   xlerror("Missing :COPY-PROPIST val");
	lv_key = xlgetarg();
	if (lv_key == k_deep)      return 3;
	if (lv_key == k_shallow)   return 2;
	if (lv_key == k_pointer)   return 1;
	if (null(lv_key))          return 0;
	return 0;
    }
}

/* }}} */
/* {{{ x03d81_CopyProplist -- PointerCopy/listcopy/deepcopy proplist.	*/

x03d81_CopyProplist( lv_dst, lv_src, depth )
LVAL                 lv_dst, lv_src;
int                                  depth;
{
    LVAL*pDstPropList  = x03d73_pPropList( lv_dst );
    LVAL*pSrcPropList  = x03d73_pPropList( lv_src );
    switch (depth) {
    case 0:                                                          	break;
    case 1:   *pDstPropList =			    *pSrcPropList  ;	break;
    case 2:   *pDstPropList = xthlG7_Copy_List(     *pSrcPropList );	break;
    case 3:   *pDstPropList = xthlG8_DeepCopy_List( *pSrcPropList );	break;
    default:
       xlbadtype();
    }

    /* Keep may_have_hooks consistent with propertylist: */
    if (depth) {
        c03d_rec* d = (c03d_rec*) gobjimmbase( lv_dst );
        c03d_rec* s = (c03d_rec*) gobjimmbase( lv_src );
	d->fileInfo.may_have_hooks = s->fileInfo.may_have_hooks;
    }
}

/* }}} */
/* {{{ x03d88_RemProp_Msg -- Remove property from propertylist.         */

LVAL x03d87_RemProp( g_as_lval )
LVAL                 g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL key        = xlgasymbol();
    xllastarg();
    return xthl83_RemProp( pPropList, key );
}

LVAL x03d88_RemProp_Msg()
/*-
    Remove property from propertylist.
-*/
{
    return x03d87_RemProp( xlgagobject() ); /* Allow other classes to use fn. */
}

/* }}} */
/* {{{ x03d91_ProplistLength_Msg -- Return length of propertylist.      */

int x03d89_PropListLength( lst )
LVAL	                   lst;
/*-
    Count length of a property list.
-*/
{
    LVAL p;
    int  len = 0;
    for (p = lst;   consp(p) && consp(cdr(p));   p = cdr(cdr(p))) {
	len++;
    }
    return len;
}
LVAL x03d90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum(   x03d89_PropListLength( *pPropList )   );
}

LVAL x03d91_ProplistLength_Msg()
/*-
    Return length of propertylist.
-*/
{
    return x03d90_ProplistLength( xlgagobject() ); /* Let other classes use fn. */
}

/* }}} */
/* {{{ x03d95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL x03d94_ProplistNth( g_as_lval )
LVAL                     g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL n_as_lval  = xlgafixnum();
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    return xthl93_ListNth(
        *pPropList,
        getfixnum(n_as_lval),
	n_as_lval,
        default_val,
        got_default
    );
}

LVAL x03d95_ProplistNth_Msg()
/*-
    Return Nth item from propertylist.
-*/
{
    return x03d94_ProplistNth( xlgagobject() ); /* Allow other classes to use fn. */
}

/* }}} */
/* {{{ x03d9b_SetObjectProp						*/

LVAL x03d9b_SetObjectProp( lv_self, lv_sym, lv_val )
LVAL			   lv_self, lv_sym, lv_val;
{   LVAL*pPropList  = x03d73_pPropList( lv_self );
    LVAL result     = xthl82_SetProp( pPropList, lv_sym, lv_val );

    /* Special hack to track whether we (maybe) have a :per-frame-hook */
    if (lv_sym == k_perframehook) {
        c03d_rec* r = (c03d_rec*) gobjimmbase( lv_self );
	xthlF2_Check_hookFns( lv_val );
	r->fileInfo.may_have_hooks = TRUE;
    }
}

/* }}} */
/* {{{ x03d9e_Maybe_Run_PerframeHooks_Msg				*/

x03d9d_Maybe_Run_PerframeHooks( lv )
LVAL				lv;
{   extern xcmr05_Frame_Number;
    c03d_rec* r = (c03d_rec*) gobjimmbase( lv );

    /* If user has supplied code to compute  */
    /* our value, it may be time to call it: */
    if (r->fileInfo.may_have_hooks &&
	r->fileInfo.last_hooks != xcmr05_Frame_Number
    ) {
        LVAL lv_hooks = xthl8a_GetObjectProp( lv, k_perframehook, NIL,TRUE );
	if (null(lv_hooks)) {
	    r->fileInfo.may_have_hooks = FALSE;
	} else {
	    r->fileInfo.last_hooks  = xcmr05_Frame_Number;/*Stop recursion!*/
	    xthlF5_Call_HookFns( lv_hooks );
    }   }
    return 0;
}
LVAL x03d9e_Maybe_Run_Perframehooks_Msg() {
    LVAL lv_self = xlgaobject();
    xllastarg();
    {   extern LVAL true;/*xlglob.c*/
        return x03d9d_Maybe_Run_PerframeHooks( lv_self ) ? true : NIL;
    }
}

/* }}} */
/* {{{ x03dA0_Is_A -- Return TRUE iff object is descended from lv_class.*/

x03dA0_Is_A( lv_class, lv_obj )
LVAL         lv_class, lv_obj;
{   LVAL lv_thisClass = getclass( lv_obj );
    for (; objectp(lv_thisClass); lv_thisClass = getivar(lv_thisClass,SUPERCLASS)) {
	if (lv_thisClass == lv_class)   return TRUE;
    }
    return   FALSE;
}
LVAL x03dA1_Is_A_Fn() {
    LVAL lv_class = xlgaobject();
    LVAL lv_obj   = xlgetarg(); /* Allow nonobjects etc for convenience. */
    xllastarg();
    if (!objectp(lv_obj) || !x03dA0_Is_A(lv_class,lv_obj))   return NIL;
    return lv_obj;
}

/* }}} */
/* {{{ x03dF0_Answer_Msg--Replacement for xlobj.c:clanswer,accepts SUBRs*/

LVAL x03dF0_Answer_Msg()
{
    /* This fn is intended to be just like xlobj.c:clanswer(),	*/
    /* except for allowing us to use c-coded primitives to	*/
    /* answer messages, as well as lambda closures.		*/
    
    extern LVAL entermsg();
    extern LVAL s_lambda;
    LVAL self,msg,fargs,code,mptr;

    /* message symbol, formal argument list and code */
    self = xlgaobject();
    msg = xlgasymbol();
#ifdef ORIGINAL
    fargs = xlgalist();
#else
    /* This section is the only change from clanswer(): */
    fargs = xlgetarg();
    if (!listp(fargs)) {
	LVAL subr;
	/* fargs should be a symbol with function value set... */
	if (!symbolp(fargs) || !fboundp(fargs)) xlbadtype(fargs);
	xllastarg();
	subr = getfunction(fargs);
	if (!subrp(subr) && !fsubrp(subr))	xlbadtype(subr);
	mptr = (LVAL)entermsg(self,msg);
	rplacd(mptr,subr);
	return self;	
    }
#endif
    code = xlgalist();
    xllastarg();

    /* make a new message list entry */
    mptr = (LVAL)entermsg(self,msg);

    /* set up the message node */
    xlprot1(fargs);
    fargs = cons(s_self,fargs); /* add 'self' as the first argument */
    rplacd(mptr,xlclose(msg,s_lambda,fargs,code,xlenv,xlfenv));	/* changed by NPM -- pass in lexical and functional environment */
    xlpop();

    /* return the object */
    return (self);
}

/* }}} */
/* {{{ x03dwo_Write_X03d_To_Graphics_File                               */

LVAL x03dfs_Find_Symbol_By_Value( lv )
LVAL                              lv;
{
    /* Search *obarray* linearly for symbol pointing to lv (!): */
    extern LVAL obarray;
    LVAL array = getvalue(obarray);
    int  i;
    for (i = 0;  i < HSIZE;   ++i) {
	LVAL h;
	for (h = getelement(array,i);  h!=NIL; h=cdr(h)) {
	    LVAL sym = car(h);
	    if (getvalue(sym)==lv)   return sym;
    }   }
    return NIL;
}

LVAL x03dfc_Find_Class_Name( lv )
LVAL                         lv;
{
    /* This is gloriously inefficient right now because our xlisp  */
    /* doesn't store the class name in the class.  Good reason to  */
    /* upgrade to 2.1f, which _does_ ...                           */

    /* Find class for object: */
    LVAL c = getclass(lv);

    /* Search *obarray* linearly for symbol pointing to c (!): */
    LVAL s = x03dfs_Find_Symbol_By_Value( c );
    if (s==NIL)   xlerror("Class has no name?!",lv);

    /* Return name of symbol: */
    return getpname(s);
}

x03dwo_Write_X03d_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */

    /* Find name of our class: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new))\n",getstring(name));
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

