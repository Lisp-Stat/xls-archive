/* {{{ xf6v.c -- 16-bit unit float vectors.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94May30
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */
/* {{{ --- history ---							*/

/* 94May30 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  
#include "../../xcore/c/xlisp.h"

#include "csry.h"

extern LVAL lv_xf6v;

#include "geo.h"
#include "cf6v.h"
#include "clsp.h"

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xf6v0a_Set_Default -- Set up Default_Initializer in csry_rec.	*/

xf6v0a_Set_Default( h )
csry_rec*           h;
{
    h->default_initializer.i = 0;
}

/* }}} */
/* {{{ xf6v00_List_To_Struct -- Convert x number to C unit float.	*/

xf6v00_List_To_Struct( p, p_as_lval, h )
CSRY_UNSIGNED16 *      p;
LVAL			  p_as_lval;
csry_rec*                            h;
/*-
    Convert x number to C unsigned char.
-*/
{
    /* If initializer is null, use default values.  */
    /* (This is also used to supply default values  */
    /* for new slots in redimensioned arrays.)	    */
    if (p_as_lval == NIL) {
        *p = h->default_initializer.u6;
        return;
    }

    {   FLOTYPE f = xgbj00_Get_Fix_Or_Flo_Num( p_as_lval );
	if (f <  0.0)   f  = 0.0;
	if (f >= 1.0)   *p = 65535;
	else            *p = (CSRY_UNSIGNED16)( 65535.0 * f );
    }
}

/* }}} */
/* {{{ xf6v01_Struct_To_List -- Convert C unit float to x flonum.	*/

LVAL xf6v01_Struct_To_List( p )
CSRY_UNSIGNED16*		    p;
{
    return cvflonum( ((float)*p) * (1.0 / 65535.0) );
}

/* }}} */
/* {{{ xf6v02_Sprintf -- Sprintf unit float into buffer.		*/

xf6v02_Sprintf( buf, p )
char*		buf;
CSRY_UNSIGNED16*	     p;
{
    return sprintf(buf, "%f", ((float)*p) * (1.0 / 65535.0) );
}

/* }}} */
/* {{{ xf6v -- Describe unit float to csry.c.				*/

FORWARD int xf6v54_BCopy();
FORWARD int xf6v55_From_Buf();
FORWARD int xf6v56_To_Buf();
FORWARD int xf6v58_Position();
FORWARD int xf6v62_Delete();
LVAL xsry22_AdjustArray();
LOCAL struct csry_struct xf6v = {
    /* int  k_class             = */ C03D_xF6V,
    /* int  sizeof_struct       = */ sizeof( CSRY_UNSIGNED16 ),
    /* int  (*list_to_struct)() = */ xf6v00_List_To_Struct,
    /* LVAL (*struct_to_list)() = */ xf6v01_Struct_To_List,
    /* int  (*sprintf_struct)() = */ xf6v02_Sprintf,
    /* int  (*copy_struct)   () = */ xf6v54_BCopy,
    /* int  (*initfn)        ();= */ xf6v0a_Set_Default,
    /* LVAL k_ary               = */ NULL,
    /* int  (*from_buf)      ();= */ xf6v55_From_Buf,
    /* int  (*  to_buf)      ();= */ xf6v56_To_Buf,
    /* LVAL (*adjust_array)  ();= */ xsry22_AdjustArray,
    /* int  (*position)      ();= */ xf6v58_Position,
    /* int  (*delete)        ();= */ xf6v62_Delete
};
/*-
    Describe our type to csry.c.
-*/

/* }}} */
/* {{{ xf6v03_Is_New -- Initialize a new unit float array.		*/

LVAL xf6v03_Is_New()
{   xf6v.k_ary = lv_xf6v;  /* Not really the best place to do this... */

    /* This isn't too bad, a good compiler will erase the test: */
    if (sizeof(CSRY_UNSIGNED16) != 2) {
	xlfatal("Please redefine csry.h:CSRY_UNSIGNED16");
    }

    return   xsry00_Is_New( &xf6v );
}

/* }}} */
/* {{{ xf6v04_Get_A_XF6V -- Get arg, must be a unit float vector/array.	*/

LVAL xf6v04_Get_A_XF6V()
{
    LVAL m_as_lval = xlgagobject();
    if (!xf6vp( m_as_lval ))   xlbadtype(m_as_lval);
    return m_as_lval;
}

/* }}} */
/* {{{ xf6v32_Copy_Bit_To_Unf                                           */

xf6v32_Copy_Bit_To_Unf( dst, src, cnt, ifv )
CSRY_UNSIGNED16         *dst;
unsigned char               *src;
int                               cnt;
unsigned char                         *ifv;
{
    int            i;
    int            inbits;
    int            ifbits;
    int            val;
    char           tab[2];
    tab[0] =   0;
    tab[1] = 65535;

    if (ifv == NULL) {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     inbits  = *src++;
	    val = (inbits & 1);
            *dst++ = tab[val];
	    inbits >>= 1;
	}
    } else {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     { inbits  = *src++;   ifbits = *ifv++; }
	    val = (inbits & 1);
            if    (ifbits & 1)   *dst = tab[val];
            ++dst;
	    inbits >>= 1;
	    ifbits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xf6v35_Copy_Fix_To_Unf                                           */

xf6v35_Copy_Fix_To_Unf( dst, src, cnt, ifv )
CSRY_UNSIGNED16         *dst;
CSRY_INT32                  *src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
            *dst++ = (CSRY_UNSIGNED16) *src++ ? 65535 : 0;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = (CSRY_UNSIGNED16) *src ? 65535 : 0;
	    ++dst;
            ++src;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xf6v34_Copy_Unf_To_Flo                                           */

xf6v34_Copy_Unf_To_Flo( dst, src, cnt, ifv )
float                  *dst;
CSRY_UNSIGNED16              *src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
            *dst++ = ((float)*src++) / 65535.0;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = ((float)*src) / 65535.0;
	    ++dst;
            ++src;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xf6v38_Copy_Flo_To_Unf                                           */

xf6v38_Copy_Flo_To_Unf( dst, src, cnt, ifv )
CSRY_UNSIGNED16         *dst;
float                       *src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
	    float          f = *src++;
	    if (f < 0.0)   f = 0.0;
	    if (f > 1.0)   f = 1.0;
            *dst++ = (CSRY_UNSIGNED16) (f * 65535.0);
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1) {
		float          f = *src;
		if (f < 0.0)   f = 0.0;
		if (f > 1.0)   f = 1.0;
		*dst = (CSRY_UNSIGNED16) (f * 65535.0);
	    }
	    ++src;
            ++dst;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xf6v41_Max_Msg -- Find maximum entry in array.               	*/

float xf6v40_Max( m_as_lval )
LVAL              m_as_lval;
{   int i, max;
    csry_rec* mh = xsry9c_Find_Immediate_Base( m_as_lval );
    {   CSRY_UNSIGNED16*  mt = (CSRY_UNSIGNED16*) csry_base( m_as_lval );
	i        = mh->size;
        if (mh->rank == 1 && mh->dim[1] >= 0) i = mh->dim[1];/*Respect fillptr*/
        if (!i)   xlfail( "max:  array is empty" );
	max      = *mt;
	while (--i >= 0) {
            if (*mt++ > max)   max = *(mt -1);
    }	}
    return ((float)max) / 65535.0;
}

LVAL xf6v41_Max_Msg()
/*-
    Find maximum entry in an array.  Message protocol.
-*/
{   LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    xllastarg();
    return cvflonum( xf6v40_Max( m_as_lval ) );
}

/* }}} */
/* {{{ xf6v43_Min_Msg -- Find minimum entry in array.               	*/

float xf6v42_Min( m_as_lval )
LVAL              m_as_lval;
{
    int i, min;
    csry_rec* mh = xsry9c_Find_Immediate_Base( m_as_lval );
    {
	CSRY_UNSIGNED16*  mt = (CSRY_UNSIGNED16*) csry_base( m_as_lval );
	i        = mh->size;
        if (mh->rank == 1 && mh->dim[1] >= 0) i = mh->dim[1];/*Respect fillptr*/
        if (!i)   xlfail( "min:  array is empty" );
	min      = *mt;
	while (--i >= 0) {
            if (*mt++ < min)   min = *(mt -1);
	}
    }
    return ((float)min) / 65535.0;
}
LVAL xf6v43_Min_Msg()
/*-
    Find minimum entry in an array.  Message protocol.
-*/
{
    LVAL m_as_lval = xsry01_Get_A_Struct_Array();
    xllastarg();
    return cvflonum( xf6v42_Min( m_as_lval ) );
}

/* }}} */
/* {{{ xf6v54_BCopy -- Copy an instance					*/

xf6v54_BCopy(  dst, src )
CSRY_UNSIGNED16*dst;
CSRY_UNSIGNED16*     src;
{
    *dst = *src;
}

/* }}} */
/* {{{ xf6v55_From_Buf -- Copy from buffer into array.			*/

int xf6v55_From_Buf( v_as_lval, buf, cnt, pos, ifv )
LVAL                 v_as_lval;
struct xlsp05_buf *             buf;
int                                  cnt, pos;
unsigned char *                                ifv;
{
    CSRY_UNSIGNED16 * vt;
    if (!xf6vp( v_as_lval ))   xlbadtype( v_as_lval );
    vt  = (CSRY_UNSIGNED16*)    csry_base( v_as_lval );
    vt += pos;

    switch (buf->buf_type) {

    case XLSP_TYPE_BIT:
	xf6v32_Copy_Bit_To_Unf( vt, buf->u.bit, cnt, ifv );
        break;

    case XLSP_TYPE_FIX:
	xf6v35_Copy_Fix_To_Unf( vt, buf->u.fix, cnt, ifv );
        break;

    case XLSP_TYPE_FLO:
	xf6v38_Copy_Flo_To_Unf( vt, buf->u.flo, cnt, ifv );
        break;

    default:
        abort();
    }

    return 0;
}

/* }}} */
/* {{{ xf6v56_To_Buf -- Copy from array into buffer.			*/

int xf6v56_To_Buf( v_as_lval, buf, cnt, pos, ifv )
LVAL               v_as_lval;
struct xlsp05_buf *           buf;
int                                cnt, pos;
unsigned char *                              ifv;
{
    CSRY_UNSIGNED16* vt;
    if (!xf6vp( v_as_lval ))          xlbadtype( v_as_lval );
    vt            = (CSRY_UNSIGNED16*) csry_base( v_as_lval );

    xf6v34_Copy_Unf_To_Flo( buf->u.flo, vt+pos, cnt, ifv );
    buf->buf_type = XLSP_TYPE_FLO;

    return 0;
}

/* }}} */
/* {{{ xf6v58_Position -- Find value within buffer.			*/

int xf6v58_Position( lv_ary, lv_arg )
LVAL                 lv_ary, lv_arg;
{
    float fval;
    int   val;
    csry_rec* mh = xsry9c_Find_Immediate_Base( lv_ary );
    if       (  fixp(lv_arg)) fval = (float) getfixnum( lv_arg );
    else if  (floatp(lv_arg)) fval =         getflonum( lv_arg );
    else xlerror("xflv :position needed float", lv_arg );
    if (fval < 0.0)   fval = 0.0;
    if (fval > 1.0)   fval = 1.0;
    val = (CSRY_UNSIGNED16) (fval * 65535.0);

    {   CSRY_UNSIGNED16*mt = (CSRY_UNSIGNED16*) csry_base( lv_ary );
	int  len            = mh->size;
	int  i;
        /* Respect fillpointer: */
        if (mh->rank == 1 && mh->dim[1] >= 0) len = mh->dim[1];
        if (!len)   return -1;
	for (i = 0; i < len; ++i) if (*mt++ == val) return i;
    }
    return -1;
}

/* }}} */
/* {{{ xf6v62_Delete -- Find value within buffer.			*/

int xf6v62_Delete( lv_ary, start, end )
LVAL               lv_ary;
int			   start, end;
{
    int val;
    csry_rec* mh = xsry9c_Find_Immediate_Base( lv_ary );
    CSRY_UNSIGNED16*mt = (CSRY_UNSIGNED16*) csry_base( lv_ary );
    int  len = mh->size;
    int  gap = end-start;
    int  i;
    /* Respect fillpointer. We know mh->rank==1 */
    if (mh->dim[1] >= 0) len = mh->dim[1];
    if (!len)   return -1;
    for (i = start; i < len-gap; ++i)  mt[i] = mt[i+gap];
    /* Set fillpointer to reflect new length: */
    mh->dim[1] = len-gap;
    return 0;
}

/* }}} */
/* {{{ xf6v80_Get_UnitFloat_Base -- Fetch base of UnitFloatVec		*/

CSRY_UNSIGNED16* xf6v80_Get_UnitFloat_Base( self )
LVAL				           self;
{
    if (!gobjectp(self) || !xf6vp(self))   xlbadtype(self);
    return   (CSRY_UNSIGNED16*) csry_base(self);
}

/* }}} */
/* {{{ xf6vwo_Write_Xf6v_To_Graphics_File                               */

xf6vwo_Write_Xf6v_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   xsrywo_Write_Xsry_To_Graphics_File( fdoa, fdob, lv,f,n, "16-BIT-FLOAT" );
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */

