/* {{{ xcmr.h -- camera objects.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Jul12
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xcmr;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xcmr00_Is_New();
extern LVAL xcmr08_Copy_Msg();
extern LVAL xcmr03_Show_Msg();
extern LVAL xcmr40_Get_Msg();
extern LVAL xcmr42_Set_Msg();
extern LVAL xcmr44_Frame_Things_Msg();
extern LVAL xcmr46_Draw_Msg();
extern LVAL xcmr49_NextFrame_Msg();
extern LVAL xcmr51_Clear_Viewport_Msg();
extern LVAL xcmr53_Clear_Zbuffer_Msg();
extern LVAL xcmr55_Swap_Buffers_Msg();
extern LVAL xcmr57_ScriptTime_Fn();
extern LVAL xcmr59_Clear_Overlay_Bitplanes_Msg();
extern LVAL xcmr91_ProplistLength_Msg();
extern LVAL xcmr95_ProplistNth_Msg();
extern LVAL xcmr99_Bounding_Box_Msg();
extern LVAL xcmrD9_RunWidgets_Msg();
extern LVAL xcmrE5_ReadMouseState_Msg();
extern LVAL xcmrF0_Copy_Contents_Msg();

#ifndef EXTERNED_S_XG3DDEBUG
extern LVAL s_xg3ddebug;/* Symbol "XG.3D-DEBUG" */
#define EXTERNED_S_XG3DDEBUG
#endif

#ifndef EXTERNED_S_PROPERTYLIST
extern LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define EXTERNED_S_PROPERTYLIST
#endif

#ifndef EXTERNED_S_XG3DCURRENTCAMERA
extern LVAL s_xg3dcurrentcamera;/* Symbol "XG.3D-CURRENT-CAMERA" */
#define EXTERNED_S_XG3DCURRENTCAMERA
#endif

#ifndef EXTERNED_S_XG3DDRAGGEDCAMERA
extern LVAL s_xg3ddraggedcamera;/* Symbol "XG.3D-DRAGGED-CAMERA" */
#define EXTERNED_S_XG3DDRAGGEDCAMERA
#endif

#ifndef EXTERNED_S_XG3DDRAGGEDTHING
extern LVAL s_xg3ddraggedthing;/* Symbol "XG.3D-DRAGGED-THING" */
#define EXTERNED_S_XG3DDRAGGEDTHING
#endif

#ifndef EXTERNED_S_XG3DDRAGGEDDRAGHOOK
extern LVAL s_xg3ddraggeddraghook;/* Symbol "XG.3D-DRAGGED-DRAG-HOOK" */
#define EXTERNED_S_XG3DDRAGGEDDRAGHOOK
#endif

#ifndef EXTERNED_S_XG3DDRAGGEDUPCLICKHOOK
extern LVAL s_xg3ddraggedupclickhook;/* Symbol "XG.3D-DRAGGED-UPCLICK-HOOK" */
#define EXTERNED_S_XG3DDRAGGEDUPCLICKHOOK
#endif

#ifndef EXTERNED_S_XG3DSELECTEDCAMERA
extern LVAL s_xg3dselectedcamera;/* Symbol "XG.3D-SELECTED-CAMERA" */
#define EXTERNED_S_XG3DSELECTEDCAMERA
#endif

#ifndef EXTERNED_S_XG3DSELECTEDTHING
extern LVAL s_xg3dselectedthing;/* Symbol "XG.3D-SELECTED-THING" */
#define EXTERNED_S_XG3DSELECTEDTHING
#endif

#ifndef EXTERNED_S_XG3DSELECTEDDESELECTHOOK
extern LVAL s_xg3dselecteddeselecthook;/* Symbol "XG.3D-SELECTED-DESELECT-HOOK" */
#define EXTERNED_S_XG3DSELECTEDDESELECTHOOK
#endif

#ifndef EXTERNED_S_XG3DMOUSEROW
extern LVAL s_xg3dmouserow;/* Symbol "XG.3D-MOUSE-ROW" */
#define EXTERNED_S_XG3DMOUSEROW
#endif

#ifndef EXTERNED_S_XG3DMOUSECOL
extern LVAL s_xg3dmousecol;/* Symbol "XG.3D-MOUSE-COL" */
#define EXTERNED_S_XG3DMOUSECOL
#endif

#ifndef EXTERNED_S_XG3DMOUSEPRESSURE
extern LVAL s_xg3dmousepressure;/* Symbol "XG.3D-MOUSE-PRESSURE" */
#define EXTERNED_S_XG3DMOUSEPRESSURE
#endif

#ifndef EXTERNED_S_XG3DMOUSESTATE
extern LVAL s_xg3dmousestate;/* Symbol "XG.3D-MOUSE-STATE" */
#define EXTERNED_S_XG3DMOUSESTATE
#endif

#ifndef EXTERNED_S_XG3DKEYBOARDCHARHOOK
extern LVAL s_xg3dkeyboardcharhook;/* Symbol "XG.3D-KEYBOARD-CHAR-HOOK" */
#define EXTERNED_S_XG3DKEYBOARDCHARHOOK
#endif

#ifndef EXTERNED_S_XG3DKEYBOARDCHAR
extern LVAL s_xg3dkeyboardchar;/* Symbol "XG.3D-KEYBOARD-CHAR" */
#define EXTERNED_S_XG3DKEYBOARDCHAR
#endif

#ifndef EXTERNED_S_XG3DREDRAWHOOK
extern LVAL s_xg3dredrawhook;/* Symbol "XG.3D-REDRAW-HOOK" */
#define EXTERNED_S_XG3DREDRAWHOOK
#endif

#ifndef EXTERNED_S_XG3DSCRIPTTIME
extern LVAL s_xg3dscripttime;/* Symbol "XG.3D-SCRIPT-TIME" */
#define EXTERNED_S_XG3DSCRIPTTIME
#endif

#ifndef EXTERNED_DEFAULT
extern LVAL k_default;   /* Keyword ":default" */
#define EXTERNED_DEFAULT
#endif

#ifndef EXTERNED_BLOCKUNTILINPUTARRIVES
extern LVAL k_blockuntilinputarrives;   /* Keyword ":block-until-input-arrives" */
#define EXTERNED_BLOCKUNTILINPUTARRIVES
#endif

#ifndef EXTERNED_MOUSELOCATIONX
extern LVAL k_mouselocationx;   /* Keyword ":mouse-location-x" */
#define EXTERNED_MOUSELOCATIONX
#endif

#ifndef EXTERNED_MOUSELOCATIONY
extern LVAL k_mouselocationy;   /* Keyword ":mouse-location-y" */
#define EXTERNED_MOUSELOCATIONY
#endif

#ifndef EXTERNED_MOUSEROW
extern LVAL k_mouserow;   /* Keyword ":mouse-row" */
#define EXTERNED_MOUSEROW
#endif

#ifndef EXTERNED_MOUSECOL
extern LVAL k_mousecol;   /* Keyword ":mouse-col" */
#define EXTERNED_MOUSECOL
#endif

#ifndef EXTERNED_SELECTEDTHING
extern LVAL k_selectedthing;   /* Keyword ":selected-thing" */
#define EXTERNED_SELECTEDTHING
#endif

#ifndef EXTERNED_SELECTEDFACET
extern LVAL k_selectedfacet;   /* Keyword ":selected-facet" */
#define EXTERNED_SELECTEDFACET
#endif

#ifndef EXTERNED_SELECTEDTHINGSPACELOCATIONX
extern LVAL k_selectedthingspacelocationx;   /* Keyword ":selected-thing-space-location-x" */
#define EXTERNED_SELECTEDTHINGSPACELOCATIONX
#endif

#ifndef EXTERNED_SELECTEDTHINGSPACELOCATIONY
extern LVAL k_selectedthingspacelocationy;   /* Keyword ":selected-thing-space-location-y" */
#define EXTERNED_SELECTEDTHINGSPACELOCATIONY
#endif

#ifndef EXTERNED_SELECTEDTHINGSPACELOCATIONZ
extern LVAL k_selectedthingspacelocationz;   /* Keyword ":selected-thing-space-location-z" */
#define EXTERNED_SELECTEDTHINGSPACELOCATIONZ
#endif

#ifndef EXTERNED_SELECTEDPARAMETRICFACETLOCATIONX
extern LVAL k_selectedparametricfacetlocationx;   /* Keyword ":selected-parametric-facet-location-x" */
#define EXTERNED_SELECTEDPARAMETRICFACETLOCATIONX
#endif

#ifndef EXTERNED_SELECTEDPARAMETRICFACETLOCATIONY
extern LVAL k_selectedparametricfacetlocationy;   /* Keyword ":selected-parametric-facet-location-y" */
#define EXTERNED_SELECTEDPARAMETRICFACETLOCATIONY
#endif

#ifndef EXTERNED_FRAMENUMBER
extern LVAL k_framenumber;   /* Keyword ":frame-number" */
#define EXTERNED_FRAMENUMBER
#endif

#ifndef EXTERNED_MOUSESTATE
extern LVAL k_mousestate;   /* Keyword ":MOUSE-STATE" */
#define EXTERNED_MOUSESTATE
#endif

#ifndef EXTERNED_DOWNCLICK
extern LVAL k_downclick;   /* Keyword ":DOWNCLICK" */
#define EXTERNED_DOWNCLICK
#endif

#ifndef EXTERNED_DRAG
extern LVAL k_drag;   /* Keyword ":DRAG" */
#define EXTERNED_DRAG
#endif

#ifndef EXTERNED_UPCLICK
extern LVAL k_upclick;   /* Keyword ":UPCLICK" */
#define EXTERNED_UPCLICK
#endif

#ifndef EXTERNED_SELECT
extern LVAL k_select;   /* Keyword ":SELECT" */
#define EXTERNED_SELECT
#endif

#ifndef EXTERNED_DROPBACKFACES
extern LVAL k_dropbackfaces;   /* Keyword ":drop-backfaces" */
#define EXTERNED_DROPBACKFACES
#endif

#ifndef EXTERNED_SCRIPTTIME
extern LVAL k_scripttime;   /* Keyword ":script-time" */
#define EXTERNED_SCRIPTTIME
#endif

#ifndef EXTERNED_SCRIPTRATE
extern LVAL k_scriptrate;   /* Keyword ":script-rate" */
#define EXTERNED_SCRIPTRATE
#endif

#ifndef EXTERNED_MOUSELOCATION
extern LVAL k_mouselocation;   /* Keyword ":mouse-location" */
#define EXTERNED_MOUSELOCATION
#endif

#ifndef EXTERNED_LIGHTINGMODEL
extern LVAL k_lightingmodel;   /* Keyword ":lighting-model" */
#define EXTERNED_LIGHTINGMODEL
#endif

#ifndef EXTERNED_MATERIAL
extern LVAL k_material;   /* Keyword ":material" */
#define EXTERNED_MATERIAL
#endif

#ifndef EXTERNED_LIGHTS
extern LVAL k_lights;   /* Keyword ":lights" */
#define EXTERNED_LIGHTS
#endif

#ifndef EXTERNED_THINGS
extern LVAL k_things;   /* Keyword ":things" */
#define EXTERNED_THINGS
#endif

#ifndef EXTERNED_TRANSFORM
extern LVAL k_transform;   /* Keyword ":transform" */
#define EXTERNED_TRANSFORM
#endif

#ifndef EXTERNED_PROJECTIONTRANSFORM
extern LVAL k_projectiontransform;   /* Keyword ":projection-transform" */
#define EXTERNED_PROJECTIONTRANSFORM
#endif

#ifndef EYEPHONE_KLUDGE
#ifndef EXTERNED_WINDOWFACTORS
extern LVAL k_windowfactors;   /* Keyword ":window-factors" */
#define EXTERNED_WINDOWFACTORS
#endif
#endif

#ifndef EXTERNED_TARGET
extern LVAL k_target;   /* Keyword ":target" */
#define EXTERNED_TARGET
#endif

#ifndef EXTERNED_LOCATION
extern LVAL k_location;   /* Keyword ":location" */
#define EXTERNED_LOCATION
#endif

#ifndef EXTERNED_TWIST
extern LVAL k_twist;      /* Keyword ":twist" */
#define EXTERNED_TWIST
#endif

#ifndef EXTERNED_DEGREES
extern LVAL k_degrees;      /* Keyword ":degrees" */
#define EXTERNED_DEGREES
#endif

#ifndef EXTERNED_RADIANS
extern LVAL k_radians;      /* Keyword ":radians" */
#define EXTERNED_RADIANS
#endif

#ifndef EXTERNED_DIAMETER
extern LVAL k_diameter;     /* Keyword ":diameter" */
#define EXTERNED_DIAMETER
#endif

#ifndef EXTERNED_VIEWPORTSPOTROW
extern LVAL k_viewportspotrow;  /* Keyword ":viewport-spot-row" */
#define EXTERNED_VIEWPORTSPOTROW
#endif

#ifndef EXTERNED_VIEWPORTSIZEROWS
extern LVAL k_viewportsizerows;  /* Keyword ":viewport-size-rows" */
#define EXTERNED_VIEWPORTSIZEROWS
#endif

#ifndef EXTERNED_VIEWPORTSPOTCOL
extern LVAL k_viewportspotcol;  /* Keyword ":viewport-spot-col" */
#define EXTERNED_VIEWPORTSPOTCOL
#endif

#ifndef EXTERNED_VIEWPORTSIZECOLS
extern LVAL k_viewportsizecols;  /* Keyword ":viewport-size-cols" */
#define EXTERNED_VIEWPORTSIZECOLS
#endif

#ifndef EXTERNED_VIEWPORTSPOTX
extern LVAL k_viewportspotx;  /* Keyword ":viewport-spot-x" */
#define EXTERNED_VIEWPORTSPOTX
#endif

#ifndef EXTERNED_VIEWPORTSIZEX
extern LVAL k_viewportsizex;  /* Keyword ":viewport-size-x" */
#define EXTERNED_VIEWPORTSIZEX
#endif

#ifndef EXTERNED_VIEWPORTSPOTY
extern LVAL k_viewportspoty;  /* Keyword ":viewport-spot-y" */
#define EXTERNED_VIEWPORTSPOTY
#endif

#ifndef EXTERNED_VIEWPORTSIZEY
extern LVAL k_viewportsizey;  /* Keyword ":viewport-size-y" */
#define EXTERNED_VIEWPORTSIZEY
#endif

#ifndef NEW_ASPECT
#ifndef EXTERNED_ASPECT
extern LVAL k_aspect;    /* Keyword ":aspect" */
#define EXTERNED_ASPECT
#endif
#endif

#ifndef EXTERNED_SHOW
extern LVAL k_show;/* Keyword ":show" */
#define EXTERNED_SHOW
#endif

#ifndef EXTERNED_VIEWING_TRANSFORM
extern LVAL s_viewing_transform; /* Symbol "viewing-transform" */
#define EXTERNED_VIEWING_TRANSFORM
#endif

#ifndef EXTERNED_PERSPECTIVE_TRANSFORM
extern LVAL s_perspective_transform; /* Symbol "perspective-transform" */
#define EXTERNED_PERSPECTIVE_TRANSFORM
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,	xcmr00_Is_New			)
DEFINE_SUBR(	NULL,	xcmr08_Copy_Msg			)
DEFINE_SUBR(	NULL,	xcmr03_Show_Msg			)
DEFINE_SUBR(	NULL,	xcmr40_Get_Msg			)
DEFINE_SUBR(	NULL,	xcmr42_Set_Msg			)
DEFINE_SUBR(	NULL,	xcmr44_Frame_Things_Msg		)
DEFINE_SUBR(	NULL,	xcmr46_Draw_Msg	   		)
DEFINE_SUBR(	NULL,	xcmr49_NextFrame_Msg		)
DEFINE_SUBR(	NULL,	xcmr51_Clear_Viewport_Msg	)
DEFINE_SUBR(	NULL,	xcmr53_Clear_Zbuffer_Msg	)
DEFINE_SUBR(	NULL,	xcmr55_Swap_Buffers_Msg		)
DEFINE_SUBR(	NULL,	xcmr59_Clear_Overlay_Bitplanes_Msg )
DEFINE_SUBR(    "XG.3D-SCRIPT-TIME", xcmr57_ScriptTime_Fn )
DEFINE_SUBR(	NULL,	xcmr91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,	xcmr95_ProplistNth_Msg		)
DEFINE_SUBR(	NULL,	xcmr99_Bounding_Box_Msg		)
DEFINE_SUBR(	NULL,	xcmrD9_RunWidgets_Msg		)
DEFINE_SUBR(	NULL,	xcmrE5_ReadMouseState_Msg	)
DEFINE_SUBR(	NULL,	xcmrF0_Copy_Contents_Msg	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xcmr;
LOCAL struct xcmr_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xcmr_table[] = {
    {	":ISNEW",		xcmr00_Is_New			},
    {	":COPY",		xcmr08_Copy_Msg			},
    {	":SHOW",		xcmr03_Show_Msg			},
    {	":GET", 		xcmr40_Get_Msg			},
    {	":SET", 		xcmr42_Set_Msg			},
    {	":FRAME-THINGS",	xcmr44_Frame_Things_Msg		},
    {	":DRAW",        	xcmr46_Draw_Msg			},
    {	":NEXT-FRAME",        	xcmr49_NextFrame_Msg		},
    {	":CLEAR-VIEWPORT",	xcmr51_Clear_Viewport_Msg	},
    {	":CLEAR-ZBUFFER",	xcmr53_Clear_Zbuffer_Msg	},
    {	":CLEAR-OVERLAY-BITPLANES",	xcmr59_Clear_Overlay_Bitplanes_Msg },
    {	":SWAP-BUFFERS",	xcmr55_Swap_Buffers_Msg		},
    {	":PROPERTY-LIST-LENGTH",xcmr91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xcmr95_ProplistNth_Msg		},
    {	":BOUNDING-BOX",	xcmr99_Bounding_Box_Msg		},
    {	":RUN-WIDGETS",		xcmrD9_RunWidgets_Msg		},
    {	":READ-MOUSE-STATE",	xcmrE5_ReadMouseState_Msg	},
    {	":COPY-CONTENTS",	xcmrF0_Copy_Contents_Msg	},

    {	NULL,			NULL				}
};



#ifndef DEFINED_S_XG3DDEBUG
LVAL s_xg3ddebug;/* Symbol "XG.3D-DEBUG" */
#define DEFINED_S_XG3DDEBUG
#endif

#ifndef DEFINED_S_PROPERTYLIST
LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define DEFINED_S_PROPERTYLIST
#endif

#ifndef DEFINED_S_XG3DCURRENTCAMERA
LVAL s_xg3dcurrentcamera;/* Symbol "XG.3D-CURRENT-CAMERA" */
#define DEFINED_S_XG3DCURRENTCAMERA
#endif

#ifndef DEFINED_S_XG3DDRAGGEDCAMERA
LVAL s_xg3ddraggedcamera;/* Symbol "XG.3D-DRAGGED-CAMERA" */
#define DEFINED_S_XG3DDRAGGEDCAMERA
#endif

#ifndef DEFINED_S_XG3DDRAGGEDTHING
LVAL s_xg3ddraggedthing;/* Symbol "XG.3D-DRAGGED-THING" */
#define DEFINED_S_XG3DDRAGGEDTHING
#endif

#ifndef DEFINED_S_XG3DDRAGGEDDRAGHOOK
LVAL s_xg3ddraggeddraghook;/* Symbol "XG.3D-DRAGGED-DRAG-HOOK" */
#define DEFINED_S_XG3DDRAGGEDDRAGHOOK
#endif

#ifndef DEFINED_S_XG3DDRAGGEDUPCLICKHOOK
LVAL s_xg3ddraggedupclickhook;/* Symbol "XG.3D-DRAGGED-UPCLICK-HOOK" */
#define DEFINED_S_XG3DDRAGGEDUPCLICKHOOK
#endif

#ifndef DEFINED_S_XG3DSELECTEDCAMERA
LVAL s_xg3dselectedcamera;/* Symbol "XG.3D-SELECTED-CAMERA" */
#define DEFINED_S_XG3DSELECTEDCAMERA
#endif

#ifndef DEFINED_S_XG3DSELECTEDTHING
LVAL s_xg3dselectedthing;/* Symbol "XG.3D-SELECTED-THING" */
#define DEFINED_S_XG3DSELECTEDTHING
#endif

#ifndef DEFINED_S_XG3DSELECTEDDESELECTHOOK
LVAL s_xg3dselecteddeselecthook;/* Symbol "XG.3D-SELECTED-DESELECT-HOOK" */
#define DEFINED_S_XG3DSELECTEDDESELECTHOOK
#endif

#ifndef DEFINED_S_XG3DMOUSEROW
LVAL s_xg3dmouserow;/* Symbol "XG.3D-MOUSE-ROW" */
#define DEFINED_S_XG3DMOUSEROW
#endif

#ifndef DEFINED_S_XG3DMOUSECOL
LVAL s_xg3dmousecol;/* Symbol "XG.3D-MOUSE-COL" */
#define DEFINED_S_XG3DMOUSECOL
#endif

#ifndef DEFINED_S_XG3DMOUSEPRESSURE
LVAL s_xg3dmousepressure;/* Symbol "XG.3D-MOUSE-PRESSURE" */
#define DEFINED_S_XG3DMOUSEPRESSURE
#endif

#ifndef DEFINED_S_XG3DMOUSESTATE
LVAL s_xg3dmousestate;/* Symbol "XG.3D-MOUSE-STATE" */
#define DEFINED_S_XG3DMOUSESTATE
#endif

#ifndef DEFINED_S_XG3DKEYBOARDCHARHOOK
LVAL s_xg3dkeyboardcharhook;/* Symbol "XG.3D-KEYBOARD-CHAR-HOOK" */
#define DEFINED_S_XG3DKEYBOARDCHARHOOK
#endif

#ifndef DEFINED_S_XG3DKEYBOARDCHAR
LVAL s_xg3dkeyboardchar;/* Symbol "XG.3D-KEYBOARD-CHAR" */
#define DEFINED_S_XG3DKEYBOARDCHAR
#endif

#ifndef DEFINED_S_XG3DREDRAWHOOK
LVAL s_xg3dredrawhook;/* Symbol "XG.3D-REDRAW-HOOK" */
#define DEFINED_S_XG3DREDRAWHOOK
#endif

#ifndef DEFINED_S_XG3DSCRIPTTIME
LVAL s_xg3dscripttime;/* Symbol "XG.3D-SCRIPT-TIME" */
#define DEFINED_S_XG3DSCRIPTTIME
#endif

#ifndef DEFINED_DEFAULT
LVAL k_default;   /* Keyword ":default" */
#define DEFINED_DEFAULT
#endif

#ifndef DEFINED_BLOCKUNTILINPUTARRIVES
LVAL k_blockuntilinputarrives;   /* Keyword ":block-until-input-arrives" */
#define DEFINED_BLOCKUNTILINPUTARRIVES
#endif

#ifndef DEFINED_MOUSELOCATIONX
LVAL k_mouselocationx;   /* Keyword ":mouse-location-x" */
#define DEFINED_MOUSELOCATIONX
#endif

#ifndef DEFINED_MOUSELOCATIONY
LVAL k_mouselocationy;   /* Keyword ":mouse-location-y" */
#define DEFINED_MOUSELOCATIONY
#endif

#ifndef DEFINED_MOUSELOCATIONZ
LVAL k_mouselocationz;   /* Keyword ":mouse-location-z" */
#define DEFINED_MOUSELOCATIONZ
#endif

#ifndef DEFINED_MOUSEROW
LVAL k_mouserow;   /* Keyword ":mouse-row" */
#define DEFINED_MOUSEROW
#endif

#ifndef DEFINED_MOUSECOL
LVAL k_mousecol;   /* Keyword ":mouse-col" */
#define DEFINED_MOUSECOL
#endif

#ifndef DEFINED_MOUSESTATE
LVAL k_mousestate;   /* Keyword ":mouse-state" */
#define DEFINED_MOUSESTATE
#endif

#ifndef DEFINED_SELECTEDTHING
LVAL k_selectedthing;   /* Keyword ":selected-thing" */
#define DEFINED_SELECTEDTHING
#endif

#ifndef DEFINED_SELECTEDFACET
LVAL k_selectedfacet;   /* Keyword ":selected-facet" */
#define DEFINED_SELECTEDFACET
#endif

#ifndef DEFINED_SELECTEDTHINGSPACELOCATIONX
LVAL k_selectedthingspacelocationx;   /* Keyword ":selected-thing-space-location-x" */
#define DEFINED_SELECTEDTHINGSPACELOCATIONX
#endif

#ifndef DEFINED_SELECTEDTHINGSPACELOCATIONY
LVAL k_selectedthingspacelocationy;   /* Keyword ":selected-thing-space-location-y" */
#define DEFINED_SELECTEDTHINGSPACELOCATIONY
#endif

#ifndef DEFINED_SELECTEDTHINGSPACELOCATIONZ
LVAL k_selectedthingspacelocationz;   /* Keyword ":selected-thing-space-location-z" */
#define DEFINED_SELECTEDTHINGSPACELOCATIONZ
#endif

#ifndef DEFINED_SELECTEDPARAMETRICFACETLOCATIONX
LVAL k_selectedparametricfacetlocationx;   /* Keyword ":selected-parametric-facet-location-x" */
#define DEFINED_SELECTEDPARAMETRICFACETLOCATIONX
#endif

#ifndef DEFINED_SELECTEDPARAMETRICFACETLOCATIONY
LVAL k_selectedparametricfacetlocationy;   /* Keyword ":selected-parametric-facet-location-y" */
#define DEFINED_SELECTEDPARAMETRICFACETLOCATIONY
#endif

#ifndef DEFINED_FRAMENUMBER
LVAL k_framenumber;   /* Keyword ":frame-number" */
#define DEFINED_FRAMENUMBER
#endif

#ifndef DEFINED_DOWNCLICK
LVAL k_downclick;   /* Keyword ":downclick" */
#define DEFINED_DOWNCLICK
#endif

#ifndef DEFINED_DRAG
LVAL k_drag;   /* Keyword ":drag" */
#define DEFINED_DRAG
#endif

#ifndef DEFINED_UPCLICK
LVAL k_upclick;   /* Keyword ":upclick" */
#define DEFINED_UPCLICK
#endif

#ifndef DEFINED_SELECT
LVAL k_select;   /* Keyword ":select" */
#define DEFINED_SELECT
#endif

#ifndef DEFINED_DROPBACKFACES
LVAL k_dropbackfaces;   /* Keyword ":drop-backfaces" */
#define DEFINED_DROPBACKFACES
#endif

#ifndef DEFINED_SCRIPTTIME
LVAL k_scripttime;   /* Keyword ":script-time" */
#define DEFINED_SCRIPTTIME
#endif

#ifndef DEFINED_SCRIPTRATE
LVAL k_scriptrate;   /* Keyword ":script-rate" */
#define DEFINED_SCRIPTRATE
#endif

#ifndef DEFINED_MOUSELOCATION
LVAL k_mouselocation;   /* Keyword ":mouse-location" */
#define DEFINED_MOUSELOCATION
#endif

#ifndef DEFINED_LIGHTINGMODEL
LVAL k_lightingmodel;   /* Keyword ":lighting-model" */
#define DEFINED_LIGHTINGMODEL
#endif

#ifndef DEFINED_MATERIAL
LVAL k_material;   /* Keyword ":material" */
#define DEFINED_MATERIAL
#endif

#ifndef DEFINED_LIGHTS
LVAL k_lights;   /* Keyword ":lights" */
#define DEFINED_LIGHTS
#endif

#ifndef DEFINED_THINGS
LVAL k_things;   /* Keyword ":things" */
#define DEFINED_THINGS
#endif

#ifndef DEFINED_TRANSFORM
LVAL k_transform;   /* Keyword ":transform" */
#define DEFINED_TRANSFORM
#endif

#ifndef DEFINED_PROJECTIONTRANSFORM
LVAL k_projectiontransform;   /* Keyword ":projection-transform" */
#define DEFINED_PROJECTIONTRANSFORM
#endif

#ifndef EYEPHONE_KLUDGE
#ifndef DEFINED_WINDOWFACTORS
LVAL k_windowfactors;   /* Keyword ":window-factors" */
#define DEFINED_WINDOWFACTORS
#endif
#endif

#ifndef DEFINED_TARGET
LVAL k_target;   /* Keyword ":target" */
#define DEFINED_TARGET
#endif

#ifndef DEFINED_LOCATION
LVAL k_location;   /* Keyword ":location" */
#define DEFINED_LOCATION
#endif

#ifndef DEFINED_TWIST
LVAL k_twist;         /* Keyword ":twist" */
#define DEFINED_TWIST
#endif

#ifndef DEFINED_DEGREES
LVAL k_degrees;      /* Keyword ":degrees" */
#define DEFINED_DEGREES
#endif

#ifndef DEFINED_RADIANS
LVAL k_radians;      /* Keyword ":radians" */
#define DEFINED_RADIANS
#endif

#ifndef DEFINED_DIAMETER
LVAL k_diameter;     /* Keyword ":diameter" */
#define DEFINED_DIAMETER
#endif

#ifndef DEFINED_VIEWPORTSPOTROW
LVAL k_viewportspotrow;     /* Keyword ":viewport-spot-row" */
#define DEFINED_VIEWPORTSPOTROW
#endif

#ifndef DEFINED_VIEWPORTSIZEROWS
LVAL k_viewportsizerows;     /* Keyword ":viewport-size-rows" */
#define DEFINED_VIEWPORTSIZEROWS
#endif

#ifndef DEFINED_VIEWPORTSPOTCOL
LVAL k_viewportspotcol;     /* Keyword ":viewport-spot-col" */
#define DEFINED_VIEWPORTSPOTCOL
#endif

#ifndef DEFINED_VIEWPORTSIZECOLS
LVAL k_viewportsizecols;     /* Keyword ":viewport-size-cols" */
#define DEFINED_VIEWPORTSIZECOLS
#endif

#ifndef DEFINED_VIEWPORTSPOTX
LVAL k_viewportspotx;     /* Keyword ":viewport-spot-x" */
#define DEFINED_VIEWPORTSPOTX
#endif

#ifndef DEFINED_VIEWPORTSIZEX
LVAL k_viewportsizex;     /* Keyword ":viewport-size-x" */
#define DEFINED_VIEWPORTSIZEX
#endif

#ifndef DEFINED_VIEWPORTSPOTY
LVAL k_viewportspoty;     /* Keyword ":viewport-spot-y" */
#define DEFINED_VIEWPORTSPOTY
#endif

#ifndef DEFINED_VIEWPORTSIZEY
LVAL k_viewportsizey;     /* Keyword ":viewport-size-y" */
#define DEFINED_VIEWPORTSIZEY
#endif


#ifndef NEW_ASPECT
#ifndef DEFINED_ASPECT
LVAL k_aspect;     /* Keyword ":aspect" */
#define DEFINED_ASPECT
#endif
#endif

#ifndef DEFINED_SHOW
LVAL k_show;/* Keyword ":show" */
#define DEFINED_SHOW
#endif

#ifndef DEFINED_VIEWING_TRANSFORM
LVAL s_viewing_transform;/* Symbol "viewing-transform" */
#define DEFINED_VIEWING_TRANSFORM
#endif

#ifndef DEFINED_PERSPECTIVE_TRANSFORM
LVAL s_perspective_transform;/* Symbol "perspective-transform" */
#define DEFINED_PERSPECTIVE_TRANSFORM
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_S_XG3DDEBUG
    s_xg3ddebug = xlenter("XG.3D-DEBUG");
    setvalue(s_xg3ddebug,NIL);
#define CREATED_S_XG3DDEBUG
#endif

#ifndef CREATED_S_PROPERTYLIST
    s_propertylist = xlenter("PROPERTY-LIST");
#define CREATED_S_PROPERTYLIST
#endif

#ifndef CREATED_S_XG3DCURRENTCAMERA
    s_xg3dcurrentcamera = xlenter("XG.3D-CURRENT-CAMERA");
#define CREATED_S_XG3DCURRENTCAMERA
#endif

#ifndef CREATED_S_XG3DDRAGGEDCAMERA
    s_xg3ddraggedcamera = xlenter("XG.3D-DRAGGED-CAMERA");
    setvalue(s_xg3ddraggedcamera,NIL);
#define CREATED_S_XG3DDRAGGEDCAMERA
#endif

#ifndef CREATED_S_XG3DDRAGGEDTHING
    s_xg3ddraggedthing = xlenter("XG.3D-DRAGGED-THING");
    setvalue(s_xg3ddraggedthing,NIL);
#define CREATED_S_XG3DDRAGGEDTHING
#endif

#ifndef CREATED_S_XG3DDRAGGEDDRAGHOOK
    s_xg3ddraggeddraghook = xlenter("XG.3D-DRAGGED-DRAG-HOOK");
    setvalue(s_xg3ddraggeddraghook,NIL);
#define CREATED_S_XG3DDRAGGEDDRAGHOOK
#endif

#ifndef CREATED_S_XG3DDRAGGEDUPCLICKHOOK
    s_xg3ddraggedupclickhook = xlenter("XG.3D-DRAGGED-UPCLICK-HOOK");
    setvalue(s_xg3ddraggedupclickhook,NIL);
#define CREATED_S_XG3DDRAGGEDUPCLICKHOOK
#endif

#ifndef CREATED_S_XG3DSELECTEDCAMERA
    s_xg3dselectedcamera = xlenter("XG.3D-SELECTED-CAMERA");
    setvalue(s_xg3dselectedcamera,NIL);
#define CREATED_S_XG3DSELECTEDCAMERA
#endif

#ifndef CREATED_S_XG3DSELECTEDTHING
    s_xg3dselectedthing = xlenter("XG.3D-SELECTED-THING");
    setvalue(s_xg3dselectedthing,NIL);
#define CREATED_S_XG3DSELECTEDTHING
#endif

#ifndef CREATED_S_XG3DSELECTEDDESELECTHOOK
    s_xg3dselecteddeselecthook = xlenter("XG.3D-SELECTED-DESELECT-HOOK");
    setvalue(s_xg3dselecteddeselecthook,NIL);
#define CREATED_S_XG3DSELECTEDDESELECTHOOK
#endif

#ifndef CREATED_S_XG3DMOUSEROW
    s_xg3dmouserow = xlenter("XG.3D-MOUSE-ROW");
#define CREATED_S_XG3DMOUSEROW
#endif

#ifndef CREATED_S_XG3DMOUSECOL
    s_xg3dmousecol = xlenter("XG.3D-MOUSE-COL");
#define CREATED_S_XG3DMOUSECOL
#endif

#ifndef CREATED_S_XG3DMOUSEPRESSURE
    s_xg3dmousepressure = xlenter("XG.3D-MOUSE-PRESSURE");
#define CREATED_S_XG3DMOUSEPRESSURE
#endif

#ifndef CREATED_S_XG3DMOUSESTATE
    s_xg3dmousestate = xlenter("XG.3D-MOUSE-STATE");
#define CREATED_S_XG3DMOUSESTATE
#endif

#ifndef CREATED_S_XG3DKEYBOARDCHARHOOK
    s_xg3dkeyboardcharhook = xlenter("XG.3D-KEYBOARD-CHAR-HOOK");
    /* So we can save/restore old value w/o worrying about 'unbound' errs: */
    setvalue( s_xg3dkeyboardcharhook, NIL );
#define CREATED_S_XG3DKEYBOARDCHARHOOK
#endif

#ifndef CREATED_S_XG3DKEYBOARDCHAR
    s_xg3dkeyboardchar = xlenter("XG.3D-KEYBOARD-CHAR");
#define CREATED_S_XG3DKEYBOARDCHAR
#endif

#ifndef CREATED_S_XG3DREDRAWHOOK
    s_xg3dredrawhook = xlenter("XG.3D-REDRAW-HOOK");
#define CREATED_S_XG3DREDRAWHOOK
#endif

#ifndef CREATED_S_XG3DSCRIPTTIME
    s_xg3dscripttime = xlenter("XG.3D-SCRIPT-TIME");
#define CREATED_S_XG3DSCRIPTTIME
#endif

#ifndef CREATED_DEFAULT
    k_default = xlenter(":DEFAULT");
#define CREATED_DEFAULT
#endif

#ifndef CREATED_BLOCKUNTILINPUTARRIVES
    k_blockuntilinputarrives = xlenter(":BLOCK-UNTIL-INPUT-ARRIVES");
#define CREATED_BLOCKUNTILINPUTARRIVES
#endif

#ifndef CREATED_MOUSELOCATIONX
    k_mouselocationx = xlenter(":MOUSE-LOCATION-X");
#define CREATED_MOUSELOCATIONX
#endif

#ifndef CREATED_MOUSELOCATIONY
    k_mouselocationy = xlenter(":MOUSE-LOCATION-Y");
#define CREATED_MOUSELOCATIONY
#endif

#ifndef CREATED_MOUSEROW
    k_mouserow = xlenter(":MOUSE-ROW");
#define CREATED_MOUSEROW
#endif

#ifndef CREATED_MOUSECOL
    k_mousecol = xlenter(":MOUSE-COL");
#define CREATED_MOUSECOL
#endif

#ifndef CREATED_SELECTEDTHING
    k_selectedthing = xlenter(":SELECTED-THING");
#define CREATED_SELECTEDTHING
#endif

#ifndef CREATED_SELECTEDFACET
    k_selectedfacet = xlenter(":SELECTED-FACET");
#define CREATED_SELECTEDFACET
#endif

#ifndef CREATED_SELECTEDTHINGSPACELOCATIONX
    k_selectedthingspacelocationx = xlenter(":SELECTED-THING-SPACE-LOCATION-X");
#define CREATED_SELECTEDTHINGSPACELOCATIONX
#endif

#ifndef CREATED_SELECTEDTHINGSPACELOCATIONY
    k_selectedthingspacelocationy = xlenter(":SELECTED-THING-SPACE-LOCATION-Y");
#define CREATED_SELECTEDTHINGSPACELOCATIONY
#endif

#ifndef CREATED_SELECTEDTHINGSPACELOCATIONZ
    k_selectedthingspacelocationz = xlenter(":SELECTED-THING-SPACE-LOCATION-Z");
#define CREATED_SELECTEDTHINGSPACELOCATIONZ
#endif

#ifndef CREATED_SELECTEDPARAMETRICFACETLOCATIONX
    k_selectedparametricfacetlocationx = xlenter(":SELECTED-PARAMETRIC-FACET-LOCATION-X");
#define CREATED_SELECTEDPARAMETRICFACETLOCATIONX
#endif

#ifndef CREATED_SELECTEDPARAMETRICFACETLOCATIONY
    k_selectedparametricfacetlocationy = xlenter(":SELECTED-PARAMETRIC-FACET-LOCATION-Y");
#define CREATED_SELECTEDPARAMETRICFACETLOCATIONY
#endif




#ifndef CREATED_FRAMENUMBER
    k_framenumber = xlenter(":FRAME-NUMBER");
#define CREATED_FRAMENUMBER
#endif

#ifndef CREATED_MOUSESTATE
    k_mousestate = xlenter(":MOUSE-STATE");
#define CREATED_MOUSESTATE
#endif

#ifndef CREATED_DOWNCLICK
    k_downclick = xlenter(":DOWNCLICK");
#define CREATED_DOWNCLICK
#endif

#ifndef CREATED_DRAG
    k_drag = xlenter(":DRAG");
#define CREATED_DRAG
#endif

#ifndef CREATED_UPCLICK
    k_upclick = xlenter(":UPCLICK");
#define CREATED_UPCLICK
#endif

#ifndef CREATED_SELECT
    k_select = xlenter(":SELECT");
#define CREATED_SELECT
#endif

#ifndef CREATED_DROPBACKFACES
    k_dropbackfaces = xlenter(":DROP-BACKFACES");
#define CREATED_DROPBACKFACES
#endif

#ifndef CREATED_SCRIPTTIME
    k_scripttime = xlenter(":SCRIPT-TIME");
#define CREATED_SCRIPTTIME
#endif

#ifndef CREATED_SCRIPTRATE
    k_scriptrate = xlenter(":SCRIPT-RATE");
#define CREATED_SCRIPTRATE
#endif

#ifndef CREATED_MOUSELOCATION
    k_mouselocation = xlenter(":MOUSE-LOCATION");
#define CREATED_MOUSELOCATION
#endif

#ifndef CREATED_LIGHTINGMODEL
    k_lightingmodel = xlenter(":LIGHTING-MODEL");
#define CREATED_LIGHTINGMODEL
#endif

#ifndef CREATED_MATERIAL
    k_material = xlenter(":MATERIAL");
#define CREATED_MATERIAL
#endif

#ifndef CREATED_LIGHTS
    k_lights = xlenter(":LIGHTS");
#define CREATED_LIGHTS
#endif

#ifndef CREATED_THINGS
    k_things = xlenter(":THINGS");
#define CREATED_THINGS
#endif

#ifndef CREATED_TRANSFORM
    k_transform = xlenter(":TRANSFORM");
#define CREATED_TRANSFORM
#endif

#ifndef CREATED_PROJECTIONTRANSFORM
    k_projectiontransform = xlenter(":PROJECTION-TRANSFORM");
#define CREATED_PROJECTIONTRANSFORM
#endif

#ifndef EYEPHONE_KLUDGE
#ifndef CREATED_WINDOWFACTORS
    k_windowfactors = xlenter(":WINDOW-FACTORS");
#define CREATED_WINDOWFACTORS
#endif
#endif

#ifndef CREATED_TARGET
    k_target = xlenter(":TARGET");
#define CREATED_TARGET
#endif

#ifndef CREATED_LOCATION
    k_location = xlenter(":LOCATION");
#define CREATED_LOCATION
#endif

#ifndef CREATED_TWIST
    k_twist = xlenter(":TWIST");
#define CREATED_TWIST
#endif

#ifndef CREATED_DEGREES
    k_degrees = xlenter(":DEGREES");
#define CREATED_DEGREES
#endif

#ifndef CREATED_RADIANS
    k_radians = xlenter(":RADIANS");
#define CREATED_RADIANS
#endif

#ifndef CREATED_DIAMETER
    k_diameter = xlenter(":DIAMETER");
#define CREATED_DIAMETER
#endif

#ifndef CREATED_VIEWPORTSPOTROW
    k_viewportspotrow = xlenter(":VIEWPORT-SPOT-ROW");
#define CREATED_VIEWPORTSPOTROW
#endif

#ifndef CREATED_VIEWPORTSIZEROWS
    k_viewportsizerows = xlenter(":VIEWPORT-SIZE-ROWS");
#define CREATED_VIEWPORTSIZEROWS
#endif

#ifndef CREATED_VIEWPORTSPOTCOL
    k_viewportspotcol = xlenter(":VIEWPORT-SPOT-COL");
#define CREATED_VIEWPORTSPOTCOL
#endif

#ifndef CREATED_VIEWPORTSIZECOLS
    k_viewportsizecols = xlenter(":VIEWPORT-SIZE-COLS");
#define CREATED_VIEWPORTSIZECOLS
#endif

#ifndef CREATED_VIEWPORTSPOTX
    k_viewportspotx = xlenter(":VIEWPORT-SPOT-X");
#define CREATED_VIEWPORTSPOTX
#endif

#ifndef CREATED_VIEWPORTSIZEX
    k_viewportsizex = xlenter(":VIEWPORT-SIZE-X");
#define CREATED_VIEWPORTSIZEX
#endif

#ifndef CREATED_VIEWPORTSPOTY
    k_viewportspoty = xlenter(":VIEWPORT-SPOT-Y");
#define CREATED_VIEWPORTSPOTY
#endif

#ifndef CREATED_VIEWPORTSIZEY
    k_viewportsizey = xlenter(":VIEWPORT-SIZE-Y");
#define CREATED_VIEWPORTSIZEY
#endif

#ifndef NEW_ASPECT
#ifndef CREATED_ASPECT
    k_aspect = xlenter(":ASPECT");
#define CREATED_ASPECT
#endif
#endif

#ifndef CREATED_SHOW
    k_show = xlenter(":SHOW");
#define CREATED_SHOW
#endif

#ifndef CREATED_VIEWING_TRANSFORM
    s_viewing_transform = xlenter("VIEWING-TRANSFORM");
#define CREATED_VIEWING_TRANSFORM
#endif

#ifndef CREATED_PERSPECTIVE_TRANSFORM
    s_perspective_transform = xlenter("PERSPECTIVE-TRANSFORM");
#define CREATED_PERSPECTIVE_TRANSFORM
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xcmr = xgbj58_Create_Class("CLASS-CAMERA",lv_x03d);
    xgbj57_Add_Instance_Variable( lv_xcmr,"VIEWING-TRANSFORM");
    xgbj57_Add_Instance_Variable( lv_xcmr,"PERSPECTIVE-TRANSFORM");
    xgbj56_Enter_Messages( lv_xcmr,  xcmr_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
