/* {{{ xtfm.h -- 4x4 transform matrices.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      90Nov20
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xtfm;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xtfm00_Is_New();
extern LVAL xtfm03_Show_Msg();
extern LVAL xtfm04_Identity_Msg();
extern LVAL xtfm08_Set_Msg();
extern LVAL xtfm06_Get_Msg();
extern LVAL xtfm16_Copy_Msg();
extern LVAL xtfm18_Move_Msg();
extern LVAL xtfm21_Move_Pre_Msg();
extern LVAL xtfm23_Move_Post_Msg();
extern LVAL xtfm60_Scale_Msg();
extern LVAL xtfm63_Scale_Pre_Msg();
extern LVAL xtfm65_Scale_Post_Msg();
extern LVAL xtfm67_Shear_Msg();
extern LVAL xtfm70_Shear_Pre_Msg();
extern LVAL xtfm72_Shear_Post_Msg();
extern LVAL xtfm10_Matrix_Multiply_Msg();
extern LVAL xtfm12_Matrix_Multiply_Pre_Msg();
extern LVAL xtfm14_Matrixt_Multiply_Post_Msg();
extern LVAL xtfm25_Rotate_Msg();
extern LVAL xtfm27_Rotate_Pre_Msg();
extern LVAL xtfm30_Rotate_Post_Msg();
extern LVAL xtfm33_X_Rotate_Msg();
extern LVAL xtfm36_X_Rotate_Pre_Msg();
extern LVAL xtfm39_X_Rotate_Post_Msg();
extern LVAL xtfm42_Y_Rotate_Msg();
extern LVAL xtfm45_Y_Rotate_Pre_Msg();
extern LVAL xtfm48_Y_Rotate_Post_Msg();
extern LVAL xtfm51_Z_Rotate_Msg();
extern LVAL xtfm54_Z_Rotate_Pre_Msg();
extern LVAL xtfm57_Z_Rotate_Post_Msg();
extern LVAL xtfm75_Transform_Point_Msg();
extern LVAL xtfm77_Transform_Normal_Msg();
extern LVAL xtfm79_Invert_Msg();
extern LVAL xtfm81_Transpose_Msg();
extern LVAL xtfm86_Get_Msg();
extern LVAL xtfm89_Set_Msg();
extern LVAL xtfm94_Frame_Things_Msg();
extern LVAL xtfmd1_Turtle_Forward_Msg();
extern LVAL xtfmd4_Turtle_Pitch_Msg();
extern LVAL xtfmd7_Turtle_Roll_Msg();
extern LVAL xtfmd9_Turtle_Yaw_Msg();
extern LVAL xtfmdb_Turtle_Right_Msg();
extern LVAL xtfmdd_Turtle_Up_Msg();
extern LVAL xtfme1_ProplistLength_Msg();
extern LVAL xtfme5_ProplistNth_Msg();
extern LVAL xtfmF0_Copy_Contents_Msg();
extern LVAL xtfmF4_Copy_Spaceball_Matrix_Msg();
extern LVAL xtfmG5_Set_To_Product_Msg();
extern LVAL xtfmH1_Decompose_Msg();
extern LVAL xtfmH2_Combine_Rotations_Fn();


#ifndef EXTERNED_S_PROPERTYLIST
extern LVAL s_propertylist;/* Symbol "property-list" */
#define EXTERNED_S_PROPERTYLIST
#endif

#ifndef EXTERNED_PERFRAMEHOOK
extern LVAL k_perframehook;   /* Keyword ":per-frame-hook" */
#define EXTERNED_PERFRAMEHOOK
#endif

#ifndef EXTERNED_DOWNCLICKHOOK
extern LVAL k_downclickhook;   /* Keyword ":DOWNCLICK-HOOK" */
#define EXTERNED_DOWNCLICKHOOK
#endif

#ifndef EXTERNED_DRAGHOOK
extern LVAL k_draghook;   /* Keyword ":DRAG-HOOK" */
#define EXTERNED_DRAGHOOK
#endif

#ifndef EXTERNED_UPCLICKHOOK
extern LVAL k_upclickhook;   /* Keyword ":UPCLICK-HOOK" */
#define EXTERNED_UPCLICKHOOK
#endif

#ifndef EXTERNED_SELECTHOOK
extern LVAL k_selecthook;   /* Keyword ":SELECT-HOOK" */
#define EXTERNED_SELECTHOOK
#endif

#ifndef EXTERNED_DESELECTHOOK
extern LVAL k_deselecthook;   /* Keyword ":DESELECT-HOOK" */
#define EXTERNED_DESELECTHOOK
#endif

#ifndef EXTERNED_RESELECTHOOK
extern LVAL k_reselecthook;   /* Keyword ":RESELECT-HOOK" */
#define EXTERNED_RESELECTHOOK
#endif

#ifndef EXTERNED_POINTRELATION
extern LVAL k_pointrelation;   /* Keyword ":point-relation" */
#define EXTERNED_POINTRELATION
#endif

#ifndef EXTERNED_PIXELRELATION
extern LVAL k_pixelrelation;   /* Keyword ":pixel-relation" */
#define EXTERNED_PIXELRELATION
#endif

#ifndef EXTERNED_FACETIF
extern LVAL k_facetif;   /* Keyword ":facet-if" */
#define EXTERNED_FACETIF
#endif

#ifndef EXTERNED_POINTIF
extern LVAL k_pointif;   /* Keyword ":point-if" */
#define EXTERNED_POINTIF
#endif

#ifndef EXTERNED_DRAW
extern LVAL k_draw;   /* Keyword ":draw" */
#define EXTERNED_DRAW
#endif

#ifndef EXTERNED_FACETRELATION
extern LVAL k_facetrelation;   /* Keyword ":facet-relation" */
#define EXTERNED_FACETRELATION
#endif

#ifndef EXTERNED_LIGHTS
extern LVAL k_lights;   /* Keyword ":lights" */
#define EXTERNED_LIGHTS
#endif

#ifndef EXTERNED_LIGHTINGMODEL
extern LVAL k_lightingmodel;   /* Keyword ":lighting-model" */
#define EXTERNED_LIGHTINGMODEL
#endif

#ifndef EXTERNED_MATERIAL
extern LVAL k_material;   /* Keyword ":material" */
#define EXTERNED_MATERIAL
#endif

#ifndef EXTERNED_TRANSFORM
extern LVAL k_transform;   /* Keyword ":transform" */
#define EXTERNED_TRANSFORM
#endif

#ifndef EXTERNED_INITIALCONTENTS
extern LVAL k_initialcontents;/* Keyword ":initial-contents" */
#define EXTERNED_INITIALCONTENTS
#endif

#ifndef EXTERNED_INITIALIZEFROMFILE
extern LVAL k_initializefromfile;/* Keyword ":initialize-from-file" */
#define EXTERNED_INITIALIZEFROMFILE
#endif

#ifndef EXTERNED_AXIS
extern LVAL k_axis;/* Keyword ":axis" */
#define EXTERNED_AXIS
#endif

#ifndef EXTERNED_TRANSFORMEDAXIS
extern LVAL k_xfmaxis;/* Keyword ":transformed-axis" */
#define EXTERNED_TRANSFORMEDAXIS
#endif

#ifndef EXTERNED_TARGET
extern LVAL k_target;   /* Keyword ":target" */
#define EXTERNED_TARGET
#endif

#ifndef EXTERNED_LOCATION
extern LVAL k_location;   /* Keyword ":location" */
#define EXTERNED_LOCATION
#endif

#ifndef EXTERNED_UP
extern LVAL k_up;      /* Keyword ":up" */
#define EXTERNED_UP
#endif

#ifndef EXTERNED_DIAMETER
extern LVAL k_diameter;     /* Keyword ":diameter" */
#define EXTERNED_DIAMETER
#endif

#ifndef EXTERNED_LEFT
extern LVAL k_left;     /* Keyword ":left" */
#define EXTERNED_LEFT
#endif

#ifndef EXTERNED_RIGHT
extern LVAL k_right;     /* Keyword ":right" */
#define EXTERNED_RIGHT
#endif

#ifndef EXTERNED_TOP
extern LVAL k_top;     /* Keyword ":top" */
#define EXTERNED_TOP
#endif

#ifndef EXTERNED_BOTTOM
extern LVAL k_bottom;     /* Keyword ":bottom" */
#define EXTERNED_BOTTOM
#endif

#ifndef EXTERNED_NEAR
extern LVAL k_near;     /* Keyword ":near" */
#define EXTERNED_NEAR
#endif

#ifndef EXTERNED_FAR
extern LVAL k_far;     /* Keyword ":far" */
#define EXTERNED_FAR
#endif

#ifndef EXTERNED_MOVE
extern LVAL k_move;/* Keyword ":move" */
#define EXTERNED_MOVE
#endif

#ifndef EXTERNED_ORIGIN
extern LVAL k_origin;/* Keyword ":origin" */
#define EXTERNED_ORIGIN
#endif

#ifndef EXTERNED_TRANSFORMEDORIGIN
extern LVAL k_xfmorigin;/* Keyword ":transformed-origin" */
#define EXTERNED_TRANSFORMEDORIGIN
#endif

#ifndef EXTERNED_SCALE
extern LVAL k_scale;/* Keyword ":scale" */
#define EXTERNED_SCALE
#endif

#ifndef EXTERNED_SHEAR
extern LVAL k_shear;/* Keyword ":shear" */
#define EXTERNED_SHEAR
#endif

#ifndef EXTERNED_RADIANS
extern LVAL k_radians;/* Keyword ":radians" */
#define EXTERNED_RADIANS
#endif

#ifndef EXTERNED_DEGREES
extern LVAL k_degrees;/* Keyword ":degrees" */
#define EXTERNED_DEGREES
#endif

#ifndef EXTERNED_ROTATE
extern LVAL k_rotate;/* Keyword ":rotate" */
#define EXTERNED_ROTATE
#endif

#ifndef EXTERNED_XROTATE
extern LVAL k_xrotate;/* Keyword ":x-rotate" */
#define EXTERNED_XROTATE
#endif

#ifndef EXTERNED_YROTATE
extern LVAL k_yrotate;/* Keyword ":y-rotate" */
#define EXTERNED_YROTATE
#endif

#ifndef EXTERNED_ZROTATE
extern LVAL k_zrotate;/* Keyword ":z-rotate" */
#define EXTERNED_ZROTATE
#endif

#ifndef EXTERNED_PERSPECTIVE
extern LVAL k_perspective;   /* Keyword ":perspective" */
#define EXTERNED_PERSPECTIVE
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,	xtfm00_Is_New				)
DEFINE_SUBR(	NULL,	xtfm06_Get_Msg				)
DEFINE_SUBR(	NULL,	xtfm08_Set_Msg				)
DEFINE_SUBR(	NULL,	xtfm16_Copy_Msg				)
DEFINE_SUBR(	NULL,	xtfm18_Move_Msg				)
DEFINE_SUBR(	NULL,	xtfm21_Move_Pre_Msg			)
DEFINE_SUBR(	NULL,	xtfm23_Move_Post_Msg			)
DEFINE_SUBR(	NULL,	xtfm60_Scale_Msg			)
DEFINE_SUBR(	NULL,	xtfm63_Scale_Pre_Msg			)
DEFINE_SUBR(	NULL,	xtfm65_Scale_Post_Msg			)
DEFINE_SUBR(	NULL,	xtfm67_Shear_Msg			)
DEFINE_SUBR(	NULL,	xtfm70_Shear_Pre_Msg			)
DEFINE_SUBR(	NULL,	xtfm72_Shear_Post_Msg			)
DEFINE_SUBR(	NULL,	xtfm10_Matrix_Multiply_Msg		)
DEFINE_SUBR(	NULL,	xtfm12_Matrix_Multiply_Pre_Msg		)
DEFINE_SUBR(	NULL,	xtfm14_Matrixt_Multiply_Post_Msg        )
DEFINE_SUBR(	NULL,	xtfm25_Rotate_Msg			)
DEFINE_SUBR(	NULL,	xtfm27_Rotate_Pre_Msg			)
DEFINE_SUBR(	NULL,	xtfm30_Rotate_Post_Msg			)
DEFINE_SUBR(	NULL,	xtfm33_X_Rotate_Msg			)
DEFINE_SUBR(	NULL,	xtfm36_X_Rotate_Pre_Msg			)
DEFINE_SUBR(	NULL,	xtfm39_X_Rotate_Post_Msg		)
DEFINE_SUBR(	NULL,	xtfm42_Y_Rotate_Msg			)
DEFINE_SUBR(	NULL,	xtfm45_Y_Rotate_Pre_Msg			)
DEFINE_SUBR(	NULL,	xtfm48_Y_Rotate_Post_Msg		)
DEFINE_SUBR(	NULL,	xtfm51_Z_Rotate_Msg			)
DEFINE_SUBR(	NULL,	xtfm54_Z_Rotate_Pre_Msg			)
DEFINE_SUBR(	NULL,	xtfm57_Z_Rotate_Post_Msg		)
DEFINE_SUBR(	NULL,	xtfm04_Identity_Msg			)
DEFINE_SUBR(	NULL,	xtfm03_Show_Msg				)
DEFINE_SUBR(    NULL,	xtfm86_Get_Msg				)
DEFINE_SUBR(    NULL,	xtfm89_Set_Msg  			)
DEFINE_SUBR(    NULL,   xtfm75_Transform_Point_Msg		)
DEFINE_SUBR(    NULL,   xtfm77_Transform_Normal_Msg		)
DEFINE_SUBR(    NULL,   xtfm79_Invert_Msg			)
DEFINE_SUBR(    NULL,   xtfm81_Transpose_Msg			)
DEFINE_SUBR(    NULL,   xtfm94_Frame_Things_Msg			)
DEFINE_SUBR(    NULL,   xtfmd1_Turtle_Forward_Msg		)
DEFINE_SUBR(    NULL,   xtfmd4_Turtle_Pitch_Msg			)
DEFINE_SUBR(    NULL,   xtfmd7_Turtle_Roll_Msg			)
DEFINE_SUBR(    NULL,   xtfmd9_Turtle_Yaw_Msg			)
DEFINE_SUBR(    NULL,   xtfmdb_Turtle_Right_Msg			)
DEFINE_SUBR(    NULL,   xtfmdd_Turtle_Up_Msg			)
DEFINE_SUBR(	NULL,	xtfme1_ProplistLength_Msg		)
DEFINE_SUBR(	NULL,	xtfme5_ProplistNth_Msg			)
DEFINE_SUBR(	NULL,	xtfmF0_Copy_Contents_Msg		)
DEFINE_SUBR(	NULL,	xtfmF4_Copy_Spaceball_Matrix_Msg	)
DEFINE_SUBR(    NULL,   xtfmG5_Set_To_Product_Msg		)
DEFINE_SUBR(    NULL,   xtfmH1_Decompose_Msg			)
DEFINE_SUBR(    "XG.3D-COMBINE-ROTATIONS",   xtfmH2_Combine_Rotations_Fn )
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xtfm;
LOCAL struct xtfm_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xtfm_table[] = {
    {	":ISNEW",		xtfm00_Is_New			},
    {	":AREF",		xtfm06_Get_Msg			},
    {	":SETF",		xtfm08_Set_Msg			},
    {	":COPY",		xtfm16_Copy_Msg			},
    {	":MOVE",		xtfm18_Move_Msg			},
    {	":MOVE-PRE",		xtfm21_Move_Pre_Msg		},
    {	":MOVE-POST",		xtfm23_Move_Post_Msg		},
    {	":SCALE",		xtfm60_Scale_Msg		},
    {	":SCALE-PRE",		xtfm63_Scale_Pre_Msg		},
    {	":SCALE-POST",		xtfm65_Scale_Post_Msg		},
    {	":SHEAR",		xtfm67_Shear_Msg		},
    {	":SHEAR-PRE",		xtfm70_Shear_Pre_Msg		},
    {	":SHEAR-POST",		xtfm72_Shear_Post_Msg		},
    {	":MULT",		xtfm10_Matrix_Multiply_Msg	},
    {	":MULT-PRE",		xtfm12_Matrix_Multiply_Pre_Msg	},
    {	":MULT-POST",		xtfm14_Matrixt_Multiply_Post_Msg},
    {	":ROTATE",		xtfm25_Rotate_Msg		},
    {	":ROTATE-PRE",		xtfm27_Rotate_Pre_Msg		},
    {	":ROTATE-POST",		xtfm30_Rotate_Post_Msg		},
    {	":X-ROTATE",		xtfm33_X_Rotate_Msg		},
    {	":X-ROTATE-PRE",	xtfm36_X_Rotate_Pre_Msg		},
    {	":X-ROTATE-POST",	xtfm39_X_Rotate_Post_Msg	},
    {	":Y-ROTATE",		xtfm42_Y_Rotate_Msg		},
    {	":Y-ROTATE-PRE",	xtfm45_Y_Rotate_Pre_Msg		},
    {	":Y-ROTATE-POST",	xtfm48_Y_Rotate_Post_Msg	},
    {	":Z-ROTATE",		xtfm51_Z_Rotate_Msg		},
    {	":Z-ROTATE-PRE",	xtfm54_Z_Rotate_Pre_Msg		},
    {	":Z-ROTATE-POST",	xtfm57_Z_Rotate_Post_Msg	},
    {	":SET-TO-IDENTITY",	xtfm04_Identity_Msg		},
    {	":SHOW",		xtfm03_Show_Msg			},
    {	":GET",			xtfm86_Get_Msg			},
    {	":SET",			xtfm89_Set_Msg			},
    {	":TRANSFORM-POINT",	xtfm75_Transform_Point_Msg	},
    {	":TRANSFORM-NORMAL",	xtfm77_Transform_Normal_Msg	},
    {	":INVERT",		xtfm79_Invert_Msg		},
    {	":TRANSPOSE",		xtfm81_Transpose_Msg		},
    {	":FRAME-THINGS",	xtfm94_Frame_Things_Msg		},
    {	":TURTLE-FORWARD",	xtfmd1_Turtle_Forward_Msg	},
    {	":TURTLE-PITCH",	xtfmd4_Turtle_Pitch_Msg		},
    {	":TURTLE-ROLL",		xtfmd7_Turtle_Roll_Msg		},
    {	":TURTLE-YAW",		xtfmd9_Turtle_Yaw_Msg		},
    {	":TURTLE-RIGHT",	xtfmdb_Turtle_Right_Msg		},
    {	":TURTLE-UP",		xtfmdd_Turtle_Up_Msg		},
    {	":PROPERTY-LIST-LENGTH",xtfme1_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xtfme5_ProplistNth_Msg		},
    {	":COPY-CONTENTS",	xtfmF0_Copy_Contents_Msg	},
    {	":COPY-SPACEBALL-MATRIX",xtfmF4_Copy_Spaceball_Matrix_Msg},
    {   ":SET-TO-PRODUCT",      xtfmG5_Set_To_Product_Msg	},
    {	":DECOMPOSE",		xtfmH1_Decompose_Msg		},
    {	NULL,			NULL				}
};



#ifndef DEFINED_S_PROPERTYLIST
LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define DEFINED_S_PROPERTYLIST
#endif

#ifndef DEFINED_PERFRAMEHOOK
LVAL k_perframehook;   /* Keyword ":per-frame-hook" */
#define DEFINED_PERFRAMEHOOK
#endif

#ifndef DEFINED_DOWNCLICKHOOK
LVAL k_downclickhook;   /* Keyword ":downclick-hook" */
#define DEFINED_DOWNCLICKHOOK
#endif

#ifndef DEFINED_DRAGHOOK
LVAL k_draghook;   /* Keyword ":drag-hook" */
#define DEFINED_DRAGHOOK
#endif

#ifndef DEFINED_UPCLICKHOOK
LVAL k_upclickhook;   /* Keyword ":upclick-hook" */
#define DEFINED_UPCLICKHOOK
#endif

#ifndef DEFINED_SELECTHOOK
LVAL k_selecthook;   /* Keyword ":select-hook" */
#define DEFINED_SELECTHOOK
#endif

#ifndef DEFINED_DESELECTHOOK
LVAL k_deselecthook;   /* Keyword ":deselect-hook" */
#define DEFINED_DESELECTHOOK
#endif

#ifndef DEFINED_RESELECTHOOK
LVAL k_reselecthook;   /* Keyword ":reselect-hook" */
#define DEFINED_RESELECTHOOK
#endif

#ifndef DEFINED_POINTRELATION
LVAL k_pointrelation;   /* Keyword ":point-relation" */
#define DEFINED_POINTRELATION
#endif

#ifndef DEFINED_PIXELRELATION
LVAL k_pixelrelation;   /* Keyword ":pixel-relation" */
#define DEFINED_PIXELRELATION
#endif

#ifndef DEFINED_FACETIF
LVAL k_facetif;   /* Keyword ":facet-if" */
#define DEFINED_FACETIF
#endif

#ifndef DEFINED_POINTIF
LVAL k_pointif;   /* Keyword ":point-if" */
#define DEFINED_POINTIF
#endif

#ifndef DEFINED_DRAW
LVAL k_draw;   /* Keyword ":draw" */
#define DEFINED_DRAW
#endif

#ifndef DEFINED_FACETRELATION
LVAL k_facetrelation;   /* Keyword ":facet-relation" */
#define DEFINED_FACETRELATION
#endif

#ifndef DEFINED_LIGHTS
LVAL k_lights;   /* Keyword ":lights" */
#define DEFINED_LIGHTS
#endif

#ifndef DEFINED_LIGHTINGMODEL
LVAL k_lightingmodel;   /* Keyword ":lighting-model" */
#define DEFINED_LIGHTINGMODEL
#endif

#ifndef DEFINED_MATERIAL
LVAL k_material;   /* Keyword ":material" */
#define DEFINED_MATERIAL
#endif

#ifndef DEFINED_TRANSFORM
LVAL k_transform;   /* Keyword ":transform" */
#define DEFINED_TRANSFORM
#endif

#ifndef DEFINED_TARGET
LVAL k_target;   /* Keyword ":target" */
#define DEFINED_TARGET
#endif

#ifndef DEFINED_LOCATION
LVAL k_location;   /* Keyword ":location" */
#define DEFINED_LOCATION
#endif

#ifndef DEFINED_UP
LVAL k_up;         /* Keyword ":up" */
#define DEFINED_UP
#endif

#ifndef DEFINED_DEGREES
LVAL k_degrees;      /* Keyword ":degrees" */
#define DEFINED_DEGREES
#endif

#ifndef DEFINED_RADIANS
LVAL k_radians;      /* Keyword ":radians" */
#define DEFINED_RADIANS
#endif

#ifndef DEFINED_DIAMETER
LVAL k_diameter;     /* Keyword ":diameter" */
#define DEFINED_DIAMETER
#endif

#ifndef DEFINED_LEFT
LVAL k_left;     /* Keyword ":left" */
#define DEFINED_LEFT
#endif

#ifndef DEFINED_RIGHT
LVAL k_right;     /* Keyword ":right" */
#define DEFINED_RIGHT
#endif

#ifndef DEFINED_TOP
LVAL k_top;     /* Keyword ":top" */
#define DEFINED_TOP
#endif

#ifndef DEFINED_BOTTOM
LVAL k_bottom;     /* Keyword ":bottom" */
#define DEFINED_BOTTOM
#endif

#ifndef DEFINED_NEAR
LVAL k_near;     /* Keyword ":near" */
#define DEFINED_NEAR
#endif

#ifndef DEFINED_FAR
LVAL k_far;     /* Keyword ":far" */
#define DEFINED_FAR
#endif

#ifndef DEFINED_INITIALCONTENTS
LVAL k_initialcontents;/* Keyword ":initial-contents" */
#define DEFINED_INITIALCONTENTS
#endif

#ifndef DEFINED_INITIALIZEFROMFILE
LVAL k_initializefromfile;/* Keyword ":initialize-from-file" */
#define DEFINED_INITIALIZEFROMFILE
#endif

#ifndef DEFINED_AXIS
LVAL k_axis;/* Keyword ":axis" */
#define DEFINED_AXIS
#endif

#ifndef DEFINED_TRANSFORMEDAXIS
LVAL k_xfmaxis;/* Keyword ":transformed-axis" */
#define DEFINED_TRANSFORMEDAXIS
#endif

#ifndef DEFINED_MOVE
LVAL k_move;/* Keyword ":move" */
#define DEFINED_MOVE
#endif

#ifndef DEFINED_ORIGIN
LVAL k_origin;/* Keyword ":origin" */
#define DEFINED_ORIGIN
#endif

#ifndef DEFINED_TRANSFORMEDORIGIN
LVAL k_xfmorigin;/* Keyword ":transformed-origin" */
#define DEFINED_TRANSFORMEDORIGIN
#endif

#ifndef DEFINED_SCALE
LVAL k_scale;/* Keyword ":scale" */
#define DEFINED_SCALE
#endif

#ifndef DEFINED_SHEAR
LVAL k_shear;/* Keyword ":shear" */
#define DEFINED_SHEAR
#endif

#ifndef DEFINED_ROTATE
LVAL k_rotate;/* Keyword ":rotate" */
#define DEFINED_ROTATE
#endif

#ifndef DEFINED_XROTATE
LVAL k_xrotate;/* Keyword ":x-rotate" */
#define DEFINED_XROTATE
#endif

#ifndef DEFINED_YROTATE
LVAL k_yrotate;/* Keyword ":y-rotate" */
#define DEFINED_YROTATE
#endif

#ifndef DEFINED_ZROTATE
LVAL k_zrotate;/* Keyword ":z-rotate" */
#define DEFINED_ZROTATE
#endif

#ifndef DEFINED_PERSPECTIVE
LVAL k_perspective;   /* Keyword ":perspective" */
#define DEFINED_PERSPECTIVE
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_S_PROPERTYLIST
    s_propertylist = xlenter("PROPERTY-LIST");
#define CREATED_S_PROPERTYLIST
#endif

#ifndef CREATED_PERFRAMEHOOK
    k_perframehook = xlenter(":PER-FRAME-HOOK");
#define CREATED_PERFRAMEHOOK
#endif

#ifndef CREATED_DOWNCLICKHOOK
    k_downclickhook = xlenter(":DOWNCLICK-HOOK");
#define CREATED_DOWNCLICKHOOK
#endif

#ifndef CREATED_DRAGHOOK
    k_draghook = xlenter(":DRAG-HOOK");
#define CREATED_DOWNCLICKHOOK
#endif

#ifndef CREATED_UPCLICKHOOK
    k_upclickhook = xlenter(":UPCLICK-HOOK");
#define CREATED_UPCLICKHOOK
#endif

#ifndef CREATED_SELECTHOOK
    k_selecthook = xlenter(":SELECT-HOOK");
#define CREATED_SELECTHOOK
#endif

#ifndef CREATED_DESELECTHOOK
    k_deselecthook = xlenter(":DESELECT-HOOK");
#define CREATED_DESELECTHOOK
#endif

#ifndef CREATED_RESELECTHOOK
    k_reselecthook = xlenter(":RESELECT-HOOK");
#define CREATED_RESELECTHOOK
#endif

#ifndef CREATED_POINTRELATION
    k_pointrelation = xlenter(":POINT-RELATION");
#define CREATED_POINTRELATION
#endif

#ifndef CREATED_PIXELRELATION
    k_pixelrelation = xlenter(":PIXEL-RELATION");
#define CREATED_PIXELRELATION
#endif

#ifndef CREATED_FACETIF
    k_facetif = xlenter(":FACET-IF");
#define CREATED_FACETIF
#endif

#ifndef CREATED_POINTIF
    k_pointif = xlenter(":POINT-IF");
#define CREATED_POINTIF
#endif

#ifndef CREATED_DRAW
    k_draw = xlenter(":DRAW");
#define CREATED_DRAW
#endif

#ifndef CREATED_FACETRELATION
    k_facetrelation = xlenter(":FACET-RELATION");
#define CREATED_FACETRELATION
#endif

#ifndef CREATED_LIGHTS
    k_lights = xlenter(":LIGHTS");
#define CREATED_LIGHTS
#endif

#ifndef CREATED_LIGHTINGMODEL
    k_lightingmodel = xlenter(":LIGHTING-MODEL");
#define CREATED_LIGHTINGMODEL
#endif

#ifndef CREATED_MATERIAL
    k_material = xlenter(":MATERIAL");
#define CREATED_MATERIAL
#endif

#ifndef CREATED_TRANSFORM
    k_transform = xlenter(":TRANSFORM");
#define CREATED_TRANSFORM
#endif

#ifndef CREATED_TARGET
    k_target = xlenter(":TARGET");
#define CREATED_TARGET
#endif

#ifndef CREATED_LOCATION
    k_location = xlenter(":LOCATION");
#define CREATED_LOCATION
#endif

#ifndef CREATED_UP
    k_up = xlenter(":UP");
#define CREATED_UP
#endif

#ifndef CREATED_DIAMETER
    k_diameter = xlenter(":DIAMETER");
#define CREATED_DIAMETER
#endif

#ifndef CREATED_LEFT
    k_left = xlenter(":LEFT");
#define CREATED_LEFT
#endif

#ifndef CREATED_RIGHT
    k_right = xlenter(":RIGHT");
#define CREATED_RIGHT
#endif

#ifndef CREATED_TOP
    k_top = xlenter(":TOP");
#define CREATED_TOP
#endif

#ifndef CREATED_BOTTOM
    k_bottom = xlenter(":BOTTOM");
#define CREATED_BOTTOM
#endif

#ifndef CREATED_NEAR
    k_near = xlenter(":NEAR");
#define CREATED_NEAR
#endif

#ifndef CREATED_FAR
    k_far = xlenter(":FAR");
#define CREATED_FAR
#endif

#ifndef CREATED_INITIALCONTENTS
    k_initialcontents = xlenter(":INITIAL-CONTENTS");
#define CREATED_INITIALCONTENTS
#endif

#ifndef CREATED_INITIALIZEFROMFILE
    k_initializefromfile = xlenter(":INITIALIZE-FROM-FILE");
#define CREATED_INITIALIZEFROMFILE
#endif

#ifndef CREATED_AXIS
    k_axis = xlenter(":AXIS");
#define CREATED_AXIS
#endif

#ifndef CREATED_TRANSFORMEDAXIS
    k_xfmaxis = xlenter(":TRANSFORMED-AXIS");
#define CREATED_TRANSFORMEDAXIS
#endif

#ifndef CREATED_MOVE
    k_move = xlenter(":MOVE");
#define CREATED_MOVE
#endif

#ifndef CREATED_ORIGIN
    k_origin = xlenter(":ORIGIN");
#define CREATED_ORIGIN
#endif

#ifndef CREATED_TRANSFORMEDORIGIN
    k_xfmorigin = xlenter(":TRANSFORMED-ORIGIN");
#define CREATED_TRANSFORMEDORIGIN
#endif

#ifndef CREATED_SCALE
    k_scale = xlenter(":SCALE");
#define CREATED_SCALE
#endif

#ifndef CREATED_SHEAR
    k_shear = xlenter(":SHEAR");
#define CREATED_SHEAR
#endif

#ifndef CREATED_RADIANS
    k_radians = xlenter(":RADIANS");
#define CREATED_RADIANS
#endif

#ifndef CREATED_DEGREES
    k_degrees = xlenter(":DEGREES");
#define CREATED_DEGREES
#endif

#ifndef CREATED_ROTATE
    k_rotate = xlenter(":ROTATE");
#define CREATED_ROTATE
#endif

#ifndef CREATED_XROTATE
    k_xrotate = xlenter(":X-ROTATE");
#define CREATED_XROTATE
#endif

#ifndef CREATED_YROTATE
    k_yrotate = xlenter(":Y-ROTATE");
#define CREATED_YROTATE
#endif

#ifndef CREATED_ZROTATE
    k_zrotate = xlenter(":Z-ROTATE");
#define CREATED_ZROTATE
#endif

#ifndef CREATED_PERSPECTIVE
    k_perspective = xlenter(":PERSPECTIVE");
#define CREATED_PERSPECTIVE
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xtfm = xgbj58_Create_Class("CLASS-MATRIX44",lv_x03d);
    xgbj56_Enter_Messages( lv_xtfm,  xtfm_table );
#endif


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
