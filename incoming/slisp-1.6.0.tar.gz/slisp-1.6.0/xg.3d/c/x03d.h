/* {{{ x03d.h -- Class 3D, superclass for 3d/c/* classes.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      92Feb11
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_x03d;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL x03d00_Is_New();
extern LVAL x03d08_Copy_Msg();
extern LVAL x03d03_Show_Msg();
extern LVAL x03d76_Get_Msg();
extern LVAL x03d79_Set_Msg();
extern LVAL x03d88_RemProp_Msg();
extern LVAL x03d91_ProplistLength_Msg();
extern LVAL x03d95_ProplistNth_Msg();
extern LVAL x03d9e_Maybe_Run_Perframehooks_Msg();
extern LVAL x03dA1_Is_A_Fn();
extern LVAL x03dF0_Answer_Msg();



#ifndef EXTERNED_S_PROPERTYLIST
extern LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define EXTERNED_S_PROPERTYLIST
#endif

#ifndef EXTERNED_FRAMETIGHTLY
extern LVAL k_frametightly;/* Keyword ":FRAME-TIGHTLY" */
#define EXTERNED_FRAMETIGHTLY
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL	,	x03d00_Is_New				)
DEFINE_SUBR(	NULL	,	x03d08_Copy_Msg				)
DEFINE_SUBR(	NULL	,	x03d03_Show_Msg				)
DEFINE_SUBR(	NULL	,	x03d76_Get_Msg				)
DEFINE_SUBR(	NULL	,	x03d79_Set_Msg				)
DEFINE_SUBR(	NULL	,	x03d88_RemProp_Msg			)
DEFINE_SUBR(	NULL	,	x03d91_ProplistLength_Msg		)
DEFINE_SUBR(	NULL	,	x03d95_ProplistNth_Msg			)
DEFINE_SUBR(	NULL	,	x03d9e_Maybe_Run_Perframehooks_Msg	)
DEFINE_SUBR(	"IS-A"	,	x03dA1_Is_A_Fn				)
DEFINE_SUBR(	NULL	,	x03dF0_Answer_Msg			)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_x03d;
LOCAL struct x03d_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} x03d_table[] = {
    {	":ISNEW",			x03d00_Is_New			},
    {	":COPY",			x03d08_Copy_Msg			},
    {	":SHOW",			x03d03_Show_Msg			},
    {	":GET", 			x03d76_Get_Msg			},
    {	":SET", 			x03d79_Set_Msg			},
    {	":REMPROP", 			x03d88_RemProp_Msg		},
    {	":PROPERTY-LIST-LENGTH",	x03d91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",		x03d95_ProplistNth_Msg		},
    {	":MAYBE-RUN-PER-FRAME-HOOK",	x03d9e_Maybe_Run_Perframehooks_Msg},

    {	NULL,			NULL				}
};



#ifndef DEFINED_S_PROPERTYLIST
LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define DEFINED_S_PROPERTYLIST
#endif

#ifndef DEFINED_FRAMETIGHTLY
LVAL k_frametightly;/* Keyword ":FRAME-TIGHTLY" */
#define DEFINED_FRAMETIGHTLY
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_S_PROPERTYLIST
    s_propertylist = xlenter("PROPERTY-LIST");
#define CREATED_S_PROPERTYLIST
#endif

#ifndef CREATED_FRAMETIGHTLY
    k_frametightly = xlenter(":FRAME-TIGHTLY");
#define CREATED_FRAMETIGHTLY
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_x03d = xgbj58_Create_Class("CLASS-3D",k_closed_gobject);
    xgbj57_Add_Instance_Variable( lv_x03d,"PROPERTY-LIST");
    xgbj56_Enter_Messages( lv_x03d,  x03d_table );
    xladdmsg(cls_class,":ANSWER",funtab_offset(x03dF0_Answer_Msg));
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
