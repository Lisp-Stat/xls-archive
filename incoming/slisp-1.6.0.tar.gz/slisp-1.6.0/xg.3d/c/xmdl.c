/* {{{ xmdl.c -- lighting models.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Aug19
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 91Aug19 jsp: Created.						*/

/* }}} */
/* {{{ --- header stuff ---						*/
  

#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xmdl;
extern LVAL k_ambientcolor;
extern LVAL k_cameraislocal;
extern LVAL k_dolightingattenuation;
extern LVAL k_fixedattenuation;
extern LVAL k_initializefromfile;
extern LVAL k_variableattenuation;

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 
LVAL xmdl41_Set();

#include <math.h>
#include "geo.h"
#include "csry.h"
#include "cmdl.h"
#include "ctfm.h"
#include "lib.h"
#include "cgrl.h"
#include "c03d.h"
#include "cthl.h"
#include "../../xg.3d.fileio/c/cfil.h"

gt_light_model_rec * xmdl04_Get_Light_Model_Rec();
cmdl_rec* xmdl9c_Find_Immediate_Base();

/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xmdl00_Is_New -- Initialize a new xmdl instance.			*/

cmdl_rec xmdl_defaults = { /* Also used in xgtm.c ... */
    C03D_xMDL,			/* k_class			*/
    C03D_FILEiNFO_INIT,         /* Always 2nd in record.        */
    {	1,			/* model_ID			*/
        0,			/* camera_is_local		*/
	0,			/* do_lighting_attenuation	*/
	1,			/* dirty			*/

	{0.2, 0.2, 0.2},	/* ambient_color		*/
	1.0,			/* fixed-attenuation		*/   
	0.0,			/* variable-attenuation		*/   
    },
};

LVAL xmdl00_Is_New()
{
    static models_created = 5;/* 0 is SGI GL-reserved, we use 1 internally. */
			      /* 2,3,4,5 are just fudge factor.             */
  
    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL lv    = xlgagobject();
    cmdl_rec* r;

#ifdef DONT_DO_IT
    /* We haven't set our k_class field yet, so this test won't work. */
    if (!xmdlp(lv))   xlbadtype(lv);
#endif

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( lv, sizeof( cmdl_rec ) );

    /* Initialize light-model record to reasonable default values: */
    r	= xmdl9c_Find_Immediate_Base( lv );
   *r   = xmdl_defaults;
    xfil50_Maybe_Note_New_3D_Object( lv );

    /* Issue each model a unique id: */
    r->r.model_ID   = ++models_created;
    r->r.dirty      = TRUE;

    /* Parse user args and save in r: */
    {   struct ctfm_Put_Rec r;
        xmdl41_Set( lv, &r );
    }

    return lv;
}

/* }}} */
/* {{{ xmdl01_Get_A_XMDL -- Get arg, must be of class xmdl.		*/

LVAL xmdl01_Get_A_XMDL()
/*-
    Get arg, must be of class xmdl.
-*/
{
    LVAL m_as_lval = xlgagobject();

    /* Nobody but class XMDL has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xmdl.  Similarly,          */
    /* nobody but nobody has any business resizing a xmdl,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    if (!xmdlp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) != sizeof(cmdl_rec) 
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}

/* }}} */
/* {{{ xmdl03_Show_Msg -- Show the contents of a cmdl.			*/

LVAL xmdl03_Show_Msg()
/*-
    Show the contents of a mdl.
-*/
{
    LVAL self,fptr;

    /* get self and the file pointer */
    self = xmdl01_Get_A_XMDL();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the mdl record: */
    {
	gt_light_model_rec * p = xmdl04_Get_Light_Model_Rec( self );
	libE5_xlprint_int(  "camera_is_local"  , p->camera_is_local        ,fptr);
	libE5_xlprint_int(  "model_ID"         , p->model_ID               ,fptr);
	libE7_xlprint_point("ambient_color"    ,&p->ambient_color          ,fptr);
	libE5_xlprint_int(  "do_attenuation"   , p->do_lighting_attenuation,fptr);
	libE6_xlprint_float("fixed_attenuation", p->fixed_attenuation      ,fptr);
	libE6_xlprint_float("variable_attenuation",p->variable_attenuation ,fptr);
    }


    /* return the gobject */
    return self;
}

/* }}} */
/* {{{ xmdl04_Get_Light_Model_Rec -- Get pointer to internal record.	*/

gt_light_model_rec * xmdl04_Get_Light_Model_Rec( lv_model ) /* Called by xtfm.c */
LVAL				     	         lv_model;
/*-
    Get pointer to internal record.
-*/
{
    /* This function sorta breaks the privacy of the class... that's	*/
    /* pretty normal in interfaces to the machine-dependent code   :).	*/
    /* Probably need a way of formally splitting a class this way. :)	*/
    cmdl_rec * l   = xmdl9c_Find_Immediate_Base(       lv_model );

    return &l->r;
}

/* }}} */
/* {{{ xmdl08_Copy_Msg -- Build copy of given CMDL.			*/

LVAL xmdl09_Copy( m_as_lval )
LVAL		  m_as_lval;
/*-
    Build copy of given CMDL.
-*/
{
    /* Create a new gobject to hold result: */
    cmdl_rec*mh = xmdl9c_Find_Immediate_Base( m_as_lval );
    cmdl_rec*nh;
    LVAL r_as_lval;
    xlprot1(m_as_lval);
    r_as_lval   = xsendmsg0(lv_xmdl,k_new);
    xlpop();
    nh = (cmdl_rec*) gobjimmbase( r_as_lval );
    *nh = *mh;

    return r_as_lval;
}

LVAL xmdl08_Copy_Msg()
/*-
    Build copy of given CMDL.
-*/
{   LVAL m_as_lval;
    LVAL x_as_lval = xmdl01_Get_A_XMDL();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    m_as_lval = xmdl09_Copy( x_as_lval );
    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    return m_as_lval;
}

/* }}} */
/* {{{ xmdl28_Equal -- Compare two arrays for equality.			*/

#if SOON_WRITE_IT

LVAL xmdl28_Equal( m_as_lval, n_as_lval )
LVAL		   m_as_lval, n_as_lval;
/*-
    Compare two arrays for equality.
-*/
{
    int i;
    csry_hdr* mh = (csry_hdr*) gobjimmbase( m_as_lval );
    csry_hdr* nh = (csry_hdr*) gobjimmbase( n_as_lval );
    if (mh->s    != nh->s   )         return NIL;
    if (mh->rank != nh->rank)         return NIL;
    for (i = mh->rank;   i --> 0; ) {
        if (mh->dim[i] != nh->dim[i]) return NIL;
    }
    {
	char* mt = (char*) csry_base( m_as_lval );
	char* nt = (char*) csry_base( n_as_lval );
	i        = mh->size * mh->s->sizeof_struct;
	while (--i >= 0) {
	    if (*mt++ != *nt++)       return NIL;
	}
    }

    {
        extern LVAL true;/*xlglob.c*/
        return true;
    }
}

LVAL xmdl29_Equal_Msg()
/*-
    Compare two arrays for equality.  Message protocol.
-*/
{
    LVAL m_as_lval = xmdl01_Get_A_XMDL();
    LVAL n_as_lval = xmdl01_Get_A_XMDL();
    xllastarg();
    return xmdl28_Equal( m_as_lval, n_as_lval );
}
#endif

/* }}} */
/* {{{ xmdl40_Get_Msg -- Get keyword properties.                        */

LVAL xmdl39_Get( lv_model )
LVAL             lv_model;
{
    cmdl_rec* light_model = xmdl9c_Find_Immediate_Base( lv_model );
    LVAL key = xlgasymbol();
    LVAL arg;
    LVAL result;
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();

    if (key == k_ambientcolor) {

        result = lib14_Point_To_List( &light_model->r.ambient_color );

    } else if (key == k_fixedattenuation) {

	result = cvflonum( light_model->r.fixed_attenuation );

    } else if (key == k_variableattenuation) {

	result = cvflonum( light_model->r.variable_attenuation );

    } else if (key == k_cameraislocal) {

        extern LVAL true;/*xlglob.c*/
        result = light_model->r.camera_is_local ? true : NIL;

    } else if (key == k_dolightingattenuation) {

        extern LVAL true;/*xlglob.c*/
        result = light_model->r.do_lighting_attenuation ? true : NIL;

    } else {

	/* If this isn't a property we know, do a generic get property: */
        result = xthl8a_GetObjectProp( lv_model, key, default_val, got_default );
    }
    return result;
}

LVAL xmdl40_Get_Msg()
/*-
    Return keyword properties for a light_model object.
-*/
{
    return xmdl39_Get( xmdl01_Get_A_XMDL() );
}

/* }}} */
/* {{{ xmdl42_Set_Msg -- Write keyword properties.                      */

/* Number of specially interpreted properties for this class.    */
/* If you hack 41_Set, update XMDL_PROPS and xmdl94_ProplistNth. */
#define XMDL_PROPS (5)

LVAL xmdl41_Set( lv_model, r )
LVAL             lv_model;
struct ctfm_Put_Rec	  *r;	/* 95Feb16jsp: Don't think 'r' is ever used.*/
{
    cmdl_rec* light_model = xmdl9c_Find_Immediate_Base( lv_model );

    ctfm70_Initialize_Put_Rec( r );

    while (moreargs()) {
        LVAL init = xlgasymbol();
	LVAL arg;

        if (init == k_ambientcolor) {

            /* Handle ":ambient-color '(1 1 1)" */
            lib17_List_To_Color( &light_model->r.ambient_color, xlgalist() ); 
	    light_model->r.dirty      = TRUE;

        } else if (init == k_fixedattenuation) {

            /* Handle ":fixed-attenuation 0.4" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly fixed-attenuation",tmp);
            light_model->r.fixed_attenuation = tmp;
	    light_model->r.dirty      = TRUE;

        } else if (init == k_variableattenuation) {

            /* Handle ":variable-attenuation 0.4" */
	    float tmp = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );
	    if (tmp < 0.0 || tmp > 1.0)   xlfail("silly variable-attenuation",tmp);
            light_model->r.variable_attenuation = tmp;
	    light_model->r.dirty      = TRUE;

        } else if (init == k_cameraislocal) {

	    light_model->r.camera_is_local = !null(xlgetarg());
	    light_model->r.dirty      = TRUE;

        } else if (init == k_dolightingattenuation) {

	    light_model->r.do_lighting_attenuation = !null(xlgetarg());
	    light_model->r.dirty      = TRUE;

        } else if (init == k_initializefromfile) {

            /* Handle ":initialize-from-file <file-pointer> ..." */
	    int xmdlz7_Read_Xmdl_From_File();
	    cfil49_Read_Binary_Rec_Header_From_File(
		lv_model,
		getfile(xlgetfile()),
		xmdlz7_Read_Xmdl_From_File,NULL
	    );

	} else {

            /* If this isn't a property we know, do a generic set property: */
            x03d9b_SetObjectProp( lv_model, init, xlgetarg() );
    }   }

    return lv_model;
}

LVAL xmdl42_Set_Msg()
/*-
    Read keyword properties for a light_model object.
-*/
{
    struct ctfm_Put_Rec r;
    LVAL   lv_model = xmdl01_Get_A_XMDL();
    LVAL   result    = xmdl41_Set( lv_model, &r );
    return result;
}

/* }}} */
/* {{{ xmdl91_ProplistLength_Msg -- Return length of propertylist.      */

LVAL xmdl90_ProplistLength( g_as_lval )
LVAL                        g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    xllastarg();
    return cvfixnum( XMDL_PROPS + x03d89_PropListLength( *pPropList ) );
}

LVAL xmdl91_ProplistLength_Msg()
/*-
    Return length of propertylist.
-*/
{
    return xmdl90_ProplistLength( xmdl01_Get_A_XMDL() );
}

/* }}} */
/* {{{ xmdl95_ProplistNth_Msg -- Return Nth prop from propertylist.     */

LVAL xmdl94_ProplistNth( g_as_lval )
LVAL                     g_as_lval;
{
    LVAL*pPropList  = x03d73_pPropList( g_as_lval );
    LVAL n_as_lval  = xlgafixnum();
    int  n          = getfixnum(n_as_lval);
    LVAL default_val = NIL;
    int  got_default = FALSE;
    if (moreargs()) {
	default_val  = xlgetarg();
	got_default  = TRUE;
    }
    xllastarg();
    switch (n) {
    case 0:    return k_ambientcolor;
    case 1:    return k_fixedattenuation;
    case 2:    return k_variableattenuation;
    case 3:    return k_cameraislocal;
    case 4:    return k_dolightingattenuation;
    default:
	return xthl93_ListNth(
	    *pPropList,
	    n - XMDL_PROPS,
	    n_as_lval,
	    default_val,
	    got_default
	);
    }
}

LVAL xmdl95_ProplistNth_Msg()
/*-
    Return Nth item from propertylist.
-*/
{
    return xmdl94_ProplistNth( xmdl01_Get_A_XMDL() );
}

/* }}} */
/* {{{ xmdl9c_Find_Immediate_Base					*/

cmdl_rec* xmdl9c_Find_Immediate_Base( lv )
LVAL				      lv;
{   int     csux = x03d9d_Maybe_Run_PerframeHooks( lv );
    cmdl_rec*mdl = (cmdl_rec*) gobjimmbase( lv );
    return mdl;
}

/* }}} */
/* {{{ xmdlF0_Copy_Contents_Msg--Copy contents of another xmdl into self*/

LVAL xmdlF1_Copy_Contents( m_as_lval, x_as_lval, depth )
LVAL			   m_as_lval, x_as_lval;
int						 depth;
{
    cmdl_rec * m = xmdl9c_Find_Immediate_Base( m_as_lval );
    cmdl_rec * x = xmdl9c_Find_Immediate_Base( x_as_lval );
    c03d_fileInfo f;

    x03d81_CopyProplist( m_as_lval, x_as_lval, depth );
    f           = m->fileInfo;
    *m          = *x;
    m->fileInfo = f;

    return x_as_lval;
}

LVAL xmdlF0_Copy_Contents_Msg()
/*-
    Copy contents of another xmdl into self.
-*/
{
    LVAL m_as_lval = xmdl01_Get_A_XMDL();
    LVAL x_as_lval = xmdl01_Get_A_XMDL();
    int  depth = x03d80_GetProplistCopyDepth();
    xllastarg();
    return xmdlF1_Copy_Contents(m_as_lval,x_as_lval,depth);
}

/* }}} */
/* {{{ xmdlz7_Read_Xmdl_From_File                                       */

xmdlz7_Read_Xmdl_From_File( dum, lv, fp, magic, version )
char                       *dum;
LVAL                             lv;
FILE                                *fp;
CSRY_INT32                               magic;
int                                             version;
{   cmdl_rec* h;
    char*     p;
    if (version != CMDL_REC_VERSION) {
	xlerror("xmdlz7: unsupported version",cvfixnum(version));
    }
    h = (cmdl_rec*) gobjimmbase( lv );

    p = (char*) &h->CMDL_FIRST_INT32;
    p = cfil55_Read_Int32s_From_File(  p, CMDL_INT32_COUNT,  magic, fp );

    p = (char*) &h->CMDL_FIRST_FLOAT;
    p = cfil54_Read_Floats_From_File(  p, CMDL_FLOAT_COUNT,  magic, fp );
}

/* }}} */
/* {{{ xmdlwo_Write_Xmdl_To_Graphics_File                               */

xmdlwo_Write_Xmdl_To_Graphics_File( fdoa, fdob, lv,f,n )
FILE                               *fdoa,*fdob;
LVAL                                            lv;
char                                              *f;
int                                                  n;
{   /* Write code sufficient to recreate ourself, excepting LVAL stuff: */
    LVAL name = x03dfc_Find_Class_Name( lv );
    fprintf(fdoa,"(setq xfil-this (send %s :new",getstring(name));
    fputs("\n  :initialize-from-file XFIL-FD-BINARY))\n"  ,fdoa);
    fprintf(fdoa,"(send xfil-this :set-file-info \"%s/%d\")\n\n",f,n);

    {   cmdl_rec* h = (cmdl_rec*) gobjimmbase( lv );

	/* Write byte-order signature plus record version number: */
	cfil50_Write_Binary_Rec_Header_To_File( fdob, lv, CMDL_REC_VERSION );

	/* Write out our binary data: */
	cfil48_Write_Int32s_To_File(&h->CMDL_FIRST_INT32, CMDL_INT32_COUNT, fdob);
	cfil47_Write_Floats_To_File(&h->CMDL_FIRST_FLOAT, CMDL_FLOAT_COUNT, fdob);
    }
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
