/* {{{ csry.h -- xsry.c library fns.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      90Dec04
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifndef INCLUDED_CSRYH
#define INCLUDED_CSRYH

/* }}} */

#include "c03d.h"

/* A struct type that tells us everything peculiar */
/* to a given class we are supporting:             */
struct csry_struct {
    int  k_class;            /* Will == C03D_XFLV or whatever.  */
    int  sizeof_struct;      /* Size of array elements.         */
    int  (*list_to_struct)();/* Convert '(...) to C struct.     */
    LVAL (*struct_to_list)();/* Convert C struct to '(...)      */
    int  (*sprintf_struct)();/* Sprintf C struct into buffer.   */
    int  (*bcopy)         ();/* Copy C struct from here to there*/
    int  (*initfn)        ();/* Initialize default_initializer  */
    LVAL k_ary;		     /* Class object for array.	        */
    int  (*from_buf)();      /* Copy from buffer to array.      */
    int  (*  to_buf)();      /* Copy from array to buffer.      */
    LVAL (*adjust_array)();  /* Change size/shape of array.     */
    int  (*position)();      /* Find value within array.        */
    int  (*delete)();        /* Slide down values within array. */
};
typedef struct csry_struct  csry_fns;

LVAL xsry00_Is_New();

/* Define this for extra checking: */
#define XSRY_IS_PARANOID (1)

/* Define type for 32-bit integers.  We use a #define */
/* rather than a typedef mostly so the Makefile can   */
/* over-ride us without hacking the source here:      */
#ifndef CSRY_INT32
#define CSRY_INT32 long int
#endif

#ifndef CSRY_UNSIGNED8
#define CSRY_UNSIGNED8 unsigned char
#endif

#ifndef CSRY_UNSIGNED16
#define CSRY_UNSIGNED16 unsigned short
#endif

#ifndef CSRY_SIGNED16
#define CSRY_SIGNED16 signed short
#endif

/* Define struct recording array shape:		      */
#define CSRY_MAX_RANK (7)
struct csry_header {
    int k_class;             /* k_class should always be first in record.   */
    c03d_fileInfo fileInfo;  /* Always 2nd in record. What file to save in. */
    int dim[ CSRY_MAX_RANK ];
    int size;	             /* Current total size of array. */
    int rank;

    union {
	CSRY_SIGNED16   i6;
	CSRY_UNSIGNED16 u6;
	CSRY_UNSIGNED8  u8;
	int              i;
	float            f;
    } default_initializer;
    csry_fns* s;
};
typedef struct csry_header csry_rec;
#define csry_base(x) (((char*) gobjimmbase(x)) + sizeof(csry_rec))

#define xsryp(o) (gobjectp(o) && ((((csry_rec*)(gobjimmbase(o)))->k_class) == C03D_xSRY))

#define CSRY_REC_VERSION (13)

#define CSRY_VECTOR_EXPANSION_INCREMENT (16)
#define CSRY_VECTOR_EXPANSION_RATIO     (16)

/* Some fns: */
LVAL xsry01_Get_A_Struct_Array();
LVAL xsry0c_Get_A_Struct_Array_Or_Grl();
csry_rec* xsry9c_Find_Immediate_Base();

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
#endif
/* }}} */
