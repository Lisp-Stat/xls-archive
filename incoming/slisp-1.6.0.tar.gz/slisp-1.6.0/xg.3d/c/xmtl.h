/* {{{ xmtl.h -- materials.					     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Aug18
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xmtl;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xmtl00_Is_New();
extern LVAL xmtl08_Copy_Msg();
extern LVAL xmtl03_Show_Msg();
extern LVAL xmtl40_Get_Msg();
extern LVAL xmtl42_Set_Msg();
extern LVAL xmtl91_ProplistLength_Msg();
extern LVAL xmtl95_ProplistNth_Msg();
extern LVAL xmtlG5_Set_To_Product_Msg();
extern LVAL xmtlF0_Copy_Contents_Msg();



#ifndef EXTERNED_S_PROPERTYLIST
extern LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define EXTERNED_S_PROPERTYLIST
#endif

#ifndef EXTERNED_EMISSIONCOLOR
extern LVAL k_emissioncolor;  /* Keyword ":emission-color" */
#define EXTERNED_EMISSIONCOLOR
#endif

#ifndef EXTERNED_AMBIENTCOLOR
extern LVAL k_ambientcolor;  /* Keyword ":ambient-color" */
#define EXTERNED_AMBIENTCOLOR
#endif

#ifndef EXTERNED_DIFFUSECOLOR
extern LVAL k_diffusecolor;  /* Keyword ":diffuse-color" */
#define EXTERNED_DIFFUSECOLOR
#endif

#ifndef EXTERNED_SPECULARCOLOR
extern LVAL k_specularcolor;  /* Keyword ":specular-color" */
#define EXTERNED_SPECULARCOLOR
#endif

#ifndef EXTERNED_SHININESS
extern LVAL k_shininess;  /* Keyword ":shininess" */
#define EXTERNED_SHININESS
#endif

#ifndef EXTERNED_ALPHA
extern LVAL k_alpha;  /* Keyword ":alpha" */
#define EXTERNED_ALPHA
#endif

#ifndef EXTERNED_ALPHAIMPLEMENTATION
extern LVAL k_alphaimplementation;  /* Keyword ":alpha-implementation" */
#define EXTERNED_ALPHAIMPLEMENTATION
#endif

#ifndef EXTERNED_ORDEREDDITHER
extern LVAL k_ordereddither;  /* Keyword ":ordered-dither" */
#define EXTERNED_ORDEREDDITHER
#endif

#ifndef EXTERNED_RANDOM16X16PATTERNS
extern LVAL k_random16x16patterns;  /* Keyword ":random-16x16-patterns" */
#define EXTERNED_RANDOM16X16PATTERNS
#endif

#ifndef EXTERNED_RANDOM32X32PATTERNS
extern LVAL k_random32x32patterns;  /* Keyword ":random-32x32-patterns" */
#define EXTERNED_RANDOM32X32PATTERNS
#endif

#ifndef EXTERNED_RANDOM64X64PATTERNS
extern LVAL k_random64x64patterns;  /* Keyword ":random-64x64-patterns" */
#define EXTERNED_RANDOM64X64PATTERNS
#endif

#ifndef EXTERNED_EMISSIONWEIGHT
extern LVAL k_emissionweight;  /* Keyword ":emission-weight" */
#define EXTERNED_EMISSIONWEIGHT
#endif

#ifndef EXTERNED_AMBIENTWEIGHT
extern LVAL k_ambientweight;  /* Keyword ":ambient-weight" */
#define EXTERNED_AMBIENTWEIGHT
#endif

#ifndef EXTERNED_DIFFUSEWEIGHT
extern LVAL k_diffuseweight;  /* Keyword ":diffuse-weight" */
#define EXTERNED_DIFFUSEWEIGHT
#endif

#ifndef EXTERNED_SPECULARWEIGHT
extern LVAL k_specularweight;  /* Keyword ":specular-weight" */
#define EXTERNED_SPECULARWEIGHT
#endif

#ifndef EXTERNED_SHININESSWEIGHT
extern LVAL k_shininessweight;  /* Keyword ":shininess-weight" */
#define EXTERNED_SHININESSWEIGHT
#endif

#ifndef EXTERNED_ALPHAWEIGHT
extern LVAL k_alphaweight;  /* Keyword ":alpha-weight" */
#define EXTERNED_ALPHAWEIGHT
#endif

#ifndef EXTERNED_SHOW
extern LVAL k_show;/* Keyword ":show" */
#define EXTERNED_SHOW
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,	xmtl00_Is_New			)
DEFINE_SUBR(	NULL,	xmtl08_Copy_Msg			)
DEFINE_SUBR(	NULL,	xmtl03_Show_Msg			)
DEFINE_SUBR(	NULL,	xmtl40_Get_Msg			)
DEFINE_SUBR(	NULL,	xmtl42_Set_Msg			)
DEFINE_SUBR(	NULL,	xmtl91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,	xmtl95_ProplistNth_Msg		)
DEFINE_SUBR(    NULL,   xmtlG5_Set_To_Product_Msg	)
DEFINE_SUBR(	NULL,	xmtlF0_Copy_Contents_Msg	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xmtl;
LOCAL struct xmtl_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xmtl_table[] = {
    {	":ISNEW",		xmtl00_Is_New			},
    {	":COPY",		xmtl08_Copy_Msg			},
    {	":SHOW",		xmtl03_Show_Msg			},
    {	":GET", 		xmtl40_Get_Msg			},
    {	":SET", 		xmtl42_Set_Msg			},
    {	":PROPERTY-LIST-LENGTH",xmtl91_ProplistLength_Msg	},
    {	":PROPERTY-LIST-NTH",	xmtl95_ProplistNth_Msg		},
    {   ":SET-TO-PRODUCT",      xmtlG5_Set_To_Product_Msg	},
    {	":COPY-CONTENTS",	xmtlF0_Copy_Contents_Msg	},

    {	NULL,			NULL				}
};



#ifndef DEFINED_S_PROPERTYLIST
LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define DEFINED_S_PROPERTYLIST
#endif

#ifndef DEFINED_EMISSIONCOLOR
LVAL k_emissioncolor;   /* Keyword ":emission-color" */
#define DEFINED_EMISSIONCOLOR
#endif

#ifndef DEFINED_AMBIENTCOLOR
LVAL k_ambientcolor;   /* Keyword ":ambient-color" */
#define DEFINED_AMBIENTCOLOR
#endif

#ifndef DEFINED_DIFFUSECOLOR
LVAL k_diffusecolor;   /* Keyword ":diffuse-color" */
#define DEFINED_DIFFUSECOLOR
#endif

#ifndef DEFINED_SPECULARCOLOR
LVAL k_specularcolor;   /* Keyword ":specular-color" */
#define DEFINED_SPECULARCOLOR
#endif

#ifndef DEFINED_SHININESS
LVAL k_shininess;   /* Keyword ":shininess" */
#define DEFINED_SHININESS
#endif

#ifndef DEFINED_ALPHA
LVAL k_alpha;   /* Keyword ":alpha" */
#define DEFINED_ALPHA
#endif

#ifndef DEFINED_ALPHAIMPLEMENTATION
LVAL k_alphaimplementation;   /* Keyword ":alpha-implementation" */
#define DEFINED_ALPHAIMPLEMENTATION
#endif

#ifndef DEFINED_ORDEREDDITHER
LVAL k_ordereddither;   /* Keyword ":ordered-dither" */
#define DEFINED_ORDEREDDITHER
#endif

#ifndef DEFINED_RANDOM16X16PATTERNS
LVAL k_random16x16patterns;   /* Keyword ":random-16x16-patterns" */
#define DEFINED_RANDOM16X16PATTERNS
#endif

#ifndef DEFINED_RANDOM32X32PATTERNS
LVAL k_random32x32patterns;   /* Keyword ":random-32x32-patterns" */
#define DEFINED_RANDOM32X32PATTERNS
#endif

#ifndef DEFINED_RANDOM64X64PATTERNS
LVAL k_random64x64patterns;   /* Keyword ":random-64x64-patterns" */
#define DEFINED_RANDOM64X64PATTERNS
#endif

#ifndef DEFINED_EMISSIONWEIGHT
LVAL k_emissionweight;   /* Keyword ":emission-weight" */
#define DEFINED_EMISSIONWEIGHT
#endif

#ifndef DEFINED_AMBIENTWEIGHT
LVAL k_ambientweight;   /* Keyword ":ambient-weight" */
#define DEFINED_AMBIENTWEIGHT
#endif

#ifndef DEFINED_DIFFUSEWEIGHT
LVAL k_diffuseweight;   /* Keyword ":diffuse-weight" */
#define DEFINED_DIFFUSEWEIGHT
#endif

#ifndef DEFINED_SPECULARWEIGHT
LVAL k_specularweight;   /* Keyword ":specular-weight" */
#define DEFINED_SPECULARWEIGHT
#endif

#ifndef DEFINED_SHININESSWEIGHT
LVAL k_shininessweight;   /* Keyword ":shininess-weight" */
#define DEFINED_SHININESSWEIGHT
#endif

#ifndef DEFINED_ALPHAWEIGHT
LVAL k_alphaweight;   /* Keyword ":alpha-weight" */
#define DEFINED_ALPHAWEIGHT
#endif

#ifndef DEFINED_SHOW
LVAL k_show;/* Keyword ":show" */
#define DEFINED_SHOW
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_S_PROPERTYLIST
    s_propertylist = xlenter("PROPERTY-LIST");
#define CREATED_S_PROPERTYLIST
#endif

#ifndef CREATED_EMISSIONCOLOR
    k_emissioncolor = xlenter(":EMISSION-COLOR");
#define CREATED_EMISSIONCOLOR
#endif

#ifndef CREATED_AMBIENTCOLOR
    k_ambientcolor = xlenter(":AMBIENT-COLOR");
#define CREATED_AMBIENTCOLOR
#endif

#ifndef CREATED_DIFFUSECOLOR
    k_diffusecolor = xlenter(":DIFFUSE-COLOR");
#define CREATED_DIFFUSECOLOR
#endif

#ifndef CREATED_SPECULARCOLOR
    k_specularcolor = xlenter(":SPECULAR-COLOR");
#define CREATED_SPECULARCOLOR
#endif

#ifndef CREATED_SHININESS
    k_shininess = xlenter(":SHININESS");
#define CREATED_SHININESS
#endif

#ifndef CREATED_ALPHA
    k_alpha = xlenter(":ALPHA");
#define CREATED_ALPHA
#endif

#ifndef CREATED_ALPHAIMPLEMENTATION
    k_alphaimplementation = xlenter(":ALPHA-IMPLEMENTATION");
#define CREATED_ALPHAIMPLEMENTATION
#endif

#ifndef CREATED_ORDEREDDITHER
    k_ordereddither = xlenter(":ORDERED-DITHER");
#define CREATED_ORDEREDDITHER
#endif

#ifndef CREATED_RANDOM16X16PATTERNS
    k_random16x16patterns = xlenter(":RANDOM-16X16-PATTERNS");
#define CREATED_RANDOM16X16PATTERNS
#endif

#ifndef CREATED_RANDOM32X32PATTERNS
    k_random32x32patterns = xlenter(":RANDOM-32X32-PATTERNS");
#define CREATED_RANDOM32X32PATTERNS
#endif

#ifndef CREATED_RANDOM64X64PATTERNS
    k_random64x64patterns = xlenter(":RANDOM-64X64-PATTERNS");
#define CREATED_RANDOM64X64PATTERNS
#endif

#ifndef CREATED_EMISSIONWEIGHT
    k_emissionweight = xlenter(":EMISSION-WEIGHT");
#define CREATED_EMISSIONWEIGHT
#endif

#ifndef CREATED_AMBIENTWEIGHT
    k_ambientweight = xlenter(":AMBIENT-WEIGHT");
#define CREATED_AMBIENTWEIGHT
#endif

#ifndef CREATED_DIFFUSEWEIGHT
    k_diffuseweight = xlenter(":DIFFUSE-WEIGHT");
#define CREATED_DIFFUSEWEIGHT
#endif

#ifndef CREATED_SPECULARWEIGHT
    k_specularweight = xlenter(":SPECULAR-WEIGHT");
#define CREATED_SPECULARWEIGHT
#endif

#ifndef CREATED_SHININESSWEIGHT
    k_shininessweight = xlenter(":SHININESS-WEIGHT");
#define CREATED_SHININESSWEIGHT
#endif

#ifndef CREATED_ALPHAWEIGHT
    k_alphaweight = xlenter(":ALPHA-WEIGHT");
#define CREATED_ALPHAWEIGHT
#endif

#ifndef CREATED_SHOW
    k_show = xlenter(":SHOW");
#define CREATED_SHOW
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xmtl = xgbj58_Create_Class("CLASS-MATERIAL",lv_x03d);
    xgbj56_Enter_Messages( lv_xmtl,  xmtl_table );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
