/* {{{ xsry.h -- generic vector support.			     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      90Dec04
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xsry;

extern LVAL xsry03_Show_Msg();
extern LVAL xsry04_Aref_Msg();
extern LVAL xsry06_Setf_Msg();
extern LVAL xsry08_Copy_Msg();
extern LVAL xsry10_ArrayDimensions_Msg();
extern LVAL xsry11_ArrayDimension_Msg();
extern LVAL xsry12_ArrayRank_Msg();
extern LVAL xsry13_ArrayTotalSize_Msg();
extern LVAL xsry21_AdjustArray_Msg();
extern LVAL xsry24_RowMajorAref_Msg();
extern LVAL xsry26_RowMajorSetf_Msg();
extern LVAL xsry29_Equalp_Msg();
extern LVAL xsry32_Fill_Pointer_Msg();
extern LVAL xsry34_Vector_Push_Msg();
extern LVAL xsry35_Vector_Push_Extend_Msg();
extern LVAL xsry36_Vector_Pop_Msg();
extern LVAL xsry37_Setf_Fill_Pointer_Msg();
extern LVAL xsry39_Array_Row_Major_Index_Msg();
extern LVAL xsry76_Get_Msg();
extern LVAL xsry79_Set_Msg();
extern LVAL xsry90_Write_To_File_Msg();
extern LVAL xsry91_ProplistLength_Msg();
extern LVAL xsry95_ProplistNth_Msg();
extern LVAL xsrya1_Position_Msg();
extern LVAL xsrya5_Delete_Msg();

#ifndef EXTERNED_S_PROPERTYLIST
extern LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define EXTERNED_S_PROPERTYLIST
#endif

#ifndef EXTERNED_FILLPOINTER
extern LVAL k_fillpointer;/* Keyword ":fill-pointer" */
#define EXTERNED_FILLPOINTER
#endif

#ifndef EXTERNED_INITIALCONTENTS
extern LVAL k_initialcontents;/* Keyword ":initial-contents" */
#define EXTERNED_INITIALCONTENTS
#endif

#ifndef EXTERNED_INITIALIZEFROMFILE
extern LVAL k_initializefromfile;/* Keyword ":initialize-from-file" */
#define EXTERNED_INITIALIZEFROMFILE
#endif

#ifndef EXTERNED_INITIALELEMENT
extern LVAL k_initialelement;/* Keyword ":initial-element" */
#define EXTERNED_INITIALELEMENT
#endif
#endif

#ifdef MODULE_XLFTAB_C_GLOBALS
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	NULL,	xsry03_Show_Msg			)
DEFINE_SUBR(	NULL,	xsry04_Aref_Msg			)
DEFINE_SUBR(	NULL,	xsry06_Setf_Msg			)
DEFINE_SUBR(	NULL,	xsry08_Copy_Msg			)
DEFINE_SUBR(	NULL,	xsry10_ArrayDimensions_Msg	)
DEFINE_SUBR(	NULL,	xsry11_ArrayDimension_Msg	)
DEFINE_SUBR(	NULL,	xsry12_ArrayRank_Msg		)
DEFINE_SUBR(	NULL,	xsry13_ArrayTotalSize_Msg	)
DEFINE_SUBR(	NULL,	xsry21_AdjustArray_Msg		)
DEFINE_SUBR(	NULL,	xsry24_RowMajorAref_Msg		)
DEFINE_SUBR(	NULL,	xsry26_RowMajorSetf_Msg		)
DEFINE_SUBR(	NULL,	xsry29_Equalp_Msg		)
DEFINE_SUBR(	NULL,	xsry32_Fill_Pointer_Msg		)
DEFINE_SUBR(	NULL,	xsry34_Vector_Push_Msg		)
DEFINE_SUBR(	NULL,	xsry35_Vector_Push_Extend_Msg	)
DEFINE_SUBR(	NULL,	xsry36_Vector_Pop_Msg		)
DEFINE_SUBR(	NULL,	xsry37_Setf_Fill_Pointer_Msg	)
DEFINE_SUBR(	NULL,	xsry39_Array_Row_Major_Index_Msg)
DEFINE_SUBR(	NULL,	xsry76_Get_Msg			)
DEFINE_SUBR(	NULL,	xsry79_Set_Msg			)
DEFINE_SUBR(    NULL,   xsry90_Write_To_File_Msg        )
DEFINE_SUBR(	NULL,	xsry91_ProplistLength_Msg	)
DEFINE_SUBR(	NULL,	xsry95_ProplistNth_Msg		)
DEFINE_SUBR(	NULL,	xsrya1_Position_Msg		)
DEFINE_SUBR(	NULL,	xsrya5_Delete_Msg		)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xsry;

LOCAL struct xsry_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xsry_table[] = {
    {	":SHOW",		 xsry03_Show_Msg		 },
    {	":AREF",		 xsry04_Aref_Msg		 },
    {	":SETF",		 xsry06_Setf_Msg		 },
    {	":COPY",		 xsry08_Copy_Msg		 },
    {	":ARRAY-DIMENSIONS",	 xsry10_ArrayDimensions_Msg	 },
    {	":ARRAY-DIMENSION",	 xsry11_ArrayDimension_Msg	 },
    {	":ARRAY-RANK",		 xsry12_ArrayRank_Msg		 },
    {	":ARRAY-TOTAL-SIZE",	 xsry13_ArrayTotalSize_Msg	 },
    {	":ADJUST-ARRAY",	 xsry21_AdjustArray_Msg		 },
    {	":ROW-MAJOR-AREF",	 xsry24_RowMajorAref_Msg	 },
    {	":ROW-MAJOR-SETF",	 xsry26_RowMajorSetf_Msg	 },
    {	":EQUALP",		 xsry29_Equalp_Msg		 },
    {	":FILL-POINTER",	 xsry32_Fill_Pointer_Msg	 },
    {	":VECTOR-PUSH",		 xsry34_Vector_Push_Msg		 },
    {	":VECTOR-PUSH-EXTEND",	 xsry35_Vector_Push_Extend_Msg	 },
    {	":VECTOR-POP",		 xsry36_Vector_Pop_Msg		 },
    {	":SETF-FILL-POINTER",	 xsry37_Setf_Fill_Pointer_Msg	 },
    {	":ARRAY-ROW-MAJOR-INDEX",xsry39_Array_Row_Major_Index_Msg},
    {	":GET",		 	 xsry76_Get_Msg			 },
    {	":SET",		 	 xsry79_Set_Msg			 },
    {	":WRITE-TO-FILE", 	 xsry90_Write_To_File_Msg	 },
    {	":PROPERTY-LIST-LENGTH", xsry91_ProplistLength_Msg	 },
    {	":PROPERTY-LIST-NTH",	 xsry95_ProplistNth_Msg		 },
    {	":POSITION",		 xsrya1_Position_Msg		 },
    {	":DELETE",		 xsrya5_Delete_Msg		 },
    
    {	NULL,		         NULL			         }
};

#ifndef DEFINED_S_PROPERTYLIST
LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define DEFINED_S_PROPERTYLIST
#endif

#ifndef DEFINED_FILLPOINTER
LVAL k_fillpointer;/* Keyword ":fill-pointer" */
#define DEFINED_FILLPOINTER
#endif

#ifndef DEFINED_INITIALCONTENTS
LVAL k_initialcontents;/* Keyword ":initial-contents" */
#define DEFINED_INITIALCONTENTS
#endif

#ifndef DEFINED_INITIALIZEFROMFILE
LVAL k_initializefromfile;/* Keyword ":initialize-from-file" */
#define DEFINED_INITIALCONTENTS
#endif

#ifndef DEFINED_INITIALELEMENT
LVAL k_initialelement;/* Keyword ":initial-element" */
#define DEFINED_INITIALELEMENT
#endif
#endif


#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_S_PROPERTYLIST
    s_propertylist = xlenter("PROPERTY-LIST");
#define CREATED_S_PROPERTYLIST
#endif

#ifndef CREATED_FILLPOINTER
    k_fillpointer = xlenter(":FILL-POINTER");
#define CREATED_FILLPOINTER
#endif

#ifndef CREATED_INITIALCONTENTS
    k_initialcontents = xlenter(":INITIAL-CONTENTS");
#define CREATED_INITIALCONTENTS
#endif

#ifndef CREATED_INITIALIZEFROMFILE
    k_initializefromfile = xlenter(":INITIALIZE-FROM-FILE");
#define CREATED_INITIALIZEFROMFILE
#endif

#ifndef CREATED_INITIALELEMENT
    k_initialelement = xlenter(":INITIAL-ELEMENT");
#define CREATED_INITIALELEMENT
#endif
#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xsry = xgbj58_Create_Class("CLASS-ARRAY",lv_x03d);
    xgbj56_Enter_Messages(lv_xsry,xsry_table);
#endif


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
