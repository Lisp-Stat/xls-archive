/* {{{ xlsp.h -- picolisp for bitwise ops on graphic relations.	     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Apr08
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* We don't define our own class, just add a message to lv_xgrl. */

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xlsp40_Pointwise_Eval_Msg();


#ifndef EXTERNED_POINTWISEEVAL
extern LVAL k_pointwiseeval;/* Keyword ":pointwise-eval" */
#define EXTERNED_SETFFILLPOINTER
#endif

#ifndef EXTERNED_S_SETQ
extern LVAL s_setq;/* Symbol "setq" */
#define EXTERNED_S_SETQ
#endif

#ifndef EXTERNED_S_ROWMAJORINDEX
extern LVAL s_rowmajorindex;/* Symbol "row-major-index" */
#define EXTERNED_S_ROWMAJORINDEX
#endif

#ifndef EXTERNED_S_INDEX
extern LVAL s_index;/* Symbol "index" */
#define EXTERNED_S_INDEX
#endif

#ifndef EXTERNED_S_DOTPROD
extern LVAL s_dotprod;
#define EXTERNED_S_DOTPROD
#endif

#ifndef EXTERNED_S_STAR
extern LVAL s_star;/* Symbol "*" */
#define EXTERNED_S_STAR
#endif

#ifndef EXTERNED_S_PLUS
extern LVAL s_plus;/* Symbol "+" */
#define EXTERNED_S_PLUS
#endif

#ifndef EXTERNED_S_DASH
extern LVAL s_dash;/* Symbol "-" */
#define EXTERNED_S_DASH
#endif

#ifndef EXTERNED_S_SLASH
extern LVAL s_slash;/* Symbol "/" */
#define EXTERNED_S_SLASH
#endif

#ifndef EXTERNED_S_NEQ
extern LVAL s_neq;/* Symbol "/=" */
#define EXTERNED_S_SLASHEQ
#endif

#ifndef EXTERNED_S_LEQ
extern LVAL s_leq;/* Symbol "<=" */
#define EXTERNED_S_LEQ
#endif

#ifndef EXTERNED_S_EQ
extern LVAL s_eq;/* Symbol "=" */
#define EXTERNED_S_EQ
#endif

#ifndef EXTERNED_S_GEQ
extern LVAL s_geq;/* Symbol ">=" */
#define EXTERNED_S_GEQ
#endif

#ifndef EXTERNED_S_L
extern LVAL s_l;/* Symbol "<" */
#define EXTERNED_S_L
#endif

#ifndef EXTERNED_S_G
extern LVAL s_g;/* Symbol ">" */
#define EXTERNED_S_G
#endif

#ifndef EXTERNED_S_RANDOM
extern LVAL s_random;/* Symbol "RANDOM" */
#define EXTERNED_S_RANDOM
#endif

#ifndef EXTERNED_S_SIN
extern LVAL s_sin;/* Symbol "SIN" */
#define EXTERNED_S_SIN
#endif

#ifndef EXTERNED_S_COS
extern LVAL s_cos;/* Symbol "COS" */
#define EXTERNED_S_COS
#endif

#ifndef EXTERNED_S_ABS
extern LVAL s_abs;/* Symbol "ABS" */
#define EXTERNED_S_ABS
#endif

#ifndef EXTERNED_S_AND
extern LVAL s_and;/* Symbol "AND" */
#define EXTERNED_S_AND
#endif

#ifndef EXTERNED_S_EVENP
extern LVAL s_evenp;/* Symbol "EVENP" */
#define EXTERNED_S_EVENP
#endif

#ifndef EXTERNED_S_EXP
extern LVAL s_exp;/* Symbol "EXP" */
#define EXTERNED_S_EXP
#endif

#ifndef EXTERNED_S_EXPT
extern LVAL s_expt;/* Symbol "EXPT" */
#define EXTERNED_S_EXPT
#endif

#ifndef EXTERNED_S_FIRST
extern LVAL s_first;/* Symbol "FIRST" */
#define EXTERNED_S_FIRST
#endif

#ifndef EXTERNED_S_FLOAT
extern LVAL s_float;/* Symbol "FLOAT" */
#define EXTERNED_S_FLOAT
#endif

#ifndef EXTERNED_S_IF
extern LVAL s_if;/* Symbol "IF" */
#define EXTERNED_S_IF
#endif

#ifndef EXTERNED_S_LIST
extern LVAL s_list;/* Symbol "LIST" */
#define EXTERNED_S_LIST
#endif

#ifndef EXTERNED_S_LOGAND
extern LVAL s_logand;/* Symbol "LOGAND" */
#define EXTERNED_S_LOGAND
#endif

#ifndef EXTERNED_S_LOGIOR
extern LVAL s_logior;/* Symbol "LOGIOR" */
#define EXTERNED_S_LOGIOR
#endif

#ifndef EXTERNED_S_LOGNOT
extern LVAL s_lognot;/* Symbol "LOGNOT" */
#define EXTERNED_S_LOGNOT
#endif

#ifndef EXTERNED_S_LOGXOR
extern LVAL s_logxor;/* Symbol "LOGXOR" */
#define EXTERNED_S_LOGXOR
#endif

#ifndef EXTERNED_S_MAX
extern LVAL s_max;/* Symbol "MAX" */
#define EXTERNED_S_MAX
#endif

#ifndef EXTERNED_S_MIN
extern LVAL s_min;/* Symbol "MIN" */
#define EXTERNED_S_MIN
#endif

#ifndef EXTERNED_S_MINUSP
extern LVAL s_minusp;/* Symbol "MINUSP" */
#define EXTERNED_S_MINUSP
#endif

#ifndef EXTERNED_S_NOT
extern LVAL s_not;/* Symbol "NOT" */
#define EXTERNED_S_NOT
#endif

#ifndef EXTERNED_S_ODDP
extern LVAL s_oddp;/* Symbol "ODDP" */
#define EXTERNED_S_ODDP
#endif

#ifndef EXTERNED_S_OR
extern LVAL s_or;/* Symbol "OR" */
#define EXTERNED_S_OR
#endif

#ifndef EXTERNED_S_PLUSP
extern LVAL s_plusp;/* Symbol "PLUSP" */
#define EXTERNED_S_PLUSP
#endif

#ifndef EXTERNED_S_PROGN
extern LVAL s_progn;/* Symbol "PROGN" */
#define EXTERNED_S_PROGN
#endif

#ifndef EXTERNED_S_SECOND
extern LVAL s_second;/* Symbol "SECOND" */
#define EXTERNED_S_SECOND
#endif

#ifndef EXTERNED_S_SQRT
extern LVAL s_sqrt;/* Symbol "SQRT" */
#define EXTERNED_S_SQRT
#endif

#ifndef EXTERNED_S_TAN
extern LVAL s_tan;/* Symbol "TAN" */
#define EXTERNED_S_TAN
#endif

#ifndef EXTERNED_S_THIRD
extern LVAL s_third;/* Symbol "THIRD" */
#define EXTERNED_S_THIRD
#endif

#ifndef EXTERNED_S_TRUNCATE
extern LVAL s_truncate;/* Symbol "TRUNCATE" */
#define EXTERNED_S_TRUNCATE
#endif

#ifndef EXTERNED_S_UNLESS
extern LVAL s_unless;/* Symbol "UNLESS" */
#define EXTERNED_S_UNLESS
#endif

#ifndef EXTERNED_S_WHEN
extern LVAL s_when;/* Symbol "WHEN" */
#define EXTERNED_S_WHEN
#endif

#ifndef EXTERNED_S_X
extern LVAL s_x;/* Symbol "X" */
#define EXTERNED_S_X
#endif

#ifndef EXTERNED_S_ZEROP
extern LVAL s_zerop;/* Symbol "ZEROP" */
#define EXTERNED_S_ZEROP
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,	xlsp40_Pointwise_Eval_Msg	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LOCAL struct xlsp_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xlsp_table[] = {
    {	":POINTWISE-EVAL",	xlsp40_Pointwise_Eval_Msg	},
    {	NULL,			NULL				}
};



#ifndef DEFINED_POINTWISEEVAL
LVAL k_pointwiseeval;/* Keyword ":pointwise-eval" */
#define DEFINED_POINTWISEEVAL
#endif

#ifndef DEFINED_S_SETQ
LVAL s_setq;/* Symbol "SETQ" */
#define DEFINED_S_SETQ
#endif

#ifndef DEFINED_S_ROWMAJORINDEX
LVAL s_rowmajorindex;/* Symbol "ROW-MAJOR-INDEX" */
#define DEFINED_S_ROWMAJORINDEX
#endif

#ifndef DEFINED_S_INDEX
LVAL s_index;/* Symbol "INDEX" */
#define DEFINED_S_INDEX
#endif

#ifndef DEFINED_S_DOTPROD
LVAL s_dotprod;
#define DEFINED_S_DOTPROD
#endif

#ifndef DEFINED_S_STAR
LVAL s_star;/* Symbol "*" */
#define DEFINED_S_STAR
#endif

#ifndef DEFINED_S_PLUS
LVAL s_plus;/* Symbol "+" */
#define DEFINED_S_PLUS
#endif

#ifndef DEFINED_S_DASH
LVAL s_dash;/* Symbol "-" */
#define DEFINED_S_DASH
#endif

#ifndef DEFINED_S_SLASH
LVAL s_slash;/* Symbol "/" */
#define DEFINED_S_SLASH
#endif

#ifndef DEFINED_S_NEQ
LVAL s_neq;/* Symbol "/=" */
#define DEFINED_S_SLASHEQ
#endif

#ifndef DEFINED_S_LEQ
LVAL s_leq;/* Symbol "<=" */
#define DEFINED_S_LEQ
#endif

#ifndef DEFINED_S_EQ
LVAL s_eq;/* Symbol "=" */
#define DEFINED_S_EQ
#endif

#ifndef DEFINED_S_GEQ
LVAL s_geq;/* Symbol ">=" */
#define DEFINED_S_GEQ
#endif

#ifndef DEFINED_S_L
LVAL s_l;/* Symbol "<" */
#define DEFINED_S_L
#endif

#ifndef DEFINED_S_G
LVAL s_g;/* Symbol ">" */
#define DEFINED_S_G
#endif

#ifndef DEFINED_S_RANDOM
LVAL s_random;/* Symbol "RANDOM" */
#define DEFINED_S_RANDOM
#endif

#ifndef DEFINED_S_SIN
LVAL s_sin;/* Symbol "SIN" */
#define DEFINED_S_SIN
#endif

#ifndef DEFINED_S_COS
LVAL s_cos;/* Symbol "COS" */
#define DEFINED_S_COS
#endif

#ifndef DEFINED_S_ABS
LVAL s_abs;/* Symbol "ABS" */
#define DEFINED_S_ABS
#endif

#ifndef DEFINED_S_AND
LVAL s_and;/* Symbol "AND" */
#define DEFINED_S_AND
#endif

#ifndef DEFINED_S_EVENP
LVAL s_evenp;/* Symbol "EVENP" */
#define DEFINED_S_EVENP
#endif

#ifndef DEFINED_S_EXP
LVAL s_exp;/* Symbol "EXP" */
#define DEFINED_S_EXP
#endif

#ifndef DEFINED_S_EXPT
LVAL s_expt;/* Symbol "EXPT" */
#define DEFINED_S_EXPT
#endif

#ifndef DEFINED_S_FIRST
LVAL s_first;/* Symbol "FIRST" */
#define DEFINED_S_FIRST
#endif

#ifndef DEFINED_S_FLOAT
LVAL s_float;/* Symbol "FLOAT" */
#define DEFINED_S_FLOAT
#endif

#ifndef DEFINED_S_IF
LVAL s_if;/* Symbol "IF" */
#define DEFINED_S_IF
#endif

#ifndef DEFINED_S_LIST
LVAL s_list;/* Symbol "LIST" */
#define DEFINED_S_LIST
#endif

#ifndef DEFINED_S_LOGAND
LVAL s_logand;/* Symbol "LOGAND" */
#define DEFINED_S_LOGAND
#endif

#ifndef DEFINED_S_LOGIOR
LVAL s_logior;/* Symbol "LOGIOR" */
#define DEFINED_S_LOGIOR
#endif

#ifndef DEFINED_S_LOGNOT
LVAL s_lognot;/* Symbol "LOGNOT" */
#define DEFINED_S_LOGNOT
#endif

#ifndef DEFINED_S_LOGXOR
LVAL s_logxor;/* Symbol "LOGXOR" */
#define DEFINED_S_LOGXOR
#endif

#ifndef DEFINED_S_MAX
LVAL s_max;/* Symbol "MAX" */
#define DEFINED_S_MAX
#endif

#ifndef DEFINED_S_MIN
LVAL s_min;/* Symbol "MIN" */
#define DEFINED_S_MIN
#endif

#ifndef DEFINED_S_MINUSP
LVAL s_minusp;/* Symbol "MINUSP" */
#define DEFINED_S_MINUSP
#endif

#ifndef DEFINED_S_NOT
LVAL s_not;/* Symbol "NOT" */
#define DEFINED_S_NOT
#endif

#ifndef DEFINED_S_ODDP
LVAL s_oddp;/* Symbol "ODDP" */
#define DEFINED_S_ODDP
#endif

#ifndef DEFINED_S_OR
LVAL s_or;/* Symbol "OR" */
#define DEFINED_S_OR
#endif

#ifndef DEFINED_S_PLUSP
LVAL s_plusp;/* Symbol "PLUSP" */
#define DEFINED_S_PLUSP
#endif

#ifndef DEFINED_S_PROGN
LVAL s_progn;/* Symbol "PROGN" */
#define DEFINED_S_PROGN
#endif

#ifndef DEFINED_S_SECOND
LVAL s_second;/* Symbol "SECOND" */
#define DEFINED_S_SECOND
#endif

#ifndef DEFINED_S_SQRT
LVAL s_sqrt;/* Symbol "SQRT" */
#define DEFINED_S_SQRT
#endif

#ifndef DEFINED_S_TAN
LVAL s_tan;/* Symbol "TAN" */
#define DEFINED_S_TAN
#endif

#ifndef DEFINED_S_THIRD
LVAL s_third;/* Symbol "THIRD" */
#define DEFINED_S_THIRD
#endif

#ifndef DEFINED_S_TRUNCATE
LVAL s_truncate;/* Symbol "TRUNCATE" */
#define DEFINED_S_TRUNCATE
#endif

#ifndef DEFINED_S_UNLESS
LVAL s_unless;/* Symbol "UNLESS" */
#define DEFINED_S_UNLESS
#endif

#ifndef DEFINED_S_WHEN
LVAL s_when;/* Symbol "WHEN" */
#define DEFINED_S_WHEN
#endif

#ifndef DEFINED_S_X
LVAL s_x;/* Symbol "X" */
#define DEFINED_S_X
#endif

#ifndef DEFINED_S_ZEROP
LVAL s_zerop;/* Symbol "ZEROP" */
#define DEFINED_S_ZEROP
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_POINTWISEEVAL
    k_pointwiseeval = xlenter(":POINTWISE-EVAL");
#define CREATED_POINTWISEEVAL
#endif

#ifndef CREATED_S_SETQ
    s_setq = xlenter("SETQ");
#define CREATED_S_SETQ
#endif

#ifndef CREATED_S_ROWMAJORINDEX
    s_rowmajorindex = xlenter("ROW-MAJOR-INDEX");
#define CREATED_S_ROWMAJORINDEX
#endif

#ifndef CREATED_S_INDEX
    s_index = xlenter("INDEX");
#define CREATED_S_INDEX
#endif

#ifndef CREATED_S_DOTPROD
    s_dotprod = xlenter(".*");
#define CREATED_S_DOTPROD
#endif

#ifndef CREATED_S_STAR
    s_star = xlenter("*");/* Symbol "*" */
#define CREATED_S_STAR
#endif

#ifndef CREATED_S_PLUS
    s_plus = xlenter("+");/* Symbol "+" */
#define CREATED_S_PLUS
#endif

#ifndef CREATED_S_DASH
    s_dash = xlenter("-");/* Symbol "-" */
#define CREATED_S_DASH
#endif

#ifndef CREATED_S_SLASH
    s_slash = xlenter("/");/* Symbol "/" */
#define CREATED_S_SLASH
#endif

#ifndef CREATED_S_NEQ
    s_neq = xlenter("/=");/* Symbol "/=" */
#define CREATED_S_SLASHEQ
#endif

#ifndef CREATED_S_LEQ
    s_leq = xlenter("<=");/* Symbol "<=" */
#define CREATED_S_LEQ
#endif

#ifndef CREATED_S_EQ
    s_eq = xlenter("=");/* Symbol "=" */
#define CREATED_S_EQ
#endif

#ifndef CREATED_S_GEQ
    s_geq = xlenter(">=");/* Symbol ">=" */
#define CREATED_S_GEQ
#endif

#ifndef CREATED_S_L
    s_l = xlenter("<");/* Symbol "<" */
#define CREATED_S_L
#endif

#ifndef CREATED_S_G
    s_g = xlenter(">");/* Symbol ">" */
#define CREATED_S_G
#endif

#ifndef CREATED_S_RANDOM
    s_random = xlenter("RANDOM");/* Symbol "RANDOM" */
#define CREATED_S_RANDOM
#endif

#ifndef CREATED_S_SIN
    s_sin = xlenter("SIN");/* Symbol "SIN" */
#define CREATED_S_SIN
#endif

#ifndef CREATED_S_COS
    s_cos = xlenter("COS");/* Symbol "COS" */
#define CREATED_S_COS
#endif

#ifndef CREATED_S_ABS
    s_abs = xlenter("ABS");/* Symbol "ABS" */
#define CREATED_S_ABS
#endif

#ifndef CREATED_S_AND
    s_and = xlenter("AND");/* Symbol "AND" */
#define CREATED_S_AND
#endif

#ifndef CREATED_S_EVENP
    s_evenp = xlenter("EVENP");/* Symbol "EVENP" */
#define CREATED_S_EVENP
#endif

#ifndef CREATED_S_EXP
    s_exp = xlenter("EXP");/* Symbol "EXP" */
#define CREATED_S_EXP
#endif

#ifndef CREATED_S_EXPT
    s_expt = xlenter("EXPT");/* Symbol "EXPT" */
#define CREATED_S_EXPT
#endif

#ifndef CREATED_S_FIRST
    s_first = xlenter("FIRST");/* Symbol "FIRST" */
#define CREATED_S_FIRST
#endif

#ifndef CREATED_S_FLOAT
    s_float = xlenter("FLOAT");/* Symbol "FLOAT" */
#define CREATED_S_FLOAT
#endif

#ifndef CREATED_S_IF
    s_if = xlenter("IF");/* Symbol "IF" */
#define CREATED_S_IF
#endif

#ifndef CREATED_S_LIST
    s_list = xlenter("LIST");/* Symbol "LIST" */
#define CREATED_S_LIST
#endif

#ifndef CREATED_S_LOGAND
    s_logand = xlenter("LOGAND");/* Symbol "LOGAND" */
#define CREATED_S_LOGAND
#endif

#ifndef CREATED_S_LOGIOR
    s_logior = xlenter("LOGIOR");/* Symbol "LOGIOR" */
#define CREATED_S_LOGIOR
#endif

#ifndef CREATED_S_LOGNOT
    s_lognot = xlenter("LOGNOT");/* Symbol "LOGNOT" */
#define CREATED_S_LOGNOT
#endif

#ifndef CREATED_S_LOGXOR
    s_logxor = xlenter("LOGXOR");/* Symbol "LOGXOR" */
#define CREATED_S_LOGXOR
#endif

#ifndef CREATED_S_MAX
    s_max = xlenter("MAX");/* Symbol "MAX" */
#define CREATED_S_MAX
#endif

#ifndef CREATED_S_MIN
    s_min = xlenter("MIN");/* Symbol "MIN" */
#define CREATED_S_MIN
#endif

#ifndef CREATED_S_MINUSP
    s_minusp = xlenter("MINUSP");/* Symbol "MINUSP" */
#define CREATED_S_MINUSP
#endif

#ifndef CREATED_S_NOT
    s_not = xlenter("NOT");/* Symbol "NOT" */
#define CREATED_S_NOT
#endif

#ifndef CREATED_S_ODDP
    s_oddp = xlenter("ODDP");/* Symbol "ODDP" */
#define CREATED_S_ODDP
#endif

#ifndef CREATED_S_OR
    s_or = xlenter("OR");/* Symbol "OR" */
#define CREATED_S_OR
#endif

#ifndef CREATED_S_PLUSP
    s_plusp = xlenter("PLUSP");/* Symbol "PLUSP" */
#define CREATED_S_PLUSP
#endif

#ifndef CREATED_S_PROGN
    s_progn = xlenter("PROGN");/* Symbol "PROGN" */
#define CREATED_S_PROGN
#endif

#ifndef CREATED_S_SECOND
    s_second = xlenter("SECOND");/* Symbol "SECOND" */
#define CREATED_S_SECOND
#endif

#ifndef CREATED_S_SQRT
    s_sqrt = xlenter("SQRT");/* Symbol "SQRT" */
#define CREATED_S_SQRT
#endif

#ifndef CREATED_S_TAN
    s_tan = xlenter("TAN");/* Symbol "TAN" */
#define CREATED_S_TAN
#endif

#ifndef CREATED_S_THIRD
    s_third = xlenter("THIRD");/* Symbol "THIRD" */
#define CREATED_S_THIRD
#endif

#ifndef CREATED_S_TRUNCATE
    s_truncate = xlenter("TRUNCATE");/* Symbol "TRUNCATE" */
#define CREATED_S_TRUNCATE
#endif

#ifndef CREATED_S_UNLESS
    s_unless = xlenter("UNLESS");/* Symbol "UNLESS" */
#define CREATED_S_UNLESS
#endif

#ifndef CREATED_S_WHEN
    s_when = xlenter("WHEN");/* Symbol "WHEN" */
#define CREATED_S_WHEN
#endif

#ifndef CREATED_S_X
    s_x = xlenter("X");/* Symbol "X" */
#define CREATED_S_X
#endif

#ifndef CREATED_S_ZEROP
    s_zerop = xlenter("ZEROP");/* Symbol "ZEROP" */
#define CREATED_S_ZEROP
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    xgbj56_Enter_Messages(        lv_xgrl, xlsp_table  );
#endif


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
