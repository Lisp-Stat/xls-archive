/* {{{ xlsp.c -- picolisp for pointwise graphic relation operations.     CrT*/
/*****************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Apr08
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1993, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/* }}} */
/* {{{ --- history ---							*/

/* 97Feb21 jsp: Changed some ifv's to NULLs in *Force_Buffer_To*       	*/
/* 96Nov05 jsp: Fixed: Max() had a left-over "*dst++ = *src++".        	*/
/* 92Apr08 jsp: Created.                                             	*/

/* }}} */
/* {{{ --- header stuff ---						*/
  

#include "../../xcore/c/xlisp.h"

#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

/*
 * Fns to think about adding:
 * floor ffloor ceiling fceiling round mod log ln
 * make-unit-length length-3D polar->rect?
 * hsi->rgb etc
 * acos asin atan? 
 * 4x4-transform as operator
 * progn
 * aref
 */


extern LVAL lv_xgrl;
extern LVAL s_abs;
extern LVAL s_and;
extern LVAL s_cos;
extern LVAL s_dash;
extern LVAL s_eq;
extern LVAL s_evenp;
extern LVAL s_g;
extern LVAL s_geq;
extern LVAL s_l;
extern LVAL s_leq;
extern LVAL s_neq;
extern LVAL s_plus;
extern LVAL s_random;
extern LVAL s_setq;
extern LVAL s_sin;
extern LVAL s_slash;
extern LVAL s_star;
extern LVAL s_exp;
extern LVAL s_expt;
extern LVAL s_float;
extern LVAL s_if;
extern LVAL s_logand;
extern LVAL s_logior;
extern LVAL s_lognot;
extern LVAL s_logxor;
extern LVAL s_max;
extern LVAL s_min;
extern LVAL s_minusp;
extern LVAL s_not;
extern LVAL s_oddp;
extern LVAL s_or;
extern LVAL s_plusp;
extern LVAL s_sqrt;
extern LVAL s_tan;
extern LVAL lv_x01v;
extern LVAL lv_x32v;
extern LVAL lv_xflv;
extern LVAL s_dotprod;
extern LVAL s_first;
extern LVAL s_index;
extern LVAL s_list;
extern LVAL s_progn;
extern LVAL s_rowmajorindex;
extern LVAL s_second;
extern LVAL s_third;
extern LVAL s_truncate;
extern LVAL s_unless;
extern LVAL s_when;
extern LVAL s_x;
extern LVAL s_zerop;

#include <math.h>
#include "csry.h"
#include "geo.h"
#include "lib.h"
#include "cgrl.h"
#include "cmtl.h"
#include "cmdl.h"
#include "clgt.h"
#include "cflv.h"
#include "c01v.h"
#include "c03d.h"
#include "c32v.h"
#include "clsp.h"

/* Imported fns: */
extern float xflv40_Max();
extern float xflv42_Min();
extern LVAL  xgrl01_Get_A_XGRL();
  
/* }}} */

/* {{{ --- Public fns ---						*/
/* }}} */
/* {{{ xlsp21_Force_Buffer_To_Bit                                       */

xlsp21_Force_Buffer_To_Bit( pBuf, pos, cnt, ifv )
struct xlsp05_buf         * pBuf;
int				  pos, cnt;
unsigned char *                             ifv;
/*-
    Force contents of given buffer to be bits.
-*/
{   struct xlsp05_buf buf;   buf.buf_type = XLSP_TYPE_NUL;

    if (ifv != NULL)   ifv += pos>>3;
    /*************************************************************/
    /* Copying twice is unnecessary usually, but is a perfectly  */
    /* safe and generic approach that avoids surprises ...       */
    /*************************************************************/
    switch (pBuf->buf_type) {

    case XLSP_TYPE_NUL:
	{   int i;
	    unsigned char* p = &pBuf->u.bit[0];
	    for (i = XLSP_BUF_SIZE>>3;   i --> 0;   ) *p++ = 0;
	}	
        pBuf->buf_type = XLSP_TYPE_BIT;
	return 0;

    case XLSP_TYPE_BIT:
        return 0;

    case XLSP_TYPE_FIX:
        xlsp34_Copy_Fix_To_Bit(& buf. u.bit[0],&pBuf->u.fix[0],cnt,NULL);
        xlsp31_Copy_Bit_To_Bit(&pBuf->u.bit[0],& buf. u.bit[0],cnt,NULL);
        pBuf->buf_type = XLSP_TYPE_BIT;
        return 0;

    case XLSP_TYPE_FLO:
        xlsp37_Copy_Flo_To_Bit(& buf. u.bit[0],&pBuf->u.flo[0],cnt,NULL);
        xlsp31_Copy_Bit_To_Bit(&pBuf->u.bit[0],& buf. u.bit[0],cnt,NULL);
        pBuf->buf_type = XLSP_TYPE_BIT;
        return 0;

    default:
	abort();
    }
}

/* }}} */
/* {{{ xlsp22_Force_Buffer_To_Fix                                       */

xlsp22_Force_Buffer_To_Fix( pBuf, pos, cnt, ifv )
struct xlsp05_buf         * pBuf;
int				  pos, cnt;
unsigned char *                             ifv;
/*-
    Force contents of given buffer to be ints.
-*/
{   struct xlsp05_buf buf;   buf.buf_type = XLSP_TYPE_NUL;
    if (ifv != NULL)   ifv += pos>>3;
    /*************************************************************/
    /* Copying twice is unnecessary usually, but is a perfectly  */
    /* safe and generic approach that avoids surprises ...       */
    /*************************************************************/
    switch (pBuf->buf_type) {

    case XLSP_TYPE_NUL:
	{   int i;
	    CSRY_INT32* p = &pBuf->u.fix[0];
	    for (i = XLSP_BUF_SIZE;   i --> 0;   ) *p++ = 0;
	}	
        pBuf->buf_type = XLSP_TYPE_FIX;
	return 0;

    case XLSP_TYPE_BIT:
        xlsp32_Copy_Bit_To_Fix(& buf. u.fix[0],&pBuf->u.bit[0],cnt,NULL);
        xlsp35_Copy_Fix_To_Fix(&pBuf->u.fix[0],& buf. u.fix[0],cnt,NULL);
        pBuf->buf_type = XLSP_TYPE_FIX;
        return 0;

    case XLSP_TYPE_FIX:
        return 0;

    case XLSP_TYPE_FLO:
        xlsp38_Copy_Flo_To_Fix(& buf. u.fix[0], &pBuf->u.flo[0],cnt,NULL);
        xlsp35_Copy_Fix_To_Fix(&pBuf->u.fix[0], & buf. u.fix[0],cnt,NULL);
        pBuf->buf_type = XLSP_TYPE_FIX;
        return 0;

    default:
	abort();
    }
}

/* }}} */
/* {{{ xlsp23_Force_Buffer_To_Flo                                       */

xlsp23_Force_Buffer_To_Flo( pBuf, pos, cnt, ifv )
struct xlsp05_buf         * pBuf;
int				  pos, cnt;
unsigned char *                             ifv;
/*-
    Force contents of given buffer to be floats.
-*/
{   struct xlsp05_buf buf;   buf.buf_type = XLSP_TYPE_NUL;
    if (ifv != NULL)   ifv += pos>>3;
    /*************************************************************/
    /* Copying twice is unnecessary usually, but is a perfectly  */
    /* safe and generic approach that avoids surprises ...       */
    /*************************************************************/
    switch (pBuf->buf_type) {

    case XLSP_TYPE_NUL:
	{   int i;
	    float* p = &pBuf->u.flo[0];
	    for (i = XLSP_BUF_SIZE;   i --> 0;   ) *p++ = 0;
	}	
        pBuf->buf_type = XLSP_TYPE_FLO;
	return 0;

    case XLSP_TYPE_BIT:
        xlsp33_Copy_Bit_To_Flo(& buf. u.flo[0],&pBuf->u.bit[0],cnt,NULL);
        xlsp39_Copy_Flo_To_Flo(&pBuf->u.flo[0],& buf. u.flo[0],cnt,NULL);
        pBuf->buf_type = XLSP_TYPE_FLO;
        return 0;

    case XLSP_TYPE_FIX:
        xlsp36_Copy_Fix_To_Flo(& buf. u.flo[0], &pBuf->u.fix[0],cnt,NULL);
        xlsp39_Copy_Flo_To_Flo(&pBuf->u.flo[0], & buf. u.flo[0],cnt,NULL);
        pBuf->buf_type = XLSP_TYPE_FLO;
        return 0;

    case XLSP_TYPE_FLO:
        return 0;

    default:
	abort();
    }
}

/* }}} */
/* {{{ xlsp31_Copy_Bit_To_Bit                                           */

xlsp31_Copy_Bit_To_Bit( dst, src, cnt, ifv )
unsigned char          *dst,*src;
int                               cnt;
unsigned char                         *ifv;
{
    int i;
    if (ifv == NULL) {
	for (i = ((cnt+7) >> 3);   i --> 0;   ) {
	    *dst++ = *src++;
	}
    } else {
	for (i = ((cnt+7) >> 3);   i --> 0;   ) {
	    unsigned char  ourbits = *src++;
	    unsigned char  oldbits = *dst;
	    unsigned char  if_bits = *ifv++;

	    *dst++ = (ourbits & if_bits) | (oldbits & !if_bits);
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp32_Copy_Bit_To_Fix                                           */

xlsp32_Copy_Bit_To_Fix( dst, src, cnt, ifv )
CSRY_INT32             *dst;
unsigned char               *src;
int                               cnt;
unsigned char                         *ifv;
{
    int            i;
    int            inbits;
    int            ifbits;
    int            val;

    if (ifv == NULL) {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     inbits  = *src++;
	    val = (inbits & 1);
            *dst++ = val;
	    inbits >>= 1;
	}
    } else {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     { inbits  = *src++;   ifbits = *ifv++; }
	    val = (inbits & 1);
            if    (ifbits & 1)   *dst = val;
            ++dst;
	    inbits >>= 1;
	    ifbits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xlsp33_Copy_Bit_To_Flo                                           */

xlsp33_Copy_Bit_To_Flo( dst, src, cnt, ifv )
float                  *dst;
unsigned char               *src;
int                               cnt;
unsigned char                         *ifv;
{
    int            i;
    int            inbits;
    int            ifbits;
    float          val;
    if (ifv == NULL) {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     inbits  = *src++;
	    val = (float) (inbits & 1);
            *dst++ = val;
	    inbits >>= 1;
	}
    } else {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     { inbits  = *src++;   ifbits = *ifv++; }
	    val = (float) (inbits & 1);
            if            (ifbits & 1)   *dst = val;
            ++dst;
	    inbits >>= 1;
	    ifbits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xlsp34_Copy_Fix_To_Bit                                           */

xlsp34_Copy_Fix_To_Bit( dst, src, cnt, ifv )
unsigned char          *dst;
CSRY_INT32                  *src;
int                               cnt;
unsigned char                         *ifv;
{
    int             i;
    int             outbits = 0;
    int             ifbits;
    int             val;
    if (ifv == NULL) {
	for (i = 0;   i < cnt;   ++i) {
	    val = (*src++ ? 1 : 0);
            outbits      |= val << (i & 7);
	    if ((i&7)    == 7)   { *dst++ = outbits; outbits = 0; }
	}
    } else {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))   ifbits = *ifv++;
	    val = (*src++ ? 1 : 0);
            if    (ifbits & 1)   outbits |= val << (i & 7);
	    if ((i&7)    == 7)   { *dst++ = outbits; outbits = 0; }
	    ifbits >>= 1;
    }	}
    if (i&7)   *dst++ = outbits;
    return 0;
}

/* }}} */
/* {{{ xlsp35_Copy_Fix_To_Fix                                           */

xlsp35_Copy_Fix_To_Fix( dst, src, cnt, ifv )
CSRY_INT32             *dst,*src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
            *dst++ = *src++;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = *src;
	    ++dst;
            ++src;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xlsp36_Copy_Fix_To_Flo                                           */

xlsp36_Copy_Fix_To_Flo( dst, src, cnt, ifv )
float                  *dst;
CSRY_INT32                  *src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
            *dst++ = (float) *src++;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = (float) *src;
	    ++src;
            ++dst;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xlsp37_Copy_Flo_To_Bit                                           */

xlsp37_Copy_Flo_To_Bit( dst, src, cnt, ifv )
unsigned char          *dst;
float                       *src;
int                               cnt;
unsigned char                         *ifv;
{
    int            i;
    int            outbits = 0;
    int            ifbits;
    int            val;
    if (ifv == NULL) {
	for (i = 0;   i < cnt;   ++i) {
	    val = ((*src++ == 0.0) ? 0 : 1);
            outbits      |= val << (i & 7);
	    if ((i&7)    == 7)   { *dst++ = outbits; outbits = 0; }
	}
    } else {
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))   ifbits = *ifv++;
	    val = ((*src++ == 0.0) ? 0 : 1);
            if    (ifbits & 1)   outbits |= val << (i & 7);
	    if ((i&7)    == 7)   { *dst++ = outbits; outbits = 0; }
	    ifbits >>= 1;
    }	}
    if (i&7)   *dst++ = outbits;
    return 0;
}

/* }}} */
/* {{{ xlsp38_Copy_Flo_To_Fix                                           */

xlsp38_Copy_Flo_To_Fix( dst, src, cnt, ifv )
CSRY_INT32             *dst;
float                       *src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
            *dst++ = (CSRY_INT32) *src++;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = (CSRY_INT32) *src;
	    ++src;
            ++dst;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xlsp39_Copy_Flo_To_Flo                                           */

xlsp39_Copy_Flo_To_Flo( dst, src, cnt, ifv )
float                  *dst,*src;
int                               cnt;
unsigned char                         *ifv;
{
    if (ifv == NULL) {
	while (cnt --> 0) {
            *dst++ = *src++;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = *src;
	    ++dst;
            ++src;
	    bits >>= 1;
    }	}
    return 0;
}

/* }}} */
/* {{{ xlsp40_Pointwise_Eval_Msg--Pointwise evaluation of a picolisp exp*/

LVAL xlsp40_Pointwise_Eval_Msg()
/*-
    Pointwise evaluation of a picolisp expression.
-*/
{
    csry_rec* h;
    int               pos, cnt, lim;
    LVAL xgrl = xgrl01_Get_A_XGRL();
    LVAL expr = xlgalist();
    struct xlsp05_buf buf;   buf.buf_type = XLSP_TYPE_NUL;
    xllastarg();
    xgrl44_Validate( xgrl );

    h = (csry_rec*) gobjimmbase( xgrl );

    /* Respect fill pointers: */
    lim = h->size;
    if (h->rank == 1  &&   h->dim[1] != -1)   lim = h->dim[1];
    for (pos = 0;   pos < lim;   pos += XLSP_BUF_SIZE) {
	cnt  = XLSP_BUF_SIZE;
	if (pos + cnt   >   lim)   cnt = lim - pos;
	xlsp41_Pointwise_Eval( &buf, pos, cnt, xgrl, expr, NULL );
    }

    return NIL;
}

xlsp41_Pointwise_Eval( buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf     *buf;
int                         pos, cnt;
LVAL				      xgrl, expr;
unsigned char *                                   ifv;
{
    if (symbolp(expr))   expr = xlgetvalue(expr);

    if        (fixp(expr)) {

	return xlsp46_fix(buf,pos,cnt,xgrl,expr,ifv);

    } else if (floatp(expr)) {

	return xlsp47_flo(buf,pos,cnt,xgrl,expr,ifv);

    } else if (symbolp(expr)) {

	return xlsp48_array(buf,pos,cnt,xgrl,expr,ifv);

    } else if (consp(expr)) {

	LVAL op = car(expr);
        expr    = cdr(expr);
        /* If this proves a speed hotspot, could try hashing or such... */
	if      (op==s_setq    ) return xlsp50_setq(    buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_star    ) return xlsp51_star(    buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_plus    ) return xlsp52_plus(    buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_dash    ) return xlsp53_dash(    buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_slash   ) return xlsp54_slash(   buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_neq     ) return xlsp55_neq(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_leq     ) return xlsp56_leq(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_eq      ) return xlsp57_eq(      buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_geq     ) return xlsp58_geq(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_l       ) return xlsp59_l(       buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_g       ) return xlsp60_g(       buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_random  ) return xlsp61_random(  buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_sin     ) return xlsp62_sin(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_cos     ) return xlsp63_cos(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_abs     ) return xlsp64_abs(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_and     ) return xlsp65_and(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_evenp   ) return xlsp66_evenp(   buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_exp     ) return xlsp67_exp(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_expt    ) return xlsp68_expt(    buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_float   ) return xlsp69_float(   buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_if      ) return xlsp70_if(      buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_logand  ) return xlsp71_logand(  buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_logior  ) return xlsp72_logior(  buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_lognot  ) return xlsp73_lognot(  buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_logxor  ) return xlsp74_logxor(  buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_max     ) return xlsp75_max(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_min     ) return xlsp76_min(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_minusp  ) return xlsp77_minusp(  buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_not     ) return xlsp78_not(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_oddp    ) return xlsp79_oddp(    buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_or      ) return xlsp80_or(      buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_plusp   ) return xlsp81_plusp(   buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_sqrt    ) return xlsp82_sqrt(    buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_tan     ) return xlsp83_tan(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_truncate) return xlsp84_truncate(buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_zerop   ) return xlsp85_zerop(   buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_index   ) return xlsp89_index(   buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_unless  ) return xlsp90_unless(  buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_when    ) return xlsp91_when(    buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_progn   ) return xlsp92_progn(   buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_list    ) return xlsp93_list(    buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_first   ) return xlsp94_first(   buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_second  ) return xlsp95_second(  buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_third   ) return xlsp96_third(   buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_dotprod ) return xlsp97_dot(     buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_x       ) return xlsp98_x(       buf,pos,cnt,xgrl,expr,ifv);
	else if (op==s_rowmajorindex) {
            return xlsp87_row_major_index(buf,pos,cnt,xgrl,expr,ifv);
        } else {
	    xlerror("Bad :POINTWISE-EVAL operator",op);
	}

    } else {

	xlerror("Bad :POINTWISE-EVAL expr",expr);

    }
}

/* }}} */
/* {{{ xlsp42_Pointwise_Eval_Any -- Compute an arg into buffer		*/

xlsp4a_Must_Be_A_Cons( expr, op )
LVAL                   expr;
char*                        op;
{   char buf[ 128 ];
    if (!consp(expr)) {
	sprintf( buf, ":POINTWISE-EVAL -- missing %s argument", op );
	xlfail(buf);
    }
    return 0;
}
LVAL xlsp42_Pointwise_Eval_Any( buf, pos, cnt, xgrl, expr, ifv, op )
struct xlsp05_buf              *buf;
int                                  pos, cnt;
LVAL				               xgrl, expr;
unsigned char *                                            ifv;
char          *							op;
{
    xlsp4a_Must_Be_A_Cons( expr, op );
    xlsp41_Pointwise_Eval( buf, pos, cnt, xgrl, car(expr), ifv );
    return cdr( expr );    
}

/* }}} */
/* {{{ xlsp43_Pointwise_Eval_Bit--Compute an arg into buffer,force to bt*/

LVAL xlsp43_Pointwise_Eval_Bit( buf, pos, cnt, xgrl, expr, ifv, op )
struct xlsp05_buf              *buf;
int                                  pos, cnt;
LVAL				               xgrl, expr;
unsigned char *                                            ifv;
char          *							op;
{
    LVAL result = xlsp42_Pointwise_Eval_Any( buf,pos,cnt, xgrl, expr, ifv,op );
    xlsp21_Force_Buffer_To_Bit( buf, pos, cnt, ifv );
    return result;    
}

/* }}} */
/* {{{ xlsp44_Pointwise_Eval_Fix--Compute an arg into buffer,force to fx*/

LVAL xlsp44_Pointwise_Eval_Fix( buf, pos, cnt, xgrl, expr, ifv, op )
struct xlsp05_buf              *buf;
int                                  pos, cnt;
LVAL				               xgrl, expr;
unsigned char *                                            ifv;
char          *							op;
{
    LVAL result = xlsp42_Pointwise_Eval_Any( buf,pos,cnt, xgrl, expr, ifv,op );
    xlsp22_Force_Buffer_To_Fix( buf, pos, cnt, ifv );
    return result;    
}

/* }}} */
/* {{{ xlsp45_Pointwise_Eval_Flo--Compute an arg into buffer,force to fl*/

LVAL xlsp45_Pointwise_Eval_Flo( buf, pos, cnt, xgrl, expr, ifv, op )
struct xlsp05_buf              *buf;
int                                  pos, cnt;
LVAL				               xgrl, expr;
unsigned char *                                            ifv;
char          *							op;
{
    LVAL result = xlsp42_Pointwise_Eval_Any( buf,pos,cnt, xgrl, expr, ifv,op );
    xlsp23_Force_Buffer_To_Flo( buf, pos, cnt, ifv );
    return result;    
}

/* }}} */
/* {{{ xlsp4b_Pointwise_Eval_Flx -- Compute arg into buffer,force nonbit*/

LVAL xlsp4b_Pointwise_Eval_Flx( buf, pos, cnt, xgrl, expr, ifv, op )
struct xlsp05_buf              *buf;
int                                  pos, cnt;
LVAL				               xgrl, expr;
unsigned char *                                            ifv;
char          *							op;
{
    LVAL result = xlsp42_Pointwise_Eval_Any( buf,pos,cnt, xgrl, expr, ifv,op );
    switch (buf->buf_type) {
    case XLSP_TYPE_FLO:
    case XLSP_TYPE_FIX:
	break;
    case XLSP_TYPE_BIT:
        xlsp22_Force_Buffer_To_Fix( buf, pos, cnt, ifv );
	break;
    default:
	abort();
    }
    return result;    
}

/* }}} */
/* {{{ xlsp4d_Pointwise_Eval_Fl3 -- Compute an arg into buffer,force vec*/

LVAL xlsp4d_Pointwise_Eval_Fl3( buf, pos, cnt, xgrl, expr, ifv, op )
struct xlsp05_buf              *buf;
int                                  pos, cnt;
LVAL				               xgrl, expr;
unsigned char *                                            ifv;
char          *							op;
{
    LVAL result = xlsp42_Pointwise_Eval_Any( buf,pos,cnt, xgrl, expr, ifv,op );
    char errbuf[ 128 ];
    switch (buf->buf_type) {
    case XLSP_TYPE_FL3:
	break;
    case XLSP_TYPE_FLO:
    case XLSP_TYPE_FIX:
    case XLSP_TYPE_BIT:
	sprintf(errbuf,":POINTWISE-EVAL: %s needs (LIST a b c) arg",op);
        xlerror(errbuf,xgrl);
	break;
    default:
	abort();
    }
    return result;    
}

/* }}} */
/* {{{ xlsp46_fix -- Deal with a lisp fixnum.                           */

xlsp4c_fix(        buf, pos, cnt, xgrl, val, ifv )
struct xlsp05_buf *buf;
int                     pos, cnt;
LVAL				  xgrl;
int				        val;
unsigned char *                               ifv;
{   CSRY_INT32 *  p = buf->u.fix;
    CSRY_INT32    v = val;
    xlsp22_Force_Buffer_To_Fix( buf, pos, cnt, ifv );
    if (ifv == NULL) {
        while (cnt --> 0)   *p++ = v;
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *p    = v;
	    ++p;
	    bits >>= 1;
    }   }
    return 0;
}
xlsp46_fix(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf *buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{  return  xlsp4c_fix( buf, pos, cnt, xgrl, getfixnum( expr ), ifv );
}

/* }}} */
/* {{{ xlsp47_flo -- Deal with a lisp flonum.                           */

xlsp47_flo(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf *buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   float * p     = buf->u.flo;
    float   v     = getflonum( expr );
    xlsp23_Force_Buffer_To_Flo( buf, pos, cnt, ifv );
    if (ifv == NULL) {
        while (cnt --> 0)   *p++ = v;
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *p    = v;
	    ++p;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp48_array -- Find and use contents of an array in our grl.    */

xlsp48_array(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf *buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   csry_rec* h;

    /* We presume a symbol that evaluates to a symbol */
    /* yielded a keyword, and look for an array by    */
    /* that name in our grl:			      */
    LVAL ary = xgrl3c_Get_Array( xgrl, expr, NIL, /*got_default*/ TRUE );
    if (null(ary))  xlerror(":POINTWISE-EVAL: no array named",expr);
    xsry0a_Must_Be_A_Struct_Array(ary);   /* Paranoia only. */

    h   = (csry_rec*) gobjimmbase(ary);

    (*h->s->to_buf)( ary, buf, cnt, pos, ifv );

    return 0;
}

/* }}} */
/* {{{ xlsp49_Lastarg                                                   */

xlsp49_Lastarg( op, expr )
char*           op;
LVAL                expr;
{
    if (!null(expr)) {
        char buf[ 128 ];
	sprintf( buf, "%s: too many args", op ); 
	xlerror( buf, expr );
    }
    return 0;
}

/* }}} */
/* {{{ xlsp50_setq							*/

xlsp5a_setq(       buf, pos, cnt, xgrl, dest, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, dest;
unsigned char *                               ifv;
{   csry_rec* h;
    LVAL ary;

    /* If dest ary doesn't exist, create it: */
    if (!symbolp(dest)) xlerror(":POINTWISE-EVAL SETQ: dest arg not symbol",dest);
    ary  = xgrl3c_Get_Array( xgrl, dest, NIL, /*got_default*/ TRUE );
    if (null(ary)) {
	extern LVAL xgrl4b_SetArray();
	LVAL typ;
	switch (buf->buf_type) {
	case XLSP_TYPE_FLO: typ = lv_xflv;   break;
	case XLSP_TYPE_FIX: typ = lv_x32v;   break;
	case XLSP_TYPE_BIT: typ = lv_x01v;   break;
	    break;
	default:
	    abort();
	}
	ary = xgrl4b_SetArray( xgrl, /*key*/dest, /*val*/typ );
    }
    xsry0a_Must_Be_A_Struct_Array( ary );   /* Paranoia only. */
    h   = (csry_rec*) gobjimmbase( ary );

    /* Do (our part of) store: */
    (*h->s->from_buf)( ary, buf, cnt, pos, ifv );

    return 0;
}
xlsp50_setq(       buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   char*op   = "SETQ";

    /* First arg is (name of) array to store to: */
    csry_rec* h;
    LVAL dest = expr;    
    xlsp4a_Must_Be_A_Cons( dest, op );
    dest = car(dest);

    /* Second arg is expression store into array: */
    expr = cdr(expr);
    expr = xlsp42_Pointwise_Eval_Any( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );

    if (buf->buf_type != XLSP_TYPE_FL3) {
	xlsp5a_setq( buf, pos, cnt, xgrl, dest, ifv );
    } else {
        buf->buf_type  = XLSP_TYPE_FLO;
        xlsp4a_Must_Be_A_Cons( dest, op );
	if (car(dest) != s_list) {
	    xlerror(":POINTWISE-EVAL/SETQ expected LIST",car(dest));
	}
	dest = cdr(dest);
        xlsp4a_Must_Be_A_Cons( dest, op );
	xlsp5a_setq( buf, pos, cnt, xgrl, car(dest), ifv ); dest = cdr(dest);
        xlsp39_Copy_Flo_To_Flo( &buf->u.flo[0], &buf->u1.flo[0], cnt, ifv );
        xlsp4a_Must_Be_A_Cons( dest, op );
	xlsp5a_setq( buf, pos, cnt, xgrl, car(dest), ifv ); dest = cdr(dest);
        xlsp39_Copy_Flo_To_Flo( &buf->u.flo[0], &buf->u2.flo[0], cnt, ifv );
        xlsp4a_Must_Be_A_Cons( dest, op );
	xlsp5a_setq( buf, pos, cnt, xgrl, car(dest), ifv ); dest = cdr(dest);
	xlsp49_Lastarg( op, dest );
    }

    return 0;
}

/* }}} */
/* {{{ xlsp51_star							*/

xlsp51_star(       buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "*";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp42_Pointwise_Eval_Any(  buf, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg, pos, cnt, xgrl, expr, ifv, op );
	if (buf->buf_type == XLSP_TYPE_FLO   ||
	    arg. buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    float *   dst;
	    float *   src;
	    xlsp23_Force_Buffer_To_Flo(  buf, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg, pos, cnt, ifv );
	    dst  = &buf->u.flo[ 0 ];
	    src  = &arg. u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ *= *src++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1)   *dst *= *src;
		    ++dst;
		    ++src;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src;
	    xlsp22_Force_Buffer_To_Fix(  buf, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src  = &arg. u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ *= *src++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1)   *dst *= *src;
		    ++dst;
		    ++src;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp52_plus							*/

xlsp52_plus(       buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "+";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp42_Pointwise_Eval_Any(  buf, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg, pos, cnt, xgrl, expr, ifv, op );
	if (buf->buf_type == XLSP_TYPE_FLO   ||
	    arg. buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    float *   dst;
	    float *   src;
	    xlsp23_Force_Buffer_To_Flo(  buf, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg, pos, cnt, ifv );
	    dst  = &buf->u.flo[ 0 ];
	    src  = &arg. u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ += *src++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1)   *dst += *src;
		    ++dst;
		    ++src;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src;
	    xlsp22_Force_Buffer_To_Fix(  buf, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src  = &arg. u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ += *src++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1)   *dst += *src;
		    ++dst;
		    ++src;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp53_dash							*/

xlsp53_dash(       buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "-";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp4b_Pointwise_Eval_Flx(  buf, pos, cnt, xgrl, expr, ifv, op );

    /* '-' is funny, with single argument does a negate: */
    if (null(expr)) {
	if (buf->buf_type == XLSP_TYPE_FLO) {
	    /* Compute float result: */
	    float *   dst;
	    dst  = &buf->u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst = -*dst;   ++dst;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1)   *dst  = -*dst;
		    ++dst;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    dst  = &buf->u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst = -*dst;   ++dst;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1)   *dst  = -*dst;
		    ++dst;
		    bits >>= 1;
    	}   }   }
	return 0;
    }

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg, pos, cnt, xgrl, expr, ifv, op );
	if (buf->buf_type == XLSP_TYPE_FLO   ||
	    arg. buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    float *   dst;
	    float *   src;
	    xlsp23_Force_Buffer_To_Flo(  buf, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg, pos, cnt, ifv );
	    dst  = &buf->u.flo[ 0 ];
	    src  = &arg. u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ -= *src++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1)   *dst -= *src;
		    ++dst;
		    ++src;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src;
	    xlsp22_Force_Buffer_To_Fix(  buf, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src  = &arg. u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ -= *src++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1)   *dst -= *src;
		    ++dst;
		    ++src;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp54_slash							*/

xlsp54_slash(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op  = "/";
    char*             err = ":POINTWISE-EVAL: Divide by zero attempted.";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp4b_Pointwise_Eval_Flx(  buf, pos, cnt, xgrl, expr, ifv, op );

    /* '/' is funny, with single argument does a 1/x: */
    if (null(expr)) {
	if (buf->buf_type == XLSP_TYPE_FLO) {
	    /* Compute float result: */
	    float *   dst;
	    dst  = &buf->u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    float f = *dst;
		    if (f == 0.0)   xlfail(err);
		    *dst++ = 1.0 / f;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			float f = *dst;
			if (f == 0.0)   xlfail(err);
			*dst  = 1.0 / f;
		    }
		    ++dst;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    dst  = &buf->u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    CSRY_INT32 f = *dst;
		    if (f == 0)   xlfail(err);
		    *dst++ = 1 / f;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			CSRY_INT32 f = *dst;
			if (f == 0)   xlfail(err);
			*dst  = 1 / f;
		    }
		    ++dst;
		    bits >>= 1;
    	}   }   }
	return 0;
    }

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg, pos, cnt, xgrl, expr, ifv, op );
	if (buf->buf_type == XLSP_TYPE_FLO   ||
	    arg. buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    float *   dst;
	    float *   src;
	    xlsp23_Force_Buffer_To_Flo(  buf, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg, pos, cnt, ifv );
	    dst  = &buf->u.flo[ 0 ];
	    src  = &arg. u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    float f = *src++;
		    if (f == 0.0)   xlfail(err);
		    *dst++ /= f;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			float f = *src;
			if (f == 0.0)   xlfail(err);
			*dst /= f;
		    }
		    ++dst;
		    ++src;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src;
	    xlsp22_Force_Buffer_To_Fix(  buf, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src  = &arg. u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    CSRY_INT32 f = *src++;
		    if (f == 0)   xlfail(err);
		    *dst++ /= f;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			CSRY_INT32 f = *src;
			if (f == 0)   xlfail(err);
			*dst /= f;
		    }
		    ++dst;
		    ++src;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp55_neq							*/

xlsp55_neq(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "/=";
    struct xlsp05_buf arg0;
    struct xlsp05_buf arg1;
    arg0.buf_type = XLSP_TYPE_NUL;
    arg1.buf_type = XLSP_TYPE_NUL;
    xlsp4c_fix( buf, pos, cnt, xgrl, 1, ifv );

    expr = xlsp42_Pointwise_Eval_Any( &arg0, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg1, pos, cnt, xgrl, expr, ifv, op );
	if (arg0.buf_type == XLSP_TYPE_FLO   ||
	    arg1.buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    CSRY_INT32 *   dst;
	    float      *   src0;
	    float      *   src1;
	    xlsp23_Force_Buffer_To_Flo( &arg0, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.flo[ 0 ];
	    src1 = &arg1.u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 != *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 != *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src0;
	    CSRY_INT32*   src1;
	    xlsp22_Force_Buffer_To_Fix( &arg0, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.fix[ 0 ];
	    src1 = &arg1.u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 != *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 != *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp56_leq							*/

xlsp56_leq(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "<=";
    struct xlsp05_buf arg0;
    struct xlsp05_buf arg1;
    arg0.buf_type = XLSP_TYPE_NUL;
    arg1.buf_type = XLSP_TYPE_NUL;
    xlsp4c_fix( buf, pos, cnt, xgrl, 1, ifv );

    expr = xlsp42_Pointwise_Eval_Any( &arg0, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg1, pos, cnt, xgrl, expr, ifv, op );
	if (arg0.buf_type == XLSP_TYPE_FLO   ||
	    arg1.buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    CSRY_INT32 *   dst;
	    float      *   src0;
	    float      *   src1;
	    xlsp23_Force_Buffer_To_Flo( &arg0, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.flo[ 0 ];
	    src1 = &arg1.u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 <= *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 <= *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src0;
	    CSRY_INT32*   src1;
	    xlsp22_Force_Buffer_To_Fix( &arg0, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.fix[ 0 ];
	    src1 = &arg1.u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 <= *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 <= *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp57_eq							*/

xlsp57_eq(         buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "=";
    struct xlsp05_buf arg0;
    struct xlsp05_buf arg1;
    arg0.buf_type = XLSP_TYPE_NUL;
    arg1.buf_type = XLSP_TYPE_NUL;
    xlsp4c_fix( buf, pos, cnt, xgrl, 1, ifv );

    expr = xlsp42_Pointwise_Eval_Any( &arg0, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg1, pos, cnt, xgrl, expr, ifv, op );
	if (arg0.buf_type == XLSP_TYPE_FLO   ||
	    arg1.buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    CSRY_INT32 *   dst;
	    float      *   src0;
	    float      *   src1;
	    xlsp23_Force_Buffer_To_Flo( &arg0, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.flo[ 0 ];
	    src1 = &arg1.u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 == *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 == *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src0;
	    CSRY_INT32*   src1;
	    xlsp22_Force_Buffer_To_Fix( &arg0, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.fix[ 0 ];
	    src1 = &arg1.u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 == *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 == *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp58_geq							*/

xlsp58_geq(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = ">=";
    struct xlsp05_buf arg0;
    struct xlsp05_buf arg1;
    arg0.buf_type = XLSP_TYPE_NUL;
    arg1.buf_type = XLSP_TYPE_NUL;
    xlsp4c_fix( buf, pos, cnt, xgrl, 1, ifv );

    expr = xlsp42_Pointwise_Eval_Any( &arg0, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg1, pos, cnt, xgrl, expr, ifv, op );
	if (arg0.buf_type == XLSP_TYPE_FLO   ||
	    arg1.buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    CSRY_INT32 *   dst;
	    float      *   src0;
	    float      *   src1;
	    xlsp23_Force_Buffer_To_Flo( &arg0, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.flo[ 0 ];
	    src1 = &arg1.u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 >= *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 >= *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src0;
	    CSRY_INT32*   src1;
	    xlsp22_Force_Buffer_To_Fix( &arg0, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.fix[ 0 ];
	    src1 = &arg1.u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 >= *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 >= *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp59_l								*/

xlsp59_l(          buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "<";
    struct xlsp05_buf arg0;
    struct xlsp05_buf arg1;
    arg0.buf_type = XLSP_TYPE_NUL;
    arg1.buf_type = XLSP_TYPE_NUL;
    xlsp4c_fix( buf, pos, cnt, xgrl, 1, ifv );

    expr = xlsp42_Pointwise_Eval_Any( &arg0, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg1, pos, cnt, xgrl, expr, ifv, op );
	if (arg0.buf_type == XLSP_TYPE_FLO   ||
	    arg1.buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    CSRY_INT32 *   dst;
	    float      *   src0;
	    float      *   src1;
	    xlsp23_Force_Buffer_To_Flo( &arg0, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.flo[ 0 ];
	    src1 = &arg1.u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 < *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 < *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src0;
	    CSRY_INT32*   src1;
	    xlsp22_Force_Buffer_To_Fix( &arg0, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.fix[ 0 ];
	    src1 = &arg1.u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 < *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 < *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp60_g								*/

xlsp60_g(          buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = ">";
    struct xlsp05_buf arg0;
    struct xlsp05_buf arg1;
    arg0.buf_type = XLSP_TYPE_NUL;
    arg1.buf_type = XLSP_TYPE_NUL;
    xlsp4c_fix( buf, pos, cnt, xgrl, 1, ifv );

    expr = xlsp42_Pointwise_Eval_Any( &arg0, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg1, pos, cnt, xgrl, expr, ifv, op );
	if (arg0.buf_type == XLSP_TYPE_FLO   ||
	    arg1.buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    CSRY_INT32 *   dst;
	    float      *   src0;
	    float      *   src1;
	    xlsp23_Force_Buffer_To_Flo( &arg0, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.flo[ 0 ];
	    src1 = &arg1.u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 > *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 > *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src0;
	    CSRY_INT32*   src1;
	    xlsp22_Force_Buffer_To_Fix( &arg0, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg1, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src0 = &arg0.u.fix[ 0 ];
	    src1 = &arg1.u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    *dst++ &= (*src0 > *src1);
		    *src0++ = *src1++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			*dst &= (*src0 > *src1);
			*src0 = *src1;
		    }
		    ++dst;
		    ++src0;
		    ++src1;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp61_random							*/

xlsp61_random(     buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   extern double drand48();
    float * p     = buf->u.flo;
    static done_initialization = FALSE;
    xlsp49_Lastarg( "RANDOM", expr );
    if (!  done_initialization) {
	srand48(0);
        done_initialization = TRUE;
    }
    xlsp23_Force_Buffer_To_Flo( buf, pos, cnt, ifv );
    if (ifv == NULL) {
        while (cnt --> 0)   *p++ = drand48();
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *p    = drand48();
	    ++p;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp62_sin							*/

xlsp62_sin(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   float * p     = buf->u.flo;
    char  * op    = "SIN";
    expr = xlsp45_Pointwise_Eval_Flo( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    if (ifv == NULL) {
        while (cnt --> 0)   { *p = sin(*p); ++p; }
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *p    = sin(*p);
	    ++p;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp63_cos							*/

xlsp63_cos(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   float * p     = buf->u.flo;
    char  * op    = "COS";
    expr = xlsp45_Pointwise_Eval_Flo( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    if (ifv == NULL) {
        while (cnt --> 0)   { *p = cos(*p); ++p; }
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *p    = cos(*p);
	    ++p;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp64_abs							*/

xlsp64_abs(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "ABS";
    expr = xlsp4b_Pointwise_Eval_Flx(  buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );

    if (buf->buf_type == XLSP_TYPE_FLO) {
	/* Compute float result: */
	float *dst = &buf->u.flo[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		float f = *dst;
		*dst++ = f >= 0.0 ? f : -f;
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    float f = *dst;
		    *dst    = f >= 0.0 ? f : -f;
		}
		++dst;
		bits >>= 1;
	}   }
    } else {
	/* Compute int   result: */
	CSRY_INT32 *dst = &buf->u.fix[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		CSRY_INT32 f = *dst;
		*dst++ = f >= 0 ? f : -f;
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    CSRY_INT32 f = *dst;
		    *dst    = f >= 0.0 ? f : -f;
		}
		++dst;
		bits >>= 1;
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp65_and							*/

xlsp65_and(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;      unsigned char *   dst;
    struct xlsp05_buf arg;    unsigned char *   src;
    char*op  = "AND";
    arg.buf_type = XLSP_TYPE_NUL;
    expr     = xlsp43_Pointwise_Eval_Bit(  buf, pos, cnt, xgrl, expr, ifv, op );
    while (!null(expr)) {
        expr = xlsp43_Pointwise_Eval_Bit( &arg, pos, cnt, xgrl, expr, ifv, op );
        dst  = &buf->u.bit[ 0 ];
        src  = &arg. u.bit[ 0 ];
	if (ifv == NULL) {
            for (i = (cnt+7) >> 3;   i --> 0;   ) {   
	        *dst++ &= *src++;
            }
	} else {
	    unsigned char* ifp = ifv;
	    for (i = ((cnt+7) >> 3);   i --> 0;   ) {
		unsigned char  ourbits = *src++ & *dst;
		unsigned char  oldbits =          *dst;
		unsigned char  if_bits = *ifv++;
		*dst++ = (ourbits & if_bits) | (oldbits & !if_bits);
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp66_evenp							*/

xlsp66_evenp(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "EVENP";
    expr = xlsp44_Pointwise_Eval_Fix(  buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    {
	/* Compute int   result: */
	CSRY_INT32 *dst = &buf->u.fix[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		CSRY_INT32 k = *dst;
		*dst++ = (k&1)^1;
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    CSRY_INT32 k = *dst;
		    *dst    = (k&1)^1;
		}
		++dst;
		bits >>= 1;
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp67_exp							*/

xlsp67_exp(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   float * p     = buf->u.flo;
    char  * op    = "EXP";
    expr = xlsp45_Pointwise_Eval_Flo( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    if (ifv == NULL) {
        while (cnt --> 0)   { *p = exp(*p); ++p; }
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *p    = exp(*p);
	    ++p;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp68_expt							*/

xlsp68_expt(       buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "EXPT";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp45_Pointwise_Eval_Flo(  buf, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	float *   dst;
	float *   src;
	expr = xlsp45_Pointwise_Eval_Flo( &arg, pos, cnt, xgrl, expr, ifv, op );
	dst  = &buf->u.flo[ 0 ];
	src  = &arg. u.flo[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		float base = *dst;
		*dst++ = pow(base,*src++);
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1)    *dst = pow(*dst,*src);
		++dst;
		++src;
		bits >>= 1;
    }	}   }
    return 0;
}

/* }}} */
/* {{{ xlsp69_float							*/

xlsp69_float(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   char*             op = "FLOAT";
    expr = xlsp45_Pointwise_Eval_Flo(  buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    return 0;
}

/* }}} */
/* {{{ xlsp70_if							*/

xlsp70_if(         buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "IF";
    struct xlsp05_buf ifvB;
    unsigned char *   dst;
    unsigned char *   ifvb = &ifvB.u.bit[0];
    ifvB.buf_type = XLSP_TYPE_NUL;
    if (ifv == NULL) {
        expr = xlsp43_Pointwise_Eval_Bit( &ifvB, pos, cnt, xgrl, expr, ifv , op );
        expr = xlsp42_Pointwise_Eval_Any(   buf, pos, cnt, xgrl, expr, ifvb, op );
	dst  = &ifvB.u.bit[ 0 ];
	for (i = (cnt+7) >> 3;   i --> 0;   ) *dst++ ^= 0xFF;
    } else {
	unsigned char *   src0;
	unsigned char *   src1;
	struct xlsp05_buf cond;
        cond.buf_type = XLSP_TYPE_NUL;
        expr = xlsp43_Pointwise_Eval_Bit( &cond, pos, cnt, xgrl, expr, ifv , op );
	dst  = &ifvB.u.bit[ 0 ];
	src0 = ifv;
	src1 = &cond.u.bit[ 0 ];
	for (i = (cnt+7) >> 3;   i --> 0;   ) {   
	    *dst++ = *src0++ &  *src1++;
	}
        expr = xlsp42_Pointwise_Eval_Any(   buf, pos, cnt, xgrl, expr, ifvb, op );
	dst  = &ifvB.u.bit[ 0 ];
	src0 = ifv;
	src1 = &cond.u.bit[ 0 ];
	for (i = (cnt+7) >> 3;   i --> 0;   ) {   
	    *dst++ = *src0++ & ~*src1++;
    }   }
    while (!null(expr)) {
        expr = xlsp42_Pointwise_Eval_Any(   buf, pos, cnt, xgrl, expr, ifvb, op );
    }
    return 0;
}

/* }}} */
/* {{{ xlsp71_logand							*/

xlsp71_logand(     buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "LOGAND";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp44_Pointwise_Eval_Fix(  buf, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	CSRY_INT32*   dst;
	CSRY_INT32*   src;
	expr = xlsp44_Pointwise_Eval_Fix( &arg, pos, cnt, xgrl, expr, ifv, op );
	dst  = &buf->u.fix[ 0 ];
	src  = &arg. u.fix[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		*dst++ &= *src++;
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1)   *dst &= *src;
		++dst;
		++src;
		bits >>= 1;
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp72_logior							*/

xlsp72_logior(     buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "LOGIOR";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp44_Pointwise_Eval_Fix(  buf, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	CSRY_INT32*   dst;
	CSRY_INT32*   src;
	expr = xlsp44_Pointwise_Eval_Fix( &arg, pos, cnt, xgrl, expr, ifv, op );
	dst  = &buf->u.fix[ 0 ];
	src  = &arg. u.fix[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		*dst++ |= *src++;
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1)   *dst |= *src;
		++dst;
		++src;
		bits >>= 1;
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp73_lognot							*/

xlsp73_lognot(     buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "LOGNOT";
    CSRY_INT32*       dst;
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp44_Pointwise_Eval_Fix(  buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );

    dst  = &buf->u.fix[ 0 ];
    if (ifv == NULL) {
	for (i = cnt;   i --> 0;   ) {   
	    *dst++ ^= ~0;
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst ^= ~0;
	    ++dst;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp74_logxor							*/

xlsp74_logxor(     buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "LOGXOR";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp44_Pointwise_Eval_Fix(  buf, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	/* Compute int   result: */
	CSRY_INT32*   dst;
	CSRY_INT32*   src;
	expr = xlsp44_Pointwise_Eval_Fix( &arg, pos, cnt, xgrl, expr, ifv, op );
	dst  = &buf->u.fix[ 0 ];
	src  = &arg. u.fix[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		*dst++ ^= *src++;
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1)   *dst ^= *src;
		++dst;
		++src;
		bits >>= 1;
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp75_max							*/

xlsp75_max(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "MAX";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp42_Pointwise_Eval_Any(  buf, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg, pos, cnt, xgrl, expr, ifv, op );
	if (buf->buf_type == XLSP_TYPE_FLO   ||
	    arg. buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    float *   dst;
	    float *   src;
	    xlsp23_Force_Buffer_To_Flo(  buf, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg, pos, cnt, ifv );
	    dst  = &buf->u.flo[ 0 ];
	    src  = &arg. u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    float d = *dst;
		    float s = *src++;
		    *dst++  = s > d ? s : d;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			float d = *dst;
			float s = *src;
			*dst    = s > d ? s : d;
		    }
		    ++dst;
		    ++src;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src;
	    xlsp22_Force_Buffer_To_Fix(  buf, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src  = &arg. u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    CSRY_INT32 d = *dst;
		    CSRY_INT32 s = *src++;
		    *dst++  = s > d ? s : d;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			CSRY_INT32 d = *dst;
			CSRY_INT32 s = *src;
			*dst    = s > d ? s : d;
		    }
		    ++dst;
		    ++src;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp76_min							*/

xlsp76_min(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "MIN";
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp42_Pointwise_Eval_Any(  buf, pos, cnt, xgrl, expr, ifv, op );

    while (!null(expr)) {
	expr = xlsp42_Pointwise_Eval_Any( &arg, pos, cnt, xgrl, expr, ifv, op );
	if (buf->buf_type == XLSP_TYPE_FLO   ||
	    arg. buf_type == XLSP_TYPE_FLO
	) {
	    /* Compute float result: */
	    float *   dst;
	    float *   src;
	    xlsp23_Force_Buffer_To_Flo(  buf, pos, cnt, ifv );
	    xlsp23_Force_Buffer_To_Flo( &arg, pos, cnt, ifv );
	    dst  = &buf->u.flo[ 0 ];
	    src  = &arg. u.flo[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    float d = *dst;
		    float s = *src++;
		    *dst++  = s < d ? s : d;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			float d = *dst;
			float s = *src;
			*dst    = s < d ? s : d;
		    }
		    ++dst;
		    ++src;
		    bits >>= 1;
	    }   }
	} else {
	    /* Compute int   result: */
	    CSRY_INT32*   dst;
	    CSRY_INT32*   src;
	    xlsp22_Force_Buffer_To_Fix(  buf, pos, cnt, ifv );
	    xlsp22_Force_Buffer_To_Fix( &arg, pos, cnt, ifv );
	    dst  = &buf->u.fix[ 0 ];
	    src  = &arg. u.fix[ 0 ];
	    if (ifv == NULL) {
		for (i = cnt;   i --> 0;   ) {   
		    CSRY_INT32 d = *dst;
		    CSRY_INT32 s = *src++;
		    *dst++  = s < d ? s : d;
		    *dst++ += *src++;
		}
	    } else {
		int i, bits;
		for (i = 0;   i < cnt;   ++i) {
		    if (!(i&7))     bits  = *ifv++;
		    if (bits & 1) {
			CSRY_INT32 d = *dst;
			CSRY_INT32 s = *src;
			*dst    = s < d ? s : d;
		    }
		    ++dst;
		    ++src;
		    bits >>= 1;
    }	}   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp77_minusp							*/

xlsp77_minusp(     buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "MINUSP";
    CSRY_INT32 *      dst = &buf->u.fix[ 0 ];
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp4b_Pointwise_Eval_Flx( &arg, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );

    if (buf->buf_type == XLSP_TYPE_FLO) {
	/* Compute float result: */
	float *src = &arg.u.flo[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		*dst++ = (*src++ < 0.0);
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    *dst    = (*src < 0.0);
		}
		++dst;
		++src;
		bits >>= 1;
        }   }
    } else {
	/* Compute int   result: */
	CSRY_INT32 *src = &arg.u.fix[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		*dst++ = (*src++ < 0);
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    *dst    = (*src < 0);
		}
		++dst;
		++src;
		bits >>= 1;
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp78_not							*/

xlsp78_not(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;      unsigned char *   dst;
    char*op  = "NOT";
    expr     = xlsp43_Pointwise_Eval_Bit(  buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    dst  = &buf->u.bit[ 0 ];
    if (ifv == NULL) {
        for (i = (cnt+7) >> 3;   i --> 0;   ) {   
	    *dst++ ^= 0xFF;
	}
    } else {
	unsigned char* ifp = ifv;
	for (i = ((cnt+7) >> 3);   i --> 0;   ) {
	    unsigned char  ourbits = 0xFF ^ *dst;
	    unsigned char  oldbits =        *dst;
	    unsigned char  if_bits = *ifv++;
	    *dst++ = (ourbits & if_bits) | (oldbits & !if_bits);
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp79_oddp							*/

xlsp79_oddp(       buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "ODDP";
    expr = xlsp44_Pointwise_Eval_Fix(  buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );

    {
	/* Compute int   result: */
	CSRY_INT32 *dst = &buf->u.fix[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		CSRY_INT32 k = *dst;
		*dst++ = k&1;
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    CSRY_INT32 k = *dst;
		    *dst    = k&1;
		}
		++dst;
		bits >>= 1;
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp80_or							*/

xlsp80_or(         buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;      unsigned char *   dst;
    struct xlsp05_buf arg;    unsigned char *   src;
    char*op  = "OR";
    arg.buf_type = XLSP_TYPE_NUL;
    expr     = xlsp43_Pointwise_Eval_Bit(  buf, pos, cnt, xgrl, expr, ifv, op );
    while (!null(expr)) {
        expr = xlsp43_Pointwise_Eval_Bit( &arg, pos, cnt, xgrl, expr, ifv, op );
        dst  = &buf->u.bit[ 0 ];
        src  = &arg. u.bit[ 0 ];
	if (ifv == NULL) {
            for (i = (cnt+7) >> 3;   i --> 0;   ) {   
	        *dst++ |= *src++;
            }
	} else {
	    unsigned char* ifp = ifv;
	    for (i = ((cnt+7) >> 3);   i --> 0;   ) {
		unsigned char  ourbits = *src++ | *dst;
		unsigned char  oldbits =          *dst;
		unsigned char  if_bits = *ifv++;
		*dst++ = (ourbits & if_bits) | (oldbits & !if_bits);
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp81_plusp							*/

xlsp81_plusp(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "PLUSP";
    CSRY_INT32 *      dst = &buf->u.fix[ 0 ];
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp4b_Pointwise_Eval_Flx( &arg, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );

    if (buf->buf_type == XLSP_TYPE_FLO) {
	/* Compute float result: */
	float *src = &arg.u.flo[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		*dst++ = (*src++ > 0.0);
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    *dst    = (*src > 0.0);
		}
		++dst;
		++src;
		bits >>= 1;
        }   }
    } else {
	/* Compute int   result: */
	CSRY_INT32 *src = &arg.u.fix[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		*dst++ = (*src++ > 0);
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    *dst    = (*src > 0);
		}
		++dst;
		++src;
		bits >>= 1;
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp82_sqrt							*/

xlsp82_sqrt(       buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   float * p     = buf->u.flo;
    char  * op    = "SQRT";
    char  * err   = ":POINTWISE-EVAL: Can't SQRT negative number";
    expr = xlsp45_Pointwise_Eval_Flo( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    if (ifv == NULL) {
        while (cnt --> 0){
	    float f = *p;
	    if (f < 0.0)   xlfail(err);
	    *p++ = sqrt(f);
	}
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1) {
		float f = *p;
		if (f < 0.0)   xlfail(err);
		*p = sqrt(f);
	    }
	    ++p;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp83_tan							*/

xlsp83_tan(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   float * p     = buf->u.flo;
    char  * op    = "TAN";
    expr = xlsp45_Pointwise_Eval_Flo( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    if (ifv == NULL) {
        while (cnt --> 0)   { *p = tan(*p); ++p; }
    } else {
	int i, bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *p    = tan(*p);
	    ++p;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp84_truncate							*/

xlsp84_truncate(   buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   char*             op = "TRUNCATE";
    expr = xlsp44_Pointwise_Eval_Fix(  buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    return 0;
}

/* }}} */
/* {{{ xlsp85_zerop							*/

xlsp85_zerop(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "ZEROP";
    CSRY_INT32 *      dst = &buf->u.fix[ 0 ];
    struct xlsp05_buf arg;   arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp4b_Pointwise_Eval_Flx( &arg, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );

    if (buf->buf_type == XLSP_TYPE_FLO) {
	/* Compute float result: */
	float *src = &arg.u.flo[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		*dst++ = (*src++ == 0.0);
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    *dst    = (*src == 0.0);
		}
		++dst;
		++src;
		bits >>= 1;
        }   }
    } else {
	/* Compute int   result: */
	CSRY_INT32 *src = &arg.u.fix[ 0 ];
	if (ifv == NULL) {
	    for (i = cnt;   i --> 0;   ) {   
		*dst++ = (*src++ == 0);
	    }
	} else {
	    int i, bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    *dst    = (*src == 0);
		}
		++dst;
		++src;
		bits >>= 1;
    }   }   }
    return 0;
}

/* }}} */
/* {{{ xlsp87_row_major_index						*/

xlsp87_row_major_index( buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf*      buf;
int                          pos, cnt;
LVAL				       xgrl, expr;
unsigned char *                                    ifv;
{   int               i;
    CSRY_INT32*       dst = &buf->u.fix[ 0 ];
    xlsp49_Lastarg( "ROW-MAJOR-INDEX", expr );
    xlsp22_Force_Buffer_To_Fix(  buf, pos, cnt, ifv );
    if (ifv == NULL) {
        for (i = 0;   i < cnt;   ++i)   *dst++ = pos + i;
    } else {
	int bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = pos + i;
	    ++dst;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp89_index							*/

xlsp88_figure_index( h, i, d, xgrl )
csry_rec*            h;
int			i, d;
LVAL			      xgrl;
{   int j;
    if (d < 0   ||   d >= h->rank) {
	char buf[ 128 ];
	sprintf(buf, "(index %d) illegal, relation rank is %d", d, h->rank );
	xlerror(buf,xgrl);
    }
    for (j = 0;   j < d;   ++j)   i /= h->dim[j];
    return i % h->dim[d]; 
}
xlsp89_index(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;
    csry_rec*         h  = (csry_rec*) gobjimmbase( xgrl );
    CSRY_INT32*       dst = &buf->u.fix[ 0 ];
    char*op = "INDEX";
    expr = xlsp44_Pointwise_Eval_Fix( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    if (ifv == NULL) {
        for (i = 0;   i < cnt;   ++i) {
	    *dst++ = xlsp88_figure_index( h, pos+i, *dst, xgrl );
	}
    } else {
	int bits;
	for (i = 0;   i < cnt;   ++i) {
	    if (!(i&7))     bits  = *ifv++;
	    if (bits & 1)   *dst  = xlsp88_figure_index( h, pos+i, *dst, xgrl );
	    ++dst;
	    bits >>= 1;
    }   }
    return 0;
}

/* }}} */
/* {{{ xlsp90_unless							*/

xlsp90_unless(     buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "UNLESS";
    struct xlsp05_buf ifvB;
    unsigned char *   dst;
    unsigned char *   ifvb = &ifvB.u.bit[0];
    ifvB.buf_type = XLSP_TYPE_NUL;
    if (ifv == NULL) {
        expr = xlsp43_Pointwise_Eval_Bit( &ifvB, pos, cnt, xgrl, expr, ifv , op );
	dst  = &ifvB.u.bit[ 0 ];
	for (i = (cnt+7) >> 3;   i --> 0;   ) *dst++ ^= 0xFF;
    } else {
	unsigned char *   src0;
	unsigned char *   src1;
	struct xlsp05_buf cond;
        cond.buf_type = XLSP_TYPE_NUL;
        expr = xlsp43_Pointwise_Eval_Bit( &cond, pos, cnt, xgrl, expr, ifv , op );
	dst  = &ifvB.u.bit[ 0 ];
	src0 = ifv;
	src1 = &cond.u.bit[ 0 ];
	for (i = (cnt+7) >> 3;   i --> 0;   ) {   
	    *dst++ = *src0++ & ~*src1++;
    }   }
    while (!null(expr)) {
        expr = xlsp42_Pointwise_Eval_Any(   buf, pos, cnt, xgrl, expr, ifvb, op );
    }
    return 0;
}

/* }}} */
/* {{{ xlsp91_when							*/

xlsp91_when(       buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "WHEN";
    struct xlsp05_buf ifvB;
    unsigned char *   dst;
    unsigned char *   ifvb = &ifvB.u.bit[0];
    ifvB.buf_type = XLSP_TYPE_NUL;
    if (ifv == NULL) {
        expr = xlsp43_Pointwise_Eval_Bit( &ifvB, pos, cnt, xgrl, expr, ifv , op );
    } else {
	unsigned char *   src0;
	unsigned char *   src1;
	struct xlsp05_buf cond;
        cond.buf_type = XLSP_TYPE_NUL;
        expr = xlsp43_Pointwise_Eval_Bit( &cond, pos, cnt, xgrl, expr, ifv , op );
	dst  = &ifvB.u.bit[ 0 ];
	src0 = ifv;
	src1 = &cond.u.bit[ 0 ];
	for (i = (cnt+7) >> 3;   i --> 0;   ) {   
	    *dst++ = *src0++ &  *src1++;
    }   }
    while (!null(expr)) {
        expr = xlsp42_Pointwise_Eval_Any(   buf, pos, cnt, xgrl, expr, ifvb, op );
    }
    return 0;
}

/* }}} */
/* {{{ xlsp92_progn							*/

xlsp92_progn(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   char*             op = "PROGN";
    while (!null(expr)) {
        expr = xlsp42_Pointwise_Eval_Any( buf, pos, cnt, xgrl, expr, ifv, op );
    }
    return 0;
}

/* }}} */
/* {{{ xlsp93_list							*/

xlsp93_list(       buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   int               i;    
    char*             op = "LIST";
    struct xlsp05_buf argy;
    struct xlsp05_buf argz;
    argy.buf_type = XLSP_TYPE_NUL;
    argz.buf_type = XLSP_TYPE_NUL;
    expr = xlsp45_Pointwise_Eval_Flo(   buf, pos, cnt, xgrl, expr, ifv, op );
    expr = xlsp45_Pointwise_Eval_Flo( &argy, pos, cnt, xgrl, expr, ifv, op );
    expr = xlsp45_Pointwise_Eval_Flo( &argz, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );

    xlsp39_Copy_Flo_To_Flo( &buf->u1.flo[0], &argy.u.flo[0], cnt, ifv );
    xlsp39_Copy_Flo_To_Flo( &buf->u2.flo[0], &argz.u.flo[0], cnt, ifv );

    buf->buf_type = XLSP_TYPE_FL3;

    return 0;
}

/* }}} */
/* {{{ xlsp94_first							*/

xlsp94_first(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   char*             op = "FIRST";
    expr = xlsp4d_Pointwise_Eval_Fl3( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    buf->buf_type = XLSP_TYPE_FLO;
    return 0;
}

/* }}} */
/* {{{ xlsp95_second							*/

xlsp95_second(     buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   char*             op = "SECOND";
    expr = xlsp4d_Pointwise_Eval_Fl3( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    xlsp39_Copy_Flo_To_Flo( &buf->u.flo[0], &buf->u1.flo[0], cnt, ifv );
    buf->buf_type = XLSP_TYPE_FLO;
    return 0;
}

/* }}} */
/* {{{ xlsp96_third							*/

xlsp96_third(      buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   char*             op = "THIRD";
    expr = xlsp4d_Pointwise_Eval_Fl3( buf, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    xlsp39_Copy_Flo_To_Flo( &buf->u.flo[0], &buf->u2.flo[0], cnt, ifv );
    buf->buf_type = XLSP_TYPE_FLO;
    return 0;
}

/* }}} */
/* {{{ xlsp97_dot							*/

xlsp97_dot(        buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   char*             op = ".*";
    int               i;
    struct xlsp05_buf arg;
    arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp4d_Pointwise_Eval_Fl3(  buf, pos, cnt, xgrl, expr, ifv, op );
    expr = xlsp4d_Pointwise_Eval_Fl3( &arg, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    buf->buf_type = XLSP_TYPE_FLO;
    {   float *x0 = &buf->u .flo[0];   float *x1 = &arg.u .flo[0];
        float *y0 = &buf->u1.flo[0];   float *y1 = &arg.u1.flo[0];
        float *z0 = &buf->u2.flo[0];   float *z1 = &arg.u2.flo[0];
        float *r  = &buf->u .flo[0];
	if (ifv == NULL) {
	    for (i = 0;   i < cnt;   ++i) {
		*r++ = *x0++**x1++ + *y0++**y1++ + *z0++**z1++;
	    }
	} else {
	    int bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1)	*r    = *x0**x1 + *y0**y1 + *z0**z1;
		++r;
		++x0; ++x1;
		++y0; ++y1;
		++z0; ++z1;
		bits >>= 1;
	}   }
    }
    return 0;
}

/* }}} */
/* {{{ xlsp98_x								*/

xlsp98_x(          buf, pos, cnt, xgrl, expr, ifv )
struct xlsp05_buf* buf;
int                     pos, cnt;
LVAL				  xgrl, expr;
unsigned char *                               ifv;
{   char*             op = "x";
    int               i;
    struct xlsp05_buf arg;
    arg.buf_type = XLSP_TYPE_NUL;
    expr = xlsp4d_Pointwise_Eval_Fl3(  buf, pos, cnt, xgrl, expr, ifv, op );
    expr = xlsp4d_Pointwise_Eval_Fl3( &arg, pos, cnt, xgrl, expr, ifv, op );
    xlsp49_Lastarg( op, expr );
    {   float *x0 = &buf->u .flo[0];   float *x1 = &arg.u .flo[0];
        float *y0 = &buf->u1.flo[0];   float *y1 = &arg.u1.flo[0];
        float *z0 = &buf->u2.flo[0];   float *z1 = &arg.u2.flo[0];
        float *rx = &buf->u .flo[0];
        float *ry = &buf->u1.flo[0];
        float *rz = &buf->u2.flo[0];
	if (ifv == NULL) {
	    for (i = 0;   i < cnt;   ++i) {
		float x_0 = *x0++;   float x_1 = *x1++;
		float y_0 = *y0++;   float y_1 = *y1++;
		float z_0 = *z0++;   float z_1 = *z1++;
		*rx++ = y_0 * z_1   -   y_1 * z_0;
		*ry++ = x_1 * z_0   -   x_0 * z_1;
		*rz++ = x_0 * y_1   -   x_1 * y_0;
	    }
	} else {
	    int bits;
	    for (i = 0;   i < cnt;   ++i) {
		if (!(i&7))     bits  = *ifv++;
		if (bits & 1) {
		    float x_0 = *x0;   float x_1 = *x1;
		    float y_0 = *y0;   float y_1 = *y1;
		    float z_0 = *z0;   float z_1 = *z1;
		    *rx = y_0 * z_1   -   y_1 * z_0;
		    *ry = x_1 * z_0   -   x_0 * z_1;
		    *rz = x_0 * y_1   -   x_1 * y_0;
    		}
		++x0; ++x1; ++rx;
		++y0; ++y1; ++ry;
		++z0; ++z1; ++rz;
		bits >>= 1;
	}   }
    }
    return 0;
}

/* }}} */

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/

/* }}} */
