/* {{{ xgrl.h -- graphic relations.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      91Jan26
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/
/* }}} */

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xgrl;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xgrl00_Is_New();
extern LVAL xgrl03_Show_Msg();
extern LVAL xgrl04_Aref_Msg();
extern LVAL xgrl06_Setf_Msg();
extern LVAL xgrl08_Copy_Msg();
extern LVAL xgrl21_AdjustArray_Msg();

extern LVAL xgrl32_Fill_Pointer_Msg();
extern LVAL xgrl34_Vector_Push_Msg();
extern LVAL xgrl35_Vector_Push_Extend_Msg();
extern LVAL xgrl36_Vector_Pop_Msg();
extern LVAL xgrl37_Setf_Fill_Pointer_Msg();

extern LVAL xgrl40_GetArray_Msg();
extern LVAL xgrl42_SetArray_Msg();

extern LVAL xgrl76_Get_Msg();
extern LVAL xgrl79_Set_Msg();

extern LVAL xgrlA1_Bounding_Box_Msg();

extern LVAL xgrlF1_Array_List_Length_Msg();
extern LVAL xgrlF3_Array_List_Nth_Msg();
extern LVAL xgrlF8_Remove_Array_Msg();
extern LVAL xgrlFb_Rename_Array_Msg();
extern LVAL xgrla5_Delete_Msg();



#ifndef EXTERNED_SETFFILLPOINTER
extern LVAL k_setffillpointer;/* Keyword ":setf-fill-pointer" */
#define EXTERNED_SETFFILLPOINTER
#endif

#ifndef EXTERNED_S_PROPERTYLIST
extern LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define EXTERNED_S_PROPERTYLIST
#endif








#ifndef EXTERNED_INITIALCONTENTS
extern LVAL k_initialcontents;/* Keyword ":initial-contents" */
#define EXTERNED_INITIALCONTENTS
#endif

#ifndef EXTERNED_SHOW
extern LVAL k_show;/* Keyword ":show" */
#define EXTERNED_SHOW
#endif

#ifndef EXTERNED_COPY
extern LVAL k_copy;/* Keyword ":copy" */
#define EXTERNED_COPY
#endif

#ifndef EXTERNED_TO
extern LVAL k_to;/* Keyword ":to" */
#define EXTERNED_TO
#endif

#ifndef EXTERNED_S_ARRAYLIST
extern LVAL s_arraylist;/* Symbol "ARRAY-LIST" */
#define EXTERNED_S_ARRAYLIST
#endif

#ifndef EXTERNED_ADJUSTARRAY
extern LVAL k_adjustarray;/* Keyword ":adjust-array" */
#define EXTERNED_ADJUSTARRAY
#endif

#ifndef EXTERNED_BOUNDING_BOX
extern LVAL k_boundingbox;/* Keyword ":bounding-box" */
#define EXTERNED_BOUNDING_BOX
#endif

#ifndef EXTERNED_ROWMAJORAREF
extern LVAL k_rmaref;/* Keyword ":row-major-aref" */
#define EXTERNED_ROWMAJORAREF
#endif

#ifndef EXTERNED_ROWMAJORSETF
extern LVAL k_rmsetf;/* Keyword ":row-major-setf" */
#define EXTERNED_ROWMAJORSETF
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,	xgrl00_Is_New			)
DEFINE_SUBR(	NULL,	xgrl03_Show_Msg			)
DEFINE_SUBR(	NULL,	xgrl04_Aref_Msg			)
DEFINE_SUBR(	NULL,	xgrl06_Setf_Msg			)
DEFINE_SUBR(	NULL,	xgrl08_Copy_Msg			)
DEFINE_SUBR(	NULL,	xgrl21_AdjustArray_Msg		)

DEFINE_SUBR(	NULL,	xgrl32_Fill_Pointer_Msg		)
DEFINE_SUBR(	NULL,	xgrl34_Vector_Push_Msg		)
DEFINE_SUBR(	NULL,	xgrl35_Vector_Push_Extend_Msg	)
DEFINE_SUBR(	NULL,	xgrl36_Vector_Pop_Msg		)
DEFINE_SUBR(	NULL,	xgrl37_Setf_Fill_Pointer_Msg	)

DEFINE_SUBR(	NULL,	xgrl40_GetArray_Msg		)
DEFINE_SUBR(	NULL,	xgrl42_SetArray_Msg		)
DEFINE_SUBR(	NULL,	xgrl76_Get_Msg			)
DEFINE_SUBR(	NULL,	xgrl79_Set_Msg			)

DEFINE_SUBR(	NULL,	xgrlA1_Bounding_Box_Msg		)

DEFINE_SUBR(    NULL,	xgrlF1_Array_List_Length_Msg	)
DEFINE_SUBR(    NULL,	xgrlF3_Array_List_Nth_Msg	)
DEFINE_SUBR(    NULL,	xgrlF8_Remove_Array_Msg		)
DEFINE_SUBR(    NULL,	xgrlFb_Rename_Array_Msg		)
DEFINE_SUBR(	NULL,	xgrla5_Delete_Msg		)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xgrl;
LOCAL struct xgrl_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xgrl_table[] = {
    {	":ISNEW",		xgrl00_Is_New			},
    {	":AREF",		xgrl04_Aref_Msg			},
    {	":SETF",		xgrl06_Setf_Msg			},
    {	":COPY",		xgrl08_Copy_Msg			},
    {	":SHOW",		xgrl03_Show_Msg			},
    {	":ADJUST-ARRAY",	xgrl21_AdjustArray_Msg		},

    {	":FILL-POINTER",	 xgrl32_Fill_Pointer_Msg	 },
    {	":VECTOR-PUSH",		 xgrl34_Vector_Push_Msg		 },
    {	":VECTOR-PUSH-EXTEND",	 xgrl35_Vector_Push_Extend_Msg	 },
    {	":VECTOR-POP",		 xgrl36_Vector_Pop_Msg		 },
    {	":SETF-FILL-POINTER",	 xgrl37_Setf_Fill_Pointer_Msg	 },

    {	":GET-ARRAY",		xgrl40_GetArray_Msg		},
    {	":SET-ARRAY",		xgrl42_SetArray_Msg		},
    {	":GET",			xgrl76_Get_Msg			},
    {	":SET",			xgrl79_Set_Msg			},

    {	":BOUNDING-BOX",	xgrlA1_Bounding_Box_Msg		},

    {	":ARRAY-LIST-LENGTH",	xgrlF1_Array_List_Length_Msg	},
    {	":ARRAY-LIST-NTH",	xgrlF3_Array_List_Nth_Msg	},
    {	":REMOVE-ARRAY",	xgrlF8_Remove_Array_Msg		},
    {	":RENAME-ARRAY",	xgrlFb_Rename_Array_Msg		},
    {	":DELETE",		xgrla5_Delete_Msg		},

    {	NULL,			NULL				}
};

#ifndef DEFINED_SETFFILLPOINTER
LVAL k_setffillpointer;/* Keyword ":setf-fill-pointer" */
#define DEFINED_SETFFILLPOINTER
#endif

#ifndef DEFINED_S_PROPERTYLIST
LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define DEFINED_S_PROPERTYLIST
#endif



#ifndef DEFINED_INITIALCONTENTS
LVAL k_initialcontents;/* Keyword ":initial-contents" */
#define DEFINED_INITIALCONTENTS
#endif

#ifndef DEFINED_SHOW
LVAL k_show;/* Keyword ":show" */
#define DEFINED_SHOW
#endif

#ifndef DEFINED_COPY
LVAL k_copy;/* Keyword ":copy" */
#define DEFINED_COPY
#endif

#ifndef DEFINED_TO
LVAL k_to;/* Keyword ":to" */
#define DEFINED_TO
#endif

#ifndef DEFINED_S_ARRAYLIST
LVAL s_arraylist;/* Symbol "ARRAY-LIST" */
#define DEFINED_S_ARRAYLIST
#endif

#ifndef DEFINED_ADJUSTARRAY
LVAL k_adjustarray;/* Keyword ":adjust-array" */
#define DEFINED_ADJUSTARRAY
#endif

#ifndef DEFINED_BOUNDING_BOX
LVAL k_boundingbox;/* Keyword ":bounding_box" */
#define DEFINED_BOUNDING_BOX
#endif

#ifndef DEFINED_ROWMAJORAREF
LVAL k_rmaref;/* Keyword ":row-major-aref" */
#define DEFINED_ROWMAJORAREF
#endif

#ifndef DEFINED_ROWMAJORSETF
LVAL k_rmsetf;/* Keyword ":row-major-setf" */
#define DEFINED_ROWMAJORSETF
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_SETFFILLPOINTER
    k_setffillpointer = xlenter(":SETF-FILL-POINTER");
#define CREATED_SETFFILLPOINTER
#endif

#ifndef CREATED_S_PROPERTYLIST
    s_propertylist = xlenter("PROPERTY-LIST");
#define CREATED_S_PROPERTYLIST
#endif


#ifndef CREATED_INITIALCONTENTS
    k_initialcontents = xlenter(":INITIAL-CONTENTS");
#define CREATED_INITIALCONTENTS
#endif

#ifndef CREATED_SHOW
    k_show = xlenter(":SHOW");
#define CREATED_SHOW
#endif

#ifndef CREATED_COPY
    k_copy = xlenter(":COPY");
#define CREATED_COPY
#endif

#ifndef CREATED_TO
    k_to = xlenter(":TO");
#define CREATED_TO
#endif

#ifndef CREATED_S_ARRAYLIST
    s_arraylist = xlenter("ARRAY-LIST");
#define CREATED_S_ARRAYLIST
#endif

#ifndef CREATED_ADJUSTARRAY
    k_adjustarray = xlenter(":ADJUST-ARRAY");
#define CREATED_ADJUSTARRAY
#endif

#ifndef CREATED_BOUNDING_BOX
    k_boundingbox = xlenter(":BOUNDING-BOX");
#define CREATED_BOUNDING_BOX
#endif

#ifndef CREATED_ROWMAJORAREF
    k_rmaref = xlenter(":ROW-MAJOR-AREF");
#define CREATED_ROWMAJORAREF
#endif

#ifndef CREATED_ROWMAJORSETF
    k_rmsetf = xlenter(":ROW-MAJOR-SETF");
#define CREATED_ROWMAJORSETF
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xgrl = xgbj58_Create_Class("CLASS-GRAPHIC-RELATION",lv_xsry);
    xgbj57_Add_Instance_Variable( lv_xgrl, "ARRAY-LIST");
    xgbj56_Enter_Messages(        lv_xgrl, xgrl_table  );
#endif

/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
/* }}} */
