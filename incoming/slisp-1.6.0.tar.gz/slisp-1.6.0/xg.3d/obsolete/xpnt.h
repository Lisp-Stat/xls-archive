/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xpnt.h
* Description:  Hybrid-class header for (x y z) PoinT Arrays.
* Author:       Jeff Prothero
* Created:      90Nov29
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jeff Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jeff Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to jsp@milton.u.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xpnt;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xpnt03_Is_New();
extern LVAL xpnt04_Show();
extern LVAL xpnt05_Get();
extern LVAL xpnt06_Set();
extern LVAL xpnt07_Copy();
extern LVAL xpnt08_GetSize();
extern LVAL xpnt09_SetSize();

#ifndef EXTERNED_INITIALCONTENTS
extern LVAL k_initialcontents;/* Keyword ":initial-contents" */
#define EXTERNED_INITIALCONTENTS
#endif
#endif

#ifdef MODULE_XLFTAB_C_GLOBALS
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,	xpnt03_Is_New	)
DEFINE_SUBR(	NULL,	xpnt04_Show	)
DEFINE_SUBR(	NULL,	xpnt05_Get	)
DEFINE_SUBR(	NULL,	xpnt06_Set	)
DEFINE_SUBR(	NULL,	xpnt07_Copy	)
DEFINE_SUBR(	NULL,	xpnt08_GetSize	)
DEFINE_SUBR(	NULL,	xpnt09_SetSize	)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xpnt;
LOCAL struct xpnt_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xpnt_table[] = {
    {	":ISNEW",		xpnt03_Is_New	},
    {	":AREF",		xpnt05_Get	},
    {	":SETF",		xpnt06_Set	},
    {	":COPY",		xpnt07_Copy	},
    {	":ARRAY-DIMENSION",	xpnt08_GetSize	},
    {	":ADJUST-ARRAY",	xpnt09_SetSize	},
    {	":SHOW",		xpnt04_Show	},

    {	NULL,			NULL		}
};

#ifndef DEFINED_INITIALCONTENTS
LVAL k_initialcontents;/* Keyword ":initial-contents" */
#define DEFINED_INITIALCONTENTS
#endif
#endif


#ifdef MODULE_XLOBJ_C_OBSYMBOLS
    lv_xpnt = getvalue(xlenter("POINT-ARRAY"));

#ifndef CREATED_INITIALCONTENTS
    k_initialcontents = xlenter(":INITIAL-CONTENTS");
#define CREATED_INITIALCONTENTS
#endif
#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xpnt = xlclass("POINT-ARRAY",0);
    setivar(lv_xpnt,SUPERCLASS,k_struc);

    /* Define basic pointarray messages. */
    {
        struct xpnt_message * p = xpnt_table;
        while (p->gs_msg_name != NULL) {
            xladdmsg(lv_xpnt,p->gs_msg_name,funtab_offset(p->gs_subr));
            ++p;
        }
    }
#endif



