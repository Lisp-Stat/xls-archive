/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xpnt.c
* Description:  Hybrid-class code for (x y z) PoinT Arrays.
* Author:       Jeff Prothero
* Created:      90Nov20
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jeff Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jeff Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to jsp@milton.u.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/************************************************************************/
/*                              contents                                */
/*									*/
/*.xpnt00_List_To_Point -- Convert (x y z) list to geo_point.		*/
/*.xpnt01_Point_To_List -- Convert geo_point to (x y z) list.		*/
/*.xpnt02_Sprintf -- Sprintf point into buffer.				*/
/*.xpnt -- Describe point-record to csry.c.				*/
/*.xpnt03_Is_New -- Initialize a new pointa instance.			*/
/*.xpnt04_Show -- Show the contents of a point-array.			*/
/*.xpnt05_Get -- Get given entry.					*/
/*.xpnt06_Set -- Set given entry.					*/
/*.xpnt07_Copy -- Build copy of given POINT-ARRAY.			*/
/*.xpnt08_GetSize - Get size-in-points of imm array.			*/
/*.xpnt09_SetSize - Set size-in-points of imm array.			*/
/*									*/
/*		(generated via "grep '/\*\.' xpnt.c")			*/
/************************************************************************/

/************************************************************************/
/*                              history                                 */
/*									*/
/* 91Jan07 jsp  xpnt01_Point_To_List() had nested-cons()s bug.  Fixed.  */
/* 90Nov20 jsp: Created.						*/
/************************************************************************/

#include "../../xcore/src/xlisp.h"

#include "csry.h"

extern LVAL lv_xpnt;

#include "geo.h"



/************************************************************************/
/*.xpnt00_List_To_Point -- Convert (x y z) list to geo_point.		*/
/************************************************************************/
/* This is essentially identical to xgtm14_List_To_XYZ() */

xpnt00_List_To_Point( p, p_as_lval )
geo_point*	      p;
LVAL			 p_as_lval;
/*-
    Convert (x y z) list to geo_point.
-*/
{
    LVAL x_cell;
    LVAL y_cell;
    LVAL z_cell;

    LVAL x_as_lval;
    LVAL y_as_lval;
    LVAL z_as_lval;

    /* If initializer is null, use default values: */
    if (p_as_lval == NIL) {
        p->x = p->y = p->z = 1.0;
        return;
    }

    x_cell = p_as_lval  ;if (!consp(x_cell)) xlbadinit(p_as_lval);
    y_cell = cdr(x_cell);if (!consp(y_cell)) xlbadinit(p_as_lval);
    z_cell = cdr(y_cell);if (!consp(z_cell)) xlbadinit(p_as_lval);

    if (cdr(z_cell) != NIL)                  xlbadinit(p_as_lval);

    x_as_lval = car(x_cell);
    y_as_lval = car(y_cell);
    z_as_lval = car(z_cell);

    p->x = xgbj00_Get_Fix_Or_Flo_Num(x_as_lval);
    p->y = xgbj00_Get_Fix_Or_Flo_Num(y_as_lval);
    p->z = xgbj00_Get_Fix_Or_Flo_Num(z_as_lval);
}



/************************************************************************/
/*.xpnt01_Point_To_List -- Convert geo_point to (x y z) list.		*/
/************************************************************************/
/* This is essentially identical to xgtm15_Point_To_List() */

LVAL xpnt01_Point_To_List( p )
geo_point*		   p;
/*-
    Convert geo_point to (x y z) list.
-*/
{
    LVAL result;
    xlsave1(result);
    result = cons( cvflonum(p->z), NIL		);
    result = cons( cvflonum(p->y), result	);
    result = cons( cvflonum(p->x), result	);
    xlpop();
    return result;
}



/************************************************************************/
/*.xpnt02_Sprintf -- Sprintf point into buffer.				*/
/************************************************************************/

xpnt02_Sprintf( buf, p )
char*		buf;
geo_point*	     p;
/*-
    Sprintf point into buffer.
-*/
{
    return sprintf(buf, "%g %g %g", p->x, p->y, p->z );
}



/************************************************************************/
/*.xpnt -- Describe point-record to csry.c.				*/
/************************************************************************/

LOCAL struct csry_struct xpnt = {
    /* LVAL k_ary              = */ NULL,/*Not known at linktime.*/
    /* int  sizeof_struct       = */ sizeof( geo_point ),
    /* int  (*list_to_struct)() = */ xpnt00_List_To_Point,
    /* LVAL (*struct_to_list)() = */ xpnt01_Point_To_List,
    /* int  (*sprintf_struct)() = */ xpnt02_Sprintf
};
/*-
    Describe point-record to csry.c.
-*/



/************************************************************************/
/*.xpnt03_Is_New -- Initialize a new pointa instance.			*/
/************************************************************************/

LVAL xpnt03_Is_New()
/*-
    Initialize a new pointa instance.
-*/
{
    /* Not really the best place to do this: */
    xpnt.k_ary = lv_xpnt;

    return xsry00_Is_New( &xpnt );
}



/************************************************************************/
/*.xpnt04_Show -- Show the contents of a point-array.			*/
/************************************************************************/

LVAL xpnt04_Show()
/*-
    Show the contents of a point-array.
-*/
{
    return xsry00_Is_New( &xpnt );
}



/************************************************************************/
/*.xpnt05_Get -- Get given entry.					*/
/************************************************************************/

LVAL xpnt05_Get()
/*-
    Get given entry.
-*/
{
    return xsry04_Get( &xpnt );
}



/************************************************************************/
/*.xpnt06_Set -- Set given entry.					*/
/************************************************************************/

LVAL xpnt06_Set()
/*-
    Set given entry.
-*/
{
    return xsry06_Set( &xpnt );
}



/************************************************************************/
/*.xpnt07_Copy -- Build copy of given POINT-ARRAY.			*/
/************************************************************************/

LVAL xpnt07_Copy()
/*-
    Build copy of given POINT-ARRAY.
-*/
{
    return xsry08_Copy( &xpnt );
}



/************************************************************************/
/*.xpnt08_GetSize - Get size-in-points of imm array.			*/
/************************************************************************/

LVAL xpnt08_GetSize()
/*-
    Get size-in-points of imm array.
-*/
{
    return xsry10_GetSize( &xpnt );
}



/************************************************************************/
/*.xpnt09_SetSize - Set size-in-points of imm array.			*/
/************************************************************************/

LVAL xpnt09_SetSize()
/*-
    Set size-in-points of imm array.
-*/
{
    return xsry11_SetSize( &xpnt );
}



