/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xmdc.c
* Description:  system specific graphics code for Silicon Graphics 4D machines.
* Author:       Jeff Prothero
* Created:      90Nov09
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jeff Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jeff Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to jsp@milton.u.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#include "gl.h"
#include "device.h"
#include "xg.h"

/* Track identifiers of open windows: */
int xm_window;

/* REQUIRED FN: Graphics initialization: */
xm_init()
{
    /* Initialize graphics hardware and software. */
    foreground();
    prefposition(XMAXSCREEN/2,XMAXSCREEN*3/4,YMAXSCREEN/2,YMAXSCREEN*3/4);
    xm_window = winopen("xlisp3d");
    winset( xm_window );
    winattach();
    winconstraints();
}

/* REQUIRED FN: Graphics wrapup: */
xm_wrapup()
{
    /* End-of-world closedown. */
    winclose( xm_window );
    gexit();
}

#ifdef XM_WCLEAR
/* Optional fn: Clear given window. */
xm_wClear( winNo, value )
int        winNo;
int               value;
{
    /* Clear window to given value. */
}
#endif

#ifdef XM_WFLUSH
/* Optional fn: Update given window. */
xm_wFlush( winNo, value )
int        winNo;
int               value;
{
    /* Some implementations may buffer */
    /* commands until this command is  */
    /* recieved, and then update the   */
    /* screen.  In particular, double- */
    /* buffered systems do this.       */
}
#endif

/* REQUIRED FN: Return count of windows we can use: */
xm_wMax()
{
    /* Return current number of windows. */
    /* It's ok to fix this at 1.         */
    return 1;
}

/* REQUIRED FN: Return pixel location of given window: */
xm_wPosGet( winNo, x, y )
int         winNo;
int               *x,*y;
{
    /* Return location of minimum (x,y)    */
    /* corner in screen pixel coordinates. */
    /* Return TRUE on success, FALSE on    */
    /* failure.  OK to always faile.       */
    /* Origin is (0,0).                    */
}

/* REQUIRED FN: Change pixel location of given window: */
xm_wPosSet( winNo, x, y )
int         winNo;
int               *x,*y;
{
    /* Set location of minimum (x,y)       */
    /* corner in screen pixel coordinates. */
    /* Return TRUE on success, FALSE on    */
    /* failure.  OK to always fail.        */
}

/* REQUIRED FN: Return pixel dimension of given window: */
xm_wSizGet( winNo, xmax,  ymax )
int         winNo;
int               *xmax, *ymax;
{
    /* Return pixel dimensions of window. */
    /* Origin is (0,0).                   */
}

/* REQUIRED FN: Set pixel dimension of given window: */
xm_wSizSet( winNo, xmax,  ymax )
int         winNo;
int                xmax,  ymax;
{
    /* Return TRUE on success, FALSE on failure. */
    /* It's ok to always fail.                   */
}

/* REQUIRED FN: Get mode of given window: */
xm_wModGet( winNo, is_rgb, tab_siz, tab_min )
int         winNo;
int               *is_rgb,*tab_siz, tab_min; 
{
    /* Set *is_rgb TRUE for true-color windows.  */
    /* Else set *tab_siz to number of entries we */
    /* are allowed to use in colortable, and     */
    /* *tab_min to first entry we can use.       */
}

/* REQUIRED FN: Set mode of given window: */
xm_wModSet( winNo, is_rgb, tab_siz, tab_min )
int         winNo;
int               *is_rgb,*tab_siz,*tab_min; 
{
    /* Try to set given window to given mode. */
    /* Return TRUE if completely successful.  */
    /* Return FALSE on failure, optionally    */
    /* setting parameters to closest valid    */
    /* request.  OK to always fail.           */
}

/* REQUIRED FN: */
xm_clikAvailable()
{
    /* Return TRUE iff xm_clikGet can return */
    /* without blocking.                     */
}

/* REQUIRED FN: */
xm_clikGet( winNo, x, y )
int        *winNo,*x,*y;
{
    /* Set *winNo to window in which user clicked. */
    /* Set *x,*y to pixel coordinates *in window*  */
    /* which user clicked on.  Block until user    */
    /* clicks on something.                        */
}

/* REQUIRED FN: */
xm_mouse( winNo, x, y, button )
int      *winNo,*x,*y,*button;
{
    /* Return window which mouse is currently in, */
    /* x,y pixel coordinates *in window*, and     */
    /* UP/DOWN (FALSE/TRUE) status of mouse       */
    /* button.  (Logical single-button mouse.)    */
    return 1;
}

/* REQUIRED if non-RGB windows exist. */
xm_pixGet( buf, winNo, x, y, count )
int       *buf, winNo, x, y, count;
{
    /* Copy COUNT pseudocolor pixels from window buffer to */
    /* buf, starting at (x,y) with x increasing. Return    */
    /* TRUE on success, FALSE on failure.  OK to always    */
    /* fail, but some programs may suffer.                 */
}

/* REQUIRED if non-RGB windows exist. */
xm_pixSet( buf, winNo, x, y, count )
int       *buf, winNo, x, y, count;
{
    /* Copy COUNT pseudocolor pixels from buf to window    */
    /* buffer, starting at (x,y) with x increasing.        */
}

/* REQUIRED if RGB windows exist. */
xm_rgbGet( buf, winNo, x, y, count )
char      *buf;
int             winNo, x, y, count;
{
    /* Copy COUNT RGB color pixels from window buffer to   */
    /* buf, starting at (x,y) with x increasing. Return    */
    /* TRUE on success, FALSE on failure.  OK to always    */
    /* fail, but some programs may suffer.                 */
}

/* REQUIRED if RGB windows exist. */
xm_rgbSet( buf, winNo, x, y, count )
char      *buf;
int             winNo, x, y, count;
{
    /* Copy COUNT RGB color pixels from buf to window    */
    /* buffer, starting at (x,y) with x increasing.      */
}

xm_2pt( x0,y0,z0, x1,y1,z1 )
float   x0,y0,z0, x1,y1,z1;
{

}

drawboxcirc() {

    pushmatrix();
    translate(200.0, 200.0, 0.0);
    color(BLACK);
    clear();
    color(BLUE);
    recti(0, 0, 100, 100);
    color(RED);
    circi(50, 50, 50);
    popmatrix();
}

xm_fLine(x0,y0,z0,x1,y1,z1)
float    x0,y0,z0,x1,y1,z1;
{
printf("\nx0,y0,z0 g=%g,%g,%g",x0,y0,z0);
printf("\nx1,y1,z1 g=%g,%g,%g",x1,y1,z1);
#if SOON
    pushmatrix();
    translate(200.0, 200.0, 0.0);

    color(BLACK);
    clear();

    color(RED);
    move(x0,y0,z0);
    draw(x1,y1,z1);

    popmatrix();
#else
    pushmatrix();
    translate(200.0, 200.0, 0.0);
    color(BLACK);
    clear();
    color(BLUE);
    recti(0, 0, 100, 100);
    recti(10, 10, 110, 110);
    color(RED);
    circi(50, 50, 50);
  move(x0,y0,z0);
  draw(x1,y1,z1);
    popmatrix();
#endif
}

