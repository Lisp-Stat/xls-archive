/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xg.h
* Description:  System-independent graphics header.
* Author:       Jeff Prothero
* Created:      90Nov09
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jeff Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jeff Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* OR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to jsp@milton.u.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#include "xmdc.h"
#include "../../xcore/src/xlisp.h"

/* Record containing our graphics state: */
struct xm_state_rec {
    /* These three matrices, concatenated, */
    float mat_pre[4][4];
    float mat_mid[4][4];
    float mat_pst[4][4];
    /* Yield this matrix: */
    float mat_tot[4][4];
};
