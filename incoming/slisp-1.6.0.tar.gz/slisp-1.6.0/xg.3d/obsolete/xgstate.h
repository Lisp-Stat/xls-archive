/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xgstate.h
* Description:  Graphics-state class.
* Author:       Jeff Prothero
* Created:      90Nov19
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jeff Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jeff Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* OR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to jsp@milton.u.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifdef MODULE_XLFTAB_C_GLOBALS
/**********************************************************/
/* In this section, you should declare all your primitive */
/* functions -- those which will be visible to the xlisp  */
/* programmer. Examples:                                  */
/**********************************************************/
extern LVAL xg_fLine();
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
DEFINE_SUBR(	"DRAW-LINE",	xg_fLine )
#endif

#ifdef MODULE_XLINIT_C_XLINIT
/**********************************************************/
/* In this section, you can specify code to be executed   */
/* on program startup.  For example, a graphics class	  */
/* may have to initialize the graphics hardware.      	  */
/*							  */
/* Example:						  */
/**********************************************************/
xg_init();
#endif

#ifdef MODULE_XLISP_C_WRAPUP
/**********************************************************/
/* In this section, you can specify code to be executed   */
/* on program exit.  For example, a graphics class	  */
/* may have to de-allocate the graphics hardware.      	  */
/*							  */
/* Example:						  */
/**********************************************************/
xg_wrapup();
#endif




/**********************************************************/
/* Stuff beyond here gets increasingly obscure.  99% of   */
/* the time, you shouldn't need to use these. I'd just as */
/* soon discourage use of these, so I won't document them */
/* in any detail. Most of this stuff relates to creating  */
/* new xlisp node types, in the sense of #defining and    */
/* implementing new n_type values.  Instead of doing this,*/
/* you might want to consider creating a subclass of      */
/* GOBJECT instead.  This lets you hide arbitrary binary  */
/* data in your object without hacking the xlisp files.   */
/* If you *do* decide to implement new n_types, you'll.   */
/* have to #define the new values in xldmem.h, worrying   */
/* about collisions with other packages which do the same */
/* thing.  (Most of?) the rest of your hacks should fit   */
/* in this file. 90Nov18 jsp.                             */
/**********************************************************/

#ifdef MODULE_XLDMEM_H_NINFO
/* New entries to appear in xldmem.h node "ninfo" union. */
#endif

#ifdef MODULE_XLDBUG_C_BREAKLOOP_REPLACEMENT
/* If you need a different "breakloop" fn, define   */
/* NEED_TO_REPLACE_BREAKLOOP in the XLISP_H_MACROS  */
/* section above, and provide a replacement version */
/* of the function here.                            */
#endif

#ifdef MODULE_XLDMEM_C_GLOBALS
/* If you #defined new values for n_type, you need  */
/* cv... functions to create them.  Put them here.  */
#endif

#ifdef MODULE_XLDMEM_C_GC
/* If your C code keeps LVAL pointers around (try   */
/* to avoid this!), the garbage collector needs to  */
/* have special code to mark them.  If so, insert   */
/* a code fragment like                             */
/*    if (v_savedobjs)  mark(v_savedobjs);          */
/* here.                                            */
#endif

#ifdef MODULE_XLDMEM_C_MARK
/* If you defined new values for n_type, mark()     */
/* needs to know how to find all the LVALs (and     */
/* only the LVALs) in them.  Insert code here to do */
/* that.                                            */
#endif

#ifdef MODULE_XLDMEM_C_SWEEP
/* If you defined new values for n_type, sweep()    */
/* needs to know how to find and recycle any ram    */
/* associated with the node (and do any other       */
/* cleanup required by your application) when the   */
/* node gets garbage-collected.  Insert code here   */
/* to do that.                                      */
#endif

#ifdef MODULE_XLDMEM_C_XLMINIT
/* If you defined new roots for the garbage         */
/* collector, xlminit() needs to initialize them    */
/* (to NIL, typically).  Insert code here to do     */
/* that.                                            */
#endif

#ifdef MODULE_XLGLOB_C_GLOBALS
/* If you defined new roots for the garbage         */
/* collector, you need to declare them.  If you     */
/* defined new values for n_type, you will need to  */
/* define names for them.  Declare both here, like: */
#endif

#ifdef MODULE_XLIMAGE_C_XLISAVE
/* If you defined new values for n_type which have  */
/* associated ram storage hidden somewhere, xlisave */
/* needs to know how to write them out. Insert code */
/* here to do that. (It is often sufficient to      */
/* simply jump to the regular vector code.)         */
#endif

#ifdef MODULE_XLIMAGE_C_XLIRESTORE
/* If you defined new values for n_type which have  */
/* extra ram storage hidden somewhere, xlirestore   */
/* needs to know how to recreate them.  Insert code */
/* here to do that. (It is often sufficient to      */
/* simply jump to the regular vector code.)         */
#endif

#ifdef MODULE_XLIMAGE_C_FREEIMAGE
/* If you defined new values for n_type which have  */
/* extra ram storage hidden somewhere, freeimage    */
/* needs to know how to free() the ram. Insert code */
/* here to do that. (It is often sufficient to      */
/* simply jump to the regular vector code.)         */
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
/* Any new typename you defined in the XLGLOB_C_VARS*/
/* section above need to be defined "extern" here:  */
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
/* Any new typename you defined in the XLGLOB_C_VARS*/
/* section above need to get a symbol here. Any     */
/* other new symbols you need can be built here too.*/
#endif

#ifdef MODULE_XLPRIN_C_XLPRINT
/* Any externs you need to print stuff (xlprin.c).  */
#endif

#ifdef MODULE_XLPRIN_C_XLPRINT
/* If you defined new values for n_type, xlprint()  */
/* needs to know how to print them out.  Insert     */
/* code here to do that.                            */
#endif

#ifdef MODULE_XLSYS_C_GLOBALS
/* Externs for any new type symbols (xlprin.c):     */
#endif

#ifdef MODULE_XLSYS_C_XTYPE
/* If you defined new values for n_type, xtype()    */
/* needs to know how to convert them to symbols.    */
/* Insert code here to do that.                     */
#endif
