/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xg.c
* Description:  portable graphics code for Silicon Graphics 4D machines.
* Author:       Jeff Prothero
* Created:      90Nov09
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jeff Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jeff Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to jsp@milton.u.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/***************************************************/
/* Note that, while the functions is this file are */
/* portable, it may frequently be desirable to re- */
/* implement some of them for speed.  Thus, each   */
/* fn has a matching #if which may be set in your  */
/* m-mymachine.h file.                             */
/*						   */
/* As a general rule, you should not modify the    */
/* functions in this file, but should instead turn */
/* off the relevant function and supply a replace- */
/* ment in your m- .h file.                        */
/***************************************************/

#include "xg.h"

/* Graphics initialization: */
xg_init()
{
    xm_init();
}

/* Graphics wrapup: */
xg_wrapup()
{
    xm_wrapup();
}

#ifndef XM_WCLEAR
xm_wClear( winNo, value )
int        winNo;
int               value;
{
    /* Clear window to given value. */
}
#endif

#ifndef XM_WFLUSH
xm_wFlush( winNo, value )
int        winNo;
int               value;
{
}
#endif

xg_fntDraw( window, points, normals, tris )
{
    /* Flat-shaded triangles from normals. */
}

xg_fctDraw( window, points, colors, tris )
{
    /* Flat-shaded triangles from colors. */
}

xg_tgnDraw( window, points, normals, tris )
{
    /* Gouraud-shaded triangles from normals. */
}

xg_tgcDraw( window, points, colors, tris )
{
    /* Gouraud-shaded triangles from colors. */
}

xg_tgcnDraw( window, points, colors, tris )
{
    /* Gouraud-shaded triangles from colors AND normals. */
}

xg_tpnDraw( window, points, normals, tris )
{
    /* Phong-shaded triangles from normals. */
}

xg_tpcnDraw( window, points, normals, tris )
{
    /* Phong-shaded triangles from normals AND colors. */
}


/* xg_fLine - draw line given two endpoints. */
/* Called like (draw-line x y z x y z) */
LVAL xg_fLine()
{
    /* Variables to hold the arguments: */
    FLOTYPE x0,y0,z0;
    FLOTYPE x1,y1,z1;
    LVAL arg;

    arg = xlgaflonum(); x0 = getflonum( arg );
    arg = xlgaflonum(); y0 = getflonum( arg );
    arg = xlgaflonum(); z0 = getflonum( arg );

    arg = xlgaflonum(); x1 = getflonum( arg );
    arg = xlgaflonum(); y1 = getflonum( arg );
    arg = xlgaflonum(); z1 = getflonum( arg );

    xm_fLine(x0,y0,z0,x1,y1,z1);

    return NIL;
}
