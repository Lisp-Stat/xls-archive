/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xtgl.c
* Description:  Hybrid-class code triangle arrays.
* Author:       Jeff Prothero
* Created:      90Dec03
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jeff Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jeff Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to jsp@milton.u.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/


/************************************************************************/
/*                              contents                                */
/*									*/
/*.xtgl00_List_To_Triangle -- Convert (a b c) list to geo_triangle.	*/
/*.xtgl01_Triangle_To_List -- Convert geo_triangle to (a b c) list.	*/
/*.xtgl02_Sprintf -- Sprintf triangle into buffer.			*/
/*.xtglgle -- Describe geo_triangle to csry.c.				*/
/*.xtgl03_Is_New -- Initialize a new trian instance.			*/
/*.xtgl04_Show -- Show the contents of a triangle-array.		*/
/*.xtgl05_Get -- Get given entry.					*/
/*.xtgl06_Set -- Set given entry.					*/
/*.xtgl07_Copy -- Build copy of given TRIA.				*/
/*.xtgl08_GetSize - Get size-in-triangles of imm array.			*/
/*.xtgl09_SetSize - Set size-in-triangles of imm array.			*/
/*									*/
/*		(generated via "grep '/\*\.' xtgl.c")			*/
/************************************************************************/

/************************************************************************/
/*                              history                                 */
/*									*/
/* 91Jan07 jsp  xtgl01_Triangle_To_List() had nested-cons()s bug. Fixed.*/
/* 90Dec03 jsp: Created.						*/
/************************************************************************/
  
#include "../../xcore/src/xlisp.h"

#include "csry.h"
#include "geo.h"

extern LVAL s_stdout;
extern LVAL xsendmsg(); 

extern LVAL lv_xtgl;



/************************************************************************/
/*.xtgl00_List_To_Triangle -- Convert (a b c) list to geo_triangle.	*/
/************************************************************************/

xtgl00_List_To_Triangle( p, p_as_lval )
geo_triangle*		 p;
LVAL			    p_as_lval;
/*-
    Convert (a b c) list to geo_triangle.
-*/
{
    LVAL a_cell;
    LVAL b_cell;
    LVAL c_cell;

    LVAL a_as_lval;
    LVAL b_as_lval;
    LVAL c_as_lval;

    /* If initializer is null, use default values: */
    if (p_as_lval == NIL) {
        p->a = p->b = p->c = 0;
        return;
    }

    a_cell = p_as_lval  ;if (!consp(a_cell)) xlbadinit(p_as_lval);
    b_cell = cdr(a_cell);if (!consp(b_cell)) xlbadinit(p_as_lval);
    c_cell = cdr(b_cell);if (!consp(c_cell)) xlbadinit(p_as_lval);

    if (cdr(c_cell) != NIL)                  xlbadinit(p_as_lval);

    a_as_lval = car(a_cell);
    b_as_lval = car(b_cell);
    c_as_lval = car(c_cell);

    if (!fixp(a_as_lval)) xlbadinit(p_as_lval);
    if (!fixp(b_as_lval)) xlbadinit(p_as_lval);
    if (!fixp(c_as_lval)) xlbadinit(p_as_lval);

    {
	int  a,b,c;

	a    = getfixnum(a_as_lval);
	b    = getfixnum(b_as_lval);
	c    = getfixnum(c_as_lval);

        if (a < 0  ||
            b < 0  ||
            c < 0
        ) {
	    xlbadinit(p_as_lval);
        }
	p->a = a;
	p->b = b;
	p->c = c;
    }
}



/************************************************************************/
/*.xtgl01_Triangle_To_List -- Convert geo_triangle to (a b c) list.	*/
/************************************************************************/

LVAL xtgl01_Triangle_To_List( p )
geo_triangle*		      p;
/*-
    Convert geo_triangle to (a b c) list.
-*/
{
    LVAL result;
    xlsave1(result);
    result = cons( cvfixnum(p->c), NIL    );
    result = cons( cvfixnum(p->b), result );
    result = cons( cvfixnum(p->a), result );
    xlpop();
    return result;
}



/************************************************************************/
/*.xtgl02_Sprintf -- Sprintf triangle into buffer.			*/
/************************************************************************/

xtgl02_Sprintf( buf, p )
char*		buf;
geo_triangle*	     p;
/*-
    Sprintf triangle into buffer.
-*/
{
    return sprintf(buf, "%d %d %d", p->a, p->b, p->c );
}



/************************************************************************/
/*.xtglgle -- Describe geo_triangle to csry.c.				*/
/************************************************************************/

LOCAL struct csry_struct xtglgle = {
    /* LVAL k_ary                = */ NULL,/*Not known at linktime.*/
    /* int  sizeof_struct        = */ sizeof( geo_triangle ),
    /* int  (*list_to_struct)()  = */ xtgl00_List_To_Triangle,
    /* LVAL (*struct_to_list)()  = */ xtgl01_Triangle_To_List,
    /* int  (*sprintf_struct)()  = */ xtgl02_Sprintf
};
/*-
    Describe geo_triangle to csry.c.
-*/



/************************************************************************/
/*.xtgl03_Is_New -- Initialize a new trian instance.			*/
/************************************************************************/

LVAL xtgl03_Is_New()
/*-
    Initialize a new trian instance.
-*/
{
    /* Not really the best place to do this: */
    xtglgle.k_ary = lv_xtgl;

    return xsry00_Is_New( &xtglgle );
}



/************************************************************************/
/*.xtgl04_Show -- Show the contents of a triangle-array.		*/
/************************************************************************/

LVAL xtgl04_Show()
/*-
    Show the contents of a triangle-array.
-*/
{
    return xsry00_Is_New( &xtglgle );
}



/************************************************************************/
/*.xtgl05_Get -- Get given entry.					*/
/************************************************************************/

LVAL xtgl05_Get()
/*-
    Get given entry.
-*/
{
    return xsry04_Get( &xtglgle );
}



/************************************************************************/
/*.xtgl06_Set -- Set given entry.					*/
/************************************************************************/

LVAL xtgl06_Set()
/*-
    Set given entry.
-*/
{
    return xsry06_Set( &xtglgle );
}



/************************************************************************/
/*.xtgl07_Copy -- Build copy of given TRIA.				*/
/************************************************************************/

LVAL xtgl07_Copy()
/*-
    Build copy of given TRIA.
-*/
{
    return xsry08_Copy( &xtglgle );
}



/************************************************************************/
/*.xtgl08_GetSize - Get size-in-triangles of imm array.			*/
/************************************************************************/
LVAL xtgl08_GetSize()
/*-
    Get size-in-triangles of imm array.
-*/
{
    return xsry10_GetSize( &xtglgle );
}



/************************************************************************/
/*.xtgl09_SetSize - Set size-in-triangles of imm array.			*/
/************************************************************************/

LVAL xtgl09_SetSize()
/*-
    Set size-in-triangles of imm array.
-*/
{
    return xsry11_SetSize( &xtglgle );
}


