/*- xvol.c -- support code for handling MRI images.			*/
/*- This file is formatted for outline-minor-mode in emacs19.		*/
/*-^C^O^A shows All of file.						*/
/* ^C^O^Q Quickfolds entire file. (Leaves only top-level headings.)	*/
/* ^C^O^T hides all Text. (Leaves all headings.)			*/
/* ^C^O^I shows Immediate children of node.				*/
/* ^C^O^S Shows all of a node.						*/
/* ^C^O^D hiDes all of a node.						*/
/* ^HFoutline-mode gives more details.					*/
/* (Or do ^HI and read emacs:outline mode.)				*/

/************************************************************************/
/*-    Copyright.							*/
/************************************************************************/

/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      94Jul28
* Language:     C
* Package:      N/A
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************

/************************************************************************/
/*-	history								*/
/************************************************************************/
/*
 * 98Mar13 kph: Moved in point normal manipulation code (from xscanner/xcut.c)
 * 96Mar29 jsp: Added xvolh9_transform_volume.
 * 96Mar28 jsp: Default xvolh6_Resample_Volume_Fn 'mat' to identity, not NULL
 * 95Jul14 jsp: Created, from xmri.c code.
 */
/************************************************************************/
/*-	header stuff							*/
/************************************************************************/

#include "../../xcore/c/xlisp.h"
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/cgrl.h"
#include "../../xg.3d/c/cf2v.h"
#include "../../xg.3d/c/cf8v.h"
#include "../../xg.3d/c/cflv.h"
#include "../../xg.3d/c/cmtl.h"
#include "../../xg.3d/c/cthl.h"
#include "../../xg.3d/c/geo.h"
#include "../../xg.3d/c/ctfm.h"
#include "cvol.h"

extern LVAL xsendmsg0();
extern LVAL xsendmsg1();
extern LVAL xsendmsg2();
extern LVAL xsendmsg3();

/* I suspect some of these aren't needed any more: */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <string.h>
#include <device.h>
#include <fcntl.h>
#include <termio.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#include <malloc.h>
#include <unistd.h>



#ifndef ERR
#define ERR (-1)
#endif

#undef  loop
#define loop for(;;)


extern LVAL k_ge_u_char;
extern LVAL k_ge_char;
extern LVAL k_ge_u_short;
extern LVAL k_ge_short;
extern LVAL k_ge_u_int;
extern LVAL k_ge_int;
extern LVAL k_ge_float;
extern LVAL k_ge_double;

extern LVAL k_reverse_x;
extern LVAL k_intensity;
extern LVAL k_min;
extern LVAL k_max;
extern LVAL k_result_in;

extern LVAL k_pixelred;
extern LVAL k_pixelgreen;
extern LVAL k_pixelblue;
extern LVAL k_pixeldepth;
extern LVAL k_setarray;
extern LVAL k_adjustarray;
extern LVAL k_show;
extern LVAL k_pixelrelation;
extern LVAL k_axis;
extern LVAL k_transform;

extern LVAL k_plane;
extern LVAL k_depth_in_bits;
extern LVAL k_endian;
extern LVAL k_big;
extern LVAL k_little;
extern LVAL k_padding;

extern LVAL k_slice;
extern LVAL k_filename;
extern LVAL k_subsample_by;
extern LVAL k_zoom_by;
extern LVAL k_voxels;
extern LVAL k_isolevel;
extern LVAL k_thing;
extern LVAL k_bin_size;
extern LVAL k_pointx;
extern LVAL k_pointy;
extern LVAL k_pointz;
extern LVAL k_rendering_relation;
extern LVAL k_facetrelation;

extern LVAL k_material;
extern LVAL k_diffuse_red;
extern LVAL k_diffuse_green;
extern LVAL k_diffuse_blue;
extern LVAL k_alpha;
extern LVAL k_range;
extern LVAL k_depth;
extern LVAL k_rows;
extern LVAL k_cols;
extern LVAL k_file_offset;
extern LVAL k_distance;
extern LVAL k_dst_min;
extern LVAL k_dst_max;
extern LVAL k_src_min;
extern LVAL k_src_max;
extern LVAL k_filter_shape;
extern LVAL k_impulse;
extern LVAL k_box;
extern LVAL k_triangle;
extern LVAL k_quadratic;
extern LVAL k_mitchell;
extern LVAL k_zero_rest;
extern LVAL k_fillpointer;
extern LVAL true;

extern LVAL k_format;
extern LVAL k_avs_uniform_field;

extern LVAL k_new;
extern LVAL lv_xgrl;
extern LVAL lv_xflv;
extern LVAL lv_xf8v;
extern LVAL lv_xf2v;


extern LVAL k_minx;  extern LVAL k_maxx;
extern LVAL k_miny;  extern LVAL k_maxy;
extern LVAL k_minz;  extern LVAL k_maxz;

extern LVAL k_mini;  extern LVAL k_maxi;
extern LVAL k_minj;  extern LVAL k_maxj;
extern LVAL k_mink;  extern LVAL k_maxk;

extern LVAL k_max_facets;
extern LVAL k_iterations;
extern LVAL k_weight;
extern LVAL k_array;
extern LVAL k_prefix;
extern LVAL k_suffix;

/************************************************************************/
/*- xvol86_Create_Plane                                             	*/
/************************************************************************/

void*
xvol86_Create_Plane(
    LVAL lv_grl,
    LVAL k_pixelxxx,  /* :pixel-{red|green|blue} &tc */
    int rows,
    int cols,
    LVAL lv_atype    /* lv_xf8v or lv_xflv */
) {
    LVAL lv_shape;

    LVAL lv_xxx;

    int        toProt = 3;
    xlstkcheck(toProt);
    xlsave(   lv_shape );
    xlprotect(lv_grl   );
    xlsave(   lv_xxx   );

    /* Create pixel-xxx array to go in point relation: */
    lv_shape = cons(cvfixnum(cols),     NIL);
    lv_shape = cons(cvfixnum(rows),lv_shape);
    lv_xxx   = xsendmsg1( lv_atype, k_new, lv_shape );

    /* Insert pixel-xxx array in pixel relation: */
    xsendmsg2( lv_grl, k_setarray, k_pixelxxx, lv_xxx );

    xlpopn(toProt);

    /* Locate the actual pixel-buffer within pixel array: */
    return (void*) csry_base( lv_xxx );
}

/************************************************************************/
/*- xvol87_Create_Pixels                                             	*/
/************************************************************************/

LVAL
xvol87_Create_Pixels(
    int rows,
    int cols,
    CSRY_UNSIGNED8 **pixel
) {
    LVAL lv_shape;
    LVAL lv_grl;

    int        toProt = 2;
    xlstkcheck(toProt);
    xlsave(lv_shape );
    xlsave(lv_grl   );

    /* Create our pixel relation: */
    lv_shape = cons(cvfixnum(cols),     NIL);
    lv_shape = cons(cvfixnum(rows),lv_shape);
    lv_grl   = xsendmsg1( lv_xgrl, k_new, lv_shape );

    if (pixel) {
	*pixel   = xvol86_Create_Plane(
	    lv_grl,
	    k_pixelgreen,
	    rows,
	    cols,
	    lv_xf8v
	);
    }

    xlpopn(toProt);

    return lv_grl;
}

/************************************************************************/
/*- xvol8d_Create_Volume                                             	*/
/************************************************************************/

void*
xvol8d_Create_Volume(
    LVAL lv_grl,
    LVAL k_pixelxxx,  /* :intensity &tc */
    int rows,
    int cols,
    int lyrs,
    LVAL lv_atype    /* lv_xf8v or lv_xflv */
) {
    LVAL lv_shape;

    LVAL lv_xxx;

    int        toProt = 3;
    xlstkcheck(toProt);
    xlsave(   lv_shape );
    xlprotect(lv_grl   );
    xlsave(   lv_xxx   );

    /* Create pixel-xxx array to go in point relation: */
    lv_shape = cons(cvfixnum(lyrs),     NIL);
    lv_shape = cons(cvfixnum(cols),lv_shape);
    lv_shape = cons(cvfixnum(rows),lv_shape);
    lv_xxx   = xsendmsg1( lv_atype, k_new, lv_shape );

    /* Insert pixel-xxx array in pixel relation: */
    xsendmsg2( lv_grl, k_setarray, k_pixelxxx, lv_xxx );

    xlpopn(toProt);

    /* Locate the actual pixel-buffer within pixel array: */
    return (void*) csry_base( lv_xxx );
}

/************************************************************************/
/*- xvol88_Create_Voxels                                             	*/
/************************************************************************/

LVAL
xvol88_Create_Voxels(
    int rows,
    int cols,
    int slices,
    CSRY_UNSIGNED16 **g
) {
    LVAL lv_shape;
    LVAL lv_grl;

    LVAL lv_intensity;

    int        toProt = 3;
    xlstkcheck(toProt);
    xlsave(lv_shape     );
    xlsave(lv_grl       );
    xlsave(lv_intensity );

    /* Create our pixel relation: */
    lv_shape = cons(cvfixnum(cols  ),     NIL);
    lv_shape = cons(cvfixnum(rows  ),lv_shape);
    lv_shape = cons(cvfixnum(slices),lv_shape);
    lv_grl		= xsendmsg1( lv_xgrl, k_new, lv_shape );

    /* Create :INTENSITY array to go in voxel relation: */
    if (g) {
	*g = (CSRY_UNSIGNED16*) xvol8d_Create_Volume(
	    lv_grl,
	    k_intensity,
	    rows,
	    cols,
	    slices,
	    lv_xf2v
	);
    }
    xlpopn(toProt);

    return lv_grl;
}

/************************************************************************/
/*- xvol8b_Init_Map -- Fill in 12->8 bit translation map.		*/
/************************************************************************/

int  xvol8c_lo_lim =  -1;
int  xvol89_hi_lim =  -1;
unsigned xvol8a_map[4096];	/* Int is likely faster than char */
void
xvol8b_Init_Map(
    int lo,
    int hi
) {
    /* Sanify selected range: */
    if (lo <  0x0000)  lo = 0x0000;
    if (hi >  0x1000)  hi = 0x1000;
    if (lo >= hi-1  )  lo = 0x0000;
    if (hi <= lo    )  hi = 0x1000;

    /* Skip work if no change: */
    if (xvol8c_lo_lim != lo
    ||  xvol89_hi_lim != hi
    ){
        xvol8c_lo_lim  = lo;
        xvol89_hi_lim  = hi;
    } else {
	return;
    }

    /* Set up translation table from 12 bits down to 8: */
    {   int   i     = 4095;
	float scale = 256.0 / (hi - lo);
	for (;  i >= hi;  i--) xvol8a_map[i] = 255;
	for (;  i >= lo;  i--) xvol8a_map[i] = (int)((i-lo)*scale);
	for (;  i >=  0;  i--) xvol8a_map[i] =   0;
    }
}

/************************************************************************/
/*- xvol93_Checksum -- Checksum a range of memory.			*/
/************************************************************************/

int
xvol93_Checksum(
    unsigned char*p,
    int count
) {
    int    sum = 0;
    while (count --> 0)   sum += *p++;
    return sum;
}

/************************************************************************/
/*- xvol94_Get_X_And_Y_Dimensions					*/
/************************************************************************/

int
xvol94_Check_X_And_Y_Dimensions(
   LVAL lv,
   int  px,
   int  py,
   int  pz
) {
    csry_rec* h = (csry_rec*) gobjimmbase( lv );
    if (!pz) {
	if (h->rank != 2)     return FALSE;
	if (py != h->dim[0])  return FALSE;
	if (px != h->dim[1])  return FALSE;
    } else {
	if (h->rank != 3)     return FALSE;
	if (pz != h->dim[0])  return FALSE;
	if (py != h->dim[1])  return FALSE;
	if (px != h->dim[2])  return FALSE;
    }
    return TRUE;
}

/************************************************************************/
/*- xvol95_Get_X_Y_Z_Dimensions						*/
/************************************************************************/

void
xvol95_Get_X_Y_Z_Dimensions(
   int* px,	/* This is the one consecutive in memory. */
   int* py,
   int* pz,
   LVAL lv
) {
    csry_rec* h = (csry_rec*) gobjimmbase( lv );
    if (h->rank != 3)  xlerror("Voxel array not 3-D!",lv);
    *pz = h->dim[0];
    *py = h->dim[1];
    *px = h->dim[2];
}

/************************************************************************/
/*- xvolcz_Get_Voxel_Slice_Fn -- Load image from voxel-grl slice.	*/
/************************************************************************/

 /***********************************************************************/
 /*- xvolca_Axis0 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvolca_Axis0(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pixel,
    int              x_dim,
    int              y_dim,
    int              z_dim,
    int              slice
) {
    /* Grab slice in which slowest-varying */
    /* index is constant:                  */
    #ifdef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    for         (k = slice;   k < slice+1;   ++k) {
	for     (j = 0;       j < y_dim;     ++j) {
	    for (i = 0;       i < x_dim;     ++i) {
		int o = i + j*x_dim + k*x_dim*y_dim;/* offset */
		pixel[i+x_dim*j] = xvol8a_map[ 0xFFF & voxel[o] ];
    }   }   }

    #else

    register CSRY_UNSIGNED16* v = voxel;
    register CSRY_UNSIGNED8*  p = pixel;
    register int              i = x_dim * y_dim;
    v += i * slice;
    while (i > 8) {
	p[0] = xvol8a_map[ 0xFFF & v[0] ];
	p[1] = xvol8a_map[ 0xFFF & v[1] ];
	p[2] = xvol8a_map[ 0xFFF & v[2] ];
	p[3] = xvol8a_map[ 0xFFF & v[3] ];
	p[4] = xvol8a_map[ 0xFFF & v[4] ];
	p[5] = xvol8a_map[ 0xFFF & v[5] ];
	p[6] = xvol8a_map[ 0xFFF & v[6] ];
	p[7] = xvol8a_map[ 0xFFF & v[7] ];
	p   += 8;
	v   += 8;
	i   -= 8;
    }
    while (i --> 0)   *p++ = xvol8a_map[ 0xFFF & *v++ ];

    #endif
}

 /***********************************************************************/
 /*- xvolcb_Axis1 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvolcb_Axis1(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pixel,
    int              x_dim,
    int              y_dim,
    int              z_dim,
    int              slice
) {
    /* Grab slice in which slowest-varying */
    /* index is constant:                  */
    #ifdef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    for         (k = 0;       k < z_dim;     ++k) {
	for     (j = slice;   j < slice+1;   ++j) {
	    for (i = 0;       i < x_dim;     ++i) {
		int o = i + j*x_dim + k*x_dim*y_dim;/* offset */
		pixel[i+x_dim*k] = xvol8a_map[ 0xFFF & voxel[o] ];
    }   }   }

    #else

    register CSRY_UNSIGNED16* v = voxel;
    register CSRY_UNSIGNED8*  p = pixel;
    register int              i;
    register int              k;
    v += x_dim*slice;
    for     (k = z_dim;     k --> 0; ) {
	i = x_dim;
	while (i > 8) {
	    p[0] = xvol8a_map[ 0xFFF & v[0] ];
	    p[1] = xvol8a_map[ 0xFFF & v[1] ];
	    p[2] = xvol8a_map[ 0xFFF & v[2] ];
	    p[3] = xvol8a_map[ 0xFFF & v[3] ];
	    p[4] = xvol8a_map[ 0xFFF & v[4] ];
	    p[5] = xvol8a_map[ 0xFFF & v[5] ];
	    p[6] = xvol8a_map[ 0xFFF & v[6] ];
	    p[7] = xvol8a_map[ 0xFFF & v[7] ];
	    p   += 8;
	    v   += 8;
	    i   -= 8;
	}
	while (i --> 0) {
	    *p++ = xvol8a_map[ 0xFFF & *v++ ];
	}
	v += x_dim*(y_dim-1);
    }

    #endif
}

 /***********************************************************************/
 /*- xvolcc_Axis2 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvolcc_Axis2(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pixel,
    int              x_dim,
    int              y_dim,
    int              z_dim,
    int              slice
) {
    /* Grab slice in which fastest-varying */
    /* index is constant:                  */
    #ifdef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    for         (k = 0;       k < z_dim;     ++k) {
	for     (j = 0;       j < y_dim;     ++j) {
	    for (i = slice;   i < slice+1;   ++i) {
		int o = i + j*x_dim + k*x_dim*y_dim;/* offset */
		pixel[k+j*x_dim] = xvol8a_map[ 0xFFF & voxel[o] ];
    }   }   }

    #else

    register CSRY_UNSIGNED16* v = voxel;
    register CSRY_UNSIGNED8*  p = pixel;
    register int j;
    register int k;
    register int xy = x_dim*y_dim;
    register int o  = slice;
    for     (j = 0;   j < y_dim;   ++j) {
	v = &voxel[ o ];
        for (k = 0;   k < z_dim;   ++k) {
	    *p++ = xvol8a_map[ 0xFFF & *v ];
	    v += xy;
        }
	o += x_dim;
    }

    #endif
}

 /***********************************************************************/
 /*- xvolcd_Double_Image_Size --					*/
 /***********************************************************************/

static void
xvolcd_Double_Image_Size(
    CSRY_UNSIGNED8*  pixel,	/* BETTER BE BIG ENOUGH! */
    int              x_dim,	/* cols. We double this. */
    int              y_dim	/* rows. We double this. */
){
    /* Here we in-place double the size */
    /* of the given pixel image.        */
    register CSRY_UNSIGNED8*  src2;
    register CSRY_UNSIGNED8*  src = pixel + x_dim   * y_dim  ;
    register CSRY_UNSIGNED8*  dst = pixel + x_dim*2 * y_dim*2;
    register unsigned         pix;
    register unsigned         lst;
    register unsigned         col;
    register unsigned         row;

    /* First we fill in the odd lines, interpolating      */
    /* every other pixel as the average of its horizontal */
    /* neighbors:                                         */
    for     (row = y_dim;   row --> 0; ) {
	lst = src[-1];
        for (col = x_dim;   col --> 0; ) {
	    pix = *--src;
	    *--dst = (pix+lst) >> 1;
	    *--dst = pix;
	    lst    = pix;
	}
	dst -= (x_dim<<1);
    }

    /* Now we fill in the even lines, interpolating every */
    /* pixel as the average of its vertical neighbors:    */
    src  = pixel + x_dim*2 * y_dim*2;
    dst  = src   - x_dim*2;
    src2 = dst   - x_dim*2;
    for     (row = y_dim-1;   row --> 0; ) {
        for (col = x_dim*2;   col --> 0; ) {
	    pix = *--src ;
	    lst = *--src2;
	    *--dst = (pix + lst) >> 1;
	}
	src   = dst;
	dst   = src2;
	src2 -= (x_dim<<1);
    }

    /* The very last even line has only one neighbor, */
    /* so we do a simple copy from that neighbor:     */
    for (col = x_dim*2;   col --> 0; ) {
	*--dst = *--src;
    }
}

 /***********************************************************************/
 /*- xvolce_Reverse_X --						*/
 /***********************************************************************/

static void
xvolce_Reverse_X(
    CSRY_UNSIGNED8*  pixel,
    int              x_dim,	/* cols. */
    int              y_dim	/* rows. */
){
    CSRY_UNSIGNED8*  prow = pixel;

    unsigned         col;
    unsigned         row;

    for     (row = y_dim;   row --> 0;   prow += x_dim) {
        register CSRY_UNSIGNED8* lo = prow;
	register CSRY_UNSIGNED8* hi = prow + (x_dim-1);
        for (col = (x_dim >> 1);   col --> 0; ) {
	    register CSRY_UNSIGNED8 b0 = *lo;
	    register CSRY_UNSIGNED8 b1 = *hi;
	    *hi-- = b0;
	    *lo++ = b1;
	}
    }
}

 /***********************************************************************/
 /*- xvolcz_Get_Voxel_Slice_Fn						*/
 /***********************************************************************/

LVAL
xvolcz_Get_Voxel_Slice_Fn(
    void
){
    /* Read filename: */
    LVAL lv_voxels   = NULL;
    LVAL lv_slice    = NULL;
    int     slice    = 0;
    int     x;
    int     y;
    int     z;
    int    reverse_x = FALSE;
    int    lo_lim    =   0;
    int    hi_lim    = 256;
    LVAL   lv_ary    = NULL;
    LVAL   lv_pix    = NULL;	/* Relation holding output pixels.	*/
    LVAL   lv_grn    = NULL;	/* :PIXEL-GREEN array in above.		*/
    int     axis     = 0;
    int     zoom     = 1;
    int    p_rows    = 256;	/* Size of output pixel array.		*/
    int    p_cols    = 256;	/* Size of output pixel array.		*/
    CSRY_UNSIGNED8 *pixel;

    FILE*   fd;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_min) {
	    lo_lim = getfixnum( xlgafixnum() );
	} else if (lv == k_max) {
	    hi_lim = getfixnum( xlgafixnum() );
	} else if (lv == k_result_in) {
	    lv_pix = xlgetarg();
	} else if (lv == k_reverse_x) {
	    reverse_x = (xlgetarg() != NIL);
	} else if (lv == k_voxels) {
	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;
	} else if (lv == k_slice) {
	    lv_slice  = xlgafixnum();
	    slice     = getfixnum( lv_slice );
	} else if (lv == k_axis) {
	    LVAL lv_axis = xlgafixnum();
	    axis = getfixnum(lv_axis);
	    if (axis < 0 || axis > 2) {
		xlerror("Bad XMRI-GET-VOXEL-SLICE :AXIS value",lv_axis);
	    }
	} else if (lv == k_zoom_by) {
	    LVAL lv_zoom = xlgafixnum();
	    zoom = getfixnum(lv_zoom);
	    if (zoom != 1
            &&  zoom != 2
            &&  zoom != 4
            &&  zoom != 8
            &&  zoom != 16
            ){
		xlerror("Bad XMRI-GET-VOXEL-SLICE :ZOOM-BY value",lv_zoom);
	    }
	} else {
	    xlerror("Bad XMRI-GET-VOXEL-SLICE keyword",lv);
    }   }
    if (!lv_voxels) xlfail("XMRI-GET-VOXEL-SLICE: missing :VOXELS keyword");

    /* If lv_ary is a relation, fetch :INTENSITY array: */
    if (xgrlp(lv_ary)) {
	lv_ary = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
    }
    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-GET-VOXEL-SLICE voxel argument.",lv_ary);
    }

    xvol95_Get_X_Y_Z_Dimensions( &x, &y, &z, lv_voxels );

    /* Compute appropriate size for result array: */
    p_rows    = y * zoom;	/* Size of output pixel array.		*/
    p_cols    = x * zoom;	/* Size of output pixel array.		*/

    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-GET-VOXEL-SLICE voxel argument.",lv_ary);
    }
    if (x != z
    ||  y != z
    ){
	xlfail("XMRI-READ-VOXEL-SLICE: Voxel array not cubic!");
    }
    if (slice < 0 || slice >= z) {
	xlerror("XMRI-READ-VOXEL-SLICE: Bad slice#",lv_slice);
    }

    /* Set up mapping from 12 down to 8 bits: */
    xvol8b_Init_Map( lo_lim, hi_lim );

    /* Make sure lv_pix is a graphic relation  */
    /* with an appropriate :PIXEL-GREEN array: */
    if (!      lv_pix
    ||  !xgrlp(lv_pix)
    ||  !(     lv_grn = xgrl3c_Get_Array( lv_pix, k_pixelgreen, NIL, TRUE ))
    ||  !xf8vp(lv_grn)
    ||  !xvol94_Check_X_And_Y_Dimensions( lv_grn, p_cols, p_rows, 0 )
    ){
	/* Create graphic relation to hold result: */
	lv_pix = xvol87_Create_Pixels(
	    p_rows, 	/*rows*/
	    p_cols,	/*cols*/
	    &pixel	/* Returns pointer to actual pixel buf here */
	);
    } else {
	pixel = (CSRY_UNSIGNED8*) csry_base( lv_grn );
    }

    {   /* Get pointer to data area in voxel array: */
	CSRY_UNSIGNED16*voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );

	/* Blast data from voxel to image array.                      */
	/* Branch depending which direction we're extracting a slice: */
	switch (axis) {
	case 0: xvolca_Axis0( voxel, pixel, x,y,z, slice ); break;
	case 1: xvolcb_Axis1( voxel, pixel, x,y,z, slice ); break;
	case 2: xvolcc_Axis2( voxel, pixel, x,y,z, slice ); break;
	default:abort();
	}

	/* Reverse x-ordering of pixels */
        /* in row if so requested:      */
	if (reverse_x) {
printf("xvolcz_Get_Voxel_Slice_Fn: p_cols d=%d p_rows d=%d zoom d=%d\n",p_cols,p_rows,zoom);
	    switch (zoom) {
	    case 16: xvolce_Reverse_X( pixel, p_cols/16, p_rows/16 );	break;
	    case  8: xvolce_Reverse_X( pixel, p_cols/8 , p_rows/8  );	break;
	    case  4: xvolce_Reverse_X( pixel, p_cols/4 , p_rows/4  );	break;
	    case  2: xvolce_Reverse_X( pixel, p_cols/2 , p_rows/2  );	break;
	    case  1: xvolce_Reverse_X( pixel, p_cols/2 , p_rows/2  );	break;
	    default:abort();
	    }
	}

	/* Branch depending which factor we're zooming by:            */
	switch (zoom) {
	case 16: xvolcd_Double_Image_Size( pixel, p_cols/16, p_rows/16 );
	case  8: xvolcd_Double_Image_Size( pixel, p_cols/8 , p_rows/8  );
	case  4: xvolcd_Double_Image_Size( pixel, p_cols/4 , p_rows/4  );
	case  2: xvolcd_Double_Image_Size( pixel, p_cols/2 , p_rows/2  );
	case  1:						   break;
	default:abort();
	}

	/* Return result image: */
	return lv_pix;
    }
}

/************************************************************************/
/*- xvoldz_Render_Fn -- Create monochrome image from voxel-grl.		*/
/************************************************************************/

 /***********************************************************************/
 /*- xvolda_Axis0 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvolda_Axis0(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pixel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int              lo,
    int              hi,

    int              slice,
    int              depth
) {
    /* Build map from depth to brightness: */
    int brightness[ 256 ];
    {   int  i;
	for (i = x_dim;   i --> 0;   ) {
	    if      (i > depth)   brightness[i] =   0;
	    else if (i < slice)   brightness[i] = 255;
	    else {
		float denom = 255.5 / (float)(depth-slice);
		brightness[i] = (int) ((depth-i)*denom);
    }   }   }

    /* Generate an image down the axis of  */
    /* slowest-varying index:              */
    #ifdef LOGICAL_ALGORITHM

    {   int i;
	int j;
	int k;
	for         (j = 0;       j < y_dim;     ++j) {
	    for     (i = 0;       i < x_dim;     ++i) {
		int  p = 0;	/* Value to store in output pixel */
		for (k = slice;   k < z_dim;     ++k) {
		    int o  = i + j*x_dim + k*x_dim*y_dim;/* offset */
		    int v  = 0xFFF & voxel[o];
		    if (v >= lo && v < hi) {
			p  = brightness[k];
			break;
		}   }
		pixel[i+x_dim*j] = p;
    }   }   }

    #else

    {   int i;
	int j;
	int k;
	int     xy = x_dim * y_dim;
	int    sxy = slice * xy;
	unsigned ulo = (unsigned)    lo ;
	unsigned lim = (unsigned)(hi-lo);
	for         (j = 0;       j < y_dim;     ++j) {
	    int jx = j* x_dim;
	    for     (i = 0;       i < x_dim;     ++i) {
		int p   = 0;
		CSRY_UNSIGNED16* v = voxel + i + jx + sxy;
		for (k = slice;   k < z_dim;     ++k) {
		    unsigned u = 0xFFF & *v;
		    if (u-ulo < lim) {
			p = brightness[k];
			break;
		    }
		    v  += xy;
		}
		*pixel++ = p;
    }   }   }

    #endif
}

 /***********************************************************************/
 /*- xvoldb_Axis1 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvoldb_Axis1(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pixel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int              lo,
    int              hi,

    int              slice,
    int              depth
) {
    /* Build map from depth to brightness: */
    int brightness[ 256 ];
    {   int  i;
	for (i = x_dim;   i --> 0;   ) {
	    if      (i > depth)   brightness[i] =   0;
	    else if (i < slice)   brightness[i] = 255;
	    else {
		float denom = 255.5 / (float)(depth-slice);
		brightness[i] = (int) ((depth-i)*denom);
    }   }   }

    /* Generate an image down the axis of  */
    /* medium-varying index:               */
    #ifdef LOGICAL_ALGORITHM

    {   int i;
	int j;
	int k;
	for         (k = 0;       k < z_dim;     ++k) {
	    for     (i = 0;       i < x_dim;     ++i) {
		int  p = 0;	/* Value to store in output pixel */
		for (j = slice;   j < y_dim;     ++j) {
		    int o  = i + j*x_dim + k*x_dim*y_dim;/* offset */
		    int v  = 0xFFF & voxel[o];
		    if (v >= lo && v < hi) {
			p  = brightness[j];
			break;
		}   }
		pixel[i+x_dim*k] = p;
    }   }   }

    #else

    {   int i;
	int j;
	int k;
	int     xy = x_dim * y_dim;
	int    sx  = slice * x_dim;
	unsigned ulo = (unsigned)    lo ;
	unsigned lim = (unsigned)(hi-lo);
	for         (k = 0;       k < z_dim;     ++k) {
	    int kxy = k * xy;
	    int kx  = k * x_dim;
	    for     (i = 0;       i < x_dim;     ++i) {
		int  p = 0;	/* Value to store in output pixel */
		int  i_jx_kxy = i+sx+kxy;
		for (j = slice;   j < y_dim;     ++j) {
		    CSRY_UNSIGNED16* v = voxel + i_jx_kxy;
		    unsigned u = 0xFFF & *v;
		    if (u-ulo < lim) {
			p  = brightness[j];
			break;
		    }
		    i_jx_kxy += x_dim;
		}
		pixel[i+kx] = p;
    }   }   }


    #endif
}

 /***********************************************************************/
 /*- xvoldc_Axis2 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvoldc_Axis2(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pixel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int              lo,
    int              hi,

    int              slice,
    int              depth
) {
    /* Build map from depth to brightness: */
    int brightness[ 256 ];
    {   int  i;
	for (i = x_dim;   i --> 0;   ) {
	    if      (i > depth)   brightness[i] =   0;
	    else if (i < slice)   brightness[i] = 255;
	    else {
		float denom = 255.5 / (float)(depth-slice);
		brightness[i] = (int) ((depth-i)*denom);
    }   }   }

    /* Generate an image down the axis of  */
    /* fastest-varying index:               */
    #ifdef LOGICAL_ALGORITHM

    {   int i;
	int j;
	int k;
	for         (k = 0;       k < z_dim;     ++k) {
	    for     (j = 0;       j < y_dim;     ++j) {
		int  p = 0;	/* Value to store in output pixel */
		for (i = slice;   i < x_dim;     ++i) {
		    int o  = i + j*x_dim + k*x_dim*y_dim;/* offset */
		    int v  = 0xFFF & voxel[o];
		    if (v >= lo && v < hi) {
			p  = brightness[i];
			break;
		}   }
		pixel[k+z_dim*j] = p;
    }   }   }

    #else

    {   int i;
	int j;
	int k;
	unsigned ulo = (unsigned)    lo ;
	unsigned lim = (unsigned)(hi-lo);
	int     xy = x_dim * y_dim;
	for         (k = 0;       k < z_dim;     ++k) {
	    int kxy = k * xy;
	    for     (j = 0;       j < y_dim;     ++j) {
		CSRY_UNSIGNED16* v = voxel + j*x_dim + kxy;
		int  p = 0;	/* Value to store in output pixel */
		for (i = slice;   i < x_dim;     ++i) {
		    unsigned u = 0xFFF & v[i];
		    if (u-ulo < lim) {
			p  = brightness[i];
			break;
		}   }
		pixel[k+z_dim*j] = p;
    }   }   }

    #endif
}

 /***********************************************************************/
 /*- xvoldz_Render_Fn							*/
 /***********************************************************************/

LVAL
xvoldz_Render_Fn(
    void
){
    LVAL lv_voxels   = NULL;
    LVAL lv_slice    = NULL;
    int     slice    = 0;
    int     x;
    int     y;
    int     z;
    int    lo        =   0;
    int    hi        = 256;
    int    depth     = 512;
    LVAL   lv_ary    = NULL;
    LVAL   lv_pix    = NULL;	/* Relation holding output pixels.	*/
    LVAL   lv_grn    = NULL;	/* :PIXEL-GREEN array in above.		*/
    int     axis     = 0;
    int     zoom     = 1;
    int    p_rows    = 256;	/* Size of output pixel array.		*/
    int    p_cols    = 256;	/* Size of output pixel array.		*/
    CSRY_UNSIGNED8 *pixel;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_min) {
	    lo = getfixnum( xlgafixnum() );

	} else if (lv == k_max) {
	    hi = getfixnum( xlgafixnum() );

	} else if (lv == k_voxels) {
	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;

	} else if (lv == k_result_in) {
	    lv_pix = xlgetarg();

	} else if (lv == k_slice) {
	    lv_slice  = xlgafixnum();
	    slice     = getfixnum( lv_slice );

	} else if (lv == k_depth) {
	    depth     = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (lv == k_axis) {
	    LVAL lv_axis = xlgafixnum();
	    axis = getfixnum(lv_axis);
	    if (axis < 0 || axis > 2) {
		xlerror("Bad XMRI-RENDER :AXIS value",lv_axis);
	    }

	} else if (lv == k_zoom_by) {
	    LVAL lv_zoom = xlgafixnum();
	    zoom = getfixnum(lv_zoom);
	    if (zoom !=  1
            &&  zoom !=  2
            &&  zoom !=  4
            &&  zoom !=  8
            &&  zoom != 16
            ){
		xlerror("Bad XMRI-RENDER :ZOOM-BY value",lv_zoom);
	    }
	} else {
	    xlerror("Bad XMRI-RENDER keyword",lv);
    }   }
    if (!lv_voxels) xlfail("XMRI-RENDER: missing :VOXELS keyword");

    /* If lv_ary is a relation, fetch :INTENSITY array: */
    if (xgrlp(lv_ary)) {
	lv_ary = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
    }
    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-RENDER voxel argument.",lv_ary);
    }

    xvol95_Get_X_Y_Z_Dimensions( &x, &y, &z, lv_voxels );

    /* Compute appropriate size for result array: */
    p_rows    = y * zoom;	/* Size of output pixel array.		*/
    p_cols    = x * zoom;	/* Size of output pixel array.		*/

    if (x != z
    ||  y != z
    ){
	xlfail("XMRI-RENDER: Voxel array not cubic!");
    }
    if (x != 128 && x != 256){
	xlfail("XMRI-RENDER: Currently only 128^3 & 256^3 voxel arrays handled.");
    }
    if (slice < 0 || slice >= z) {
	xlerror("XMRI-RENDER: Bad slice#",lv_slice);
    }

    if (depth < 1)   depth = 1;
    depth    += slice;
    if (depth > x)   depth = x;


    /* Make sure lv_pix is a graphic relation  */
    /* with an appropriate :PIXEL-GREEN array: */
    if (!      lv_pix
    ||  !xgrlp(lv_pix)
    ||  !(     lv_grn = xgrl3c_Get_Array( lv_pix, k_pixelgreen, NIL, TRUE ))
    ||  !xf8vp(lv_grn)
    ||  !xvol94_Check_X_And_Y_Dimensions( lv_grn, p_cols, p_rows, 0 )
    ){
	/* Create graphic relation to hold result: */
	lv_pix = xvol87_Create_Pixels(
	    p_rows, 	/*rows*/
	    p_cols,	/*cols*/
	    &pixel	/* Returns pointer to actual pixel buf here */
	);
    } else {
	pixel = (CSRY_UNSIGNED8*) csry_base( lv_grn );
    }

    {   /* Get pointer to data area in voxel array: */
	CSRY_UNSIGNED16*voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );

	/* Blast data from voxel to image array.                      */
	/* Branch depending which direction we're extracting a slice: */
	switch (axis) {
	case 0: xvolda_Axis0( voxel, pixel, x,y,z, lo,hi, slice,depth ); break;
	case 1: xvoldb_Axis1( voxel, pixel, x,y,z, lo,hi, slice,depth ); break;
	case 2: xvoldc_Axis2( voxel, pixel, x,y,z, lo,hi, slice,depth ); break;
	default:abort();
	}

	/* Branch depending which factor we're zooming by:            */
	switch (zoom) {
	case 16: xvolcd_Double_Image_Size( pixel, p_cols/16, p_rows/16 );
	case  8: xvolcd_Double_Image_Size( pixel, p_cols/8 , p_rows/8  );
	case  4: xvolcd_Double_Image_Size( pixel, p_cols/4 , p_rows/4  );
	case  2: xvolcd_Double_Image_Size( pixel, p_cols/2 , p_rows/2  );
	case  1:						   break;
	default:abort();
	}

	/* Return result image: */
	return lv_pix;
    }
}

/************************************************************************/
/*- xvoliz_Render_Max_Intensity_Fn -- Create grey image from voxel-grl.	*/
/************************************************************************/

 /***********************************************************************/
 /*- xvolia_Axis0 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvolia_Axis0(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pixel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int              lo,
    int              hi,

    int              slice,
    int              depth
) {
    /* Build map from voxel values to brightness: */
    xvol8b_Init_Map( lo, hi );

    /* Generate an image down the axis of  */
    /* slowest-varying index:              */
    #ifdef LOGICAL_ALGORITHM

    {   int i;
	int j;
	int k;
	for         (j = 0;       j < y_dim;     ++j) {
	    for     (i = 0;       i < x_dim;     ++i) {
		int  p = 0;	/* Value to store in output pixel */
		for (k = slice;   k < depth;     ++k) {
		    int o  = i + j*x_dim + k*x_dim*y_dim;/* offset */
		    int v  = 0xFFF & voxel[o];
		    if (p < v) p = v;
		}
		pixel[i+x_dim*j] = xvol8a_map[p];
    }   }   }

    #else

    {   int i;
	int j;
	int k;
	int     xy = x_dim * y_dim;
	int    sxy = slice * xy;
	int lim = slice+depth < z_dim ? slice+depth : z_dim;
	for         (j = 0;       j < y_dim;     ++j) {
	    int jx = j* x_dim;
	    for     (i = 0;       i < x_dim;     ++i) {
		unsigned p = 0;
		CSRY_UNSIGNED16* v = voxel + i + jx + sxy;
		for (k = slice;   k < depth;     ++k) {
		    unsigned u = 0xFFF & *v;
		    if (p < u) p = u;
		    v  += xy;
		}
		*pixel++ = xvol8a_map[p];
    }   }   }

    #endif
}

 /***********************************************************************/
 /*- xvolib_Axis1 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvolib_Axis1(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pixel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int              lo,
    int              hi,

    int              slice,
    int              depth
) {
    /* Build map from voxel values to brightness: */
    xvol8b_Init_Map( lo, hi );

    /* Generate an image down the axis of  */
    /* medium-varying index:               */
    #ifdef LOGICAL_ALGORITHM

    {   int i;
	int j;
	int k;
	for         (k = 0;       k < z_dim;     ++k) {
	    for     (i = 0;       i < x_dim;     ++i) {
		int  p = 0;	/* Value to store in output pixel */
		for (j = slice;   j < depth;     ++j) {
		    int o  = i + j*x_dim + k*x_dim*y_dim;/* offset */
		    int v  = 0xFFF & voxel[o];
		    if (p < v) p = v;
		}
		pixel[i+x_dim*k] = xvol8a_map[p];
    }   }   }

    #else

    {   int i;
	int j;
	int k;
	int     xy = x_dim * y_dim;
	int    sx  = slice * x_dim;
	int lim = slice+depth < y_dim ? slice+depth : y_dim;
	for         (k = 0;       k < z_dim;     ++k) {
	    int kxy = k * xy;
	    int kx  = k * x_dim;
	    for     (i = 0;       i < x_dim;     ++i) {
		unsigned p = 0;	/* Value to store in output pixel */
		int  i_jx_kxy = i+sx+kxy;
		for (j = slice;   j < depth;     ++j) {
		    CSRY_UNSIGNED16* v = voxel + i_jx_kxy;
		    unsigned u = 0xFFF & *v;
		    if (p < u)   p = u;
		    i_jx_kxy += x_dim;
		}
		pixel[i+kx] = xvol8a_map[p];
    }   }   }


    #endif
}

 /***********************************************************************/
 /*- xvolic_Axis2 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvolic_Axis2(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pixel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int              lo,
    int              hi,

    int              slice,
    int              depth
) {
    /* Build map from voxel values to brightness: */
    xvol8b_Init_Map( lo, hi );

    /* Generate an image down the axis of  */
    /* fastest-varying index:               */
    #ifdef LOGICAL_ALGORITHM

    {   int i;
	int j;
	int k;
	for         (k = 0;       k < z_dim;     ++k) {
	    for     (j = 0;       j < y_dim;     ++j) {
		int  p = 0;	/* Value to store in output pixel */
		for (i = slice;   i < depth;     ++i) {
		    int o  = i + j*x_dim + k*x_dim*y_dim;/* offset */
		    int v  = 0xFFF & voxel[o];
		    if (p < v) p = v;
		}
		pixel[k+z_dim*j] = xvol8a_map[p];
    }   }   }

    #else

    {   int i;
	int j;
	int k;
	int     xy = x_dim * y_dim;
	for         (k = 0;       k < z_dim;     ++k) {
	    int kxy = k * xy;
	    for     (j = 0;       j < y_dim;     ++j) {
		CSRY_UNSIGNED16* v = voxel + j*x_dim + kxy;
		unsigned p = 0;	/* Value to store in output pixel */
		for (i = slice;   i < depth;     ++i) {
		    unsigned u = 0xFFF & v[i];
		    if (p < u) p = u;
		}
		pixel[k+z_dim*j] = xvol8a_map[p];
    }   }   }

    #endif
}

 /***********************************************************************/
 /*- xvoliz_Render_Max_Intensity_Fn					*/
 /***********************************************************************/

LVAL
xvoliz_Render_Max_Intensity_Fn(
    void
){
    LVAL lv_voxels   = NULL;
    LVAL lv_slice    = NULL;
    int     slice    = 0;
    int     x;
    int     y;
    int     z;
    int    lo        =   0;
    int    hi        = 256;
    int    depth     = 512;
    LVAL   lv_ary    = NULL;
    LVAL   lv_pix    = NULL;	/* Relation holding output pixels.	*/
    LVAL   lv_grn    = NULL;	/* :PIXEL-GREEN array in above.		*/
    int     axis     = 0;
    int     zoom     = 1;
    int    p_rows    = 256;	/* Size of output pixel array.		*/
    int    p_cols    = 256;	/* Size of output pixel array.		*/
    CSRY_UNSIGNED8 *pixel;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_min) {
	    lo = getfixnum( xlgafixnum() );

	} else if (lv == k_max) {
	    hi = getfixnum( xlgafixnum() );

	} else if (lv == k_voxels) {
	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;

	} else if (lv == k_result_in) {
	    lv_pix = xlgetarg();

	} else if (lv == k_slice) {
	    lv_slice  = xlgafixnum();
	    slice     = getfixnum( lv_slice );

	} else if (lv == k_depth) {
	    depth     = xgbj00_Get_Fix_Or_Flo_Num( xlgetarg() );

	} else if (lv == k_axis) {
	    LVAL lv_axis = xlgafixnum();
	    axis = getfixnum(lv_axis);
	    if (axis < 0 || axis > 2) {
		xlerror("Bad XMRI-RENDER-MAX-INTENSITY :AXIS value",lv_axis);
	    }

	} else if (lv == k_zoom_by) {
	    LVAL lv_zoom = xlgafixnum();
	    zoom = getfixnum(lv_zoom);
	    if (zoom !=  1
            &&  zoom !=  2
            &&  zoom !=  4
            &&  zoom !=  8
            &&  zoom != 16
            ){
		xlerror("Bad XMRI-RENDER-MAX-INTENSITY :ZOOM-BY value",lv_zoom);
	    }
	} else {
	    xlerror("Bad XMRI-RENDER-MAX-INTENSITY keyword",lv);
    }   }
    if (!lv_voxels) xlfail("XMRI-RENDER-MAX-INTENSITY: missing :VOXELS keyword");

    /* If lv_ary is a relation, fetch :INTENSITY array: */
    if (xgrlp(lv_ary)) {
	lv_ary = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
    }
    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-RENDER-MAX-INTENSITY voxel argument.",lv_ary);
    }

    xvol95_Get_X_Y_Z_Dimensions( &x, &y, &z, lv_voxels );

    /* Compute appropriate size for result array: */
    p_rows    = y * zoom;	/* Size of output pixel array.		*/
    p_cols    = x * zoom;	/* Size of output pixel array.		*/

    if (x != z
    ||  y != z
    ){
	xlfail("XMRI-RENDER-MAX-INTENSITY: Voxel array not cubic!");
    }
    if (x != 128 && x != 256){
	xlfail("XMRI-RENDER-MAX-INTENSITY: Currently only 128^3 & 256^3 voxel arrays handled.");
    }
    if (slice < 0 || slice >= z) {
	xlerror("XMRI-RENDER-MAX-INTENSITY: Bad slice#",lv_slice);
    }

    if (depth < 1)   depth = 1;
    depth    += slice;
    if (depth > x)   depth = x;


    /* Make sure lv_pix is a graphic relation  */
    /* with an appropriate :PIXEL-GREEN array: */
    if (!      lv_pix
    ||  !xgrlp(lv_pix)
    ||  !(     lv_grn = xgrl3c_Get_Array( lv_pix, k_pixelgreen, NIL, TRUE ))
    ||  !xf8vp(lv_grn)
    ||  !xvol94_Check_X_And_Y_Dimensions( lv_grn, p_cols, p_rows, 0 )
    ){
	/* Create graphic relation to hold result: */
	lv_pix = xvol87_Create_Pixels(
	    p_rows, 	/*rows*/
	    p_cols,	/*cols*/
	    &pixel	/* Returns pointer to actual pixel buf here */
	);
    } else {
	pixel = (CSRY_UNSIGNED8*) csry_base( lv_grn );
    }

    {   /* Get pointer to data area in voxel array: */
	CSRY_UNSIGNED16*voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );

	/* Blast data from voxel to image array.                      */
	/* Branch depending which direction we're extracting a slice: */
	switch (axis) {
	case 0: xvolia_Axis0( voxel, pixel, x,y,z, lo,hi, slice,depth ); break;
	case 1: xvolib_Axis1( voxel, pixel, x,y,z, lo,hi, slice,depth ); break;
	case 2: xvolic_Axis2( voxel, pixel, x,y,z, lo,hi, slice,depth ); break;
	default:abort();
	}

	/* Branch depending which factor we're zooming by:            */
	switch (zoom) {
	case 16: xvolcd_Double_Image_Size( pixel, p_cols/16, p_rows/16 );
	case  8: xvolcd_Double_Image_Size( pixel, p_cols/8 , p_rows/8  );
	case  4: xvolcd_Double_Image_Size( pixel, p_cols/4 , p_rows/4  );
	case  2: xvolcd_Double_Image_Size( pixel, p_cols/2 , p_rows/2  );
	case  1:						   break;
	default:abort();
	}

	/* Return result image: */
	return lv_pix;
    }
}

/************************************************************************/
/*- xvole4_Fill_Histogram_Fn -- Compute voxel histogram.		*/
/************************************************************************/

 /***********************************************************************/
 /*- xvole2_Create_Points                                             	*/
 /***********************************************************************/

LVAL
xvole2_Create_Points( len,  g )
int                   len;
float                     **g;
{   LVAL lv_shape;
    LVAL lv_grl;

    LVAL lv_x;
    LVAL lv_y;
    LVAL lv_z;

    int        toProt = 5;
    xlstkcheck(toProt);
    xlsave(lv_shape );
    xlsave(lv_grl   );
    xlsave(lv_x     );
    xlsave(lv_y     );
    xlsave(lv_z     );

    /* Create our pixel relation: */
    lv_shape = cons(cvfixnum(len),     NIL);
    lv_grl		= xsendmsg1( lv_xgrl, k_new, lv_shape );

    /* Create point-x/y/z arrays to go in point relation: */
    lv_x	= xsendmsg1( lv_xflv, k_new, lv_shape );
    lv_y	= xsendmsg1( lv_xflv, k_new, lv_shape );
    lv_z	= xsendmsg1( lv_xflv, k_new, lv_shape );

    /* Insert point arrays in pixel relation: */
    xsendmsg2( lv_grl, k_setarray, k_pointx, lv_x );
    xsendmsg2( lv_grl, k_setarray, k_pointy, lv_y );
    xsendmsg2( lv_grl, k_setarray, k_pointz, lv_z );

    /* Locate the actual pixel-buffer within pointy array: */
    *g     = (float*) csry_base( lv_y );

    xlpopn(toProt);

    return lv_grl;
}

 /***********************************************************************/
 /*- xvole3_Check_Dimension						*/
 /***********************************************************************/

static int
xvole3_Check_Dimension(
   LVAL lv,
   int  len
) {
    csry_rec* h = (csry_rec*) gobjimmbase( lv );
    if (h->rank != 1)     return FALSE;
    if (h->dim[0] < len)  return FALSE;
    return TRUE;
}

 /***********************************************************************/
 /*- xvole4_Fill_Histogram_Fn						*/
 /***********************************************************************/

LVAL
xvole4_Fill_Histogram_Fn(
    void
){
    /* Read filename: */
    LVAL lv_voxels   = NULL;
    int     x;
    int     y;
    int     z;
    int    lo        = 0x0000;
    int    hi        = 0x1000;
    LVAL   lv_ary    = NULL;
    LVAL   lv_bin    = NULL;	/* Relation holding output pixels.	*/
    LVAL   lv_y      = NULL;	/* :POINT-Y array in above.		*/
    int    binshift  = 4;
    int    p_bins    = 256;	/* Size of output array.		*/
    int    hist[4097];		/* Holds histogram during computation.	*/
    int    bin[4096];		/* Maps voxel values to histogram slots.*/
    float* bins;		/* Output pointer.			*/

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_min) {
	    lo = getfixnum( xlgafixnum() );
	} else if (lv == k_max) {
	    hi = getfixnum( xlgafixnum() );
	} else if (lv == k_voxels) {
	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;
	} else if (lv == k_result_in) {
	    lv_bin = xlgetarg();
	} else if (lv == k_bin_size) {
	    LVAL lv_binsize = xlgafixnum();
	    int     binsize = getfixnum(lv_binsize);
	    switch (binsize) {
	    case  1:	binshift = 0;	break;
            case  2:	binshift = 1;	break;
            case  4:	binshift = 2;	break;
            case  8:	binshift = 3;	break;
            case 16:	binshift = 4;	break;
            case 32:	binshift = 5;	break;
            case 64:	binshift = 6;	break;
	    default:
		xlerror("Bad XMRI-FILL-HISTOGRAM :BIN-SIZE value",lv_binsize);
	    }
	} else {
	    xlerror("Bad XMRI-FILL-HISTOGRAM keyword",lv);
    }   }
    if (!lv_voxels) xlfail("XMRI-FILL-HISTOGRAM: missing :VOXELS keyword");

    /* If lv_ary is a relation, fetch :INTENSITY array: */
    if (xgrlp(lv_ary)) {
	lv_ary = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
    }
    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-RENDER voxel argument.",lv_ary);
    }

    xvol95_Get_X_Y_Z_Dimensions( &x, &y, &z, lv_voxels );

    /* Zero result array: */
    {   int i;
	for (i = 4097;   i --> 0;  )  hist[i] = 0;
    }

    /* Sanify selected voxel value range: */
    if (lo <  0x0000)  lo = 0x0000;
    if (hi >  0x1000)  hi = 0x1000;
    if (lo >= hi-1  )  lo = 0x0000;
    if (hi <= lo    )  hi = 0x1000;

    /* Compute voxel value -> bin mapping: */
    {   int  i;
	for (i = 4096;   i --> 0;   ) {
	    if      (i <  lo)   bin[i] = 4096;
	    else if (i >= hi)   bin[i] = 4096;
	    else                bin[i] = (i-lo) >> binshift;
    }	}

    /* Compute desired histogram: */
    {   register int* h = hist;
	register int* b = bin;
	register CSRY_UNSIGNED16*v = (
	    (CSRY_UNSIGNED16*) csry_base( lv_ary )	/* Voxels */
	);
	int i = x * y * z;
#ifdef SOON
	while (i > 8) {
	    ++(h[ b[ v[0] & 0xfff ] ]);
	    ++(h[ b[ v[1] & 0xfff ] ]);
	    ++(h[ b[ v[2] & 0xfff ] ]);
	    ++(h[ b[ v[3] & 0xfff ] ]);
	    ++(h[ b[ v[4] & 0xfff ] ]);
	    ++(h[ b[ v[5] & 0xfff ] ]);
	    ++(h[ b[ v[6] & 0xfff ] ]);
	    ++(h[ b[ v[7] & 0xfff ] ]);
	    i -= 8;
	    v += 8;
	}
	while (i --> 0)   ++(h[ b[ *v++ & 0xfff ] ]);
#else
	while (i --> 0) {
	    int val = *v;
	    int* p  = h+val;
	    ++(*p);
v += 1;
        }
#endif
    }

    /* Compute appropriate size for result array: */
#ifdef SOON
    p_bins    = (0x1000-lo) >> binshift;
#else
    p_bins    =  0x100;
#endif

    /* Make sure lv_bin is a graphic relation  */
    /* with an appropriate :POINT-Y array:     */
    if (!      lv_bin
    ||  !xgrlp(lv_bin)
    ||  !(     lv_y   = xgrl3c_Get_Array( lv_bin, k_pointy, NIL, TRUE ))
    ||  !xflvp(lv_y)
    ||  !xvole3_Check_Dimension( lv_y, p_bins )
    ){
	/* Create graphic relation to hold result: */
	lv_bin = xvole2_Create_Points( p_bins, &bins );
    } else {
	bins = (float*) csry_base( lv_y );
    }

    /* Copy result bins into result relation: */
    {   int i;
	for (i = 0;   i < p_bins;   ++i) {
#ifdef SERIOUS
	    bins[i] = (float) hist[i];
#else
	    bins[i] = (float) hist[i +1];
#endif
    }	}

    /* Return result relation: */
    return lv_bin;
}

/************************************************************************/
/*- xvole8_Build_Rendering_Relation_Fn --				*/
/************************************************************************/

 /***********************************************************************/
 /*- xvole5_range -- struct holding info on one range.			*/
 /***********************************************************************/

struct xvole5_rec {
   float diffuse_red;
   float diffuse_green;
   float diffuse_blue;
   float alpha;
   int   vox_min;
   int   vox_max;
};
typedef struct xvole5_rec Xmri_a_range;
typedef struct xvole5_rec*  Xmri_range;

 /***********************************************************************/
 /*- xvole6_parse_range -- Fill struct holding info on one range.	*/
 /***********************************************************************/

static void
xvole6_parse_range(
    Xmri_range r,	/* result goes here */
    LVAL       lv	/* list to parse    */
){
    r->diffuse_red   =  0.0;
    r->diffuse_green =  1.0;
    r->diffuse_blue  =  1.0;
    r->alpha         =  1.0;
    r->vox_min       =   16;
    r->vox_max       =   64;

    for (;   consp(lv);   lv = cdr(lv)) {
	LVAL lv_key = car(lv);
	LVAL lv_val;
	if        (lv_key == k_min) {
	    lv = cdr(lv);
	    if (!consp(lv)
	    || !(lv_val = car(lv))
	    || (!fixp(lv_val) && (!symbolp(lv_val) || !fixp(getvalue(lv_val))))
	    ){
		xlfail("XMRI-BUILD-RENDERING-RELATION: bad :MIN val.");
	    } else {
		if (symbolp(lv_val)) lv_val = getvalue(lv_val);
		r->vox_min = getfixnum( lv_val );
	    }
	} else if (lv_key == k_max) {
	    lv = cdr(lv);
	    if (!consp(lv)
	    || !(lv_val = car(lv))
	    || (!fixp(lv_val) && (!symbolp(lv_val) || !fixp(getvalue(lv_val))))
	    ){
		xlfail("XMRI-BUILD-RENDERING-RELATION: bad :MAX val.");
	    } else {
		if (symbolp(lv_val)) lv_val = getvalue(lv_val);
		r->vox_max = getfixnum( lv_val );
	    }
	    r->vox_max = getfixnum( lv_val );
	} else if (lv_key == k_material) {
	    lv = cdr(lv);
	    if (!consp(lv)
	    || !(lv_val = car(lv))
	    || (!xmtlp(lv_val) && (!symbolp(lv_val) || !xmtlp(getvalue(lv_val))))
	    ){
		xlerror("XMRI-BUILD-RENDERING-RELATION: bad :MATERIAL",lv_val);
	    } else {
		if (symbolp(lv_val)) lv_val = getvalue(lv_val);
		{    gt_material_rec * p = xmtl04_Get_Material_Rec( lv_val );
		    r->alpha         = p->alpha;
		    r->diffuse_red   = p->diffuse_color.r;
		    r->diffuse_green = p->diffuse_color.g;
		    r->diffuse_blue  = p->diffuse_color.b;
	    }   }
	} else {
	    xlerror("XMRI-BUILD-RENDERING-RELATION: bad :RANGE key",lv_key);
	}
    }
}

 /***********************************************************************/
 /*- xvole7_Create_Rendering_Relation					*/
 /***********************************************************************/

LVAL
xvole7_Create_Rendering_Relation(
    int len
) {
    LVAL lv_shape;
    LVAL lv_grl;

    LVAL lv_red;
    LVAL lv_grn;
    LVAL lv_blu;
    LVAL lv_alf;

    int        toProt = 6;
    xlstkcheck(toProt);
    xlsave(lv_shape );
    xlsave(lv_grl   );
    xlsave(lv_red   );
    xlsave(lv_grn   );
    xlsave(lv_blu   );
    xlsave(lv_alf   );

    /* Create our pixel relation: */
    lv_shape = cons(cvfixnum(len),     NIL);
    lv_grl		= xsendmsg1( lv_xgrl, k_new, lv_shape );

    /* Create point-x/y/z arrays to go in point relation: */
    lv_red	= xsendmsg1( lv_xflv, k_new, lv_shape );
    lv_grn	= xsendmsg1( lv_xflv, k_new, lv_shape );
    lv_blu	= xsendmsg1( lv_xflv, k_new, lv_shape );
    lv_alf	= xsendmsg1( lv_xflv, k_new, lv_shape );

    /* Insert arrays into relation: */
    xsendmsg2( lv_grl, k_setarray, k_diffuse_red  , lv_red );
    xsendmsg2( lv_grl, k_setarray, k_diffuse_green, lv_grn );
    xsendmsg2( lv_grl, k_setarray, k_diffuse_blue , lv_blu );
    xsendmsg2( lv_grl, k_setarray, k_alpha        , lv_alf );

    xlpopn(toProt);

    return lv_grl;
}

 /***********************************************************************/
 /*- xvoled_Build_Rendering_Relation_Fn					*/
 /***********************************************************************/

#ifndef XMRI_MAX_RANGES
#define XMRI_MAX_RANGES 32
#endif

LVAL
xvoled_Build_Rendering_Relation_Fn(
    void
){
    Xmri_a_range r[ XMRI_MAX_RANGES ];
    int          ranges = 0;

    LVAL   lv_grl    = NULL;	/* Relation holding output arrays.	*/
    LVAL   lv_red;
    LVAL   lv_grn;
    LVAL   lv_blu;
    LVAL   lv_alf;

    while (moreargs()) {
        LVAL lv_key = xlgasymbol();

	if        (lv_key == k_range) {
	    if (ranges == XMRI_MAX_RANGES) {
		xlerror(
		    "XMRI-BUILD-RENDERING-RELATION: too many :RANGE keys!",
		    cvfixnum(ranges+1)
		);
	    }
	    xvole6_parse_range( &r[ ranges++ ], xlgetarg() );
	} else if (lv_key == k_result_in) {
	    lv_grl = xlgetarg();
	} else {
	    xlerror("XMRI-BUILD-RENDERING-RELATION: bad keyword:",lv_key);
    }   }
    if (!ranges) {
	xlfail("XMRI-BUILD-RENDERING-RELATION: missing :RANGE keyword");
    }

    /* Sanity-check all given ranges: */
    {   int i;
	for (i = 0;   i < ranges;   ++i) {
	    if (r[i].vox_min < 0) {
		xlerror(
		    "XMRI-BUILD-RENDERING-RELATION: :MIN val < 0",
		    cvfixnum(r[i].vox_min)
		);
	    }
	    if (r[i].vox_min > 4096) {
		xlerror(
		    "XMRI-BUILD-RENDERING-RELATION: :MIN val > 4096",
		    cvfixnum(r[i].vox_min)
		);
	    }
	    if (r[i].vox_max < 0) {
		xlerror(
		    "XMRI-BUILD-RENDERING-RELATION: :MAX val < 0",
		    cvfixnum(r[i].vox_max)
		);
	    }
	    if (r[i].vox_max > 4096) {
		xlerror(
		    "XMRI-BUILD-RENDERING-RELATION: :MAX val > 4096",
		    cvfixnum(r[i].vox_max)
		);
	    }
	    if (i > 0   &&   r[i-1].vox_max > r[i].vox_min) {
		xlerror(
		    "XMRI-BUILD-RENDERING-RELATION: "
		    "overlaps preceding range: range #",
		    cvfixnum(i)
		);
	    }
    }   }

    /* Make sure lv_grl is a graphic relation */
    /* with appropriate arrays:               */
    if (!      lv_grl
    ||  !xgrlp(lv_grl)
    ||  !(     lv_red = xgrl3c_Get_Array(lv_grl, k_diffuse_red  , NIL, TRUE))
    ||  !xflvp(lv_red)
    ||  !(     lv_grn = xgrl3c_Get_Array(lv_grl, k_diffuse_green, NIL, TRUE))
    ||  !xflvp(lv_grn)
    ||  !(     lv_blu = xgrl3c_Get_Array(lv_grl, k_diffuse_blue , NIL, TRUE))
    ||  !xflvp(lv_blu)
    ||  !(     lv_alf = xgrl3c_Get_Array(lv_grl, k_alpha        , NIL, TRUE))
    ||  !xflvp(lv_alf)
    ||  !xvole3_Check_Dimension( lv_red, 4096 )
    ||  !xvole3_Check_Dimension( lv_grn, 4096 )
    ||  !xvole3_Check_Dimension( lv_blu, 4096 )
    ||  !xvole3_Check_Dimension( lv_alf, 4096 )
    ){
	/* Create graphic relation to hold result: */
	lv_grl = xvole7_Create_Rendering_Relation( 4096 );
        lv_red = xgrl3c_Get_Array(lv_grl, k_diffuse_red  , NIL, TRUE);
	lv_grn = xgrl3c_Get_Array(lv_grl, k_diffuse_green, NIL, TRUE);
	lv_blu = xgrl3c_Get_Array(lv_grl, k_diffuse_blue , NIL, TRUE);
	lv_alf = xgrl3c_Get_Array(lv_grl, k_alpha        , NIL, TRUE);
    }

    /* Locate the actual float buffers within red/grn/blu/alpha arrays: */
    {   float* red = (float*) csry_base( lv_red );
	float* grn = (float*) csry_base( lv_grn );
	float* blu = (float*) csry_base( lv_blu );
	float* alf = (float*) csry_base( lv_alf );

	/* Fill in output arrays: */

	/* Initialize interval below first range: */
	int  i;
	for (i = 0;   i < r[i].vox_min;   ++i) {
	    red[i] = r[0].diffuse_red;
	    grn[i] = r[0].diffuse_green;
	    blu[i] = r[0].diffuse_blue;
	    alf[i] = r[0].alpha;
        }

	/* Initialize interval specified by each range: */
	for (i = 0;   i < ranges;   ++i) {

	    /* Do range proper: */
	    int  j;
	    for (j = r[i].vox_min;   j < r[i].vox_max;   ++j) {
		red[j] = r[i].diffuse_red;
		grn[j] = r[i].diffuse_green;
		blu[j] = r[i].diffuse_blue;
		alf[j] = r[i].alpha;
	    }

	    /* Do buffer interval between      */
	    /* this range and preceding range: */
	    if (i) {
		int   lo = r[i-1].vox_max -1;	/* Last  slot in last range. */
		int   hi = r[i  ].vox_min   ;	/* First slot in this range. */
		float f  = ((float)(hi-lo));	/* Range of interpolation.   */

		/* Weight due to relative alpha values: */
		float alpha_weight;
		float aw = r[i-1].alpha + r[i].alpha;
		if (aw == 0.0) {
		    alpha_weight = 0.5;
		} else {
		    alpha_weight = r[i].alpha / aw;
		}

		/* Over all voxels in buffer range: */
		for (j = lo+1;   j < hi;   ++j) {

		    /* Weight due to voxel intensity: */
		    float iwt = ((float)(j-lo))/f;	/* "Intensity Weight, This" */
		    float iwl = 1.0 - iwl;		/* "Intensity Weight, Last" */

		    float wt = alpha_weight * iwt;	/* "Weight This" */
		    float wl = 1.0 - wt;		/* "Weight Last" */

		    red[j] =  wl*r[i-1].diffuse_red   +  wt*r[i].diffuse_red;
		    grn[j] =  wl*r[i-1].diffuse_green +  wt*r[i].diffuse_green;
		    blu[j] =  wl*r[i-1].diffuse_blue  +  wt*r[i].diffuse_blue;
		    alf[j] = iwl*r[i-1].alpha         + iwt*r[i].alpha;
	}   }	}

	/* Initialize interval above last range: */
	for (i = r[ranges-1].vox_max;   i < 4096;   ++i) {
	    red[i] = r[ranges-1].diffuse_red;
	    grn[i] = r[ranges-1].diffuse_green;
	    blu[i] = r[ranges-1].diffuse_blue;
	    alf[i] = r[ranges-1].alpha;
    }	}

    /* Return result relation: */
    return lv_grl;
}

/************************************************************************/
/*- xvolfz_Render_In_Color_Fn -- Create color image from voxel-grl.	*/
/************************************************************************/

 /***********************************************************************/
 /*- xvolfa_Axis0 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvolfa_Axis0(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pr,	/* Pixel red plane.	*/
    CSRY_UNSIGNED8*  pg,	/*       grn		*/
    CSRY_UNSIGNED8*  pb,	/*       blu		*/

    int              x_dim,
    int              y_dim,
    int              z_dim,

    float*           red,
    float*           grn,
    float*           blu,
    float*           alf,

    int              slice
) {
    /* Generate an image down the axis of  */
    /* slowest-varying index:              */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy  = x_dim*y_dim;
    for         (j = 0;       j < y_dim;     ++j) {
	int jx  = j*x_dim;
	for     (i = 0;       i < x_dim;     ++i) {
	    float o_red = 0.0;	/* Values to store in output pixel.*/
	    float o_grn = 0.0;	/* "                             " */
	    float o_blu = 0.0;	/* "                             " */
	    float o_alf = 0.0;	/* Accumulated opacity of pixel.   */
    	    for (k = slice;   k < z_dim;     ++k) {
		int o  = i + jx + k*xy;/* offset */

		/* Look up color components for this voxel: */
		int   v    = voxel[ o ];
		float Valf = alf[v];
		if (Valf != 0.0) {

		    /* Compute 'surface normal' for lighting purposes: */
		    float Nx;
		    float Ny;
		    float Nz;
		    if (k == slice || k == z_dim-1
		    ||  i == 0     || i == x_dim-1
		    ||  j == 0     || j == y_dim-1
		    ){
			Nx   =  0.0;
			Ny   =  0.0;
			Nz   = -1.0;
		    } else {
			int v000 = 0xFFF & voxel[ ((o-1)-x_dim)-xy ];
			int v001 = 0xFFF & voxel[ ((o-1)-x_dim)    ];
			int v002 = 0xFFF & voxel[ ((o-1)-x_dim)+xy ];
			int v010 = 0xFFF & voxel[ ((o-1)      )-xy ];
			int v011 = 0xFFF & voxel[ ((o-1)      )    ];
			int v012 = 0xFFF & voxel[ ((o-1)      )+xy ];
			int v020 = 0xFFF & voxel[ ((o-1)+x_dim)-xy ];
			int v021 = 0xFFF & voxel[ ((o-1)+x_dim)    ];
			int v022 = 0xFFF & voxel[ ((o-1)+x_dim)+xy ];
			int v100 = 0xFFF & voxel[ ((o  )-x_dim)-xy ];
			int v101 = 0xFFF & voxel[ ((o  )-x_dim)    ];
			int v102 = 0xFFF & voxel[ ((o  )-x_dim)+xy ];
			int v110 = 0xFFF & voxel[ ((o  )      )-xy ];
			int v111 = 0xFFF & voxel[ ((o  )      )    ];
			int v112 = 0xFFF & voxel[ ((o  )      )+xy ];
			int v120 = 0xFFF & voxel[ ((o  )+x_dim)-xy ];
			int v121 = 0xFFF & voxel[ ((o  )+x_dim)    ];
			int v122 = 0xFFF & voxel[ ((o  )+x_dim)+xy ];
			int v200 = 0xFFF & voxel[ ((o+1)-x_dim)-xy ];
			int v201 = 0xFFF & voxel[ ((o+1)-x_dim)    ];
			int v202 = 0xFFF & voxel[ ((o+1)-x_dim)+xy ];
			int v210 = 0xFFF & voxel[ ((o+1)      )-xy ];
			int v211 = 0xFFF & voxel[ ((o+1)      )    ];
			int v212 = 0xFFF & voxel[ ((o+1)      )+xy ];
			int v220 = 0xFFF & voxel[ ((o+1)+x_dim)-xy ];
			int v221 = 0xFFF & voxel[ ((o+1)+x_dim)    ];
			int v222 = 0xFFF & voxel[ ((o+1)+x_dim)+xy ];

			int del_x= (
			    (  v000+v001+v002+
			       v010+v011+v012+
			       v020+v021+v022
			    ) - (
			       v200+v201+v202+
			       v210+v211+v212+
			       v220+v221+v222
			    )
			);
			int del_y= (
			    (  v000+v001+v002+
			       v100+v101+v102+
			       v200+v201+v202
			    ) - (
			       v020+v021+v022+
			       v120+v121+v122+
			       v220+v221+v222
			    )
			);
			int del_z= (
			    (  v000+v010+v020+
			       v100+v110+v120+
			       v200+v210+v220
			    ) - (
			       v002+v012+v022+
			       v102+v112+v122+
			       v202+v212+v222
			    )
			);

			Nx   =  (float) del_x;
			Ny   =  (float) del_y;
			Nz   =  (float) del_z;

			{   float len = sqrt(Nx*Nx+Ny*Ny+Nz*Nz);
			    if (len == 0.0) {
				Nz  = -1.0;
			    } else {
				float len_1 = 1.0 / len;
				Nx *= len_1;
				Ny *= len_1;
				Nz *= len_1;
		    }   }   }

		    /* Taking the light vector */
		    /* as fixed on a diagonal: */
		    {   float innerprod = (
			   -0.57735 * Nx  +
			    0.57735 * Ny  +
			    0.57735 * Nz
			);
			/* I'm perverted and use the innerproduct */
			/* of lighting vect with surface normal   */
			/* to produce a 1.0 -> 0.0 colorweight:   */
			float w = innerprod * 0.5 + 0.5;

			/* Okie, now we're set to merge this voxel's */
			/* color contribution into our accumulating  */
			/* pixel:                                    */
			if (o_alf +  Valf < 1.0) {
			    o_red += Valf * red[v] * w;
			    o_grn += Valf * grn[v] * w;
			    o_blu += Valf * blu[v] * w;
			    o_alf += Valf;
			} else {
			    /* Pixel has reached 100% opacity,  */
			    /* stop iterating down this column: */
			    Valf   = 1.0 - o_alf;
			    o_red += Valf * red[v] * w;
			    o_grn += Valf * grn[v] * w;
			    o_blu += Valf * blu[v] * w;
			    o_alf += Valf;
			    break;
            }   }   }   }

	    /* Salt away computed color for this pixel: */
	    pr[i+jx] = (int)(255.99*o_red);
	    pg[i+jx] = (int)(255.99*o_grn);
	    pb[i+jx] = (int)(255.99*o_blu);
    }   }

    #else


    #endif
}

/************************************************************************/
 /*- xvolfb_Axis1 -- Load image from voxel-grl slice.			*/
/************************************************************************/

static void
xvolfb_Axis1(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pr,	/* Pixel red plane.	*/
    CSRY_UNSIGNED8*  pg,	/*       grn		*/
    CSRY_UNSIGNED8*  pb,	/*       blu		*/

    int              x_dim,
    int              y_dim,
    int              z_dim,

    float*           red,
    float*           grn,
    float*           blu,
    float*           alf,

    int              slice
) {
    /* Generate an image down the axis of */
    /* medium-varying index:              */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy  = x_dim*y_dim;
    for         (k = 0;       k < z_dim;     ++k) {
	int kxy = k*xy;
	for     (i = 0;       i < x_dim;     ++i) {
	    float o_red = 0.0;	/* Values to store in output pixel.*/
	    float o_grn = 0.0;	/* "                             " */
	    float o_blu = 0.0;	/* "                             " */
	    float o_alf = 0.0;	/* Accumulated opacity of pixel.   */
    	    for (j = slice;   j < y_dim;     ++j) {
		int o  = i + j*x_dim + kxy;/* offset */

		/* Look up color components for this voxel: */
		int   v    = voxel[ o ];
		float Valf = alf[v];
		if (Valf != 0.0) {

		    /* Compute 'surface normal' for lighting purposes: */
		    float Nx;
		    float Ny;
		    float Nz;
		    if (j == slice || j == y_dim-1
		    ||  i == 0     || i == x_dim-1
		    ||  k == 0     || k == z_dim-1
		    ){
			Nx   =  0.0;
			Ny   =  0.0;
			Nz   = -1.0;
		    } else {
			int v000 = 0xFFF & voxel[ ((o-1)-x_dim)-xy ];
			int v001 = 0xFFF & voxel[ ((o-1)-x_dim)    ];
			int v002 = 0xFFF & voxel[ ((o-1)-x_dim)+xy ];
			int v010 = 0xFFF & voxel[ ((o-1)      )-xy ];
			int v011 = 0xFFF & voxel[ ((o-1)      )    ];
			int v012 = 0xFFF & voxel[ ((o-1)      )+xy ];
			int v020 = 0xFFF & voxel[ ((o-1)+x_dim)-xy ];
			int v021 = 0xFFF & voxel[ ((o-1)+x_dim)    ];
			int v022 = 0xFFF & voxel[ ((o-1)+x_dim)+xy ];
			int v100 = 0xFFF & voxel[ ((o  )-x_dim)-xy ];
			int v101 = 0xFFF & voxel[ ((o  )-x_dim)    ];
			int v102 = 0xFFF & voxel[ ((o  )-x_dim)+xy ];
			int v110 = 0xFFF & voxel[ ((o  )      )-xy ];
			int v111 = 0xFFF & voxel[ ((o  )      )    ];
			int v112 = 0xFFF & voxel[ ((o  )      )+xy ];
			int v120 = 0xFFF & voxel[ ((o  )+x_dim)-xy ];
			int v121 = 0xFFF & voxel[ ((o  )+x_dim)    ];
			int v122 = 0xFFF & voxel[ ((o  )+x_dim)+xy ];
			int v200 = 0xFFF & voxel[ ((o+1)-x_dim)-xy ];
			int v201 = 0xFFF & voxel[ ((o+1)-x_dim)    ];
			int v202 = 0xFFF & voxel[ ((o+1)-x_dim)+xy ];
			int v210 = 0xFFF & voxel[ ((o+1)      )-xy ];
			int v211 = 0xFFF & voxel[ ((o+1)      )    ];
			int v212 = 0xFFF & voxel[ ((o+1)      )+xy ];
			int v220 = 0xFFF & voxel[ ((o+1)+x_dim)-xy ];
			int v221 = 0xFFF & voxel[ ((o+1)+x_dim)    ];
			int v222 = 0xFFF & voxel[ ((o+1)+x_dim)+xy ];

			int del_x= (
			    (  v000+v001+v002+
			       v010+v011+v012+
			       v020+v021+v022
			    ) - (
			       v200+v201+v202+
			       v210+v211+v212+
			       v220+v221+v222
			    )
			);
			int del_y= (
			    (  v000+v001+v002+
			       v100+v101+v102+
			       v200+v201+v202
			    ) - (
			       v020+v021+v022+
			       v120+v121+v122+
			       v220+v221+v222
			    )
			);
			int del_z= (
			    (  v000+v010+v020+
			       v100+v110+v120+
			       v200+v210+v220
			    ) - (
			       v002+v012+v022+
			       v102+v112+v122+
			       v202+v212+v222
			    )
			);

			/* We're looking down y instead of z so: */
			Nx   =  (float) del_x;
			Ny   =  (float) del_z;
			Nz   =  (float) del_y;

			{   float len = sqrt(Nx*Nx+Ny*Ny+Nz*Nz);
			    if (len == 0.0) {
				Nz  = -1.0;
			    } else {
				float len_1 = 1.0 / len;
				Nx *= len_1;
				Ny *= len_1;
				Nz *= len_1;
		    }   }   }

		    /* Taking the light vector */
		    /* as fixed on a diagonal: */
		    {   float innerprod = (
			   -0.57735 * Nx  +
			    0.57735 * Ny  +
			    0.57735 * Nz
			);
			/* I'm perverted and use the innerproduct */
			/* of lighting vect with surface normal   */
			/* to produce a 1.0 -> 0.0 colorweight:   */
			float w = innerprod * 0.5 + 0.5;

			/* Okie, now we're set to merge this voxel's */
			/* color contribution into our accumulating  */
			/* pixel:                                    */
			if (o_alf +  Valf < 1.0) {
			    o_red += Valf * red[v] * w;
			    o_grn += Valf * grn[v] * w;
			    o_blu += Valf * blu[v] * w;
			    o_alf += Valf;
			} else {
			    /* Pixel has reached 100% opacity,  */
			    /* stop iterating down this column: */
			    Valf   = 1.0 - o_alf;
			    o_red += Valf * red[v] * w;
			    o_grn += Valf * grn[v] * w;
			    o_blu += Valf * blu[v] * w;
			    o_alf += Valf;
			    break;
            }   }   }   }

	    /* Salt away computed color for this pixel: */
	    pr[i+k*x_dim] = (int)(255.99*o_red);
	    pg[i+k*x_dim] = (int)(255.99*o_grn);
	    pb[i+k*x_dim] = (int)(255.99*o_blu);
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolfc_Axis2 -- Load image from voxel-grl slice.			*/
 /***********************************************************************/

static void
xvolfc_Axis2(
    CSRY_UNSIGNED16* voxel,
    CSRY_UNSIGNED8*  pr,	/* Pixel red plane.	*/
    CSRY_UNSIGNED8*  pg,	/*       grn		*/
    CSRY_UNSIGNED8*  pb,	/*       blu		*/

    int              x_dim,
    int              y_dim,
    int              z_dim,

    float*           red,
    float*           grn,
    float*           blu,
    float*           alf,

    int              slice
) {
    /* Generate an image down the axis of */
    /* fastest-varying index:             */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy  = x_dim*y_dim;
    for         (k = 0;       k < z_dim;     ++k) {
	int kxy = k*xy;
	for     (j = 0;       j < y_dim;     ++j) {
	    float o_red = 0.0;	/* Values to store in output pixel.*/
	    float o_grn = 0.0;	/* "                             " */
	    float o_blu = 0.0;	/* "                             " */
	    float o_alf = 0.0;	/* Accumulated opacity of pixel.   */
    	    for (i = slice;   i < x_dim;     ++i) {
		int o  = i + j*x_dim + kxy;/* offset */

		/* Look up color components for this voxel: */
		int   v    = voxel[ o ];
		float Valf = alf[v];
		if (Valf != 0.0) {

		    /* Compute 'surface normal' for lighting purposes: */
		    float Nx;
		    float Ny;
		    float Nz;
		    if (i == slice || i == x_dim-1
		    ||  j == 0     || j == y_dim-1
		    ||  k == 0     || k == z_dim-1
		    ){
			Nx   =  0.0;
			Ny   =  0.0;
			Nz   = -1.0;
		    } else {
			int v000 = 0xFFF & voxel[ ((o-1)-x_dim)-xy ];
			int v001 = 0xFFF & voxel[ ((o-1)-x_dim)    ];
			int v002 = 0xFFF & voxel[ ((o-1)-x_dim)+xy ];
			int v010 = 0xFFF & voxel[ ((o-1)      )-xy ];
			int v011 = 0xFFF & voxel[ ((o-1)      )    ];
			int v012 = 0xFFF & voxel[ ((o-1)      )+xy ];
			int v020 = 0xFFF & voxel[ ((o-1)+x_dim)-xy ];
			int v021 = 0xFFF & voxel[ ((o-1)+x_dim)    ];
			int v022 = 0xFFF & voxel[ ((o-1)+x_dim)+xy ];
			int v100 = 0xFFF & voxel[ ((o  )-x_dim)-xy ];
			int v101 = 0xFFF & voxel[ ((o  )-x_dim)    ];
			int v102 = 0xFFF & voxel[ ((o  )-x_dim)+xy ];
			int v110 = 0xFFF & voxel[ ((o  )      )-xy ];
			int v111 = 0xFFF & voxel[ ((o  )      )    ];
			int v112 = 0xFFF & voxel[ ((o  )      )+xy ];
			int v120 = 0xFFF & voxel[ ((o  )+x_dim)-xy ];
			int v121 = 0xFFF & voxel[ ((o  )+x_dim)    ];
			int v122 = 0xFFF & voxel[ ((o  )+x_dim)+xy ];
			int v200 = 0xFFF & voxel[ ((o+1)-x_dim)-xy ];
			int v201 = 0xFFF & voxel[ ((o+1)-x_dim)    ];
			int v202 = 0xFFF & voxel[ ((o+1)-x_dim)+xy ];
			int v210 = 0xFFF & voxel[ ((o+1)      )-xy ];
			int v211 = 0xFFF & voxel[ ((o+1)      )    ];
			int v212 = 0xFFF & voxel[ ((o+1)      )+xy ];
			int v220 = 0xFFF & voxel[ ((o+1)+x_dim)-xy ];
			int v221 = 0xFFF & voxel[ ((o+1)+x_dim)    ];
			int v222 = 0xFFF & voxel[ ((o+1)+x_dim)+xy ];

			int del_x= (
			    (  v000+v001+v002+
			       v010+v011+v012+
			       v020+v021+v022
			    ) - (
			       v200+v201+v202+
			       v210+v211+v212+
			       v220+v221+v222
			    )
			);
			int del_y= (
			    (  v000+v001+v002+
			       v100+v101+v102+
			       v200+v201+v202
			    ) - (
			       v020+v021+v022+
			       v120+v121+v122+
			       v220+v221+v222
			    )
			);
			int del_z= (
			    (  v000+v010+v020+
			       v100+v110+v120+
			       v200+v210+v220
			    ) - (
			       v002+v012+v022+
			       v102+v112+v122+
			       v202+v212+v222
			    )
			);

			/* We're looking down x instead of z so: */
			Nx   =  (float) del_z;
			Ny   =  (float) del_y;
			Nz   =  (float) del_x;

			{   float len = sqrt(Nx*Nx+Ny*Ny+Nz*Nz);
			    if (len == 0.0) {
				Nz  = -1.0;
			    } else {
				float len_1 = 1.0 / len;
				Nx *= len_1;
				Ny *= len_1;
				Nz *= len_1;
		    }   }   }

		    /* Taking the light vector */
		    /* as fixed on a diagonal: */
		    {   float innerprod = (
			   -0.57735 * Nx  +
			    0.57735 * Ny  +
			    0.57735 * Nz
			);
			/* I'm perverted and use the innerproduct */
			/* of lighting vect with surface normal   */
			/* to produce a 1.0 -> 0.0 colorweight:   */
			float w = innerprod * 0.5 + 0.5;

			/* Okie, now we're set to merge this voxel's */
			/* color contribution into our accumulating  */
			/* pixel:                                    */
			if (o_alf +  Valf < 1.0) {
			    o_red += Valf * red[v] * w;
			    o_grn += Valf * grn[v] * w;
			    o_blu += Valf * blu[v] * w;
			    o_alf += Valf;
			} else {
			    /* Pixel has reached 100% opacity,  */
			    /* stop iterating down this column: */
			    Valf   = 1.0 - o_alf;
			    o_red += Valf * red[v] * w;
			    o_grn += Valf * grn[v] * w;
			    o_blu += Valf * blu[v] * w;
			    o_alf += Valf;
			    break;
            }   }   }   }

	    /* Salt away computed color for this pixel: */
	    pr[k+j*z_dim] = (int)(255.99*o_red);
	    pg[k+j*z_dim] = (int)(255.99*o_grn);
	    pb[k+j*z_dim] = (int)(255.99*o_blu);
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolfd_Create_Rgb_Pixels -- 					*/
 /***********************************************************************/

LVAL xvolfd_Create_Rgb_Pixels(
    int rows,
    int cols,
    CSRY_UNSIGNED8 **r,
    CSRY_UNSIGNED8 **g,
    CSRY_UNSIGNED8 **b
){
    LVAL lv_shape;
    LVAL lv_grl;

    LVAL lv_red;
    LVAL lv_grn;
    LVAL lv_blu;

    int        toProt = 5;
    xlstkcheck(toProt);
    xlsave(lv_shape );
    xlsave(lv_grl   );
    xlsave(lv_red   );
    xlsave(lv_grn   );
    xlsave(lv_blu   );

    /* Create our pixel relation: */
    lv_shape = cons(cvfixnum(cols),     NIL);
    lv_shape = cons(cvfixnum(rows),lv_shape);
    lv_grl		= xsendmsg1( lv_xgrl, k_new, lv_shape );

    /* Create pixel-r/g/b arrays to go in pixel relation: */
    lv_red	= xsendmsg1( lv_xf8v, k_new, lv_shape );
    lv_grn	= xsendmsg1( lv_xf8v, k_new, lv_shape );
    lv_blu	= xsendmsg1( lv_xf8v, k_new, lv_shape );

    /* Insert pixel-green array in pixel relation: */
    xsendmsg2( lv_grl, k_setarray, k_pixelred  , lv_red );
    xsendmsg2( lv_grl, k_setarray, k_pixelgreen, lv_grn );
    xsendmsg2( lv_grl, k_setarray, k_pixelblue , lv_blu );

    /* Locate the actual pixel-buffers within pixel arrays: */
    *r     = (CSRY_UNSIGNED8*) csry_base( lv_red );
    *g     = (CSRY_UNSIGNED8*) csry_base( lv_grn );
    *b     = (CSRY_UNSIGNED8*) csry_base( lv_blu );

    xlpopn(toProt);

    return lv_grl;
}

 /***********************************************************************/
 /*- xvolfz_Render_In_Color_Fn						*/
 /***********************************************************************/

LVAL
xvolfz_Render_In_Color_Fn(
    void
){
    /* Read filename: */
    LVAL lv_voxels   = NULL;
    LVAL lv_slice    = NULL;
    LVAL lv_rrl      = NULL;	/* Rendering relation.			*/
    LVAL lv_red;		/* From rendering relation.		*/
    LVAL lv_grn;		/* "                        "		*/
    LVAL lv_blu;		/* "                        "		*/
    LVAL lv_alf;		/* "                        "		*/
    float*  red;		/* Pointer to data in lv_red above.	*/
    float*  grn;		/* "                  lv_grn      "	*/
    float*  blu;		/* "                  lv_blu      "	*/
    float*  alf;		/* "                  lv_alf      "	*/
    CSRY_UNSIGNED8* pr;		/* Pixel Red plane in result relation.	*/
    CSRY_UNSIGNED8* pg;		/* "     Grn                         "	*/
    CSRY_UNSIGNED8* pb;		/* "     Blu                         "	*/
    int     slice    = 0;
    int     x;
    int     y;
    int     z;
    int    lo        =   0;
    int    hi        = 256;
    LVAL   lv_ary    = NULL;
    LVAL   lv_pix    = NULL;	/* Relation holding output pixels.	*/
    int     axis     = 0;
    int     zoom     = 1;
    int    p_rows    = 256;	/* Size of output pixel array.		*/
    int    p_cols    = 256;	/* Size of output pixel array.		*/

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_rendering_relation) {
	    lv_rrl    = xlgetarg();
	} else if (lv == k_voxels) {
	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;
	} else if (lv == k_result_in) {
	    lv_pix = xlgetarg();
	} else if (lv == k_slice) {
	    lv_slice  = xlgafixnum();
	    slice     = getfixnum( lv_slice );
	} else if (lv == k_axis) {
	    LVAL lv_axis = xlgafixnum();
	    axis = getfixnum(lv_axis);
	    if (axis < 0 || axis > 2) {
		xlerror("Bad XMRI-RENDER-IN-COLOR :AXIS value",lv_axis);
	    }
	} else if (lv == k_zoom_by) {
	    LVAL lv_zoom = xlgafixnum();
	    zoom = getfixnum(lv_zoom);
	    if (zoom !=  1
            &&  zoom !=  2
            &&  zoom !=  4
            &&  zoom !=  8
            &&  zoom != 16
            ){
		xlerror("Bad XMRI-RENDER-IN-COLOR :ZOOM-BY value",lv_zoom);
	    }
	} else {
	    xlerror("Bad XMRI-RENDER-IN-COLOR keyword",lv);
    }   }
    if (!lv_voxels) xlfail("XMRI-RENDER-IN-COLOR: missing :VOXELS keyword");
    if (!lv_rrl) {
	xlfail("XMRI-RENDER-IN-COLOR: missing :RENDERING-RELATION keyword");
    }

    /* Unpack and check render-relation:      */
    /* Make sure lv_rrl is a graphic relation */
    /* with appropriate arrays:               */
    if (!      lv_rrl
    ||  !xgrlp(lv_rrl)
    ||  !(     lv_red = xgrl3c_Get_Array(lv_rrl, k_diffuse_red  , NIL, TRUE))
    ||  !xflvp(lv_red)
    ||  !(     lv_grn = xgrl3c_Get_Array(lv_rrl, k_diffuse_green, NIL, TRUE))
    ||  !xflvp(lv_grn)
    ||  !(     lv_blu = xgrl3c_Get_Array(lv_rrl, k_diffuse_blue , NIL, TRUE))
    ||  !xflvp(lv_blu)
    ||  !(     lv_alf = xgrl3c_Get_Array(lv_rrl, k_alpha        , NIL, TRUE))
    ||  !xflvp(lv_alf)
    ||  !xvole3_Check_Dimension( lv_red, 4096 )
    ||  !xvole3_Check_Dimension( lv_grn, 4096 )
    ||  !xvole3_Check_Dimension( lv_blu, 4096 )
    ||  !xvole3_Check_Dimension( lv_alf, 4096 )
    ){
	xlfail("XMRI-RENDER-IN-COLOR: bad :RENDERING-RELATION value");
    }
    /* Locate the actual float buffers within red/grn/blu/alpha arrays: */
    red = (float*) csry_base( lv_red );
    grn = (float*) csry_base( lv_grn );
    blu = (float*) csry_base( lv_blu );
    alf = (float*) csry_base( lv_alf );


    /* If lv_ary is a relation, fetch :INTENSITY array: */
    if (xgrlp(lv_ary)) {
	lv_ary = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
    }
    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-RENDER-IN-COLOR voxel argument.",lv_ary);
    }

    xvol95_Get_X_Y_Z_Dimensions( &x, &y, &z, lv_voxels );

    /* Compute appropriate size for result array: */
    p_rows    = y * zoom;	/* Size of output pixel array.		*/
    p_cols    = x * zoom;	/* Size of output pixel array.		*/

    /* This code has only been tested on 128^3 and 256^3 voxelsets,	*/
    /* but in principle should work on other sizes as well:             */
    #ifdef CAUTIOUS
    if (x != z
    ||  y != z
    ){
	xlfail("XMRI-RENDER-IN-COLOR: Voxel array not cubic!");
    }
    if (x != 128 && x != 256){
	xlfail(
	    "XMRI-RENDER-IN-COLOR: "
	    "Currently only 128^3 and 256^3 voxel arrays handled."
	);
    }
    #endif

    if (slice < 0 || slice >= z) {
	xlerror("XMRI-RENDER-IN-COLOR: Bad slice#",lv_slice);
    }

    /* Make sure lv_pix is a graphic relation with */
    /* appropriate :PIXEL-RED/GREEN/BLUE arrays:   */
    if (!      lv_pix
    ||  !xgrlp(lv_pix)
    ||  !(     lv_red = xgrl3c_Get_Array( lv_pix, k_pixelred  , NIL, TRUE ))
    ||  !xf8vp(lv_red)
    ||  !(     lv_grn = xgrl3c_Get_Array( lv_pix, k_pixelgreen, NIL, TRUE ))
    ||  !xf8vp(lv_grn)
    ||  !(     lv_blu = xgrl3c_Get_Array( lv_pix, k_pixelblue , NIL, TRUE ))
    ||  !xf8vp(lv_blu)
    ||  !xvol94_Check_X_And_Y_Dimensions( lv_red, p_cols, p_rows, 0 )
    ||  !xvol94_Check_X_And_Y_Dimensions( lv_grn, p_cols, p_rows, 0 )
    ||  !xvol94_Check_X_And_Y_Dimensions( lv_blu, p_cols, p_rows, 0 )
    ){
	/* Create graphic relation to hold result: */
	lv_pix = xvolfd_Create_Rgb_Pixels(
	    p_rows, 	/*rows*/
	    p_cols,	/*cols*/
	    &pr,	/* Returns pointer to pixel red  plane here */
	    &pg,	/*                          grn             */
	    &pb 	/*                          blu             */
	);
    } else {
	pr = (CSRY_UNSIGNED8*) csry_base( lv_red );
	pg = (CSRY_UNSIGNED8*) csry_base( lv_grn );
	pb = (CSRY_UNSIGNED8*) csry_base( lv_blu );
    }

    {   /* Get pointer to data area in voxel array: */
	CSRY_UNSIGNED16*voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );

	/* Blast data from voxel to image array.                      */
	/* Branch depending which direction we're extracting a slice: */
	switch (axis) {
	case 0:xvolfa_Axis0(voxel,pr,pg,pb,x,y,z,red,grn,blu,alf,slice);break;
	case 1:xvolfb_Axis1(voxel,pr,pg,pb,x,y,z,red,grn,blu,alf,slice);break;
	case 2:xvolfc_Axis2(voxel,pr,pg,pb,x,y,z,red,grn,blu,alf,slice);break;
	default:abort();
	}

	/* Branch depending which factor we're zooming by. */
	/* Yes, these cases cutely fall into each other:   */
	switch (zoom) {

	case 16: xvolcd_Double_Image_Size( pr, p_cols/16, p_rows/16 );
		 xvolcd_Double_Image_Size( pg, p_cols/16, p_rows/16 );
		 xvolcd_Double_Image_Size( pb, p_cols/16, p_rows/16 );

	case  8: xvolcd_Double_Image_Size( pr, p_cols/8 , p_rows/8  );
		 xvolcd_Double_Image_Size( pg, p_cols/8 , p_rows/8  );
		 xvolcd_Double_Image_Size( pb, p_cols/8 , p_rows/8  );

	case  4: xvolcd_Double_Image_Size( pr, p_cols/4 , p_rows/4  );
		 xvolcd_Double_Image_Size( pg, p_cols/4 , p_rows/4  );
		 xvolcd_Double_Image_Size( pb, p_cols/4 , p_rows/4  );

	case  2: xvolcd_Double_Image_Size( pr, p_cols/2 , p_rows/2  );
		 xvolcd_Double_Image_Size( pg, p_cols/2 , p_rows/2  );
		 xvolcd_Double_Image_Size( pb, p_cols/2 , p_rows/2  );

	case  1:					        break;

	default:abort();
	}

	/* Return result image: */
	return lv_pix;
    }
}

/************************************************************************/
/*- xvolg4_Mirror_Voxels_Axially_Fn --					*/
/************************************************************************/

 /***********************************************************************/
 /*- xvolg0_Axis0 -- Reflect along axis 0.				*/
 /***********************************************************************/

static void
xvolg0_Axis0(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim
) {
    /* Reflect voxels down the axis */
    /* of slowest-varying index:    */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy   = x_dim * y_dim;
    int xyz1 = xy * (z_dim-1);
    for         (j = 0;       j < y_dim;     ++j) {
	for     (i = 0;       i < x_dim;     ++i) {
	    CSRY_UNSIGNED16* bat = &voxel[ i + j*x_dim ];
	    CSRY_UNSIGNED16* cat = &bat[   xyz1        ];
    	    for (k = z_dim >> 1;   k --> 0;  ) {
		CSRY_UNSIGNED16 b = *bat;
		CSRY_UNSIGNED16 c = *cat;
		*bat = c;	bat += xy;
		*cat = b;	cat -= xy;
    }   }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolg1_Axis1 -- Reflect along axis 1.				*/
 /***********************************************************************/

static void
xvolg1_Axis1(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim
) {
    /* Reflect voxels down the axis */
    /* of medium-varying index:     */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy   = x_dim * y_dim;
    int xy1  = xy - x_dim;
    for         (k = 0;       k < z_dim;     ++k) {
	for     (i = 0;       i < x_dim;     ++i) {
	    CSRY_UNSIGNED16* bat = &voxel[ i + k*xy ];
	    CSRY_UNSIGNED16* cat = &bat[   xy1      ];
    	    for (j = y_dim >> 1;   j --> 0;  ) {
		CSRY_UNSIGNED16 b = *bat;
		CSRY_UNSIGNED16 c = *cat;
		*bat = c;   bat += x_dim;
		*cat = b;   cat -= x_dim;
    }   }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolg2_Axis2 -- Reflect along axis 2.				*/
 /***********************************************************************/

static void
xvolg2_Axis2(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim
) {
    /* Reflect voxels down the axis */
    /* of fastest-varying index:    */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy   = x_dim * y_dim;
    for         (k = 0;       k < z_dim;     ++k) {
	for     (j = 0;       j < y_dim;     ++j) {
	    CSRY_UNSIGNED16* bat = &voxel[ j*x_dim + k*xy ];
	    CSRY_UNSIGNED16* cat = &bat[   x_dim-1        ];
    	    for (i = x_dim >> 1;   i --> 0;  ) {
		CSRY_UNSIGNED16 b = *bat;
		CSRY_UNSIGNED16 c = *cat;
		*bat++ = c;
		*cat-- = b;
    }   }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolg4_Mirror_Voxels_Axially_Fn					*/
 /***********************************************************************/

LVAL
xvolg4_Mirror_Voxels_Axially_Fn(
    void
){
    LVAL lv_voxels   = NULL;
    LVAL lv_ary      = NULL;
    int     axis     = 0;
    int     x;
    int     y;
    int     z;

    while (moreargs()) {
        LVAL lv_key = xlgasymbol();

	if (lv_key == k_voxels) {
	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;
 	} else if (lv_key == k_axis) {
	    LVAL lv_axis = xlgafixnum();
	    axis = getfixnum(lv_axis);
	    if (axis < 0 || axis > 2) {
		xlerror("Bad XMRI-MIRROR-VOXELS-AXIALLY :AXIS value",lv_axis);
	    }
	} else {
	    xlerror("XMRI-MIRROR-VOXELS-AXIALLY: bad keyword:",lv_key);
    }   }

    if (!lv_voxels) xlfail("XMRI-MIRROR-VOXELS-AXIALLY: missing :VOXELS keyword");

    /* If lv_ary is a relation, fetch :INTENSITY array: */
    if (xgrlp(lv_ary)) {
	lv_ary = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
    }
    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-MIRROR-VOXELS-AXIALLY :VOXEL val.",lv_ary);
    }

    xvol95_Get_X_Y_Z_Dimensions( &x, &y, &z, lv_voxels );
    if (x != z
    ||  y != z
    ){
	xlfail("XMRI-MIRROR-VOXELS-AXIALLY: Voxel array not cubic!");
    }

    {   /* Get pointer to data area in voxel array: */
	CSRY_UNSIGNED16*voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );

	switch (axis) {
	case 0: xvolg0_Axis0( voxel, x,y,z ); break;
	case 1: xvolg1_Axis1( voxel, x,y,z ); break;
	case 2: xvolg2_Axis2( voxel, x,y,z ); break;
	default:abort();
    }	}

    return NIL;
}

/************************************************************************/
/*- xvolg8_Mirror_Voxels_Diagonally_Fn --				*/
/************************************************************************/

 /***********************************************************************/
 /*- xvolg5_Axis0 -- Reflect around axis 0.				*/
 /***********************************************************************/

static void
xvolg5_Axis0(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim
) {
    /* Reflect voxels around the axis */
    /* of slowest-varying index:      */
    #ifndef LOGICAL_ALGORITHM

    int s;
    int t;
    int k;
    int xy   = x_dim * y_dim;

    /* Over each plane to diagonally mirror: */
    for  (k = 0; k < z_dim; ++k) {

	/* Over each pair of perpendicular voxel-lines */
	/* to be swapped in plane, starting at origin: */
	for (s = 0;       s < x_dim;     ++s) {
	    CSRY_UNSIGNED16* bat = &voxel[ s + s*x_dim + k*xy ];
	    CSRY_UNSIGNED16* cat =  bat;

	    /* Follow both lines outward from their */
	    /* meeting point, swapping matching     */
	    /* pairs of voxels as we go:            */
    	    for (t = s;   t < y_dim;   ++t) {
		CSRY_UNSIGNED16 b = *bat;
		CSRY_UNSIGNED16 c = *cat;
		*bat = c;	bat +=     1;
		*cat = b;	cat += x_dim;
    }   }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolg6_Axis1 -- Reflect around axis 1.				*/
 /***********************************************************************/

static void
xvolg6_Axis1(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim
) {
    /* Reflect voxels around the axis */
    /* of medium-varying index:       */
    #ifndef LOGICAL_ALGORITHM

    int s;
    int t;
    int j;
    int xy   = x_dim * y_dim;

    /* Over each plane to diagonally mirror: */
    for  (j = 0;   j < y_dim;   ++j) {

	/* Over each pair of perpendicular voxel-lines */
	/* to be swapped in plane, starting at origin: */
	for (s = 0;       s < x_dim;     ++s) {
	    CSRY_UNSIGNED16* bat = &voxel[ s + j*x_dim + s*xy ];
	    CSRY_UNSIGNED16* cat =  bat;

	    /* Follow both lines outward from their */
	    /* meeting point, swapping matching     */
	    /* pairs of voxels as we go:            */
    	    for (t = s;   t < z_dim;   ++t) {
		CSRY_UNSIGNED16 b = *bat;
		CSRY_UNSIGNED16 c = *cat;
		*bat = c;	bat +=  1;
		*cat = b;	cat += xy;
    }   }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolg7_Axis2 -- Reflect around axis 2.				*/
 /***********************************************************************/

static void
xvolg7_Axis2(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim
) {
    /* Reflect voxels around the axis */
    /* of fastest-varying index:      */
    #ifndef LOGICAL_ALGORITHM

    int s;
    int t;
    int i;
    int xy   = x_dim * y_dim;

    /* Over each plane to diagonally mirror: */
    for  (i = 0;   i < x_dim;   ++i) {

	/* Over each pair of perpendicular voxel-lines */
	/* to be swapped in plane, starting at origin: */
	for (s = 0;       s < x_dim;     ++s) {
	    CSRY_UNSIGNED16* bat = &voxel[ i + s*x_dim + s*xy ];
	    CSRY_UNSIGNED16* cat =  bat;

	    /* Follow both lines outward from their */
	    /* meeting point, swapping matching     */
	    /* pairs of voxels as we go:            */
    	    for (t = s;   t < z_dim;   ++t) {
		CSRY_UNSIGNED16 b = *bat;
		CSRY_UNSIGNED16 c = *cat;
		*bat = c;	bat += x_dim;
		*cat = b;	cat +=    xy;
    }   }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolg8_Mirror_Voxels_Diagonally_Fn					*/
 /***********************************************************************/

LVAL
xvolg8_Mirror_Voxels_Diagonally_Fn(
    void
){
    LVAL lv_voxels   = NULL;
    LVAL lv_ary      = NULL;
    int  axis_count  = 0;
    int     axis0    = 1;
    int     axis1    = 2;
    int     axis;
    int     x;
    int     y;
    int     z;

    while (moreargs()) {
        LVAL lv_key = xlgasymbol();

	if (lv_key == k_voxels) {
	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;
	} else if (lv_key == k_axis) {
	    LVAL lv_axis = xlgafixnum();
	    int ax = getfixnum(lv_axis);
	    if (ax < 0 || ax > 2) {
		xlerror("Bad XMRI-MIRROR-VOXELS-DIAGONALLY bad :AXIS value",lv_axis);
	    }
	    switch (axis_count++) {
	    case 0: axis0 = ax;   axis1 = (axis0+1) % 3;   break;
	    case 1: axis1 = ax;	                           break;
	    default:
		xlfail("XMRI-MIRROR-VOXELS-DIAGONALLY too many :AXIS values");
	    }
	} else {
	    xlerror("XMRI-MIRROR-VOXELS-DIAGONALLY: bad keyword:",lv_key);
    }   }

    if (!lv_voxels)      xlfail("XMRI-MIRROR-VOXELS-DIAGONALLY: missing :VOXELS keyword");
    if (axis0 == axis1)  xlfail("XMRI-MIRROR-VOXELS-DIAGONALLY: :AXIS args must differ");
    if (axis0 > axis1) {
	int tmp = axis0;
	axis0   = axis1;
	axis1   = tmp;
    }
    switch ((axis0 << 4) | axis1) {
    case 0x01: axis = 2;	break;
    case 0x02: axis = 1;	break;
    case 0x12: axis = 0;	break;
    default: abort();
    }

    /* If lv_ary is a relation, fetch :INTENSITY array: */
    if (xgrlp(lv_ary)) {
	lv_ary = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
    }
    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-MIRROR-VOXELS-DIAGONALLY :VOXEL val.",lv_ary);
    }

    xvol95_Get_X_Y_Z_Dimensions( &x, &y, &z, lv_voxels );
    if (x != z
    ||  y != z
    ){
	xlfail("XMRI-MIRROR-VOXELS-DIAGONALLY: Voxel array not cubic!");
    }

    {   /* Get pointer to data area in voxel array: */
	CSRY_UNSIGNED16*voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );

	switch (axis) {
	case 0: xvolg5_Axis0( voxel, x,y,z ); break;
	case 1: xvolg6_Axis1( voxel, x,y,z ); break;
	case 2: xvolg7_Axis2( voxel, x,y,z ); break;
	default:abort();
    }	}

    return NIL;
}

/************************************************************************/
/*- xvolgc_Circulate_Voxels_Axially_Fn --				*/
/************************************************************************/

#ifndef XMRI_BUFSIZ
#define XMRI_BUFSIZ 4096
#endif
 /***********************************************************************/
 /*- xvolg9_Axis0 -- Circulate along axis 0.				*/
 /***********************************************************************/

static void
xvolg9_Axis0(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int		     dist
) {
    /* Circulate voxels down the axis */
    /* of slowest-varying index:      */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy   = x_dim * y_dim;

    /* A map from source offset to destination offset in hyper-row: */
    int map[ XMRI_BUFSIZ ];

    /* With a little headscratching about prime factors, */
    /* it should be possible to do this in-place, but    */
    /* using a buffer is easier to write:                */
    unsigned buf[ XMRI_BUFSIZ ];

    /* Check that our buffers are big enough.  Yes,      */
    /* alloca() would be more elegant...                 */
    if (z_dim > XMRI_BUFSIZ) {
	xlerror(
	    "XMRI-CIRCULATE-VOXELS-AXIALLY buffer overflow, "
	    "increase XMRI_BUFSIZ and recompile."
	);
    }

    /* Initialize our array: */
    for (k = 0;   k < z_dim;   ++k) {
        int m = k+dist;
	while (m >= z_dim) m -= z_dim;
	map[k] = m*xy;
    }

    /* Rotate each hyper-row: */
    for         (j = 0;       j < y_dim;     ++j) {
	for     (i = 0;       i < x_dim;     ++i) {

	    /* Find hyper-row (?) we're operating on: */
	    CSRY_UNSIGNED16* p = &voxel[ i + j*x_dim ];

	    /* Copy hyper-row into buffer: */
	    int  x = 0;
    	    for (k = 0;   k < z_dim;   k += 1, x += xy)  buf[k] = p[x];

	    /* Copy hyper-row back, suitably rotated: */
	    for (k = z_dim;   k --> 0;  )  p[map[k]] = buf[k];
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolga_Axis1 -- Circulate along axis 1.				*/
 /***********************************************************************/

static void
xvolga_Axis1(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int		     dist
) {
    /* Circulate voxels down the axis */
    /* of medium-varying index:       */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy   = x_dim * y_dim;

    /* A map from source offset to destination offset in hyper-row: */
    int map[ XMRI_BUFSIZ ];

    /* Check that our buffers are big enough.  Yes,      */
    /* alloca() would be more elegant...                 */
    unsigned buf[ XMRI_BUFSIZ ];
    if (y_dim > XMRI_BUFSIZ) {
	xlerror(
	    "XMRI-CIRCULATE-VOXELS-AXIALLY buffer overflow, "
	    "increase XMRI_BUFSIZ and recompile."
	);
    }

    /* Initialize our array: */
    for (j = 0;   j < y_dim;   ++j) {
        int m = j+dist;
	while (m >= y_dim) m -= y_dim;
	map[j] = m*x_dim;
    }

    /* Rotate each column: */
    for         (k = 0;       k < z_dim;     ++k) {
	for     (i = 0;       i < x_dim;     ++i) {

	    /* Find column we're operating on: */
	    CSRY_UNSIGNED16* p = &voxel[ i + k*xy ];

	    /* Copy column into buffer: */
	    int  y = 0;
    	    for (j = 0;   j < y_dim;   j += 1, y += x_dim)  buf[j] = p[y];

	    /* Copy column back, suitably rotated: */
	    for (j = y_dim;   j --> 0;  )  p[map[j]] = buf[j];
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolgb_Axis2 -- Circulate along axis 2.				*/
 /***********************************************************************/

static void
xvolgb_Axis2(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int		     dist
) {
    /* Circulate voxels down the axis */
    /* of fastest-varying index:      */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy   = x_dim * y_dim;

    /* A map from source offset to destination offset in hyper-row: */
    unsigned map[ XMRI_BUFSIZ ];

    /* Check that our buffers are big enough.  Yes,      */
    /* alloca() would be more elegant...                 */
    int buf[ XMRI_BUFSIZ ];
    if (x_dim > XMRI_BUFSIZ) {
	xlerror(
	    "XMRI-CIRCULATE-VOXELS-AXIALLY buffer overflow, "
	    "increase XMRI_BUFSIZ and recompile."
	);
    }

    /* Initialize our array: */
    for (i = 0;   i < x_dim;   ++i) {
        int m = i+dist;
	while (m >= x_dim) m -= x_dim;
	map[i] = m;
    }

    /* Rotate each row: */
    for         (k = 0;       k < z_dim;     ++k) {
	for     (j = 0;       j < y_dim;     ++j) {

	    /* Find row we're operating on: */
	    CSRY_UNSIGNED16* p = &voxel[ j*x_dim + k*xy ];

	    /* Copy row into buffer: */
    	    for (i = x_dim;   i --> 0;   )  buf[i] = p[i];

	    /* Copy column back, suitably rotated: */
	    for (i = x_dim;   i --> 0;   )  p[map[i]] = buf[i];
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolgc_Circulate_Voxels_Axially_Fn					*/
 /***********************************************************************/

LVAL
xvolgc_Circulate_Voxels_Axially_Fn(
    void
){
    Xmri_a_range r[ XMRI_MAX_RANGES ];
    int          ranges = 0;

    LVAL lv_voxels   = NULL;
    LVAL lv_ary      = NULL;
    int     axis     = 0;
    float  fdist     = 0.0;
    int    idist;
    int     x;
    int     y;
    int     z;

    while (moreargs()) {
        LVAL lv_key = xlgasymbol();

	if (lv_key == k_voxels) {
	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;
	} else if (lv_key == k_axis) {
	    LVAL lv_axis = xlgafixnum();
	    axis = getfixnum(lv_axis);
	    if (axis < 0 || axis > 2) {
		xlerror("Bad XMRI-CIRCULATE-VOXELS-AXIALLY :AXIS value",lv_axis);
	    }
	} else if (lv_key == k_distance) {
	    LVAL lv_dist = xlgaflonum();
	    fdist = getflonum(lv_dist);

	    if (fdist < -1.0 || fdist > 1.0) {
		xlerror("Bad XMRI-CIRCULATE-VOXELS-AXIALLY :DISTANCE value",lv_dist);
	    }
	} else {
	    xlerror("XMRI-CIRCULATE-VOXELS-AXIALLY: bad keyword:",lv_key);
    }   }

    /* If lv_ary is a relation, fetch :INTENSITY array: */
    if (xgrlp(lv_ary)) {
	lv_ary = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
    }
    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-CIRCULATE-VOXELS-AXIALLY :VOXEL val.",lv_ary);
    }

    xvol95_Get_X_Y_Z_Dimensions( &x, &y, &z, lv_voxels );
    if (x != z
    ||  y != z
    ){
	xlfail("XMRI-CIRCULATE-VOXELS-AXIALLY: Voxel array not cubic!");
    }

    /* Convert fdist to a voxel count: */
    if (fdist < 0.0)  fdist += 1.0;
    idist = (int)(fdist*((float)x));

    {   /* Get pointer to data area in voxel array: */
	CSRY_UNSIGNED16*voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );

	switch (axis) {
	case 0: xvolg9_Axis0( voxel, x,y,z, idist ); break;
	case 1: xvolga_Axis1( voxel, x,y,z, idist ); break;
	case 2: xvolgb_Axis2( voxel, x,y,z, idist ); break;
	default:abort();
    }	}

    return NIL;
}

/************************************************************************/
/*- xvolgk_Resize_Voxels_Axially_Fn --					*/
/************************************************************************/

#ifndef XMRI_BUFSIZ
#define XMRI_BUFSIZ 4096
#endif

 /***********************************************************************/
 /*- xvolgd_Axis0 -- Impulse resizing along axis 0.			*/
 /***********************************************************************/

static void
xvolgd_Axis0(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int		     dst_min,
    int		     dst_max,
    int		     src_min,
    int		     src_max,

    int		     zero_rest
) {
    /* Resize voxels down the axis */
    /* of slowest-varying index:   */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy         = x_dim * y_dim;
    int xyXsrc_min = xy*src_min;
    int xyXdst_min = xy*dst_min;

    /* A map from destination offset to source offset in hyper-row: */
    int map[ XMRI_BUFSIZ ];

    unsigned buf[ XMRI_BUFSIZ ];

    /* Check that our buffers are big enough.  Yes,      */
    /* alloca() would be more elegant...                 */
    if (z_dim > XMRI_BUFSIZ) {
	xlerror(
	    "XMRI-RESIZE-VOXELS-AXIALLY buffer overflow, "
	    "increase XMRI_BUFSIZ and recompile."
	);
    }

    /* Initialize our map: */
    {   int dst_num   = dst_max-dst_min;
	int src_num   = src_max-src_min;
	if (dst_num <= 0)   return;
	{   float delta     = ((float)src_num) / ((float)dst_num);
	    float src_idx   = 0.5;
	    for (k = dst_min;   k < dst_max;   ++k, src_idx += delta) {
		int si = (int) src_idx;
		if (si < 0)      si = 0;
		if (si >= z_dim) si = z_dim-1;
		map[k] = si;
    }	}   }

    /* Remap each hyper-row: */
    for         (j = 0;   j < y_dim;   ++j) {
	for     (i = 0;   i < x_dim;   ++i) {

	    /* Find hyper-row we're operating on: */
	    CSRY_UNSIGNED16* p = &voxel[ i + j*x_dim ];

	    /* Copy part of hyper-row into buffer: */
	    int  x = xyXsrc_min;
    	    for (k = src_min;   k < src_max;   k += 1, x += xy)  buf[k] = p[x];

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
		x = 0;
	        for (k = 0;   k < dst_min;   k += 1, x += xy)  p[x] = 0;
	    }

	    /* Copy hyper-row back, suitably remapped: */
	    x = xyXdst_min;
	    for (k = dst_min; k < dst_max;   k += 1, x += xy) {
		p[x] = buf[map[k]];
	    }

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
	        for (     ;   k <   z_dim;   k += 1, x += xy)  p[x] = 0;
	    }
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolge_Axis1 -- Impulse resizing along axis 1.			*/
 /***********************************************************************/

static void
xvolge_Axis1(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int		     dst_min,
    int		     dst_max,
    int		     src_min,
    int		     src_max,

    int		     zero_rest
) {
    /* Resize voxels down the axis */
    /* of medium-varying index:    */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy         = x_dim*y_dim;
    int xXsrc_min  = x_dim*src_min;
    int xXdst_min  = x_dim*dst_min;

    /* A map from destination offset to source offset in column: */
    int map[ XMRI_BUFSIZ ];

    unsigned buf[ XMRI_BUFSIZ ];
    if (y_dim > XMRI_BUFSIZ) {
	xlerror(
	    "XMRI-RESIZE-VOXELS-AXIALLY buffer overflow, "
	    "increase XMRI_BUFSIZ and recompile."
	);
    }

    /* Initialize our map: */
    {   int dst_num   = dst_max-dst_min;
	int src_num   = src_max-src_min;
	if (dst_num <= 0)   return;
	{   float delta     = ((float)src_num) / ((float)dst_num);
	    float src_idx   = 0.5;
	    for (j = dst_min;   j < dst_max;   ++j, src_idx += delta) {
		int si = (int) src_idx;
		if (si < 0)      si = 0;
		if (si >= y_dim) si = y_dim-1;
		map[j] = si;
    }	}   }

    /* Remap each column: */
    for         (k = 0;   k < z_dim;   ++k) {
	for     (i = 0;   i < x_dim;   ++i) {

	    int  y;

	    /* Find column we're operating on: */
	    CSRY_UNSIGNED16* p = &voxel[ i + k*xy ];

	    /* Copy source part of column into buffer: */
	    y = xXsrc_min;
    	    for (j = src_min;   j < src_max;   j += 1, y += x_dim)  buf[j] = p[y];

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
		y = 0;
	        for (j = 0;   j < dst_min;   j += 1, y += x_dim)  p[y] = 0;
	    }

	    /* Copy column back, suitably remapped: */
	    y = xXdst_min;
	    for (j = dst_min; j < dst_max;   j += 1, y += x_dim) {
		p[y] = buf[map[j]];
	    }

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
	        for (     ;   j <   y_dim;   j += 1, y += x_dim)  p[y] = 0;
	    }
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolgf_Axis2 -- Impulse resizing along axis 2.			*/
 /***********************************************************************/

static void
xvolgf_Axis2(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int		     dst_min,
    int		     dst_max,
    int		     src_min,
    int		     src_max,

    int		     zero_rest
) {
    /* Resize voxels down the axis */
    /* of fastest-varying index:   */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy         = x_dim * y_dim;
    int xyXsrc_min = xy*src_min;
    int xyXdst_min = xy*dst_min;

    /* A map from destination offset to source offset in row: */
    int map[ XMRI_BUFSIZ ];

    unsigned buf[ XMRI_BUFSIZ ];

    /* Check that our buffers are big enough.  Yes,      */
    /* alloca() would be more elegant...                 */
    if (x_dim > XMRI_BUFSIZ) {
	xlerror(
	    "XMRI-RESIZE-VOXELS-AXIALLY buffer overflow, "
	    "increase XMRI_BUFSIZ and recompile."
	);
    }

    /* Initialize our map: */
    {   int dst_num   = dst_max-dst_min;
	int src_num   = src_max-src_min;
	if (dst_num <= 0)   return;
	{   float delta     = ((float)src_num) / ((float)dst_num);
	    float src_idx   = 0.5;
	    for (i = dst_min;   i < dst_max;   ++i, src_idx += delta) {
		int si = (int) src_idx;
		if (si < 0)      si = 0;
		if (si >= x_dim) si = x_dim-1;
		map[i] = si;
    }	}   }

    /* Remap each row: */
    for         (k = 0;   k < z_dim;   ++k) {
	for     (j = 0;   j < y_dim;   ++j) {

	    /* Find row we're operating on: */
	    CSRY_UNSIGNED16* p = &voxel[ j*x_dim + k*xy ];

	    /* Copy source part of row into buffer: */
    	    for (i = src_min;   i < src_max;   i++)  buf[i] = p[i];

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
	        for (i = 0;   i < dst_min;   i++)  p[i] = 0;
	    }

	    /* Copy row back, suitably remapped: */
	    for (i = dst_min; i < dst_max;   i++)  p[i] = buf[map[i]];

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
	        for (     ;   i <   x_dim;   i++)  p[i] = 0;
	    }
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolgg_Axis0 -- Filtered resizing along axis 0.			*/
 /***********************************************************************/

static void
xvolgg_Axis0(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int		     dst_min,	/* First pixel     to alter.		*/
    int		     dst_max,	/* First pixel NOT to alter. (Last+1)	*/
    int		     src_min,	/* First pixel     to use.		*/
    int		     src_max,	/* First pixel NOT to use.   (Last+1)	*/

    int		     zero_rest,
    LVAL	     lv_filter
) {
    /* Resize voxels down the axis */
    /* of slowest-varying index:   */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy         = x_dim * y_dim;
    int xyXsrc_min = xy*src_min;
    int xyXdst_min = xy*dst_min;

    short  in_buf[ XMRI_BUFSIZ ];
    short out_buf[ XMRI_BUFSIZ ];

    /* Check that our buffers are big enough.  Yes,      */
    /* alloca() would be more elegant...                 */
    if (z_dim > XMRI_BUFSIZ) {
	xlerror(
	    "XMRI-RESIZE-VOXELS-AXIALLY buffer overflow, "
	    "increase XMRI_BUFSIZ and recompile."
	);
    }

    /* Initialize filters in xzum.c: */
    xzum75_VoxelZoom_Init( dst_max-dst_min, src_max-src_min, lv_filter );

    /* Remap each hyper-row: */
    for         (j = 0;   j < y_dim;   ++j) {
	for     (i = 0;   i < x_dim;   ++i) {

	    /* Find hyper-row we're operating on: */
	    CSRY_UNSIGNED16* p = &voxel[ i + j*x_dim ];

	    /* Copy part of hyper-row into input buffer: */
	    int  x = xyXsrc_min;
    	    for (k = src_min;   k < src_max;   k += 1, x += xy)  in_buf[k] = p[x];

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
		x = 0;
	        for (k = 0;   k < dst_min;   k += 1, x += xy)  p[x] = 0;
	    }

	    /* Filter input buffer to output buffer: */
	    xzum78_VoxelZoom_Row(
		&out_buf[dst_min], &in_buf[src_min],
		dst_max-dst_min,   src_max-src_min,
		lv_filter == k_mitchell
	    );

	    /* Copy hyper-row back, suitably remapped: */
	    x = xyXdst_min;
	    for (k = dst_min; k < dst_max;   k += 1, x += xy) {
		p[x] = out_buf[k];
	    }

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
	        for (     ;   k <   z_dim;   k += 1, x += xy)  p[x] = 0;
	    }
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolgh_Axis1 -- Filtered resizing along axis 1.			*/
 /***********************************************************************/

static void
xvolgh_Axis1(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int		     dst_min,
    int		     dst_max,
    int		     src_min,
    int		     src_max,

    int		     zero_rest,
    LVAL	     lv_filter

) {
    /* Resize voxels down the axis */
    /* of medium-varying index:    */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy         = x_dim*y_dim;
    int xXsrc_min  = x_dim*src_min;
    int xXdst_min  = x_dim*dst_min;

    short  in_buf[ XMRI_BUFSIZ ];
    short out_buf[ XMRI_BUFSIZ ];

    /* Check that our buffers are big enough.  Yes,      */
    /* alloca() would be more elegant...                 */
    if (z_dim > XMRI_BUFSIZ) {
	xlerror(
	    "XMRI-RESIZE-VOXELS-AXIALLY buffer overflow, "
	    "increase XMRI_BUFSIZ and recompile."
	);
    }

    /* Initialize filters in xzum.c: */
    xzum75_VoxelZoom_Init( dst_max-dst_min, src_max-src_min, lv_filter );

    /* Remap each column: */
    for         (k = 0;   k < z_dim;   ++k) {
	for     (i = 0;   i < x_dim;   ++i) {

	    int  y;

	    /* Find column we're operating on: */
	    CSRY_UNSIGNED16* p = &voxel[ i + k*xy ];

	    /* Copy source part of column into input buffer: */
	    y = xXsrc_min;
    	    for (j = src_min;   j < src_max;   j += 1, y += x_dim)  in_buf[j] = p[y];

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
		y = 0;
	        for (j = 0;   j < dst_min;   j += 1, y += x_dim)  p[y] = 0;
	    }

	    /* Filter input buffer to output buffer: */
	    xzum78_VoxelZoom_Row(
		&out_buf[dst_min], &in_buf[src_min],
		dst_max-dst_min,   src_max-src_min,
		lv_filter == k_mitchell
	    );

	    /* Copy column back, suitably remapped: */
	    y = xXdst_min;
	    for (j = dst_min; j < dst_max;   j += 1, y += x_dim) {
		p[y] = out_buf[j];
	    }

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
	        for (     ;   j <   y_dim;   j += 1, y += x_dim)  p[y] = 0;
	    }
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolgi_Axis2 -- Filtered resizing along axis 2.			*/
 /***********************************************************************/

static void
xvolgi_Axis2(
    CSRY_UNSIGNED16* voxel,

    int              x_dim,
    int              y_dim,
    int              z_dim,

    int		     dst_min,
    int		     dst_max,
    int		     src_min,
    int		     src_max,

    int		     zero_rest,
    LVAL	     lv_filter

) {
    /* Resize voxels down the axis */
    /* of fastest-varying index:   */
    #ifndef LOGICAL_ALGORITHM

    int i;
    int j;
    int k;
    int xy         = x_dim * y_dim;
    int xyXsrc_min = xy*src_min;
    int xyXdst_min = xy*dst_min;

    short  in_buf[ XMRI_BUFSIZ ];
    short out_buf[ XMRI_BUFSIZ ];

    /* Check that our buffers are big enough.  Yes,      */
    /* alloca() would be more elegant...                 */
    if (z_dim > XMRI_BUFSIZ) {
	xlerror(
	    "XMRI-RESIZE-VOXELS-AXIALLY buffer overflow, "
	    "increase XMRI_BUFSIZ and recompile."
	);
    }

    /* Initialize filters in xzum.c: */
    xzum75_VoxelZoom_Init( dst_max-dst_min, src_max-src_min, lv_filter );

    /* Remap each row: */
    for         (k = 0;   k < z_dim;   ++k) {
	for     (j = 0;   j < y_dim;   ++j) {

	    /* Find row we're operating on: */
	    CSRY_UNSIGNED16* p = &voxel[ j*x_dim + k*xy ];

	    /* Copy source part of row into buffer: */
    	    for (i = src_min;   i < src_max;   i++)  in_buf[i] = p[i];

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
	        for (i = 0;   i < dst_min;   i++)  p[i] = 0;
	    }

	    /* Filter input buffer to output buffer: */
	    xzum78_VoxelZoom_Row(
		&out_buf[dst_min], &in_buf[src_min],
		dst_max-dst_min,   src_max-src_min,
		lv_filter == k_mitchell
	    );

	    /* Copy row back, suitably remapped: */
	    for (i = dst_min; i < dst_max;   i++)  p[i] = out_buf[i];

	    /* Maybe zero non-destination part of hyper-row: */
	    if (zero_rest) {
	        for (     ;   i <   x_dim;   i++)  p[i] = 0;
	    }
    }   }

    #else


    #endif
}

 /***********************************************************************/
 /*- xvolgk_Resize_Voxels_Axially_Fn					*/
 /***********************************************************************/

LVAL
xvolgk_Resize_Voxels_Axially_Fn(
    void
){
    Xmri_a_range r[ XMRI_MAX_RANGES ];
    int          ranges = 0;

    LVAL lv_filter   = k_impulse;
    LVAL lv_voxels   = NULL;
    LVAL lv_ary      = NULL;
    int     axis     = 0;
    int    zero_rest = FALSE;
    float  fsrcmin   = 0.0;
    float  fsrcmax   = 1.0;
    float  fdstmin   = 0.0;
    float  fdstmax   = 1.0;
    int    isrcmin;
    int    isrcmax;
    int    idstmin;
    int    idstmax;
    int     x;
    int     y;
    int     z;

    while (moreargs()) {
        LVAL lv_key = xlgasymbol();

	if (lv_key == k_voxels) {
	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;
	} else if (lv_key == k_axis) {
	    LVAL lv_axis = xlgafixnum();
	    axis = getfixnum(lv_axis);
	    if (axis < 0 || axis > 2) {
		xlerror("Bad XMRI-RESIZE-VOXELS-AXIALLY :AXIS value",lv_axis);
	    }
	} else if (lv_key == k_zero_rest) {
	    zero_rest = (xlgetarg()!=NIL);
	} else if (lv_key == k_dst_min) {
	    LVAL lv_val = xlgetarg();
	    double f    = xgbj00_Get_Fix_Or_Flo_Num(lv_val);

	    if (f < 0.0 || f > 1.0) {
		xlerror("Bad XMRI-RESIZE-VOXELS-AXIALLY :DST-MIN value",lv_val);
	    }
	    fdstmin = f;

	} else if (lv_key == k_dst_max) {
	    LVAL lv_val = xlgetarg();
	    double f    = xgbj00_Get_Fix_Or_Flo_Num(lv_val);

	    if (f < 0.0 || f > 1.0) {
		xlerror("Bad XMRI-RESIZE-VOXELS-AXIALLY :DST-MAX value",lv_val);
	    }
	    fdstmax = f;

	} else if (lv_key == k_src_min) {
	    LVAL lv_val = xlgetarg();
	    double f    = xgbj00_Get_Fix_Or_Flo_Num(lv_val);

	    if (f < 0.0 || f > 1.0) {
		xlerror("Bad XMRI-RESIZE-VOXELS-AXIALLY :SRC-MIN value",lv_val);
	    }
	    fsrcmin = f;

	} else if (lv_key == k_src_max) {
	    LVAL lv_val = xlgetarg();
	    double f    = xgbj00_Get_Fix_Or_Flo_Num(lv_val);

	    if (f < 0.0 || f > 1.0) {
		xlerror("Bad XMRI-RESIZE-VOXELS-AXIALLY :SRC-MAX value",lv_val);
	    }
	    fsrcmax = f;

	} else if (lv_key == k_filter_shape) {
	    LVAL lv_val = xlgasymbol();
	    if (lv_val == k_impulse
	    ||  lv_val == k_box
	    ||  lv_val == k_triangle
	    ||  lv_val == k_quadratic
	    ||  lv_val == k_mitchell
	    ){
		lv_filter = lv_val;
	    } else {
		xlerror("Bad XMRI-RESIZE-VOXELS-AXIALLY :FILTER-SHAPE value",lv_val);
	    }

	} else {
	    xlerror("XMRI-RESIZE-VOXELS-AXIALLY: bad keyword:",lv_key);
    }   }

    /* If lv_ary is a relation, fetch :INTENSITY array: */
    if (xgrlp(lv_ary)) {
	lv_ary = xgrl3c_Get_Array( lv_voxels, k_intensity, NIL, TRUE );
    }
    /* Make sure lv_ary is our expected 12-bit array: */
    if (!xf2vp(  lv_ary )) {
	xlerror("Bad XMRI-RESIZE-VOXELS-AXIALLY :VOXEL val.",lv_ary);
    }

    xvol95_Get_X_Y_Z_Dimensions( &x, &y, &z, lv_voxels );
    if (x != z
    ||  y != z
    ){
	xlfail("XMRI-RESIZE-VOXELS-AXIALLY: Voxel array not cubic!");
    }

    /* Convert float ranges voxel counts: */
    idstmin = (int)(0.5+fdstmin*((float)x));
    idstmax = (int)(0.5+fdstmax*((float)x));
    isrcmin = (int)(0.5+fsrcmin*((float)x));
    isrcmax = (int)(0.5+fsrcmax*((float)x));

    if (idstmin >= idstmax) xlfail("Bad XMRI-RESIZE-VOXELS-AXIALLY destination range");
    if (isrcmin >= isrcmax) xlfail("Bad XMRI-RESIZE-VOXELS-AXIALLY source range");

    if (lv_filter == k_impulse) {
	/* Get pointer to data area in voxel array: */
	CSRY_UNSIGNED16*voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );

	switch (axis) {
	#undef ARGS
	#define ARGS voxel, x,y,z, idstmin,idstmax, isrcmin, isrcmax, zero_rest
	case 0: xvolgd_Axis0( ARGS ); break;
	case 1: xvolge_Axis1( ARGS ); break;
	case 2: xvolgf_Axis2( ARGS ); break;
	default:abort();
     	}
    } else {
	/* Get pointer to data area in voxel array: */
	CSRY_UNSIGNED16*voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );

	switch (axis) {
	#undef ARGS
	#define ARGS voxel, x,y,z, idstmin,idstmax, isrcmin, isrcmax, zero_rest, lv_filter
	case 0: xvolgg_Axis0( ARGS ); break;
	case 1: xvolgh_Axis1( ARGS ); break;
	case 2: xvolgi_Axis2( ARGS ); break;
	default:abort();
     	}
    }

    return NIL;
}

/************************************************************************/
/*- xvolh0_Dump_Voxels_To_File_Fn --					*/
/************************************************************************/

LVAL
xvolh0_Dump_Voxels_To_File_Fn(
    void
){
    /* Read filename: */
    LVAL lv_filename = NULL;
    char*   filename = "dump.bin";
    int     fd;

    LVAL lv_voxels   = NULL;
    LVAL   lv_ary    = NULL;
    int     x_dim;
    int     y_dim;
    int     z_dim;

    int     as_avs = FALSE;

    float   min_x = 0.0;   float max_x = 1.0;
    float   min_y = 0.0;   float max_y = 1.0;
    float   min_z = 0.0;   float max_z = 1.0;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_filename) {

	    lv_filename = xlgastring();
	    filename = (char*) getstring( lv_filename );

	} else if (lv == k_voxels) {

	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;

	} else if (lv == k_format) {

	    LVAL lv_v = xlgetarg();
	    if (lv_v == k_avs_uniform_field) {
		as_avs = TRUE;
	    } else {
		xlerror("Bad XVOL-DUMP-VOXELS-TO-FILE :FORMAT arg.",lv_v);
	    }
	    lv_ary    = lv_voxels;

	} else if (lv == k_minx) {
	    min_x = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	} else if (lv == k_maxx) {
	    max_x = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

	} else if (lv == k_miny) {
	    min_y = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	} else if (lv == k_maxy) {
	    max_y = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

	} else if (lv == k_minz) {
	    min_z = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	} else if (lv == k_maxz) {
	    max_z = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

	} else {
	    xlerror("Bad XVOL-DUMP-VOXELS-TO-FILE keyword",lv);
    }   }
    if (!filename) xlfail("XVOL-DUMP-VOXELS-TO-FILE: missing :FILENAME keyword");

    /* If image isn't congruent with voxel */
    /* array or voxel array doesn't exist, */
    /* create a congruent voxel array:     */
    if (lv_ary && xgrlp( lv_ary )) {
	lv_ary = xgrl3c_Get_Array( lv_ary, k_intensity, NIL, TRUE );
    }
    if (lv_ary && xf2vp( lv_ary )) {
	xvol95_Get_X_Y_Z_Dimensions( &x_dim, &y_dim, &z_dim, lv_ary );
    } else {
	xlerror("Bad XVOL-DUMP-VOXELS-TO-FILE :VOXELS arg",lv_voxels);
    }

    fd  = open( filename, O_WRONLY|O_CREAT, 0644 );
    if (fd < 0)	{
	xlerror("XVOL-DUMP-VOXELS-TO-FILE can't create file",lv_filename);
    }

    if (as_avs) {

	/* Write a header that makes this into a native AVS file: */
        /* (added "creation date" line so file can be read in -- kph) */

        /* NOTE:  order of dimensions may be wrong, but it will only
	 * matter for non-cubic datasets (kph, 98Mar05)
	 */

	char buf[1024];
	sprintf(buf,
	    "# AVS field file\n"
	    "# creation date: \n"
	    "#\n"
	    "ndim=3\t# number of computational dimensions\n"
	    "dim1=%d\n"
	    "dim2=%d\n"
	    "dim3=%d\n"
	    "nspace=3\t# number of physical dimensions\n"
	    "veclen=1\n"
	    "data=short\n"
	    "field=uniform\n"
	    "\014\014",	/* Two formfeed characters */
	    x_dim, y_dim, z_dim
	);
	write( fd, buf, strlen(buf) );
    }

    {   CSRY_UNSIGNED16* voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );
	#ifdef BAD_IDEA
	int totbytes = x_dim * y_dim * z_dim * sizeof(CSRY_UNSIGNED16);
	int count    = write( fd, voxel, totbytes );
	if (count != totbytes) {
	    close(fd);
	    xlerror("Bad XVOL-DUMP-VOXELS-TO-FILE Couldn't complete write! [0]",lv_filename);
    	}
	#else
	/* Unix requires that write()s be atomic, */
	/* so writing a single 32Meg chunk tends  */
	/* to lock things up more than I like.    */
	/* Write each slice individually instead: */
	int slice_elements = x_dim * y_dim;
	int slice_bytes    = slice_elements  * sizeof(CSRY_UNSIGNED16);
	int slice;
	int count;
	for (slice = 0;   slice < z_dim;   ++slice) {
	    count = write(
		fd,
		voxel + slice * slice_elements,
		slice_bytes
	    );

	    if (count != slice_bytes) {
perror("xvolh0_Dump_Voxels_To_File_Fn failure");
fprintf(stderr,"slice d=%d slice_bytes d=%d count d=%d\n",slice,slice_bytes,count);
		close(fd);
		xlerror(
		    "Bad XVOL-DUMP-VOXELS-TO-FILE Couldn't complete write! [1]",
		    lv_filename
		);
	}   }
	#endif

	if (as_avs) {
	    /* Write the trailer that AVS expects: */
	    count = write( fd, &min_x, sizeof(min_x) );
	    count = write( fd, &max_x, sizeof(max_x) );

	    count = write( fd, &min_y, sizeof(min_y) );
	    count = write( fd, &max_y, sizeof(max_y) );

	    count = write( fd, &min_z, sizeof(min_z) );
	    count = write( fd, &max_z, sizeof(max_z) );

	    close(fd);

	    if (count != sizeof(max_z)) {
		xlerror(
		    "Bad XVOL-DUMP-VOXELS-TO-FILE Couldn't complete write! [2]",
		    lv_filename
		);
	    }
	}

        return cvfixnum(count);
    }
}

/************************************************************************/
/*- xvolha_Dump_Voxels_As_Slices_Fn --					*/
/************************************************************************/

LVAL
xvolha_Dump_Voxels_As_Slices_Fn(
    void
){
    /* Lisp name: XVOL-DUMP-VOXELS-AS-SLICES
     * 
     * Save voxels as individual slices, rather than as a single volume.
     */

    #undef         BUF_SIZE
    #define        BUF_SIZE 1024
    char  filename[BUF_SIZE];

    LVAL lv_prefix   = NULL;
    LVAL lv_suffix   = NULL;
    char*   prefix   = "image";
    char*   suffix   = ".raw";
    int     fd;

    LVAL lv_voxels   = NULL;
    LVAL lv_ary      = NULL;
    int     x_dim;
    int     y_dim;
    int     z_dim;

/*
    int     as_avs = FALSE;
    float   min_x = 0.0;   float max_x = 1.0;
    float   min_y = 0.0;   float max_y = 1.0;
    float   min_z = 0.0;   float max_z = 1.0;
*/

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_prefix) {

	    lv_prefix = xlgastring();
	    prefix = (char*) getstring( lv_prefix );

	} else if(lv == k_suffix) {

	    lv_suffix = xlgastring();
	    suffix = (char*) getstring( lv_suffix );

	} else if (lv == k_voxels) {

	    lv_voxels = xlgetarg();
	    lv_ary    = lv_voxels;
/*
	} else if (lv == k_format) {

	    LVAL lv_v = xlgetarg();
	    if (lv_v == k_avs_uniform_field) {
		as_avs = TRUE;
	    } else {
		xlerror("Bad XVOL-DUMP-VOXELS-AS-SLICES :FORMAT arg.",lv_v);
	    }
	    lv_ary    = lv_voxels;

	} else if (lv == k_minx) {
	    min_x = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	} else if (lv == k_maxx) {
	    max_x = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

	} else if (lv == k_miny) {
	    min_y = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	} else if (lv == k_maxy) {
	    max_y = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());

	} else if (lv == k_minz) {
	    min_z = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
	} else if (lv == k_maxz) {
	    max_z = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
*/
	} else {
	    xlerror("Bad XVOL-DUMP-VOXELS-AS-SLICES keyword",lv);
    }   }

    /* If image isn't congruent with voxel */
    /* array or voxel array doesn't exist, */
    /* create a congruent voxel array:     */
    if (lv_ary && xgrlp( lv_ary )) {
	lv_ary = xgrl3c_Get_Array( lv_ary, k_intensity, NIL, TRUE );
    }
    if (lv_ary && xf2vp( lv_ary )) {
	xvol95_Get_X_Y_Z_Dimensions( &x_dim, &y_dim, &z_dim, lv_ary );
    } else {
	xlerror("Bad XVOL-DUMP-VOXELS-AS-SLICES :VOXELS arg",lv_voxels);
    }

    {   CSRY_UNSIGNED16* voxel = (CSRY_UNSIGNED16*) csry_base( lv_ary );
	int slice_elements = x_dim * y_dim;
	int slice_bytes    = slice_elements  * sizeof(CSRY_UNSIGNED16);
	int slice;
	int count;

	/* Write each slice */
	for (slice = 0;   slice < z_dim;   ++slice) {
	  sprintf(filename, "%s%d%s", prefix, slice, suffix);
	  fd = open( filename, O_WRONLY|O_CREAT, 0644 );
	  if (fd < 0)	{
	    xlerror("XVOL-DUMP-VOXELS-AS-SLICES can't create file",
		    cvstring(filename));
	  }
	  count = write(fd,
			voxel + slice * slice_elements,
			slice_bytes
			);
	  close(fd);
	  if (count != slice_bytes) {
perror("xvolha_Dump_Voxels_As_Slices_Fn failure");
fprintf(stderr,"slice d=%d slice_bytes d=%d count d=%d\n",slice,slice_bytes,count);
	    xlerror(
		    "Bad XVOL-DUMP-VOXELS-AS-SLICES Couldn't complete write! [1]",
		    cvstring(filename)
		    );
	  }
	}
        return cvfixnum(count);
    }
}

/************************************************************************/
/*- xvolh2_Read_AVS_Field_From_File_Fn --				*/
/************************************************************************/

void
xvolh1_next_line(
    char*buf,
    int  bufsize,
    FILE*fd,
    LVAL lv_filename
) {
    /* AVS header ends with a double formfeed,  */
    /* so we need next_line to recognize either */
    /* newline -or- formfeed as end of line:    */
    int i;
    for (i = 0;  /*i < bufsize-1*/;  ++i) {

	int c = fgetc( fd );

	if (c == -1) {
	    buf[i] = '\0';
	    return;
	}

	buf[i] = c;

        if (c == '\n'
        ||  c == '\f'
        ||  i == bufsize-2
        ){
	    buf[i+1] = '\0';
	    return;
	}
    }
}
LVAL
xvolh2_Read_AVS_Field_From_File_Fn(
    void
){
    LVAL   lv_pix    = NULL;	/* Relation holding output pixels.	*/

    LVAL lv_filename = NULL;
    char*   filename = NULL;

    /* Most AVS labels we expect to find: */
    #undef  MAX_LABEL
    #define MAX_LABEL (4)

    /* We support reading byte, short and float fields, so far: */
    #undef  BYTE_FIELD
    #define BYTE_FIELD  (1)

    #undef  FLOAT_FIELD
    #define FLOAT_FIELD (2)

    #undef  SHORT_FIELD
    #define SHORT_FIELD (3)
    int     field_type;

    char*   label[MAX_LABEL] = { NULL, NULL, NULL, NULL };
    LVAL    lv_label[MAX_LABEL] = { NIL, NIL, NIL, NIL };
    LVAL    lv_plane[MAX_LABEL] = { NIL, NIL, NIL, NIL };
    void*      plane[MAX_LABEL] = { NULL, NULL, NULL, NULL };
    FILE*   fd;

    LVAL   lv_min_x;
    LVAL   lv_max_x;
    LVAL   lv_min_y;
    LVAL   lv_max_y;
    LVAL   lv_min_z;
    LVAL   lv_max_z;

    LVAL   lv_red;
    LVAL   lv_green;
    LVAL   lv_blue;
    LVAL   lv_depth;
    CSRY_UNSIGNED8 *pixel_red;
    CSRY_UNSIGNED8 *pixel_green;
    CSRY_UNSIGNED8 *pixel_blue;
    CSRY_UNSIGNED8 *pixel_depth;

    float   min_x = 0.0;   float max_x = 1.0;
    float   min_y = 0.0;   float max_y = 1.0;
    float   min_z = 0.0;   float max_z = 1.0;

    int        toProt = 20;
    xlstkcheck(toProt   );
    xlsave( lv_pix      );
    xlsave( lv_red      );
    xlsave( lv_green    );
    xlsave( lv_blue     );
    xlsave( lv_depth    );
    xlsave( lv_filename );
    xlsave( lv_min_x );
    xlsave( lv_max_x );
    xlsave( lv_min_y );
    xlsave( lv_max_y );
    xlsave( lv_min_z );
    xlsave( lv_max_z );
    xlsave( lv_label[0] );
    xlsave( lv_label[1] );
    xlsave( lv_label[2] );
    xlsave( lv_label[3] );
    xlsave( lv_plane[0] );
    xlsave( lv_plane[1] );
    xlsave( lv_plane[2] );
    xlsave( lv_plane[3] );

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_filename) {

	    lv_filename = xlgastring();
	    filename = (char*) getstring( lv_filename );

	} else if (lv == k_result_in) {

	    lv_pix = xlgetarg();

	} else {
	    xlerror("Bad XMRI-READ-AVS-FIELD-FROM-FILE keyword",lv);
    }   }
    if (!filename) {
	xlfail("XMRI-READ-AVS-FIELD-FROM-FILE: missing :FILENAME keyword");
    }

    /* Open file from which to read header: */
/*printf("xvolh2_Read_AVS_Field_From_File_Fn: filename s='%s'\n",filename);*/
    fd  = fopen( filename, "r" );
    if (!fd)	{
	xlerror( "Can't open file.", lv_filename );
    }


    {   int ndim;
        int height;
        int width;
        int depth = 1;
        int nspace;
        int veclen;
	int i;

        /* Read first line of file, check type: */
	#undef         LINE_BUF_SIZE
	#define        LINE_BUF_SIZE 1024
	char       buf[LINE_BUF_SIZE];	buf[0] = '\0';
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	if (strncmp(buf,"# AVS field file",16)) {
	    fclose( fd );
	    xlerror( "Not an AVS field file.", lv_filename );
	}

	/* Skip next two lines, which just contain creation date: */
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);

	/* Now process the header lines: */

	/* ndim=2	  # number of dimensions in the field		*/
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	if (1!=sscanf(buf,"ndim=%d",&ndim)) {
	    fclose( fd );
	    xlerror( "Bad 'ndim' field.", lv_filename );
	}

	/* dim1=160       # dimension of axis 1				*/
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	if (1!=sscanf(buf,"dim1=%d",&width)) {
	    fclose( fd );
	    xlerror( "Bad 'dim1' field.", lv_filename );
	}

	/* dim2=220       # dimension of axis 2				*/
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	if (1!=sscanf(buf,"dim2=%d",&height)) {
	    fclose( fd );
	    xlerror( "Bad 'dim2' field.", lv_filename );
	}

	/* dim3=140       # dimension of axis 3				*/
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	if (1==sscanf(buf,"dim3=%d",&depth)) {
	    xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	} else {
	    depth = 0;
	}

	/* nspace=3	  # number of physical coordinates per point	*/
	if (1!=sscanf(buf,"nspace=%d",&nspace)
	||  nspace!=3
	){
	    fclose( fd );
	    xlerror( "Bad 'nspace' field.", lv_filename );
	}

	/* veclen=3 or 4  # number of components at each point		*/
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	if (1!=sscanf(buf,"veclen=%d",&veclen)
#ifdef OLD
	|| (veclen!=3 && veclen !=4)
#endif
	){
	    fclose( fd );
	    xlerror( "Bad 'veclen' field.", lv_filename );
	}

	/* data=byte      # native format of sg				*/
	/* data=short     # native format of sg				*/
	/* data=float     # native format of sg				*/
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	if (!strncmp(buf,"data=byte",9)) {
	    field_type = BYTE_FIELD;
	} else if (!strncmp(buf,"data=short",10)) {
	    field_type = SHORT_FIELD;
	} else if (!strncmp(buf,"data=float",10)) {
	    field_type = FLOAT_FIELD;
        } else {
	    fclose( fd );
	    xlerror( "Not a byte, short or float field file.", lv_filename );
	}

	/* field=uniform  # field type (uniform, rectilinear, irregular)*/
	xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	if (strncmp(buf,"field=uniform",13)) {
	    fclose( fd );
	    xlerror( "Not a uniform field file.", lv_filename );
	}

	/* Now we seem to get into optional fields. */
	/* (Maybe we should be treating all the     */
	/* fields as being arbitrarily ordered?)    */
	/* AVS appears to ends this section with    */
	/* a double formfeed:                       */
	for (;;) {
	    xvolh1_next_line(buf,LINE_BUF_SIZE,fd,lv_filename);
	    if (!strcmp( buf, "\f"))   break;

	    /* AVS seems to be sometimes adding   */
	    /* min_ext= and max_ext= lines before */
	    /* the label= line.  I don't know why */
	    /* yet, so we'll just skip them if    */
	    /* present:                           */
	    if (!strncmp(buf,"min_ext=",8))  continue;
	    if (!strncmp(buf,"max_ext=",8))  continue;
	    if (!strncmp(buf,"min_val=",8))  continue;
	    if (!strncmp(buf,"max_val=",8))  continue;

	    /* label= red green blue alpha	    */
	    /* label= right superior anterior	    */
	    if (!strncmp(buf,"label=",6)) {
		/* Break out 3-4 label names.  */
		/* Save each one in label[] as */
		/* an uppercase ':'-initial,   */
		/* null-terminated string:     */
		int   i = 0;
		char* t = buf+6;
		for (i = 0;   ;   ++i) {
		    char* begin;
		    while (*t == ' ' || *t == '\t') ++t;
		    if (*t == '\n') break;
		    begin = t;
		    while (*t != ' ' && *t != '\t' && *t != '\n') ++t;
		    if (i < MAX_LABEL) {
			int len = t-begin;
			label[i] = (char*) malloc( len+2 );
			strncpy( label[i]+1, begin, len );
			label[i][0]     = ':';
			label[i][len+1] = '\0';
			{   int  j;
			    for (j = 0;   j <= len;   ++j) {
				label[i][j] = toupper( label[i][j] );
			    }
			}
		    }
		}
		continue;
	    }
	    fclose( fd );
	    xlerror( "Unrecognized header field.", lv_filename );
	}

	/* Next we should have one more formfeeds: */
	if (fgetc( fd ) != '\f'){
	    fclose( fd );
	    xlerror( "Missing formfeed in file.", lv_filename );
	}



	/* If field labels weren't supplied,   */
	/* fill in default values: :PIXEL-     */
	/* RED GREEN BLUE ALPHA for bytes,     */
        /* :RIGHT :SUPERIOR :ANTERIOR for flts */
	switch (field_type) {

	case BYTE_FIELD:
	    /* Default order used to be RGBA, but    */
	    /* AVS appears to have changed to ARGB: */
	    if (!label[0])   label[0] = ":PIXEL-ALPHA";
	    if (!label[1])   label[1] = ":PIXEL-RED";
	    if (!label[2])   label[2] = ":PIXEL-GREEN";
	    if (!label[3])   label[3] = ":PIXEL-BLUE";
	    /* And now for a -really- ugly backward-compability hack: */
	    if (!strcmp(label[0],":DEPTH"))   label[0] = ":PIXEL-ALPHA";
	    if (!strcmp(label[1],":RED"  ))   label[1] = ":PIXEL-RED";
	    if (!strcmp(label[2],":GREEN"))   label[2] = ":PIXEL-GREEN";
	    if (!strcmp(label[3],":BLUE" ))   label[3] = ":PIXEL-BLUE";
	    break;

	case SHORT_FIELD:
	    /* We're only using this for reading :intensity */
	    /* voxel arrays, at present: */
	    /* AVS appears to have changed to ARGB: */
	    if (!label[0])   label[0] = ":INTENSITY";
	    if (!label[1])   label[1] = ":XXX";	/* Nothing depends on these */
	    if (!label[2])   label[2] = ":YYY";
	    if (!label[3])   label[3] = ":ZZZ";
	    break;

	case FLOAT_FIELD:
	    if (!label[0])   label[0] = ":RIGHT";
	    if (!label[1])   label[1] = ":SUPERIOR";
	    if (!label[2])   label[2] = ":ANTERIOR";
	    if (!label[3])   label[3] = ":MYSTERY"; /* Should never be used? */
	    break;
	}



	/* Convert field labels to symbols: */
	{   int i;
	    for (i = 0;   i < MAX_LABEL;   ++i) {
		lv_label[i] = xlenter( label[i] );
	}   }

	/* Make sure lv_pix is a graphic relation  */
	/* of appropriate shape, creating a new    */
        /* one if it is not:                       */
	if (!      lv_pix
	||  !xgrlp(lv_pix)
	||  !xvol94_Check_X_And_Y_Dimensions(lv_pix,width,height,depth)
	){
	    /* Create graphic relation to hold result: */
	    switch (ndim) {
	    case 2:
/*printf("xvolh2_Read_AVS_Field_From_File_Fn/2 creating pixels...\n");*/
		lv_pix = xvol87_Create_Pixels(
		    height,	/*rows*/
		    width,	/*cols*/
		    NULL
		);
		break;
	    
	    case 3:
/*printf("xvolh2_Read_AVS_Field_From_File_Fn/3 creating pixels...\n");*/
		lv_pix = xvol88_Create_Voxels(
		    height,
		    width,
		    depth,
		    NULL
		);
	    }
	}

	/* Make sure lv_pix contains properly */
	/* typed and shaped arrays:           */

	switch (field_type) {

	case BYTE_FIELD:
/*printf("xvolh2_Read_AVS_Field_From_File_Fn/BYTE...\n");*/
	    for (i = 0;   i < veclen;   ++i) {
		lv_plane[i] = xgrl3c_Get_Array(
                    lv_pix,
                    lv_label[i],
                    NIL,
                    TRUE
                );
		if (!lv_plane[i]
		||  !xf8vp(lv_plane[i])
		||  !xvol94_Check_X_And_Y_Dimensions(lv_plane[i],width,height,0)
		){
		    plane[i] = xvol86_Create_Plane(
			lv_pix,
			lv_label[i],
			height,
			width,
			lv_xf8v
		    );
		} else {
		    plane[i] = (void*) csry_base( lv_plane[i] );
		}
	    }
	    break;

	case SHORT_FIELD:
/*printf("xvolh2_Read_AVS_Field_From_File_Fn/SHORT...\n");*/
	    for (i = 0;   i < veclen;   ++i) {
		lv_plane[i] = xgrl3c_Get_Array(
                    lv_pix,
                    lv_label[i],
                    NIL,
                    TRUE
                );
		if (!lv_plane[i]
		||  !xf2vp(lv_plane[i])
		||  !xvol94_Check_X_And_Y_Dimensions(lv_plane[i],width,height,depth)
		){
		    plane[i] = xvol8d_Create_Volume(
			lv_pix,
			lv_label[i],
			height,
			width,
			depth,
			lv_xf2v
		    );
		} else {
		    plane[i] = (void*) csry_base( lv_plane[i] );
		}
	    }
	    break;

	case FLOAT_FIELD:
/*printf("xvolh2_Read_AVS_Field_From_File_Fn/FLOAT...\n");*/
	    for (i = 0;   i < veclen;   ++i) {
		lv_plane[i] = xgrl3c_Get_Array(
                    lv_pix,
                    lv_label[i],
                    NIL,
                    TRUE
                );
		if (!lv_plane[i]
		||  !xflvp(lv_plane[i])
		||  !xvol94_Check_X_And_Y_Dimensions(lv_plane[i],width,height,0)
		){
		    plane[i] = xvol86_Create_Plane(
			lv_pix,
			lv_label[i],
			height,
			width,
			lv_xflv
		    );
		} else {
		    plane[i] = (void*) csry_base( lv_plane[i] );
		}
	    }
	    break;
	}


	/* Now we have the actual rectangular array of  */
	/* interleaved r/g/b/z byte values or whatever: */
	#undef        BUF_SIZE
	#define       BUF_SIZE 0x10000
/*printf("xvolh2_Read_AVS_Field_From_File_Fn/reading...\n");*/
	{   char buf[ BUF_SIZE ];
	    int  d;
	    int  r;
	    int  row_bytes;
	    int  size_of_element;

	    switch (field_type) {
	    case BYTE_FIELD:  size_of_element = sizeof(char);  break;
	    case SHORT_FIELD: size_of_element = sizeof(short); break;
	    case FLOAT_FIELD: size_of_element = sizeof(float); break;
	    }

	    row_bytes = width * size_of_element * veclen;

	    if  (row_bytes > BUF_SIZE) {
		fclose( fd );
		xlerror( "Yikes, buffer overflow reading file.", lv_filename );
	    }

	    /* Only using images before, but try this for volumes */
	    /* (kph, 98Jan26) */
	    for (d = 0;  d < depth;  ++d) {

	    /* Over all rows in image: */

	    /* Read row into buffer: */
	    for (r = 0;   r < height;   ++r) {
		int bytes_read  = fread( buf, 1, row_bytes, fd );
		if (bytes_read != row_bytes) {
		    fclose( fd );
		    xlerror( "Error reading image data in file.", lv_filename);
		}

		/* Unpack four-way interleaved buffer row: */
		switch (field_type) {

		case BYTE_FIELD:
		    {   int offset = ((height-1)-r) * width;
			char* p  = buf;
			int  i;
			for (i = 0;   i < width;   ++i, ++offset) {
			    int  v;
			    for (v = 0;   v < veclen;   ++v) {
				char el = *p++;
				((char*)plane[v])[ offset ] = el;
			    }
		    }	}
		    break;

		/* Trying to fill in missing case.  I had to change 
		 * the offset computation to get proper orientation.  
		 * (kph, 98Jan23)
		 */
		case SHORT_FIELD:
		    {   
		      /* int offset = ((height-1)-r) * width; */
			int offset = (r * width) +
			             (d * width * height);
			short* p  = (short*)buf;
			int  i;
			for (i = 0;   i < width;   ++i, ++offset) {
			    int  v;
			    for (v = 0;   v < veclen;   ++v) {
				short el = *p++;
				((short*)plane[v])[ offset ] = el;
			    }
		    }	}
		    break;

		case FLOAT_FIELD:
		    {   int offset = ((height-1)-r) * width;
			float* p  = (float*)buf;
			int  i;
			for (i = 0;   i < width;   ++i, ++offset) {
			    int  v;
			    for (v = 0;   v < veclen;   ++v) {
				float el = *p++;
				((float*)plane[v])[ offset ] = el;
			    }
		    }	}
		    break;
		}
	      }
	  }
	  }

	/* Finally, we may have six floats giving */
	/* the min/max location along each axis.  */
	/* As an interim hack, we read this info  */
	/* for byte fields but not float ones,    */
	/* which gives the results we need for    */
	/* the moment when loading Bharath's      */
	/* brain-image fields;  This isn't a very */
	/* satisfactory solution for more general */
	/* use, however.                          */
	switch (field_type) {

/* On older datasets, we were getting the bounding box */
/* info off the bytefield, but in the latest iteration,*/
/* this appears to be junk, with the good bounding box */
/* info on the float field.  96Jan23jsp.               */
	case BYTE_FIELD:
/*{float min_x,max_x,min_y,max_y,min_z,max_z;*/
	    if (fread( &min_x, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &max_x, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &min_y, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &max_y, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &min_z, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &max_z, 1, sizeof(float), fd ) != sizeof(float)
	    ){
		fclose( fd );
		xlerror( "Error reading bounding box from file.", lv_filename);
	    }
/*printf("byte_field:\n");*/
/*printf("    min_x: %g\n",min_x);*/
/*printf("    max_x: %g\n",max_x);*/
/*printf("    min_y: %g\n",min_y);*/
/*printf("    max_y: %g\n",max_y);*/
/*printf("    min_z: %g\n",min_z);*/
/*printf("    max_z: %g\n",max_z);*/
/*}*/
	    break;

	case FLOAT_FIELD:
	    if (fread( &min_x, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &max_x, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &min_y, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &max_y, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &min_z, 1, sizeof(float), fd ) != sizeof(float)
	    ||  fread( &max_z, 1, sizeof(float), fd ) != sizeof(float)
	    ){
		fclose( fd );
		xlerror( "Error reading bounding box from file.", lv_filename);
	    }
/*printf("float_field:\n");*/
/*printf("    min_x: %g\n",min_x);*/
/*printf("    max_x: %g\n",max_x);*/
/*printf("    min_y: %g\n",min_y);*/
/*printf("    max_y: %g\n",max_y);*/
/*printf("    min_z: %g\n",min_z);*/
/*printf("    max_z: %g\n",max_z);*/

            #ifdef OLD
	    /* Attach above info to result relation.  */
	    /* We negate the x and z coords because   */
	    /* I want to do 3-D graphics in a natural */
	    /* way in the resulting space, and SGI(?) */
	    /* will do a mirror operation if the top  */
	    /* coord is less than the bottom coord or */
	    /* such.  We'll need to remember to undo  */
	    /* this if we ever need to match the MRI  */
	    /* machine coordinate system exactly.     */
	    lv_min_x = cvflonum( -min_x );
	    lv_max_x = cvflonum( -max_x );
	    lv_min_y = cvflonum(  max_y );
	    lv_max_y = cvflonum(  min_y );
	    lv_min_z = cvflonum( -min_z );
	    lv_max_z = cvflonum( -max_z );
            #endif
            #ifdef OLD
	    /* Dunno why, but on the latest iteration,  */
	    /* the bounding box info seems to be coming */
	    /* through sorted as I'd expect. ?!?!       */
	    lv_min_x = cvflonum(  min_x );
	    lv_max_x = cvflonum(  max_x );
	    lv_min_y = cvflonum(  min_y );
	    lv_max_y = cvflonum(  max_y );
	    lv_min_z = cvflonum(  min_z );
	    lv_max_z = cvflonum(  max_z );
/* printf("xvolh2_Read_AVS_Field_From_File_Fn:\n");*/
/* printf("    min_x: %g\n",min_x);*/
/* printf("    max_x: %g\n",max_x);*/
/* printf("    min_y: %g\n",min_y);*/
/* printf("    max_y: %g\n",max_y);*/
/* printf("    min_z: %g\n",min_z);*/
/* printf("    max_z: %g\n",max_z);*/

	    {   LVAL*pPropList  = x03d73_pPropList( lv_pix );
		xthl82_SetProp( pPropList, k_minx, lv_min_x );
		xthl82_SetProp( pPropList, k_maxx, lv_max_x );
		xthl82_SetProp( pPropList, k_miny, lv_min_y );
		xthl82_SetProp( pPropList, k_maxy, lv_max_y );
		xthl82_SetProp( pPropList, k_minz, lv_min_z );
		xthl82_SetProp( pPropList, k_maxz, lv_max_z );
	    }
            #endif
	}

	/* For now, at least, I give up: the  */
	/* bounding box info keeps changing   */
	/* around in ways I cannot anticipate */
	/* control or understand.  So we'll   */
	/* do our best to recover the bound-  */
	/* ing box info from the contents of  */
	/* the RSA arrays:                    */
	if (field_type == FLOAT_FIELD) {
	    int row, col;
	    float min_r =  10000000.0;
	    float max_r = -10000000.0;
	    float min_s =  10000000.0;  int min_s_row = 0;
	    float max_s = -10000000.0;  int max_s_row = 0;
	    float min_a =  10000000.0;  int min_a_col = 0;
	    float max_a = -10000000.0;  int max_a_col = 0;
	    float lo_a, hi_a;
	    float lo_s, hi_s;
	    for (row = 0;  row < height;   ++row) {
		int offset = row * width;
		for (col = 0;   col < width;   ++col) {
		    float r = ((float*)plane[0])[ offset+col ];
		    float s = ((float*)plane[1])[ offset+col ];
		    float a = ((float*)plane[2])[ offset+col ];
		    if (r != 0.0 || s != 0.0 || a != 0.0) {
			if (r < min_r) { min_r = r; }
			if (r > max_r) { max_r = r; }
			if (a < min_a) { min_a = a; min_a_col = col; }
			if (a > max_a) { max_a = a; max_a_col = col; }
			if (s < min_s) { min_s = s; min_s_row = row; }
			if (s > max_s) { max_s = s; max_s_row = row; }
		    }
/*if (!row || row==(height>>2) || row==(height>>1) || (row-1)==(height>>1)) {*/
/*printf("row %3d col %3d r %g s %g a %g\n",row,col,r,s,a);*/
/*}*/
	        }
	    }
/*printf("min_r %g max_r %g\n",min_r,max_r);	    */
/*printf("min_s %g max_s %g (rows %d %d)\n",min_s,max_s,min_s_row,max_s_row);	    */
/*printf("min_a %g max_a %g (cols %d %d)\n",min_a,max_a,min_a_col,max_a_col);	    */
	    /* Extrapolate bounding box from values we found: */
	    lo_a = max_a - (max_a-min_a)*(((float)max_a_col)/((float)(max_a_col-min_a_col)));
	    hi_a = min_a + (max_a-min_a)*(((float)(width-min_a_col))/((float)(max_a_col-min_a_col)));
	    lo_s = max_s - (max_s-min_s)*(((float)max_s_row)/((float)(max_s_row-min_s_row)));
	    hi_s = min_s + (max_s-min_s)*(((float)(height-min_s_row))/((float)(max_s_row-min_s_row)));
/*printf("xvolh2_Read_AVS_Field_From_File_Fn:\n");*/
/*printf("lo_a %g hi_a %g\n",lo_a,hi_a);*/
/*printf("lo_s %g hi_s %g\n",lo_s,hi_s);*/
/*printf("min_r %g max_r %g\n",min_r,max_r);*/

	    lv_min_x = cvflonum( -lo_a );
	    lv_max_x = cvflonum( -hi_a );
	    lv_min_y = cvflonum(  lo_s );
	    lv_max_y = cvflonum(  hi_s );
	    lv_min_z = cvflonum( -max_r );
	    lv_max_z = cvflonum( -min_r );

	    {   LVAL*pPropList  = x03d73_pPropList( lv_pix );
		xthl82_SetProp( pPropList, k_minx, lv_min_x );
		xthl82_SetProp( pPropList, k_maxx, lv_max_x );
		xthl82_SetProp( pPropList, k_miny, lv_min_y );
		xthl82_SetProp( pPropList, k_maxy, lv_max_y );
		xthl82_SetProp( pPropList, k_minz, lv_min_z );
		xthl82_SetProp( pPropList, k_maxz, lv_max_z );
	    }
	}
    }
    fclose( fd );
    xlpopn(toProt);
    return lv_pix;
}

/************************************************************************/
/*- xvolh6_Resample_Volume_Fn --					*/
/************************************************************************/

void
xvolh5_resample_volume(

    unsigned char* point_r,	/* Result red/green/blue */
    unsigned char* point_g,	/* values for the given  */
    unsigned char* point_b,	/* sample points.        */

    float*         point_x,	/* Location of the       */
    float*         point_y,     /* sample points in	 */
    float*         point_z,	/* space.                */

    int            point_len,	/* Len of point_* arrays */

    CSRY_UNSIGNED16* voxel,	/* 3-D voxel array	 */
    int    x_dim,		/* Dimensions of 'voxel' */
    int    y_dim,
    int    z_dim,

    float* red,			/* These four map from   */
    float* grn,			/* voxel density values  */
    float* blu,			/* to color information. */
    float* alf,			/*                       */

    geo_matrix* mat		/* 4x4 transform matrix  */
){
    float     r;
    float     g;
    float     b;

    float     x_dim2 = (float)(x_dim >> 1);
    float     y_dim2 = (float)(y_dim >> 1);
    float     z_dim2 = (float)(z_dim >> 1);

    int       row;
    int       col;
    int       lev;

    int       offset;

    int       intensity;

    geo_point p;

    /* Over all given points: */
    int  i;
    for (i = 0;   i < point_len;   ++i) {

	/* Transform given point by given matrix: */
	p.x = point_x[i];
	p.y = point_y[i];
	p.z = point_z[i];
	lib26_Matrix_Apply_To_Point( &p, &p, mat );



	/* Convert point into integer voxel indices: */

	row = (int) (y_dim2 * (p.y + 1.0));
	col = (int) (x_dim2 * (p.x + 1.0));
	lev = (int) (z_dim2 * (p.z + 1.0));

	if (row < 0)   row = 0;
	if (col < 0)   col = 0;
	if (lev < 0)   lev = 0;

	if (row >= y_dim)   row = y_dim-1;
	if (col >= x_dim)   col = x_dim-1;
	if (lev >= z_dim)   lev = z_dim-1;



	/* Convert voxel indices into linear address: */
	offset = (lev*y_dim + row) * x_dim + col;

	/* Fetch voxel intensity for that voxel: */
	intensity = voxel[ offset ];

	/* Map voxel intensity to RGB values: */
	r = red[ intensity ];
	g = grn[ intensity ];
	b = blu[ intensity ];

	/* Save as unsigned char values in result relation: */
	point_r[ i ] = (unsigned char)( r * 255.99 );
	point_g[ i ] = (unsigned char)( g * 255.99 );
	point_b[ i ] = (unsigned char)( b * 255.99 );
    }
}
LVAL
xvolh6_Resample_Volume_Fn(
    void
){
    LVAL xtfm01_Get_A_XTFM();
#ifdef OLD
    geo_matrix* mat  = NULL;
#else
    /* Default to identity matrix: */
    geo_matrix* mat  = &xtfm___defaults.m;
#endif

    int     x_dim;
    int     y_dim;
    int     z_dim;

    LVAL lv_voxels   = NULL;
    LVAL lv_voxary   = NULL;

    LVAL lv_result   = NULL;
    int  result_len  = 0;

    LVAL lv_transf   = NULL;

    LVAL lv_filter   = k_impulse;

    LVAL lv_rrl      = NULL;	/* Rendering relation.			*/
    LVAL lv_red;		/* From rendering relation.		*/
    LVAL lv_grn;		/* "                        "		*/
    LVAL lv_blu;		/* "                        "		*/
    LVAL lv_alf;		/* "                        "		*/
    float*  red;		/* Pointer to data in lv_red above.	*/
    float*  grn;		/* "                  lv_grn      "	*/
    float*  blu;		/* "                  lv_blu      "	*/
    float*  alf;		/* "                  lv_alf      "	*/

    unsigned char* point_r;
    unsigned char* point_g;
    unsigned char* point_b;

    float* point_x;
    float* point_y;
    float* point_z;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_voxels) {

	    lv_voxels = xlgetarg();
	    lv_voxary = lv_voxels;

	} else if (lv == k_result_in) {

	    csry_rec* h;
	    int       i;
	    lv_result = xgrl01_Get_A_XGRL();
	    xthl42_GetPointXYZ(
		&point_x,
		&point_y,
		&point_z,
		lv_result
	    );
	    h = xsry9c_Find_Immediate_Base( lv_result );
	    result_len = h->size;
	    /* Respect fill pointer if present: */
	    if (h->rank == 1   &&   (i=h->dim[1]) >= 0)     result_len = i;

	} else if (lv == k_transform) {

	    lv_transf = xtfm01_Get_A_XTFM();
	    mat       = xtfm9b_Find_Matrix( lv_transf );

	} else if (lv == k_rendering_relation) {

	    lv_rrl    = xlgetarg();

	} else if (lv == k_filter_shape) {
	    LVAL lv_val = xlgasymbol();
	    if (lv_val == k_impulse
	    ||  lv_val == k_box
	    ||  lv_val == k_triangle
	    ||  lv_val == k_quadratic
	    ||  lv_val == k_mitchell
	    ){
		lv_filter = lv_val;
	    } else {
		xlerror("Bad XMRI-RESAMPLE-VOLUME :FILTER-SHAPE value",lv_val);
	    }

	} else {
	    xlerror("Bad XMRI-RESAMPLE-VOLUME keyword",lv);
    }   }
    if (!lv_voxels) xlfail("XMRI-RESAMPLE-VOLUME: missing :VOXELS keyword");
    if (!lv_result) xlfail("XMRI-RESAMPLE-VOLUME: missing :RESULT-IN keyword");
    if (!lv_transf) xlfail("XMRI-RESAMPLE-VOLUME: missing :TRANSFORM keyword");

    /* If image isn't congruent with voxel */
    /* array or voxel array doesn't exist, */
    /* create a congruent voxel array:     */
    if (lv_voxary && xgrlp( lv_voxary )) {
	lv_voxary = xgrl3c_Get_Array( lv_voxary, k_intensity, NIL, TRUE );
    }
    if (lv_voxary && xf2vp( lv_voxary )) {
	xvol95_Get_X_Y_Z_Dimensions( &x_dim, &y_dim, &z_dim, lv_voxary );
    } else {
	xlerror("Bad XMRI-RESAMPLE-VOLUME :VOXELS arg",lv_voxels);
    }
    if ((x_dim != 128 && x_dim != 256)
    ||   x_dim != y_dim
    ||   x_dim != z_dim
    ){
	xlerror("XMRI-RESAMPLE-VOLUME :VOXELS arg must be 128^3 or 256^3",lv_voxels);
    }

    /* Unpack and check render-relation:      */
    /* Make sure lv_rrl is a graphic relation */
    /* with appropriate arrays:               */
    if (lv_rrl) {
	if (!xgrlp(lv_rrl)
	||  !(     lv_red = xgrl3c_Get_Array(lv_rrl, k_diffuse_red  , NIL, TRUE))
	||  !xflvp(lv_red)
	||  !(     lv_grn = xgrl3c_Get_Array(lv_rrl, k_diffuse_green, NIL, TRUE))
	||  !xflvp(lv_grn)
	||  !(     lv_blu = xgrl3c_Get_Array(lv_rrl, k_diffuse_blue , NIL, TRUE))
	||  !xflvp(lv_blu)
	||  !(     lv_alf = xgrl3c_Get_Array(lv_rrl, k_alpha        , NIL, TRUE))
	||  !xflvp(lv_alf)
	||  !xvole3_Check_Dimension( lv_red, 4096 )
	||  !xvole3_Check_Dimension( lv_grn, 4096 )
	||  !xvole3_Check_Dimension( lv_blu, 4096 )
	||  !xvole3_Check_Dimension( lv_alf, 4096 )
	){
	    xlfail("XMRI-RESAMPLE-VOLUME: bad :RENDERING-RELATION value");
	}
	/* Locate the actual float buffers within red/grn/blu/alpha arrays: */
	red = (float*) csry_base( lv_red );
	grn = (float*) csry_base( lv_grn );
	blu = (float*) csry_base( lv_blu );
	alf = (float*) csry_base( lv_alf );
    }

    /* For now, we require r/g/b result arrays: */
    xthl44_GetPointRedGreenBlue(
	&point_r,
	&point_g,
	&point_b,
	lv_result
    );

    {   CSRY_UNSIGNED16* voxel = (CSRY_UNSIGNED16*) csry_base( lv_voxary );
	xvolh5_resample_volume(
	    point_r, point_g, point_b,
	    point_x, point_y, point_z,
	    result_len,
	    voxel, x_dim, y_dim, z_dim,
	    red, grn, blu, alf,
	    mat
	);
    }
    return NIL;
}

/************************************************************************/
/*- xvolh9_Transform_Volume_Fn --					*/
/************************************************************************/

void
xvolh8_transform_volume(

    CSRY_UNSIGNED16* result,	/* 3-D voxel array	  */
    int    x_ut,		/* Dimensions of 'result' */
    int    y_ut,
    int    z_ut,

    CSRY_UNSIGNED16* voxel,	/* 3-D voxel array	  */
    int    x_in,		/* Dimensions of 'voxel'  */
    int    y_in,
    int    z_in,

    geo_matrix* mat		/* 4x4 transform matrix   */
){
    int x_ut2 = (x_ut >> 1);
    int y_ut2 = (y_ut >> 1);
    int z_ut2 = (z_ut >> 1);

    int x_in2 = (x_in >> 1);
    int y_in2 = (y_in >> 1);
    int z_in2 = (z_in >> 1);

    int       xi, yi, zi;
    int       xu, yu, zu;

    geo_point p;

    float     x_ut_inv2 = 2.0 / (float)x_ut;
    float     y_ut_inv2 = 2.0 / (float)y_ut;
    float     z_ut_inv2 = 2.0 / (float)z_ut;

    float     x_in2f = 0.5 * (float)x_ut;
    float     y_in2f = 0.5 * (float)y_ut;
    float     z_in2f = 0.5 * (float)z_ut;

    int intensity;

    /* Over all voxels in output volume: */
    for         (xu = 0;   xu < x_ut;   ++xu) {
        for     (yu = 0;   yu < y_ut;   ++yu) {
            for (zu = 0;   zu < z_ut;   ++zu) {

		/* Convert voxel indices to [-1,1]^3 */
	        /* parametric coordinates:           */
		p.x = (float)(xu-x_ut2) * x_ut_inv2;
		p.y = (float)(yu-y_ut2) * y_ut_inv2;
		p.z = (float)(zu-z_ut2) * z_ut_inv2;


		/* Transform given point by given matrix: */
		lib26_Matrix_Apply_To_Point( &p, &p, mat );

		/* Transform resulting [-1,1]^3 */
                /* parametric coords into input */
		/* matrix voxel coords:         */
		xi = (unsigned)(((int)( p.x*x_in2f /*round:*/+0.5 ))+x_in2);
		yi = (unsigned)(((int)( p.y*y_in2f /*round:*/+0.5 ))+y_in2);
		zi = (unsigned)(((int)( p.z*z_in2f /*round:*/+0.5 ))+z_in2);

		/* Impulse-sample input matrix, defaulting */
		/* to zero when outside of it:             */
		intensity = 0;
		if ((unsigned)xi < (unsigned)x_in
		&   (unsigned)yi < (unsigned)y_in
		&   (unsigned)zi < (unsigned)z_in
		){
		    /* Convert voxel indices into linear address: */
		    intensity = voxel[ (zi*y_in + yi)*x_in + xi ];
		}

		result[ (zu*y_ut + yu)*x_ut + xu ] = intensity;
	    }
	}
    }
}
LVAL
xvolh9_Transform_Volume_Fn(
    void
){
    LVAL xtfm01_Get_A_XTFM();
    /* Default to identity matrix: */
    geo_matrix* mat  = &xtfm___defaults.m;

    int     x_in;
    int     y_in;
    int     z_in;

    int     x_out;
    int     y_out;
    int     z_out;

    LVAL lv_voxels   = NULL;
    LVAL lv_voxary   = NULL;

    LVAL lv_result   = NULL;

    LVAL lv_transf   = NULL;

    LVAL lv_filter   = k_impulse;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_voxels) {

	    lv_voxels = xlgetarg();
	    lv_voxary = lv_voxels;

	} else if (lv == k_result_in) {

	    lv_result = xlgetarg();

	} else if (lv == k_transform) {

	    lv_transf = xtfm01_Get_A_XTFM();
	    mat       = xtfm9b_Find_Matrix( lv_transf );

	} else if (lv == k_filter_shape) {
	    LVAL lv_val = xlgasymbol();
	    if (lv_val == k_impulse
	    ||  lv_val == k_box
	    ||  lv_val == k_triangle
	    ||  lv_val == k_quadratic
	    ||  lv_val == k_mitchell
	    ){
		lv_filter = lv_val;
	    } else {
		xlerror("Bad XMRI-TRANSFORM-VOLUME :FILTER-SHAPE value",lv_val);
	    }

	} else {
	    xlerror("Bad XMRI-TRANSFORM-VOLUME keyword",lv);
    }   }
    if (!lv_voxels) xlfail("XMRI-TRANSFORM-VOLUME: missing :VOXELS keyword");
    if (!lv_result) xlfail("XMRI-TRANSFORM-VOLUME: missing :RESULT-IN keyword");
    if (!lv_transf) xlfail("XMRI-TRANSFORM-VOLUME: missing :TRANSFORM keyword");

    /* Validate :voxels array: */
    if (lv_voxary && xgrlp( lv_voxary )) {
	lv_voxary = xgrl3c_Get_Array( lv_voxary, k_intensity, NIL, TRUE );
    }
    if (lv_voxary && xf2vp( lv_voxary )) {
	xvol95_Get_X_Y_Z_Dimensions( &x_in, &y_in, &z_in, lv_voxary );
    } else {
	xlerror("Bad XMRI-TRANSFORM-VOLUME :VOXELS arg",lv_voxels);
    }
    if ((x_in != 128 && x_in != 256)
    ||   x_in != y_in
    ||   x_in != z_in
    ){
	xlerror("XMRI-TRANSFORM-VOLUME :VOXELS arg must be 128^3 or 256^3",lv_voxels);
    }

    /* Validate :result-in array: */
    if (lv_result && xgrlp( lv_result )) {
	lv_result = xgrl3c_Get_Array( lv_result, k_intensity, NIL, TRUE );
    }
    if (lv_result && xf2vp( lv_result )) {
	xvol95_Get_X_Y_Z_Dimensions( &x_out, &y_out, &z_out, lv_result );
    } else {
	xlerror("Bad XMRI-TRANSFORM-VOLUME :RESULT-IN arg",lv_result);
    }
    if ((x_out != 128 && x_out != 256)
    ||   x_out != y_out
    ||   x_out != z_out
    ){
	xlerror("XMRI-TRANSFORM-VOLUME :RESULT-IN arg must be 128^3 or 256^3",lv_result);
    }

    if (lv_voxary == lv_result) {
	xlerror(
	    "XMRI-TRANSFORM-VOLUME :RESULT-IN must not be same as :VOXELS"
	    ,lv_result
	);
    }

    {   CSRY_UNSIGNED16* voxel  = (CSRY_UNSIGNED16*) csry_base( lv_voxary );
        CSRY_UNSIGNED16* result = (CSRY_UNSIGNED16*) csry_base( lv_result );
	xvolh8_transform_volume(
	    result, x_out, y_out, z_out,
	    voxel,  x_in,  y_in,  z_in,
	    mat
	);
    }
    return NIL;
}

/************************************************************************/
/*- xvoljz_Insert_Isosurface_Fn --					*/
/************************************************************************/

/* Tables				*/
/*     xvolj0_triangles_needed[ 256 ]	*/
/*     xvolj1_vertices_needed[  256 ]	*/
/*     xvolj2_fn[               256 ]	*/
/* are mechanically generated by	*/
/* xvol-codegen.c and live in		*/
/* xvol-code.c.				*/

extern int xvolj0_triangles_needed[ 256 ];
extern int xvolj1_vertices_needed[  256 ];
extern void
(*xvolj2_fn[256])(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
);

void
xvolj8_insert_isosurface(

    LVAL   lv_thing,
    int    *points_to_insert,
    int    *facets_to_insert,

    CSRY_UNSIGNED16* voxel,	/* 3-D voxel array	  */
    int    x_in,		/* Dimensions of 'voxel'  */
    int    y_in,
    int    z_in,

    int    iso,
    int    pass2,	/* FALSE => we count; TRUE => we insert. */
    int    min_i, int max_i,
    int    min_j, int max_j,
    int    min_k, int max_k
){
    int  pbase = 0;
    int  fbase = 0;

    int        f = 0;	/* facet */
    int        p = 0;	/* point */

    LVAL       lv_pointGrl;
    LVAL       lv_facetGrl;
    gt_tri_rec r;
    int       interesting_voxels = 0;
    int       y_in_x_in = y_in*x_in;
    int       xi, yi, zi;

    if (pass2) {
	xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
	xthlB1_Process_Thing( &r, lv_thing );

	/* Find our relations: */
	if (r.got_points) {
	    lv_pointGrl   = xthlA2_Get_Point_Relation_From_Thing( lv_thing );
	} else {
	    return;
	}
	if (r.got_segments) {
	    lv_facetGrl   = xthlA4_Get_Facet_Relation_From_Thing( lv_thing );
	} else {
	    f = 0;
	}

	if (r.got_points)   pbase = xthlEf_Resize_Grl( lv_pointGrl, *points_to_insert );
	if (r.got_segments) fbase = xthlEf_Resize_Grl( lv_facetGrl, *facets_to_insert );

	/* Reload r, because resizing may have moved (realloc()ed) stuff in ram: */
	xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
	xthlB1_Process_Thing( &r, lv_thing );
/* Buggo, need to issue an error if we get anything */
/* other than a thing of triangles. */
    }

    /* Over all voxels in input volume: */
    /************************************/
    /* Note that if we iterate in zyx   */
    /* order, the cache is our friend,  */
    /* but if we iterate in xyz order   */
    /* here the cache is NOT our friend:*/
    /* During early testing, I clocked  */
    /* pass0 at 7.1secs in xyz order,   */
    /* but   at 1.7secs in zyx order!   */
    /* (128^3 MRI dataset MC9602.)      */
    /* Polygon insertion on same dataset*/
    /* took 2.0secs, so the above code  */
    /* change tripled overall speed.    */
    /************************************/
    for         (zi = min_k+1;   zi < max_k;   ++zi) {
        for     (yi = min_j+1;   yi < max_j;   ++yi) {
            for (xi = min_i+1;   xi < max_i;   ++xi) {
                CSRY_UNSIGNED16* vox111 = &voxel[ (zi*y_in + yi)*x_in + xi ];
		int val111   = vox111[                       0  ];
		int val110   = vox111[ - (                   1) ];
		int val101   = vox111[ - (            x_in    ) ];
		int val011   = vox111[ - (y_in_x_in           ) ];
		int val001   = vox111[ - (y_in_x_in + x_in    ) ];
		int val010   = vox111[ - (y_in_x_in        + 1) ];
		int val100   = vox111[ - (            x_in + 1) ];
		int val000   = vox111[ - (y_in_x_in + x_in + 1) ];
		int signature = (
		    ((val111 > iso) << 7)	|
		    ((val110 > iso) << 6)	|
		    ((val101 > iso) << 5)	|
		    ((val100 > iso) << 4)	|
		    ((val011 > iso) << 3)	|
		    ((val010 > iso) << 2)	|
		    ((val001 > iso) << 1)	|
		    ((val000 > iso)     )
		);
		int triangles_needed = xvolj0_triangles_needed[ signature ];
		if (triangles_needed) {
		    if (!pass2) {
			f += triangles_needed;
			p += xvolj1_vertices_needed[  signature ];
		    } else {
			(*xvolj2_fn[ signature ])(
			    &fbase,        /* Where to insert next facet */
			    &pbase,        /* Where to insert next point */
			    r.x,           /* Array to hold output point x vals */
			    r.y,           /* Array to hold output point y vals */
			    r.z,           /* Array to hold output point z vals */
			    r.f0,          /* Array to hold 1st point of output triangles */
			    r.f1,          /* Array to hold 2nd point of output triangles */
			    r.f2,          /* Array to hold 3rd point of output triangles */
			    (float)(xi-1), /* X-Coord of voxel's 000 corner */
			    (float)(yi-1), /* Y-Coord of voxel's 000 corner */
			    (float)(zi-1), /* Z-Coord of voxel's 000 corner */
			    1.0,           /* X-Length of voxel */
			    1.0,           /* Y-Length of voxel */
			    1.0,           /* Z-Length of voxel */
			    (float) iso,   /* Isosurface threshhold value     */
			    val000,    /* Fn value at corner 000 of voxel */
			    val001,    /* Fn value at corner 001 of voxel */
			    val010,    /* Fn value at corner 010 of voxel */
			    val011,    /* Fn value at corner 011 of voxel */
			    val100,    /* Fn value at corner 100 of voxel */
			    val101,    /* Fn value at corner 101 of voxel */
			    val110,    /* Fn value at corner 110 of voxel */
			    val111     /* Fn value at corner 111 of voxel */
			);
		    }
		}
	    }
	}
    }
    *points_to_insert = p;
    *facets_to_insert = f;
}
LVAL
xvoljz_Insert_Isosurface_Fn(
    void
){
    int points_to_insert;
    int facets_to_insert;

    int     min_i = 0, max_i = 256;
    int     min_j = 0, max_j = 256;
    int     min_k = 0, max_k = 256;

    int     x_in;
    int     y_in;
    int     z_in;

    int     isolevel = 30;

    LVAL lv_voxels   = NULL;
    LVAL lv_voxary   = NULL;

    LVAL lv_thing    = NULL;

    int     max_facets = (int)(((unsigned)~0)>>1);

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_voxels) {

	    lv_voxels = xlgetarg();
	    lv_voxary = lv_voxels;

	} else if (lv == k_max_facets) {

	    max_facets = getfixnum(xlgafixnum());

	} else if (lv == k_thing) {

	    lv_thing = xlgacons();

	} else if (lv == k_isolevel) {

	    isolevel = getfixnum(xlgafixnum());

	} else if (lv == k_mini) {    min_i = getfixnum(xlgafixnum());
	} else if (lv == k_maxi) {    max_i = getfixnum(xlgafixnum());
	} else if (lv == k_minj) {    min_j = getfixnum(xlgafixnum());
	} else if (lv == k_maxj) {    max_j = getfixnum(xlgafixnum());
	} else if (lv == k_mink) {    min_k = getfixnum(xlgafixnum());
	} else if (lv == k_maxk) {    max_k = getfixnum(xlgafixnum());

	} else {

	    xlerror("Bad XVOL-INSERT-ISOSURFACE keyword",lv);
    }   }
    if (!lv_voxels) xlfail("XVOL-INSERT-ISOSURFACE: missing :VOXELS keyword");
    if (null(lv_thing)) xlfail("XVOL-INSERT-ISOSURFACE: missing :THING keyword");


    /* Validate :voxels array: */
    if (lv_voxary && xgrlp( lv_voxary )) {
	lv_voxary = xgrl3c_Get_Array( lv_voxary, k_intensity, NIL, TRUE );
    }
    if (lv_voxary && xf2vp( lv_voxary )) {
	xvol95_Get_X_Y_Z_Dimensions( &x_in, &y_in, &z_in, lv_voxary );
    } else {
	xlerror("Bad XVOL-INSERT-ISOSURFACE :VOXELS arg",lv_voxels);
    }
    if (min_i < 0)   min_i = 0;	   if (max_i > x_in)   max_i = x_in;
    if (min_j < 0)   min_j = 0;	   if (max_j > y_in)   max_j = y_in;
    if (min_k < 0)   min_k = 0;	   if (max_k > z_in)   max_k = z_in;
    {   CSRY_UNSIGNED16* voxel  = (CSRY_UNSIGNED16*) csry_base( lv_voxary );
        xvolj8_insert_isosurface(
            lv_thing,
	    &points_to_insert,
	    &facets_to_insert,
	    voxel,
            x_in,  y_in,  z_in,
            isolevel,
            /* pass2== */ FALSE,
	    min_i, max_i,
	    min_j, max_j,
	    min_k, max_k
	);
	if (facets_to_insert > max_facets) return cvfixnum(facets_to_insert);
        xvolj8_insert_isosurface(
            lv_thing,
	    &points_to_insert,
	    &facets_to_insert,
	    voxel,
            x_in,  y_in,  z_in,
            isolevel,
            /* pass2== */ TRUE,
	    min_i, max_i,
	    min_j, max_j,
	    min_k, max_k
	);
    }
    return NIL;
}

/************************************************************************/
/*- xvolkz_Merge_Redundant_Points_Fn --					*/
/************************************************************************/

int xvolkw_is_prime(int n) {
  
  /* decide if this number is prime */

  unsigned int  i;

  if (n < 2) {
    return 0;
  }
  else if ((n % 2) == 0) {
    return 0;
  }
  else {
    for (i = 3; i <= sqrt(n); i += 2) {
      if ((n % i) == 0) {
	return 0;
      }
    }
    /* no divisor, so it's prime */
    return 1;
  }
}

int
xvolkx_compute_hash_table_size(
    int    entries
){

  /* Decide how large a hash table should be to hold the specified
   * number of entries.  
   *
   * We want the table size to be larger than the number of entries,
   * and we also want it be a prime number.  Compute this by taking
   * the number of entries, scaling by some factor, and looking for
   * the next prime number larger than that.  (Initially I thought
   * this would be too slow, but it turns out to find a prime pretty
   * quickly.)
   *
   * WARNING: no overflow checking.
   */

  float  scale = 1.5;  /* keep table less than two-thirds full */
  int    size;

  /* start with an odd size, work up from there */
  size = entries * scale;
  size = size | 1;
  while (!xvolkw_is_prime(size)) {
    size += 2;
  }

  return size;
}  


int
xvolkx_compute_hash_table_size_OLD(
    int    entries
){

  /* Decide how large a hash table should be to hold the specified
   * number of entries.  
   *
   * We want the table size to be larger than the number of entries,
   * and we also want it be a prime number.  Things of the form
   * 2^p - 1, where p is odd, tend to be prime.  Therefore pick the
   * next number of this form that is "big enough."
   */

  int    temp, power, size;
  float  max_filled = 0.80;  /* upper bound on how full table should be */

  /* find power of two that is just larger than number of entries */
  for (temp = entries, power = 0; temp; temp = temp >> 1) {
    power++;
  }

  /* ensure an odd power by tweaking last bit */
  power = power | 0x00000001;

  /* compute 2^p */
  size = 1 << power;

  /* if the table will be too full, bump up the size to be safe */
  if (entries > (size * max_filled)) {
    size = size << 2;
  }

  /* do the final "-1" */
  return size - 1;
}


void
xvolky_merge_redundant_points(
    LVAL   lv_thing
){

  gt_tri_rec r;        /* record with info on the graphics relation */
  csry_rec* h;
  int  f;
  int  pi[4];          /* indices into point array */
  int  pi_max = 0;     /* number of vertices per polygon */
  int  is_dup = 0;     /* duplicate vertex flag */
  int  ncount = 0;     /* number of verts in merged list */
  LVAL lv_pointGrl;    /* graphic relation for vertices */
  LVAL lv_nx;          /* merged point arrays (as LVALs) */
  LVAL lv_ny;
  LVAL lv_nz;
  LVAL lv_val;         /* temp val */
  int  i, p;           /* loop index */
  int  *map;           /* mapping from old to new vertex indices */
  int  u;              /* temp var */
  int  done;           /* loop flag */
  int  key;            /* integer key for doing hashing */
  int  hash;           /* the hashed value of a vertex */
  float *nx,*ny,*nz;   /* merged point arrays */
  hash_entry  *table;  /* hash table for vertices */
  int  table_size;     /* size of the hash table */
  int  *facets;        /* array of facet indices */
  int  count = 0;      /* for testing avg search depth in hash table */

  int        toProt = 6;
  xlstkcheck(toProt);
  xlprotect(lv_thing);
  xlsave(lv_pointGrl);
  xlsave(lv_nx);
  xlsave(lv_ny);
  xlsave(lv_nz);
  xlsave(lv_val);

/* printf("in merge points fn...\n"); */

  xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
  xthlB1_Process_Thing( &r, lv_thing );

  /* Find our relations: */
  if (!r.got_triangles) {
    xlfail("XVOL-MERGE-REDUNDANT-POINTS: only works with triangles (for now)");
  }

  /* Create new arrays for merged points */
  lv_pointGrl = xthlA2_Get_Point_Relation_From_Thing( lv_thing );
  h = xsry9c_Find_Immediate_Base( lv_pointGrl );
  lv_nx = xsendmsg3( lv_xflv, k_new, cvfixnum(1), k_fillpointer, true );
  lv_ny = xsendmsg3( lv_xflv, k_new, cvfixnum(1), k_fillpointer, true );
  lv_nz = xsendmsg3( lv_xflv, k_new, cvfixnum(1), k_fillpointer, true );
  xsry22_AdjustArray( lv_nx, h );
  xsry22_AdjustArray( lv_ny, h );
  xsry22_AdjustArray( lv_nz, h );
  nx = (float *) (csry_base( lv_nx ));
  ny = (float *) (csry_base( lv_ny ));
  nz = (float *) (csry_base( lv_nz ));

  /* how many vertices per polygon? */
  if (r.got_rectangles)      { pi_max = 4; }
  else if (r.got_triangles)  { pi_max = 3; }
  else if (r.got_segments)   { pi_max = 2; }
  else if (r.got_points)     { pi_max = 1; }
  else {    
    xlfail("XVOL-MERGE-REDUNDANT-POINTS: illegal number of vertices!");
  }

  /* initialize the hash table */
/* printf("computing hash table size...\n"); */
  table_size = xvolkx_compute_hash_table_size(r.pLen);
/* printf("allocating space...\n"); */
  table = (hash_entry *) calloc(table_size, sizeof(hash_entry));
  memset( (void *)table, 0, table_size * sizeof(hash_entry));

  /* initialize the mapping array */
  map = (int *) calloc(r.pLen, sizeof(int));

  /* So that I can use an index of '0' to flag empty slots in the hash
   * table, I'm going to leave slot 0 of the new vertex array empty.
   * To be safe, though, I'll clear out that entry.
   */
  nx[0] = ny[0] = nz[0] = 0.0;

  /**************************************
   * Step 1:  compute new point indices *
   **************************************/

/* printf("computing new indices...\n"); */

  /* for each point, compute a new index */
  for (p = r.pLen;  p --> 0; ) {
  
    /* compute an integer key for this vertex and hash it */
    key = ((((int) r.x[p]) & 0x000000ff) << 16) |
          ((((int) r.y[p]) & 0x000000ff) <<  8) |
	  ((((int) r.z[p]) & 0x000000ff));
    hash = key % table_size;

    /* start searching the hash table */
    done = 0;
    while (!done) {

      count++;  /* just for testing */

      /* If we find an empty slot, then no match was found.  Add this 
       * vertex to the table, the mapping, and the new vertex arrays.
       *
       * TRICKERY WARNING: I want to use an index of 0 to indicate an
       * empty hash table entry, but don't want to leave vertex 0 empty.
       * So I will set the index in each hash table entry to be 1 larger
       * than the corresponding value in the mapping.
       */
      if (table[hash].index == 0) {
	map[p] = ncount;
	table[hash].index = ncount + 1;  /* this is the trickery */
	table[hash].x = r.x[p];
	table[hash].y = r.y[p];
	table[hash].z = r.z[p];
	nx[ncount] = r.x[p];
	ny[ncount] = r.y[p];
	nz[ncount] = r.z[p];
	done = 1;
	ncount++;
      }

      /* If the point is already in the table, then just update the map. */
      else if ((table[hash].x == r.x[p]) &&
	       (table[hash].y == r.y[p]) &&
	       (table[hash].z == r.z[p])) {
	map[p] = table[hash].index - 1;  /* -1 because of trickery */
	done = 1;
      }

      /* Otherwise move to the next entry.  I'm using a double hashing 
       * scheme, so use the key to decide how far ahead to jump. (This 
       * second hash function comes from p. 239 of "Algorithms in C"
       * by Robert Sedgewick.)
       */
      else {
	u = 8 - (key % 8);
	hash = (hash + u) % table_size;
      }
    }  /* end while not done */	       

  } /* end for each vertex */

/*
printf("------------------------------------\n");
printf("HASH TABLE STATS:\n");
printf("Total Vertices:       %d\n", r.pLen);
printf("Hash Table Size:      %d\n", table_size);
printf("Average search depth: %0.2f\n", count / (float) r.pLen);
printf("Fullness of table:    %0.1f%%\n", (r.pLen * 100.0) / table_size);
printf("------------------------------------\n");
*/

  /******************************************
   * Step 2:  re-map values in facet arrays *
   ******************************************/

/* printf("remapping facet indices...\n"); */

  /* for each facet array */
  for (i = pi_max; i --> 0;  ) {

    /* grab the right array */
    switch(i) {
    case 0:  facets = r.f0;  break;
    case 1:  facets = r.f1;  break;
    case 2:  facets = r.f2;  break;
    case 3:  facets = r.f3;  break;
    default: xlfail("XVOL-MERGE-REDUNDANT-POINTS: bad value in switch");
    }

    /* re-map all facets in this array */
    for (f = r.fLen; f --> 0; ) {
      facets[f] = map[ facets[f] ];
    }

  }  /* end for each facet array */

  /* set point relation's size to match final merged count */
  /* (if a fill pointer exists, just tweak that)           */
  if (h->rank == 1   &&   (h->dim[1]) >= 0) {
    h->dim[1] = ncount;
  }
  else {
    lv_val = cvfixnum(ncount);
    xsendmsg1( lv_pointGrl, k_adjustarray, lv_val );
  }

  /* put merged point arrays back into the point relation */
  xsendmsg2( lv_pointGrl, k_setarray, k_pointx, lv_nx );
  xsendmsg2( lv_pointGrl, k_setarray, k_pointy, lv_ny );
  xsendmsg2( lv_pointGrl, k_setarray, k_pointz, lv_nz );

  /* free up extra space */
  free(table);
  free(map);

/* printf("Done!\n"); */

  xlpopn(toProt);
}


LVAL
xvolkz_Merge_Redundant_Points_Fn()  {

  /* Lisp name:  XVOL-MERGE-REDUNDANT-POINTS
   *
   * For the specified graphics relation, merge any points in the point
   * relation that are duplicates and make appropriate changes in
   * the facet relation.  (This is a useful post-processing step for the
   * isosurface code, which may create multiple copies of each vertex.)
   */

    LVAL lv_thing = NIL;
    while (moreargs()) {

        LVAL lv = xlgasymbol();

	if (lv == k_thing) {

	    lv_thing = xlgacons();

	} else {

	    xlerror("Bad XVOL-MERGE-REDUNDANT-POINTS keyword",lv);
    }   }
    if (null(lv_thing)) xlfail("XVOL-MERGE-REDUNDANT-POINTS: missing :THING keyword");

    xvolky_merge_redundant_points( lv_thing );
    return NIL;
}

/************************************************************************/
/*- xvolkz_Merge_Redundant_Points_Fn_OLD --				*/
/************************************************************************/

void
xvolky_merge_redundant_points_OLD(
    LVAL   lv_thing
){

  /* NOTE:  the current strategy is for finding duplicates is REALLY
   * dumb, because it is doing a linear-time search.  A hash table is
   * probably the right way to go.
   */

  gt_tri_rec r;
  int  f;
  int  pi[4];         /* indices into point array */
  int  pi_max = 0;    /* number of vertices per polygon */
  int  is_dup = 0;    /* duplicate vertex flag */
  int  ncount = 0;    /* number of verts in merged list */
  LVAL lv_pointGrl;   /* graphic relation for vertices */
  LVAL lv_nx;         /* merged point arrays (as LVALs) */
  LVAL lv_ny;
  LVAL lv_nz;
  float *nx,*ny,*nz;  /* merged point arrays */
  int  i,ni;          /* loop indices */
  
  int        toProt = 5;
  xlstkcheck(toProt);
  xlprotect(lv_thing);
  xlsave(lv_pointGrl);
  xlsave(lv_nx);
  xlsave(lv_ny);
  xlsave(lv_nz);

  xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
  xthlB1_Process_Thing( &r, lv_thing );

  /* Find our relations: */
  if (!r.got_triangles) {
    xlfail("XVOL-MERGE-REDUNDANT-POINTS: only works with triangles (for now)");
  }

  /* Create new arrays for merged points */
  lv_nx = xsendmsg1( lv_xflv, k_new, cvfixnum(r.pLen) );
  lv_ny = xsendmsg1( lv_xflv, k_new, cvfixnum(r.pLen) );
  lv_nz = xsendmsg1( lv_xflv, k_new, cvfixnum(r.pLen) );
  nx = (float *) (csry_base( lv_nx ));
  ny = (float *) (csry_base( lv_ny ));
  nz = (float *) (csry_base( lv_nz ));

  /* how many vertices per polygon? */
  if (r.got_rectangles)      { pi_max = 4; }
  else if (r.got_triangles)  { pi_max = 3; }
  else if (r.got_segments)   { pi_max = 2; }
  else if (r.got_points)     { pi_max = 1; }
  else {    
    xlfail("XVOL-MERGE-REDUNDANT-POINTS: illegal number of vertices!");
  }

  /* Over all facets: */
  for (f = r.fLen;   f --> 0;   ) {
    pi[0] = r.f0[f];
    pi[1] = r.f1[f];
    if (r.got_rectangles) {
      pi[2] = r.f2[f];
      pi[3] = r.f3[f];
    } else if (r.got_triangles) {
      pi[2] = r.f2[f];
    }

    /* for each facet vertex... */
    for (i = pi_max; i --> 0;  ) {
      int  p = pi[i];

      /* check against the consolidated vertex list  */
      is_dup = 0;
      for (ni = ncount; (!is_dup) && (ni --> 0);  ) {
	if ((r.x[p] == nx[ni]) &&
	    (r.y[p] == ny[ni]) &&
	    (r.z[p] == nz[ni])) {

/*	  printf("MERGING...\n"); */
	  /* point is a duplicate, so use existing version and move on */
	  switch (i) {
	  case 0:  r.f0[f] = ni;  break;
	  case 1:  r.f1[f] = ni;  break;
	  case 2:  r.f2[f] = ni;  break;
	  case 3:  r.f3[f] = ni;  break;
	  default: xlfail("XVOL-MERGE-REDUNDANT-POINTS: bad value in switch");
	  }
	  is_dup = 1;
	}
      }
      /* if vertex is not a duplicate, add it to the new point array */
      if (!is_dup) {
/*	printf("adding...\n"); */
	nx[ncount] = r.x[p];
	ny[ncount] = r.y[p];
	nz[ncount] = r.z[p];
	switch (i) {
	case 0:  r.f0[f] = ncount;  break;
	case 1:  r.f1[f] = ncount;  break;
	case 2:  r.f2[f] = ncount;  break;
	case 3:  r.f3[f] = ncount;  break;
	default: xlfail("XVOL-MERGE-REDUNDANT-POINTS: bad value in switch");
	}
	ncount++;
      }
    }  /* end for each facet vertex */
  }    /* end for each facet */

  /* put merged point arrays back into the point relation */
  lv_pointGrl = xthlA2_Get_Point_Relation_From_Thing( lv_thing );
  xsendmsg2( lv_pointGrl, k_setarray, k_pointx, lv_nx );
  xsendmsg2( lv_pointGrl, k_setarray, k_pointy, lv_ny );
  xsendmsg2( lv_pointGrl, k_setarray, k_pointz, lv_nz );

  /* shrink point relation to match final merged count */
  xsendmsg1( lv_pointGrl, k_adjustarray, cvfixnum(ncount) );

  xlpopn(toProt);
}

LVAL
xvolkz_Merge_Redundant_Points_Fn_OLD()  {

  /* Lisp name:  XVOL-MERGE-REDUNDANT-POINTS
   *
   * For the specified graphics relation, merge any points in the point
   * relation that are duplicates and make appropriate changes in
   * the facet relation.  (This is a useful post-processing step for the
   * isosurface code, which may create multiple copies of each vertex.)
   */

    LVAL lv_thing = NIL;
    while (moreargs()) {

        LVAL lv = xlgasymbol();

	if (lv == k_thing) {

	    lv_thing = xlgacons();

	} else {

	    xlerror("Bad XVOL-MERGE-REDUNDANT-POINTS keyword",lv);
    }   }
    if (null(lv_thing)) xlfail("XVOL-MERGE-REDUNDANT-POINTS: missing :THING keyword");

    xvolky_merge_redundant_points_OLD( lv_thing );
    return NIL;
}

/************************************************************************/
/*- xvollz_Compute_Unnormalized_Facet_Normals_Fn --			*/
/************************************************************************/

void
xvolly_compute_unnormalized_facet_normals(
    LVAL   lv_thing
){
    gt_tri_rec r;

    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, lv_thing );

    /* Find our relations: */
    if (!r.got_points) {
        xlfail("XVOL-COMPUTE-UNNORMALIZED-FACET-NORMALS: missing :POINT-X/Y/Z arrays");
    }
    if (r.got_rectangles) {
        xlfail("XVOL-COMPUTE-UNNORMALIZED-FACET-NORMALS: rectangles not supported yet");
    }
    if (!r.got_triangles) {
        xlfail("XVOL-COMPUTE-UNNORMALIZED-FACET-NORMALS: need thing of triangles");
    }
    if (!r.got_facet_normals) {
        xlfail("XVOL-COMPUTE-UNNORMALIZED-FACET-NORMALS: need :FACET-NORMAL-X/Y/Z arrays");
    }

    {   /* Cache float array pointers in registers: */
	float * px = r.x;		float * fnx = r.fnx;
	float * py = r.y;		float * fny = r.fny;
	float * pz = r.z;		float * fnz = r.fnz;

	/* Over all facets: */
	int  f;
	for (f = r.fLen;   f --> 0;   ) {

	    /* Which three points comprise the facet? */
	    int   f0  = r.f0[ f ];
	    int   f1  = r.f1[ f ];
	    int   f2  = r.f2[ f ];

	    /* Compute vectors forming */
	    /* two edges of triangle:  */
	    float dx2 = px[ f0 ] - px[ f1 ];  float dx0 = px[ f2 ] - px[ f1 ];
	    float dy2 = py[ f0 ] - py[ f1 ];  float dy0 = py[ f2 ] - py[ f1 ];
	    float dz2 = pz[ f0 ] - pz[ f1 ];  float dz0 = pz[ f2 ] - pz[ f1 ];

	    /* Compute and save cross product: */
	    fnx[f] = dy0 * dz2   -   dy2 * dz0;
	    fny[f] = dx2 * dz0   -   dx0 * dz2;
	    fnz[f] = dx0 * dy2   -   dx2 * dy0;
	}
    }
}
LVAL
xvollz_Compute_Unnormalized_Facet_Normals_Fn()
{
    LVAL lv_thing = NIL;
    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if (lv == k_thing) {

	    lv_thing = xlgacons();

	} else {

	    xlerror("Bad XVOL-COMPUTE-UNNORMALIZED-FACET-NORMALS keyword",lv);
    }   }
    if (null(lv_thing)) xlfail("XVOL-COMPUTE_UNNORMALIZED-FACET-NORMALS: missing :THING keyword");

    xvolly_compute_unnormalized_facet_normals( lv_thing );
    return NIL;
}

/************************************************************************/
/*- xvolmz_Accumulate_Unnormalized_Point_Normals_Fn --			*/
/************************************************************************/

LVAL xvolmz_Accumulate_Unnormalized_Point_Normals_Fn()  { return NIL; }

/************************************************************************/
/*- xvolnz_Set_Facet_Normals_To_Unit_Length_Fn --			*/
/************************************************************************/

void
xvolny_set_facet_normals_to_unit_length(
    LVAL   lv_thing
){
    gt_tri_rec r;

    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, lv_thing );

    /* Find our relations: */
    if (!r.got_facet_normals) {
        xlfail("XVOL-SET-FACET-NORMALS-TO-UNIT-LENGTH: need :FACET-NORMAL-X/Y/Z arrays");
    }

    {   /* Cache float array pointers in registers: */
	float * fnx = r.fnx;
	float * fny = r.fny;
	float * fnz = r.fnz;

	/* Over all facets: */
	int  f;
	for (f = r.fLen;   f --> 0;   ) {

	    /* Get components of normal: */
	    float x = fnx[ f ];
	    float y = fny[ f ];
	    float z = fnz[ f ];

	    /* Compute inverse length of normal: */
	    float d = x*x + y*y + z*z;
	    if (d != 0.0) {
		float id = 1.0 / sqrt( d );
		
		/* Scale all components: */
		fnx[f] = x * id;
		fny[f] = y * id;
		fnz[f] = z * id;
	    }
	}
    }
}
LVAL
xvolnz_Set_Facet_Normals_To_Unit_Length_Fn()
{
    LVAL lv_thing = NIL;
    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if (lv == k_thing) {

	    lv_thing = xlgacons();

	} else {

	    xlerror("Bad XVOL-COMPUTE-UNNORMALIZED-FACET-NORMALS keyword",lv);
    }   }
    if (null(lv_thing)) xlfail("XVOL-COMPUTE_UNNORMALIZED-FACET-NORMALS: missing :THING keyword");

    xvolny_set_facet_normals_to_unit_length( lv_thing );
    return NIL;
}

/************************************************************************/
/*- xvolo3_Information_Content_Fn --					*/
/************************************************************************/

double xvolo2_information_content(
    CSRY_UNSIGNED16* voxel,
    int              len
) {
     /* Compute an upper limit on the bit-content of a  */
     /* V-voxel 12-bit MRI voxel dataset, computed by   */
     /* first figuring a histogram giving the frequency */
     /* F of each integer I in the dataset, then taking */
     /* the information content of each instance of I   */
     /* to be log2(1/probability(I)) == log2(V/F):      */

     /****************************************/
     /*      x            y                  */
     /* If  2 = c   and 10 = c               */
     /*                                      */
     /* then y * log10(10) = x * log10(2)    */
     /*                                      */
     /* and  x = y / log10(2)                */
     /****************************************/

    int table[ 4096 ];
    int i;
    double log_10_2_inv = 1.0 / log10(2.0);
    double flen         = (double) len;
    double info         = 0.0;
    for (i = 0;   i < 4096;   ++i)     table[i] = 0;
    for (i = 0;   i < len;    ++i)   ++table[ voxel[ i ] & 0xFFF ];
    for (i = 0;   i < 4096;   ++i) {
	if (table[i]) {
	    double f          = (double)(table[i]);
	    double p_inv      = flen / f;
	    double log10pinv  = log10( p_inv );
	    double log2pinv   = log10pinv * log_10_2_inv;
	    info += f * log2pinv;
	}
    }
    return info;
}

LVAL xvolo3_Information_Content_Fn()
{
    int     len;
    LVAL lv_voxels   = NULL;
    LVAL lv_voxary   = NULL;

    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if        (lv == k_voxels) {

	    lv_voxels = xlgetarg();
	    lv_voxary = lv_voxels;

	} else {
	    xlerror("Bad XVOL-INFORMATION-CONTENT keyword",lv);
    }   }
    if (!lv_voxels) xlfail("XMRI-INFORMATION-CONTENT: missing :VOXELS keyword");

    /* Validate :voxels array: */
    if (lv_voxary && xgrlp( lv_voxary )) {
	lv_voxary = xgrl3c_Get_Array( lv_voxary, k_intensity, NIL, TRUE );
    }
    if (lv_voxary && xf2vp( lv_voxary )) {
        csry_rec* h    = xsry9c_Find_Immediate_Base( lv_voxary );
        len = h->size;
    } else {
	xlerror("Bad XMRI-INFORMATION-CONTENT :VOXELS arg",lv_voxels);
    }
    {   CSRY_UNSIGNED16* voxel  = (CSRY_UNSIGNED16*) csry_base( lv_voxary );
	double bits = xvolo2_information_content(
	    voxel,  len
	);
        return cvflonum( bits );
    }
}

/************************************************************************/
/*- xvolpz_Compute_Unnormalized_Point_Normals --			*/
/************************************************************************/

void
xvolpy_compute_unnormalized_point_normals(
    LVAL   lv_thing
){
  gt_tri_rec r;

  xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
  xthlB1_Process_Thing( &r, lv_thing );

  /* Find our relations: */
  if (!r.got_points) {
    xlfail("XVOL-COMPUTE-UNNORMALIZED-POINT-NORMALS: missing :POINT-X/Y/Z arrays");
  }
  if (r.got_rectangles) {
    xlfail("XVOL-COMPUTE-UNNORMALIZED-POINT-NORMALS: rectangles not supported yet");
  }
  if (!r.got_triangles) {
    xlfail("XVOL-COMPUTE-UNNORMALIZED-POINT-NORMALS: need thing of triangles");
  }
  if (!r.got_point_normals) {
    xlfail("XVOL-COMPUTE-UNNORMALIZED-POINT-NORMALS: need :POINT-NORMAL-X/Y/Z arrays");
  }
  if (!r.got_facet_normals) {
    xlfail("XVOL-COMPUTE-UNNORMALIZED-POINT-NORMALS: need :FACET-NORMAL-X/Y/Z arrays");
  }

  /* compute facet normals (may be redundant, but how do we know?) */
  xvolly_compute_unnormalized_facet_normals(lv_thing);
  xvolny_set_facet_normals_to_unit_length(lv_thing);

  { /* Cache float array pointers in registers: */
    float *px = r.x;   float *fnx = r.fnx;   float *pnx = r.pnx;
    float *py = r.y;   float *fny = r.fny;   float *pny = r.pny;
    float *pz = r.z;   float *fnz = r.fnz;   float *pnz = r.pnz;
    int  f;

    /* clear out pre-existing point normals */
    memset( (void *)pnx, 0, r.pLen * sizeof(float) );
    memset( (void *)pny, 0, r.pLen * sizeof(float) );
    memset( (void *)pnz, 0, r.pLen * sizeof(float) );

    /* Over all facets: */
    for (f = r.fLen;   f --> 0;   ) {

      /* Which three points comprise the facet? */
      int   f0  = r.f0[ f ];
      int   f1  = r.f1[ f ];
      int   f2  = r.f2[ f ];

      /* add facet's normal to each point's normal */
      pnx[f0] += fnx[f];  pny[f0] += fny[f];  pnz[f0] += fnz[f];
      pnx[f1] += fnx[f];  pny[f1] += fny[f];  pnz[f1] += fnz[f];
      pnx[f2] += fnx[f];  pny[f2] += fny[f];  pnz[f2] += fnz[f];
    }
  }
}

LVAL
xvolpz_Compute_Unnormalized_Point_Normals_Fn()
{
    LVAL lv_thing = NIL;
    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if (lv == k_thing) {

	    lv_thing = xlgacons();

	} else {

	    xlerror("Bad XVOL-COMPUTE-UNNORMALIZED-POINT-NORMALS keyword",lv);
    }   }
    if (null(lv_thing)) xlfail("XVOL-COMPUTE_UNNORMALIZED-POINT-NORMALS: missing :THING keyword");

    xvolpy_compute_unnormalized_point_normals( lv_thing );
    return NIL;
}

/************************************************************************/
/*- xvolqz_Set_Point_Normals_To_Unit_Length --				*/
/************************************************************************/

void
xvolqy_set_point_normals_to_unit_length(
    LVAL   lv_thing
){
    gt_tri_rec r;

    xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
    xthlB1_Process_Thing( &r, lv_thing );

    /* Find our relations: */
    if (!r.got_point_normals) {
        xlfail("XVOL-SET-POINT-NORMALS-TO_UNIT_LENGTH: need :POINT-NORMAL-X/Y/Z arrays");
    }

    {   /* Cache float array pointers in registers: */
	float * pnx = r.pnx;
	float * pny = r.pny;
	float * pnz = r.pnz;

	/* Over all points: */
	int  p;
	for (p = r.pLen;   p --> 0;   ) {

	    /* Get components of normal: */
	    float x = pnx[ p ];
	    float y = pny[ p ];
	    float z = pnz[ p ];

	    /* Compute inverse length of normal: */
	    float d = x*x + y*y + z*z;
	    if (d != 0.0) {
		float id = 1.0 / sqrt( d );
		
		/* Scale all components: */
		pnx[p] = x * id;
		pny[p] = y * id;
		pnz[p] = z * id;
	    }
	}
    }
}
LVAL
xvolqz_Set_Point_Normals_To_Unit_Length_Fn()
{
    LVAL lv_thing = NIL;
    while (moreargs()) {
        LVAL lv = xlgasymbol();

	if (lv == k_thing) {

	    lv_thing = xlgacons();

	} else {

	    xlerror("Bad XVOL-SET-POINT-NORMALS-TO_UNIT_LENGTH keyword",lv);
    }   }
    if (null(lv_thing)) xlfail("XVOL-SET-POINT-NORMALS-TO_UNIT_LENGTH: missing :THING keyword");

    xvolqy_set_point_normals_to_unit_length( lv_thing );
    return NIL;
}

/************************************************************************/
/*- xvolrz_Average_Point_Normals --					*/
/************************************************************************/

void
xvolry_average_point_normals(
    LVAL   lv_thing,
    int    iterations,    /* number of averaging steps */
    float  weight         /* weight of averaged normal */
){
  gt_tri_rec r;

  xthlC2_Init_Tri_Rec(  &r, NIL, NIL, NULL );
  xthlB1_Process_Thing( &r, lv_thing );

  /* Find our relations: */
  if (!r.got_points) {
    xlfail("XVOL-AVERAGE-POINT-NORMALS: missing :POINT-X/Y/Z arrays");
  }
  if (r.got_rectangles) {
    xlfail("XVOL-AVERAGE-POINT-NORMALS: rectangles not supported yet");
  }
  if (!r.got_triangles) {
    xlfail("XVOL-AVERAGE-POINT-NORMALS: need thing of triangles");
  }
  if (!r.got_point_normals) {
    xlfail("XVOL-AVERAGE-POINT-NORMALS: need :POINT-NORMAL-X/Y/Z arrays");
  }

  { /* Cache float array pointers in registers: */
    float *pnx = r.pnx;   float *onx;
    float *pny = r.pny;   float *ony;
    float *pnz = r.pnz;   float *onz;
    
    int  it, f, p;   /* loop indices */

    /* allocate space for old point normals */
    if ((onx = (float *) calloc(sizeof(float), r.pLen)) == NULL) {
      xlfail("XVOL-AVERAGE-POINT-NORMALS: can't allocate space"); }
    if ((ony = (float *) calloc(sizeof(float), r.pLen)) == NULL) {
      xlfail("XVOL-AVERAGE-POINT-NORMALS: can't allocate space"); }
    if ((onz = (float *) calloc(sizeof(float), r.pLen)) == NULL) {
      xlfail("XVOL-AVERAGE-POINT-NORMALS: can't allocate space"); }

    for (it = iterations; it --> 0; ) {

      /* set "old" point normals to current values */
      memcpy( (void *)onx, (void *)pnx, r.pLen * sizeof(float) );
      memcpy( (void *)ony, (void *)pny, r.pLen * sizeof(float) );
      memcpy( (void *)onz, (void *)pnz, r.pLen * sizeof(float) );

      /* initialize "new" point normals */
      memset( (void *)pnx, 0, r.pLen * sizeof(float) );
      memset( (void *)pny, 0, r.pLen * sizeof(float) );
      memset( (void *)pnz, 0, r.pLen * sizeof(float) );

      /* Over all facets: */
      for (f = r.fLen; f --> 0; ) {

	/* Which three points comprise the facet? */
	int   f0  = r.f0[ f ];
	int   f1  = r.f1[ f ];
	int   f2  = r.f2[ f ];

	/* add in each normal's two neighbors */
	pnx[f0] += onx[f1] + onx[f2];
	pny[f0] += ony[f1] + ony[f2];
	pnz[f0] += onz[f1] + onz[f2];

	pnx[f1] += onx[f0] + onx[f2];
	pny[f1] += ony[f0] + ony[f2];
	pnz[f1] += onz[f0] + onz[f2];

	pnx[f2] += onx[f0] + onx[f1];
	pny[f2] += ony[f0] + ony[f1];
	pnz[f2] += onz[f0] + onz[f1];
      }

      /* restore normals to unit length */
      xvolqy_set_point_normals_to_unit_length(lv_thing);

      /* compute weighted combo of new and old */
      for (p = r.pLen; p --> 0; ) {
	pnx[p] = (weight * pnx[p]) + ((1.0 - weight) * onx[p]);
	pny[p] = (weight * pny[p]) + ((1.0 - weight) * ony[p]);
	pnz[p] = (weight * pnz[p]) + ((1.0 - weight) * onz[p]);
      }
    }  /* end iterations loop */
  }    /* end block (for registers) */
}

LVAL
xvolrz_Average_Point_Normals_Fn()
{
    LVAL   lv_thing;         /* our object */
    LVAL   lv_val;           /* temp LVAL */
    int    iterations = 1;   /* number of averaging steps */
    float  weight = 1.0;     /* weight of averaged normal */

    int        toProt = 2;
    xlstkcheck(toProt);
    xlsave(lv_val);
    xlsave(lv_thing);

    while (moreargs()) {
      LVAL key = xlgasymbol();

      if        (key == k_thing) {        /* :THING */
	lv_thing = xlgacons();
      }
      else if   (key == k_iterations) {   /* :ITERATIONS */
	lv_val = xlgafixnum();
	iterations = getfixnum(lv_val);
      }
      else if   (key == k_weight) {       /* :WEIGHT */
	weight = xgbj00_Get_Fix_Or_Flo_Num(xlgetarg());
      }
      else {
	xlerror("Bad XVOL-AVERAGE-POINT-NORMALS keyword",key);
      }   
    }

    /* error-checking */
    if (!lv_thing) 
      xlfail("XVOL-AVERAGE-POINT-NORMALS: missing :THING keyword");
    if ((weight < 0.0) || (weight > 1.0))
      xlfail("XVOL-AVERAGE-POINT-NORMALS: weight must be between 0 and 1");
    if (iterations < 1)
      iterations = 1;
 
    xvolry_average_point_normals( lv_thing, iterations, weight );

    xlpopn(toProt);
    return NIL;
}
/*- xvolsz_Subsample_Array --	          				*/
/************************************************************************/

/*
 * FUNCTION:  XVOL-SUBSAMPLE-ARRAY
 * AUTHOR:    Kevin Hinshaw
 * DATE:      March 13, 1998
 *
 * SYNTAX:
 *
 *   (XVOL-SUBSAMPLE-ARRAY :ARRAY <ary>
 *                         [:SUBSAMPLE-BY <fix>]
 *                         [:RESULT-IN <ary>]
 *   )
 *
 * DESCRIPTION:
 *
 * Function to resample an array.  Values in the source array :ARRAY
 * are sampled at an interval specified by :SUBSAMPLE-BY, and the
 * resulting array is returned.  
 * 
 * If a :RESULT-IN value is supplied, and is of appropriate type, the
 * result will be placed in it and returned; otherwise, a fresh
 * array will be allocated and returned.
 * 
 * This is basically a quick hack to resample the aligned volume images,
 * so the current version only works for 3-D, 12-bit arrays.  (Mainly
 * because I wasn't sure how to check the type of the source array and
 * create a destination array of the same type.)  Maybe this is
 * something that should be defined by each array?
 * 
 */

LVAL
xvolsy_subsample_array(
  LVAL lv_src,
  LVAL lv_dst,
  int  subsample_by
){
  LVAL    lv_shape;
  int     src_x_dim = 0;
  int     src_y_dim = 0;
  int     src_z_dim = 0;
  int     dst_x_dim = 0;
  int     dst_y_dim = 0;
  int     dst_z_dim = 0;
  int     sub_x_dim = 0;
  int     sub_y_dim = 0;
  int     sub_z_dim = 0;
  int     dst_index = 0;
  int     src_index = 0;
  int     dx, dy, dz;
  int     x, y, z;
  CSRY_UNSIGNED16*  src_h;
  CSRY_UNSIGNED16*  dst_h;

  int        toProt = 3;
  xlstkcheck(toProt);
  xlprotect(lv_src);
  xlprotect(lv_dst);
  xlsave(lv_shape);

  /* HACK:  only handle 12-bit arrays */
  if (!xf2vp( lv_src ))
    xlfail("XVOL-SUBSAMPLE-VOXELS: temporarily limited to 12-bit arrays");

  /* get src and subsampled dimensions (assuming 3-D for now) */
  xvol95_Get_X_Y_Z_Dimensions( &src_x_dim, &src_y_dim, &src_z_dim, lv_src );
  sub_x_dim = src_x_dim / subsample_by;
  sub_y_dim = src_y_dim / subsample_by;
  sub_z_dim = src_z_dim / subsample_by;

  /* create dest. array, if needed */
  if (lv_dst)
    xvol95_Get_X_Y_Z_Dimensions( &dst_x_dim, &dst_y_dim, &dst_z_dim, lv_dst );
  if (!lv_dst                  ||
      !xf2vp( lv_dst )         ||   /* HACK:  force to 12-bit arrays */
      (sub_x_dim != dst_x_dim) ||
      (sub_y_dim != dst_y_dim) ||
      (sub_z_dim != dst_z_dim))  {
      
    /* is the dim order right?!? */
    lv_shape = cons(cvfixnum(sub_z_dim), NIL);
    lv_shape = cons(cvfixnum(sub_y_dim), lv_shape);
    lv_shape = cons(cvfixnum(sub_x_dim), lv_shape);
    lv_dst   = xsendmsg1( lv_xf2v, k_new, lv_shape );
  }

  /* get the actual arrays */
  src_h = (CSRY_UNSIGNED16*) csry_base( lv_src );
  dst_h = (CSRY_UNSIGNED16*) csry_base( lv_dst );
/*
  src_h = (csry_rec*) gobjimmbase( lv_src );
  dst_h = (csry_rec*) gobjimmbase( lv_dst );
*/

  /* both arrays are really 1-D, so compute deltas for the index into */
  /* the source array */

  dx = subsample_by;                                /* # of columns to skip */

  dy = (src_x_dim - (subsample_by * sub_x_dim)) +   /* # of leftover columns */
       (src_x_dim *                                 /* row size */
	(subsample_by - 1));                        /* # of rows to skip */

  dz = (src_x_dim *                                 /* row size */
	(src_y_dim - (subsample_by * sub_y_dim))) + /* # of leftover rows */
       (src_x_dim * src_y_dim *                     /* plane size */
	(subsample_by - 1));                        /* # of planes to skip */

  /* subsample the array */
  for (    z = 0;  z < sub_z_dim;  z++, src_index += dz) {
/* printf("plane %d...\n", z); */
    for (  y = 0;  y < sub_y_dim;  y++, src_index += dy) {
      for (x = 0;  x < sub_x_dim;  x++, src_index += dx) {
/*
	printf("%9d (%d, %d, %d) ==> %9d (%d, %d, %d)\n", 
	       src_index, x*subsample_by, y*subsample_by, z*subsample_by,
	       dst_index, x, y, z);
*/
	/* debugging (kph, 98Mar16) */
/*
	if ((src_index >= src_x_dim * src_y_dim * src_z_dim) ||
	    (dst_index >= sub_x_dim * sub_y_dim * sub_z_dim)) {
	  printf("Danger, Will Robinson!  Bad array index!\n");
	  printf("src = %d, dst = %d\n", src_index, dst_index);
	  exit(1);
	}
*/
	dst_h[dst_index] = src_h[src_index];
	dst_index++;
  } } }
	
  xlpopn(toProt);
  return lv_dst;
}

LVAL
xvolsz_Subsample_Array_Fn (
    void
){
  LVAL lv_src          = NULL;
  LVAL lv_dst          = NULL;
  LVAL lv_subsample_by = NULL;
  int     subsample_by = 2;

  while (moreargs()) {
    LVAL lv = xlgasymbol();

    if (lv == k_array) {                 /* :ARRAY */
      lv_src = xlgetarg();
      
    } else if (lv == k_result_in) {      /* :RESULT-IN */
      lv_dst = xlgetarg();

    } else if (lv == k_subsample_by) {   /* :SUBSAMPLE-BY */
      lv_subsample_by = xlgafixnum();
      subsample_by    = getfixnum( lv_subsample_by );

    } else {
      xlerror("Bad XVOL-SUBSAMPLE-VOXELS keyword",lv);
  } }

  /* error-checking */
  if (!lv_src) 
    xlfail("XVOL-SUBSAMPLE-VOXELS: missing :ARRAY keyword");

  /* do the work */
  return xvolsy_subsample_array(lv_src, lv_dst, subsample_by);
}


/*-    File variables							*/
/************************************************************************/
/*

Local variables:
mode: outline-minor
outline-regexp: "[ \\t]*\/\\*-"
End:
*/

