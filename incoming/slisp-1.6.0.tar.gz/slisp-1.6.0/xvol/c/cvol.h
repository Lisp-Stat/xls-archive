/* {{{ cvol.h -- xvol.c support stuff.				     CrT*/
/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      95Jul14
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1995, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifndef INCLUDED_CVOL_H
#define INCLUDED_CVOL_H

/* }}} */

/* hash table entries */
struct         hash_entry_struct  { float  x,y,z;  
				    int    index;  };
typedef struct hash_entry_struct  hash_entry;


extern void*
xvol86_Create_Plane(
    LVAL lv_grl,
    LVAL k_pixelxxx,
    int rows,
    int cols,
    LVAL lv_atype
);
extern LVAL
xvol87_Create_Pixels(
    int rows,
    int cols,
    CSRY_UNSIGNED8 **pixel
);

extern LVAL
xvol88_Create_Voxels(
    int rows,
    int cols,
    int slices,
    CSRY_UNSIGNED16 **g
);

extern int  xvol8c_lo_lim;
extern int  xvol89_hi_lim;
extern unsigned xvol8a_map[4096];	/* Int is likely faster than char */
extern void xvol8b_Init_Map( int, int );

extern int  xvol94_Check_X_And_Y_Dimensions( LVAL, int, int, int );
extern void xvol95_Get_X_Y_Z_Dimensions( int*,int*,int*,LVAL );
extern int  xvol93_Checksum( unsigned char*, int );


/* {{{ File variables							*/
/*

Local variables:
case-fold-search: nil
folded-file: t
fold-fold-on-startup: nil
End:
*/
#endif
/* }}} */
