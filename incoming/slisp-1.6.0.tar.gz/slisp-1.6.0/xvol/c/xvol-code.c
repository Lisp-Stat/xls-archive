int xvolj0_triangles_needed[ 256 ] = {
    /* cube 00 triangles needed: */  0,
    /* cube 01 triangles needed: */  1,
    /* cube 02 triangles needed: */  1,
    /* cube 03 triangles needed: */  2,
    /* cube 04 triangles needed: */  1,
    /* cube 05 triangles needed: */  2,
    /* cube 06 triangles needed: */  2,
    /* cube 07 triangles needed: */  3,
    /* cube 08 triangles needed: */  1,
    /* cube 09 triangles needed: */  2,
    /* cube 0a triangles needed: */  2,
    /* cube 0b triangles needed: */  3,
    /* cube 0c triangles needed: */  2,
    /* cube 0d triangles needed: */  3,
    /* cube 0e triangles needed: */  3,
    /* cube 0f triangles needed: */  2,
    /* cube 10 triangles needed: */  1,
    /* cube 11 triangles needed: */  2,
    /* cube 12 triangles needed: */  2,
    /* cube 13 triangles needed: */  3,
    /* cube 14 triangles needed: */  2,
    /* cube 15 triangles needed: */  3,
    /* cube 16 triangles needed: */  3,
    /* cube 17 triangles needed: */  4,
    /* cube 18 triangles needed: */  2,
    /* cube 19 triangles needed: */  3,
    /* cube 1a triangles needed: */  3,
    /* cube 1b triangles needed: */  4,
    /* cube 1c triangles needed: */  3,
    /* cube 1d triangles needed: */  4,
    /* cube 1e triangles needed: */  4,
    /* cube 1f triangles needed: */  3,
    /* cube 20 triangles needed: */  1,
    /* cube 21 triangles needed: */  2,
    /* cube 22 triangles needed: */  2,
    /* cube 23 triangles needed: */  3,
    /* cube 24 triangles needed: */  2,
    /* cube 25 triangles needed: */  3,
    /* cube 26 triangles needed: */  3,
    /* cube 27 triangles needed: */  4,
    /* cube 28 triangles needed: */  2,
    /* cube 29 triangles needed: */  3,
    /* cube 2a triangles needed: */  3,
    /* cube 2b triangles needed: */  4,
    /* cube 2c triangles needed: */  3,
    /* cube 2d triangles needed: */  4,
    /* cube 2e triangles needed: */  4,
    /* cube 2f triangles needed: */  3,
    /* cube 30 triangles needed: */  2,
    /* cube 31 triangles needed: */  3,
    /* cube 32 triangles needed: */  3,
    /* cube 33 triangles needed: */  2,
    /* cube 34 triangles needed: */  3,
    /* cube 35 triangles needed: */  4,
    /* cube 36 triangles needed: */  4,
    /* cube 37 triangles needed: */  3,
    /* cube 38 triangles needed: */  3,
    /* cube 39 triangles needed: */  4,
    /* cube 3a triangles needed: */  4,
    /* cube 3b triangles needed: */  3,
    /* cube 3c triangles needed: */  4,
    /* cube 3d triangles needed: */  5,
    /* cube 3e triangles needed: */  5,
    /* cube 3f triangles needed: */  2,
    /* cube 40 triangles needed: */  1,
    /* cube 41 triangles needed: */  2,
    /* cube 42 triangles needed: */  2,
    /* cube 43 triangles needed: */  3,
    /* cube 44 triangles needed: */  2,
    /* cube 45 triangles needed: */  3,
    /* cube 46 triangles needed: */  3,
    /* cube 47 triangles needed: */  4,
    /* cube 48 triangles needed: */  2,
    /* cube 49 triangles needed: */  3,
    /* cube 4a triangles needed: */  3,
    /* cube 4b triangles needed: */  4,
    /* cube 4c triangles needed: */  3,
    /* cube 4d triangles needed: */  4,
    /* cube 4e triangles needed: */  4,
    /* cube 4f triangles needed: */  3,
    /* cube 50 triangles needed: */  2,
    /* cube 51 triangles needed: */  3,
    /* cube 52 triangles needed: */  3,
    /* cube 53 triangles needed: */  4,
    /* cube 54 triangles needed: */  3,
    /* cube 55 triangles needed: */  2,
    /* cube 56 triangles needed: */  4,
    /* cube 57 triangles needed: */  3,
    /* cube 58 triangles needed: */  3,
    /* cube 59 triangles needed: */  4,
    /* cube 5a triangles needed: */  4,
    /* cube 5b triangles needed: */  5,
    /* cube 5c triangles needed: */  4,
    /* cube 5d triangles needed: */  3,
    /* cube 5e triangles needed: */  5,
    /* cube 5f triangles needed: */  2,
    /* cube 60 triangles needed: */  2,
    /* cube 61 triangles needed: */  3,
    /* cube 62 triangles needed: */  3,
    /* cube 63 triangles needed: */  4,
    /* cube 64 triangles needed: */  3,
    /* cube 65 triangles needed: */  4,
    /* cube 66 triangles needed: */  4,
    /* cube 67 triangles needed: */  5,
    /* cube 68 triangles needed: */  3,
    /* cube 69 triangles needed: */  4,
    /* cube 6a triangles needed: */  4,
    /* cube 6b triangles needed: */  5,
    /* cube 6c triangles needed: */  4,
    /* cube 6d triangles needed: */  5,
    /* cube 6e triangles needed: */  5,
    /* cube 6f triangles needed: */  4,
    /* cube 70 triangles needed: */  3,
    /* cube 71 triangles needed: */  4,
    /* cube 72 triangles needed: */  4,
    /* cube 73 triangles needed: */  3,
    /* cube 74 triangles needed: */  4,
    /* cube 75 triangles needed: */  3,
    /* cube 76 triangles needed: */  5,
    /* cube 77 triangles needed: */  2,
    /* cube 78 triangles needed: */  4,
    /* cube 79 triangles needed: */  5,
    /* cube 7a triangles needed: */  5,
    /* cube 7b triangles needed: */  4,
    /* cube 7c triangles needed: */  5,
    /* cube 7d triangles needed: */  4,
    /* cube 7e triangles needed: */  2,
    /* cube 7f triangles needed: */  1,
    /* cube 80 triangles needed: */  1,
    /* cube 81 triangles needed: */  2,
    /* cube 82 triangles needed: */  2,
    /* cube 83 triangles needed: */  3,
    /* cube 84 triangles needed: */  2,
    /* cube 85 triangles needed: */  3,
    /* cube 86 triangles needed: */  3,
    /* cube 87 triangles needed: */  4,
    /* cube 88 triangles needed: */  2,
    /* cube 89 triangles needed: */  3,
    /* cube 8a triangles needed: */  3,
    /* cube 8b triangles needed: */  4,
    /* cube 8c triangles needed: */  3,
    /* cube 8d triangles needed: */  4,
    /* cube 8e triangles needed: */  4,
    /* cube 8f triangles needed: */  3,
    /* cube 90 triangles needed: */  2,
    /* cube 91 triangles needed: */  3,
    /* cube 92 triangles needed: */  3,
    /* cube 93 triangles needed: */  4,
    /* cube 94 triangles needed: */  3,
    /* cube 95 triangles needed: */  4,
    /* cube 96 triangles needed: */  4,
    /* cube 97 triangles needed: */  5,
    /* cube 98 triangles needed: */  3,
    /* cube 99 triangles needed: */  4,
    /* cube 9a triangles needed: */  4,
    /* cube 9b triangles needed: */  5,
    /* cube 9c triangles needed: */  4,
    /* cube 9d triangles needed: */  5,
    /* cube 9e triangles needed: */  5,
    /* cube 9f triangles needed: */  4,
    /* cube a0 triangles needed: */  2,
    /* cube a1 triangles needed: */  3,
    /* cube a2 triangles needed: */  3,
    /* cube a3 triangles needed: */  4,
    /* cube a4 triangles needed: */  3,
    /* cube a5 triangles needed: */  4,
    /* cube a6 triangles needed: */  4,
    /* cube a7 triangles needed: */  5,
    /* cube a8 triangles needed: */  3,
    /* cube a9 triangles needed: */  4,
    /* cube aa triangles needed: */  2,
    /* cube ab triangles needed: */  3,
    /* cube ac triangles needed: */  4,
    /* cube ad triangles needed: */  5,
    /* cube ae triangles needed: */  3,
    /* cube af triangles needed: */  2,
    /* cube b0 triangles needed: */  3,
    /* cube b1 triangles needed: */  4,
    /* cube b2 triangles needed: */  4,
    /* cube b3 triangles needed: */  3,
    /* cube b4 triangles needed: */  4,
    /* cube b5 triangles needed: */  5,
    /* cube b6 triangles needed: */  5,
    /* cube b7 triangles needed: */  4,
    /* cube b8 triangles needed: */  4,
    /* cube b9 triangles needed: */  5,
    /* cube ba triangles needed: */  3,
    /* cube bb triangles needed: */  2,
    /* cube bc triangles needed: */  5,
    /* cube bd triangles needed: */  2,
    /* cube be triangles needed: */  4,
    /* cube bf triangles needed: */  1,
    /* cube c0 triangles needed: */  2,
    /* cube c1 triangles needed: */  3,
    /* cube c2 triangles needed: */  3,
    /* cube c3 triangles needed: */  4,
    /* cube c4 triangles needed: */  3,
    /* cube c5 triangles needed: */  4,
    /* cube c6 triangles needed: */  4,
    /* cube c7 triangles needed: */  5,
    /* cube c8 triangles needed: */  3,
    /* cube c9 triangles needed: */  4,
    /* cube ca triangles needed: */  4,
    /* cube cb triangles needed: */  5,
    /* cube cc triangles needed: */  2,
    /* cube cd triangles needed: */  3,
    /* cube ce triangles needed: */  3,
    /* cube cf triangles needed: */  2,
    /* cube d0 triangles needed: */  3,
    /* cube d1 triangles needed: */  4,
    /* cube d2 triangles needed: */  4,
    /* cube d3 triangles needed: */  5,
    /* cube d4 triangles needed: */  4,
    /* cube d5 triangles needed: */  3,
    /* cube d6 triangles needed: */  5,
    /* cube d7 triangles needed: */  4,
    /* cube d8 triangles needed: */  4,
    /* cube d9 triangles needed: */  5,
    /* cube da triangles needed: */  5,
    /* cube db triangles needed: */  2,
    /* cube dc triangles needed: */  3,
    /* cube dd triangles needed: */  2,
    /* cube de triangles needed: */  4,
    /* cube df triangles needed: */  1,
    /* cube e0 triangles needed: */  3,
    /* cube e1 triangles needed: */  4,
    /* cube e2 triangles needed: */  4,
    /* cube e3 triangles needed: */  5,
    /* cube e4 triangles needed: */  4,
    /* cube e5 triangles needed: */  5,
    /* cube e6 triangles needed: */  5,
    /* cube e7 triangles needed: */  2,
    /* cube e8 triangles needed: */  4,
    /* cube e9 triangles needed: */  5,
    /* cube ea triangles needed: */  3,
    /* cube eb triangles needed: */  4,
    /* cube ec triangles needed: */  3,
    /* cube ed triangles needed: */  4,
    /* cube ee triangles needed: */  2,
    /* cube ef triangles needed: */  1,
    /* cube f0 triangles needed: */  2,
    /* cube f1 triangles needed: */  3,
    /* cube f2 triangles needed: */  3,
    /* cube f3 triangles needed: */  2,
    /* cube f4 triangles needed: */  3,
    /* cube f5 triangles needed: */  2,
    /* cube f6 triangles needed: */  4,
    /* cube f7 triangles needed: */  1,
    /* cube f8 triangles needed: */  3,
    /* cube f9 triangles needed: */  4,
    /* cube fa triangles needed: */  2,
    /* cube fb triangles needed: */  1,
    /* cube fc triangles needed: */  2,
    /* cube fd triangles needed: */  1,
    /* cube fe triangles needed: */  1,
    /* cube ff triangles needed: */  0,
};

int xvolj1_vertices_needed[ 256 ] = {
    /* cube 00 vertices needed: */  0,
    /* cube 01 vertices needed: */  3,
    /* cube 02 vertices needed: */  3,
    /* cube 03 vertices needed: */  4,
    /* cube 04 vertices needed: */  3,
    /* cube 05 vertices needed: */  4,
    /* cube 06 vertices needed: */  6,
    /* cube 07 vertices needed: */  5,
    /* cube 08 vertices needed: */  3,
    /* cube 09 vertices needed: */  6,
    /* cube 0a vertices needed: */  4,
    /* cube 0b vertices needed: */  5,
    /* cube 0c vertices needed: */  4,
    /* cube 0d vertices needed: */  5,
    /* cube 0e vertices needed: */  5,
    /* cube 0f vertices needed: */  4,
    /* cube 10 vertices needed: */  3,
    /* cube 11 vertices needed: */  4,
    /* cube 12 vertices needed: */  6,
    /* cube 13 vertices needed: */  5,
    /* cube 14 vertices needed: */  6,
    /* cube 15 vertices needed: */  5,
    /* cube 16 vertices needed: */  9,
    /* cube 17 vertices needed: */  6,
    /* cube 18 vertices needed: */  6,
    /* cube 19 vertices needed: */  7,
    /* cube 1a vertices needed: */  7,
    /* cube 1b vertices needed: */  6,
    /* cube 1c vertices needed: */  7,
    /* cube 1d vertices needed: */  6,
    /* cube 1e vertices needed: */  8,
    /* cube 1f vertices needed: */  5,
    /* cube 20 vertices needed: */  3,
    /* cube 21 vertices needed: */  6,
    /* cube 22 vertices needed: */  4,
    /* cube 23 vertices needed: */  5,
    /* cube 24 vertices needed: */  6,
    /* cube 25 vertices needed: */  7,
    /* cube 26 vertices needed: */  7,
    /* cube 27 vertices needed: */  6,
    /* cube 28 vertices needed: */  6,
    /* cube 29 vertices needed: */  9,
    /* cube 2a vertices needed: */  5,
    /* cube 2b vertices needed: */  6,
    /* cube 2c vertices needed: */  7,
    /* cube 2d vertices needed: */  8,
    /* cube 2e vertices needed: */  6,
    /* cube 2f vertices needed: */  5,
    /* cube 30 vertices needed: */  4,
    /* cube 31 vertices needed: */  5,
    /* cube 32 vertices needed: */  5,
    /* cube 33 vertices needed: */  4,
    /* cube 34 vertices needed: */  7,
    /* cube 35 vertices needed: */  6,
    /* cube 36 vertices needed: */  8,
    /* cube 37 vertices needed: */  5,
    /* cube 38 vertices needed: */  7,
    /* cube 39 vertices needed: */  8,
    /* cube 3a vertices needed: */  6,
    /* cube 3b vertices needed: */  5,
    /* cube 3c vertices needed: */  8,
    /* cube 3d vertices needed: */  7,
    /* cube 3e vertices needed: */  7,
    /* cube 3f vertices needed: */  4,
    /* cube 40 vertices needed: */  3,
    /* cube 41 vertices needed: */  6,
    /* cube 42 vertices needed: */  6,
    /* cube 43 vertices needed: */  7,
    /* cube 44 vertices needed: */  4,
    /* cube 45 vertices needed: */  5,
    /* cube 46 vertices needed: */  7,
    /* cube 47 vertices needed: */  6,
    /* cube 48 vertices needed: */  6,
    /* cube 49 vertices needed: */  9,
    /* cube 4a vertices needed: */  7,
    /* cube 4b vertices needed: */  8,
    /* cube 4c vertices needed: */  5,
    /* cube 4d vertices needed: */  6,
    /* cube 4e vertices needed: */  6,
    /* cube 4f vertices needed: */  5,
    /* cube 50 vertices needed: */  4,
    /* cube 51 vertices needed: */  5,
    /* cube 52 vertices needed: */  7,
    /* cube 53 vertices needed: */  6,
    /* cube 54 vertices needed: */  5,
    /* cube 55 vertices needed: */  4,
    /* cube 56 vertices needed: */  8,
    /* cube 57 vertices needed: */  5,
    /* cube 58 vertices needed: */  7,
    /* cube 59 vertices needed: */  8,
    /* cube 5a vertices needed: */  8,
    /* cube 5b vertices needed: */  7,
    /* cube 5c vertices needed: */  6,
    /* cube 5d vertices needed: */  5,
    /* cube 5e vertices needed: */  7,
    /* cube 5f vertices needed: */  4,
    /* cube 60 vertices needed: */  6,
    /* cube 61 vertices needed: */  9,
    /* cube 62 vertices needed: */  7,
    /* cube 63 vertices needed: */  8,
    /* cube 64 vertices needed: */  7,
    /* cube 65 vertices needed: */  8,
    /* cube 66 vertices needed: */  8,
    /* cube 67 vertices needed: */  7,
    /* cube 68 vertices needed: */  9,
    /* cube 69 vertices needed: */ 12,
    /* cube 6a vertices needed: */  8,
    /* cube 6b vertices needed: */  9,
    /* cube 6c vertices needed: */  8,
    /* cube 6d vertices needed: */  9,
    /* cube 6e vertices needed: */  7,
    /* cube 6f vertices needed: */  6,
    /* cube 70 vertices needed: */  5,
    /* cube 71 vertices needed: */  6,
    /* cube 72 vertices needed: */  6,
    /* cube 73 vertices needed: */  5,
    /* cube 74 vertices needed: */  6,
    /* cube 75 vertices needed: */  5,
    /* cube 76 vertices needed: */  7,
    /* cube 77 vertices needed: */  4,
    /* cube 78 vertices needed: */  8,
    /* cube 79 vertices needed: */  9,
    /* cube 7a vertices needed: */  7,
    /* cube 7b vertices needed: */  6,
    /* cube 7c vertices needed: */  7,
    /* cube 7d vertices needed: */  6,
    /* cube 7e vertices needed: */  6,
    /* cube 7f vertices needed: */  3,
    /* cube 80 vertices needed: */  3,
    /* cube 81 vertices needed: */  6,
    /* cube 82 vertices needed: */  6,
    /* cube 83 vertices needed: */  7,
    /* cube 84 vertices needed: */  6,
    /* cube 85 vertices needed: */  7,
    /* cube 86 vertices needed: */  9,
    /* cube 87 vertices needed: */  8,
    /* cube 88 vertices needed: */  4,
    /* cube 89 vertices needed: */  7,
    /* cube 8a vertices needed: */  5,
    /* cube 8b vertices needed: */  6,
    /* cube 8c vertices needed: */  5,
    /* cube 8d vertices needed: */  6,
    /* cube 8e vertices needed: */  6,
    /* cube 8f vertices needed: */  5,
    /* cube 90 vertices needed: */  6,
    /* cube 91 vertices needed: */  7,
    /* cube 92 vertices needed: */  9,
    /* cube 93 vertices needed: */  8,
    /* cube 94 vertices needed: */  9,
    /* cube 95 vertices needed: */  8,
    /* cube 96 vertices needed: */ 12,
    /* cube 97 vertices needed: */  9,
    /* cube 98 vertices needed: */  7,
    /* cube 99 vertices needed: */  8,
    /* cube 9a vertices needed: */  8,
    /* cube 9b vertices needed: */  7,
    /* cube 9c vertices needed: */  8,
    /* cube 9d vertices needed: */  7,
    /* cube 9e vertices needed: */  9,
    /* cube 9f vertices needed: */  6,
    /* cube a0 vertices needed: */  4,
    /* cube a1 vertices needed: */  7,
    /* cube a2 vertices needed: */  5,
    /* cube a3 vertices needed: */  6,
    /* cube a4 vertices needed: */  7,
    /* cube a5 vertices needed: */  8,
    /* cube a6 vertices needed: */  8,
    /* cube a7 vertices needed: */  7,
    /* cube a8 vertices needed: */  5,
    /* cube a9 vertices needed: */  8,
    /* cube aa vertices needed: */  4,
    /* cube ab vertices needed: */  5,
    /* cube ac vertices needed: */  6,
    /* cube ad vertices needed: */  7,
    /* cube ae vertices needed: */  5,
    /* cube af vertices needed: */  4,
    /* cube b0 vertices needed: */  5,
    /* cube b1 vertices needed: */  6,
    /* cube b2 vertices needed: */  6,
    /* cube b3 vertices needed: */  5,
    /* cube b4 vertices needed: */  8,
    /* cube b5 vertices needed: */  7,
    /* cube b6 vertices needed: */  9,
    /* cube b7 vertices needed: */  6,
    /* cube b8 vertices needed: */  6,
    /* cube b9 vertices needed: */  7,
    /* cube ba vertices needed: */  5,
    /* cube bb vertices needed: */  4,
    /* cube bc vertices needed: */  7,
    /* cube bd vertices needed: */  6,
    /* cube be vertices needed: */  6,
    /* cube bf vertices needed: */  3,
    /* cube c0 vertices needed: */  4,
    /* cube c1 vertices needed: */  7,
    /* cube c2 vertices needed: */  7,
    /* cube c3 vertices needed: */  8,
    /* cube c4 vertices needed: */  5,
    /* cube c5 vertices needed: */  6,
    /* cube c6 vertices needed: */  8,
    /* cube c7 vertices needed: */  7,
    /* cube c8 vertices needed: */  5,
    /* cube c9 vertices needed: */  8,
    /* cube ca vertices needed: */  6,
    /* cube cb vertices needed: */  7,
    /* cube cc vertices needed: */  4,
    /* cube cd vertices needed: */  5,
    /* cube ce vertices needed: */  5,
    /* cube cf vertices needed: */  4,
    /* cube d0 vertices needed: */  5,
    /* cube d1 vertices needed: */  6,
    /* cube d2 vertices needed: */  8,
    /* cube d3 vertices needed: */  7,
    /* cube d4 vertices needed: */  6,
    /* cube d5 vertices needed: */  5,
    /* cube d6 vertices needed: */  9,
    /* cube d7 vertices needed: */  6,
    /* cube d8 vertices needed: */  6,
    /* cube d9 vertices needed: */  7,
    /* cube da vertices needed: */  7,
    /* cube db vertices needed: */  6,
    /* cube dc vertices needed: */  5,
    /* cube dd vertices needed: */  4,
    /* cube de vertices needed: */  6,
    /* cube df vertices needed: */  3,
    /* cube e0 vertices needed: */  5,
    /* cube e1 vertices needed: */  8,
    /* cube e2 vertices needed: */  6,
    /* cube e3 vertices needed: */  7,
    /* cube e4 vertices needed: */  6,
    /* cube e5 vertices needed: */  7,
    /* cube e6 vertices needed: */  7,
    /* cube e7 vertices needed: */  6,
    /* cube e8 vertices needed: */  6,
    /* cube e9 vertices needed: */  9,
    /* cube ea vertices needed: */  5,
    /* cube eb vertices needed: */  6,
    /* cube ec vertices needed: */  5,
    /* cube ed vertices needed: */  6,
    /* cube ee vertices needed: */  4,
    /* cube ef vertices needed: */  3,
    /* cube f0 vertices needed: */  4,
    /* cube f1 vertices needed: */  5,
    /* cube f2 vertices needed: */  5,
    /* cube f3 vertices needed: */  4,
    /* cube f4 vertices needed: */  5,
    /* cube f5 vertices needed: */  4,
    /* cube f6 vertices needed: */  6,
    /* cube f7 vertices needed: */  3,
    /* cube f8 vertices needed: */  5,
    /* cube f9 vertices needed: */  6,
    /* cube fa vertices needed: */  4,
    /* cube fb vertices needed: */  3,
    /* cube fc vertices needed: */  4,
    /* cube fd vertices needed: */  3,
    /* cube fe vertices needed: */  3,
    /* cube ff vertices needed: */  0,
};

void
xvoljfn_00(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {
}

void
xvoljfn_01(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_02(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_03(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_04(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_05(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_06(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_07(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_08(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_09(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_0a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_0b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_0c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_0d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_0e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_0f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_10(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_11(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_12(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_13(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_14(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_15(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_16(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_17(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_18(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_19(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_1a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_1b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_1c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_1d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+5] = y0;
        pz[p+5] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_1e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_1f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_20(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_21(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_22(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_23(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_24(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_25(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_26(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_27(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        px[p+5] = x0;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_28(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_29(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_2a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_2b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_2c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_2d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_2e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_2f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_30(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_31(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_32(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_33(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_34(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_35(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_36(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_37(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_38(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_39(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_3a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_3b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_3c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_3d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0+dx;
        py[p+6] = y0;
        pz[p+6] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_3e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+6] = x0;
        py[p+6] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_3f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_40(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_41(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_42(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_43(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_44(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_45(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_46(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_47(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        px[p+4] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+5] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_48(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_49(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_4a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_4b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_4c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_4d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_4e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_4f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_50(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_51(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_52(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_53(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_54(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_55(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_56(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_57(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_58(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_59(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_5a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_5b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+6] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+6] = y0+dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_5c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_5d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_5e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+6] = x0;
        py[p+6] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_5f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_60(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_61(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_62(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_63(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_64(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_65(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_66(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_67(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        px[p+5] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0;
        py[p+6] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+6] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_68(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_69(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_6a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_6b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_6c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_6d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_6e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0;
        py[p+6] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_6f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+5] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_70(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_71(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_72(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_73(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_74(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_75(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_76(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+2] = z0;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        px[p+4] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0+dx;
        py[p+6] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_77(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_78(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_79(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_7a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+6] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+6] = y0+dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_7b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_7c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+6] = x0;
        py[p+6] = y0;
        pz[p+6] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_7d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_7e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_7f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_80(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_81(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_82(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_83(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_84(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_85(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_86(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_87(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_88(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_89(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_8a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_8b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_8c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_8d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_8e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_8f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_90(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_91(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_92(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_93(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_94(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_95(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_96(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_97(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_98(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_99(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_9a(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_9b(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+6] = y0+dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_9c(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_9d(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+6] = y0;
        pz[p+6] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_9e(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_9f(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+5] = y0;
        pz[p+5] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_a0(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_a1(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_a2(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_a3(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_a4(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_a5(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_a6(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_a7(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        px[p+6] = x0;
        py[p+6] = y0+dy;
        pz[p+6] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_a8(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_a9(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_aa(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_ab(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_ac(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_ad(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+6] = x0;
        py[p+6] = y0;
        pz[p+6] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_ae(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_af(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_b0(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_b1(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_b2(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_b3(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_b4(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_b5(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+6] = x0+dx;
        py[p+6] = y0;
        pz[p+6] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_b6(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_b7(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_b8(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_b9(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+5] = z0;

        px[p+6] = x0+dx;
        py[p+6] = y0;
        pz[p+6] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_ba(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_bb(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_bc(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0;
        py[p+6] = y0+dy;
        pz[p+6] = z0 + ((e2-iso)/(e2-e6))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_bd(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_be(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_bf(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0;
        py[p+1] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e6-iso)/(e6-e7))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_c0(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_c1(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_c2(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_c3(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0+dy;
        pz[p+0] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_c4(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_c5(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_c6(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_c7(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0;
        py[p+6] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+6] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_c8(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_c9(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_ca(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_cb(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+6] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+6] = y0+dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_cc(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_cd(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_ce(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_cf(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_d0(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_d1(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+5] = y0;
        pz[p+5] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_d2(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_d3(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+6] = x0+dx;
        py[p+6] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_d4(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_d5(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_d6(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_d7(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_d8(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+5] = y0;
        pz[p+5] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_d9(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+6] = y0;
        pz[p+6] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_da(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+5] = x0;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+6] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+6] = y0+dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_db(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_dc(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_dd(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_de(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_df(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e5-iso)/(e5-e7))*dy;
        pz[p+1] = z0+dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_e0(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_e1(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_e2(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_e3(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+6] = x0+dx;
        py[p+6] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_e4(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+5] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_e5(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+4] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+4] = y0;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+5] = z0+dz;

        px[p+6] = x0;
        py[p+6] = y0;
        pz[p+6] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_e6(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+3] = z0;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        px[p+5] = x0+dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+6] = x0+dx;
        py[p+6] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+6] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;
        f0[f+4] = p;   f1[f+4] = p+5;   f2[f+4] = p+6;

        /* Update array cursors: */
        *pp = p+7;
        *pf = f+5;
    }
}

void
xvoljfn_e7(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_e8(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_e9(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_ea(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+4] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_eb(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+2] = y0;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+5] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+5] = y0+dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_ec(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_ed(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+3] = y0;
        pz[p+3] = z0+dz;

        px[p+4] = x0;
        py[p+4] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+4] = z0+dz;

        px[p+5] = x0;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_ee(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        px[p+3] = x0;
        py[p+3] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_ef(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0 + ((e4-iso)/(e4-e5))*dx;
        py[p+1] = y0;
        pz[p+1] = z0+dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e4-iso)/(e4-e6))*dy;
        pz[p+2] = z0+dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_f0(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_f1(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_f2(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_f3(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_f4(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+4] = x0;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_f5(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+3] = x0+dx;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_f6(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+2] = z0;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        px[p+4] = x0+dx;
        py[p+4] = y0+dy;
        pz[p+4] = z0 + ((e3-iso)/(e3-e7))*dz;

        px[p+5] = x0+dx;
        py[p+5] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+5] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_f7(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e7 = (float)val7;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0+dx;
        py[p+0] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+0] = z0;

        px[p+1] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+1] = y0+dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e3-iso)/(e3-e7))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_f8(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0;
        pz[p+0] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        px[p+3] = x0+dx;
        py[p+3] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+3] = z0;

        px[p+4] = x0+dx;
        py[p+4] = y0;
        pz[p+4] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;

        /* Update array cursors: */
        *pp = p+5;
        *pf = f+3;
    }
}

void
xvoljfn_f9(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e5 = (float)val5;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+1] = z0;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        px[p+4] = x0+dx;
        py[p+4] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+4] = z0;

        px[p+5] = x0+dx;
        py[p+5] = y0;
        pz[p+5] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;
        f0[f+2] = p;   f1[f+2] = p+3;   f2[f+2] = p+4;
        f0[f+3] = p;   f1[f+3] = p+4;   f2[f+3] = p+5;

        /* Update array cursors: */
        *pp = p+6;
        *pf = f+4;
    }
}

void
xvoljfn_fa(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0+dy;
        pz[p+2] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+3] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+3] = y0+dy;
        pz[p+3] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_fb(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e6 = (float)val6;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0+dy;
        pz[p+1] = z0 + ((e2-iso)/(e2-e6))*dz;

        px[p+2] = x0 + ((e2-iso)/(e2-e3))*dx;
        py[p+2] = y0+dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_fc(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e3 = (float)val3;
        float e4 = (float)val4;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0;
        py[p+0] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        px[p+3] = x0;
        py[p+3] = y0;
        pz[p+3] = z0 + ((e0-iso)/(e0-e4))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;
        f0[f+1] = p;   f1[f+1] = p+2;   f2[f+1] = p+3;

        /* Update array cursors: */
        *pp = p+4;
        *pf = f+2;
    }
}

void
xvoljfn_fd(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e3 = (float)val3;
        float e5 = (float)val5;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0+dx;
        py[p+1] = y0 + ((e1-iso)/(e1-e3))*dy;
        pz[p+1] = z0;

        px[p+2] = x0+dx;
        py[p+2] = y0;
        pz[p+2] = z0 + ((e1-iso)/(e1-e5))*dz;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_fe(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {

    {   /* Cache array cursors: */
        int   f = *pf;
        int   p = *pp;

        /* Cache needed cube corners: */
        float e0 = (float)val0;
        float e1 = (float)val1;
        float e2 = (float)val2;
        float e4 = (float)val4;



        /* Find isosurface/edge intersections */
        /* via linear interpolation:          */

        px[p+0] = x0 + ((e0-iso)/(e0-e1))*dx;
        py[p+0] = y0;
        pz[p+0] = z0;

        px[p+1] = x0;
        py[p+1] = y0;
        pz[p+1] = z0 + ((e0-iso)/(e0-e4))*dz;

        px[p+2] = x0;
        py[p+2] = y0 + ((e0-iso)/(e0-e2))*dy;
        pz[p+2] = z0;

        /* Insert facets for this path: */
        f0[f+0] = p;   f1[f+0] = p+1;   f2[f+0] = p+2;

        /* Update array cursors: */
        *pp = p+3;
        *pf = f+1;
    }
}

void
xvoljfn_ff(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) {
}

void
(*xvolj2_fn[256])(
    int*   pf,  /* Where to insert next facet */
    int*   pp,  /* Where to insert next point */
    float* px,  /* Array to hold output point x vals */
    float* py,  /* Array to hold output point y vals */
    float* pz,  /* Array to hold output point z vals */
    int*   f0,  /* Array to hold 1st point of output triangles */
    int*   f1,  /* Array to hold 2nd point of output triangles */
    int*   f2,  /* Array to hold 3rd point of output triangles */
    float  x0,  /* X-Coord of voxel's 000 corner */
    float  y0,  /* Y-Coord of voxel's 000 corner */
    float  z0,  /* Z-Coord of voxel's 000 corner */
    float  dx,  /* X-Length of voxel */
    float  dy,  /* Y-Length of voxel */
    float  dz,  /* Z-Length of voxel */
    float  iso, /* Isosurface threshhold value */
    int val0, /* Fn value at corner 000 of voxel */
    int val1, /* Fn value at corner 001 of voxel */
    int val2, /* Fn value at corner 010 of voxel */
    int val3, /* Fn value at corner 011 of voxel */
    int val4, /* Fn value at corner 100 of voxel */
    int val5, /* Fn value at corner 101 of voxel */
    int val6, /* Fn value at corner 110 of voxel */
    int val7  /* Fn value at corner 111 of voxel */
) = {
    xvoljfn_00,
    xvoljfn_01,
    xvoljfn_02,
    xvoljfn_03,
    xvoljfn_04,
    xvoljfn_05,
    xvoljfn_06,
    xvoljfn_07,
    xvoljfn_08,
    xvoljfn_09,
    xvoljfn_0a,
    xvoljfn_0b,
    xvoljfn_0c,
    xvoljfn_0d,
    xvoljfn_0e,
    xvoljfn_0f,
    xvoljfn_10,
    xvoljfn_11,
    xvoljfn_12,
    xvoljfn_13,
    xvoljfn_14,
    xvoljfn_15,
    xvoljfn_16,
    xvoljfn_17,
    xvoljfn_18,
    xvoljfn_19,
    xvoljfn_1a,
    xvoljfn_1b,
    xvoljfn_1c,
    xvoljfn_1d,
    xvoljfn_1e,
    xvoljfn_1f,
    xvoljfn_20,
    xvoljfn_21,
    xvoljfn_22,
    xvoljfn_23,
    xvoljfn_24,
    xvoljfn_25,
    xvoljfn_26,
    xvoljfn_27,
    xvoljfn_28,
    xvoljfn_29,
    xvoljfn_2a,
    xvoljfn_2b,
    xvoljfn_2c,
    xvoljfn_2d,
    xvoljfn_2e,
    xvoljfn_2f,
    xvoljfn_30,
    xvoljfn_31,
    xvoljfn_32,
    xvoljfn_33,
    xvoljfn_34,
    xvoljfn_35,
    xvoljfn_36,
    xvoljfn_37,
    xvoljfn_38,
    xvoljfn_39,
    xvoljfn_3a,
    xvoljfn_3b,
    xvoljfn_3c,
    xvoljfn_3d,
    xvoljfn_3e,
    xvoljfn_3f,
    xvoljfn_40,
    xvoljfn_41,
    xvoljfn_42,
    xvoljfn_43,
    xvoljfn_44,
    xvoljfn_45,
    xvoljfn_46,
    xvoljfn_47,
    xvoljfn_48,
    xvoljfn_49,
    xvoljfn_4a,
    xvoljfn_4b,
    xvoljfn_4c,
    xvoljfn_4d,
    xvoljfn_4e,
    xvoljfn_4f,
    xvoljfn_50,
    xvoljfn_51,
    xvoljfn_52,
    xvoljfn_53,
    xvoljfn_54,
    xvoljfn_55,
    xvoljfn_56,
    xvoljfn_57,
    xvoljfn_58,
    xvoljfn_59,
    xvoljfn_5a,
    xvoljfn_5b,
    xvoljfn_5c,
    xvoljfn_5d,
    xvoljfn_5e,
    xvoljfn_5f,
    xvoljfn_60,
    xvoljfn_61,
    xvoljfn_62,
    xvoljfn_63,
    xvoljfn_64,
    xvoljfn_65,
    xvoljfn_66,
    xvoljfn_67,
    xvoljfn_68,
    xvoljfn_69,
    xvoljfn_6a,
    xvoljfn_6b,
    xvoljfn_6c,
    xvoljfn_6d,
    xvoljfn_6e,
    xvoljfn_6f,
    xvoljfn_70,
    xvoljfn_71,
    xvoljfn_72,
    xvoljfn_73,
    xvoljfn_74,
    xvoljfn_75,
    xvoljfn_76,
    xvoljfn_77,
    xvoljfn_78,
    xvoljfn_79,
    xvoljfn_7a,
    xvoljfn_7b,
    xvoljfn_7c,
    xvoljfn_7d,
    xvoljfn_7e,
    xvoljfn_7f,
    xvoljfn_80,
    xvoljfn_81,
    xvoljfn_82,
    xvoljfn_83,
    xvoljfn_84,
    xvoljfn_85,
    xvoljfn_86,
    xvoljfn_87,
    xvoljfn_88,
    xvoljfn_89,
    xvoljfn_8a,
    xvoljfn_8b,
    xvoljfn_8c,
    xvoljfn_8d,
    xvoljfn_8e,
    xvoljfn_8f,
    xvoljfn_90,
    xvoljfn_91,
    xvoljfn_92,
    xvoljfn_93,
    xvoljfn_94,
    xvoljfn_95,
    xvoljfn_96,
    xvoljfn_97,
    xvoljfn_98,
    xvoljfn_99,
    xvoljfn_9a,
    xvoljfn_9b,
    xvoljfn_9c,
    xvoljfn_9d,
    xvoljfn_9e,
    xvoljfn_9f,
    xvoljfn_a0,
    xvoljfn_a1,
    xvoljfn_a2,
    xvoljfn_a3,
    xvoljfn_a4,
    xvoljfn_a5,
    xvoljfn_a6,
    xvoljfn_a7,
    xvoljfn_a8,
    xvoljfn_a9,
    xvoljfn_aa,
    xvoljfn_ab,
    xvoljfn_ac,
    xvoljfn_ad,
    xvoljfn_ae,
    xvoljfn_af,
    xvoljfn_b0,
    xvoljfn_b1,
    xvoljfn_b2,
    xvoljfn_b3,
    xvoljfn_b4,
    xvoljfn_b5,
    xvoljfn_b6,
    xvoljfn_b7,
    xvoljfn_b8,
    xvoljfn_b9,
    xvoljfn_ba,
    xvoljfn_bb,
    xvoljfn_bc,
    xvoljfn_bd,
    xvoljfn_be,
    xvoljfn_bf,
    xvoljfn_c0,
    xvoljfn_c1,
    xvoljfn_c2,
    xvoljfn_c3,
    xvoljfn_c4,
    xvoljfn_c5,
    xvoljfn_c6,
    xvoljfn_c7,
    xvoljfn_c8,
    xvoljfn_c9,
    xvoljfn_ca,
    xvoljfn_cb,
    xvoljfn_cc,
    xvoljfn_cd,
    xvoljfn_ce,
    xvoljfn_cf,
    xvoljfn_d0,
    xvoljfn_d1,
    xvoljfn_d2,
    xvoljfn_d3,
    xvoljfn_d4,
    xvoljfn_d5,
    xvoljfn_d6,
    xvoljfn_d7,
    xvoljfn_d8,
    xvoljfn_d9,
    xvoljfn_da,
    xvoljfn_db,
    xvoljfn_dc,
    xvoljfn_dd,
    xvoljfn_de,
    xvoljfn_df,
    xvoljfn_e0,
    xvoljfn_e1,
    xvoljfn_e2,
    xvoljfn_e3,
    xvoljfn_e4,
    xvoljfn_e5,
    xvoljfn_e6,
    xvoljfn_e7,
    xvoljfn_e8,
    xvoljfn_e9,
    xvoljfn_ea,
    xvoljfn_eb,
    xvoljfn_ec,
    xvoljfn_ed,
    xvoljfn_ee,
    xvoljfn_ef,
    xvoljfn_f0,
    xvoljfn_f1,
    xvoljfn_f2,
    xvoljfn_f3,
    xvoljfn_f4,
    xvoljfn_f5,
    xvoljfn_f6,
    xvoljfn_f7,
    xvoljfn_f8,
    xvoljfn_f9,
    xvoljfn_fa,
    xvoljfn_fb,
    xvoljfn_fc,
    xvoljfn_fd,
    xvoljfn_fe,
    xvoljfn_ff,
};

