/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xvol.h
* Description:  Hybrid-class header for volume imaging/processing stuff
* Author:       Jeff Prothero
* Created:      95Jul14
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1996, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifdef MODULE_XLDMEM_H_GLOBALS

extern LVAL xvolcz_Get_Voxel_Slice_Fn();
extern LVAL xvoldz_Render_Fn();
extern LVAL xvole4_Fill_Histogram_Fn();
extern LVAL xvoled_Build_Rendering_Relation_Fn();
extern LVAL xvolfz_Render_In_Color_Fn();
extern LVAL xvolg4_Mirror_Voxels_Axially_Fn();
extern LVAL xvolg8_Mirror_Voxels_Diagonally_Fn();
extern LVAL xvolgc_Circulate_Voxels_Axially_Fn();
extern LVAL xvolgk_Resize_Voxels_Axially_Fn();
extern LVAL xvolh0_Dump_Voxels_To_File_Fn();
extern LVAL xvolha_Dump_Voxels_As_Slices_Fn();
extern LVAL xvolh2_Read_AVS_Field_From_File_Fn();
extern LVAL xvolh6_Resample_Volume_Fn();
extern LVAL xvolh9_Transform_Volume_Fn();
extern LVAL xvoliz_Render_Max_Intensity_Fn();
extern LVAL xvoljz_Insert_Isosurface_Fn();
extern LVAL xvolkz_Merge_Redundant_Points_Fn();
extern LVAL xvollz_Compute_Unnormalized_Facet_Normals_Fn();
extern LVAL xvolmz_Accumulate_Unnormalized_Point_Normals_Fn();
extern LVAL xvolnz_Set_Facet_Normals_To_Unit_Length_Fn();
extern LVAL xvolo3_Information_Content_Fn();
extern LVAL xvolsz_Subsample_Array_Fn();

#ifndef EXTERNED_K_GE_U_CHAR
extern LVAL k_ge_u_char;/* Symbol ":GE-U-CHAR" */
#define EXTERNED_K_GE_U_CHAR
#endif

#ifndef EXTERNED_K_GE_CHAR
extern LVAL k_ge_char;/* Symbol ":GE-CHAR" */
#define EXTERNED_K_GE_CHAR
#endif

#ifndef EXTERNED_K_GE_U_SHORT
extern LVAL k_ge_u_short;/* Symbol ":GE-U-SHORT" */
#define EXTERNED_K_GE_U_SHORT
#endif

#ifndef EXTERNED_K_GE_SHORT
extern LVAL k_ge_short;/* Symbol ":GE-SHORT" */
#define EXTERNED_K_GE_SHORT
#endif

#ifndef EXTERNED_K_GE_U_INT
extern LVAL k_ge_u_int;/* Symbol ":GE-U-INT" */
#define EXTERNED_K_GE_U_INT
#endif

#ifndef EXTERNED_K_GE_INT
extern LVAL k_ge_int;/* Symbol ":GE-INT" */
#define EXTERNED_K_GE_INT
#endif

#ifndef EXTERNED_K_GE_FLOAT
extern LVAL k_ge_float;/* Symbol ":GE-FLOAT" */
#define EXTERNED_K_GE_FLOAT
#endif

#ifndef EXTERNED_K_GE_DOUBLE
extern LVAL k_ge_double;/* Symbol ":GE-DOUBLE" */
#define EXTERNED_K_GE_DOUBLE
#endif

#ifndef EXTERNED_K_MIN
extern LVAL k_min;/* Symbol ":MIN" */
#define EXTERNED_K_MIN
#endif

#ifndef EXTERNED_K_MAX
extern LVAL k_max;/* Symbol ":MAX" */
#define EXTERNED_K_MAX
#endif

#ifndef EXTERNED_K_INTENSITY
extern LVAL k_intensity;/* Symbol ":INTENSITY" */
#define EXTERNED_K_INTENSITY
#endif

#ifndef EXTERNED_K_REVERSE_X
extern LVAL k_reverse_x;/* Symbol ":REVERSE-X" */
#define EXTERNED_K_REVERSE_X
#endif

#ifndef EXTERNED_K_RESULT_IN
extern LVAL k_result_in;/* Symbol ":RESULT-IN" */
#define EXTERNED_K_RESULT_IN
#endif

#ifndef EXTERNED_K_AXIS
extern LVAL k_axis;/* Symbol ":AXIS" */
#define EXTERNED_K_AXIS
#endif

#ifndef EXTERNED_K_FILENAME
extern LVAL k_filename;/* Symbol ":FILE-NAME" */
#define EXTERNED_K_FILENAME
#endif

#ifndef EXTERNED_K_SLICE
extern LVAL k_slice;/* Symbol ":SLICE" */
#define EXTERNED_K_SLICE
#endif

#ifndef EXTERNED_K_SUBSAMPLE_BY
extern LVAL k_subsample_by;/* Symbol ":SUBSAMPLE-BY" */
#define EXTERNED_K_SUBSAMPLE_BY
#endif

#ifndef EXTERNED_K_ZOOM_BY
extern LVAL k_zoom_by;/* Symbol ":ZOOM-BY" */
#define EXTERNED_K_ZOOM_BY
#endif

#ifndef EXTERNED_K_VOXELS
extern LVAL k_voxels;/* Symbol ":VOXELS" */
#define EXTERNED_K_VOXELS
#endif

#ifndef EXTERNED_K_ISOLEVEL
extern LVAL k_isolevel;/* Symbol ":ISOLEVEL" */
#define EXTERNED_K_ISOLEVEL
#endif

#ifndef EXTERNED_K_BIN_SIZE
extern LVAL k_bin_size;/* Symbol ":BIN-SIZE" */
#define EXTERNED_K_BIN_SIZE
#endif

#ifndef EXTERNED_K_RENDERING_RELATION
extern LVAL k_rendering_relation;/* Symbol ":RENDERING-RELATION" */
#define EXTERNED_K_RENDERING_RELATION
#endif

#ifndef EXTERNED_K_DIFFUSE_RED
extern LVAL k_diffuse_red;/* Symbol ":DIFFUSE-RED" */
#define EXTERNED_K_DIFFUSE_RED
#endif

#ifndef EXTERNED_K_DIFFUSE_GREEN
extern LVAL k_diffuse_green;/* Symbol ":DIFFUSE-GREEN" */
#define EXTERNED_K_DIFFUSE_GREEN
#endif

#ifndef EXTERNED_K_DIFFUSE_BLUE
extern LVAL k_diffuse_blue;/* Symbol ":DIFFUSE-BLUE" */
#define EXTERNED_K_DIFFUSE_BLUE
#endif

#ifndef EXTERNED_K_ALPHA
extern LVAL k_alpha;/* Symbol ":ALPHA" */
#define EXTERNED_K_ALPHA
#endif

#ifndef EXTERNED_K_RANGE
extern LVAL k_range;/* Symbol ":RANGE" */
#define EXTERNED_K_RANGE
#endif

#ifndef EXTERNED_K_SRC_MIN
extern LVAL k_src_min;/* Symbol ":SRC-MIN" */
#define EXTERNED_K_SRC_MIN
#endif

#ifndef EXTERNED_K_SRC_MAX
extern LVAL k_src_max;/* Symbol ":SRC-MAX" */
#define EXTERNED_K_SRC_MAX
#endif

#ifndef EXTERNED_K_DST_MIN
extern LVAL k_dst_min;/* Symbol ":DST-MIN" */
#define EXTERNED_K_DST_MIN
#endif

#ifndef EXTERNED_K_DST_MAX
extern LVAL k_dst_max;/* Symbol ":DST-MAX" */
#define EXTERNED_K_DST_MAX
#endif

#ifndef EXTERNED_K_DEPTH
extern LVAL k_depth;/* Symbol ":DEPTH" */
#define EXTERNED_K_DEPTH
#endif

#ifndef EXTERNED_K_PIXELDEPTH
extern LVAL k_pixeldepth;/* Symbol ":PIXEL-DEPTH" */
#define EXTERNED_K_PIXELDEPTH
#endif

#ifndef EXTERNED_K_FILE_OFFSET
extern LVAL k_file_offset;/* Symbol ":FILE-OFFSET" */
#define EXTERNED_K_FILE_OFFSET
#endif

#ifndef EXTERNED_K_ROWS
extern LVAL k_rows;/* Symbol ":ROWS" */
#define EXTERNED_K_ROWS
#endif

#ifndef EXTERNED_K_COLS
extern LVAL k_cols;/* Symbol ":COLS" */
#define EXTERNED_K_COLS
#endif

#ifndef EXTERNED_K_DISTANCE
extern LVAL k_distance;/* Symbol ":DISTANCE" */
#define EXTERNED_K_DISTANCE
#endif

#ifndef EXTERNED_K_FILTER_SHAPE
extern LVAL k_filter_shape;/* Symbol ":FILTER-SHAPE" */
#define EXTERNED_K_FILTER_SHAPE
#endif

#ifndef EXTERNED_K_IMPULSE
extern LVAL k_impulse;/* Symbol ":IMPULSE" */
#define EXTERNED_K_IMPULSE
#endif

#ifndef EXTERNED_K_BOX
extern LVAL k_box;/* Symbol ":BOX" */
#define EXTERNED_K_BOX
#endif

#ifndef EXTERNED_K_TRIANGLE
extern LVAL k_triangle;/* Symbol ":TRIANGLE" */
#define EXTERNED_K_TRIANGLE
#endif

#ifndef EXTERNED_K_QUADRATIC
extern LVAL k_quadratic;/* Symbol ":QUADRATIC" */
#define EXTERNED_K_QUADRATIC
#endif

#ifndef EXTERNED_K_MITCHELL
extern LVAL k_mitchell;/* Symbol ":MITCHELL" */
#define EXTERNED_K_MITCHELL
#endif

#ifndef EXTERNED_K_ZERO_REST
extern LVAL k_zero_rest;/* Symbol ":ZERO-REST" */
#define EXTERNED_K_ZERO_REST
#endif

#ifndef EXTERNED_K_PLANE
extern LVAL k_plane;/* Symbol ":PLANE" */
#define EXTERNED_K_PLANE
#endif

#ifndef EXTERNED_K_PLANE
extern LVAL k_plane;/* Symbol ":PLANE" */
#define EXTERNED_K_PLANE
#endif

#ifndef EXTERNED_K_DEPTH_IN_BITS
extern LVAL k_depth_in_bits;/* Symbol ":DEPTH-IN-BITS" */
#define EXTERNED_K_DEPTH_IN_BITS
#endif

#ifndef EXTERNED_K_ENDIAN
extern LVAL k_endian;/* Symbol ":ENDIAN" */
#define EXTERNED_K_ENDIAN
#endif

#ifndef EXTERNED_K_BIG
extern LVAL k_big;/* Symbol ":BIG" */
#define EXTERNED_K_BIG
#endif

#ifndef EXTERNED_K_LITTLE
extern LVAL k_little;/* Symbol ":LITTLE" */
#define EXTERNED_K_LITTLE
#endif

#ifndef EXTERNED_K_ENDIAN
extern LVAL k_endian;/* Symbol ":ENDIAN" */
#define EXTERNED_K_ENDIAN
#endif

#ifndef EXTERNED_K_PADDING
extern LVAL k_padding;/* Symbol ":PADDING" */
#define EXTERNED_K_PADDING
#endif

#ifndef EXTERNED_K_FORMAT
extern LVAL k_format;/* Symbol ":FORMAT" */
#define EXTERNED_K_FORMAT
#endif

#ifndef EXTERNED_K_AVS_UNIFORM_FIELD
extern LVAL k_avs_uniform_field;/* Symbol ":AVS-UNIFORM-FIELD" */
#define EXTERNED_K_AVS_UNIFORM_FIELD
#endif

#ifndef EXTERNED_K_MINX
extern LVAL k_minx;/* Symbol ":MIN-X" */
#define EXTERNED_K_MINX
#endif

#ifndef EXTERNED_K_MAXX
extern LVAL k_maxx;/* Symbol ":MAX-X" */
#define EXTERNED_K_MAXX
#endif

#ifndef EXTERNED_K_MINY
extern LVAL k_miny;/* Symbol ":MIN-Y" */
#define EXTERNED_K_MINY
#endif

#ifndef EXTERNED_K_MAXY
extern LVAL k_maxy;/* Symbol ":MAX-Y" */
#define EXTERNED_K_MAXY
#endif

#ifndef EXTERNED_K_MINZ
extern LVAL k_minz;/* Symbol ":MIN-Z" */
#define EXTERNED_K_MINZ
#endif

#ifndef EXTERNED_K_MAXZ
extern LVAL k_maxz;/* Symbol ":MAX-Z" */
#define EXTERNED_K_MAXZ
#endif

#ifndef EXTERNED_K_MINI
extern LVAL k_mini;/* Symbol ":MIN-I" */
#define EXTERNED_K_MINI
#endif

#ifndef EXTERNED_K_MAXI
extern LVAL k_maxi;/* Symbol ":MAX-I" */
#define EXTERNED_K_MAXI
#endif

#ifndef EXTERNED_K_MINJ
extern LVAL k_minj;/* Symbol ":MIN-J" */
#define EXTERNED_K_MINJ
#endif

#ifndef EXTERNED_K_MAXJ
extern LVAL k_maxj;/* Symbol ":MAX-J" */
#define EXTERNED_K_MAXJ
#endif

#ifndef EXTERNED_K_MINK
extern LVAL k_mink;/* Symbol ":MIN-K" */
#define EXTERNED_K_MINK
#endif

#ifndef EXTERNED_K_MAXK
extern LVAL k_maxk;/* Symbol ":MAX-K" */
#define EXTERNED_K_MAXK
#endif

#ifndef EXTERNED_K_MAX_FACETS
extern LVAL k_max_facets;/* Symbol ":MAX-FACETS" */
#define EXTERNED_K_MAX_FACETS
#endif

#ifndef EXTERNED_ITERATIONS
extern LVAL k_iterations;   /* Keyword ":ITERATIONS" */
#define EXTERNED_ITERATIONS
#endif

#ifndef EXTERNED_WEIGHT
extern LVAL k_weight;   /* Keyword ":WEIGHT" */
#define EXTERNED_WEIGHT
#endif

#ifndef EXTERNED_ARRAY
extern LVAL k_array;   /* Keyword ":ARRAY" */
#define EXTERNED_ARRAY
#endif

#ifndef EXTERNED_PREFIX
extern LVAL k_prefix;   /* Keyword ":PREFIX" */
#define EXTERNED_PREFIX
#endif

#ifndef EXTERNED_SUFFIX
extern LVAL k_suffix;   /* Keyword ":SUFFIX" */
#define EXTERNED_SUFFIX
#endif


#endif


#ifdef MODULE_XLFTAB_C_FUNTAB_S

DEFINE_SUBR( "XVOL-GET-VOXEL-SLICE",		xvolcz_Get_Voxel_Slice_Fn)
DEFINE_SUBR( "XVOL-RENDER",			xvoldz_Render_Fn	)
DEFINE_SUBR( "XVOL-FILL-HISTOGRAM",		xvole4_Fill_Histogram_Fn)
DEFINE_SUBR( "XVOL-RENDER-IN-COLOR",		xvolfz_Render_In_Color_Fn)
DEFINE_SUBR( "XVOL-RENDER-MAX-INTENSITY",	xvoliz_Render_Max_Intensity_Fn)
DEFINE_SUBR( "XVOL-BUILD-RENDERING-RELATION",	xvoled_Build_Rendering_Relation_Fn)
DEFINE_SUBR( "XVOL-MIRROR-VOXELS-AXIALLY",	xvolg4_Mirror_Voxels_Axially_Fn)
DEFINE_SUBR( "XVOL-MIRROR-VOXELS-DIAGONALLY",	xvolg8_Mirror_Voxels_Diagonally_Fn)
DEFINE_SUBR( "XVOL-CIRCULATE-VOXELS-AXIALLY",	xvolgc_Circulate_Voxels_Axially_Fn)
DEFINE_SUBR( "XVOL-RESIZE-VOXELS-AXIALLY",	xvolgk_Resize_Voxels_Axially_Fn)
DEFINE_SUBR( "XVOL-DUMP-VOXELS-TO-FILE",	xvolh0_Dump_Voxels_To_File_Fn)
DEFINE_SUBR( "XVOL-DUMP-VOXELS-AS-SLICES",	xvolha_Dump_Voxels_As_Slices_Fn)
DEFINE_SUBR( "XVOL-READ-AVS-FIELD-FROM-FILE",	xvolh2_Read_AVS_Field_From_File_Fn)
DEFINE_SUBR( "XVOL-RESAMPLE-VOLUME",	        xvolh6_Resample_Volume_Fn)
DEFINE_SUBR( "XVOL-TRANSFORM-VOLUME",        	xvolh9_Transform_Volume_Fn)
DEFINE_SUBR( "XVOL-INSERT-ISOSURFACE",        	xvoljz_Insert_Isosurface_Fn)
DEFINE_SUBR( "XVOL-MERGE-REDUNDANT-POINTS",     xvolkz_Merge_Redundant_Points_Fn)
DEFINE_SUBR( "XVOL-COMPUTE-UNNORMALIZED-FACET-NORMALS",xvollz_Compute_Unnormalized_Facet_Normals_Fn)
DEFINE_SUBR( "XVOL-ACCUMULATE-UNNORMALIZED-POINT-NORMALS",xvolmz_Accumulate_Unnormalized_Point_Normals_Fn)
DEFINE_SUBR( "XVOL-SET-FACET-NORMALS-TO-UNIT-LENGTH", xvolnz_Set_Facet_Normals_To_Unit_Length_Fn)
DEFINE_SUBR( "XVOL-INFORMATION-CONTENT", xvolo3_Information_Content_Fn)
DEFINE_SUBR( "XVOL-COMPUTE-UNNORMALIZED-POINT-NORMALS",xvolpz_Compute_Unnormalized_Point_Normals_Fn)
DEFINE_SUBR( "XVOL-SET-POINT-NORMALS-TO-UNIT-LENGTH", xvolqz_Set_Point_Normals_To_Unit_Length_Fn)
DEFINE_SUBR( "XVOL-AVERAGE-POINT-NORMALS", xvolrz_Average_Point_Normals_Fn)
DEFINE_SUBR( "XVOL-SUBSAMPLE-ARRAY", xvolsz_Subsample_Array_Fn)
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS

#ifndef DEFINED_K_MIN
LVAL k_min;/* Symbol ":MIN" */
#define DEFINED_K_MIN
#endif

#ifndef DEFINED_K_MAX
LVAL k_max;/* Symbol ":MAX" */
#define DEFINED_K_MAX
#endif

#ifndef DEFINED_K_INTENSITY
LVAL k_intensity;/* Symbol ":INTENSITY" */
#define DEFINED_K_INTENSITY
#endif

#ifndef DEFINED_K_REVERSE_X
LVAL k_reverse_x;/* Symbol ":REVERSE-X" */
#define DEFINED_K_REVERSE_X
#endif

#ifndef DEFINED_K_RESULT_IN
LVAL k_result_in;/* Symbol ":RESULT-IN" */
#define DEFINED_K_RESULT_IN
#endif

#ifndef DEFINED_K_AXIS
LVAL k_axis;/* Symbol ":AXIS" */
#define DEFINED_K_AXIS
#endif

#ifndef DEFINED_K_FILENAME
LVAL k_filename;/* Symbol ":FILE-NAME" */
#define DEFINED_K_FILENAME
#endif

#ifndef DEFINED_K_SLICE
LVAL k_slice;/* Symbol ":SLICE" */
#define DEFINED_K_SLICE
#endif

#ifndef DEFINED_K_SUBSAMPLE_BY
LVAL k_subsample_by;/* Symbol ":SUBSAMPLE-BY" */
#define DEFINED_K_SUBSAMPLE_BY
#endif

#ifndef DEFINED_K_ZOOM_BY
LVAL k_zoom_by;		/* Symbol ":ZOOM-BY" */
#define DEFINED_K_ZOOM_BY
#endif

#ifndef DEFINED_K_VOXELS
LVAL k_voxels;		/* Symbol ":VOXELS" */
#define DEFINED_K_VOXELS
#endif

#ifndef DEFINED_K_ISOLEVEL
LVAL k_isolevel;	/* Symbol ":ISOLEVEL" */
#define DEFINED_K_ISOLEVEL
#endif

#ifndef DEFINED_K_BIN_SIZE
LVAL k_bin_size;	/* Symbol ":BIN-SIZE" */
#define DEFINED_K_BIN_SIZE
#endif

#ifndef DEFINED_K_RENDERING_RELATION
LVAL k_rendering_relation;	/* Symbol ":RENDERING-RELATION" */
#define DEFINED_K_RENDERING_RELATION
#endif

#ifndef DEFINED_K_DIFFUSE_RED
LVAL k_diffuse_red;	/* Symbol ":DIFFUSE-RED" */
#define DEFINED_K_DIFFUSE_RED
#endif

#ifndef DEFINED_K_DIFFUSE_GREEN
LVAL k_diffuse_green;	/* Symbol ":DIFFUSE-GREEN" */
#define DEFINED_K_DIFFUSE_GREEN
#endif

#ifndef DEFINED_K_DIFFUSE_BLUE
LVAL k_diffuse_blue;	/* Symbol ":DIFFUSE-BLUE" */
#define DEFINED_K_DIFFUSE_BLUE
#endif

#ifndef DEFINED_K_ALPHA
LVAL k_alpha;	/* Symbol ":ALPHA" */
#define DEFINED_K_ALPHA
#endif

#ifndef DEFINED_K_RANGE
LVAL k_range;	/* Symbol ":RANGE" */
#define DEFINED_K_RANGE
#endif

#ifndef DEFINED_K_DST_MIN
LVAL k_dst_min;	/* Symbol ":DST-MIN" */
#define DEFINED_K_DST_MIN
#endif

#ifndef DEFINED_K_DST_MAX
LVAL k_dst_max;	/* Symbol ":DST-MAX" */
#define DEFINED_K_DST_MAX
#endif

#ifndef DEFINED_K_SRC_MIN
LVAL k_src_min;	/* Symbol ":SRC-MIN" */
#define DEFINED_K_SRC_MIN
#endif

#ifndef DEFINED_K_SRC_MAX
LVAL k_src_max;	/* Symbol ":SRC-MAX" */
#define DEFINED_K_SRC_MAX
#endif

#ifndef DEFINED_K_DEPTH
LVAL k_depth;	/* Symbol ":DEPTH" */
#define DEFINED_K_DEPTH
#endif

#ifndef DEFINED_K_PIXELDEPTH
LVAL k_pixeldepth;	/* Symbol ":PIXEL-DEPTH" */
#define DEFINED_K_PIXELDEPTH
#endif

#ifndef DEFINED_K_FILE_OFFSET
LVAL k_file_offset;	/* Symbol ":FILE-OFFSET" */
#define DEFINED_K_FILE_OFFSET
#endif

#ifndef DEFINED_K_ROWS
LVAL k_rows;	/* Symbol ":ROWS" */
#define DEFINED_K_ROWS
#endif

#ifndef DEFINED_K_COLS
LVAL k_cols;	/* Symbol ":COLS" */
#define DEFINED_K_COLS
#endif

#ifndef DEFINED_K_DISTANCE
LVAL k_distance;/* Symbol ":DISTANCE" */
#define DEFINED_K_DISTANCE
#endif

#ifndef DEFINED_K_FILTER_SHAPE
LVAL k_filter_shape;/* Symbol ":FILTER-SHAPE" */
#define DEFINED_K_FILTER_SHAPE
#endif

#ifndef DEFINED_IMPULSE
LVAL k_impulse;   /* Keyword ":impulse" */
#define DEFINED_IMPULSE
#endif

#ifndef DEFINED_TRIANGLE
LVAL k_triangle;   /* Keyword ":triangle" */
#define DEFINED_IMPULSE
#endif

#ifndef DEFINED_BOX
LVAL k_box;   /* Keyword ":box" */
#define DEFINED_BOX
#endif

#ifndef DEFINED_QUADRATIC
LVAL k_quadratic;   /* Keyword ":quadratic" */
#define DEFINED_QUADRATIC
#endif

#ifndef DEFINED_MITCHELL
LVAL k_mitchell;   /* Keyword ":mitchell" */
#define DEFINED_MITCHELL
#endif

#ifndef DEFINED_K_ZERO_REST
LVAL k_zero_rest;/* Symbol ":ZERO-REST" */
#define DEFINED_K_ZERO_REST
#endif

#ifndef DEFINED_K_PLANE
LVAL k_plane;/* Symbol ":PLANE" */
#define DEFINED_K_PLANE
#endif

#ifndef DEFINED_K_DEPTH_IN_BITS
LVAL k_depth_in_bits;/* Symbol ":DEPTH-IN-BITS" */
#define DEFINED_K_DEPTH_IN_BITS
#endif

#ifndef DEFINED_K_ENDIAN
LVAL k_endian;/* Symbol ":ENDIAN" */
#define DEFINED_K_ENDIAN
#endif

#ifndef DEFINED_K_BIG
LVAL k_big;/* Symbol ":BIG" */
#define DEFINED_K_BIG
#endif

#ifndef DEFINED_K_LITTLE
LVAL k_little;/* Symbol ":LITTLE" */
#define DEFINED_K_LITTLE
#endif

#ifndef DEFINED_K_PADDING
LVAL k_padding;/* Symbol ":PADDING" */
#define DEFINED_K_PADDING
#endif

#ifndef DEFINED_K_FORMAT
LVAL k_format;/* Symbol ":FORMAT" */
#define DEFINED_K_FORMAT
#endif

#ifndef DEFINED_K_AVS_UNIFORM_FIELD
LVAL k_avs_uniform_field;/* Symbol ":AVS-UNIFORM-FIELD" */
#define DEFINED_K_AVS_UNIFORM_FIELD
#endif

#ifndef DEFINED_K_MINX
LVAL k_minx;/* Symbol ":MIN-X" */
#define DEFINED_K_MINX
#endif

#ifndef DEFINED_K_MAXX
LVAL k_maxx;/* Symbol ":MAX-X" */
#define DEFINED_K_MAXX
#endif

#ifndef DEFINED_K_MINY
LVAL k_miny;/* Symbol ":MIN-Y" */
#define DEFINED_K_MINY
#endif

#ifndef DEFINED_K_MAXY
LVAL k_maxy;/* Symbol ":MAX-Y" */
#define DEFINED_K_MAXY
#endif

#ifndef DEFINED_K_MINZ
LVAL k_minz;/* Symbol ":MIN-Z" */
#define DEFINED_K_MINZ
#endif

#ifndef DEFINED_K_MAXZ
LVAL k_maxz;/* Symbol ":MAX-Z" */
#define DEFINED_K_MAXZ
#endif

#ifndef DEFINED_K_MINI
LVAL k_mini;/* Symbol ":MIN-I" */
#define DEFINED_K_MINI
#endif

#ifndef DEFINED_K_MAXI
LVAL k_maxi;/* Symbol ":MAX-I" */
#define DEFINED_K_MAXI
#endif

#ifndef DEFINED_K_MINJ
LVAL k_minj;/* Symbol ":MIN-J" */
#define DEFINED_K_MINJ
#endif

#ifndef DEFINED_K_MAXJ
LVAL k_maxj;/* Symbol ":MAX-J" */
#define DEFINED_K_MAXJ
#endif

#ifndef DEFINED_K_MINK
LVAL k_mink;/* Symbol ":MIN-K" */
#define DEFINED_K_MINK
#endif

#ifndef DEFINED_K_MAXK
LVAL k_maxk;/* Symbol ":MAX-K" */
#define DEFINED_K_MAXK
#endif

#ifndef DEFINED_K_MAX_FACETS
LVAL k_max_facets;/* Symbol ":MAX-FACETS" */
#define DEFINED_K_MAX_FACETS
#endif

#ifndef DEFINED_ITERATIONS
LVAL k_iterations;   /* Keyword ":ITERATIONS" */
#define DEFINED_ITERATIONS
#endif

#ifndef DEFINED_WEIGHT
LVAL k_weight;   /* Keyword ":WEIGHT" */
#define DEFINED_WEIGHT
#endif

#ifndef DEFINED_ARRAY
LVAL k_array;   /* Keyword ":ARRAY" */
#define DEFINED_ARRAY
#endif

#ifndef DEFINED_PREFIX
LVAL k_prefix;   /* Keyword ":PREFIX" */
#define DEFINED_PREFIX
#endif

#ifndef DEFINED_SUFFIX
LVAL k_suffix;   /* Keyword ":SUFFIX" */
#define DEFINED_SUFFIX
#endif

#endif


#ifdef MODULE_XLOBJ_C_OBSYMBOLS

#ifndef CREATED_K_MIN
    k_min= xlenter(":MIN");
#define CREATED_K_MIN
#endif

#ifndef CREATED_K_MAX
    k_max= xlenter(":MAX");
#define CREATED_K_MAX
#endif

#ifndef CREATED_K_INTENSITY
    k_intensity= xlenter(":INTENSITY");
#define CREATED_K_INTENSITY
#endif

#ifndef CREATED_K_REVERSE_X
    k_reverse_x= xlenter(":REVERSE-X");
#define CREATED_K_REVERSE_X
#endif

#ifndef CREATED_K_RESULT_IN
    k_result_in= xlenter(":RESULT-IN");
#define CREATED_K_RESULT_IN
#endif

#ifndef CREATED_K_AXIS
    k_axis= xlenter(":AXIS");
#define CREATED_K_AXIS
#endif

#ifndef CREATED_K_FILENAME
    k_filename= xlenter(":FILE-NAME");
#define CREATED_K_FILENAME
#endif

#ifndef CREATED_K_SLICE
    k_slice= xlenter(":SLICE");
#define CREATED_K_SLICE
#endif

#ifndef CREATED_K_SUBSAMPLE_BY
    k_subsample_by= xlenter(":SUBSAMPLE-BY");
#define CREATED_K_SUBSAMPLE_BY
#endif

#ifndef CREATED_K_ZOOM_BY
    k_zoom_by= xlenter(":ZOOM-BY");
#define CREATED_K_ZOOM_BY
#endif

#ifndef CREATED_K_VOXELS
    k_voxels= xlenter(":VOXELS");
#define CREATED_K_VOXELS
#endif

#ifndef CREATED_K_ISOLEVEL
    k_isolevel= xlenter(":ISOLEVEL");
#define CREATED_K_ISOLEVEL
#endif

#ifndef CREATED_K_BIN_SIZE
    k_bin_size= xlenter(":BIN-SIZE");
#define CREATED_K_BIN_SIZE
#endif

#ifndef CREATED_K_RENDERING_RELATION
    k_rendering_relation= xlenter(":RENDERING-RELATION");
#define CREATED_K_RENDERING_RELATION
#endif

#ifndef CREATED_K_DIFFUSE_RED
    k_diffuse_red= xlenter(":DIFFUSE-RED");
#define CREATED_K_DIFFUSE_RED
#endif

#ifndef CREATED_K_DIFFUSE_GREEN
    k_diffuse_green= xlenter(":DIFFUSE-GREEN");
#define CREATED_K_DIFFUSE_GREEN
#endif

#ifndef CREATED_K_DIFFUSE_BLUE
    k_diffuse_blue= xlenter(":DIFFUSE-BLUE");
#define CREATED_K_DIFFUSE_BLUE
#endif

#ifndef CREATED_K_ALPHA
    k_alpha= xlenter(":ALPHA");
#define CREATED_K_ALPHA
#endif

#ifndef CREATED_K_RANGE
    k_range= xlenter(":RANGE");
#define CREATED_K_RANGE
#endif

#ifndef CREATED_K_SRC_MIN
    k_src_min= xlenter(":SRC-MIN");
#define CREATED_K_SRC_MIN
#endif

#ifndef CREATED_K_SRC_MAX
    k_src_max= xlenter(":SRC-MAX");
#define CREATED_K_SRC_MAX
#endif

#ifndef CREATED_K_DST_MIN
    k_dst_min= xlenter(":DST-MIN");
#define CREATED_K_DST_MIN
#endif

#ifndef CREATED_K_DST_MAX
    k_dst_max= xlenter(":DST-MAX");
#define CREATED_K_DST_MAX
#endif

#ifndef CREATED_K_DEPTH
    k_depth= xlenter(":DEPTH");
#define CREATED_K_DEPTH
#endif

#ifndef CREATED_K_PIXELDEPTH
    k_pixeldepth= xlenter(":PIXEL-DEPTH");
#define CREATED_K_PIXELDEPTH
#endif

#ifndef CREATED_K_FILE_OFFSET
    k_file_offset= xlenter(":FILE-OFFSET");
#define CREATED_K_FILE_OFFSET
#endif

#ifndef CREATED_K_ROWS
    k_rows= xlenter(":ROWS");
#define CREATED_K_ROWS
#endif

#ifndef CREATED_K_COLS
    k_cols= xlenter(":COLS");
#define CREATED_K_COLS
#endif

#ifndef CREATED_K_DISTANCE
    k_distance= xlenter(":DISTANCE");
#define CREATED_K_DISTANCE
#endif

#ifndef CREATED_K_FILTER_SHAPE
    k_filter_shape= xlenter(":FILTER-SHAPE");
#define CREATED_K_FILTER_SHAPE
#endif

#ifndef CREATED_IMPULSE
    k_impulse = xlenter(":IMPULSE");
#define CREATED_IMPULSE
#endif

#ifndef CREATED_TRIANGLE
    k_triangle = xlenter(":TRIANGLE");
#define CREATED_TRIANGLE
#endif

#ifndef CREATED_BOX
    k_box = xlenter(":BOX");
#define CREATED_BOX
#endif

#ifndef CREATED_QUADRATIC
    k_quadratic = xlenter(":QUADRATIC");
#define CREATED_QUADRATIC
#endif

#ifndef CREATED_MITCHELL
    k_mitchell = xlenter(":MITCHELL");
#define CREATED_MITCHELL
#endif

#ifndef CREATED_K_ZERO_REST
    k_zero_rest= xlenter(":ZERO-REST");
#define CREATED_K_ZERO_REST
#endif

#ifndef CREATED_K_PLANE
    k_plane= xlenter(":PLANE");
#define CREATED_K_PLANE
#endif

#ifndef CREATED_K_DEPTH_IN_BITS
    k_depth_in_bits = xlenter(":DEPTH-IN-BITS");
#define CREATED_K_DEPTH_IN_BITS
#endif

#ifndef CREATED_K_ENDIAN
    k_endian = xlenter(":ENDIAN");
#define CREATED_K_ENDIAN
#endif

#ifndef CREATED_K_BIG
    k_big = xlenter(":BIG");
#define CREATED_K_BIG
#endif

#ifndef CREATED_K_LITTLE
    k_little = xlenter(":LITTLE");
#define CREATED_K_LITTLE
#endif

#ifndef CREATED_K_PADDING
    k_padding = xlenter(":PADDING");
#define CREATED_K_PADDING
#endif

#ifndef CREATED_K_FORMAT
    k_format = xlenter(":FORMAT");
#define CREATED_K_FORMAT
#endif

#ifndef CREATED_K_AVS_UNIFORM_FIELD
    k_avs_uniform_field = xlenter(":AVS-UNIFORM-FIELD");
#define CREATED_K_AVS_UNIFORM_FIELD
#endif

#ifndef CREATED_K_MINX
    k_minx = xlenter(":MIN-X");
#define CREATED_K_MINX
#endif

#ifndef CREATED_K_MAXX
    k_maxx = xlenter(":MAX-X");
#define CREATED_K_MAXX
#endif

#ifndef CREATED_K_MINY
    k_miny = xlenter(":MIN-Y");
#define CREATED_K_MINY
#endif

#ifndef CREATED_K_MAXY
    k_maxy = xlenter(":MAX-Y");
#define CREATED_K_MAXY
#endif

#ifndef CREATED_K_MINZ
    k_minz = xlenter(":MIN-Z");
#define CREATED_K_MINZ
#endif

#ifndef CREATED_K_MAXZ
    k_maxz = xlenter(":MAX-Z");
#define CREATED_K_MAXZ
#endif

#ifndef CREATED_K_MINI
    k_mini = xlenter(":MIN-I");
#define CREATED_K_MINI
#endif

#ifndef CREATED_K_MAXI
    k_maxi = xlenter(":MAX-I");
#define CREATED_K_MAXI
#endif

#ifndef CREATED_K_MINJ
    k_minj = xlenter(":MIN-J");
#define CREATED_K_MINJ
#endif

#ifndef CREATED_K_MAXJ
    k_maxj = xlenter(":MAX-J");
#define CREATED_K_MAXJ
#endif

#ifndef CREATED_K_MINK
    k_mink = xlenter(":MIN-K");
#define CREATED_K_MINK
#endif

#ifndef CREATED_K_MAXK
    k_maxk = xlenter(":MAX-K");
#define CREATED_K_MAXK
#endif

#ifndef CREATED_K_MAX_FACETS
    k_max_facets = xlenter(":MAX-FACETS");
#define CREATED_K_MAX_FACETS
#endif

#ifndef CREATED_ITERATIONS
    k_iterations = xlenter(":ITERATIONS");
#define CREATED_ITERATIONS
#endif

#ifndef CREATED_WEIGHT
    k_weight = xlenter(":WEIGHT");
#define CREATED_WEIGHT
#endif

#ifndef CREATED_ARRAY
    k_array = xlenter(":ARRAY");
#define CREATED_ARRAY
#endif

#ifndef CREATED_PREFIX
    k_prefix = xlenter(":PREFIX");
#define CREATED_PREFIX
#endif

#ifndef CREATED_SUFFIX
    k_suffix = xlenter(":SUFFIX");
#define CREATED_SUFFIX
#endif

#endif
