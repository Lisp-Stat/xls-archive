/*- xvol-codegen.c -- support code for handling MRI images.		*/
/*- This file is formatted for outline-minor-mode in emacs19.		*/
/*-^C^O^A shows All of file.						*/
/* ^C^O^Q Quickfolds entire file. (Leaves only top-level headings.)	*/
/* ^C^O^T hides all Text. (Leaves all headings.)			*/
/* ^C^O^I shows Immediate children of node.				*/
/* ^C^O^S Shows all of a node.						*/
/* ^C^O^D hiDes all of a node.						*/
/* ^HFoutline-mode gives more details.					*/
/* (Or do ^HI and read emacs:outline mode.)				*/

/************************************************************************/
/*-    Copyright.							*/
/************************************************************************/

/*************************************************************************
*
* Author:       Jeff Prothero
* Created:      96Nov01
* Language:     C
* Package:      N/A
*
* Copyright (c) 1997, University of Washington (by Jeff Prothero)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Library General Public License as
*   published by the Free Software Foundation; either version 2, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Library General Public License for more details.
*
*   You should have received a copy of the GNU Library General
*   Public License along with this program; if not, write to the
*   Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
*   MA 02139, USA.
*
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************

/************************************************************************/
/*-	history								*/
/************************************************************************/

/* 96Nov01 jsp: Created.						*/

/* A little hack to generate some of the */
/* code and data needed by xvol.c.       */
/* I just compile it and run it by doing */
/*    cc xvol-codegen.c -o x		 */
/*    ./x >xvol-code.c                   */

/************************************************************************/
/*-	header stuff							*/
/************************************************************************/

#include <stdio.h>

#ifndef TRUE
#define TRUE (1)
#endif

#ifndef FALSE
#define FALSE (0)
#endif

/* Switch to generate debugging output: */
#ifndef VERBOSE
#define VERBOSE FALSE
#endif

struct point_rec { float x,y,z; };	/* x,y,z: -1.0 or 1.0 */
typedef struct point_rec point;

/************************************************************************/
/*-	Vector subtraction, dotproduction, crossproduct			*/
/************************************************************************/

/* Vector subtraction: */
static point vsub( point a, point b ) {
    point c;
    c.x = a.x - b.x;
    c.y = a.y - b.y;
    c.z = a.z - b.z;
    return c;
}

/* Vector dot product: */
static float vdot( point a, point b ) {
    return     a.x * b.x   +   a.y * b.y   +   a.z * b.z;
}

/* Vector cross product: */
static point vcross( point a, point b ) {
    point c;
    c.x = a.y * b.z   -   b.y * a.z;
    c.y = b.x * a.z   -   a.x * b.z;
    c.z = a.x * b.y   -   b.x * a.y;
    return c;
}

static struct vertex_rec {
    int edge[3];	/* Edges touching vertex. */
    int i;		/* isosurface flag	  */
    point p;	
} vertex[8];
static struct edge_rec {
    int vertex[2];
    /* next_edge_clockwise[0] is the edge   */
    /* reached travelling clockwise toward  */
    /* toward vertex[0], similarly for [1]: */
    int next_edge_clockwise[2];
    int intersects_isosurface;
    int mark;
} edge[ 12 ];

/************************************************************************/
/*-	Cube navigation: nextedge_clockwise				*/
/************************************************************************/

/* Array to hold sequence of isosurface- */
/* piercing edges outlining a complete   */
/* isosurface portion in our cube:       */
static path_edge[ 12 ];
static path_vertex;	/* Vertex to leave next. */

static nextedge_clockwise(
    int e	/* Current edge -- index into edge[] */
) {
    int next;
    if        (edge[e].vertex[0] == path_vertex) {
	next = edge[e].next_edge_clockwise[0];
    } else if (edge[e].vertex[1] == path_vertex) {
	next = edge[e].next_edge_clockwise[1];
    } else {
	fprintf(stderr,"Ickypoo!\n");
	abort();
    }
    if (edge[next].vertex[0] != path_vertex
    &&  edge[next].vertex[1] != path_vertex
    ){
	fprintf(stderr,"Mommy!\n");
	abort();
    }
    if (edge[next].vertex[0] != path_vertex) {
        path_vertex = edge[next].vertex[0];
    } else if (edge[next].vertex[1] != path_vertex) {
        path_vertex = edge[next].vertex[1];
    } else {
	fprintf(stderr,"Poker, anyone?\n");
	abort();
    }
    return next;
}

/************************************************************************/
/*-	Cube construction: initialize_datastructures			*/
/************************************************************************/

static void
initialize_datastructures(
    void
) {
    /* Given a    voxel with each corner    */
    /* classified as being above or below   */
    /* the isosurface threshhold, how many  */
    /* triangles do we need to represent    */
    /* the isosurface?                      */
    /* The fast way to answer this question */
    /* is clearly to precompute a table of  */
    /* answers for all 256 possible inputs, */
    /* which is what we do here:            */
    int i,j,e,u,v,cube;

    /* Initialize edge[*].vertex*: */
    e = 0;
    /* Over all ordered pairs of vertices: */
    for (    u = 0;   u < 8;   ++u) { 
	for (v = u;   v < 8;   ++v) { 
	    /* If this pair shares an edge: */
	    int x = (u^v);
	    if (x == 1 || x == 2 || x ==4) {
		/* Record the edge: */
		edge[e].vertex[0] = u;
		edge[e].vertex[1] = v;
		#if VERBOSE
		printf("edge %d: %d, %d\n", e, u, v );
		#endif
		++e;
	    }
	}
    }

    /* Initialize vertex[*].x/y/z: */
    for (    v = 0;   v < 8;   ++v) {
	vertex[v].p.x = ((v&1) ? 1.0 : -1.0);
	vertex[v].p.y = ((v&2) ? 1.0 : -1.0);
	vertex[v].p.z = ((v&4) ? 1.0 : -1.0);
    }

    /* Initialize vertex[*].edge[*]: */
    /* First, mark all vertex->edge adjacencies as unused: */
    /* Over all vertices: */
    for (    v = 0;   v < 8;   ++v) {
	/* Over all adjacency slots on vertex: */
	for (e = 0;   e < 3;   ++e) { 
	    vertex[v].edge[e] = -1;
	}
    }
    /* Now, note on each vertex all edges connected to it: */
    /* Over all edges: */
    for     (i = 0;   i < 12;   ++i) { 
	/* For both ends of the edge: */
	for (j = 0;   j < 2 ;   ++j) {
	    v = edge[i].vertex[j];
	    for (e = 0;   ;   ++e) {
		if (vertex[v].edge[e] == -1) {
		    #if VERBOSE
		    printf("Vertex %d edge %2d is %2d\n",v,e,i);
		    #endif
		    vertex[v].edge[e] = i;
		    break;
		}
		/* Sanity check -- should be three */
		/* edges per vertex, exactly:      */
		if (e == 2) {
		    fprintf(stderr,"Oops!\n");
		    abort();
		}
	    }
	}
    }

    /* Initialize edge[*].next_edge_clockwise[*]: */
    /* Over all edges: */
    for (    i = 0;   i < 12;   ++i) { 
	/* Over both ends of edge: */
	for (j = 0;   j < 2 ;   ++j) { 
	    /* Haven't found cw edge yet: */
	    edge[i].next_edge_clockwise[j] = -1;
	}
    }
    /* Over all edges: */
    for (    i = 0;   i < 12;   ++i) { 
	/* Over both ends of edge: */
	for (j = 0;   j < 2 ;   ++j) { 
	    /* Over all edges connected to that end: */
	    for (e = 0;   e < 3;   ++e) {
		int edge0 = i;
		int edge1 = vertex[edge[i].vertex[j]].edge[e];
		/* If that edge isn't us: */
		if (edge0 != edge1) {
		    /* See if it goes clockwise from us: */
		    /* Find three points defining triangle */
		    /* formed by the two edges:            */
		    int   k  =(edge[edge1].vertex[0] == edge[edge0].vertex[j]);
		    int   v0 = edge[edge0].vertex[j^1];
		    int   v1 = edge[edge0].vertex[j  ];
		    int   v2 = edge[edge1].vertex[k  ];
		    point p0 = vertex[ v0 ].p;
		    point p1 = vertex[ v1 ].p;
		    point p2 = vertex[ v2 ].p;
		    /* Find vectors p1->p0 and p1->p2: */
		    point p01;	/* MIPS C won't let us use initializer here :( */
		    point p21;
		    point c;
		    p01 = vsub( p0, p1 );
		    p21 = vsub( p2, p1 );
		    /* Take crossproduct: */
		    c   = vcross( p01, p21 );
		    /* Find remaining point adjacent to p1: */
		    {   int   a;
			int   v3;
			point p3;
			point p31;
		        for (a = 0;   ;   ++a) {
			    int edge2 = vertex[v1].edge[a];
			    if (edge2 != edge0
			    &&  edge2 != edge1
			    ){
				int which_end = edge[edge2].vertex[0] == v1;
				v3 = edge[edge2].vertex[which_end];
				break;
			    }
			    /* Sanity check */
			    if (k == 2) {
			        fprintf(stderr,"Whoops!\n");
				abort();
			    }
			}
			p3  = vertex[ v3 ].p;
			p31 = vsub( p3, p1 );
			/* Finally, the clockwise test: */
			if (vdot( p31, c) > 0.0) {
			    /* Found the edge we want: */
			    if (edge[edge0].next_edge_clockwise[j] != -1) {
			        fprintf(stderr,"Yikes!\n");
				abort();
			    }
			    edge[edge0].next_edge_clockwise[j] = edge1;
			    #if VERBOSE
                            printf("edge[%2d].next_edge_clockwise[%d] == %2d\n",edge0,j,edge1);
			    #endif
			}
		    }
		}
	    }
	}
    }
}


/************************************************************************/
/*-	Isosurface/Cube intersection: generate_paths			*/
/************************************************************************/

/* Here we generate all 256 possible patterns of     */
/* cube corners being inside/outside the isosurface, */
/* and then generate the isosurface intersections    */
/* for each one.  The three function arguments allow */
/* the caller to do whatever is desired with the     */
/* resulting information:                            */

static void
generate_paths(
    void (*cube_top_fn)(int cube),
    void (*per_path_fn)(int*path,int len),
    void (*cube_bot_fn)(int cube)
) {
    /* Given a    voxel with each corner    */
    /* classified as being above or below   */
    /* the isosurface threshhold, how many  */
    /* triangles do we need to represent    */
    /* the isosurface?                      */
    /* The fast way to answer this question */
    /* is clearly to precompute a table of  */
    /* answers for all 256 possible inputs, */
    /* which is what we do here:            */
    int i,j,e,u,v,cube;

    /* Over all possible cubes: */
    for (cube = 0;   cube < 256;   ++cube) {
	
        (*cube_top_fn)(cube);

	/* Explicitly construct cube vertices, */
	/* marked zero if below threshhold,    */
	/* one if above threshold:             */
	vertex[0].i = ((cube & (1<<0)) != 0);
	vertex[1].i = ((cube & (1<<1)) != 0);
	vertex[2].i = ((cube & (1<<2)) != 0);
	vertex[3].i = ((cube & (1<<3)) != 0);
	vertex[4].i = ((cube & (1<<4)) != 0);
	vertex[5].i = ((cube & (1<<5)) != 0);
	vertex[6].i = ((cube & (1<<6)) != 0);
	vertex[7].i = ((cube & (1<<7)) != 0);

        /* Clear mark on all edges: */
	for (e = 0;   e < 12;   ++e)  {
	    edge[e].mark = FALSE;
	}	

	/* Find all edges intersecting isosurface: */
	for (e = 0;   e < 12;   ++e)  {
	    edge[e].intersects_isosurface = (
		vertex[ edge[e].vertex[0] ].i != vertex[ edge[e].vertex[1] ].i
	    );
	    #if VERBOSE
            printf("cube x=%02x: edge d=%2d (%d %d) does %sintersect isosurface\n",
                cube,e,edge[e].vertex[0],edge[e].vertex[1],
                edge[e].intersects_isosurface?"    ":"not "
            );
	    #endif
	}

	/* Generate isosurface triangles: */
	/* Over all unmarked isosurface-piercing edges: */
	for (e = 0;   e < 12;   ++e)  {
	    if (edge[e].intersects_isosurface
	    && !edge[e].mark
	    ){
		int path_len;

		/* Mark edge: */
		edge[e].mark = TRUE;

		/* Remember first edge in isosurface chunk: */
		path_edge[0] = e;

		/* Remember which vertex path leaves from: */
		if (vertex[edge[e].vertex[0]].i) {
		    path_vertex = edge[e].vertex[0];
		} else {
		    path_vertex = edge[e].vertex[1];
		}

		/* Find adjacent isosurface-piercing  */
		/* edges until we return to original  */
		/* edge, printing out triangles as we */
		/* go:                                */
		path_len = 1;
		for (;;) {
		    int this_edge = path_edge[path_len-1];
		    do {
			this_edge = nextedge_clockwise( this_edge );
			if (edge[this_edge].mark && this_edge != e) {
			    fprintf(stderr,"*snicker*\n");
			    abort();
			}
		    } while (!edge[this_edge].intersects_isosurface);
		    if (this_edge == e)   break;
                    path_edge[path_len++] = this_edge;
		    edge[this_edge].mark = TRUE;

		    /* Reverse edge-traversal direction: */
		    if (vertex[edge[this_edge].vertex[0]].i) {
			path_vertex = edge[this_edge].vertex[0];
		    } else {
			path_vertex = edge[this_edge].vertex[1];
		    }
		}
		#if VERBOSE
                {   int t;
                    printf(" path: ");
                    for(t = 0;   t < path_len;   ++t) {
                        printf(" %d(%d %d)",
                            path_edge[t],
                            edge[path_edge[t]].vertex[0],
                            edge[path_edge[t]].vertex[1]
                        );
		    }
                    printf("\n");
		}
		#endif

		per_path_fn( path_edge, path_len );
	    }
	}

	cube_bot_fn(cube);
    }

}

/************************************************************************/
/*-	Table construction: generate_triangles_needed			*/
/************************************************************************/

/* Here we print out a table containing for each of   */
/* the 256 patterns of isosurface/voxel intersection, */
/* the number of triangles needed to represent that   */
/* isosurface.                                        */
/*						      */
/* The table will be xvolj0_triangles_needed[256];    */

static int triangles_found;
static void
triangles_top_fn(
    int cube
){
    /* Initialize count of triangles */
    /* found so far for this cube:   */
    triangles_found = 0;
}
static void
triangle_path_fn(
    int* path,
    int  path_len
){
    /* Triangles needed for this patch of */
    /* isosurface is vertexcount-2, since */
    /* a three-point path needs one       */
    /* triangle and each additional point */
    /* requires one more triangle:        */
    triangles_found += path_len-2;
}
static void
triangles_bot_fn(
    int cube
){
    /* Write out line with polygons-needed */
    /* figure for this particular cube:    */
    printf(
	"    /* cube %02x triangles needed: */ %2d,\n",
	cube,
	triangles_found
    );
}
static void
generate_triangles_needed(
    void
) {
    /* Write out header: */
    printf("int xvolj0_triangles_needed[ 256 ] = {\n");

    /* Write out body: */
    generate_paths(
	triangles_top_fn,
	triangle_path_fn,
	triangles_bot_fn
    );

    /* Write out trailer: */
    printf("};\n\n");
}


/************************************************************************/
/*-	Table construction: generate_vertices_needed			*/
/************************************************************************/

/* Here we print out a table containing for each of   */
/* the 256 patterns of isosurface/voxel intersection, */
/* the number of points needed to represent that      */
/* isosurface.                                        */
/*						      */
/* The table will be xvolj1_vertices_needed[256];     */

static int vertices_found;
static void
vertices_top_fn(
    int cube
){
    /* Initialize count of vertices */
    /* found so far for this cube:  */
    vertices_found = 0;
}
static void
vertices_path_fn(
    int* path,
    int  path_len
){
    /* Vertices needed for this patch of  */
    /* isosurface is path_len:            */
    vertices_found += path_len;
}
static void
vertices_bot_fn(
    int cube
){
    /* Write out line with vertices-needed */
    /* figure for this particular cube:    */
    printf(
	"    /* cube %02x vertices needed: */ %2d,\n",
	cube,
	vertices_found
    );
}
static void
generate_vertices_needed(
    void
) {
    /* Write out header: */
    printf("int xvolj1_vertices_needed[ 256 ] = {\n");

    /* Write out body: */
    generate_paths(
	vertices_top_fn,
	vertices_path_fn,
	vertices_bot_fn
    );

    /* Write out trailer: */
    printf("};\n\n");
}


/************************************************************************/
/*-	Function construction: generate_functions_needed		*/
/************************************************************************/

/* Here we print out 256 functions, one for each of   */
/* the 256 patterns of isosurface/voxel intersection, */
/* which when called will insert in specified arrays  */
/* a triangulation of the isosurface fragment for the */
/* voxel.                                             */

static void
functions_top_fn(
    int cube
){
    /* Write header of function: */
    printf("void\n");
    printf("xvoljfn_%02x(\n",cube);
    printf("    int*   pf,  /* Where to insert next facet */\n");
    printf("    int*   pp,  /* Where to insert next point */\n");
    printf("    float* px,  /* Array to hold output point x vals */\n");
    printf("    float* py,  /* Array to hold output point y vals */\n");
    printf("    float* pz,  /* Array to hold output point z vals */\n");
    printf("    int*   f0,  /* Array to hold 1st point of output triangles */\n");
    printf("    int*   f1,  /* Array to hold 2nd point of output triangles */\n");
    printf("    int*   f2,  /* Array to hold 3rd point of output triangles */\n");
    printf("    float  x0,  /* X-Coord of voxel's 000 corner */\n");
    printf("    float  y0,  /* Y-Coord of voxel's 000 corner */\n");
    printf("    float  z0,  /* Z-Coord of voxel's 000 corner */\n");
    printf("    float  dx,  /* X-Length of voxel */\n");
    printf("    float  dy,  /* Y-Length of voxel */\n");
    printf("    float  dz,  /* Z-Length of voxel */\n");
    printf("    float  iso, /* Isosurface threshhold value */\n");
    printf("    int val0, /* Fn value at corner 000 of voxel */\n");
    printf("    int val1, /* Fn value at corner 001 of voxel */\n");
    printf("    int val2, /* Fn value at corner 010 of voxel */\n");
    printf("    int val3, /* Fn value at corner 011 of voxel */\n");
    printf("    int val4, /* Fn value at corner 100 of voxel */\n");
    printf("    int val5, /* Fn value at corner 101 of voxel */\n");
    printf("    int val6, /* Fn value at corner 110 of voxel */\n");
    printf("    int val7  /* Fn value at corner 111 of voxel */\n");
    printf(") {\n");
}
static void
function_path_fn(
    int* path,
    int  path_len
){
    int  i;

    if (!path_len)   return;

    /* Generate code to insert  */
    /* triangles in given path  */

    /* First job is to compute coords */
    /* of each point in path:         */

    /* Declare array to hold results: */
    printf("\n");
    printf("    {   /* Cache array cursors: */\n");
    printf("        int   f = *pf;\n");
    printf("        int   p = *pp;\n");

    /* Convert all needed vertex */
    /* values to floats:         */
    printf("\n");
    printf("        /* Cache needed cube corners: */\n");
    {   int  need_it[ 8 ];
	for (i = 8;   i --> 0;   )  need_it[i] = FALSE;
	for (i = 0;   i < path_len;   ++i) {
	    /* Which two vertices does this edge connect? */
	    need_it[ edge[path[i]].vertex[0] ] = TRUE;
	    need_it[ edge[path[i]].vertex[1] ] = TRUE;
	}
	for (i = 0;   i < 8;   ++i) {
	    if (need_it[i]) {
		printf("        float e%d = (float)val%d;\n",i,i);
	    }
	}
    }

    /* Generate code to fill in array: */
    printf("\n");
    printf("\n");
    printf("\n");
    printf("        /* Find isosurface/edge intersections */\n");
    printf("        /* via linear interpolation:          */\n");
    for (i = 0;   i < path_len;   ++i) {
	/* Which two vertices does this edge connect? */
	int v0 = edge[path[i]].vertex[0];
	int v1 = edge[path[i]].vertex[1];

	/* Different cases depending  */
	/* which direction edge runs: */
	printf("\n");
	switch (v0^v1) {
	case 1:
	    /* Only X axis needs interpolation: */
	    if (v0&1)printf("        px[p+%d] = x0 + ((iso-e%d)/(e%d-e%d))*dx;\n",i,v1,v0,v1);
	    else     printf("        px[p+%d] = x0 + ((e%d-iso)/(e%d-e%d))*dx;\n",i,v0,v0,v1);
	    printf(         "        py[p+%d] = y0%s;\n",i,(v0&2)?"+dy":"");
	    printf(         "        pz[p+%d] = z0%s;\n",i,(v0&4)?"+dz":"");
	    break;
	case 2:
	    /* Only Y axis needs interpolation: */
	    printf(         "        px[p+%d] = x0%s;\n",i,(v0&1)?"+dx":"");
	    if (v0&2)printf("        py[p+%d] = y0 + ((iso-e%d)/(e%d-e%d))*dy;\n",i,v1,v0,v1);
	    else     printf("        py[p+%d] = y0 + ((e%d-iso)/(e%d-e%d))*dy;\n",i,v0,v0,v1);
	    printf(         "        pz[p+%d] = z0%s;\n",i,(v0&4)?"+dz":"");
	    break;
	case 4:
	    /* Only Z axis needs interpolation: */
	    printf(         "        px[p+%d] = x0%s;\n",i,(v0&1)?"+dx":"");
	    printf(         "        py[p+%d] = y0%s;\n",i,(v0&2)?"+dy":"");
	    if (v0&4)printf("        pz[p+%d] = z0 + ((iso-e%d)/(e%d-e%d))*dz;\n",i,v1,v0,v1);
	    else     printf("        pz[p+%d] = z0 + ((e%d-iso)/(e%d-e%d))*dz;\n",i,v0,v0,v1);
	    break;
	default:
	    fprintf(stderr,"Dreck -- %d vs %d!\n",v0,v1);
	    abort();
	}
    }

    printf("\n");
    printf("        /* Insert facets for this path: */\n");
    for (i = 0;   i < path_len-2;   ++i) {

	/* Write the three coords out: */
	printf(
            "        f0[f+%d] = p;   f1[f+%d] = p+%d;   f2[f+%d] = p+%d;\n",
                          i,              i,     i+1,         i,   i+2
        );
    }

    printf("\n");
    printf("        /* Update array cursors: */\n");
    printf("        *pp = p+%d;\n",path_len);
    printf("        *pf = f+%d;\n",path_len-2);

    printf("    }\n");
}
static void
functions_bot_fn(
    int cube
){
    /* Write trailer of function: */
    printf("}\n\n");
}
static void
generate_functions_needed(
    void
) {
    generate_paths(
	functions_top_fn,
	function_path_fn,
	functions_bot_fn
    );
}

/************************************************************************/
/*-	Function table construction: generate_function_table		*/
/************************************************************************/

/* Here we generate a table indexing */
/* the above-generated functions:    */

static void
generate_function_table(
    void
) {
    /* Write header of function table: */
    printf("void\n"); 
    printf("(*xvolj2_fn[256])(\n");
    printf("    int*   pf,  /* Where to insert next facet */\n");
    printf("    int*   pp,  /* Where to insert next point */\n");
    printf("    float* px,  /* Array to hold output point x vals */\n");
    printf("    float* py,  /* Array to hold output point y vals */\n");
    printf("    float* pz,  /* Array to hold output point z vals */\n");
    printf("    int*   f0,  /* Array to hold 1st point of output triangles */\n");
    printf("    int*   f1,  /* Array to hold 2nd point of output triangles */\n");
    printf("    int*   f2,  /* Array to hold 3rd point of output triangles */\n");
    printf("    float  x0,  /* X-Coord of voxel's 000 corner */\n");
    printf("    float  y0,  /* Y-Coord of voxel's 000 corner */\n");
    printf("    float  z0,  /* Z-Coord of voxel's 000 corner */\n");
    printf("    float  dx,  /* X-Length of voxel */\n");
    printf("    float  dy,  /* Y-Length of voxel */\n");
    printf("    float  dz,  /* Z-Length of voxel */\n");
    printf("    float  iso, /* Isosurface threshhold value */\n");
    printf("    int val0, /* Fn value at corner 000 of voxel */\n");
    printf("    int val1, /* Fn value at corner 001 of voxel */\n");
    printf("    int val2, /* Fn value at corner 010 of voxel */\n");
    printf("    int val3, /* Fn value at corner 011 of voxel */\n");
    printf("    int val4, /* Fn value at corner 100 of voxel */\n");
    printf("    int val5, /* Fn value at corner 101 of voxel */\n");
    printf("    int val6, /* Fn value at corner 110 of voxel */\n");
    printf("    int val7  /* Fn value at corner 111 of voxel */\n");
    printf(") = {\n");

    /* Write body of function table: */
    {   int  i;
	for (i = 0;   i < 256;   ++i) {
	    printf("    xvoljfn_%02x,\n",i);
    }	}

    /* Write trailer of function table: */
    printf("};\n\n");
}

/************************************************************************/
/*-	main -- this does all the work :)				*/
/************************************************************************/

main() {
    initialize_datastructures();
    generate_triangles_needed();
    generate_vertices_needed( );
    generate_functions_needed();
    generate_function_table(  );
}

/************************************************************************/
/*-    File variables							*/
/************************************************************************/
/*

Local variables:
mode: outline-minor
outline-regexp: "[ \\t]*\/\\*-"
End:
*/
