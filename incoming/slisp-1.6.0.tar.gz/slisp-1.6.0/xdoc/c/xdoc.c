/* Dummy */
xdoc(){}
