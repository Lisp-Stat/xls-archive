/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xveo.c
* Description:  Interface to HIT Lab's VEOS operating system.
* Author:       Jerry Prothero
* Created:      91Aug21
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, Human Interface Technology Lab (by Jerry Prothero).
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jeff Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jeff Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JERRY PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JERRY PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send improvements and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/************************************************************************/
/*				comments				*/
/*									*/
/* This module provides an interface between XLisp and the VEOS opera-  */
/* ting system developed by the Human Interface Technology Lab.         */
/* VEOS is the glue used by the HIT Lab to connect different virtual    */
/* reality components together.	Our main concern in this module is to   */
/* connect to the VEOS grouple space, which contains the common shared  */
/* data.  To this end, we provide XLisp wrappers for the high-level     */
/* VEOS grouple space calls.						*/
/*									*/
/* To compile xlisp with support for VEOS, just uncomment               */
/* '#include "xveos/c/xveo.h" in ~/xmodules.h, and recompile.           */
/************************************************************************/

/************************************************************************/
/*                              contents                                */
/*									*/
/*		(generated via "grep '/\*\.' xgbj.c")			*/
/************************************************************************/

/************************************************************************/
/*                              history                                 */
/*									*/
/* 91Oct01 jdp  Nested grouple support.					*/
/* 91Sep30 jdp  Put with replacement, matrix support added.		*/
/* 91Sep25 jdp  Wrote and read a grouple to local workspace.		*/
/* 91Sep18 jdp  Dusted off, init & wrap fns added.			*/
/* 91Aug21 jdp  Created.						*/
/************************************************************************/
  
/* VEOS definitions: */
#include "/home/veos/src/include/world.h"



#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL xsendmsg0(); 
LVAL xveo80_Query_Wrapper();

#include <math.h>
#include "../../xg.3d/c/geo.h"
#include "../../xg.3d/c/csry.h"
#include "../../xg.3d/c/ccmr.h"
#include "../../xg.3d/c/ctfm.h"
#include "../../xg.3d/c/lib.h"
#include "../../xg.3d/c/cgrl.h"
#include "xveo.h"

/************************************************************************/
/*.User_LoadSpecialPrims -- Add new VEOS primitives.			*/
/************************************************************************/

TVeosErr User_LoadSpecialPrims()
{
    /*****************************************************************/
    /* At present, we don't make any hooks into Skandha available,   */
    /* we just read data placed in grouple-space by other processes. */
    /*****************************************************************/
    return VEOS_SUCCESS;
}

/************************************************************************/
/*.xveo10_List_To_Grouple -- Convert a Lisp list to a Nancy grouple.    */
/************************************************************************/

TPGrouple xveo10_List_To_Grouple( arg_list )
LVAL 				  arg_list;
/*-
    Convert a Lisp list to a Nancy grouple.
-*/
{
    int	      iErr;
    int       idx;
    int	      len;
    TPGrouple new_grouple;
    ctfm_rec* transform;

    /* Current spot when tracing through a list: */
    LVAL here;

    /* Perform system operations: */
    Kernel_SystemTask();

    /* Build a new grouple: */
    iErr = Nancy_NewGrouple( &new_grouple );    
    Nancy_TrapErr(iErr);

    /* Read through the list of things to write to the grouple-space: */
    here = arg_list;
    for (idx = 0, here = arg_list;   !null(here);   ++idx, here = cdr(here)) {
	
	LVAL element;

	/* Should be on a cons: */
        if (!consp(here))     xlbadtype( arg_list );
	
	/* Unpack the data element for this cons: */
        element = car( here );

	switch (ntype( element )) {
	case CONS:

	    /* Nested grouple: */
            Nancy_NewElementsInGrouple( new_grouple, idx, 1, GR_grouple, 0 );
            new_grouple->pEltList[ idx ].u.pGr = 
	     	xveo10_List_To_Grouple( element )
	    ;

	    break;

	case FIXNUM:

	    /* Int val: */
            Nancy_NewElementsInGrouple( new_grouple, idx, 1, GR_int, 0 );
            *new_grouple->pEltList[ idx ].u.pI = getfixnum( element );

	    break;

	case FLONUM:

	    /* Double val: */
            Nancy_NewElementsInGrouple( new_grouple, idx, 1, GR_float, 0 );
            *new_grouple->pEltList[ idx ].u.pF = (float) getflonum( element );

	    break;

	case STRING:

	    /* String val: */
            Nancy_NewElementsInGrouple( new_grouple, idx, 1, GR_string, 0 );
            new_grouple->pEltList[ idx ].u.pS = getstring( element );
	    break;

 	case GOBJECT:

	    /* Object val: */

	    /* So far, the only object we pass to VEOS is a 4x4 transform: */
            if (!xtfmp( element ))   xlbadtype( arg_list );

	    /* Get the matrix: */
            transform = (ctfm_rec*) gobjimmbase( element );
            Nancy_NewElementsInGrouple( new_grouple, idx, 1, GR_homo_mat, 0 );
	    
	    /* Copy into the Nancy matrix: */	    
	    {
		int i, j;
		float (*m)[4][4] = new_grouple->pEltList[ idx ].u.pMat;
		for (i = 0;   i < 4;   ++i) {
		    for (j = 0;   j < 4;   ++j) {
			(*m)[i][j] = (float) transform->m.m[i][j];
		    }
		}
	    }

 	    break;

	default:
	    xlbadtype( arg_list );
	}	
    }

    return new_grouple;
}

/************************************************************************/
/*.xveo20_Grouple_To_List -- Convert a Nancy grouple to a Lisp list.	*/
/************************************************************************/

LVAL xveo20_Grouple_To_List( arg_grouple )
TPGrouple  		     arg_grouple;
/*-
    Convert a Nancy grouple to a Lisp list.
-*/
{
    int       idx;
    int	      len;
    ctfm_rec* transform;
    LVAL      list    = NIL;
    LVAL      result  = NIL;

    /* Perform system operations: */
    Kernel_SystemTask();

    /* Protect our result list from garbage collection: */
    xlsave1( list   );
    xlsave1( result );

    /* Over all elements of the grouple: */
    len = arg_grouple->iElts;
    for (idx = 0;   idx < len;   ++idx) {

	/* Load the current grouple element into our output list: */
	switch (arg_grouple->pEltList[idx].iType) {

	case GR_grouple:

	    /* Nested grouple: */
            list = cons( 
		xveo20_Grouple_To_List( 
                    arg_grouple->pEltList[ idx ].u.pGr
		), 
	        list
	    );
	    break;

	case GR_int:            
            list = cons( 
                cvfixnum(*arg_grouple->pEltList[ idx ].u.pI), list
            );
	    break;

	case GR_float:
            list = cons( 
                cvflonum(*arg_grouple->pEltList[ idx ].u.pF), list
            );
	    break;
	
	case GR_string:
            list = cons( 
                cvstring(arg_grouple->pEltList[ idx ].u.pS), list
            );
	    break;

	case GR_homo_mat:
	    {
		int i, j;
		
		/* Build a new transform, to hold the matrix: */

 	        ctfm_rec * mat;
		LVAL trans_obj = xsendmsg0( lv_xtfm, k_new );

		/* Protect the transform from garbage collection: */
		xlprot1( trans_obj );

		/* Fetch the transform's internal matrix: */
 	        mat = (ctfm_rec*) gobjimmbase( trans_obj );
	        for (i=0; i<4; ++i) {
 		    for (j=0; j<4; ++j) {
		        mat->m.m[i][j] = 
			    (double) *arg_grouple->pEltList[ idx ].u.pMat[i][j]
			;
		    }
		}

	        /* Add the new transform to our output list: */
                list = cons( trans_obj, list );

	        /* Unprotect trans_obj from garbage collection: */
	        xlpop();
	    }

	    break;

        default:	

	    xlfail("Unsupported VEOS type");
	}
    }

    /* Reverse the list, to get it into the correct order: */
    for (result = NIL; consp(list); list = cdr(list)) {
	result = cons(car(list),result);
    }

    /* Unprotect result from garbage collection: */
    xlpop();
    xlpop();

    /* This line intentionally left cons-free. */
    return result;
}

/************************************************************************/
/*.xveo30_VEOS_Get -- Fetch a Nancy grouple.				*/
/************************************************************************/

LVAL xveo30_VEOS_Get()
/*-
    Fetch a grouple from the Nancy grouple-base, returning NIL if not there.
-*/
{
    return xveo80_Query_Wrapper( NANCY_RemoveMatch );
}

/************************************************************************/
/*.xveo40_VEOS_Put -- Put a grouple into the Nancy grouple-space.       */
/************************************************************************/

LVAL xveo40_VEOS_Put()
/*-
    Put a grouple into the Nancy grouple-base.
-*/
{	
    char *    str;
    LVAL      here;
    LVAL      element;
    long      which_space_to_search;
    int       local_or_non_local = NANCY_LocalSpace;
    TPGrouple data_grouple;
    TPGrouple match_grouple = 0;
    int       how_to_insert = NANCY_Append;
	
    /* Fetch our argument list: */
    LVAL arg_list = xlgalist();
	
    /* Perform system operations: */
    Kernel_SystemTask();

    /* Shouldn't be any more arguments: */
    xllastarg();

    /* Current spot in the arg_list: */
    here = arg_list;
	
    /* Find which grouple space to read from: */
    if (!consp(here))   xlbadtype( arg_list );
    element = car( here );
    if (ntype( element ) == STRING) {

	/* "w", "u", "s", "p": */
	which_space_to_search = (long) getstring( element );
	local_or_non_local    = NANCY_LocalSpace;

    } else if (ntype( element ) == FIXNUM) {

	/* Specified grouple: */
	which_space_to_search = (long) getfixnum( element );
	local_or_non_local    = NANCY_ThisGrouple;

    } else { 

        xlbadtype( arg_list );
    }

    /* Drop the element which we just read from the list: */
    if (!consp(here))   xlbadtype( arg_list );
    here = cdr( here );



    /* If a match pattern was specified, read it: */
    element = car( here );
    if (ntype( element ) == STRING) {
        str = getstring( element );
        if      (!strcmp( str, "." )) how_to_insert = NANCY_ReplaceOne;
        else if (!strcmp( str, "#" )) how_to_insert = NANCY_ReplaceAll;
        else 			    xlbadtype( arg_list );
	
        /* Drop the element which we just read from the list: */
        if (!consp(here))   xlbadtype( arg_list );
        here = cdr( here );

        /* The next element should be the list to convert to a grouple: */
        element = car( here );

	/* Which grouples to replace: */
        match_grouple = xveo10_List_To_Grouple( element );

        /* Drop the element which we just read from the list: */
        if (!consp(here))   xlbadtype( arg_list );
        here = cdr( here );

	/* Next element of the argument list: */
        element = car( here );
    }



    /* Pattern we're matching for: */
    data_grouple = xveo10_List_To_Grouple( element );
	
    /* Insert into the local grouple space: */
    PutSpace(
	local_or_non_local,
	how_to_insert,
	which_space_to_search,
        data_grouple,
	match_grouple
    );
}

/************************************************************************/
/*.xveo50_Init -- VEOS initialization call.				*/
/************************************************************************/

xveo50_Init()
/*-
    VEOS initialization call. 
-*/
{	
    /* Perform system operations: */
    Kernel_SystemTask();

    if (Kernel_Init(0, NULL) != VEOS_SUCCESS) {
	printf( "\nVEOS Kernel_Init call failed" );
    }
}

/************************************************************************/
/*.xveo60_Wrap -- VEOS program exit call.				*/
/************************************************************************/

xveo60_Wrap()
/*-
    VEOS program exit call. 
-*/
{	
    /* Perform system operations: */
    Kernel_SystemTask();

    Kernel_Shutdown();
}

/************************************************************************/
/*.xveo70_VEOS_Copy -- Get a grouple (without deletion).		*/
/************************************************************************/

LVAL xveo70_VEOS_Copy()
/*-
    Like get, except we don't delete from the grouple space.
-*/
{
    return xveo80_Query_Wrapper( NANCY_CopyMatch );
}

/************************************************************************/
/*.xveo80_Query_Wrapper -- Call to NANCY_QuerySpace.			*/
/************************************************************************/

LVAL xveo80_Query_Wrapper( copy_or_get )
int			   copy_or_get;
/*-
    Call to NANCY_Query_Wrapper.
-*/
{
    char *    str;
    LVAL      here;
    LVAL      element;
    long      which_space_to_search;
    int       local_or_non_local = NANCY_LocalSpace;
    TPGrouple result_grouple;
    TPGrouple match_grouple;
    int       how_many_to_match;
	
    /* Fetch our argument list: */
    LVAL arg_list = xlgalist();
	
    /* Perform system operations: */
    Kernel_SystemTask();

    /* Shouldn't be any more arguments: */
    xllastarg();
	
    /* Read how many grouples to match: */
    here = arg_list;
    if (!consp(here))   xlbadtype( arg_list );
    element = car( here );
    if (ntype( element ) != STRING)   xlbadtype( arg_list );
    str = getstring( element );
    if      (!strcmp( str, "." ))   how_many_to_match = NANCY_MatchOne;
    else if (!strcmp( str, "#" ))   how_many_to_match = NANCY_MatchMany;
    else 			    xlbadtype( arg_list );

    /* Drop the element which we just read from the list: */
    here = cdr( here );

    /* Find which grouple space to read from: */
    if (!consp(here))   xlbadtype( arg_list );
    element = car( here );
    if (ntype( element ) == STRING) {

	/* "w", "u", "s", "p": */
	which_space_to_search = (long) getstring( element );
	local_or_non_local    = NANCY_LocalSpace;

    } else if (ntype( element ) == FIXNUM) {

	/* Specified grouple: */
	which_space_to_search = (long) getfixnum( element );
	local_or_non_local    = NANCY_ThisGrouple;

    } else { 

        xlbadtype( arg_list );
    }

    /* Drop the element which we just read from the list: */
    here = cdr( here );

    /* The next element should be the list to convert to a grouple: */
    if (!consp(here))   xlbadtype( arg_list );
    element = car( here );

    /* Pattern we're matching for: */
    match_grouple = xveo10_List_To_Grouple( element );
	
    /* Get the grouple, if present: */
    Nancy_QuerySpace(
	match_grouple,
	local_or_non_local,
	which_space_to_search,
	how_many_to_match,
	copy_or_get,
       &result_grouple	
    );

    /* If no match occurred, QuerySpace returns nil, not an empty grouple: */
    if (!result_grouple)   return NIL;

    /* Convert the grouple to a list, and return it: */
    return xveo20_Grouple_To_List( result_grouple );    
}
