/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         xveo.h
* Description:  Header file for connecting to the HIT Lab's VEOS.
* Author:       Jerry Prothero
* Created:      91Aug22
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, University of Washington (by Jerry Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jerry Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jerry Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JERRY PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send improvements and bugfixes to jsp@glia.biostr.washington.edu.
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

#ifdef MODULE_XLINIT_C_XLINIT
/* Code to be executed on program start-up: */
xveo50_Init();
#endif

#ifdef MODULE_XLISP_C_WRAPUP
/* Code to be executed on program exit: */
xveo60_Wrap();
#endif

#ifdef MODULE_XLDMEM_H_GLOBALS
/* New extern declarations to appear in xldmem.h. */
extern LVAL xveo30_VEOS_Get();
extern LVAL xveo40_VEOS_Put();
extern LVAL xveo70_VEOS_Copy();
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Native xlisp names of the new primitives: */
DEFINE_SUBR( "VEOS-GET",  xveo30_VEOS_Get  )
DEFINE_SUBR( "VEOS-PUT",  xveo40_VEOS_Put  )
DEFINE_SUBR( "VEOS-COPY", xveo70_VEOS_Copy )
#endif




