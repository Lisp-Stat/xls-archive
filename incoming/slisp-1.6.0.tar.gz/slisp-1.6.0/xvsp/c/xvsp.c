/************************************************************************/
/*                          	xvsp.c					*/
/* SGI VideoSplitter support.						*/
/************************************************************************/

/**************************************************************************
*
* File:         xvsp.c
* Description:  Source code for xvsp.c video splitter objects.
* Author:       Jerry Prothero
* Created:      92Jan08
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, Human Interface Technology Lab (by Jerry Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of Human Interface Technology
* Lab and Jerry Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  Human Interface Technology Lab and 
* Jerry Prothero make no representations about the suitability of this 
* software for any purpose. It is provided "as is" without express or 
* implied warranty.
* 
* HUMAN INTERFACE TECHNOLOGY LAB AND JERRY PROTHERO DISCLAIM ALL WARRANTIES 
* WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL HUMAN INTERFACE TECHNOLOGY
* LAB NOR JERRY PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to 
* prothero@hitl.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
****************************************************************************/

/************************************************************************/
/*                              contents                                */
/*									*/
/*		(generated via "grep '/\*\.' xvsp.c")			*/
/************************************************************************/

/************************************************************************/
/*                          history   				        */
/*									*/
/* 92Jan08 jdp  Created.						*/
/************************************************************************/

/************************************************************************/
/* Nausea in Virtual Reality:						*/
/*     "That's a sign of how powerful the medium is."  -- Tom Furness.  */
/*     "That it can make you barf?" -- Warren Robinett 			*/
/************************************************************************/

/*****************************************************/
/* "People make so much money off Apple's mistakes." */
/*	-- A HITLite				     */
/*****************************************************/

/************************************************************************/
/* "Since this is virtual reality, why not have imaginary coordinates?" */
/************************************************************************/

/**********************************************************************/
/* "Lord Babbage was an outspoken supporter of the Webb method; as a  */
/*  result, every school-boy knew that the methane potential from a   */
/*  single cow was adequate for an average household's daily heating, */
/*  lighting, and cooking requirements."			      */
/*	*The Difference Engine*, Gibson and Sterling		      */
/**********************************************************************/

/* Why does this need stdlib.h twice? -- CrT */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gl.h>
#include <device.h>
#include <sys/types.h>
#include <malloc.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <device.h>
#include <math.h>
#include "/usr/video/vs/include/vs.h"

#include "../../xcore/c/xlisp.h"
#include "../../xgplotlib/c/dist/gplotlib/gtplot.h"

extern LVAL lv_xvsp;

extern LVAL s_stdout;
extern LVAL xsendmsg0(); 
extern LVAL xsendmsg2(); 
#define xvspp(o) (getclass(o) == lv_xvsp)
#include <math.h>
#include "../../3d/c/lib.h"
#include "../../3d/c/csry.h"
#include "../../3d/c/xcmr.h"
#include "xvsp.h"
#include "cvsp.h"

LVAL xvsp41_Map_Cameras_Msg();
LVAL xvsp31_Close_Video_Splitter();
LVAL cvfixnum();

/************************************************************************/
/*.xvsp00_Is_New -- Initialize a new xvsp instance.			*/
/************************************************************************/

LVAL xvsp00_Is_New()
/*-
    Initialize a new video splitter object.
-*/
{
    int	     config_ok;
    long     horiz;
    long     vert;
    VS_DEV * VS_Device;

    extern LVAL xgbj11_Set_Size_In_Bytes();
    LVAL m    = xlgagobject();
    cvsp_rec* r;

    if (!xvspp(m))   xlbadtype(m);

    /* Allocate space for context record: */
    xgbj11_Set_Size_In_Bytes( m, sizeof(cvsp_rec) );
 
    /*****************************************************************/
    /* Get the values we use for positioning the cameras.  We stick  */
    /* each camera viewport in a quarter screen, which means 640x512 */
    /* pixels for the SGI 320.  In fact, though, the video-splitter  */
    /* will only take 640-496 pixels, so we are losing 16 pixels off */
    /* the top in the eyephone image.  We could hard-wire 640x496,   */
    /* but it seems more natural to stick with the quarter-screen    */
    /* approximation, trusting that this will cause less problems    */
    /* down the road.						     */
    /*****************************************************************/
    xvsp50_GetScreenSize( &horiz, &vert );
    
    /* State information for this instance: */
    r	= (cvsp_rec*) gobjimmbase( m );

    config_ok = vs_check_config(VS_DEF_ID);
    if (config_ok == VS_FOUND) {

	int ok = 1;
	VS_Device   = vs_open(VS_DEF_ID);
	if (VS_Device) {

	    /* Success: */
	    if (vs_set_outformat(VS_Device, VS_RS170A)              ) ok = 0;
	    if (vs_set_origin(VS_Device, VS_CHANNEL_3, 0,         0)) ok = 0;
	    if (vs_set_origin(VS_Device, VS_CHANNEL_4, horiz / 2, 0)) ok = 0;
	}

	/* Death and gloom: */
	if (!ok)   xlfail( "Video Splitter Error" );
    }

    /**************************************************************************/
    /* Make the display window as large as 1/2 screen.  We have to do this    */
    /* because the video splitter will be mapping from the bottom left and    */
    /* bottom right quadrants:  therefore, we have to be sure that the window */
    /* covers these quadrants.						      */
    /**************************************************************************/
    {
	int ok = 1;
	gt_fhue hue;
        if (!GTterm_tbl[ gt_stat->terminal ].gt_set_window(
	    0,
	    horiz -1,
	    0,
	    vert/2 -1
	)) {
	    ok = 0;
	}
	hue.fr = 1.0;
	hue.fg = 1.0;
	hue.fb = 0.0;
        if (!GTterm_tbl[ gt_stat->terminal ].gt_set_color( &hue )) {
	    ok = 0;
	}
        GTterm_tbl[ gt_stat->terminal ].gt_clear_viewport();
        GTterm_tbl[ gt_stat->terminal ].gt_swap_buffers();
	if (!ok)   xlfail( "video-splitter window error" );
    }

    /* Remember: */
    r->video_splitter = VS_Device;
    r->horiz	      = horiz;
    r->vert	      = vert;

    return m;
}

/************************************************************************/
/*.xvsp01_Get_A_XVSP -- Get arg, must be of class xvsp.			*/
/************************************************************************/

LOCAL LVAL xvsp01_Get_A_XVSP()
/*-
    Get arg, must be of class xvsp.
-*/
{
    LVAL m_as_lval = xlgagobject();

    /***********************************************************/
    /* Nobody but class XVSP has any business calling          */
    /* any function in this file, but they *can*, so we        */
    /* check that we actually got a xcmr.  Similarly,          */
    /* nobody but nobody has any business resizing a xcmr,     */
    /* but they *can*, so again we check (to avoid clobbering  */
    /* memory if they did):                                    */
    /***********************************************************/
    if (!xvspp(m_as_lval) || 
        getgobjimmbytes(m_as_lval) != sizeof(cvsp_rec) 
    ) {
        xlbadtype(m_as_lval);
    }
    return m_as_lval;
}



/************************************************************************/
/*.xvsp03_Show_Msg -- Show the contents of a cvsp.			*/
/************************************************************************/

LVAL xvsp03_Show_Msg()
/*-
    Show the contents of a vsp.
-*/
{
    LVAL self,fptr;
    int i;

    /* get self and the file pointer */
    self = xvsp01_Get_A_XVSP();
    fptr = (moreargs() ? xlgetfile() : getvalue(s_stdout));
    xllastarg();

    xgbj51_Show_Instance_Variables(self,fptr);
    xgbj52_Show_Lval_Vector(self,fptr);

    /* Print the vsp record: */
/* TO BE COMPLETED.  Honest... */

    /* return the gobject */
    return self;
}

/***************************************************************************/ 
/*.     xvsp20_Wrapup_Msg   Close VideoSplitter module. 	           */
/***************************************************************************/ 
LVAL xvsp20_Wrapup_Msg()
/*-
  Code executed when object is recycled.
-*/
{
    return xvsp31_Close_Video_Splitter();
}

/***************************************************************************/ 
/*.     xvsp31_Close_Video_Splitter       Close VideoSplitter module.      */
/***************************************************************************/ 
LVAL xvsp31_Close_Video_Splitter()
/*-
  Close VideoSplitter module.
-*/
{
    /* The object holding the video splitter info: */
    LVAL m = xvsp01_Get_A_XVSP();

    /* Fetch record holding video splitter info: */
    cvsp_rec *r = (cvsp_rec*) gobjimmbase( m );

    if (r->video_splitter != NULL) {
        vs_close( r->video_splitter );
        r->video_splitter = NULL;
    }

    return m;
}

/***************************************************************************/
/*.     xvsp41_Map_Cameras_Msg   Bind two cameras to left, right VS ports. */
/***************************************************************************/
LVAL xvsp41_Map_Cameras_Msg()
/*-
  Bind two cameras to left & right video splitter ports (bottom left & roit quads).
-*/
{
    /* The object holding the video splitter info: */
    LVAL m = xvsp01_Get_A_XVSP();

    /* Fetch record holding video splitter info: */
    cvsp_rec *r = (cvsp_rec*) gobjimmbase( m );
    long horiz  = r->horiz;
    long vert   = r->vert;

    /* Fetch cameras from argument stack: */
    LVAL pair_camera   = xlgaobject();
    LVAL left_camera   = xlgaobject();
    LVAL roit_camera   = xlgaobject();

    /* The ":put" message: */
    LVAL put_lval      = xlenter( ":PUT" );

    /* Used for building up lists, protected from garbage collector: */
    LVAL val;

    /* Should be only the camera pair and two cameras as args: */
    xllastarg();

    /* Make sure that the arguments were cameras: */
    if (getclass(left_camera) != lv_xcmr) {
	xlerror( "needed camera arg", left_camera );
    }
    if (getclass(roit_camera) != lv_xcmr) {
	xlerror( "needed camera arg", roit_camera );
    }

    /* Set the port for the pair of both cameras: */
    xlsave1(val);
    val = cons( cvfixnum(0), NIL );
    val = cons( cvfixnum(0), val );
    xsendmsg2(
	 pair_camera,
	 put_lval,
	 k_port_loc,
	 val
    );
    val = cons( cvfixnum(vert  / 2 -1), NIL );
    val = cons( cvfixnum(horiz     -1), val );
    xsendmsg2(
	 pair_camera,
	 put_lval,
	 k_port_siz,
	 val
    );

    /* Set the port for the left camera: */
    xlsave1(val);
    val = cons( cvfixnum(0), NIL );
    val = cons( cvfixnum(0), val );
    xsendmsg2(
	 left_camera,
	 put_lval,
	 k_port_loc,
	 val
    );
    val = cons( cvfixnum(vert  / 2 -1), NIL );
    val = cons( cvfixnum(horiz / 2 -1), val );
    xsendmsg2(
	 left_camera,
	 put_lval,
	 k_port_siz,
	 val
    );

    /* Set the port for the right camera: */
    val = cons( cvfixnum(0        ), NIL );
    val = cons( cvfixnum(horiz / 2), val );
    xsendmsg2(
	 roit_camera,
	 put_lval,
	 k_port_loc,
	 val
    );
    val = cons( cvfixnum(vert  / 2 -1), NIL );
    val = cons( cvfixnum(horiz / 2 -1), val );
    xsendmsg2(
	 roit_camera,
	 put_lval,
	 k_port_siz,
	 val
    );

    /* Unprotect val: */
    xlpop();

    return m;
}

/***************************************************************************/
/*.     xvsp50_GetScreenSize 	 Horiz and Vert size in pixels.		   */
/***************************************************************************/
xvsp50_GetScreenSize( horizP, vertP )
long *		      horizP;
long *			      vertP;
{
    long iRetVal;
    
    *horizP = getgdesc( GD_XPMAX );
    *vertP  = getgdesc( GD_YPMAX );
}
