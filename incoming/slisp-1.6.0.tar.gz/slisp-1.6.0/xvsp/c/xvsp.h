/**************************************************************************
*
* File:         xvsp.h
* Description:  Xlisp header file for xvsp.c video splitter objects.
* Author:       Jerry Prothero
* Created:      92Jan08
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, Human Interface Technology Lab (by Jerry Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of Human Interface Technology
* Lab and Jerry Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  Human Interface Technology Lab and 
* Jerry Prothero make no representations about the suitability of this 
* software for any purpose. It is provided "as is" without express or 
* implied warranty.
* 
* HUMAN INTERFACE TECHNOLOGY LAB AND JERRY PROTHERO DISCLAIM ALL WARRANTIES 
* WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL HUMAN INTERFACE TECHNOLOGY
* LAB NOR JERRY PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to 
* prothero@hitl.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
***************************************************************************
*/




#ifdef MODULE_XLINIT_C_XLINIT
/* Code to be executed on program start-up: */
xvsp10_Init_Msg();
#endif

#ifdef MODULE_XLISP_C_WRAPUP
/* Code to be executed on program exit: */
xvsp20_Wrapup_Msg();
#endif

#ifdef MODULE_XLDMEM_H_GLOBALS
/* New extern declarations to appear in xldmem.h. */
extern LVAL xvsp31_Close_Video_Splitter_Msg();
extern LVAL xvsp41_Map_Cameras_Msg();
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Native xlisp names of the new primitives: */
DEFINE_SUBR(	NULL, xvsp00_Is_New         	      )
DEFINE_SUBR(	NULL, xvsp03_Show_Msg       	      )
DEFINE_SUBR(    NULL, xvsp41_Map_Cameras_Msg	      )
#endif



#ifdef MODULE_XLISP_C_WRAPUP
/* Code to be executed on program exit: */
xvsp20_Wrapup_Msg();
#endif

#ifdef MODULE_XLDMEM_H_GLOBALS
/* Our class object: */
extern LVAL lv_xvsp;

/* Following are defined here rather than in */
/* MODULE_XLFTAB_C_GLOBALS because we need   */
/* them in MODULE_XLOBJ_C_XLOINIT as well as */
/* in MODULE_XLFTAB_C_FUNTAB.                */
extern LVAL xvsp00_Is_New();
extern LVAL xvsp03_Show_Msg();
extern LVAL xvsp41_Map_Cameras_Msg();



#ifndef EXTERNED_S_PROPERTYLIST
extern LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define EXTERNED_S_PROPERTYLIST
#endif

#ifndef EXTERNED_SHOW
extern LVAL k_show;/* Keyword ":show" */
#define EXTERNED_SHOW
#endif

#endif



#ifdef MODULE_XLFTAB_C_GLOBALS
#endif



#ifdef MODULE_XLFTAB_C_FUNTAB_S
/* Following have NULL names because they are provided only as */
/* messages, not as xlisp functions.                           */
DEFINE_SUBR(	NULL,	xvsp00_Is_New			)
DEFINE_SUBR(	NULL,	xvsp03_Show_Msg			)
DEFINE_SUBR(	NULL,	xvsp41_Map_Cameras_Msg		)
#endif


#ifdef MODULE_XLGLOB_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
#endif


#ifdef MODULE_XLOBJ_C_GLOBALS
LVAL lv_xvsp;
LOCAL struct xvsp_message {
    char *gs_msg_name;  /* Message name              */
    LVAL (*gs_subr)();	/* C fn implementing message */
} xvsp_table[] = {
    {	":ISNEW", 	xvsp00_Is_New		        },
    {	":SHOW", 	xvsp03_Show_Msg		        },
    {   ":MAP-CAMERAS", xvsp41_Map_Cameras_Msg		},

    {	NULL,			 NULL			}
};



#ifndef DEFINED_S_PROPERTYLIST
LVAL s_propertylist;/* Symbol "PROPERTY-LIST" */
#define DEFINED_S_PROPERTYLIST
#endif

#ifndef DEFINED_SHOW
LVAL k_show;/* Keyword ":show" */
#define DEFINED_SHOW
#endif

#endif



#ifdef MODULE_XLOBJ_C_OBSYMBOLS
    lv_xvsp = getvalue(xlenter("CLASS-VIDEO-SPLITTER"));

#ifndef CREATED_S_PROPERTYLIST
    s_propertylist = xlenter("PROPERTY-LIST");
#define CREATED_S_PROPERTYLIST
#endif

#ifndef CREATED_SHOW
    k_show = xlenter(":SHOW");
#define CREATED_SHOW
#endif

#endif



#ifdef MODULE_XLOBJ_C_XLOINIT
    lv_xvsp = xgbj58_Create_Class("CLASS-VIDEO-SPLITTER",k_closed_gobject);
    xgbj57_Add_Instance_Variable( lv_xvsp,"PROPERTY-LIST");
    xgbj56_Enter_Messages( lv_xvsp,  xvsp_table );
#endif




















