
/**************************************************************************
*
* File:         cvsp.h
* Description:  C header file for xvsp.c video splitter objects.
* Author:       Jerry Prothero
* Created:      92Jan11
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1992, Human Interface Technology Lab (by Jerry Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of Human Interface Technology
* Lab and Jerry Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  Human Interface Technology Lab and 
* Jerry Prothero make no representations about the suitability of this 
* software for any purpose. It is provided "as is" without express or 
* implied warranty.
* 
* HUMAN INTERFACE TECHNOLOGY LAB AND JERRY PROTHERO DISCLAIM ALL WARRANTIES 
* WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL HUMAN INTERFACE TECHNOLOGY
* LAB NOR JERRY PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to 
* prothero@hitl.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
***************************************************************************
*/

/* A struct type that holds everything we need to know about a camera.  */
/* WARNING:  xvsp.c depends on the below order to initialize correctly. */
/* See xvsp00_Is_New.     						*/ 
struct cvsp_struct {
    VS_DEV *   video_splitter;	/* SG data structure for video splitters. */
    long       horiz;		/* Width of screen.			  */
    long       vert;		/* Height of screen.			  */
};
typedef struct cvsp_struct  cvsp_rec;



