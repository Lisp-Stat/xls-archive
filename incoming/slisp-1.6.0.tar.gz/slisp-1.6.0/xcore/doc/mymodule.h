/* -*-C-*-                                                                   CrT
********************************************************************************
*
* File:         mymodule.h
* Description:  Template for xlisp extension-module file headers.
* Author:       Jeff Prothero
* Created:      90Nov16
* Modified:     
* Language:     C
* Package:      N/A
* Status:       
*
* Copyright (c) 1991, University of Washington (by Jeff Prothero)
*
* Permission to use, copy, modify, distribute, and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies and that
* both that copyright notice and this permission notice appear in
* supporting documentation, and that the name of University of
* Washington and Jeff Prothero not be used in advertising or
* publicity pertaining to distribution of the software without specific,
* written prior permission.  University of Washington and Jeff Prothero make no
* representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
* 
* UNIVERITY OF WASHINGTON AND JEFF PROTHERO DISCLAIM ALL WARRANTIES WITH
* REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL UNIVERSITY OF WASHINGTON
* NOR JEFF PROTHERO BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
* PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
* TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* Please send modifications, improvements and bugfixes to jsp@milton.u.washington.edu
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
********************************************************************************
*/

/**************************************************************************/
/* Not infrequently, implementing a new xlisp class requires adding some  */
/* new primitive (== "implemented in C") functions to xlisp.  The new	  */
/* primitives may be needed to access special hardware resources, or they */
/* may be speed hacks needed to achieve acceptable performance.		  */
/* 								          */
/* This file is a template showing how to do so.  Make a copy of this	  */
/* file called, say, "xmyclass.h", insert a '#include "xmyclass.h"' line  */
/* xmodules.h, and then edit "xmyclass.h" following the directions below. */
/* REMEMBER TO DELETE ALL THE EXAMPLE CODE FROM YOUR COPY OF THIS FILE!   */
/**************************************************************************/

#ifdef MODULE_XLINIT_C_XLINIT
/**********************************************************/
/* In this section, you can specify code to be executed   */
/* on program startup.  For example, a graphics class	  */
/* may have to initialize the graphics hardware.      	  */
/*							  */
/* Example:						  */
/**********************************************************/
initfn();
#endif

#ifdef MODULE_XLISP_C_WRAPUP
/**********************************************************/

/* In this section, you can specify code to be executed   */
/* on program exit.  For example, a graphics class	  */
/* may have to de-allocate the graphics hardware.      	  */
/*							  */
/* Example:						  */
/**********************************************************/
wrapfn();
#endif

#ifdef MODULE_XLDMEM_H_GLOBALS
/* New macros to appear in xldmem.h. */
/* New extern declarations to appear in xldmem.h. */
/**********************************************************/
/* In this section, you should declare all your primitive */
/* functions -- those which will be visible to the xlisp  */
/* programmer. Examples:                                  */
/**********************************************************/
extern LVAL myshow();

/**********************************************************/
/* Here you need to declare a variable which points to    */
/* the class object for your hybrid class.  The "cls_"    */
/* prefix is conventional.  Example:                      */
/**********************************************************/
extern LVAL cls_myclass;

/**********************************************************/
/* If your class defines any new keywords *AND* IF YOUR   */
/* C PRIMITIVES NEED A QUICK WAY TO FIND THOSE KEYWORDS   */
/* you need externs for them here. (If your C code doesn't*/
/* need a permanent hard pointer to them, you can skip the*/
/* keyword stuff in this file entirely.)  The "k_" prefix */
/* is conventional. The macro stuff keeps different       */
/* modules which define the same keyword from tripping    */
/* over each other.  Drop all special chars.  Example:    */
/**********************************************************/
#ifndef EXTERNED_MYKEYWORD
extern LVAL k_mykeyword; /* For ":my-keyword" */
#define EXTERNED_MYKEYWORD
#endif
#endif

#ifdef MODULE_XLOBJ_C_GLOBALS
/**********************************************************/
/* Here you need to repeat the above "cls_" declarations, */
/* without the "extern".  Example:			  */
/**********************************************************/
LVAL cls_myclass;

/**********************************************************/
/* Here you need to set up a table listing all the        */
/* primitive (C-implemented) messages your class defines, */
/* along with the implementing function.  The table ends  */
/* with a NULL entry.                                     */
/**********************************************************/
LOCAL struct my_message {
    char *msg_name;     /* Message name              */
    LVAL (*msg_subr)();	/* C fn implementing message */
} my_table[] = {
    {	":SHOW",	myshow	},/* One line per message.   */

    {	NULL,		xm4IsNew} /* Don't delete this line! */
};
/* Note: myshow() should have been declared in the  */
/* MODULE_XLDMEM_H_GLOBALS section and listed in the*/
/* MODULE_XLFTAB_C_FUNTAB  section.                 */

/**********************************************************/
/* If your class defines any new keywords *AND* IF YOUR   */
/* C PRIMITIVES NEED A QUICK WAY TO FIND THOSE KEYWORDS   */
/* you must define them here. (If your C code doesn't     */
/* need a permanent hard pointer to them, you can skip the*/
/* keyword stuff in this file entirely.)  The "k_" prefix */
/* is conventional. The macro stuff keeps different       */
/* modules which define the same keyword from tripping    */
/* over each other.  Example:                             */
/**********************************************************/
#ifndef DEFINED_MYKEYWORD
LVAL k_mykeyword; /* For ":my-keyword" */
#define DEFINED_MYKEYWORD
#endif
#endif

#ifdef MODULE_XLOBJ_C_XLOINIT
/**********************************************************/
/* Here you create your class instances and initialize    */
/* your "cls_" variables to point to them.  Example:      */
/**********************************************************/
    cls_myclass = xlclass("MYCLASS",0);

/**********************************************************/
/* By default your new class will be a subclass of OBJECT.*/
/* If you want it to be a subclass of some other class,   */
/* such as cls_gobject or cls_closed_gobject, you need to */
/* hack the superclass slot by hand here:                 */
/**********************************************************/
    setivar(cls_myclass,SUPERCLASS,cls_closed_gobject);

/**********************************************************/
/* This boilerplate installs your messages in your class. */
/* Make sure "my_table" and "cls_myclass" match your above*/
/* declarations!                         		  */
/**********************************************************/
    xgbj56_Enter_Messages( cls_myclass,  my_table );
/**********************************************************/
/* If you're not including the gobject module, you'll need*/
/* to either clone xgbj56_Enter_Messages, or else drop the*/
/* above call in favor of the following code:             */    
/*  {							  */
/*      struct my_message * p = my_table;		  */
/*      while (p->msg_name != NULL) {			  */
/*          xladdmsg(					  */
/*              cls_myclass,				  */
/*              p->msg_name,				  */
/*              funtab_offset(p->msg_subr)		  */
/*          );				 		  */
/*          ++p;					  */
/*      }						  */
/*  }							  */
/**********************************************************/
#endif

#ifdef MODULE_XLOBJ_C_OBSYMBOLS
/**********************************************************/
/* Your MODULE_XLOBJ_C_XLOINIT "cls_" variables need to be*/
/* re-initialized here. (This runs after an image restore,*/
/* when everything may have moved around.)                */
/**********************************************************/
    cls_myclass = getvalue(xlenter("MYCLASS"));

/**********************************************************/
/* If your class defines any new keywords *AND* IF YOUR   */
/* C PRIMITIVES NEED A QUICK WAY TO FIND THOSE KEYWORDS   */
/* you must create them here. (If your C code doesn't     */
/* need a permanent hard pointer to them, you can skip the*/
/* keyword stuff in this file entirely.)  The "k_" prefix */
/* is conventional. The macro stuff keeps different       */
/* modules which define the same keyword from tripping    */
/* over each other.  Example:                             */
/**********************************************************/
#ifndef CREATED_MYKEYWORD
    k_mykeyword = xlenter(":MY-KEYWORD"); /* For ":my-keyword" */
#define CREATED_MYKEYWORD
#endif
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_S
/**********************************************************/
/* In this section, you specify the native xlisp name of  */
/* each of your primitive SUBR functions -- those which   */
/* want their arguments evaluated. (Most likely, all of   */
/* your primitives will be of this type.)		  */
/*							  */
/* Each line has two parts.				  */
/*							  */
/* The first part gives the xlisp name for your		  */
/* primitive.  Make it all upper case.  If your primitive */
/* is to be a message rather than a function, make this   */
/* this entry NULL.					  */
/*							  */
/* The second part is the name of your C function.	  */
/*							  */
/* Examples:						  */
/**********************************************************/
DEFINE_SUBR( "PRIM0", xlprim0 )
DEFINE_SUBR( "PRIM1", xlprim1 )
DEFINE_SUBR( "PRIM2", xlprim2 )
#endif

#ifdef MODULE_XLFTAB_C_FUNTAB_F
/**********************************************************/
/* In this section, you specify the native xlisp name of  */
/* each of your primitive FSUBR functions -- those which  */
/* do NOT want their arguments evaluated. (Most likely,   */
/* you will never write a such a special form.)		  */
/*							  */
/* Format is much like the previous section:		  */
/*							  */
/* Examples:						  */
/**********************************************************/
DEFINE_FSUBR( "MYFSUBR0", xlfsubr0 )
DEFINE_FSUBR( "MYFSUBR1", xlfsubr1 )
DEFINE_FSUBR( "MYFSUBR2", xlfsubr2 )
#endif





/**********************************************************/
/* Stuff beyond here gets increasingly obscure.  99% of   */
/* the time, you shouldn't need to use these. I'd just as */
/* soon discourage use of these, so I won't document them */
/* in any detail. Most of this stuff relates to creating  */
/* new xlisp node types, in the sense of #defining and    */
/* implementing new n_type values.  Instead of doing this,*/
/* you might want to consider creating a subclass of      */
/* GOBJECT instead.  This lets you hide arbitrary binary  */
/* data in your object without hacking the xlisp files.   */
/* If you *do* decide to implement new n_types, you'll    */
/* have to #define the new values in xldmem.h, worrying   */
/* about collisions with other packages which do the same */
/* thing.  (Most of?) the rest of your hacks should fit   */
/* in this file. 90Nov18 jsp.                             */
/**********************************************************/



#ifdef MODULE_XLFTAB_C_GLOBALS
/* New macros, externs etc for xlftab.c.            */
#endif

#ifdef MODULE_XLDMEM_H_NINFO
/* New entries for xldmem.h node "ninfo" union.     */
#endif

#ifdef MODULE_XLDBUG_C_BREAKLOOP_REPLACEMENT
/* If you need a different "breakloop" fn, define   */
/* NEED_TO_REPLACE_BREAKLOOP in the XLISP_H_MACROS  */
/* section above, and provide a replacement version */
/* of the function here.                            */
#endif

#ifdef MODULE_XLDMEM_C_GLOBALS
/* If you #defined new values for n_type, you need  */
/* cv... functions to create them.  Put them here.  */
#endif

#ifdef MODULE_XLDMEM_C_GC
/* If your C code keeps LVAL pointers around (try   */
/* to avoid this!), the garbage collector needs to  */
/* have special code to mark them.  If so, insert   */
/* a code fragment like                             */
/*    if (v_savedobjs)  mark(v_savedobjs);          */
/* here.                                            */
#endif

#ifdef MODULE_XLDMEM_C_MARK
/* If you defined new values for n_type, mark()     */
/* needs to know how to find all the LVALs (and     */
/* only the LVALs) in them.  Insert code here to do */
/* that.                                            */
#endif

#ifdef MODULE_XLDMEM_C_SWEEP
/* If you defined new values for n_type, sweep()    */
/* needs to know how to find and recycle any ram    */
/* associated with the node (and do any other       */
/* cleanup required by your application) when the   */
/* node gets garbage-collected.  Insert code here   */
/* to do that.                                      */
#endif

#ifdef MODULE_XLDMEM_C_XLMINIT
/* If you defined new roots for the garbage         */
/* collector, xlminit() needs to initialize them    */
/* (to NIL, typically).  Insert code here to do     */
/* that.                                            */
#endif

#ifdef MODULE_XLGLOB_C_GLOBALS
/* If you defined new roots for the garbage         */
/* collector, you need to declare them.  If you     */
/* defined new values for n_type, you will need to  */
/* define names for them.  Declare both here, like: */
LVAL a_newwidget=NIL;
LVAL v_newroot=NIL;
#endif

#ifdef MODULE_XLIMAGE_C_XLISAVE
/* If you defined new values for n_type which have  */
/* associated ram storage hidden somewhere, xlisave */
/* needs to know how to write them out. Insert code */
/* here to do that. (It is often sufficient to      */
/* simply jump to the regular vector code.)         */
#endif

#ifdef MODULE_XLIMAGE_C_XLIRESTORE
/* If you defined new values for n_type which have  */
/* extra ram storage hidden somewhere, xlirestore   */
/* needs to know how to recreate them.  Insert code */
/* here to do that. (It is often sufficient to      */
/* simply jump to the regular vector code.)         */
#endif

#ifdef MODULE_XLIMAGE_C_FREEIMAGE
/* If you defined new values for n_type which have  */
/* extra ram storage hidden somewhere, freeimage    */
/* needs to know how to free() the ram. Insert code */
/* here to do that. (It is often sufficient to      */
/* simply jump to the regular vector code.)         */
#endif

#ifdef MODULE_XLINIT_C_GLOBALS
/* Any new typename you defined in the XLGLOB_C_GLOBALS*/
/* section above needs to be defined "extern" here: */
extern LVAL a_newwidget;
#endif

#ifdef MODULE_XLINIT_C_XLSYMBOLS
/* Any new typename you defined in the XLGLOB_C_VARS*/
/* section above needs to get a symbol here. Any    */
/* other new symbols you need can be built here too.*/
a_newwidget	= xlenter("NEW-WIDGET");
#endif

#ifdef MODULE_XLOBJ_C_CLNEW
/* If your class needs objects created by a special */
/* replacment for the standard newobject() (sure you*/
/* can't use :ISNEW instead?), this is the place to */
/* hack a special check in.                         */
    if (ismyclass(self)) {
        return (my_newobject(self,getivcnt(self,IVARTOTAL)));
    }
#endif

#ifdef MODULE_XLPRIN_C_GLOBALS
/* Any externs you need to print stuff (xlprin.c).  */
#endif

#ifdef MODULE_XLPRIN_C_XLPRINT
/* If you defined new values for n_type, xlprint()  */
/* needs to know how to print them out.  Insert     */
/* code here to do that.                            */
#endif

#ifdef MODULE_XLSYS_C_GLOBALS
/* Externs for any new type symbols (xlprin.c):     */
extern LVAL a_newwidget;
#endif

#ifdef MODULE_XLSYS_C_XTYPE
/* If you defined new values for n_type, xtype()    */
/* needs to know how to convert them to symbols.    */
/* Insert code here to do that.                     */
#endif


