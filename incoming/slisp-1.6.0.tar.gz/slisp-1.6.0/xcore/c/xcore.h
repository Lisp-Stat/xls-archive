/* Dummy file.  Makes build_app script simpler   */
/* if every module 'mod' has a file mod/c/mod.h. */
