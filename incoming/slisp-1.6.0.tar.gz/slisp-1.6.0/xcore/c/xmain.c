/* xmain.c - main program for slisp - an extension that allows the addition
	of c-coded lisp primitives to xlisp  -  a small implementation of lisp
 	with object-oriented programming */
/*	xlisp version 2.1 Copyright (c) 1987, by David Michael Betz */
/*	slisp version 1.6 Copyright 1998, by University of Washington  */

#include "xlisp.h"

/* SWB 97.01.28 */
#include "kbsrv.h"

/* define the banner line string */
#define BANNER	"SLISP version 1.6, do (COPYING) for Copyright information" 

#define ORIGINALBANNER "XLISP version 2.1, Copyright (c) 1989, by David Betz"

/* global variables */
jmp_buf top_level;
LVAL debugsave;		    				   /* jfb */
extern int server_end;  			           /* jfb */
extern int server_data;					   /* jfb */

/* external variables */
extern LVAL s_stdin,s_evalhook,s_applyhook;
extern LVAL s_stdout, s_tracenable, s_breakenable;	   /* jfb */
extern LVAL s_1plus,s_2plus,s_3plus,s_1star,s_2star,s_3star,s_minus;
extern int xltrcindent;
extern int xldebug;
extern LVAL true;
extern char buf[];
extern FILE *tfp;

/* external routines */
extern FILE *osaopen();

/* SWB 97.02.04
   moved main()'s var decls to be global
   since I broke main into two functions. */
char *transcript;
CONTEXT cntxt;
int verbose,i;
LVAL expr;
int server_mode;     /* jfb */
int standalone_mode; /* SWB */
int server_port;     /* SWB */

/* main - the main routine */
main(argc,argv)
  int argc; char *argv[];
{

/* Include hybrid-class functions: *//* JSP */
#define MODULE_XLISP_C_MAIN
#include "xmodules.h"
#undef MODULE_XLISP_C_MAIN

    /* setup default argument values */
    transcript = NULL;
    verbose = FALSE;
    server_mode = FALSE;      /* jfb */
    standalone_mode = FALSE;  /* SWB */
    server_port=7000;         /* SWB */

    /* parse the argument list switches */
#ifndef LSC
    for (i = 1; i < argc; ++i) {
	if (argv[i][0] == '-') {
	    switch(argv[i][1]) {
	    case 't':
	    case 'T':
		transcript = &argv[i][2];
		break;
	    case 'v':
	    case 'V':
		verbose = TRUE;
		break;
	   /* s, e, d,x options for server control */ /* jfb */
	    case 's':
		server_mode = TRUE;
		break;
	    case 'e':
		server_end = atoi(&argv[i][2]);
		break;
	    case 'd':
		server_data = atoi(&argv[i][2]);
		break;
	    /* p for standalone server mode on sepcified port - SWB 97.01.28 */
	    case 'p':   
		server_mode=TRUE;
		standalone_mode=TRUE;
		server_port=atoi(&argv[i][2]);
		break;
	    }
        }
    }
#endif

    /* initialize and print the banner line */
    osinit(BANNER);

    /* setup initialization error handler */
    xlbegin(&cntxt,CF_TOPLEVEL|CF_CLEANUP|CF_BRKLEVEL,(LVAL)1);
    if (setjmp(cntxt.c_jmpbuf))
	xlfatal("fatal initialization error");
    if (setjmp(top_level))
	xlfatal("RESTORE not allowed during initialization");

    /* initialize xlisp */
    xlinit();
    xlend(&cntxt);
    /* If server_mode disable debugging and tracing */ /* jfb */
    xlsave1(debugsave);
    if (server_mode) {
	debugsave = xlmakesym("*DEBUGSAVE*");
	setvalue(debugsave, NIL);
        s_breakenable = debugsave;
        s_tracenable  = debugsave;
	}
    /* reset the error handler */
    xlbegin(&cntxt,CF_TOPLEVEL|CF_CLEANUP|CF_BRKLEVEL,true);

    /* open the transcript file */
    if (transcript && (tfp = osaopen(transcript,"w")) == NULL) {
	sprintf(buf,"error: can't open transcript file: %s",transcript);
	stdputstr(buf);
    }

    /* load "init.lsp" */
    if (setjmp(cntxt.c_jmpbuf) == 0) {
/*	xlload("init.lsp",TRUE,FALSE); non-jsp code */	/* JSP */
        extern LVAL xetc02_Load_Library();		/* JSP */
        xetc02_Load_Library("init.lsp",TRUE,FALSE);	/* JSP */
    }
	

    /* load any files mentioned on the command line */
    if (setjmp(cntxt.c_jmpbuf) == 0) {
	for (i = 1; i < argc; i++) {  
            extern LVAL xetc02_Load_Library();			/* JSP */
	    if (argv[i][0] != '-'   &&
/*             !xlload(argv[i],TRUE,verbose) non-jsp */		/* JSP */
	       !xetc02_Load_Library(argv[i],TRUE,verbose)	/* JSP */
            ) {
		xlerror("can't load file",cvstring(argv[i]));
    }   }   }

    /* target for restore */
    if (setjmp(top_level))
	xlbegin(&cntxt,CF_TOPLEVEL|CF_CLEANUP|CF_BRKLEVEL,true);

    /* protect some pointers */
    xlsave1(expr);

    /* SWB 97.01.28
       set up stand-alone mode */
    if (standalone_mode) {
      char *err;

      /* perform server initialization */
      if (err=srv_initServer(server_port)) {
	xlfatal(err);
      }
    } else {
      /* not standalone mode,
	 run as if one child */
      void xl_childMain();
      xl_childMain(); 
    }
}

/* SWB 97.02.04
   broke the rest of main into xl_childMain()
   so the kbsrv package can call this part directly */
void xl_childMain() {
  /* SWB-NOTE: if running in standalone-mode, only the
     child processes will get this far. */

  /* if stand-alone mode, wait for a connection
     SWB 97.01.28 */
  if (standalone_mode) {
    char *err;
    if (err=srv_wait4connection()) {
      xlfatal(err);
    }
  }
 
    /* For server_mode signal end of initialization output */ /* jfb */
    if (server_mode)
        xlputc(getvalue(s_stdout), server_end);               /* jfb */
 
  /* main command processing loop */
  for (;;) {
    
    /* setup the error return */
    if (setjmp(cntxt.c_jmpbuf)) {
      setvalue(s_evalhook,NIL);
      setvalue(s_applyhook,NIL);
      xltrcindent = 0;
      xldebug = 0;
      if (server_mode) 
	xlputc(getvalue(s_stdout), server_end);      /* jfb */
      xlflush();
    }
    
    /* print a prompt unless we are in server_mode */
    if (!server_mode)				     /* jfb */
      stdputstr("> ");
    
    /* temp hack */
    /* if (standalone_mode) {
      char prompt[256];
      sprintf(prompt,"(%d) > ",getpid());
      stdputstr(prompt);
    } */
    
    /* read an expression */
    if (!xlread(getvalue(s_stdin),&expr,FALSE))
      break;
    
    /* save the input expression */
    xlrdsave(expr);
    
    /* evaluate the expression */
    expr = xleval(expr);
    
    /* SWB-NOTE: need to find out what happens on (exit) */
    
    /* save the result */
    xlevsave(expr);
    
    /* print it */
    if (server_mode) 
      xlputc(getvalue(s_stdout), server_data);  	      /* jfb */
    stdprint(expr);
    if (server_mode) 
      xlputc(getvalue(s_stdout), server_end);  	      /* jfb */
    
  }
  /* SWB 97.01.28
     if stand-alone, close connection */
  if (standalone_mode) {
    srv_closeConnection();
  }

  xlend(&cntxt);
  
  /* clean up */
  wrapup();
}

