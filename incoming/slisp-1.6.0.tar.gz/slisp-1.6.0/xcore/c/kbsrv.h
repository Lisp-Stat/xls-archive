#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

/* function declarations */
char *srv_initServer(int portnum);
void srv_initChild();
char *srv_wait4connection();
void srv_closeConnection();
