
/*
 * Scandir returns the number of entries or -1 if the
 * directory cannot be opened or malloc fails.
 */
scandir(dir, nmptr, select, compar)
char *dir;
char ***nmptr;
int (*select)();
int (*compar)();
{
    DIR *dirp;
    char **array;
    char **realloc();
    struct dirent *ent;
    unsigned int nalloc = 10, nentries = 0;

    if ((dirp = opendir(dir)) == NULL)
        return(-1);

    array = (char **) malloc(nalloc * sizeof (char *));

    if (array == NULL)
        return(-1);

    while ((ent = readdir(dirp)) != NULL) {
        if (select && ((*select)(ent->d_name) == 0))
            continue;

        if (nentries == nalloc) {
            array = realloc(array, (nalloc += 10) * sizeof(char *));

            if (array == NULL)
                return(-1);
        }

        array[nentries] = (char *) malloc(DIRSIZE(ent)+1);
        strncpy(array[nentries], ent->d_name, DIRSIZE(ent));
        array[nentries][DIRSIZE(ent)] = NULL;
        nentries++;
    }

    closedir(dirp);

    if ((nentries + 1) != nalloc)
        array = realloc(array, ((nentries + 1) * sizeof (char *)));

    if (compar != 0)
        qsort(array, nentries, sizeof(char **), compar);

    *nmptr = array;
    array[nentries] = 0;     /* guaranteed 0 pointer */

    return(nentries);
}

alphasort(a, b)
char **a, **b;
{
    return(strcmp(*a, *b));
}
