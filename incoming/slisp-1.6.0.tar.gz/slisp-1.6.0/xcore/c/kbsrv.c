#include <stdio.h>
#include <unistd.h>
#include "signal.h"
#include "kbsrv.h"
/* #include "daemon.h" */
/* #include "sync.h" */
#include "flck.h"

#define MAXLINE  1024               /* for I/O */
/* #define SEMKEY   ((key_t) 697071L) */ /* semaphore ID */

/* variables global to this package */
int SERV_TCP_PORT;                  /* port to listen to */
int NUM_CHILDREN=4;                 /* number of server child processes */
int sockfd, newsockfd, semid;
int shutting_down=0;                /* so SIGCLD doesn't procreate */
int currently_serving=0;            /* to protect processes while sending
				       data, from the SIGTERM */

/* function decls. for internal use only */
void srv_makeChild();
void srv_parentTERM();
void srv_childTERM();
void srv_childDied();

/***********************************************************\
** srv_initServer()
**
** Prepares process for becoming standalone TCP server.
**   - Sets up signal handlers for process management
**   - Creates semaphore to be used by sercer children
**   - Binds and listens to specified port number
**
** Returns NULL if successful, otherwise returns an
** error string.
**
** SWB - 97.01.28
\***********************************************************/
char *srv_initServer(int portnum) {
  int                 newsockfd, temp, i;
  struct sockaddr_in  serv_addr;
  
  /* set up signal handlers */
  signal(SIGTERM, srv_parentTERM);
  signal(SIGCLD,  srv_childDied);

  /* create semaphore */
  /* if ((temp=sem_create(SEMKEY,1)) < 0) {
    return "srv_initServer(): can't open semaphore";
  } */

  /* open a TCP stream socket */
  if ((sockfd=socket(AF_INET,SOCK_STREAM,0)) < 0) {
    return "srv_initServer(): can't open stream socket";
  }

  /* bind local address so client can send to me */
  bzero((char *)&serv_addr, sizeof(serv_addr));
  serv_addr.sin_family      = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port        = htons(portnum);

  if (bind(sockfd,(struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
    return "srv_initServer(): can't bind local address";
  }

  /* listen up! */
  listen(sockfd,5);

  /* start spawning children */
  for (i=0; i < NUM_CHILDREN; i++) {
    srv_makeChild();
  }

  /* parent has now finished spawning children,
     so it needs just to block and wait for
     any signals it needs to handle (for
     process management */
  while(1) {
    pause();
  }

  /* should never reach */
  return "srv_initServer(): wierd runtime error";
    
}

/********************************************************\
** srv_makeChild()
**
** spawns a new server child process and starts it by
** calling xl_childMain(). Parent process returns normally
**
** SWB 97.02.04
\********************************************************/
void srv_makeChild() {
  int pid;
  void xl_childMain();

  if ((pid=fork()) == 0) {  /* in child */
    srv_initChild();        /* initialize child process */
    xl_childMain();         /* jump to read-eval-print loop */
    exit(1);                /* terminate when done */
  } /* else in parent */
}

/***********************************************************\
** srv_initChild()
**
** Prepares a server child process for operation
**   - Sets up signal handlers for process management
**   - Opens socket-regulating semaphore
**
** SWB - 97.01.28
\***********************************************************/
void srv_initChild() {
  /* set up child's signal handlers */
  currently_serving=0;
  signal(SIGTERM, srv_childTERM);

  /* open the socket-regulating semaphore */
  /* semid = sem_open(SEMKEY); */
}

char *srv_wait4connection() {
  struct sockaddr_in cli_addr;
  int clilen;

  acquire_socket_lock();

  /* wait for a connection */
  clilen = sizeof(cli_addr);
  newsockfd = accept(sockfd,(struct sockaddr *)&cli_addr, &clilen);
  if (newsockfd < 0) {
    return "srv_wait4connection(): accept error";
  }

  /* protect from SIGTERM death during service */
  currently_serving=1;

  /* release main socket resource */
  /* sem_signal(semid); */
  release_socket_lock();

  /* make stdin, stdout, and stderr all point ot this socket */
  dup2(newsockfd,0);
  dup2(newsockfd,1);
  dup2(newsockfd,2);

  /* setting these to unbeffered seems to help */
  setbuf(stdin,NULL);
  setbuf(stdout,NULL);
  setbuf(stderr,NULL);

  /* can now return to main program that works with stdin, stdout, stderr */
  return NULL;
}

void srv_closeConnection() {
  close(newsockfd);
  close(0);
  close(1);
  close(2);
}


void srv_parentTERM() {
  shutting_down=1;            /* set shutdown mode */
  close(sockfd);              /* close socket      */
  kill(0-getpid(),SIGTERM);   /* kill children     */
  exit(0);
}

void srv_childTERM() {
  if (!currently_serving) {  /* if not sending data */
    exit(0);                 /* die */

    /* NOTE: should make sure this is really what I want to do. 
       There might be some slisp cleanup we want to do here */
  }
  /* else */
  signal(SIGTERM, srv_childTERM);   /* reset handler */
  return;
}  

void srv_childDied() {
  int st;

  if (!shutting_down) {              /* if not shutting down... */
    srv_makeChild();                    /* make new child process */
  }
  wait(&st);                         /* take care of zombie */
  signal(SIGCLD,srv_childDied);      /* reset sig handler */
  return; 
}
