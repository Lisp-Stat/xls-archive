#include "flck.h"

#define LOCKFILE "/usr/tmp/.kblock"

static int lock_fd;

int acquire_socket_lock() {
  FILE *fp;

  if (!(fp=fopen(LOCKFILE,"w+"))) {
    return 0;  /* error */
  }

  lock_fd=fileno(fp);

  lockf(lock_fd,F_LOCK,0);
  return 1;
}

void release_socket_lock() {
  lockf(lock_fd,F_ULOCK,0);
  close(lock_fd);
}
