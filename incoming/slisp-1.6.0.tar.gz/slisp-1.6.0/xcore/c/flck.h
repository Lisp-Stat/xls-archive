#include <unistd.h>
#include <sys/fcntl.h>
#include <stdio.h>

int acquire_socket_lock();
void release_socket_lock();
