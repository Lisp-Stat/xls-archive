/* -*-C-*-
********************************************************************************
*
* File:         xlmfns.c
* Description:  xmain functions that were in xmain.c in 2.1 release
*		Needed to separate in slisp so programs other than xmain
*		could call lisp function
* Author:       David Michael Betz; Niels Mayer
* Created:      
* Modified:     Tue Dec 14 17:13:52 PST 1993 Jim Brinkley (jfb)
* Language:     C
* Package:      N/A
* Status:       
*
* WINTERP 1.0 Copyright 1989 Hewlett-Packard Company (by Niels Mayer).
* XLISP version 2.1, Copyright (c) 1989, by David Betz.
*
* Permission to use, copy, modify, distribute, and sell this software and its
* documentation for any purpose is hereby granted without fee, provided that
* the above copyright notice appear in all copies and that both that
* copyright notice and this permission notice appear in supporting
* documentation, and that the name of Hewlett-Packard and David Betz not be
* used in advertising or publicity pertaining to distribution of the software
* without specific, written prior permission.  Hewlett-Packard and David Betz
* make no representations about the suitability of this software for any
* purpose. It is provided "as is" without express or implied warranty.
*
* HEWLETT-PACKARD AND DAVID BETZ DISCLAIM ALL WARRANTIES WITH REGARD TO THIS
* SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
* IN NO EVENT SHALL HEWLETT-PACKARD NOR DAVID BETZ BE LIABLE FOR ANY SPECIAL,
* INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
* LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
* OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
* PERFORMANCE OF THIS SOFTWARE.
*
* See ./winterp/COPYRIGHT for information on contacting the authors.
* 
* Please send modifications, improvements and bugfixes to mayer@hplabs.hp.com
* Post XLISP-specific questions/information to the newsgroup comp.lang.lisp.x
*
*********************************************************************************/
#include "xlisp.h"
extern LVAL s_1plus,s_2plus,s_3plus,s_1star,s_2star,s_3star,s_minus;
extern FILE *tfp;

/* xlrdsave - save the last expression returned by the reader */
xlrdsave(expr)
  LVAL expr;
{
    setvalue(s_3plus,getvalue(s_2plus));
    setvalue(s_2plus,getvalue(s_1plus));
    setvalue(s_1plus,getvalue(s_minus));
    setvalue(s_minus,expr);
}

/* xlevsave - save the last expression returned by the evaluator */
xlevsave(expr)
  LVAL expr;
{
    setvalue(s_3star,getvalue(s_2star));
    setvalue(s_2star,getvalue(s_1star));
    setvalue(s_1star,expr);
}

/* xlfatal - print a fatal error message and exit */
#ifndef BOGUS
xlfatal(msg)
  char *msg;
{
    xoserror(msg);
    wrapup();
}
#else
static xlfatal_zero = 0;
xlfatal(msg)
  char *msg;
{
    xoserror(msg);
printf( "\ndummy printf %x, %x", 1 / xlfatal_zero, *(int*)xlfatal_zero );
    wrapup();
}
#endif


/* wrapup - clean up and exit to the operating system */
wrapup()
{
/* Include hybrid-class functions: *//* JSP */
#define MODULE_XLISP_C_WRAPUP
#include "xmodules.h"
#undef MODULE_XLISP_C_WRAPUP


    if (tfp)   osclose(tfp);

    osfinish();
    exit(0);
}

