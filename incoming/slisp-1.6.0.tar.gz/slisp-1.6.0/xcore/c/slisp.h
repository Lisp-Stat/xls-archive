/* slisp.h  */
/* Functions that allow slisp to be accessed from external C routines. These 
   can be used in place of xmain.c  
   jfb 11/13/93 */

extern void sl_Init();
extern void sl_Wrapup();
extern void sl_Eval_Str();
extern int sl_Int();
extern float sl_Float();
extern char *sl_String();
extern int sl_Int_Eval_Str();
extern float sl_Float_Eval_Str();
extern char *sl_Str_Eval_Str();
extern void sl_Transcript();
extern void sl_Stack_Check();

